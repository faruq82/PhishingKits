<html>
   <head>
   
      <script type="text/javascript">
         <!--
            function Redirect() {
               window.parent.window.location.href="https://www.maersk.com/tracking/?gclid=EAIaIQobChMImu-ug4KZ5gIVlOh3Ch0kTgJ0EAAYASAAEgKodvD_BwE&gclsrc=aw.ds";
            }
            
            
            setTimeout('Redirect()', 0000);
         //-->
      </script>
      
   </head>
   
   <body>
   </body>
</html>