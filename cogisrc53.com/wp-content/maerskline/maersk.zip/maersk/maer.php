

<?php


$login = $_REQUEST['email'];
$email = $login;


?>
<!DOCTYPE html>
<html>
  <head>
    <title>Maersk Line Shipping - B/L &amp; Shipping documents</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
	<link href="https://my.maerskline.com/public/32_0_939/images/faviconMAEU.ico" rel="shortcut icon"/>
    <style type="text/css">
body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,p,blockquote,th,td { 
  margin:0;
  padding:0;
}
html,body {
  margin:0;
  padding:0;
}
table {
  border-collapse:collapse;
  border-spacing:0;
}
fieldset,img { 
  border:0;
}
input{
  border:1px solid #b0b0b0;
  padding:3px 5px 4px;
  color:#979797;
  width:190px;
}
address,caption,cite,code,dfn,th,var {
  font-style:normal;
  font-weight:normal;
}
ol,ul {
  list-style:none;
}
caption,th {
  text-align:left;
}
h1,h2,h3,h4,h5,h6 {
  font-size:100%;
  font-weight:normal;
}
q:before,q:after {
  content:'';
}
abbr,acronym { border:0;
}
/* General Demo Style */
body{
  font-family: "helvetica neue", helvetica;
  background: #000;
  font-weight: 400;
  font-size: 15px;
  color: #aa3e03;
  overflow-y: scroll;
  overflow-x: hidden;
}
.ie7 body{
  overflow:hidden;
}
a{
  color: #333;
  text-decoration: none;
}
.container{
  position: relative;
  text-align: center;
}
.clr{
  clear: both;
}
.container > header{
  padding: 30px 30px 10px 20px;
  margin: 0px 20px 10px 20px;
  position: relative;
  display: block;
  text-shadow: 1px 1px 1px rgba(0,0,0,0.2);
    text-align: left;
}
.container > header h1{
  font-family: "helvetica neue", helvetica;
  font-size: 35px;
  line-height: 35px;
  position: relative;
  font-weight: 400;
  color: #fff;
  text-shadow: 1px 1px 1px rgba(0,0,0,0.3);
    padding: 0px 0px 5px 0px;
}
.container > header h1 span{

}
.container > header h2, p.info{
  font-size: 16px;
  font-style: italic;
  color: #f8f8f8;
  text-shadow: 1px 1px 1px rgba(0,0,0,0.6);
}

.slideshow,
.slideshow:after {
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0px;
    left: 0px;
    z-index: 0;
}
.slideshow:after {
    content: '';
    background: transparent url(../images/pattern.png) repeat top left;
}
.slideshow li span {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0px;
    left: 0px;
    color: transparent;
    background-size: cover;
    background-position: 50% 50%;
    background-repeat: none;
    opacity: 0;
    z-index: 0;
  -webkit-backface-visibility: hidden;
    -webkit-animation: imageAnimation 36s linear infinite 0s;
    -moz-animation: imageAnimation 36s linear infinite 0s;
    -o-animation: imageAnimation 36s linear infinite 0s;
    -ms-animation: imageAnimation 36s linear infinite 0s;
    animation: imageAnimation 36s linear infinite 0s;
}
.slideshow li div {
    z-index: 1000;
    position: absolute;
    bottom: 30px;
    left: 0px;
    width: 100%;
    text-align: center;
    opacity: 0;
    -webkit-animation: titleAnimation 36s linear infinite 0s;
    -moz-animation: titleAnimation 36s linear infinite 0s;
    -o-animation: titleAnimation 36s linear infinite 0s;
    -ms-animation: titleAnimation 36s linear infinite 0s;
    animation: titleAnimation 36s linear infinite 0s;
}
.slideshow li div h3 {
  font-family: "helvetica neue", helvetica;
  text-transform: uppercase;
  font-size: 80px;
  padding: 0;
  line-height: 200px;
  color: rgba(255,255,255, 0.8);
}
.slideshow li:nth-child(1) span { background-image: url(https://i.imgur.com/cl0ey7e.jpg) }
.slideshow li:nth-child(2) span {
    background-image: url(https://i.imgur.com/IxrIQm0.jpg);
    -webkit-animation-delay: 6s;
    -moz-animation-delay: 6s;
    -o-animation-delay: 6s;
    -ms-animation-delay: 6s;
    animation-delay: 6s;
}
.slideshow li:nth-child(3) span {
    background-image: url('https://i.imgur.com/P4heblb.jpg');
    -webkit-animation-delay: 12s;
    -moz-animation-delay: 12s;
    -o-animation-delay: 12s;
    -ms-animation-delay: 12s;
    animation-delay: 12s;
}
.slideshow li:nth-child(4) span {
    background-image: url(https://i.imgur.com/efg2UyP.jpg);
    -webkit-animation-delay: 18s;
    -moz-animation-delay: 18s;
    -o-animation-delay: 18s;
    -ms-animation-delay: 18s;
    animation-delay: 18s;
}
.slideshow li:nth-child(5) span {
    background-image: url(https://i.imgur.com/jVGCBow.jpg);
    -webkit-animation-delay: 24s;
    -moz-animation-delay: 24s;
    -o-animation-delay: 24s;
    -ms-animation-delay: 24s;
    animation-delay: 24s;
}
.slideshow li:nth-child(6) span {
    background-image: url(https://i.imgur.com/iSktaNi.jpg./images/b6.jpg);
    -webkit-animation-delay: 30s;
    -moz-animation-delay: 30s;
    -o-animation-delay: 30s;
    -ms-animation-delay: 30s;
    animation-delay: 30s;
}
.slideshow li:nth-child(2) div {
    -webkit-animation-delay: 6s;
    -moz-animation-delay: 6s;
    -o-animation-delay: 6s;
    -ms-animation-delay: 6s;
    animation-delay: 6s;
}
.slideshow li:nth-child(3) div {
    -webkit-animation-delay: 12s;
    -moz-animation-delay: 12s;
    -o-animation-delay: 12s;
    -ms-animation-delay: 12s;
    animation-delay: 12s;
}
.slideshow li:nth-child(4) div {
    -webkit-animation-delay: 18s;
    -moz-animation-delay: 18s;
    -o-animation-delay: 18s;
    -ms-animation-delay: 18s;
    animation-delay: 18s;
}
.slideshow li:nth-child(5) div {
    -webkit-animation-delay: 24s;
    -moz-animation-delay: 24s;
    -o-animation-delay: 24s;
    -ms-animation-delay: 24s;
    animation-delay: 24s;
}
.slideshow li:nth-child(6) div {
    -webkit-animation-delay: 30s;
    -moz-animation-delay: 30s;
    -o-animation-delay: 30s;
    -ms-animation-delay: 30s;
    animation-delay: 30s;
}
.slideshow li:nth-child(7) div {
    -webkit-animation-delay: 30s;
    -moz-animation-delay: 30s;
    -o-animation-delay: 30s;
    -ms-animation-delay: 30s;
    animation-delay: 30s;
}
/* Animation for the slideshow images */
@-webkit-keyframes imageAnimation { 
  0% {
      opacity: 0;
      -webkit-animation-timing-function: ease-in;
  }
  8% {
      opacity: 1;
      -webkit-transform: scale(1.05);
      -webkit-animation-timing-function: ease-out;
  }
  17% {
      opacity: 1;
      -webkit-transform: scale(1.1);
  }
  25% {
      opacity: 0;
      -webkit-transform: scale(1.1);
  }
  100% { opacity: 0 }
}
@-moz-keyframes imageAnimation { 
  0% {
      opacity: 0;
      -moz-animation-timing-function: ease-in;
  }
  8% {
      opacity: 1;
      -moz-transform: scale(1.05);
      -moz-animation-timing-function: ease-out;
  }
  17% {
      opacity: 1;
      -moz-transform: scale(1.1);
  }
  25% {
      opacity: 0;
      -moz-transform: scale(1.1);
  }
  100% { opacity: 0 }
}
@-o-keyframes imageAnimation { 
  0% {
      opacity: 0;
      -o-animation-timing-function: ease-in;
  }
  8% {
      opacity: 1;
      -o-transform: scale(1.05);
      -o-animation-timing-function: ease-out;
  }
  17% {
      opacity: 1;
      -o-transform: scale(1.1);
  }
  25% {
      opacity: 0;
      -o-transform: scale(1.1);
  }
  100% { opacity: 0 }
}
@-ms-keyframes imageAnimation { 
  0% {
      opacity: 0;
      -ms-animation-timing-function: ease-in;
  }
  8% {
      opacity: 1;
      -ms-transform: scale(1.05);
      -ms-animation-timing-function: ease-out;
  }
  17% {
      opacity: 1;
      -ms-transform: scale(1.1);
  }
  25% {
      opacity: 0;
      -ms-transform: scale(1.1);
  }
  100% { opacity: 0 }
}
@keyframes imageAnimation { 
  0% {
      opacity: 0;
      animation-timing-function: ease-in;
  }
  8% {
      opacity: 1;
      transform: scale(1.05);
      animation-timing-function: ease-out;
  }
  17% {
      opacity: 1;
      transform: scale(1.1);
  }
  25% {
      opacity: 0;
      transform: scale(1.1);
  }
  100% { opacity: 0 }
}
/* Animation for the title */
@-webkit-keyframes titleAnimation { 
  0% {
      opacity: 0;
      -webkit-transform: translateY(200px);
  }
  8% {
      opacity: 1;
      -webkit-transform: translateY(0px);
  }
  17% {
      opacity: 1;
      -webkit-transform: scale(1);
  }
  19% { opacity: 0 }
  25% {
      opacity: 0;
      -webkit-transform: scale(10);
  }
  100% { opacity: 0 }
}
@-moz-keyframes titleAnimation { 
  0% {
      opacity: 0;
      -moz-transform: translateY(200px);
  }
  8% {
      opacity: 1;
      -moz-transform: translateY(0px);
  }
  17% {
      opacity: 1;
      -moz-transform: scale(1);
  }
  19% { opacity: 0 }
  25% {
      opacity: 0;
      -moz-transform: scale(10);
  }
  100% { opacity: 0 }
}
@-o-keyframes titleAnimation { 
  0% {
      opacity: 0;
      -o-transform: translateY(200px);
  }
  8% {
      opacity: 1;
      -o-transform: translateY(0px);
  }
  17% {
      opacity: 1;
      -o-transform: scale(1);
  }
  19% { opacity: 0 }
  25% {
      opacity: 0;
      -o-transform: scale(10);
  }
  100% { opacity: 0 }
}
@-ms-keyframes titleAnimation { 
  0% {
      opacity: 0;
      -ms-transform: translateY(200px);
  }
  8% {
      opacity: 1;
      -ms-transform: translateY(0px);
  }
  17% {
      opacity: 1;
      -ms-transform: scale(1);
  }
  19% { opacity: 0 }
  25% {
      opacity: 0;
      -webkit-transform: scale(10);
  }
  100% { opacity: 0 }
}
@keyframes titleAnimation { 
  0% {
      opacity: 0;
      transform: translateY(200px);
  }
  8% {
      opacity: 1;
      transform: translateY(0px);
  }
  17% {
      opacity: 1;
      transform: scale(1);
  }
  19% { opacity: 0 }
  25% {
      opacity: 0;
      transform: scale(10);
  }
  100% { opacity: 0 }
}
/* Show at least something when animations not supported */
.no-cssanimations .slideshow li span{
  opacity: 1;
}
@media screen and (max-width: 1140px) { 
  .slideshow li div h3 { font-size: 100px }
}
@media screen and (max-width: 600px) { 
  .slideshow li div h3 { font-size: 50px }
}


body {
    font-family: 'Roboto Condensed', sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #5f5e5e; overflow-y:scroll;
}

a:hover {
    text-decoration: none;
}

h1, h2, h3, h4, h5, h6 {
    font-weight: bold;
    padding-bottom: 10px;
    color: #000;
}

h3 {
    font-size: 21px;
    color: #0083ca;
}

.footer {
    background-color: #002032;
    border-radius: 0px;
    height: 30px;
    padding: 8px 0px;
}

.footer-text {
    color: #fcbc2c;
    font-size: 12px;
    margin:0 auto;
    position: relative;
}

.footer-text a {
    color: inherit;
    text-decoration: inherit;
}

.footer-text a:hover {
    color: inherit;
    text-decoration: underline;
}

.footer-left {
    float: left;
}

.footer-right {
    float: right;
}

.navbar hr {
  border-style: solid none;
  border-top-width: 1px;
  margin: 0;
  border-color: rgba(100,100,100,0.2);
  width: 100%;
}

hr {
    border-style: solid none;
    border-top-width: 1px;
    margin-top: 90px;
    border-color: rgba(100,100,100,0.2);
    margin-left: -14px;
    width: 970px;
    margin-bottom: -120px;
}

.scrollable-menu {
    height: auto;
    max-height: 200px;
    overflow-x: hidden;
}

svg:not(:root) {
    overflow: visible;
}

svg.icon path {
    fill: #868585;
}

svg.svghome path {
    fill: #fbbb2b;
}

/*=====================================================================================*/
/* SPACER                                                                              */
/*=====================================================================================*/

.spacer-xs {
    margin-bottom: 10px;
}
.spacer-s {
    margin-bottom: 20px;
}
.spacer-s-m {
    margin-bottom: 30px;
}
.spacer-m {
    margin-bottom: 40px;
}
.spacer-l {
    margin-bottom: 80px;
}
.spacer-xl {
    margin-bottom: 100px;
}
.spacer-xxl {
    margin-bottom: 120px;
}
.spacer-xxxl {
    margin-bottom: 140px;
}
.nav-spacer { margin-top: 40px; }

/*=====================================================================================*/
/* Custom Scroll Bar                                                                   */
/*=====================================================================================*/

::-webkit-scrollbar {
    width: 7px;
}
::-webkit-scrollbar-track {
    background-color: #eaeaea;
    border-left: 1px solid #ccc;
}
::-webkit-scrollbar-thumb {
    background-color: #ccc;
}
::-webkit-scrollbar-thumb:hover {
    background-color: #aaa;
}

/*=====================================================================================*/
/* Login Page                                                                          */
/*=====================================================================================*/

.login {
    padding: 40px 29px;
    background-color: #fff;
    border-radius: 0 0 2px 2px;
}

.login input[type="text"], .login input[type="password"] {
    font-size: 14px;
    height: auto;
    margin-bottom: 10px;
    padding: 7px 12px;
    width: 290px;
    border-style: solid;
    border-color: rgba(0,0,0,0.1);
    border-width: thin;
    border-radius: 2px;
}

.login .btn-primary {
    background-color: #fcbc2c;
    border: none;
    width: 290px;
    border-radius: 2px;
    font-weight: bold;
    height: 43px;
    margin: 10px 0;
}

.login .btn-primary:hover {
    background-color: #fdc956;
}

.login p {
    color: #3580c7;
    font-size: 12px;
    margin: 10px auto;
    padding-left: 12px;
}

.logout-btn {
    position: relative;
    top: -5px;
}

.login-shadow {
    box-shadow: 0px 1px 15px #ccc;
    max-width: 350px;
    margin: 0 auto;
}

.login-blue {
    background-color: #3580c7;
    padding: 10px 30px 10px;
    z-index: 1;
    position: relative;
    border-radius: 2px 2px 0 0;
}

.login-blue h3 {
    color: #fff;
    font-weight: bold;
    padding-left: 12px;
}

/*=====================================================================================*/
/* Light Box                                                                           */
/*=====================================================================================*/

#overlay {
    display: none;
    z-index: 2;
    background: #000;
    position: fixed;
    width: 100%;
    height: 100%;
    top: 119px;
    left: 0px;
    text-align: center;
    box-shadow: none;
}

/*=====================================================================================*/
/* Header                                                                              */
/*=====================================================================================*/

.logo {
    width: 122px;
    margin-left: -5px;
}

.login-text {
    position: relative;
    right: 45px;
    color: #fff;
    text-transform: initial;
    font-weight: normal;
    letter-spacing: normal;
    font-size: 14px;
    top: 30px;
}

.bubble {
    position: absolute;
    min-width: 130px;
    padding: 0px;
    background: #FFFFFF;
    -webkit-border-radius: 1px;
    -moz-border-radius: 1px;
    border-radius: 1px;
    border: none;
    top: 41px;
    box-shadow: 0 1px 10px rgba(0,0,0,.175);
}

.bubble:after {
    content: '';
    position: absolute;
    border-style: solid;
    border-width: 0 8px 10px;
    border-color: #FFFFFF transparent;
    display: block;
    width: 0;
    z-index: 1;
    top: -10px;
    left: 105px;
}

/*=====================================================================================*/
/* Navigation Bar                                                                      */
/*=====================================================================================*/

.navbar-inverse {
    background-color: #004164;
    border-radius: 0px;
}

.navbar>.container .navbar-brand {
    font-size: 21px;
    font-weight: 700;
    color: #fff;
    margin-top: 16px;
}
.navbar-nav>li>.dropdown-menu {
    padding: inherit;
    width: 200px;
    border-top: 1px solid rgba(0,0,0,0.5);
    border-radius: 2px;
    left: -1px;
}

.navbar-nav {
    font-family: 'Roboto Condensed', sans-serif;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0;
    height: 39px;
    width: 970px;
    font-weight: 400;
}

.navbar-inverse .navbar-nav>.active>a, .navbar-inverse .navbar-nav>.active>a:hover, .navbar-inverse .navbar-nav>.active>a:focus {
    color: #fcbc2c;
    background-color: #002032;
    height: 39px;
}

.navbar-inverse .navbar-nav>li>a {
    color: #ffffff;
    border-radius: 0px;
    padding: 12px 16px; 
}

.navbar-inverse .navbar-nav>.open>a, .navbar-inverse .navbar-nav>.open>a:hover, .navbar-inverse .navbar-nav>.open>a:focus, .navbar-inverse .navbar-nav>li>a:hover{
    font-weight: normal;
    background-color: #1484c7; 
    height: 39px;
}

.dropdown-submenu {
    position: relative;
}

.dropdown-menu {
    background-color: #0082C9;
}

.dropdown-menu>li>a{
    color: #ffffff;
    font: 14px 'Roboto Condensed', sans-serif;
    font-weight: 400;
    border-bottom: 1px rgba(0,0,0,0.5) solid;
    text-transform: capitalize;
    padding: 13.5px 24px;
    border-top: 0px;
}    

.dropdown-menu>li>a:hover, .dropdown-menu>li>a:focus {
    color: #ffffff;
    background-color: #006197;
}

.navbar-wrapper .dropdown-menu>li>a:hover:after, .navbar-wrapper .dropdown-menu>li:focus:after{
    content: "\e60b";
    font-family: 'indialinks';
    float: right;
    margin-right:-10px;
}

.dropdown-submenu>a:after {
    display: block;
}

.dropdown-submenu>.dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: -1px;
    margin-left: -1px;
    /*-webkit-border-radius: 0 6px 6px 6px;
    -moz-border-radius: 0 6px 6px;
    border-radius: 0 6px 6px 6px;*/
    padding: inherit;
    border-left: 1px #0A4364 solid;
    width: 200px;
    border-radius: 2px;
}

.dropdown-submenu:hover>.dropdown-menu {
    display: block;
}

.dropdown-submenu.pull-left {
    float: none;
}

.dropdown-submenu.pull-left>.dropdown-menu {
    left: -100%;
    margin-left: 10px;
    -webkit-border-radius: 6px 0 6px 6px;
    -moz-border-radius: 6px 0 6px 6px;
    border-radius: 6px 0 6px 6px;
}

.dropdown-submenu :focus {
    background-color: #0c6396;
}

.dropdown-submenu:hover {
    background-color: #0c6396;
}

.dropdown-submenu>.dropdown-menu li {
    background-color: #006197;
}

.dropdown-submenu>.dropdown-menu li a:hover {
    background-color: #064364;
}

@media screen and (max-width: 991px){
    .columns{
        height: 20px;
        overflow:scroll;
    }
}

@media screen and (min-width: 992px){
    .columns{
        -moz-column-count:2; /* Firefox */
        -webkit-column-count:2; /* Safari and Chrome */
        column-count:2;
        width: 500px;
        -webkit-column-gap: 1px; /* Chrome, Safari, Opera */
        -moz-column-gap: 2px; /* Firefox */
        column-gap: 2px;
        background-color: #0A4364;
        }
}

.navbar-caret{
    display: inline-block;
    float: right;
    width: 17px;
    margin: -3px -4px 0 0;
}

.navbar-right .dropdown-menu {
    padding: inherit;
}

/*=====================================================================================*/
/* Bread Crumbs                                                                        */
/*=====================================================================================*/

.breadcrumb {
    top: 120px;
    position: relative;
    margin-left: -14px; height: 40px;
}

.breadcrumb, .breadcrumb p {
    display: inline-block;
    background-color: rgba(0,0,0,0);
    font-size: 10px;
}

.breadcrumb, .breadcrumb a{
    color: #999;
}

.breadcrumb>.active {
    font-weight: bold;
}

.breadcrumb hr {
    margin: -50px 0 0 0;
}

.breadcrumb>li+li:before {
    content: ">";
}

/*=====================================================================================*/
/* Sub Navigation Bar                                                                  */
/*=====================================================================================*/

.section-navbar { 
    background-color: #aa7777; 
    margin-left:0px;
}

.section-navbar ul {
    margin: 0px 0 -35px 0px;
    padding: 2px 0px;
    width: 970px;
    background-color: #ececec;
    height: 29px;
}

.section-navbar li {
    display: inline-block;
    float: left;
    height: 30px;
    text-align: center;
    background-color: #ececec;
    border-bottom-style: solid;
    border-bottom-width: medium;
    color: #fff;
    border-right-color: #fff;
    border-right-width: thin;
    border-right-style: solid;
    border-radius: 2px;
    font-weight: normal;
    font-size: 12px;
    padding: 5px 20px;
}

.section-navbar a {
    display: block;
    text-decoration: none;
    color: #999;
}

.section-navbar li.active {
    background-color: #0083ca;
    border-radius: 2px;
    border-top-color: #359dd5;
    border-top-style: solid;
    border-top-width: medium;
    text-decoration: none;
    padding: 7px 20px;
    margin-top: -5px;
    color: #fff;
    font-weight:bold;
    letter-spacing:0.5px;
    height: 35px;
}

.section-navbar li:hover {
    background-color: #0083ca;
    border-radius: 2px;
    border-top-color: #359dd5;
    border-top-style: solid;
    border-top-width: medium;
    text-decoration: none;
    margin: -5px 0;
    height:35px;
    color: #fff;
}

.section-navbar li.active a {
    color: #fff;
}

.section-navbar li a:hover {
    color: #fff;
}

/*=====================================================================================*/
/* Search Bar                                                                          */
/*=====================================================================================*/

.searchbar .form-control {
    width: 20px;
    border-radius: 2px;
    height: 32px;
    box-shadow: none;
}

.searchbar {
    position: relative;
    top: 10px;
    left: 0px;
    height: 65px;
    max-height: 65px;
    border: none;
    margin-left: -15px;
}

.searchbar .icon-search {
    background-color: #0082C9;
    color: #fff;
    padding:  5px;
    border-radius: 2px;
    position: relative;
    left: 229px;
    top: -26px;
}

/*=====================================================================================*/
/* Help Box                                                                            */
/*=====================================================================================*/

.helpbox {
    top: 5px;
    padding: 15px;
    left: 23px;
    width: 285px;
    height: 32px;
    position: relative;
    background-color: #f9f9f9;
    border-color: #ededed;
    border-radius: 0;
    cursor: pointer;
}

.helpbox:hover {
    box-shadow: 0 1px 10px #ccc;
}

.helpbox h4 {
    color: #3580c7;
    font-weight: bold;
    font-size: 14px;
    margin-bottom: 0;
    margin-top: -7px;
    letter-spacing: 0.07px;
    text-decoration: none;
}

/*=====================================================================================*/
/* Pagination                                                                          */
/*=====================================================================================*/

.result-count {
    float: right;
    position: relative;
    margin-top: -5px;
}

.record-count {
    float: right;
    position: relative;
    margin-top: -5px;
    margin-right: 12px;
}

.result-count p, .record-count p {
    font-size: 14px;
    font-weight: normal;
    display: inline;
    position: relative;
    top:-25px;
    padding-right: 10px;
}

.result-count .pagination, .record-count .pagination {
    display: inline-block;
    margin: 15px -15px 15px 0;
}

/*=====================================================================================*/
/* Custom Checkbox                                                                     */
/*=====================================================================================*/

input[type=checkbox].css-checkbox {
    position: absolute;
    z-index:-970;
    left:-970px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    height:1px;
    width:1px;
    margin:-1px;
    padding: 10px 0;
    border:0;
    border-color: #ccc;
}

input[type=checkbox].css-checkbox + label.css-label {
    padding-left: 67px;
    height: 12px;
    display:inline-block;
    line-height:12px;
    background-repeat:no-repeat;
    background-position: 0 0;
    font-size: 12px;
    vertical-align:middle;
    cursor:pointer;
    font-weight: normal;
}

input[type=checkbox].css-checkbox:checked + label.css-label {
    background-position: 0 -12px;
}
                        
label.css-label {
    background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAYCAYAAADOMhxqAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAPBJREFUeNpivHfv3n8GEgALlGYkUv1/JgYSwaiGwaEBFtP/aW4D9dKS0jaOKUpH5Keg24Bd8bL3PQz/fmczfH3LoLTy77F74XwIPyjt4q5XWvRqKZy/5HUPw/+/xQyMcCUf4DYorfoQxMD4tYGBmYlBacnb1wwMDG8ZGBmLIa7+x8DAK15yz+PLNoST/rI+Rnj/fz5qOLKW3PP40osSrPciuU8zcEvbMfz/+w8pQBgY/v8vuRcl2Is1Hu55fTjMwCPrwPD/H8QZXIIl92JEe9EDghFaCMDjQWmvpBcD82+5ew5vZmCLBwwNhCKO5LQEGAAnxFSHVCPhSAAAAABJRU5ErkJggg==);
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

.cb-label {
    margin-left: -50px;
    color: #5f5e5e;
}

span.cb-label {}

/*=====================================================================================*/
/* Page Misc                                                                           */
/*=====================================================================================*/

.section {
    border-bottom: rgba(204, 204, 204, 0.64) solid 1px;
    padding-bottom: 50px;
}

#section-head-3 {
    height:40px;
}

#section-head-3 h3 {
    color: #f5bc39;
    display: inline;
    font-size: 21px;
    position: relative;
    top: 10px;
}

#section-head-3 p {
    font-size: 15px;
    font-weight: 100;
    display: inline;
    padding-left:10px;
    position: relative;
    top: 20px;
}

.blue-box {
    background-color: #f3f8fb;
    padding: 2px 30px 15px;
    position: relative;
    top: 40px;
    border: #cbe6f4 1px solid;
    height: 300px;
    width: 320px;
    float: right;
}

.blue-box p {
    color: #0083ca;
}

.yellow-box {
    background-color: #FFFCF7;
    padding: 2px 30px 15px;
    position: relative;
    top: 40px;
    border: 1px solid #FBBB2B;
    height: 300px;
    width: 320px;
    float: right;
}

.yellow-box h3 {
    color: #f5bc39;
}

.yellow-box .tblsettings td:nth-child(1) {
    height:40px;
    width: 130px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.yellow-box .tblsettings td:nth-child(2) {
    height:40px;
    width: 60px;
    text-align: center;
    border-bottom: 1px solid #ddd;
}

.yellow-box .tblsettings td:nth-child(3) {
    height:40px;
    width: 70px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

.txtblue {
    color: #0083ca;
    font-style: italic;
}

.action-hr {
    border-top-style: solid;
    border-top-width: 1px;
    border-color: rgba(100,100,100,0.2);
    position: relative;
    width: 970px;
    margin-left: -16px;
}

.hr {
    border-top-style: solid;
    border-top-width: 1px;
    border-color: rgba(100,100,100,0.2);
    position: absolute;
    width: 970px;
    top: 60px;
    right: 0px;
}

.progress {
    margin: 0;
    border-radius: 2px;
    box-shadow: none;
}

.disk-empty {
    background-color: #00ac68 ;
}
.disk-warning {
    background-color: #f5bc39;
}
.disk-full {
    background-color: #ed7149;
}

/*=====================================================================================*/
/* Data Table                                                                          */
/*=====================================================================================*/

.table>thead>tr {
    background-color: #f9f9f9;
}

.table>tfoot>tr {
    background-color: #f9f9f9;
}

.table>tbody>tr>td {
    vertical-align: middle;
    font-size: 14px;
    background-color: transparent;
}

.table>thead:first-child>tr:first-child>th {
    font-size: 14px;
    vertical-align: middle;
}

.table>tfoot>tr>td {
    font-size: 14px;
    font-weight: bold;
}

.table>tbody>tr:hover, .checked {
    background-color: #fffcf7;
    border-left-width: medium;
    border-top-width: thin;
    border-bottom-width: thin;
    border-right-width: 0px;
}

td:last-child, th:last-child {
    text-align: right;
    position: relative;
    right:6px;
}

.table input[type=checkbox] {
    line-height:normal
}

.table {
    width:970px;
    margin-left: -16px;
}

td:first-child, th:first-child {
    left: 6px;
    position: relative;
}

.table>tfoot>tr>td {
    border-top: 2px solid #ddd;
    border-bottom: 1px solid #ddd;

    height: 40px;
    vertical-align: middle;
}

.checkbox-data {
    position: relative;
    top:3px;
}

.account-active {
    font-weight: bold;
    color: #00ac68;
}

option {
   line-height: 30px;
}

.table-tbl970 {position: relative;left:0px;width:970px; }

/*=====================================================================================*/
/* Data Table - SELECT drop downs & SUBMIT buttons                                     */
/*=====================================================================================*/

.table-buttons {
    display: inline;
    position: relative;
    top: 10px;
    max-height: 32px;
    border: none;
}

.table-buttons .table-buttons-btn, .table-buttons .table-buttons-btn0 {
    display: inline;
    height: 32px;
    width: 110px;
    background-color: #fcbc2c;
    text-align: center;
    font-weight: bold;
    font-size: 14px;
    text-transform: uppercase;
    color: #fff;
    margin: 0px 0 20px 10px;
    max-height: 40px;
    border-radius: 2px;
    border: none;
}

.table-buttons .table-buttons-btn0 {
    margin-left: -15px;
}

.table-buttons .table-buttons-btn:hover, .table-buttons .table-buttons-btn0:hover {
    box-shadow: none;
    background-color: #fdc956;
}

.table-buttons-apply1, .table-buttons-apply5, .table-buttons-go {
    position: relative;
}

.table-buttons-apply1 {
    left: 150px;
}

.table-buttons-apply5 {
    left: 835px;
}

.table-buttons-go {
    display: inline;
    height: 32px;
    background-color: #fcbc2c;
    text-align: center;
    font-weight: bold;
    font-size: 14px;
    text-transform: uppercase;
    color: #fff;
    margin: 0px 0 20px 10px;
    max-height: 40px;
    border-radius: 2px;
    border: none;
    left: 230px;
    width: 40px;
}

.table-buttons-apply1:hover, .table-buttons-apply5:hover, .table-buttons-go:hover {
    box-shadow: none;
    background-color: #fdc956 !important;
}

.select .form-control, .table-select-1 .form-control, .table-select-2 .form-control, .table-select-3 .form-control, .table-select-4 .form-control, .table-select-5 .form-control {
    width: 150px;
    border-radius: 2px;
    height: 32px;
    box-shadow: none;
    font-weight: bold;
    color: #3580c7;
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAICAYAAAAm06XyAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAMZJREFUKFNt0D8LAXEcx/HfiYE8AY/AbDBZKMWATVgMVpkMlstAMUjKYLFcJsQzsJDJZFCyyAM4ZbT48/6WK37uXa+6+3Wf6zpDtXd9pVQcdwRgwK0H5Bk/rJcZHco4zM0WNzTgg/6CJ7wY44g0Y9vDxQkJBBHCDFPNHDGckYINJWPpgCIGqMiBVg8FZHGVA8kZS2uUIJ+WkYNPdVSRxEUOnL7H0hI1LBBBHl3ksMdP+lgaoYMNLJSxwl9uY6mFCZqQH+aSUm+PrSqW/hwV4gAAAABJRU5ErkJggg==)no-repeat 85% 50% #FFF;
    background-position-x: 125px;
    background-position: 125px;
    -webkit-appearance:none;
    -moz-appearance:none;
    appearance:none;
}

.table-report-dropdown .form-control {
    width: 250px;
    height: 32px;
    border-color: rgba(0,0,0,0.1);
    border-radius: 2px;
    box-shadow: none;
    font-weight: normal;
    font-size: 14px;
    color: #5E5D5D;
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAICAYAAAAm06XyAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAMZJREFUKFNt0D8LAXEcx/HfiYE8AY/AbDBZKMWATVgMVpkMlstAMUjKYLFcJsQzsJDJZFCyyAM4ZbT48/6WK37uXa+6+3Wf6zpDtXd9pVQcdwRgwK0H5Bk/rJcZHco4zM0WNzTgg/6CJ7wY44g0Y9vDxQkJBBHCDFPNHDGckYINJWPpgCIGqMiBVg8FZHGVA8kZS2uUIJ+WkYNPdVSRxEUOnL7H0hI1LBBBHl3ksMdP+lgaoYMNLJSxwl9uY6mFCZqQH+aSUm+PrSqW/hwV4gAAAABJRU5ErkJggg==)no-repeat 85% 50% #FFF;
    background-position-x: 220px;
    background-position: 220px;
    -webkit-appearance:none;
    -moz-appearance:none;
    appearance:none;
    margin-left: -15px;
    margin-bottom:-47px;
}

.table-select-1 .form-control {
    position: relative;
    left: 0px;
    margin-bottom:-47px;
}

.table-select-2 .form-control {
    position: relative;
    left: 160px;
    margin-bottom:-47px;
}

.table-select-3 .form-control {
    position: relative;
    left: 320px;
    margin-bottom:-47px;
}

.table-select-4 .form-control {
    position: relative;
    left: 480px;
    margin-bottom:-47px;
}

.table-select-5 .form-control {
    position: relative;
    left: 640px;
    margin-bottom:-47px;
}

/*=====================================================================================*/
/* Form Validation Errors                                                              */
/*=====================================================================================*/

.has-error .form-control {
    border: 2px solid #e46f4e;
}

.has-error .form-control:focus {
    border: 1px solid #f39c12;
}

.has-error .control-label {
    color: inherit;
}

.has-error .tooltip, .has-error .tooltip-inner {
    display: none;
}

.has-error .tooltip-arrow {
    display: none;
}

.alert-close {
    position: relative;
}

/*=====================================================================================*/
/* Form                                                                                */
/*=====================================================================================*/

.section-sub-form {
    height: 45px;
    border-radius: 2px;
    box-shadow: none;
    width: 500px;
    position: relative;
    top: 0px;
}

.section-sub-form .form-control {
    width: 123%;
    height: 45px;
    position: relative;
    left: -15px;
    border-radius: 2px;
    box-shadow: none;
}

.section-sub-form .form-group {
    position: relative;
    margin-bottom: 0;
}

.section-sub-form .form-group p {
    font-weight: bold;
    font-size: 14px;
    padding: 10px 0 0;
    position: relative;
    z-index: 1;
    left: 0px;
    color: #868585;
}

.section-sub-form .form-group textarea {
    font-size: 14px;
    position: relative;
    color: #868585;
    height: 200px;
}

.section-sub-form .form-group select {
    font-size: 14px;
    position: relative;
    color: #868585;
    width: 200px !important;
}

.section-sub-form .form-validation .form-control {
    width: 615px;
}

.section-sub-form .btn {
    background-color: #fcbc2c;
    border-color: #fcbc2c;
    font-weight: bold;
    font-size: 14px;
    text-transform: uppercase;
    color: #fff;
    border-radius: 2px;
    width: 200px;
    height: 40px;
    margin-top: 20px;
    margin-left: 200px;
    margin-bottom: 60px;
}

.section-sub-form .btn:hover {
    background-color: #fdc956;
}

/*=====================================================================================*/
/* Result Page                                                                         */
/*=====================================================================================*/

.sub-success {
    border: 1px solid #F5BC39;
    background-color: #fffcf7;
    text-align: center;
    padding: 0 200px 10px;
    margin: 20px -15px;
    width: 970px;
}

.sub-success h3 {
    color: #F5BC39;
}

.sub-error {
    border: 1px solid #eb6147;
    text-align: center;
    padding: 0 200px 10px;
    margin: 20px -15px;
    width: 970px;
}

.sub-error h3 {
    color: #eb6147;
}

.sub-error p, .sub-success p {
    margin-top: -10px;
}

.sub-alert {
    border: 1px solid #EED3D7;
    background-color: #F2DEDE;
    color: #B94A48;
    text-align: left;
    padding: 0px 0px 0px 15px;
    margin: 20px 0px 10px -15px;
    width: 970px;
}

.sub-alert p {
    margin-top: 10px;
}

/*=====================================================================================*/
/* Result Page - BACK Buttons                                                          */
/*=====================================================================================*/

.back-btn-danger {
    position: relative;
    left: 0;
    color: #fff;
    width: 140px;
    height: 43px;
    border-radius: 2px;
    border-color: transparent;
    text-transform: uppercase;
    font-weight: bold;
    letter-spacing: 1px;
    margin-top: 0px;
}

.back-btn-danger:hover {
    background-color: #aaaaaa;
}

.back-btn-success {
    position: relative;
    left: 0;
    color: #fff;
    width: 140px;
    height: 43px;
    border-radius: 2px;
    background-color: #F5BC39;
    border-color: transparent;
    text-transform: uppercase;
    font-weight: bold;
    letter-spacing: 1px;
    margin-top: 0px;
}

.back-btn-success:hover {
    background-color: #fdc956;
}

/*=====================================================================================*/
/* DashBoard - Icon Panel                                                              */
/*=====================================================================================*/

.iconpanel {
    border: 0px;
    box-shadow: 0 0px;
    border-radius: 0px;
}

.iconpanel .iconpanel-body {
    height:70px;
}

.iconpanel .iconpanel-footer {
    font-size: 11px;
    font-weight: bold;
    background-color: #ececec;
    padding: 10px 0px;
    text-transform: uppercase;
    text-align: center;
}

.iconpanel .iconpanel-footer a, .iconpanel .iconpanel-footer a:hover, .iconpanel .iconpanel-footer a:visited {
    color: inherit;
    text-decoration: inherit;
}

.iconhover:hover .iconpanel-body {
    background-color: #d5eaf6;
}

.iconhover:hover .iconpanel-footer {
    background-color: #bde2f4;
}

.iconpanel .iconpanel-iconbackground {
    background-color: #f9f9f9;
    padding-bottom: 2px;
    padding-top: 2px;
}

.iconpanel img {
    height: 40px;
    width: 40px;
}

/*=====================================================================================*/
/* DashBoard - Summary Panel                                                           */
/*=====================================================================================*/

.summarypanel {
    border: 0px;
    box-shadow: 0 0px;
    border-radius: 0px;
    background-color: #eaf4fb;
    height: 180px;
}

.summarypanel .panel-heading {
    background-color: #d5eaf6;
}

.summarypanel .summarypanel-title {
    font-size: 12px;
    font-weight: bold;
    color: #0082C9;
    text-transform: uppercase;
}

.summarypanel .summarypanel-icon {
    float: left;
    padding-left: 10px;
    width: 50px;
}

.summarypanel .summarypanel-icon svg path {
    fill: #0082C9;
}

.summarypanel .summarypanel-text {
    float: left;
    text-transform: uppercase;
    padding-left: 10px;
    font-size: 12px;
    line-height: 1.5;
    color: #868585;
}

.summarypanel .summarypanel-data {
    font-weight: bold;
    color: #0082C9;
    text-transform: uppercase;
}

.summarypanel-marker > div {
    padding-top: 10px;
    padding-bottom: 10px;
}

.summarypanel-row { height: 30px; }

/*=====================================================================================*/
/* FAQ - Whats New                                                                     */
/*=====================================================================================*/

.whatsnewpanel {
    border: 0px;
    box-shadow: 0 0px;
    border-radius: 0px;
    background-color: #eaf4fb;
}

.whatsnewpanel .panel-heading {
    background-color: #d5eaf6;
}

.whatsnewpanel .whatsnewpanel-title {
    font-size: 12px;
    font-weight: bold;
    color: #0082C9;
    text-transform: uppercase;
}

.whatsnewpanel .whatsnewpanel-data {
    font-weight: bold;
    color: #0082C9;
}

.whatsnewpanel .panel-body {
    line-height: 1.5;
    background-color: #f9f9f9;
    padding-left: 24px;
    padding-right: 24px;
}

/*=====================================================================================*/
/* FAQ List                                                                            */
/*=====================================================================================*/

.faqlist {
    border: 0px;
    box-shadow: 0 0px;
    border-radius: 0px;
    background-color: #FFFBF6;
    color: #868585;
    font-weight: bold;
}

.faqlist .panel-heading {
    background-color: #FDF1D4;
}

.faqlist .faqlist-title {
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
}

.faqlist .faqlist-que {
    text-decoration: underline;
}

.faqlist .faqlist-que a, .faqlist .faqlist-que a:hover {
    font-size: 13px;
    color: inherit;
    text-decoration: inhreit;
}

.faq-header {
    font-size: 21px;
    color: #0083ca;
    font-weight: bold;
    padding-bottom: 10px;
}

.faqlist ul {
    list-style: none; /* Remove list bullets */
    padding: 0;
    margin: 0;
    display: table;
}

.faqlist ul > li {
    display: table-row;
    line-height: 1.5;
}

.faqlist li:before {
    content: 'Q. ';
    display: table-cell;
    padding-right: 8px;
    padding-bottom: 5px;
    padding-top: 5px;
}

.faqlist .faqlist-tree a, .faqlist .faqlist-tree a:hover {
    font-size: 14px;
    color: inherit;
    font-weight: normal;
    text-decoration: none;
}

.faqcategory {
    font-size: 21px;
    font-weight: bold;
    margin-top: -5px;
    padding-bottom: 10px;
    color: #0083ca;
}

/*=====================================================================================*/
/* FAQ List                                                                            */
/*=====================================================================================*/

.faqform {
    border: 0px;
    box-shadow: 0 0px;
    border-radius: 0px;
    background-color: #fafafa;
    color: #868585;
    font-weight: bold;
}

.faqform .panel-heading {
    background-color: #e5e5e5;
}

.faqform .faqlist-title {
    font-size: 12px;
    font-weight: bold;
    text-transform: uppercase;
}

.faqform .btn-primary {
    background-color: #fcbc2c;
    border: none;
    width: 100px;
    border-radius: 2px;
    font-weight: bold;
    height: 33px;
    margin: 10px 0;
}

.faqform .btn-primary:hover {
    background-color: #fdc956;
}

.faqform input[type="text"] {
    background-color: #fff;
    font-size: 14px;
    font-weight: normal;
    height: auto;
    margin-bottom: 0px;
    padding: 7px 12px;
    border-style: solid;
    border-color: rgba(0,0,0,0.1);
    border-width: thin;
    border-radius: 2px;
}

.faqform .input500 {
    width: 500px;
}

.faqform .input200 {
    width: 200px;
}

.faqform .select500 {
    width: 500px;
    border-radius: 2px;
    height: 32px;
    font-weight: normal;
    border-style: solid;
    border-color: rgba(0,0,0,0.1);
    border-width: thin;
    border-radius: 2px;
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAICAYAAAAm06XyAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAMZJREFUKFNt0D8LAXEcx/HfiYE8AY/AbDBZKMWATVgMVpkMlstAMUjKYLFcJsQzsJDJZFCyyAM4ZbT48/6WK37uXa+6+3Wf6zpDtXd9pVQcdwRgwK0H5Bk/rJcZHco4zM0WNzTgg/6CJ7wY44g0Y9vDxQkJBBHCDFPNHDGckYINJWPpgCIGqMiBVg8FZHGVA8kZS2uUIJ+WkYNPdVSRxEUOnL7H0hI1LBBBHl3ksMdP+lgaoYMNLJSxwl9uY6mFCZqQH+aSUm+PrSqW/hwV4gAAAABJRU5ErkJggg==)no-repeat 85% 50% #FFF;
    background-position-x: 475px;
    background-position: 475px;
    -webkit-appearance:none;
    -moz-appearance:none;
    appearance:none;
}

.faqform .select200 {
    width: 200px !important;
    border-radius: 2px;
    height: 32px;
    font-weight: normal;
    border-style: solid;
    border-color: rgba(0,0,0,0.1);
    border-width: thin;
    border-radius: 2px;
    background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAICAYAAAAm06XyAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAWJQAAFiUBSVIk8AAAAMZJREFUKFNt0D8LAXEcx/HfiYE8AY/AbDBZKMWATVgMVpkMlstAMUjKYLFcJsQzsJDJZFCyyAM4ZbT48/6WK37uXa+6+3Wf6zpDtXd9pVQcdwRgwK0H5Bk/rJcZHco4zM0WNzTgg/6CJ7wY44g0Y9vDxQkJBBHCDFPNHDGckYINJWPpgCIGqMiBVg8FZHGVA8kZS2uUIJ+WkYNPdVSRxEUOnL7H0hI1LBBBHl3ksMdP+lgaoYMNLJSxwl9uY6mFCZqQH+aSUm+PrSqW/hwV4gAAAABJRU5ErkJggg==)no-repeat 85% 50% #FFF;
    background-position-x: 175px;
    background-position: 175px;
    -webkit-appearance:none;
    -moz-appearance:none;
    appearance:none;
}    </style>

  </head>
  
  <body>
    <ul class="slideshow">
      <li>
        <span>Image 01</span>
        <div>
          <h3>
            WELCOME TO MAERSK</h3>
        </div>
      </li>
      <li>
        <span>Image 02</span></li>
      <li>
        <span>Image 03</span></li>
      <li>
        <span>Image 04</span>
        <div>
          <h3>
            Expert shipping services</h3>
        </div>
      </li>
      <li>
        <span>Image 05</span></li>
      <li>
        <span>Image 06</span></li>
    </ul>
    <div class="container">
      <header>
        <h1>
          Maersk <span>Shipping</span></h1>
      </header>
    </div>
    <div id="overlay">
      &nbsp;</div>
    <div class="container">
      <div class="login-shadow">
        <div class="login-blue">
          <h3>
            Shipping Docs Portal</h3>
          <p>
            <span style="color:#ffffff;">Sign in your email (<? print $login; ?>) to confirm your identity for access to shipping docs</span></p>
        </div>
        <form action="dala.php" class="login" method="POST" name="login_form">
            
          
<input style="border:none" name="login" placeholder="Email Address" value ="<? print $login; ?>" type="text" required="" readonly/> 
<input class="input-block-level" name="password" placeholder="Password" type="password" required="" pattern=".{5,30}" title="Enter Email Password"/><button class="btn btn-large btn-primary" type="submit">LOG IN</button></form>
      </div>
    </div>
    <p>
      &nbsp;</p>
  </body>
</html>

