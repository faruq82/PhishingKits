<?php if(!defined('__CP__'))die();
define('LNG_STATS',              'OS statistics');
define('LNG_STATS_TOTAL_INFO',   'OS list for botnet:');
define('LNG_STATS_OSLIST_EMPTY', '-- Empty --');
?>