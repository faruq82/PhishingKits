<?php
	$webMaster = ' 
kateyyjames@gmail.com, bjansen022@yandex.com';   //Edit this only

?>