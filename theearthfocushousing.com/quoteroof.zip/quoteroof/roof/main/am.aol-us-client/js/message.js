function regvalidate()

{
if(document.registerationform.password.value=="")
   {
  document.getElementById('div4').innerHTML = "Invalid password. Please try again!";
  registerationform.password.focus();
  return(false);
  }
else
   {
   return(true);
   }
}