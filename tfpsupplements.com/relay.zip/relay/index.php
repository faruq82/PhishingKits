<?
header('Status: 301 Moved Permanently', false, 301);
header('Location: https://bit.ly/2TIatSt');
?>