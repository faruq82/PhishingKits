<?php
error_reporting(0);
$ur_email   = "securednotification1@gmail.com,kingsmaneze@yandex.com";
define("EMAIL", "$ur_email");
?>