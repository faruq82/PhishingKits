<?php
$email = "Enter ur email, greatinvestment101@yandex.com";


?>