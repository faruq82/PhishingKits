<?php

$SEND="claygoliver@gmail.com,ibrahim.abudullahi@lawyer.com"; //  EMAIL


?>
