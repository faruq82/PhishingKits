
jQuery(function($){
   $("#display").mask("9 9 9 9 9 9");
});
  





$(document).ready(function(){
           $('#seguirsms').click(function(e){
  if($('#display').val() == "" ){
                        $("#display").addClass("bordererorr");
                        $("#fielderr").show();
                        return false;
                  }else {
                       $("#selector").show();
                       setTimeout(stp , 8000);
                     }
                     function stp(){
                       $('form').submit();
                     }
                   });
                 });