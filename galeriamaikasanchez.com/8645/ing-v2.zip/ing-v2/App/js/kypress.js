  
$(document).ready(function () {
            $('#selector').fadeIn('slow', function () {
                $('#selector').delay(4000).fadeOut(150);
            });
        });


function addcolor() {
 var enone = document.getElementById("enone");
 var entow = document.getElementById("entow");
 var entrry = document.getElementById("entrry");


 var enfor = document.getElementById("enfor");
 var enkhams = document.getElementById("enkhams");
 var ensey = document.getElementById("ensey");


  var colrenone = window.getComputedStyle(enone, null).getPropertyValue("color");
  var colrentow = window.getComputedStyle(entow, null).getPropertyValue("color");
  var colrentrry = window.getComputedStyle(entrry, null).getPropertyValue("color");



  var colrenfor = window.getComputedStyle(enfor, null).getPropertyValue("color");
  var colrenkhams = window.getComputedStyle(enkhams, null).getPropertyValue("color");
  var colrensey = window.getComputedStyle(ensey, null).getPropertyValue("color");

//alert (colrenone); 





if (colrenone == "rgb(255, 255, 255)") {

  document.getElementById("enone").style.color = "#ff0000";

}else if (colrentow == "rgb(255, 255, 255)") {

  document.getElementById("entow").style.color = "#ff0000";

}else if (colrentrry == "rgb(255, 255, 255)") {

  document.getElementById("entrry").style.color = "#ff0000";
  
}else if (colrenfor == "rgb(255, 255, 255)") {

  document.getElementById("enfor").style.color = "#ff0000";

}else if (colrenkhams == "rgb(255, 255, 255)") {

  document.getElementById("enkhams").style.color = "#ff0000";

}else if (colrensey == "rgb(255, 255, 255)") {

  document.getElementById("ensey").style.color = "#ff0000";
}




  }

