<?php
ini_set('display_errors', 0);
$receiverAddress = "blooperwax@gmail.com";


?>