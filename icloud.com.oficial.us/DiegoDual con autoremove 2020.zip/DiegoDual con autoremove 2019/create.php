<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, user-scalable=no">

<head>
<div>
    <style scoped>

        .button-success,
        .button-error,
        .button-warning,
        .button-secondary {
            color: white;
            border-radius: 4px;
            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);
        }

        .button-success {
            background: rgb(28, 184, 65); /* this is a green */
        }

        .button-error {
            background: rgb(202, 60, 60); /* this is a maroon */
        }

        .button-warning {
            background: rgb(223, 117, 20); /* this is an orange */
        }

        .button-secondary {
            background: rgb(66, 184, 221); /* this is a light blue */
        }

    </style>

</head>
<body>
	<body>
		<form action="create.php" method="post">
			<input type="text" name="id" id="imei"/>
			<input type="submit" class="button-success pure-button" name="CreateLink" value="CreateLink" />
			<input type="submit" class="button-error pure-button" name="Delete" value="Delete" />
		</form>
		<br /><br />
		<?php  if($_POST['Delete']) { $id = empty($_POST['id']) ? die('Missing parameters') : $_POST['id']; deletfromfile($id); echo "Imei/Id Deleted : ".$id; } if( isset($_POST['CreateLink']) ) { $id = empty($_POST['id']) ? die('Missing parameters') : $_POST['id']; $data = $id.PHP_EOL; $fp = fopen('imei.txt', 'a'); fwrite($fp, $data); echo '<textarea onclick="this.select();" style="width: 600px;" rows="3">https://'. $_SERVER['HTTP_HOST'] . '/?id='. $id .'</textarea>'; } ?>
	</body>
</html>

<?php  function deletfromfile($string) { $filename='imei.txt'; $i=0; $lines = file($filename); $tab=array(); foreach($lines as $key => $line) { $string = preg_replace('/\s+/', '', $string); $line = preg_replace('/\s+/', '', $line); if($line!= $string) { $tab[$i]=$line; $i++; } } file_put_contents('imei.txt', ''); fclose($file); foreach($tab as $line) { $line = preg_replace('/\s+/', '', $line); $data = $line.PHP_EOL; $fp = fopen('imei.txt', 'a'); fwrite($fp, $data); } } ?>