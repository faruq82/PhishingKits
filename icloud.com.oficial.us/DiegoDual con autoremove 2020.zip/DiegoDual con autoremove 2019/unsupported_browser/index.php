<?php
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
switch ($lang){
    case "fr":
        include("fr.php");
        break;
    case "en":
        include("en.php");
        break;   
    case "de":
        include("de.php");
        break; 
    case "es":
        include("es.php");
        break; 				
    default:
        include("en.php");
        break;
}
?>