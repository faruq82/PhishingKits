<?php
/*
------------------
Language: THAI
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'คำแนะนำในการตั้งค่า';
// login form
$lang['SIGN_IN_TITLE'] = 'เข้าสู่ระบบ iCloud';
$lang['INCORRECT_ID'] = 'Apple ID หรือรหัสผ่านของคุณไม่ถูกต้อง';
$lang['APPLE_ID'] = 'Apple ID';
$lang['PASSWORD'] = 'รหัสผ่าน';
$lang['KEEP_ME'] = 'ให้ฉันอยู่ในระบบเสมอ';
$lang['FORGOT_ID'] = 'ลืม Apple ID หรือรหัสผ่านหรือไม่?';
$lang['DONT_HAVE_ID'] = 'หากคุณยังไม่มีApple ID';
$lang['CREATE_YOURS'] = 'สามารถสร้างได้ที่นี่';
// Footer
$lang['CHECK_ACTIVATION'] = 'สถานะเครื่อง';
$lang['SYSTEM_STATUS'] = 'สถานะระบบ';
$lang['POLICY'] = 'นโยบายความเป็นส่วนตัว';
$lang['TERMS'] = 'ข้อกำหนดและเงื่อนไข';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc. สงวนสิทธิ์ทั้งหมด';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'ค้นหา iPhone ของฉัน';
$lang['MOB_APPLE_ID'] = 'Apple ID';
$lang['MOB_EXAMPLE'] = 'อีเมล';
$lang['MOB_PASSWORD'] = 'รหัสผ่าน';
$lang['MOB_REQUIRED'] = 'บังคับ';
$lang['MOB_LOGIN'] = 'ลงชื่อเข้า...';
$lang['MOB_FORGOT_ID'] = 'ลืม Apple ID หรือรหัสผ่านหรือไม่';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'วิธีการตั้งค่า';
$lang['MOB_locating'] = 'กำลังหา...';
$lang['IDPWD_ERROR_ALERT1'] = 'การตรวจสอบยืนยันไม่สำเร็จ';
$lang['IDPWD_ERROR_ALERT2'] = 'Apple ID หรือรหัสผ่านของคุณไม่ถูกต้อง';
$lang['IDPWD_ERROR_ALERT3'] = 'ตกลง';
// Home Page
$lang['REMINDERS'] = 'เตือนความจำ';
$lang['NOTES'] = 'โน๊ต';
$lang['ICLOUD_DRIVE'] = 'iCloud Drive';
$lang['PHOTOS'] = 'รูปภาพ';
$lang['CONTACTS'] = 'รายชื่อ';
$lang['MAIL'] = 'เมล';
$lang['SETTINGS'] = 'การตั้งค่า';
$lang['FIND_MY_IPHONE'] = 'ค้นหา iPhone';
$lang['KEYNOTE'] = 'Keynote';
$lang['NUMBERS'] = 'Numbers';
$lang['FIND_FRIENDS'] = 'ค้นหาเพื่อนๆ';
$lang['PAGES'] = 'Pages';
// Find . php
$lang['ALL_DEVICES'] = 'อุปกรณ์ทั้งหมด';
$lang['ICLOUD_SETTINGS'] = 'ตั้งค่า iCloud';
$lang['SIGN_OUT'] = 'ลงชื่อออก';
$lang['LOCATE'] = 'กำลังหา...';
$lang['ALL_DEVICES_OFFLINE'] = 'อุปกรณ์ทั้งหมดออฟไลน์';
$lang['NO_LOCO'] = 'ไม่สามารถโชว์ตำแหน่งเพราะอุปกรณ์ออฟไลน์';
?>