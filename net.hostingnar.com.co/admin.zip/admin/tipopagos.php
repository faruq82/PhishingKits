<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "inicio.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>FORMAS DE PAGO DISPONBLE EN BOLIARES</title>
<style type="text/css">
<!--

table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo2 {font-size: 18px}
.Estilo3 {
	font-size: 14px;
	font-weight: bold;
}

-->
</style>
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<?php

	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	if(mysql_num_rows($datos22)==0)
	{
		echo "NO SE ENCUENTRA REGISTRADO EN NINGUNA ESCUELA";
		
	
	}else{
	for($i=0;$i<mysql_num_rows($datos22);$i++)
	{
?>
<table width="780" border="0" align="center" cellpadding="0" cellspacing="2" class="normal">
  <tr>
    <td colspan="2">
		<?php
	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	$escuela= mysql_result($datos22,0,"escuela");
	if (mysql_result($datos22,0,"status") == 'Pagado')
	{
		echo " NO TIENE NIGUNA ESCUELA PENDIENTE DE PAGO";
	}else{
	$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");


	echo " <br><strong>Nombre de la Escuela:</strong> ".mysql_result($escuelas,0,"escuela");
	//echo " <br><strong>Precio en USD:</strong> ".mysql_result($escuelas,0,"precio_usd");
	//echo " <br><strong>Precio en USD:</strong> ".mysql_result($escuelas,0,"precio_usd");
	echo " <br>";
	?>
	</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td width="399"><div align="center"><strong><a href="pagosext.php" class="Estilo2">PAGAR EN DOLARES </a></strong></div></td>
  <td width="373"><div align="center"><strong><a href="pagosven.php" class="Estilo2">PAGAR EN BOLIVARES</a> </strong></div></td>
  </tr>
  <tr>
    <td><div align="center">
      
          <?php
	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	$escuela= mysql_result($datos22,0,"escuela");
	$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");


	//echo " <br><strong>Nombre de la Escuela:</strong> ".mysql_result($escuelas,0,"escuela");
	echo " <strong>Precio en USD: </strong> ".mysql_result($escuelas,0,"precio_usd");
	//echo " <br><strong>Precio en USD:</strong> ".mysql_result($escuelas,0,"precio_usd");
	echo " <br>";
	?></div>
        </td>
  <td><div align="center">
    <?php
	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	$escuela= mysql_result($datos22,0,"escuela");
	$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");


	//echo " <br><strong>Nombre de la Escuela:</strong> ".mysql_result($escuelas,0,"escuela");
	echo " <strong>Precio en Bs.F: </strong> ".mysql_result($escuelas,0,"precio_bs");
	
	
	//echo " <br><strong>Precio en USD:</strong> ".mysql_result($escuelas,0,"precio_usd");
	echo " <br>";
		?>
  </div></td>
  </tr>
  <tr>
    <td colspan="2" ><br><br><div align="center"> <span class="Estilo3">Si su Forma de pago la realiza a través de transferencia o depósito Bancario,<br> 
      debe enviar la imagen del comprobante al email: pagos@ministerioredil.org</span><br>
    </div></td>
  </tr>
</table>
							<?php
						
							echo "</td>
  							</tr></table>";
						
						}

?>

<br><br><br><br><br>
<?php 
	}
}

?>


<?php     
	piecera($PRIVILEGIO);
?>
</body>
</html>
