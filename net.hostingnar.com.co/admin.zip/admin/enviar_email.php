<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Enviar e-mail</title>
<link href="estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div style="margin:10px">


<?
$asunto = $_REQUEST["asunto"];
$nombre = $_REQUEST["nombre"];
$destinatario = $_REQUEST["correo"];
$mensaje = $_REQUEST["mensaje"];
$cuerpo="
		<!DOCTYPE html>
		<html>
			<head>
				<style type=\"text/css\">
					body{font-size: 12px; font-family: \"Helvetica Neue\", Arial, Helvetica, sans-serif; color: #222; }
					.table{border: 1px solid #56647d; width:580px; padding:20px; }
					.capa{ width:100%;}
				</style>
			
			</head>
			<body>
				<div class=\"capa\">
					<table class=\"table\" align=\"center\">
					<tr>
						<td align=\"center\"><img src=\"http://centroeducativocecip.com/css/images/logo22.png\" border=\"0\"/>
							<br><b>CECIP</b></td>	
					</tr>
					<tr>
						<td align=\"left\"><br>Alumno:&nbsp;".$nombre."</td>	
					</tr>
					<tr>
						<td align=\"left\" valign=\"middle\" height=\"100px\">
						".$mensaje."
						</td>	
					</tr>	
					<tr>
						<td align=\"center\"></td>	
					</tr>	
					</table>
				</div>
			</body>
		</html>
		";
		

$copia = "<p>Correo enviado a: ".$destinatario."</p><p>Asunto: ".$asunto." </p><p> Mensaje enviado: ".$mensaje."</p>";
$cabecera1 = "From: contacto <contacto@ministerioredil.org>\r\nContent-Type: text/html; charset=iso-8859-1;MIME-Version: 1.0\r\n";
$cabecera2 = "From: contacto@ministerioredil.org\r\nContent-Type: text/html; charset=iso-8859-1;MIME-Version: 1.0\r\n";
//mail($destinatario, $asunto, $cuerpo, $cabecera1) or die ("Su mensaje no se envio.");
//Esto envia una copia
//mail("contacto@ministerioredil.org", "Copia de e-mail enviado a ".$destinatario."", $copia, $cabecera2) or die ("Su mensaje no se envio.");
//echo "<div class='order'>Se envio tu correo correctamente</div>";
	require("PHPMailer/class.phpmailer.php");	
	$mail = new PHPMailer();
	$mail->Mailer = "smtp";
	$mail->Host = "mail.centroeducativocecip.com";
	$mail->Port="25";
	$mail->SMTPAuth = true;
	$mail->Username = "cecip_online@centroeducativocecip.com";
	$mail->Password = "LXM71HE3i";
	$mail->CharSet = "UTF-8";
	$mail->From = "cecip_online@centroeducativocecip.com";
	$mail->FromName = "Cecip";
	$mail->IsHTML(true);                                
	$mail->Subject = $asunto;
	$mail->Body    = $cuerpo;
	$mail->AddAddress($destinatario);
	$mail->Send();
	
echo $cuerpo;

?>
</div>
</body>
</html>