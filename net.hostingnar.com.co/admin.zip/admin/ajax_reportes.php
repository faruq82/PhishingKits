<?php
			 
			include("ajaxordenconfig.php");
			$ACCION = $_POST['ACCION'];
			
			
			if($ACCION==0){
				
				 echo "<table border='0' align='center' cellpadding='2' cellspacing='2' width='780'>
				 <tr><td>Fecha</td><td><input type=text id='dateArrival' name =TXTFECHA   onFocus=popUpCalendar(document.getElementById('dateArrival'),document.getElementById('dateArrival'),'dd-mm-yyyy') size='10' maxlength=0></td><td><input type=button value='Generar Reporte' onClick=generar_diario()></td><td><b>Ingrese la fecha y presione el boton para generar el reporte</b></td></tr></table>";
			
			}
			
				if($ACCION==1){
				
				 echo "<table border='0' align='center' cellpadding='2' cellspacing='2' width='780'>
				 <tr><td><input type=button value='Generar Reporte' onClick=generar_empleados2()></td></tr></table>";
				 
				
			
			}

                        if($ACCION==2){

				 echo "<table border='0' align='center' cellpadding='2' cellspacing='2' width='780'>
				 <tr><td>";
                                    COMBO_MESES();

                                 echo"</td><td>
                                     <select id=ano name=ano>
                                     <option value=2011>2011</option>
                                     <option value=2012>2012</option>
                                     </select>
                                     </td>

                                    <td><input type=button value='Generar Reporte' onClick=generar_mensual()>
                                 </td><td><b>Seleccione  mes y a&oacute;o y presione el boton para generar el reporte</b></td></tr></table>";



			}

				
?>