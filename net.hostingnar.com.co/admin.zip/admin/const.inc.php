<?php

//Database settings

$DBName = "tupunto_tesis";
$DBUser = "tupunto_admin";
$DBPassword = "admin32";
$DBHost = "localhost";
$adminemail = "";

//Front Language settings
$front_charset = "iso-8859-1";
$front_previouspage = "P�gina anterior";
$front_nextpage = "P�gina siguiente";
$front_submititle = "T�tulo";
$front_categories = "Categorias";
$front_indextitle = "Index";
$front_searchresult = "Resultados de la busqueda";
$front_searchsubmit = "Buscar";
$front_latestnews = "Ultimas noticias";
$front_more = "M�s";
$front_rateit = "Clasifiquelo";
$front_rating = "Grado";
$front_letmerateit = "D�jem� clasificarlo";
$front_ratebest = "Mejor";
$front_ratesubmit = "Clasificar!";
$front_adddate = "Datos de este noticia a�adidos";
$front_source = "Fuente de este art�culo";

$front_latestonhomerecord = 4;
$front_latestoncatarecord = 20;
$front_searchresultrecord = 20;
$front_catnewsonhomerecord = 5;
$front_catnewsoncatarecord = 5;

//Admin Language settings
$admin_charset = "iso-8859-1";
$admin_url = "URL";
$admin_ok = "OK";
$admin_back = "Atr�s";
$admin_add = "A�adir";
$admin_name = "Nombre";
$admin_del = "Borrar";
$admin_previouspage = "P�gina anterior";
$admin_nextpage = "P�gina siguiente";
$admin_news = "Noticias";
$admin_delconfirm = "Realmente quiere borrarla?";
$admin_yes = "Si";
$admin_no = "No";
$admin_edit = "Editar";
$admin_adminindex = "Admin Index";
$admin_next = "Siguiente";
$admin_reset = "Reset";
$admin_description = "Descripci�n";
$admin_adminsystem = "Sistema Admin";
$admin_admin = "Admin";
$admin_welcome = "Bienvenido al sistema admin";
$admin_existing = "Existente";
$admin_opreation = "Opreation";
$admin_save = "Salvar";
$admin_picture = "Imagen";
$admin_install = "Instalar";
$admin_databasename = "Nombre de la base de datos";
$admin_databaseuser = "Usuario de la base de datos";
$admin_databasepass = "Password de la base de datos";
$admin_databasehost = "Host de la base de datos";
$admin_adminemail = "Email del administrador";
$admin_databasesetting = "Database setting";
$admin_setadminpassword = "El�ge un usuario y password para el Admin";
$admin_username = "username";
$admin_password = "password";
$admin_loginfail = "Mal username o password";
$admin_login = "Conectar";
$admin_linkadded = "link a�adido";
$admin_constisnotwriteable = "const.inc.php no es writeable,por favor cambia el permiso";
$admin_catalogadmin = "Categor�a Admin";
$admin_newsadmin = "Noticias Admin";
$admin_parentcatalog = "Categor�a Parent";
$admin_catalogalreadyexist = "Categor�a ya existente";
$admin_catalog = "Categor�a";
$admin_isdisplay = "Es exhibido";
$admin_none = "ninguno";
$admin_title = "T�tulo";
$admin_content = "Contenido";
$admin_viewnumber = "Hits";
$admin_rating = "Rating";
$admin_ratenumber = "Rate number";
$admin_source = "Fuente";
$admin_sourceurl = "URL de Fuente";

$help_source = "Si su texto es de otra fuente.";

if (count($HTTP_POST_VARS)) {
while (list($key, $val) = each($HTTP_POST_VARS)) {
$$key = $val;
}
}

if (count($HTTP_GET_VARS)) {
while (list($key, $val) = each($HTTP_GET_VARS)) {
$$key = $val;
}
}

if (count($HTTP_COOKIE_VARS)) {
while (list($key, $val) = each($HTTP_COOKIE_VARS)) {
$$key = $val;
}
}

if (count($HTTP_SESSION_VARS)) {
while (list($key, $val) = each($HTTP_SESSION_VARS)) {
$$key = $val;
}
}

?>