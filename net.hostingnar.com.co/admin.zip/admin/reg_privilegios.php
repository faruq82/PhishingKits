<?php 
	
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	
?>
<html >
<head>
<title>Asignaci&oacute;n de Privilegios</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>
<script type="text/javascript">
	</script>

<script language="javascript">

	function objetoAjax(){
		var xmlhttp=false;
		try {
			xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
			   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (E) {
				xmlhttp = false;
	  		}
		}
	
		if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
			xmlhttp = new XMLHttpRequest();
		}
		return xmlhttp;
	}
	
function buscar(ACCION){

	if(ACCION==0)
	{
		document.getElementById('mensaje').innerHTML= "";
		var ID_TIPO_USUARIO = document.getElementById('CMBID_TIPO_USUARIO').value;
		
		if(ID_TIPO_USUARIO==0)
		{
			document.getElementById('privilegios').innerHTML= "";
			return;
		}
				
		divPrivilegios= document.getElementById('privilegios');
		mensaje("Cargando...")
		//tomamos el valor de la lista desplegable
				//instanciamos el objetoAjax
				ajax=objetoAjax();
				//usamos el medoto POST
				//archivo que realizara la operacion
			 //datoscliente.php
				ajax.open("POST", "ajax_asig_privilegios.php",true);
				ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			    ajax.send("ID_TIPO_USUARIO="+ID_TIPO_USUARIO+"&ACCION="+encodeURIComponent(ACCION)); 
			 
				ajax.onreadystatechange=function() {
					if (ajax.readyState==4) {
						//mostrar resultados en esta capa
						cerrar_mensaje();
						document.getElementById('divalerta').innerHTML = '';
						divPrivilegios.innerHTML = ajax.responseText;
						
					}
					

				}
				
	}

	if(ACCION==1)
	{
		campos = new Array();
		campos_eliminar = new Array();
		ID_USUARIO='<?php echo $ID_USUARIO;?>';
		var ID_TIPO_USUARIO = document.getElementById('CMBID_TIPO_USUARIO').value;
		if(ID_TIPO_USUARIO!=0)
		{
				var campos = new Array();
				maximo = document.getElementById('TXTLISTA').value;
				for(x=0;x<maximo;x++)
				{
					if(document.getElementById('campos_'+(x)+''))
					{
						if(document.getElementById('campos_'+(x)+'').checked == true)
						{	
							campos.push(document.getElementById('campos_'+(x)+'').value);
						}else{
							campos_eliminar.push(document.getElementById('campos_'+(x)+'').value);
						}	
					}
				}
				
				//instanciamos el objetoAjax
				ajax=objetoAjax();
				mensaje("Actualizando...")
				ajax.open("POST", "ajax_asig_privilegios.php",true);
				ajax.onreadystatechange=function() {
					if (ajax.readyState==4) {
						document.getElementById('divalerta').innerHTML = ajax.responseText;
						cerrar_mensaje();
						if(document.getElementById('AVISO'))
						{
							if(document.getElementById('AVISO').value =="error")
							{
								alert("Hubo un error durante la operaci\u00f3n");
								return false;
							}
							if(document.getElementById('AVISO').value=="")
							{
								alert("Proceso Completado con exito");	
							}
						}else{
							alert("Hubo un error durante la operaci\u00f3n");
							return false;

						}			
					
						//buscar(0);			
						
					}
				}
				ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
				//enviando los valores
			
		
				 ajax.send("campos="+campos+"&campos_eliminar="+campos_eliminar+"&ACCION="+encodeURIComponent(ACCION)+"&ID_TIPO_USUARIO="+encodeURIComponent(ID_TIPO_USUARIO)+"&ID_USUARIO="+ID_USUARIO+""); 
			 
			
			
			}
		}			
}

	function limpiar()
	{
		document.getElementById('CMBID_TIPO_USUARIO').selectedIndex=0;
		document.getElementById('privilegios').innerHTML= "";
		document.getElementById('mensaje').innerHTML= "";
		
	}
	
	function info(msj)
	{
		
		document.getElementById('mensaje').innerHTML= msj;
		
	}
</script>
	<body>

<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
	
  <BR>
	    
	    
   
       	<table align="center" border="0" width="780">
		
		<br>
        	 <tr><td width="100">Tipo de usuario</td><td>
            <?php
				$SQL = "select * from t_tipos_usuarios";
				$QUERY = mysql_query($SQL);
			
					echo "<select name=CMBID_TIPO_USUARIO id=CMBID_TIPO_USUARIO onChange=buscar('0')><option value=0>--</option>";
					for($i=0;$i<mysql_num_rows($QUERY);$i++)
					{
						echo "<option value=".mysql_result($QUERY,$i,"id_tipo_usuario").">".mysql_result($QUERY,$i,"tipo_usuario")."</option>";
					}
					echo "</select>";
					
				
            ?>
            </td></tr>
			
			</table>
		
    	    <table align="center" border="0" width="780">
        	<tr valign="middle"><td valign="middle" align="center" colspan="2"><div id="privilegios"></div></td></tr>
             </table>	
             <br>
             <table align="center" border="0" width="780">
            <tr><td align="left" ><input type="button" value="Limpiar" onClick="limpiar()"></td><td><input type="button" value="Guardar" name="GUARDAR" id="GUARDAR" onClick="buscar('1')" ></td><td align="left"  width="800"><div id="mensaje" ></div></td></tr>
       
            </table> 
            <div id="resultado"></div>   
        
 <br>
 <?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>