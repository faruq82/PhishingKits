<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
	<title>CENTRO EDUCATIVO CECIP</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,900,800,700,600,500,300,200,100' rel='stylesheet' type='text/css'>
	
	<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.carouFredSel-5.5.0-packed.js" type="text/javascript"></script>
<script src="js/functions.js" type="text/javascript"></script>
<style type="text/css">
#wrapper .shell .container .main .cols .col p {
	text-align: justify;
}
#wrapper .shell .container .main .entries .entry p {
	font-family: "Century Gothic";
	font-style: normal;
}
#wrapper .shell .container .main .cols .col table tr td table tr td ul li p {
	font-size: 16px;
}
strong {
	color: #F00;
}
#wrapper .shell .container .main .cols .col table tr td table tr td strong {
	color: #000;
	text-align: left;
}
strong {
	color: #F00;
}
strong {
	color: #000;
}
.Estilo4 {color: #333333;
	font-weight: bold;
	font-size: 11px;
}
.Estilo7 {color: #333333; font-size: 11px; }
.Estilo8 {font-size: 12px}
.Estilo8 {font-size: 11px}
.Estilo3 {COLOR: #ff6600
}
.Estilo541 {FONT-SIZE: 12px; COLOR: #003366; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif
}
.Estilo57 {FONT-SIZE: 11px; COLOR: #ffffff; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif
}
.Estilo61 {color: #FFFFFF}
.Estilo801 {font-size: 14px; font-family: "Century Gothic"; }
.Estilo81 {color: #FFFF00}
.Estilo611 {	color: #000
}
</style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<!-- wrapper -->
<div id="wrapper">
	<!-- shell -->
	<div class="shell">
		<!-- container -->
		<div class="container">
			<!-- header -->
			<header id="header">
				<h1 id="logo"><a href="#">Retina</a></h1>
				<!-- search -->
				<div class="search">
					<form action="" method="post">
						<input type="text" class="field" value="keywords here ..." title="keywords here ..." />
						<input type="submit" class="search-btn" value="" />
						<div class="cl">&nbsp;</div>
					</form>
			  </div>
				<!-- end of search -->
				<div class="cl">&nbsp;</div>
		  </header>
			<!-- end of header -->
			<!-- navigaation -->
			<nav id="navigation">
				<a href="home.html" title="principal" target="_self" class="nav-btn">HOME<span></span></a>
				<ul>
	        <li class="active"><a href="home.html" title="principal" target="_self">HOME</a></li>
					<li><a href="http://centroeducativocecip.com/index2.php" target="_self">LOGIN</a></li>
					<li><a href="estudiantes.html" title="ESTUDIANTES" target="_self">ESTUDIANTE</a></li>
					<li><a href="cecip.html" title="ESCUELAS" target="_self">ESCUELAS</a></li>
					<li><a href="contacto.php" title="CONTACTO" target="_self">CONTACTOS</a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
				</ul>
				<div class="cl">&nbsp;</div>
			</nav>
			<!-- end of navigation -->
			<!-- slider-holder -->
			<div class="slider-holder">
				
				<!-- slider -->
			  <div class="slider">
					<div class="socials">
						<a href="http://www.facebook.com/redil.ministerio" title="facebook" target="_blank" class="facebook-ico">facebook-ico</a>
						<a href="http://www.twitter.com/MinisterioRedil" title="twitter" target="_blank" class="twitter-ico">twitter-ico</a>
						<a href="http://www.youtube.com/user/reddeintercesores" title="youtube" target="_blank" class="skype-ico">skype-ico</a>
						<a href="http://instagram.com/ministerioredil" title="instagram" target="_blank" class="rss-ico">rss-ico</a>
					  <div class="cl">&nbsp;</div>
					</div>

				<div class="arrs">
						<a href="#" class="prev-arr"></a>
						<a href="#" class="next-arr"></a>
			    </div>

				  <ul>
					  <li id="img1"></li>
				  </ul>
			  </div>
				<!-- end of slider -->

				<!-- thumbs --><!-- end of thumbs -->
			</div>

			<!-- main -->
			<div class="main">

				<div class="featured">
				  <h4>Bienvenido al <strong>Centro Educativo y Cultural del Intercesor Profético.</strong> CECIP</h4>
					<a href="http://centroeducativocecip.com/reg_alumnos_online.php" target="_self" class="blue-btn">INSCRIBETE AQUI.</a>
				</div>

				<section class="cols">
				  <div class="col">
<table width="955" height="224" border="0">
		      <tr>
				        <td width="342" valign="top"><p><strong>La cobertura de CECIP esta creciendo por toda Latinoamerica y tu puedes ser parte de esta visión y trabajo. Si deseas formar parte del Centro Eduativo CECIP contactanos y llena el siguiente formulario para cualquier duda que tengas estamos para servirte.</strong></p>
			            <p><font face="Verdana, Arial, Helvetica, sans-serif">
			              <?
								if (!$HTTP_POST_VARS){
								?>
                        </font> </p>
			            <form action="contacto.php" method="post">
			              <table width="100%" border="0">
			                <tr bgcolor="" background="">
			                  <td colspan="2"><div align="left"><span class="blue_text Estilo9"><font face="Verdana, Arial, Helvetica, sans-serif"><br />
			                    </font></span> <font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif"><br />
			                      </font></div></td>
		                    </tr>
			                <tr background="images/day_camp.gif">
			                  <td colspan="2"><div align="center" class="Estilo4"><font face="Verdana, Arial, Helvetica, sans-serif">CONTACTO</font></div></td>
		                    </tr>
			                <tr>
			                  <td width="31%"><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">NOMBRE :</font></div></td>
			                  <td width="69%"><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
			                    <input name="nombre" type="text" id="nombre" size="40" />
			                    </font></span></td>
		                    </tr>
			                <tr>
			                  <td><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">TELEFONO:</font></div></td>
			                  <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
			                    <input name="telefono" type="text" id="telefono" size="40" />
			                    </font></span></td>
		                    </tr>
			                <tr>
			                  <td><div align="right"><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">EMAIL:</font></span></div></td>
			                  <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
			                    <input name="email" type="text" id="email" size="40" />
			                    </font></span></td>
		                    </tr>
			                <tr background="images/day_camp.gif">
			                  <td><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">ASUNTO :</font></div></td>
			                  <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
			                    <input name="asunto" type="text" id="asunto" size="30" />
			                    </font></span></td>
		                    </tr>
			                <tr>
			                  <td height="88"><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif"> MENSAJE :</font></div></td>
			                  <td><span class="Estilo7"> <font face="Verdana, Arial, Helvetica, sans-serif">
			                    <textarea name="mensaje" cols="40" rows="4" id="mensaje"></textarea>
			                    </font></span></td>
		                    </tr>
			                <tr>
			                  <td>&nbsp;</td>
			                  <td><span class="Estilo8"></span></td>
		                    </tr>
			                <tr>
			                  <td>&nbsp;</td>
			                  <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
			                    <input name="submit" type="submit" value="Enviar Información" />
			                    </font></span></td>
		                    </tr>
		                  </table>
			              <div align="center"> </div>
			              </form>
                        <font face="Verdana, Arial, Helvetica, sans-serif">
                        <?
								}else{
									//Estoy recibiendo el formulario, compongo el cuerpo
									$cuerpo = "Formulario de CONTACTO \n\n\n";
									$cuerpo = "===== INFORMACION DE USUARIO ===== \n\n";
									$cuerpo .= "Nombre: " . $HTTP_POST_VARS["nombre"] . "\n";
									$cuerpo .= "Telefono: " . $HTTP_POST_VARS["telefono"] . "\n";
									$cuerpo .= "Email: " . $HTTP_POST_VARS["email"] . "\n";
									$cuerpo .= "Asunto: " . $HTTP_POST_VARS["asunto"] . "\n\n";
									//$cuerpo .= "Banco: " . $HTTP_POST_VARS["empresa"] . "\n";
									$cuerpo .= "Mensaje: " . $HTTP_POST_VARS["mensaje"] . "\n";

									//mando el correo...
									$email1=$HTTP_POST_VARS["email"];
									mail("cecip_online@centroeducativocecip.com","Mensaje de Contacto:",$cuerpo,"From: Contacto $email1");

									//doy las gracias por el env&iacute;o
									echo "Gracias por Contactarnos. \n";
									echo "En Breve nos Comunicaremos con Usted..!.";

								}
								?>
                        </font></td>
				        <td width="603" align="center" valign="middle"><table width="200" border="0">
				          <tr>
				            <td><span class="Estilo611"><img src="css/images/donaciones.png" width="194" height="52" align="middle"></span></td>
			              </tr>
				          </table>
				          <table width="522" border="0">
			              <tr>
			                <td width="516" height="24" bgcolor="#edf3f8" class="Estilo541"><span class="Estilo801">Direcci&oacute;n en Venezuela: Sector Sierra Maestra, calle 13 entre Av. 7 y 8. Tel&eacute;fonos: 58-(261) 3229424- 58-(424)-6170987</span></td>
		                  </tr>
			              <tr>
			                <td class="Estilo541" bgcolor="#edf3f8" height="24"><span class="Estilo801">Para contactarnos fuera del pais: Toll Free Number 1 (844) 627-6508 ó 1 (786) 315-6394 </span></td>
		                  </tr>
			              <tr>
			                <td class="Estilo541" bgcolor="#edf3f8" height="22"><span class="Estilo801">P.O BOX 836144 Miami, Florida, 33283 </span></td>
		                  </tr>
			              <tr>
			                <td class="Estilo541" bgcolor="#000000" height="22">Correo Electronico:<a href="mailto:cecip_online@centroeducativocecip.com" class="Estilo81">cecip_online@centroeducativocecip.com</a></td>
		                  </tr>
			              <tr>
			                <td>&nbsp;</td>
		                  </tr>
			              <tr>
			                <td><table width="521" border="0">
			                  <tr>
			                    <td width="515"><table width="493" height="518" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#EDF3F8">
			                      <tr>
			                        <td width="493" height="20" bgcolor="#5282C9" class="Estilo57" ><strong>Donaciones dentro de los EE.UU</strong></td>
		                          </tr>
			                      <tr>
			                        <td height="90" class="Estilo541"><strong>A nombre de <span class="Estilo3">Redil,Corp</span></strong>
			                          <blockquote>
			                            <table width="289" border="0">
			                              <tr>
			                                <td width="243" height="62">Banco Wells Fargo&nbsp;&nbsp; <br />
			                                  # 
			                                  5232312263<br />
			                                  checking account</td>
		                                  </tr>
		                                </table>
			                            <p>&nbsp;</p>
		                              </blockquote></td>
		                          </tr>
			                      <tr>
			                        <td height="20" bgcolor="#5282C9" ><p align="center"><span class="Estilo61"><strong><strong>Donaciones con tarjeta de cr&eacute;dito fuera de Venezuela ( USD) </strong></span></p></td>
		                          </tr>
			                      <tr>
			                        <td height="68" ><table width="175" border="0" align="center" cellpadding="0" cellspacing="0">
			                          <tr>
			                            <td><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
			                              <input type="hidden" name="cmd" value="_s-xclick" />
			                              <input type="hidden" name="hosted_button_id" value="CZ7EMGNBCT9L6" />
			                              <input type="image" src="https://www.paypalobjects.com/es_XC/i/btn/btn_donateCC_LG.gif" border="0" name="submit2" alt="PayPal, la forma más segura y rápida de pagar en línea." />
			                              <img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1" />
			                              </form></td>
		                              </tr>
			                          </table></td>
		                          </tr>
			                      <tr>
			                        <td height="220"><table width="487"  border="0" align="center" cellpadding="1" cellspacing="1">
			                          <tbody>
			                            <tr>
			                              <th width="430" height="20" bgcolor="#5282c9" class="Estilo57" scope="col"> <p><span class="Estilo61"><strong><strong>Donaciones dentro de Venezuela.</strong></span></p></th>
		                                </tr>
			                            <tr>
			                              <td class="Estilo541" bgcolor="#edf3f8" height="100"><table width="321" border="0">
			                                <tr>
			                                  <td width="315"><strong>A nombre de <span class="Estilo3">FUNDACION REDIL</span></strong></td>
			                                  </tr>
			                                </table>
			                                <p>&nbsp;</p>
			                                <blockquote>
			                                  <ul>
			                                    <li>Banco Venezuela: 01020347310000095044</li>
			                                    <li>RIF J- 40112407-0</li>
		                                      </ul>
		                                    </blockquote></td>
		                                </tr>
		                              </tbody>
			                          </table></td>
		                          </tr>
			                      </table></td>
		                      </tr>
			                  <tr>
			                    <td height="22">&nbsp;</td>
		                      </tr>
		                    </table></td>
		                  </tr>
			              </table>
	            <p class="Estilo611">&nbsp;</p></td>
	          </tr>
				      <tr>
				        <td valign="top">&nbsp;</td>
				        <td valign="top">&nbsp;</td>
			          </tr>
				      <tr>
				        <td colspan="2" valign="top"><img src="css/images/banerlibreriaIP.jpg" alt="REDESSOCIALES" width="924" height="205" border="0" usemap="#MapMap" /></td>
			          </tr>
			        </table>
				    <map name="MapMap" id="Map">
				      <area shape="rect" coords="6,4,915,198" href="http://www.ministerioredil.org/tienda" target="_blank" />
			        </map>
				    <h3>&nbsp;</h3>
				  </div>
				</section>
			</div>
			<!-- end of main -->
			<div class="cl">&nbsp;</div>
			
			<!-- footer -->
			<div id="footer"><img src="css/images/paypal.jpg" alt="en la imagen se pueden ver varias personas reunidas estudiando" width="950" height="50" hspace="12" border="0" align="middle" usemap="#MapMap2">
			  <map name="MapMap2">
			    <area shape="rect" coords="3,600,576,832" href="http://www.ministerioredil.org/tienda" target="_blank" />
			    <area shape="rect" coords="69,355,501,396" href="salmistas.html" target="_self" alt="salmistas">
			    <area shape="rect" coords="69,295,501,341" href="culturaygobierno.html" target="_self" alt="culturaygobierno">
			    <area shape="rect" coords="68,240,501,279" href="profetas.html" target="_self" alt="profeta">
			    <area shape="rect" coords="67,181,503,221" href="escuelaintersecion.html" target="_self" alt="escuelaintersecion">
			    <area shape="rect" coords="4,406,564,592" href="http://centroeducativocecip.com/reg_alumnos_online.php" target="_self">
		      </map>
		  </div>
			<!-- end of footer -->
		</div>
		<!-- end of container -->
	</div>
	<!-- end of shell -->
</div>
<!-- end of wrapper -->

<map name="Map">
  <area shape="rect" coords="11,9,327,72" href="#">
</map>
</body>
</html>