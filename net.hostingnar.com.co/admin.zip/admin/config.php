<?php

// Registro de usuarios PHPFACIL.NET
// CopyLeft 2005 phpfacil.net // Guillem 
// Config.php
// Creado: 20-3-05

// Configuraci�n del script

///// Base de datos

	//$host = "localhost"; //Host base de datos
	//$user = "minister_admin"; // Usuario nase de datos
	//$pass = "admin32"; // Contrase�a Base de datos
	//$db   = "minister_admin"; // Nombre base de datos
	//$dirw = ""; //Direcci�n de su web, debe acabar en "/".
	
/// No tocar -----------------------------------------

	if(!$conectar = @mysql_connect($host,$user,$pass)){

		echo"No se ha podido conectar a la base de datos";
		exit;
	
	} 
	
	mysql_select_db($db,$conectar);	
	
	if($configuracion != "no"){

	$query = mysql_query("SELECT * FROM configuracion"); 
	$sql = mysql_fetch_array($query);

	$administrador = $sql[administrador]; // ID del administrador
	$puntos = $sql[puntos]; // Activar sistema de puntos
	$idioma = $sql[idioma]; //Idioma: espanol.php, catala.php
	$pagina = $sql[pagina]; //Pagina
	$get = $sql[get];		// Get
	$estilo = $sql[estilo];	// Estilo



	if($directorio){

	if(file_exists($directorio."idiomas/".$idioma)){
		include("./idiomas/".$idioma);
	} else {
		echo"No se ha encontrado p�gina de idiomas";
	}
	} else {


	if(file_exists("idiomas/".$idioma)){
		include("idiomas/".$idioma);
	} else {
		echo"No se ha encontrado la p�gina de idiomas";
	}
	}

	}
	
	$GLOBALS['required_php_version'] = '4.1.0';

	$phpversion = phpversion();

	if($phpversion < $GLOBALS['required_php_version']){

		echo"Tu versi�n de php es inferior  a la 4.1.0, este script no funciona con versiones anteriores a esa";
		exit;
	}
	
	if(!$instalando){
	
	if(file_exists("instalar.php") or file_exists("update.php")){
		echo"<b><font size=3>Tienes que borrar el archivo instalar.php y update.php!!</font></b>";
	}
	if(!function_exists("comprueba_sesion")){
	
	function comprueba_sesion(){
	
	if($_COOKIE[nombre]){ if($_COOKIE[contrasena]){
			
			$query="SELECT * FROM usuarios WHERE nick='$_COOKIE[nombre]' and contrasena='$_COOKIE[contrasena]' and id='$_COOKIE[id]'"; $resp = mysql_query($query);
			$count = mysql_num_rows($resp);
			
			if($count != 1){
				echo"Sesi�n incorrecta";
				exit;
			}
			
		} else {
		echo"Sesi�n incorrecta";
		exit;
		}
	}
}
}
	
comprueba_sesion();

}


?>