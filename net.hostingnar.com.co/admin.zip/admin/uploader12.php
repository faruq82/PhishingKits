<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "descargas.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>subida de archivos</title>
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<?
if( !isset($_FILES['evaluativo12']) ){
  echo 'Ha habido un error, tienes que elegir un archivo<br/>';
  echo '<a href="descargas_evaluativos_escuelaintersecion.php">Subir archivo</a>';
}else{
  $cedula = $_POST['cedula'];
  $id = $_POST['id'];
  $escuela = $_POST['escuela'];
  $alumno = $_POST['alumno'];
  $email = $_POST['email'];
  $nombre = $_FILES['evaluativo12']['name'];
  $nombre_tmp = $_FILES['evaluativo12']['tmp_name'];
  $tipo = $_FILES['evaluativo12']['type'];
  $tamano = $_FILES['evaluativo12']['size'];
 
  $ext_permitidas = array('docx','doc');
  $partes_nombre = explode('.', $nombre);
  $extension = end( $partes_nombre );
  $ext_correcta = in_array($extension, $ext_permitidas);
 
  //$tipo_correcto = preg_match('/^application\/(docx|doc)$/', $tipo);
 
  $limite = 500 * 1024;
  //if( $ext_correcta && $tipo_correcto && $tamano <= $limite ){
  if( $ext_correcta  && $tamano <= $limite ){
    if( $_FILES['evaluativo12']['error'] > 0 ){
      echo 'Error: ' . $_FILES['evaluativo12']['error'] . '<br/>';
    }else{
      echo 'Nombre del Archivo: ' .$nombre. '<br/>';
     // echo 'Tipo: ' . $tipo . '<br/>';
      echo 'Tamaño: ' . ($tamano / 1024) . ' Kb<br/>';
     // echo 'Guardado en: ' . $nombre_tmp;
 
      if( file_exists( 'subidas/'.$escuela.'-'.$cedula.'-'.$nombre) ){
        echo '<br/>El archivo ya fue subido: ' .$nombre.'<br/>DEBE ESPERAR QUE EL DEPARTAMENTEO DE CONTROL DE ESTUDIO LO REVISE';
      }else{
	  	//if (!move_uploaded_file($_FILES['FICHEROIMAGEN']['tmp_name'],$DIRECTORIOIMAGEN.$NOMBRE_ARCHIVOIMAGEN))
		$fecha=date ( "j / n / Y" );
		$archivo=$escuela.'-'.$cedula.'-'.$nombre;
		$evaluativo="evaluativo12";
		mysql_query("INSERT INTO evaluativos (alumno,nombre,email,archivo,cedula,id_online,escuela,fecha,evaluativo) 
	   	VALUES ('$alumno','$nombre','$email','$archivo','$cedula','$id','$escuela','$fecha','$evaluativo')")or die (mysql_error());
		
        move_uploaded_file($nombre_tmp,"subidas/". $escuela.'-'.$cedula.'-'.$nombre);
 
        //echo "<br/>Guardado en: " . "subidas/" $escuela."-".$cedula.$nombre;
											$cuerpo = "===== INFORMACION ===== \n\n";
									$cuerpo .= "Alumno" . $alumno . "\n";
									$cuerpo .= "SE HA SUBIDO CORRECTAMENTE. SERA REVISADO POR EL DEPARTAMENTO DE CONTROL DE ESTUDIONOTA: SOLO SUBA EL ARCHIVO UNA SOLA VEZ " . "\n";
 
        //echo "<br/>Guardado en: " . "subidas/" $escuela."-".$cedula.$nombre;
		mail("cecip_online@centroeducativocecip.com","TIENES UN NUEVO EVALUATIVO",$cuerpo,"From: Contacto $email");
		
		mail($email,"Evaluativo SE HA SUBIDO CORRECTAMENTE",$cuerpo,"From: Cecip <cecip_online@centroeducativocecip.com>");

	
		echo 'EL ARCHIVO '.$nombre.'  SE HA SUBIDO CORRECTAMENTE.<br/> DEBE ESPERAR LA REVISIÓN POR EL DEPARTAMENTO DE CONTROL DE ESTUDIO<br/><br/>NOTA: SOLO SUBA EL ARCHIVO UNA SOLA VEZ';     
      }
    }
  }else{
    echo 'Archivo inválido';
  }
}
?>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>