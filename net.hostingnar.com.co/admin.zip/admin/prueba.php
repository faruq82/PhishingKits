<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang='en'>
<head>
<meta http-equiv='Content-Type' content='text/html; charset=ISO-8859-1'>
<META name="description" content="">
<meta name="keywords" content="">
<title>Untitled</title>
<!-- link rel='stylesheet' href='/include/style.css' type='text/css' -->
<style type="text/css">
<!--
-->
</style>
</head>
<body>
<?php
$float1 = 3;
$float2 = 1.2;

$float12= $float1 - $float2;

echo $float12;



?>
</body>
</html>