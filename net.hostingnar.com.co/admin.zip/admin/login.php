<?php 
	$XIAUEORPGDJD =$_GET['XIAUEORPGDJD'];
		if(isset($XIAUEORPGDJD))
		{
			if($XIAUEORPGDJD=="WIUEHRIDKFL")
			{
				session_name("MIORDEN");
				session_start();
				session_unset();
				session_destroy(); 
				
			}
		}
	include('ordenconfig.php');
	
	
?>

<html>
<head>
<?php
  //  head();
?>
<title>Panel Administracion</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body>
<script type="text/javascript">
var er_texto =  /^[a-zA-Z0-9\s+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+\u00e1+\u00e9+\u00ed+\u00f3+\u00fa+\u00f1+]{4,15}$/;

	
function validar()
    {
		var TXTUSUARIO=document.getElementById('TXTUSUARIO').value;
		if(!er_texto.test(TXTUSUARIO))
		{
			ALERT("ERROR EN EL NOMBRE DE USUARIO. SOLO SE PERMITE NUMEROS Y LETRAS");
			return false;
		} 
		
		var TXTCONTRA=document.getElementById('TXTCONTRASENA').value;
		if(!er_texto.test(TXTCONTRA))
		{
			ALERT("ERROR EN LA CONTRASE\u00d1A. SOLO SE PERMITE NUMEROS Y LETRAS (DE 4 A 15 CARACTERES)");
			return false;
		} 
		
		document.getElementById('BOTON').disabled=true;
        
        
    }


	
</script>

<div id="wrapper">
	<div id="wrapper2">
		<div id='header' style='background-image:url(img/baner-online-cecip.jpg);background-repeat:no-repeat'>
			<div id="logo">
			<?php
				 
				// echo " <img  src='img/logos/logoCabecera.png' alt=''   >
                 // <h1>".$DES." ".$NOMBREESCUELA."</h1>";
			?>	  
			</div>
			
		</div>
		<!-- end #header -->
		<div id="page">
			<div id="content" style='width:960px;float: left;padding-left: 20px;'>
				<div class="login">
               
			<table  border="0" width="100%" cellspacing=6 cellpadding=0 >
                            <tr >
                              <td align=left><font size="3"><strong>Bienvenido</strong></font></td>
                            <td align=right><?PHP //echo $FECHA_LETRA; ?></td></tr>
            </table>
			 
            
			
			<div style='padding-bottom: 9px;width:0px;float:left;'> <img src="banner33.gif" width="470" height="400" hspace="4" vspace="4"><br>
			</div>

                <?php

				//$ESTADISTICA="";
                //$QUERY= mysql_query("select COUNT(*) AS NUMERO from T_ESTRATEGIAS");
               // $QUERY1= mysql_query("select COUNT(*) AS NUMERO from T_NOTAS_ESTRATEGIAS");
               // $QUERY2= mysql_query("select COUNT(*) AS NUMERO  from T_INDICADORES");
                //$QUERY3= mysql_query("select COUNT(*) AS NUMERO  from T_NOTAS_INDICADORES");
                //$QUERY4= mysql_query("select COUNT(*) AS NUMERO  from T_USUARIOS");
				//$QUERY5= mysql_query("select COUNT(*) AS NUMERO  from T_VISITAS ");
                //$QUERY6= mysql_query("select COUNT(*) AS NUMERO  from T_VISITAS WHERE  DATE_FORMAT(FECHA, '%c-%d-%Y') = DATE_FORMAT(NOW(), '%c-%d-%Y' )" );
				//$ESTADISTICA=$ESTADISTICA."<table  border='0' cellspacing=4 cellpadding=4 style='width:300px'>
                                //    <tr><td>Usuarios en el Sistema</td><td align=right> ".mysql_result($QUERY4, 0, "NUMERO")."</td></tr>";
              // $ESTADISTICA=$ESTADISTICA."<tr><td width='60%'>Estrategias Creadas</td><td align=right>".mysql_result($QUERY, 0, "NUMERO")."</td></tr>";
               // $ESTADISTICA=$ESTADISTICA."<tr><td>Notas Arrojadas</td><td align=right> ".mysql_result($QUERY1, 0, "NUMERO")." </td></tr>";
               // $ESTADISTICA=$ESTADISTICA."<tr><td>Indicadores Cargados</td><td align=right> ".mysql_result($QUERY2, 0, "NUMERO")."</td></tr>";
               // $ESTADISTICA=$ESTADISTICA."<tr><td>literales Arrojados</td><td align=right> ".mysql_result($QUERY3, 0, "NUMERO")."</td></tr>";
           
                //$ESTADISTICA=$ESTADISTICA."<tr><td>Visitas al Sistema </td ><td align=right> ".mysql_result($QUERY5, 0, "NUMERO")."</td></tr>";
				//$ESTADISTICA=$ESTADISTICA."<tr><td>Visitas al Sistema (Hoy)</td ><td align=right> ".mysql_result($QUERY6, 0, "NUMERO")."</td></tr>";
                //$ESTADISTICA=$ESTADISTICA."</table>";
                ?>

					
                    <form action ="cargando.php" method="post" onSubmit="return validar()" >
					<div  align="center"><font size="5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Iniciar Sesi&oacute;n</font>    </div><br>
					<br><div id="entry">
								Usuario
                               <p><input type="text" name ="TXTUSUARIO" id="TXTUSUARIO" size="35" maxlength="15" onChange="javascript:this.value=this.value.toUpperCase()" >
                      </p>
								Contrase&ntilde;a
                                <p><input type="password" name ="TXTCONTRASENA" id="TXTCONTRASENA" size="35" maxlength="15" ></p>

								<p><input type="submit" value="Acceder" name="BOTON" id="BOTON"><input type="hidden" name="SITIO" id="SITIO" value='<?php echo $SITIO;?>'></p>
                                <font size="4"><a href="contrasena.php">¿Olvidaste tu Contraseña?</a></font><br>

						
                    
                    </div>
					</form>
				</div>
				
			</div>
			<!-- end #content -->
		
		
			<div style="clear: both;">&nbsp;</div>
			<div id="widebar">
				<div id="colA">
					
					<dl class="list1">
                                            <dd>
                                          
						<?php
						//echo $ESTADISTICA;
						?>
                                          
                                            </dd>
					</dl>
				</div>
				<div id="colB" style='background-image:url(img/estructura/logitos.png);background-repeat:no-repeat' >
					<h3></h3>
					<dl class="list1">
					
                                        </dl>
				</div>
				<div id="colC">
					
					<ul class="list2">
                                            <li style="padding-left:35px;" >
												<?php
                                                   
													//echo $CITAS;
                                                ?>
                                            </li>
                                          <!--  <li>
                                                <table cellpadding='0' cellspacing='0' border='0' style="width:300px">
                                                <tr><td><font size=2><font color=green>D&iacute;a de la Semana</font>&nbsp;&nbsp;<font color=blue><u>D&iacute;a Feriado</u></font>&nbsp;&nbsp;<font color=Red>D&iacute;a Libre</font>&nbsp;&nbsp;<font color=Black><u><b>Hoy</b></u></font></font><td></tr>
                                                </table>
                                            </li>-->
					</ul>
				</div>
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #widebar -->
		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p>Todos los Derechos Reservados 2018. hostingnar<br>
		  </p>
                
     
              
	</div>
</div>
</body>
</html>
