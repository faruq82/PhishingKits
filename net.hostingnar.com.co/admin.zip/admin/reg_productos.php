<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	$PROCESO = $_GET['PROCESO'];
	$TXTAULA = $_POST['TXTAULA'];
	$TXTDESCRIPCION = $_POST['TXTDESCRIPCION'];
	$TXTPRECIO = $_POST['TXTPRECIO'];
	$TXTVIDEO = $_POST['TXTVIDEO'];
	$FECHA = $_POST['FECHA'];
	$TXTDURACION= $_POST['TXTDURACION'];
	


	$DIRECTORIOIMAGEN="productos/";
	
	$BOTON = $_POST['BOTON'];
	
	if(!isset($BOTON))
	{	
		$BOTON = $_GET['BOTON'];
		if(!isset($BOTON))
		{
			$BOTON = "Guardar";
		}else{
			$BOTON = $BOTON;
			
		}
		
	}else{
		$BOTON = $BOTON;
		
	}
	
	function  LISTAR_AULAS()
	{
		global $STYLECELDAS,$CABECERACELDAS;
		echo "<br><table width=780><tr><td><b>Lista de Tours.</b></td></tr><tr><td><hr align = center width=780></td></tr><table>";
              
	$QUERY_LISTAR_AULAS = mysql_query("select * from productos order by id");
		if(mysql_num_rows($QUERY_LISTAR_AULAS)==0)
		{
			echo "<b>No tienes productos registrados.</b>";
		}else{
				
				echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera'><th width=150>Precio</th><th width=430>Nombre<th width=50>Act.</th><th width=50>Elim.</th></tr>";
				for($i=0;$i<mysql_num_rows($QUERY_LISTAR_AULAS);$i++)
				{	
					if($i%2==0)
					{
						echo"<tr ".$STYLECELDAS.">";
					}else{
						echo"<tr ".$STYLECELDAS." bgcolor=#F2F9F9>";
					}
						echo "<td align=left>".mysql_result($QUERY_LISTAR_AULAS,$i,"precio")."</td><td>".mysql_result($QUERY_LISTAR_AULAS,$i,"nombre")."</td><td  align = center><a href=reg_productos.php?BOTON=Modificar&ID_AULA=".mysql_result($QUERY_LISTAR_AULAS,$i,"id")."><img src=img/iconos/actualizar.png border=0 onmouseover=this.style.cursor='pointer' title='Modificar Registro'></a></td><td  align = center><a href=reg_productos.php?BOTON=Eliminar&ID_AULA=".mysql_result($QUERY_LISTAR_AULAS,$i,"id")."><img src=img/iconos/eliminar_1.png border=0 onmouseover=this.style.cursor='pointer' title='Eliminar Registro'></a></td></tr>";

					
				}
					
			
			echo "</table>";
			
		}
		echo "<br>";

	}	
	
	
?>
<html >
<head>
<title>Tours</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>
<script type="text/javascript">
</script>

<script language="javascript">
var er_texto = /^[A-Z\s+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+]{1,100}$/;

	function validar()
	{
	
		_TXTAULA= document.getElementById('TXTAULA').value;
		if(!er_texto.test(_TXTAULA))
		{
			ALERT("-Error en campo tipo de usuario");
			return false;
		}
		
	}	
	
		function limpiar()
		{
			document.location = "reg_grados.php";
		
		}
</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
	
  <BR>
    	

    	
    	<form enctype="multipart/form-data" action ="<?php echo $url ?>" method="post" onSubmit="return validar()">
    	<table align="center" border="0"  cellpadding="2" cellspacing="2" width="780">

          <tr>
            <td width="121">Nombre Car </td>
            <td width="645"><input type="text" name ="TXTAULA" id="TXTAULA" size="55" maxlength="45" >
            &nbsp;<font color='red'><label title='Requerido'>*</label></font></td></tr>
			
			    <tr>
            <td width="121">Precio </td>
            <td width="645">
			<input type="text" name ="TXTPRECIO" id="TXTPRECIO" size="15" maxlength="100" >
			&nbsp;<font color='red'><label title='Requerido'>*</label></font></td></tr>
			    <tr>
			      <td>&nbsp;</td>
			      <td><input type="hidden" name ="TXTVIDEO" id="TXTVIDEO" size="55" maxlength="45" ></td>
	      </tr>
			    <tr>
			      <td>Duracion:</td>
			      <td><input type="text" name ="TXTDURACION" id="TXTDURACION" size="15" maxlength="100" > 
			        Horas</td>
	      </tr>
			    <tr>
			      <td>Fecha</td>
			      <td><input type="text" name ="TXTFECHA" id="TXTFECHA" size="15" maxlength="100" ></td>
			    </tr>
			    <tr>
			      <td>Descripcion</td>
			      <td>
				  <textarea cols=82 rows=6 name="TXTDESCRIPCION" id="TXTDESCRIPCION"></textarea>&nbsp;<font color="#FF0000">*</font>
				  
				  </td></tr>
				  <tr>
				    <td> Imagen principal</td><td> <input name="FICHEROIMAGEN"  id="FICHEROIMAGEN" type="file" size="25 ">
				      <input type="text" name ="TXTIMAGEN" id="TXTIMAGEN" size="30" maxlength="25"></td></tr>
			<tr><td>img:</td>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td>Imagen 1 </td>
			  <td><input name="IMAGEN1"  id="IMAGEN1" type="file" size="25 ">
		      <input type="text" name ="TXTIMAGEN1" id="TXTIMAGEN1" size="30"  maxlength="25"></td>
		  </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
			</tr>
			<tr>
			  <td>Imagen 2 </td>
			  <td><input name="IMAGEN2"  id="IMAGEN2" type="file" size="25 ">
		      <input type="text" name ="TXTIMAGEN2" id="TXTIMAGEN2" size="30"  maxlength="25"></td>
		  </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		  </tr>
			<tr>
			  <td>Imagen 3 </td>
			  <td><input name="IMAGEN3"  id="IMAGEN3" type="file" size="25 ">
		      <input type="text" name ="TXTIMAGEN3" id="TXTIMAGEN3" size="30"  maxlength="25"></td>
		  </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		  </tr>
			<tr>
			  <td>Imagen 4 </td>
			  <td><input name="IMAGEN4"  id="IMAGEN4" type="file" size="25 ">
		      <input type="text" name ="TXTIMAGEN4" id="TXTIMAGEN4" size="30"  maxlength="25"></td>
		  </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		  </tr>
			<tr>
			  <td>Imagen 5 </td>
			  <td><input name="IMAGEN5"  id="IMAGEN5" type="file" size="25 ">
		      <input type="text" name ="TXTIMAGEN5" id="TXTIMAGEN5" size="30"  maxlength="25"></td>
		  </tr>
			<tr>
			  <td>&nbsp;</td>
			  <td>&nbsp;</td>
		  </tr>
			<?php 
			HABILITAR('TXTIMAGEN',0);
			HABILITAR('TXTIMAGEN1',0);
			HABILITAR('TXTIMAGEN2',0);
			HABILITAR('TXTIMAGEN3',0);
			HABILITAR('TXTIMAGEN4',0);
			HABILITAR('TXTIMAGEN5',0);
			
			?>
				<tr><td>&nbsp;</td></tr>
                 <tr><td colspan="2" align="left"><input type="reset" value="Limpiar" onClick="limpiar()"><input type="submit" value="<?php echo $BOTON?>" name="BOTON" id="BOTON"><input type="hidden" name ="ACCION" id="ACCION"><input type="hidden" name ="ID_AULA" id="ID_AULA" ></td></tr>
      
	  
	  
	    </table>
        </form>
              
              
        <?php
		$BOTON = $_POST['BOTON'];
		if(!isset($BOTON))
		{	
			$BOTON = $_GET['BOTON'];
			if(!isset($BOTON))
			{
				$BOTON = "";
			}else{
				$BOTON = $BOTON;
				
			}
			
		}else{
			$BOTON = $BOTON;
			
		}
		$ACCION = $_POST['ACCION'];
		if($ACCION==1)
		{
			$SQL=array();
			$ID_AULA= $_POST['ID_AULA'];
				
			$SQL_CHK_EXISTENCIA = mysql_query("select * from productos where ID =".$ID_AULA."");
			if(mysql_num_rows($SQL_CHK_EXISTENCIA)!=0)
			{
		if($_FILES['FICHEROIMAGEN']['name']=="")
			{
			$NOMBRE_ARCHIVOIMAGEN=mysql_result($SQL_CHK_EXISTENCIA,0,"imagep");
		}else{	
			$fechaactual  = date("dHi");  //Fecha Actual       
  			$no_aleatorio  = rand(10, 99); //Generamos dos Digitos aleatorios
			$NOMBRE_ARCHIVOIMAGEN= $fechaactual.$no_aleatorio."-".$_FILES['FICHEROIMAGEN']['name'];
			 if (move_uploaded_file($_FILES['FICHEROIMAGEN']['tmp_name'],"productos/".$fechaactual.$no_aleatorio."-".$_FILES['FICHEROIMAGEN']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');	
			} else {
           //Si no se ha podido subir la imagen, mostramos un mensaje de error
           	MESSAGE('Ocurrió algún error al subir el fichero. No pudo guardarse.');
       		 }
		 }
			///// imagen 1 ////
		if($_FILES['IMAGEN1']['name']=="")
			{
			$nomimage1=mysql_result($SQL_CHK_EXISTENCIA,0,"image1");
		}else{
			$no_aleatorio1  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage1= $fechaactual.$no_aleatorio1."-".$_FILES['IMAGEN1']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN1']['tmp_name'],"productos/".$fechaactual.$no_aleatorio1."-".$_FILES['IMAGEN1']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }
		} 
			///// imagen 2 ////
		if($_FILES['IMAGEN2']['name']=="")
			{
			$nomimage2=mysql_result($SQL_CHK_EXISTENCIA,0,"image2");
		}else{
			$no_aleatorio2  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage2= $fechaactual.$no_aleatorio2."-".$_FILES['IMAGEN2']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN2']['tmp_name'],"productos/".$fechaactual.$no_aleatorio2."-".$_FILES['IMAGEN2']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }		 
		}
			///// imagen 3 ////
		if($_FILES['IMAGEN3']['name']=="")
			{
			$nomimage3=mysql_result($SQL_CHK_EXISTENCIA,0,"image3");
		}else{
			$no_aleatorio3  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage3= $fechaactual.$no_aleatorio3."-".$_FILES['IMAGEN3']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN3']['tmp_name'],"productos/".$fechaactual.$no_aleatorio3."-".$_FILES['IMAGEN3']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }				 
		}
			///// imagen 4 ////
		if($_FILES['IMAGEN4']['name']=="")
			{
			$nomimage4=mysql_result($SQL_CHK_EXISTENCIA,0,"image4");
		}else{
			$no_aleatorio4  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage4= $fechaactual.$no_aleatorio4."-".$_FILES['IMAGEN4']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN4']['tmp_name'],"productos/".$fechaactual.$no_aleatorio4."-".$_FILES['IMAGEN4']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }				
		}
			///// imagen 5 ////
		if($_FILES['IMAGEN5']['name']=="")
			{
			$nomimage5=mysql_result($SQL_CHK_EXISTENCIA,0,"image5");
		}else{
			$no_aleatorio5  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage5= $fechaactual.$no_aleatorio5."-".$_FILES['IMAGEN5']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN5']['tmp_name'],"productos/".$fechaactual.$no_aleatorio5."-".$_FILES['IMAGEN5']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }				
		}

			}
			
			
			
			$SQL[] = "UPDATE productos  SET nombre = '".$TXTAULA."', image1 ='".$nomimage1."', image2 ='".$nomimage2."', image3='".$nomimage3."', image4='".$nomimage4."', image5 ='".$nomimage5."',video ='".$TXTVIDEO."',fecha ='".$TXTFECHA."',duracion ='".$TXTDURACION."',precio ='".$TXTPRECIO."', imagep ='".$NOMBRE_ARCHIVOIMAGEN."', descripcion ='".$TXTDESCRIPCION."' WHERE id = ".$ID_AULA."";

			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
			unset($SQL);
			
			ASIG_VALOR(0,0,"ACCION","");
			ASIG_VALOR(0,0,"ID_AULA","");
			echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
		
			$BOTON = "";
			
		}
		if($ACCION==2)
		{
			$ID_AULA = $_POST['ID_AULA'];
				
			$SQL=array();
			$SQL[] = "DELETE FROM productos WHERE id = ".$ID_AULA."";
				
			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
			unset($SQL);
			ASIG_VALOR(0,0,"ACCION","");
			ASIG_VALOR(0,0,"ID_AULA","");
			
			echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			$BOTON = "";
		}
		if($BOTON=="Eliminar")
		{
			$ID_AULA = $_GET['ID_AULA'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from productos where id =".$ID_AULA."");
			ASIG_VALOR(0,0,"TXTAULA",mysql_result($SQL_CHK_EXISTENCIA,0,"nombre"));
			ASIG_VALOR(0,0,"TXTDESCRIPCION",mysql_result($SQL_CHK_EXISTENCIA,0,"descripcion"));
			ASIG_VALOR(0,0,"ID_AULA",mysql_result($SQL_CHK_EXISTENCIA,0,"id"));
			ASIG_VALOR(0,0,"ACCION","2");
			
			
		}
		if($BOTON=="Modificar")
		{	
			
			
			
			$ID_AULA = $_GET['ID_AULA'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from productos where id =".$ID_AULA."");
			ASIG_VALOR(0,0,"TXTAULA",mysql_result($SQL_CHK_EXISTENCIA,0,"nombre"));
			ASIG_VALOR(0,0,"TXTDESCRIPCION",mysql_result($SQL_CHK_EXISTENCIA,0,"descripcion"));
			ASIG_VALOR(0,0,"TXTPRECIO",mysql_result($SQL_CHK_EXISTENCIA,0,"precio"));
			ASIG_VALOR(0,0,"TXTVIDEO",mysql_result($SQL_CHK_EXISTENCIA,0,"video"));
			ASIG_VALOR(0,0,"TXTFECHA",mysql_result($SQL_CHK_EXISTENCIA,0,"fecha"));
			ASIG_VALOR(0,0,"TXTDURACION",mysql_result($SQL_CHK_EXISTENCIA,0,"duracion"));		
			ASIG_VALOR(0,0,"TXTIMAGEN",mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGEP"));
			ASIG_VALOR(0,0,"TXTIMAGEN1",mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGE1"));
			ASIG_VALOR(0,0,"TXTIMAGEN2",mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGE2"));
			ASIG_VALOR(0,0,"TXTIMAGEN3",mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGE3"));
			ASIG_VALOR(0,0,"TXTIMAGEN4",mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGE4"));
			ASIG_VALOR(0,0,"TXTIMAGEN5",mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGE5"));
			
			
			ASIG_VALOR(0,0,"ID_AULA",mysql_result($SQL_CHK_EXISTENCIA,0,"id"));
			ASIG_VALOR(0,0,"ACCION","1");
		
		}
		if($BOTON=="Guardar")
		{
			 
			$SQL_CHK_EXISTENCIA = mysql_query("select * from productos where  imagep = '$NOMBRE_ARCHIVOIMAGEN'");
			if(mysql_num_rows($SQL_CHK_EXISTENCIA)==0)
			{

			$fechaactual  = date("dHi");  //Fecha Actual       
  			$no_aleatorio  = rand(10, 99); //Generamos dos Digitos aleatorios
			$NOMBRE_ARCHIVOIMAGEN= $fechaactual.$no_aleatorio."-".$_FILES['FICHEROIMAGEN']['name'];
			if (move_uploaded_file($_FILES['FICHEROIMAGEN']['tmp_name'],"productos/".$fechaactual.$no_aleatorio."-".$_FILES['FICHEROIMAGEN']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');	
			} else {
           //Si no se ha podido subir la imagen, mostramos un mensaje de error
           	MESSAGE('Ocurrió algún error al subir el fichero. No pudo guardarse.');
       		 }
		
			///// imagen 1 ////
			$no_aleatorio1  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage1= $fechaactual.$no_aleatorio1."-".$_FILES['IMAGEN1']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN1']['tmp_name'],"productos/".$fechaactual.$no_aleatorio1."-".$_FILES['IMAGEN1']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }
	
			///// imagen 2 ////
			$no_aleatorio2  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage2= $fechaactual.$no_aleatorio2."-".$_FILES['IMAGEN2']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN2']['tmp_name'],"productos/".$fechaactual.$no_aleatorio2."-".$_FILES['IMAGEN2']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }		 
		
			///// imagen 3 ////
			$no_aleatorio3  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage3= $fechaactual.$no_aleatorio3."-".$_FILES['IMAGEN3']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN3']['tmp_name'],"productos/".$fechaactual.$no_aleatorio3."-".$_FILES['IMAGEN3']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }				 
		
			///// imagen 4 ////
			$no_aleatorio4  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage4= $fechaactual.$no_aleatorio4."-".$_FILES['IMAGEN4']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN4']['tmp_name'],"productos/".$fechaactual.$no_aleatorio4."-".$_FILES['IMAGEN4']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }				
		
			///// imagen 5 ////
			$no_aleatorio5  = rand(10, 99); //Generamos dos Digitos aleatorios
			$nomimage5= $fechaactual.$no_aleatorio5."-".$_FILES['IMAGEN5']['name'];
			 if (move_uploaded_file($_FILES['IMAGEN5']['tmp_name'],"productos/".$fechaactual.$no_aleatorio5."-".$_FILES['IMAGEN5']['name'])) {		
			// MESSAGE('Se ha subido correctamente la imagen.');
			} else {
           	MESSAGE('Ocurrió algún error al subir la imagen principal. No pudo guardarse.');
       		 }				
			
			
	
			

			
				$SQL=array();
				$SQL[] = "INSERT INTO productos (nombre,descripcion,precio,imagep,image1,image2,image3,image4,image5,video,fecha,duracion) VALUES ('".$TXTAULA."','".$TXTDESCRIPCION."','".$TXTPRECIO."','".$NOMBRE_ARCHIVOIMAGEN."','".$nomimage1."','".$nomimage2."','".$nomimage3."','".$nomimage4."','".$nomimage5."','".$TXTVIDEO."','".$FECHA."','".$TXTDURACION."');";
					
			

			
			
			
			
			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
			unset($SQL);
				echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			}else{
				MESSAGE('HUBO UN ERROR DURANTE LA OPERACION. EL REGISTRO YA SE ENCUENTRA ALMACENADO');
			}
			
			
		}
?> 

 <?php LISTAR_AULAS(); 
		piecera($PRIVILEGIO);
?>
</body>
</html>