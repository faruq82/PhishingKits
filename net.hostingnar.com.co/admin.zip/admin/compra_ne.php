<?php

	$id = $_POST['id'];
	$id_personal = $_POST['idpersonal'];
	//$creditos = $_POST['creditos'];
	$creditodi = $_POST['creditodi'];
	$vacredito = $_POST['vacredito'];
	$nombre = $_POST['nombre'];
	$seudonimo = $_POST['seudonimo'];
	require('ceoconexion.php');
	
 	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
			
				alert('".$MSJ."');
				
			</script>
		";
	}  
		
if ($creditodi <=0){	

MESSAGE('NO DISPONE DE CREDITO PARA PODER REALIZAR LA COMPRA, DEBE COMUNICARSE CON VENTAS AL Whatsapp: +573113761056 ');

}else{



		$sql = "UPDATE t_netflix SET tipo='' where id_areacomp='$id'";
		$result = mysql_query($sql);


		//$creditos=intVal($creditodi)-intVal($vacredito);
		$creditos=$creditodi-$vacredito;
		$sql2 = "UPDATE alumnos_online SET creditos='$creditos' where id_personal='$id_personal'";
		$result2 = mysql_query($sql2);
		
		
		
			mysql_query("INSERT INTO t_cuentas (nombre,usuario, id_personal,tipo,valor) VALUES ('".$nombre."','".$seudonimo."','".$id_personal."','NETFLIX','".$vacredito."')");
		
}		
	echo"<script>location='inicio.php'</script>";	
	
?>