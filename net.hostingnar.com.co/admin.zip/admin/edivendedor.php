<?php

	$id = $_POST['id'];
	$id_personal = $_POST['idpersonal'];
	$seudonimo = $_POST['seudonimo'];
	$clave = md5($_POST['clave'],false);
	$creditos = $_POST['creditos'];
	$celular = $_POST['celular'];
	
	require('ceoconexion.php');
	
 	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
			
				alert('".$MSJ."');
				
			</script>
		";
	}  
		



		$sql = "UPDATE t_personal SET cedula='$seudonimo',celular='$celular' where id_personal='$id_personal'";
		$result = mysql_query($sql);


		
		
		$sql2 = "UPDATE alumnos_online SET creditos='$creditos',nick='$seudonimo', celular='$celular',contrasena='$clave'  where id='$id'";
		$result2 = mysql_query($sql2);
		

		$sql3 = "UPDATE t_usuarios SET contrasena='$clave',nombre_usuario='$seudonimo' where id_personal='$id_personal'";
		$result3 = mysql_query($sql3);		
		

		
		
	echo"<script>location='lista_vendedores.php'</script>";	
	
?>