<?php 
	
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	
?>
<html >
<head>
<title>Registro de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>
<script type="text/javascript">
</script>

<script language="javascript">
	var er_identificacion = /^[0-9]{6,11}$/;
	var er_texto = /^[a-zA-Z0-9\.+\_+\s+\,+\-+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+]{1,45}$/;
	var er_fecha = /^[0-9]{2}[\-]{1}[0-9]{2}[\-]{1}[0-9]{4}$/;
	var er_telefono = /^[0-9]{4}[\-]{1}[0-9]{7}$/;

	


function BUSQUEDAPERSONAL()
{
			

	document.getElementById('nobodybusqueda').innerHTML="<div id='ventanabusqueda'  onmousedown=dragStart(event,'nobodybusqueda') style='visibility:visible'><table border=0 cellpadding=0 cellspacing=0 width=700  background='img/estructura/busqueda.png' valign=top ><tr valign=center ><td  colspan=2 width=697 align='right' valign=center>&nbsp;&nbsp;</td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr>" +
	"<tr valign=center><td width=350>&nbsp;&nbsp;Enter some information&nbsp;&nbsp;<input type=text name=TXTDATO id=TXTDATO onblur=this.value=this.value.toUpperCase()>&nbsp;<img src='img/iconos/buscar.png' title='Buscar' onClick='validarbusqueda()' style='cursor:pointer'></td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr>" +
	"<tr><td  colspan=2 ><table border=1 cellpadding=0 cellspacing=0 width=697 align=center><tr class='cabecera'><th align=center width=97>&nbsp;&nbsp;Identificacion</th><th align=left width=150>&nbsp;P. Apellido</th><th align=left width=150>&nbsp;S. Apellido</th><th align=left width=150>&nbsp;P. Nombre</th><th align=left width=150>&nbsp;S. Nombre/th></table></td></tr>" +
	"<tr height = 260  ><td colspan=2 valign=top><div id='busquedaarrojada'></div></td></tr>" +
	"<tr><td align=left><div id='CANTIDADLISTAS'>&nbsp;</div></td><td align= right ><input type=button value=Cerrar onClick=cerrarbusqueda()>&nbsp;&nbsp;</td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr></table></div>";
	document.getElementById('TXTDATO').focus();	
	
	
}
function cerrar()
{
	document.getElementById('nobody').innerHTML="";
}
function cerrarbusqueda()
{
	document.getElementById('ventanabusqueda').style.visibility='hidden';
}
function validarbusqueda()
{
	if(document.getElementById('TXTDATO').value=="")
	{
		alert("Debe especificar el dato");
		return false;
	}else{
	
			cargandodatospersonal(0);
			
		}
}
function cargandodatospersonal(NRO)
{
	divResultado = document.getElementById('busquedaarrojada');
	ajax=objetoAjax();
	ajax.open("POST", "ajax_reg_usuarios.php",true);
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
	if(NRO!=0)
	{
		dato = document.getElementById('datoviejo').value
		ajax.send("DATO="+dato+"&ACCION=USUARIOS&NRO="+NRO+"");
	}else{
		ajax.send("DATO="+document.getElementById('TXTDATO').value+"&ACCION=USUARIOS"); 
	}
	ajax.onreadystatechange=function(){
	if (ajax.readyState==4) {
			//mostrar resultados en esta capa
			divResultado.innerHTML = ajax.responseText;
			var muestra = "";
			var cantidad = document.getElementById('cantidad').value;
			for(i=0;i<cantidad;i++)
			{
				if(i==0)
				{
					muestra="&nbsp;<label style='cursor:pointer' onClick=cargandodatospersonal("+(i+1)+")><b>"+(i+1)+"</b></label>";
				}else{
					muestra = muestra+"-<label style='cursor:pointer' onClick=cargandodatospersonal("+(i+1)+")><b>"+(i+1)+"</b></label>"; 
				}
			}
			document.getElementById('TXTDATO').value=document.getElementById('datoviejo').value;
			document.getElementById('CANTIDADLISTAS').innerHTML=muestra;
		}
	}
		 
}
function VOLCAR_PERSONAL(IDENTIDAD)
{
	document.getElementById('TXTIDENTIFICACION').value=IDENTIDAD;
	document.getElementById('buscarimgpersonal').onclick();
	cerrarbusqueda();
}


function objetoAjax()
{ 
	var xmlhttp=false; 
	try 
	{ 
		xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); 
	}
	catch(e)
	{ 
		try
		{ 
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
		} 
		catch(E) { xmlhttp=false; }
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') { xmlhttp=new XMLHttpRequest(); } 

	return xmlhttp; 
}


function limpiar()
{

	document.getElementById('TXTIDENTIFICACION').value = "";
	document.getElementById('TXTP_APELLIDO').value="";
	document.getElementById('TXTS_APELLIDO').value="";
	document.getElementById('TXTP_NOMBRE').value="";
	document.getElementById('TXTS_NOMBRE').value="";
	document.getElementById('ID_PERSONAL').value="";
	document.getElementById('TXTTELEFONO').value="";
	document.getElementById('TXTTELEFONO2').value="";
	document.getElementById('ID_USUARIO').value="";
	document.getElementById('CMBTIPOSUSUARIOS').value=-1;
	document.getElementById('TXTNOMBRE_USUARIO').value="";
	document.getElementById('CMBSEXO').value="M";
	document.getElementById('TXTDIRECCION').value="";
	document.getElementById('TXTCORREO').value="";
	document.getElementById('ID_PERSONAL').value = "";
	document.getElementById('ID_USUARIO').value = "";
	document.getElementById('TXTNOMBRE_USUARIO').value = "";
	document.getElementById('CMBTIPOSUSUARIOS').value = 1;
	document.getElementById('CMBESTATUS_USUARIOS').value = "0";
	document.getElementById('CMBSUCURSAL').value = -1;
	document.getElementById('procesando').innerHTML ='';
	document.getElementById('resultado').innerHTML ='';
	if(document.getElementById('AVISO'))
	{document.getElementById('AVISO').value = '';
	}
	document.getElementById('SUBMIT').value =  "Guardar";
	document.getElementById('TXTIDENTIFICACION').focus()
}

function usuarios(ACCION)
{
	
	   if(ACCION=="BUSCAR")
	   {
		   var datos = new Array();
		   var TXTIDENTIFICACION = document.getElementById('TXTIDENTIFICACION').value;
		  
			  
		    if(!er_identificacion.test(TXTIDENTIFICACION))
			{
				alert("IDENTIFICACION ERRARDA");
				document.getElementById('TXTIDENTIFICACION').focus()
				return false;
			}
			mensaje("Buscando...");
		
			ajax=objetoAjax();
			ajax.open("POST", "ajax_reg_usuarios.php",true);
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ID_PERSONAL="+ID_PERSONAL+"&TXTIDENTIFICACION="+encodeURIComponent(TXTIDENTIFICACION)+"&ACCION=BUSCAR"); 
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4)
				{
					
				
					document.getElementById('divalerta').innerHTML = ajax.responseText;
					document.getElementById('divalerta').style.display='none';
					document.getElementById('divalerta').style.height = "0px";
					if(document.getElementById('AVISO'))
					{
						if(document.getElementById('AVISO').value=="noencontrado")
						{
							alert("NO HUBO RESULTADO");
							limpiar();
							return;
						}else{
							datos = document.getElementById('AVISO').value.split("|");
							document.getElementById('TXTIDENTIFICACION').value=datos[0];
							document.getElementById('TXTP_APELLIDO').value=datos[1];
							document.getElementById('TXTS_APELLIDO').value=datos[2];
							document.getElementById('TXTP_NOMBRE').value=datos[3];
							document.getElementById('TXTS_NOMBRE').value=datos[4];
							document.getElementById('ID_PERSONAL').value=datos[5];
							document.getElementById('ID_USUARIO').value=datos[6];
							document.getElementById('CMBTIPOSUSUARIOS').value=datos[7];
							document.getElementById('TXTNOMBRE_USUARIO').value=datos[8];
							document.getElementById('TXTTELEFONO').value=datos[9];
							document.getElementById('TXTTELEFONO2').value=datos[10];
							document.getElementById('TXTCORREO').value=datos[11];
							document.getElementById('CMBSEXO').value=datos[12];
							document.getElementById('TXTDIRECCION').value=datos[13];
							document.getElementById('CMBSUCURSAL').value=datos[15];
							if(datos[14]=="")
							{
								document.getElementById('CMBESTATUS_USUARIOS').value="0";		
							}
							if(datos[14]=="BLOQUEADO")
							{
								document.getElementById('CMBESTATUS_USUARIOS').value="BLOQUEADO";		
							}
							document.getElementById('SUBMIT').value = "Modificar";
							document.getElementById('procesando').innerHTML ="";
							for(i=0;i<datos.length;i++)
							{
								delete datos[i];
							}
						}
					}else{
						alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
						return false;

					}
				}
			}

         }

		if(ACCION=="MODIFICAR")
		{
			var boton= document.getElementById('SUBMIT').value;
			var ID_USUARIO='<?php echo $ID_USUARIO;?>';
			var P_APELLIDO=document.getElementById('TXTP_APELLIDO').value;
			var S_APELLIDO=document.getElementById('TXTS_APELLIDO').value;
			var P_NOMBRE=document.getElementById('TXTP_NOMBRE').value;
			var S_NOMBRE=	document.getElementById('TXTS_NOMBRE').value;
			var CORREO=	document.getElementById('TXTCORREO').value;
			var SEXO=document.getElementById('CMBSEXO').value;
			var DIRECCION=document.getElementById('TXTDIRECCION').value;
			var TIPO_USUARIO = document.getElementById('CMBTIPOSUSUARIOS').value;
			var ESTATUS_USUARIO = document.getElementById('CMBESTATUS_USUARIOS').value;
			var CMBSUCURSAL = document.getElementById('CMBSUCURSAL').value;
			var TXTIDENTIFICACION = document.getElementById('TXTIDENTIFICACION').value;
			
			  if(!er_identificacion.test(TXTIDENTIFICACION))
			{
				alert("IDENTIFICACION ERRARDA");
				return false;
			}
			if(!er_texto.test(P_NOMBRE))
			{
				ALERT("ERROR EN EL PRIMER NOMBRE");
				return false;
			}

			if(!er_texto.test(P_APELLIDO))
			{
				ALERT("ERROR EN EL PRIMER APELLIDO");
				return false;
			}
			
			var TXTTELEFONO = document.getElementById('TXTTELEFONO').value;
			if(TXTTELEFONO!="")
			{
				if(!er_telefono.test(TXTTELEFONO))
				{
					alert("-ERROR . FORMATO PERMITIDO 9999-9999999");
					return false;
				}
			}
			var TXTTELEFONO2 = document.getElementById('TXTTELEFONO2').value;
			if(TXTTELEFONO2!="")
			{
				if(!er_telefono.test(TXTTELEFONO2))
				{
					alert("-ERROR. FORMATO PERMITIDO 9999-9999999");
					return false;
				}
			}
					
			if(DIRECCION=="")
			{
				ALERT("ERROR EN LA DIRECCION.");
				return false;
			}

			
			
			
			if(boton=="Modificar")
			{
				
				var ID_USER = document.getElementById('ID_USUARIO').value;
				
				var ID_PERSONAL = document.getElementById('ID_PERSONAL').value;
				
							
				if(ID_USER=="")
				{
					alert("DEBE REALIZAR LA BUSQUEDA PRIMERO");
					document.getElementById('TXTIDENTIFICACION').focus()
					return false;
				}
				mensaje("Editing...");
				ajax=objetoAjax();
				ajax.open("POST", "ajax_reg_usuarios.php",true);
				ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
				ajax.send("ID_USER="+encodeURIComponent(ID_USER)+"&TIPO_USUARIO="+encodeURIComponent(TIPO_USUARIO)+"&ESTATUS_USUARIO="+encodeURIComponent(ESTATUS_USUARIO)+"&ID_USUARIO="+ID_USUARIO+"&ACCION=MODIFICAR&ID_PERSONAL="+ID_PERSONAL+"&P_APELLIDO="+P_APELLIDO+"&S_APELLIDO="+S_APELLIDO+"&P_NOMBRE="+P_NOMBRE+"&S_NOMBRE="+S_NOMBRE+"&CORREO="+CORREO+"&SEXO="+SEXO+"&DIRECCION="+encodeURIComponent(DIRECCION)+"&TXTIDENTIFICACION="+TXTIDENTIFICACION+"&TXTTELEFONO="+TXTTELEFONO+"&TXTTELEFONO2="+TXTTELEFONO2+"&CMBSUCURSAL="+CMBSUCURSAL+"");  
					ajax.onreadystatechange=function() {
					if (ajax.readyState==4)
					{
						
						
						document.getElementById('divalerta').innerHTML = ajax.responseText;
						document.getElementById('divalerta').style.display='none';
						document.getElementById('divalerta').style.height = "0px";
						if(document.getElementById('AVISOMOFICIADO'))
						{
							if(document.getElementById('AVISOMOFICIADO').value=="yaexiste")
							{
								alert("IMPOSIBLE REALIZAR LA OPERACION, IDENTIFICACION DUPLICADA");
								return false;
							}
							if(document.getElementById('AVISOMOFICIADO').value=="")
							{
										
								alert("Operation successful");
								limpiar();
								return;
													
							}
							if(document.getElementById('AVISOMOFICIADO').value=="error")
							{
								alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
								
								return false;
							}
						}else{

							alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
							return false;
						

						}
										
					}
				}
				
				
			
			}
			if(boton=="Guardar")
			{
				mensaje("Guardando...");
				var ESTATUS_USUARIO = document.getElementById('CMBESTATUS_USUARIOS').value;
				ajax=objetoAjax();
				ajax.open("POST", "ajax_reg_usuarios.php",true);
				ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
				ajax.send("ID_USER="+encodeURIComponent(ID_USER)+"&TIPO_USUARIO="+encodeURIComponent(TIPO_USUARIO)+"&ESTATUS_USUARIO="+encodeURIComponent(ESTATUS_USUARIO)+"&ID_USUARIO="+ID_USUARIO+"&ACCION=GUARDAR&ID_PERSONAL="+ID_PERSONAL+"&P_APELLIDO="+P_APELLIDO+"&S_APELLIDO="+S_APELLIDO+"&P_NOMBRE="+P_NOMBRE+"&S_NOMBRE="+S_NOMBRE+"&CORREO="+CORREO+"&SEXO="+SEXO+"&DIRECCION="+encodeURIComponent(DIRECCION)+"&TXTIDENTIFICACION="+TXTIDENTIFICACION+"&TXTTELEFONO="+TXTTELEFONO+"&TXTTELEFONO2="+TXTTELEFONO2+"&CMBSUCURSAL="+CMBSUCURSAL+"");  
					ajax.onreadystatechange=function() {
					if (ajax.readyState==4)
					{
						
					
						document.getElementById('divalerta').innerHTML = ajax.responseText;
						document.getElementById('divalerta').style.display='none';
						document.getElementById('divalerta').style.height = "0px";
						if(document.getElementById('AVISOMOFICIADO'))
						{
							if(document.getElementById('AVISOMOFICIADO').value=="yaexiste")
							{
								alert("IMPOSIBLE REALIZAR LA OPERACION, IDENTIFICACION DUPLICADA");
								return false;
							}
							if(document.getElementById('AVISOMOFICIADO').value=="")
							{
										
								alert("OPERACION EXITOSA");
								limpiar();
								return;
							
													
							}
							if(document.getElementById('AVISOMOFICIADO').value=="error")
							{
								alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
								return false;
							}
						}else{

							alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
							return false;
						

						}
										
					}
				}
				
				
			}
		}
		if(ACCION=="CARGAR")
		{
			document.getElementById('TXTIDENTIFICACION').focus()
			
		}
		
}
function Busqueda_Enter(key)
{

	if(key == 13) 
	{	
		usuarios('BUSCAR');
	}
}

</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
     <br>
     <table border="0" cellpadding="2" cellspacing="2" align="center" width="780" >
       <tr>
         <td>Identificaci&oacute;n(cedula)</td>
         <td colspan="3"><table cellpadding="0" cellspacing="0" border=0>
             <tr>
               <td><input type="text" name="TXTIDENTIFICACION" id=TXTIDENTIFICACION size="20" maxlength="10" onChange="javascript:this.value=this.value.toUpperCase()" onKeyUp="javascript:Busqueda_Enter(event.keyCode)">
     &nbsp;<font color=red>
                 <label title='Required'>*</label>
               </font>&nbsp;</td>
               <td><img  style="cursor:pointer" id="buscarimgpersonal" src="img/iconos/buscar.png" title="Buscar" onClick="usuarios('BUSCAR')" /><img src="img/iconos/cargar.png" title="Busqueda Avanzada" onClick="BUSQUEDAPERSONAL()" style="cursor:pointer" ></td>
               <td width=200><div id="procesando"></div></td>
             </tr>
         </table></td>
       </tr>
       <tr>
         <td>Primer Nombre</td>
         <td><input type="text" name ="TXTP_NOMBRE" id="TXTP_NOMBRE" size="25" maxlength="50" onChange="javascript:this.value=this.value.toUpperCase()">
     &nbsp;<font color='red'>
           <label title='Required'>*</label>
         </font></td>
       </tr>
       <tr>
         <td>Segundo Nombre</td>
         <td><input type="text" name ="TXTS_NOMBRE" id="TXTS_NOMBRE" size="25" maxlength="25" onChange="javascript:this.value=this.value.toUpperCase()"></td>
       </tr>
       <tr>
         <td>Primer Apellido</td>
         <td><input type="text" name ="TXTP_APELLIDO" id="TXTP_APELLIDO" size="25" maxlength="50" onChange="javascript:this.value=this.value.toUpperCase()">
     &nbsp;<font color='red'>
           <label title='Required'>*</label>
         </font></td>
       </tr>
       <tr>
         <td>Segundo Apellido</td>
         <td><input type="text" name ="TXTS_APELLIDO" id="TXTS_APELLIDO" size="25" maxlength="50" onChange="javascript:this.value=this.value.toUpperCase()"></td>
       </tr>
       <tr>
         <td>Sexo</td>
         <td><table>
             <tr>
               <?php COMBO_SEXO()?>
               <td>&nbsp;<font color=red>
                 <label title='Required'>*</label>
               </font></td>
             </tr>
         </table></td>
       </tr>
       <tr>
         <td >E-Mail</td>
         <td colspan="2"><input type="text"  name="TXTCORREO" id="TXTCORREO" size="77"></td>
       </tr>
       <tr>
         <td>Tel&eacute;fono Celular</td>
         <td><input type="text" name ="TXTTELEFONO" id="TXTTELEFONO" size="25" maxlength="25" onChange="javascript:this.value=this.value.toUpperCase()">
     &nbsp;<font size=1 color=gray>Ej. 0414-6556565</font></td>
       </tr>
       <tr>
         <td>Tel&eacute;fono </td>
         <td><input type="text" name ="TXTTELEFONO2" id="TXTTELEFONO2" size="25" maxlength="25" onChange="javascript:this.value=this.value.toUpperCase()">
     &nbsp;<font size=1 color=gray>Ej. 0261-7556565</font></td>
       </tr>
       <tr>
         <td >Direccion</td>
         <td colspan="2"><input type="text" onChange="javascript:this.value=this.value.toUpperCase()" name="TXTDIRECCION" id="TXTDIRECCION" size="77">
     &nbsp;<font color=red>
           <label title='Required'>*</label>
         </font></td>
       </tr>
       <?php 
				
				echo "<input type=hidden value='CMBSUCURSAL' id='CMBSUCURSAL' >";
			?>
       <tr>
         <td>Nombre de Usuario</td>
         <td><input type="text" name="TXTNOMBRE_USUARIO" id="TXTNOMBRE_USUARIO" readonly></td>
       </tr>
       <tr>
         <td>Tipo de Usuario</td>
         <td><?php
         	$SQL = "select * from t_tipos_usuarios";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBTIPOSUSUARIOS' id='CMBTIPOSUSUARIOS'  >"; 
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{ 
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"id_tipo_usuario").">".mysql_result($BUSCAR_LAPSOS,$i,"tipo_usuario")."</option>"; 
			}
			echo "</select>";
           	?>
     &nbsp;<font color=red>
           <label title='Required'>*</label>
         </font></td>
       </tr>
       <tr>
         <td>Accion</td>
         <td><select name='CMBESTATUS_USUARIOS' id='CMBESTATUS_USUARIOS' >
             <option value="0">--</option>
             <option value="BLOQUEADO">BLOQUEADO</option>
             <option value="DESBLOQUEADO">DESBLOQUEAR</option>
             <option value="REESTABLECER">REESTABLECER CONTRASE&Ntilde;A</option>
           </select>
         </td>
       </tr>
       <tr>
         <td colspan="2" align="right"><input type="hidden" name="ID_PERSONAL" id="ID_PERSONAL" >
             <input type="hidden" name="ID_USUARIO" id="ID_USUARIO" ></td>
       </tr>
       <tr>
         <td colspan="2" align="left"><input type="button" value="Limpiar" name="BOTON" id="reset" onClick="limpiar()">
             <input type="button" value="Guardar" name="SUBMIT" id="SUBMIT" onClick="usuarios('MODIFICAR')"></td>
       </tr>
     </table>
     <div id="resultado"></div>
  
   <BR>
 
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
