<?php 
	
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	
?>
<html >
<head>
<title>Registro de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>


<script language="javascript">
	var er_identificacion = /^[0-9]{6,11}$/;
        var er_can = /^[0-9]{1,3}$/;
	var er_texto = /^[a-zA-Z0-9\.+\_+\s+\,+\-+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+]{1,45}$/;
	var er_fecha = /^[0-9]{2}[\-]{1}[0-9]{2}[\-]{1}[0-9]{4}$/;
	var er_telefono = /^[0-9]{4}[\-]{1}[0-9]{7}$/;
        var er_hora =  /^[0-9]{2}[\:]{1}[0-9]{2}$/;

	


function BUSQUEDAPERSONAL()
{
			

	document.getElementById('nobodybusqueda').innerHTML="<div id='ventanabusqueda'  onmousedown=dragStart(event,'nobodybusqueda') style='visibility:visible'><table border=0 cellpadding=0 cellspacing=0 width=700  background='img/estructura/busqueda.png' valign=top ><tr valign=center ><td  colspan=2 width=697 align='right' valign=center>&nbsp;&nbsp;</td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr>" +
	"<tr valign=center><td width=350>&nbsp;&nbsp;Enter some information&nbsp;&nbsp;<input type=text name=TXTDATO id=TXTDATO onblur=this.value=this.value.toUpperCase()>&nbsp;<img src='img/iconos/buscar.png' title='Buscar' onClick='validarbusqueda()' style='cursor:pointer'></td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr>" +
	"<tr><td  colspan=2 ><table border=1 cellpadding=0 cellspacing=0 width=697 align=center><tr class='cabecera'><th align=center width=97>&nbsp;&nbsp;Identificacion</th><th align=left width=150>&nbsp;P. Apellido</th><th align=left width=150>&nbsp;S. Apellido</th><th align=left width=150>&nbsp;P. Nombre</th><th align=left width=150>&nbsp;S. Nombre</th></table></td></tr>" +
	"<tr height = 260  ><td colspan=2 valign=top><div id='busquedaarrojada'></div></td></tr>" +
	"<tr><td align=left><div id='CANTIDADLISTAS'>&nbsp;</div></td><td align= right ><input type=button value=Cerrar onClick=cerrarbusqueda()>&nbsp;&nbsp;</td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr></table></div>";
	document.getElementById('TXTDATO').focus();	
	
	
}
function cerrar()
{
	document.getElementById('nobody').innerHTML="";
}
function cerrarbusqueda()
{
	document.getElementById('ventanabusqueda').style.visibility='hidden';
}
function validarbusqueda()
{
	if(document.getElementById('TXTDATO').value=="")
	{
		alert("Debe especificar el dato");
		return false;
	}else{
	
			cargandodatospersonal(0);
			
		}
}
function cargandodatospersonal(NRO)
{
	divResultado = document.getElementById('busquedaarrojada');
	ajax=objetoAjax();
	ajax.open("POST", "ajax_reg_actividades.php",true);
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
	if(NRO!=0)
	{
		dato = document.getElementById('datoviejo').value
		ajax.send("DATO="+dato+"&ACCION=USUARIOS&NRO="+NRO+"");
	}else{
		ajax.send("DATO="+document.getElementById('TXTDATO').value+"&ACCION=USUARIOS"); 
	}
	ajax.onreadystatechange=function(){
	if (ajax.readyState==4) {
			//mostrar resultados en esta capa
			divResultado.innerHTML = ajax.responseText;
			var muestra = "";
			var cantidad = document.getElementById('cantidad').value;
			for(i=0;i<cantidad;i++)
			{
				if(i==0)
				{
					muestra="&nbsp;<label style='cursor:pointer' onClick=cargandodatospersonal("+(i+1)+")><b>"+(i+1)+"</b></label>";
				}else{
					muestra = muestra+"-<label style='cursor:pointer' onClick=cargandodatospersonal("+(i+1)+")><b>"+(i+1)+"</b></label>"; 
				}
			}
			document.getElementById('TXTDATO').value=document.getElementById('datoviejo').value;
			document.getElementById('CANTIDADLISTAS').innerHTML=muestra;
		}
	}
		 
}
function VOLCAR_PERSONAL(IDENTIDAD)
{
	document.getElementById('TXTIDENTIFICACION').value=IDENTIDAD;
	document.getElementById('buscarimgpersonal').onclick();
	cerrarbusqueda();
}


function objetoAjax()
{ 
	var xmlhttp=false; 
	try 
	{ 
		xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); 
	}
	catch(e)
	{ 
		try
		{ 
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
		} 
		catch(E) { xmlhttp=false; }
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') { xmlhttp=new XMLHttpRequest(); } 

	return xmlhttp; 
}


function limpiar()
{


	document.getElementById('dateArrival').value="";
	document.getElementById('ID_PERSONAL').value="";
	document.getElementById('HORAE').value="";
	document.getElementById('HORAS').value="";
	document.getElementById('CANTIDAD').value="";
	document.getElementById('CANTIDAD').value="";
	document.getElementById('TXTIDENTIFICACION').value="";
	document.getElementById('CMBGRADO').value="";
	document.getElementById('TXTP_NOMBRE').value="";
	if(document.getElementById('AVISO'))
	{document.getElementById('AVISO').value = '';
	}
	document.getElementById('SUBMIT').value =  "Guardar";
	document.getElementById('TXTIDENTIFICACION').focus()
    
}

function usuarios(ACCION)
{
	
	   if(ACCION=="BUSCAR")
	   {
		   var datos = new Array();
		   var TXTIDENTIFICACION = document.getElementById('TXTIDENTIFICACION').value;
		  
			  
		    if(!er_identificacion.test(TXTIDENTIFICACION))
			{
				alert("IDENTIFICACION ERRARDA");
				document.getElementById('TXTIDENTIFICACION').focus()
				return false;
			}
			mensaje("Buscando...");
		
			ajax=objetoAjax();
			ajax.open("POST", "ajax_reg_actividades.php",true);
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ID_PERSONAL="+ID_PERSONAL+"&TXTIDENTIFICACION="+encodeURIComponent(TXTIDENTIFICACION)+"&ACCION=BUSCAR"); 
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4)
				{
					
				
					document.getElementById('divalerta').innerHTML = ajax.responseText;
					document.getElementById('divalerta').style.display='none';
					document.getElementById('divalerta').style.height = "0px";
					if(document.getElementById('AVISO'))
					{
						if(document.getElementById('AVISO').value=="noencontrado")
						{
							alert("NO HUBO RESULTADO");
							limpiar();
							return;
						}else{
							datos = document.getElementById('AVISO').value.split("|");
							document.getElementById('TXTIDENTIFICACION').value=datos[0];
							document.getElementById('TXTP_NOMBRE').value=datos[1];
                                                        document.getElementById('ID_PERSONAL').value=datos[2];
							document.getElementById('procesando').innerHTML ="";
							for(i=0;i<datos.length;i++)
							{
								delete datos[i];
							}
						}
					}else{
						alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
						return false;

					}
				}
			}

		if(ACCION=="CARGAR")
		{
			document.getElementById('TXTIDENTIFICACION').focus()
			
		}
		
}



	   if(ACCION=="BUSCAR2")
	   {
		   var datos = new Array();
		   var CMBGRADO = document.getElementById('CMBGRADO').value;
		  
			  

			mensaje("Buscando...");
		
			ajax=objetoAjax();
			ajax.open("POST", "ajax_reg_actividades.php",true);
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ID_PERSONAL="+ID_PERSONAL+"&CMBGRADO="+encodeURIComponent(CMBGRADO)+"&ACCION=BUSCAR2"); 
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4)
				{
					
				
					document.getElementById('divalerta').innerHTML = ajax.responseText;
					document.getElementById('divalerta').style.display='none';
					document.getElementById('divalerta').style.height = "0px";
					if(document.getElementById('AVISO'))
					{
						if(document.getElementById('AVISO').value=="noencontrado")
						{
							alert("NO HUBO RESULTADO");
							limpiar();
							return;
						}else{
							datos = document.getElementById('AVISO').value.split("|");
							document.getElementById('CMBGRADO').value=datos[0];
							document.getElementById('CANTIDAD').value=datos[1];
                                                        document.getElementById('ID_PERSONAL').value=datos[2];
							document.getElementById('procesando').innerHTML ="";
							for(i=0;i<datos.length;i++)
							{
								delete datos[i];
							}
						}
					}else{
						alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
						return false;

					}
				}
			}

         }
		
		if(ACCION=="CARGAR")
		{
			document.getElementById('CMBGRADO').focus()
			
		}
		
}


function guardar()
{

    var ID_USUARIO='<?php echo $ID_USUARIO;?>';
    var FECHA=document.getElementById('dateArrival').value;
	var ID_PERSONAL=document.getElementById('TXTIDENTIFICACION').value;
    var HORAE=document.getElementById('HORAE').value;
    var HORAS=document.getElementById('HORAS').value;
    var ID_GRADO=document.getElementById('CMBGRADO').value;
    var CANTIDAD=document.getElementById('CANTIDAD').value;
    var ID_AREACOMP=document.getElementById('CMBAREACOMP').value;
    var TXTOBSERVACION = document.getElementById('TXTP_NOMBRE').value;



    if(!er_fecha.test(FECHA))
    {
            alert("ERROR EN LA FECHA");
            return false;
    }
    if(!er_hora.test(HORAE))
     {
           alert("ERROR EN LA HORA DE ENTRADA");
            return false;


     }
     if(!er_hora.test(HORAS))
     {
           alert("ERROR EN LA HORA DE SALIDA");
            return false;


     }

     if(!er_can.test(CANTIDAD))
     {
           alert("ERROR EN LA CANTIDAD DE ALUMNOS");
            return false;


     }
     mensaje("Guardando...");
    ajax=objetoAjax();
    ajax.open("POST", "ajax_reg_actividades.php",true);
    ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	//ajax.send("ID_PERSONAL="+encodeURIComponent(ID_PERSONAL)+"&FECHA="+encodeURIComponent(FECHA)+"&HORAE="+encodeURIComponent(HORAE)+"&HORAS="+encodeURIComponent(HORAS)+"&ID_USUARIO="+ID_USUARIO+"&ACCION=GUARDAR&ID_GRADO="+ID_GRADO+"&CANTIDAD="+CANTIDAD+"&ID_PROYECTO="+ID_PROYECTO+"&ID_AREACOMP="+ID_AREACOMP+"&ID_AREATECN="+ID_AREATECN+"&ID_HERRAMIENTA="+ID_HERRAMIENTA+"&TXTOBSERVACION="+encodeURIComponent(TXTOBSERVACION)+"&CMB1="+CMB1+"&CMB2="+CMB2+"&CMB3="+CMB3+"");
    ajax.send("ID_PERSONAL="+encodeURIComponent(ID_PERSONAL)+"&FECHA="+encodeURIComponent(FECHA)+"&HORAE="+encodeURIComponent(HORAE)+"&HORAS="+encodeURIComponent(HORAS)+"&ID_USUARIO="+ID_USUARIO+"&ACCION=GUARDAR&ID_GRADO="+ID_GRADO+"&CANTIDAD="+CANTIDAD+"&ID_AREACOMP="+ID_AREACOMP+"&TXTOBSERVACION="+encodeURIComponent(TXTOBSERVACION)+"");
       ajax.onreadystatechange=function() {
    if (ajax.readyState==4)
    {


            document.getElementById('divalerta').innerHTML = ajax.responseText;
           document.getElementById('divalerta').style.display='none';
            document.getElementById('divalerta').style.height = "0px";
            if(document.getElementById('AVISOMOFICIADO'))
            {

                    if(document.getElementById('AVISOMOFICIADO').value=="yaexiste")
                    {

                            alert("REGISTRO YA EXISTE");
                         return;


                    }

                    if(document.getElementById('AVISOMOFICIADO').value=="")
                    {

                            alert("OPERACION EXITOSA");
                            limpiar();
                            return;


                    }
                    if(document.getElementById('AVISOMOFICIADO').value=="error")
                    {
                            alert("NO SE PUEDE REALIZAR LA OPERACIÓN, se produjo un error en el proceso");
                            return false;
                    }
            }else{

                    alert("NO SE PUEDE REALIZAR LA OPERACIÓN, se produjo un error en el proceso");
                    return false;


            }

    }
    }

    
}
function Busqueda_Enter(key)
{

	if(key == 13) 
	{	
		usuarios('BUSCAR');
	}
}

</script>
<script type="text/javascript">
function actualizar(s) {
document.getElementById('CANTIDAD').value = s.options[s.selectedIndex].text;
}
</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
     <br>
     <table border="0" cellpadding="2" cellspacing="2" align="center" width="780" >    	
            <tr>
              <td width="204">Cedula Chofer (Identificaci&oacute;n)</td>
              <td width="562" colspan="3"><table cellpadding="0" cellspacing="0" border=0><tr><td><input type="text" name="TXTIDENTIFICACION" id=TXTIDENTIFICACION size="20" maxlength="10" onChange="javascript:this.value=this.value.toUpperCase()" onKeyUp="javascript:Busqueda_Enter(event.keyCode)">&nbsp;<font color=red><label title='Required'>*</label></font>&nbsp;</td><td><img  style="cursor:pointer" id="buscarimgpersonal" src="img/iconos/buscar.png" title="Buscar" onClick="usuarios('BUSCAR')" /></td><td width=200><div id="procesando"></div></td></tr></table></td></tr>
            <tr><td>Chofer</td>
            <td ><input type="text" name ="TXTP_NOMBRE" id="TXTP_NOMBRE" size="80" ><input type="hidden" id="ID_PERSONAL">&nbsp;<font color='red'><label title='Required'>*</label></font></td></tr>
            <tr><td >Fecha</td><td ><input type=text id='dateArrival' name =TXTFECHA  onFocus="popUpCalendar(document.getElementById('dateArrival'),document.getElementById('dateArrival'),'dd-mm-yyyy')" size="10">&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
            <tr><td>Hora Entrada</td><td><input type='text' name='HORAE' id='HORAE' size='5' maxlength='5'  >&nbsp;&nbsp;Hora Salida&nbsp;&nbsp;<input type='text' name='HORAS' id='HORAS' size='5' maxlength='5' >&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
            <tr>
              <td>Bus (unidad) </td>
              <td>			  
                <input type="text" name="CMBGRADO" id="CMBGRADO" size="8" maxlength="8" value="">
                <img  style="cursor:pointer" id="buscarimgpersonal2" src="img/iconos/buscar.png" title="Buscar2" onClick="usuarios('BUSCAR2')" /><font color=red><label title='Required'>*</label></font></td></tr>
             <tr>
               <td>Capacidad de Alumnos</td>
               <td><input type="text" name ="CANTIDAD" id="CANTIDAD" size="5" maxlength="3" value="">
               &nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
             <tr>
               <td>Destino</td>
               <td><?php
         	$SQL = "select * from t_areacomp order by areacomp";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBAREACOMP' id='CMBAREACOMP'  >";
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"areacomp").">".mysql_result($BUSCAR_LAPSOS,$i,"areacomp")."</option>";
			}
			echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>

            <tr><td >&nbsp;</td>
            <td ><input type=text id='TXTOBSERVACION' name =TXTOBSERVACION  size="80"></td></tr>


     </table>
      <table border="0" cellpadding="2" cellspacing="2" align="center" width="780" >

     
             <tr><td width="40%" align="left">&nbsp;</td></tr>
 <tr><td align="left"><input type="button" value="Limpiar" name="BOTON" id="reset" onClick="limpiar()"><input type="button" value="Guardar" name="SUBMIT" id="SUBMIT" onClick="guardar()"></td></tr>

</table>
       	<div id="resultado"></div>
  
   <BR>
 
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
