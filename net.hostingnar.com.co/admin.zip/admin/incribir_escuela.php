<meta charset="utf-8" />
<div style="margin:10px">
  <?php
if($_POST[editar]){
	require('ceoconexion.php');
	$TXTNICK = $_POST['nick'];
	$TXTAPELLIDO=$_POST['apellido'];
	$TXTNOMBRE=$_POST['nombre'];
	$TXTCI=$_POST['ci'];
	$TXTPROFESION=$_POST['profesion'];
	$TXTNACI=$_POST['naci'];
	$TXTTELEFONO=$_POST['telefono'];
	$CMBSEXO=$_POST['sexo'];
	$ESCUELA=$_POST['CMBESCUELA'];
	$EMAIL =$_POST['email'];
	$TXTPAIS=$_POST['pais'];
	$ESTADOS=$_POST['estado'];
	$CIUDAD=$_POST['ciudad'];
	$fecha = time();
	$ip = $_SERVER['REMOTE_ADDR'];
		//$sql = "UPDATE entradas SET articulo='$_POST[articulo]' where id='$_POST[id]'";
		
		$sql ="INSERT INTO alumnos_online (fecha,nick,email,pais,estado,ciudad,sexo,ip,ci,profesion,nombre,apellido,telefono,fechana,escuela) VALUES('".$fecha."', '".$TXTNICK."','".$EMAIL."','".$TXTPAIS."','".$ESTADOS."','".$CIUDAD."','".$CMBSEXO."','".$IP."','".$TXTCI."','".$TXTPROFESION."','".$TXTNOMBRE."','".$TXTAPELLIDO."','".$TXTTELEFONO."','".$TXTNACI."','".$ESCUELA."')";

		$result = mysql_query($sql);
		echo "Alumno Inscripto correctamente";
		//mail("$_POST[email]", "Cotizacion Aprobada", $firma, "From: cotizaciones <info@tupuntoempresarial.com>") or die ("Su mensaje no se envio.");
		
echo '
<button onclick="opener.location.href=\'..\/buscar.php?x=1\'; self.close();">Cerrar</button>

';
//Para devolver a la página donde se pidió la acción


} else { 
  
$id = $_GET['id'];
require('ceoconexion.php');
//mysql_connect("localhost","root");
//mysql_select_db("pedidos");  
$sql = "SELECT * FROM alumnos_online WHERE id='$id'";
$result=mysql_query($sql);
//mysql_query ("SET NAMES 'utf8'");
$row = mysql_fetch_assoc($result);

echo "<div > NICK: ".$row['nick']."</div><br>" ;
echo "<div > EMAIL: ".$row['email']."</div><br>" ;
echo "<div > CEDULA: ".$row['ci']."</div><br>" ;
echo "<div > NOMBRE: ".$row['nombre']."</div><br>" ;
echo "<div > APELLIDO: ".$row['apellido']."</div><br>" ;
	
echo "<form action=\"incribir_escuela.php\" method=\"post\" name=\"datos\" >";

echo "<select name='CMBESCUELA' id='CMBESCUELA' >";
               	$QUERY= mysql_query("select * from t_actividades2 order by id_actividad");
              	echo "<option value=-1></option>";
				mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"id_actividad").">".mysql_result($QUERY,$i,"escuela")."</option>";
				}
              	echo "</select> ";
					




echo " <input name='nick'  type='hidden' id='nick' value=". $row['nick']." >";
echo " <input name='email' type='hidden' id='email' value=". $row['email']." >";
echo " <input name='pais' type='hidden' id='pais' value=". $row['pais']." >";
echo " <input name='estado' type='hidden' id='estado' value=". $row['estado']." >";
echo " <input name='ciudad' type='hidden' id='ciudad' value=". $row['ciudad']." >";
echo " <input name='sexo' type='hidden' id='sexo' value=". $row['sexo']." >";
echo " <input name='ci' type='hidden' id='ci' value=". $row['ci']." >";
echo " <input name='profesion' type='hidden' id='profesion' value=". $row['profesion']." >";
echo " <input name='nombre' type='hidden' id='nombre' value=". $row['nombre']." >";
echo " <input name='apellido' type='hidden' id='apellido' value=". $row['apellido']." >";
echo " <input name='telefono' type='hidden' id='telefono' value=". $row['telefono']." >";
echo " <input name='naci' type='hidden' id='naci' value=". $row['fechana']." >";

	
?>
<?php echo "<input type='submit' name='editar' id='editar' value=' Editar Pedido '><input type='reset' name='button2' value=' Limpiar'>";
?>

<?php
  echo "</form>";
  
 


}

  ?>
</div>
