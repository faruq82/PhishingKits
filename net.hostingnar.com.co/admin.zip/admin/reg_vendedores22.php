<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
?>
<html>
<head>

<title>MERCADOLIBRE - FORMULARIO DE PAGO</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language='javascript' src="scriptbusqueda.js"></script>
<style type="text/css">
<!--
.Estilo17 {color: #333333}
.Estilo20 {color: #FF0000}
.Estilo23 {font-family: Verdana, Arial, Helvetica, sans-serif; color: #333333; }
body {
	background-color: #FFFFFF;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.Estilo24 {
	color: #000000}
.Estilo27 {
	color: #0000FF;
	font-size: 12px;
}
.Estilo28 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 18px;
}
.Estilo29 {font-size: 18px}
-->
</style>

<script language="JavaScript">
	var er_identificacion = /^[a-zA-Z0-9\.+\_+\s+\,+\-+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+]{1,45}$/;
	var er_texto = /^[a-zA-Z0-9\.+\_+\s+\,+\-+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+]{1,45}$/;
	var er_fecha = /^[0-9]{2}[\-]{1}[0-9]{2}[\-]{1}[0-9]{4}$/;
	var er_telefono = /^[0-9]{4}[\-]{1}[0-9]{7}$/;
	
function objetoAjax()
{ 
	var xmlhttp=false; 
	try 
	{ 
		xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); 
	}
	catch(e)
	{ 
		try
		{ 
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
		} 
		catch(E) { xmlhttp=false; }
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') { xmlhttp=new XMLHttpRequest(); } 

	return xmlhttp; 
}

function limpiar()
{


	document.getElementById('nombre').value="";
	document.getElementById('cii').value="";
	document.getElementById('email').value="";
	document.getElementById('bauche').value="";
	document.getElementById('monto').value="";
	document.getElementById('estatus').value="";
	document.getElementById('procesando').innerHTML ='';
	document.getElementById('resultado').innerHTML ='';
	if(document.getElementById('AVISO'))
	{document.getElementById('AVISO').value = '';
	}
	document.getElementById('nombre').focus()
}

function usuarios(ACCION)
{
	
	   if(ACCION=="BUSCAR")
	   {
		   var datos = new Array();
		   var seudonimo = document.getElementById('seudonimo').value;
		  
			  
		    if(!er_identificacion.test(seudonimo))
			{
				alert("IDENTIFICACION ERRARDA");
				document.getElementById('seudonimo').focus()
				return false;
			}
			mensaje("Buscando...");
		
			ajax=objetoAjax();
			ajax.open("POST", "ajax_reg_usuarios2.php",true);
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("seudonimo="+encodeURIComponent(seudonimo)+"&ACCION=BUSCAR"); 
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4)
				{
					
				
					document.getElementById('divalerta').innerHTML = ajax.responseText;
					document.getElementById('divalerta').style.display='none';
					document.getElementById('divalerta').style.height = "0px";
					if(document.getElementById('AVISO'))
					{
						if(document.getElementById('AVISO').value=="noencontrado")
						{
							alert("NO HUBO RESULTADO AGREGE LOS DATOS MANUALMENTE O REVISE QUE ESTE ESCRIBIENDO EL SEUDONIMO COMO APARECE EN MERCADOLIBRE");
							limpiar();

							return;
						}else{
							datos = document.getElementById('AVISO').value.split("|");
							document.getElementById('seudonimo').value=datos[0];
							document.getElementById('nombre').value=datos[1];
							document.getElementById('cii').value=datos[2];
							document.getElementById('email').value=datos[3];
							document.getElementById('bauche').value=datos[4];
							document.getElementById('estatus').value=datos[5];
						}
					}else{
						alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
						return false;

					}
				}
			}

         }
    }

</script>




<script language="JavaScript" type="text/JavaScript">
function validar_datos_p()
 { 
 		if(document.pago.seudonimo.value.length<2)
     { alert("Debe ingresar el USUARIO");
	   document.pago.seudonimo.focus();
	   return false;
	 }
	
	
			 
	 		if(document.pago.bauche.value=="")
     		{ alert("Debe ingresar el Numero de WHATSAPP");
      		document.pago.bauche.focus();
     		 return false;
			 }
	  	
     

		
	 
 }
 
 function Busqueda_Enter(key)
{

	if(key == 13) 
	{	
		usuarios('BUSCAR');
	}
}
</script>
</head>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td></td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td height="2"></td>
      </tr>
      <tr>
        <td height="2"><div align="center" class="tablaPrincipal Estilo24" ><br />
        <?php date_default_timezone_set('America/Caracas');  $fecha = time ();?>
        <br />
                Hora actual:
        <?php  

		  

		  function ve_date($d){

date_default_timezone_set("America/Caracas");

$t = time()+(1800);

return date($d,$t);

}

echo ve_date('h:i:s A');

		  

		  

		  

		  ?>
        </div></td>
      </tr>
      <tr>
        <td height="2"></td>
      </tr>
</table>
<form action='procesarin.php' method='post' enctype='multipart/form-data' name="pago" id="pago"   onSubmit="return validar_datos_p()">
               
			    <div style="display:none" ><strong>Codigo de Pedido: </strong>

                  <input name='cuponpedido' type="text" value="<?php $fecha = time ();

$codigo = "";
$longitud = 1;
for ($i=1; $i<=$longitud; $i++){
$letra = chr(rand(65,90));
$codigo .= $letra;
}
//Mostramos el serial
echo $codigo; echo date ( "his" , $fecha ); echo date ("njy");?>" size="15" readonly="readonly"/>
                  <strong>Hora:</strong>
                  <input name='Horacontrol' type="text" value="<?php  echo ve_date('h:i:s A'); ?>" size="10" readonly="readonly"   />
                  <strong>Fecha</strong>:
                  <input name='Fechacontrol' type="text" value="<?php echo date ( "j / n / Y" )?>" size="20" readonly="readonly"   />
  </div> 

<table border="0" cellpadding="2" cellspacing="2" align="center" width="780" >
  <tr>
    <td colspan="2" align="center">
      </td>
  </tr>
  <tr bgcolor="#5fa6d7">
    <td height="28" colspan="2" align="center" class="headline2">Datos del Vendedor</td>
  </tr>
  <tr>
    <td colspan="2">              

      </td>
  </tr>
  <tr>
    <td width="234"  class="title Estilo17"><div align="right" class="Estilo24">* Usuario:</div></td>
    <td width="533"><input tabIndex=1 size=30 name=seudonimo id=seudonimo onChange="javascript:this.value=this.value.toUpperCase()">
      <img  style="cursor:pointer" id="buscarimgpersonal" src="buscar.gif" title="Buscar" onClick="usuarios('BUSCAR')" /></td>
    </tr>
  <tr>
    <td  class="title Estilo17"><div align="right" class="Estilo24">* Contrase&ntilde;a:</div></td>
    <td><input name=password type="password" id=nombre  tabIndex=2 size=30></td>
    </tr>
  <tr>
    <td  class="title Estilo17"><div align="right" class="Estilo24">  Agregar Creditos:</div></td>
    <td ><input  tabIndex=5 size=30 name=email id=email></td>
  </tr>
  <tr>
    <td  class="title Estilo17"><div align="right" class="Estilo24">* Whatsapp:</div></td>
    <td "><input id=TXTTELEFONO  tabIndex=7 maxLength=30 size=30 name=TXTTELEFONO ></td>
  </tr>
  <tr>
    <td colspan="2" align="center" class="headline2 Estilo17"><div align="right"><span class="Estilo24"></span></div></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td align="center"><input style="FONT-WEIGHT: bold; FONT-SIZE: 10pt" name="pago" type="submit" id="pago" value=" AGREGAR " ></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td align="center">&nbsp;</td>
    </tr>
  <tr>
    <td colspan="2" align="center">&nbsp;</td>
  </tr>
</table>
</form>


<?php    
	piecera($PRIVILEGIO);
?>

</body>
</html>
