<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<html >
<head>
<title>Aplicacion web</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<script type="text/javascript">
</script>
<style type="text/css">
<!--

table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo3 {font-size: 18px; }

-->
</style>
</head>
<body>

<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table   border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td  valign="top">&nbsp;</td>
  </tr>
  <tr>
    <td>Bienvenidos a su Area de Estudio::::</td>
  </tr>
</table>
<?php




	//$resp = "SELECT entradas.id_personal,entradas.email,t_usuarios.id_tipo_usuario FROM  entradas inner join t_usuarios on entradas.id_personal = t_usuarios.id_personal  WHERE t_usuarios.id_usuario= ".$ID_USUARIO."";
    
	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");

	
		
		
		global $STYLECELDAS,$CABECERACELDAS;
		
		echo "<br><table width=780><tr><td><b>Escuela Inscrita Actualmente </b></td></tr><tr><td><hr align = center width=780></td></tr></table>";
              
		$QUERY_LISTAR_AULAS = mysql_query("select * from alumnos_online WHERE ci=".$cedula." ");
		if(mysql_num_rows($QUERY_LISTAR_AULAS)==0)
		{
                    echo "<br><table width=780><tr><td><b>No esta Inscrito en niguna Escuela.</b></td></tr></table>";
		}else{
				
				for($i=0;$i<mysql_num_rows($QUERY_LISTAR_AULAS);$i++)
				{	
					$escuela=mysql_result($QUERY_LISTAR_AULAS,$i,"escuela");
					$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad='$escuela' ");
					if (mysql_result($QUERY_LISTAR_AULAS,$i,"status") == 'Pagado')
						{
						
							echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera2'><td width=300><font color=white>NOMBRE DE LA ESCUELA</font></td></tr>";
							echo"<tr ".$STYLECELDAS." bgcolor=#DBFFB7>";
							echo "<td align=left>".mysql_result($escuelas,0,"escuela")."</td></tr>";
							
						}else{
							echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera2'><td width=300><font color=white>NOMBRE DE LA ESCUELA</font></td><td width=150><font color=white>PRECIO EN Bs.F</font></td> <td width=150> <font color=white>PRECIO EN DOLARES</font></td> <td width=118><font color=white>PAGAR ESCUELA</font></td></tr>";
							echo"<tr ".$STYLECELDAS." bgcolor=#FFB9B9>";
							echo "<td align=left>".mysql_result($escuelas,0,"escuela")."</td><td> Bs.F: <a href='pagosven.php'>".mysql_result($escuelas,0,"precio_bs")."</a></td><td width=150> $: <a href='pagosext.php'>".mysql_result($escuelas,0,"precio_usd")."</a></td><td  width=118 align = center><a href=tipopagos.php><img src=img/pagar.jpg border=0 onmouseover=this.style.cursor='pointer' title='Realizar pago'></a></td></tr>";

						}
			
				}
				echo "</table>";
		}
		echo "<br>";
?>
<table width="780" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td colspan="2">
	<table width="780" border="0" align="center" cellpadding="0" cellspacing="0" class="normal">
      <tr>
        <td><a href="instructivo.php"><img src="img/instructivo.jpg" width="207" height="155" border="0"></a></td>
        <td><a href="descargas2.php"><img src="img/evaluativos.jpg" width="207" height="155" border="0"></a></td>
        <td><a href="descargas.php"><img src="img/descargar.jpg" width="207" height="155" border="0"></a></td>
        </tr>
      <tr>
        <td ><div align="center"> <a href="instructivo.php" class="Estilo3">Instructivo</a></div></td>
        <td ><div align="center"><a href="descargas2.php" class="Estilo3">Evaluativos</a></div></td>
        <td ><div align="center"><a href="descargas.php" class="Estilo3">Descargar Audios y Guia</a> </div></td>
        </tr>
      <tr>
        <th scope="row">&nbsp;</th>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        </tr>
      <tr>
        <td><a href="horarios.php"><img src="img/horarios.jpg" width="207" height="155" border="0"></a></td>
        <td><a href="talle_online.php"><img src="img/online.jpg" width="207" height="155" border="0"></a></td>
        <td><a href="clasesonline.php"><img src="img/ayuda.jpg" width="207" height="155" border="0"></a></td>
        </tr>
      <tr>
        <td ><div align="center"><a href="horarios.php" class="Estilo3"> Horario</a></div></td>
        <td><div align="center"><a href="talle_online.php" class="Estilo3">Taller Online</a></div></td>
        <td ><div align="center"><a href="clasesonline.php" class="Estilo3">Clase Online</a> </div></td>
        </tr>
      <tr>
        <td >&nbsp;</td>
        <td>&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      <tr>
        <th scope="row"><a href="tutorias.php" target="_self"><img src="img/asesoriaonline.gif" width="207" height="155" border="0" ></a></th>
        <th scope="row">&nbsp;</th>
        <td ><a href="http://www.ministerioredil.org/tienda" target="_blank"><img src="img/libreria.jpg" width="207" height="155" border="0" ></a></td>
      </tr>
      <tr>
        <th  scope="row"><div align="center"><a href="tutorias.php" class="Estilo3">Asesoria al Estudiante</a></div></th>
        <th  scope="row">&nbsp;</th>
        <td ><div align="center"><a href="http://www.ministerioredil.org/tienda" target="_blank" class="Estilo3">Librería Online</a></div></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="169">&nbsp;</td>
    <td width="456">&nbsp;</td>
  </tr>
</table>
<br>
<br><br><br><br>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
