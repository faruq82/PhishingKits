<?php

	function AUDITORIA($INTRUCCION)
	{
		global $ID_USUARIO;
		$FECHA = date('20y-m-d');
		$FORMATO_HORA = getdate(time());
		$HORA= $FORMATO_HORA["hours"].":".$FORMATO_HORA["minutes"].":".$FORMATO_HORA["seconds"];
		$QUERYS=array();
		for($x=0;$x<count($INTRUCCION);$x++)
		{
			$INTRUCCION1= str_replace("'","|",$INTRUCCION[$x]);
			$QUERYS[]="CALL SP_T_AUDITORIAS(0,0,".$ID_USUARIO.",'".$INTRUCCION1."','".$FECHA."','".$HORA."')";
			
		}
		CORRER_TRANSACCION($QUERYS);
	}
	
		function CORRER_TRANSACCION($QUERY_ARRAY)
	{
		
	
		$QUERY_ERROR =  array();
		mysql_query("SET AUTOCOMMIT=0;
					START TRANSACTION;");
				
					for($i=0;$i<count($QUERY_ARRAY);$i++)
					{
							
						 	$QUERY= mysql_query($QUERY_ARRAY[$i]);
						 	if($QUERY=="")
							{
								$QUERY_ERROR[]=$QUERY_ARRAY[$i];
								
							}
							
					}
					if(count($QUERY_ERROR)==0)
					{
						mysql_query("COMMIT;");
						return O;
					
					}else{
					
						mysql_query("ROLLBACK;");
						for($i=0;$i<count($QUERY_ERROR);$i++)
						{
						
							global $ID_USUARIO;
							$FECHA = date('20y-m-d');
							$FORMATO_HORA = getdate(time());
							$HORA= $FORMATO_HORA["hours"].":".$FORMATO_HORA["minutes"].":".$FORMATO_HORA["seconds"];
							$INTRUCCION= str_replace("'","|",$QUERY_ERROR[$i]);
							mysql_query("CALL SP_T_EXCEPCIONES(0,0,".$ID_USUARIO.",'".$INTRUCCION."','','".$FECHA."','".$HORA."')");
							
						}
						unset($QUERY_ERROR);
						return 1;
					
					}
				
	
	
	}
	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
			
				alert('".$MSJ."');
				
			</script>
		";
	}
$cuponpedido = $_POST['cuponpedido'];
$Horacontrol =$_POST['Horacontrol'];
$Fechacontrol =$_POST['Fechacontrol'];
$nombre =$_POST['nombre'];
$seudonimo =$_POST['seudonimo'];
$creditos =$_POST['email'];
$articulo =$_POST['articulo'];
$operadora=$_POST['operadora'];
$medio=$_POST['medio'];
$monto=$_POST['monto'];
$banco=$_POST['banco'];
$bauche=$_POST['bauche'];
$estatus=$_POST['estatus'];
$envio=$_POST['envio'];
$dir1=$_POST['dir1'];
$estado=$_POST['estado'];
$ciudad=$_POST['ciudad'];
$tarjeta=$_POST['tarjeta'];
$sucuenta=$_POST['sucuenta'];
$obs=$_POST['obs'];
$emaill=$_POST['emaill'];
//$ci = $_POST["ci"] .' - '. $_POST["cii"];
$ci = $_POST["cii"];
$dia = $_POST["dia"] . ' / ' . $_POST["mes"] . ' / ' . $_POST["ano"];
$codcel = $_POST["codcel"] .' - '. $_POST["celular"];
$codfono = $_POST["codfono"] .' - ' .$_POST["fono"];

	$TXTIDENTIFICACION =  $_POST["seudonimo"];
	$TXTP_APELLIDO="--";
	$TXTS_APELLIDO="--";
	$TXTP_NOMBRE="--";
	$TXTS_NOMBRE="--";
	$TXTTELEFONO=$_POST['TXTTELEFONO'];
	$TXTTELEFONO2="0410-0000000";
	$TXTCORREO=" ";
	$CMBSEXO="--";
	$TXTDIRECCION="--";
	$ID_PERSONAL =$_POST['ID_PERSONAL'];
	$ID_USER =$_POST['ID_USER'];
	$ID_USUARIO =$_POST['ID_USUARIO'];
	$TIPO_USUARIO ="5";
	$ESTATUS_USUARIO ="0";
	$CMBSUCURSAL =" ";
	$password=$_POST['password'];



//////////////////////////////////////////////////////////////////////////////////////////
///// insertamos datos

    //   $q ="INSERT INTO entradas (cuponpedido,Horacontrol,Fechacontrol,nombrecompleto,seudonimo,ci,email,codfono,articulo,operadora,dia,medio,monto,banco,bauche,envio,dir1,estado,ciudad,codcel,tarjeta,sucuenta,obs,emaill)
//VALUES ('{$_POST['cuponpedido']}','{$_POST['Horacontrol']}','{$_POST['Fechacontrol']}','{$_POST['nombre']}','{$_POST['seudonimo']}','$ci','{$_POST['email']}','$codfono','{$_POST['articulo']}','{$_POST['operadora']}','$dia','{$_POST['medio']}','{$_POST['monto']}','{$_POST['banco']}','{$_POST['bauche']}','{$_POST['envio']}','{$_POST['dir1']}','{$_POST['estado']}','{$_POST['ciudad']}','$codcel','{$_POST['tarjeta']}','{$_POST['sucuenta']}','{$_POST['obs']}','{$_POST['emaill']}')";

//$tabla1= mysql_query($q, $link) or die ("problema con query");

	require("conexiondb.php");	


		$SQL=array();
		$SQL1= "SELECT * FROM  t_personal  WHERE cedula  ='".$TXTIDENTIFICACION."' ";
		$QUERY = mysql_query($SQL1);
		if(mysql_num_rows($QUERY)!=0)
		{
			 //echo "registro ya existe";
			$resp11 = "SELECT * FROM  t_usuarios   WHERE nombre_usuario  ='".$TXTIDENTIFICACION."'  "; 
			$datos11 = mysql_query($resp11) or die("no se pude realizar el sql");
			
			$usu=mysql_result($datos11,0,'nombre_usuario');
			$clav=mysql_result($datos11,0,'contrasena');
			
			
			 
			MESSAGE('USUARIO YA SE ENCUENTRA AGREGADO A LA BD.');
			echo"<script>location='reg_vendedores.php'</script>";
			return; 
		}else{
		
		//$SQL[] ="INSERT INTO t_personal (cedula,p_apellido,s_apellido,p_nombre,s_nombre,sexo,direccion,celular,telefono,correo ) VALUES('".$TXTIDENTIFICACION."', '".$TXTP_APELLIDO."','".$TXTS_APELLIDO."','".$TXTP_NOMBRE."','".$TXTS_NOMBRE."','".$CMBSEXO."','".$TXTDIRECCION."','".$TXTTELEFONO."','".$TXTTELEFONO2."','".$TXTCORREO."')";
		
		//$q ="INSERT INTO t_personal (cedula,p_apellido,s_apellido,p_nombre,s_nombre,sexo,direccion,celular,telefono,correo,cuponpedido,Horacontrol,Fechacontrol,nombrecompleto,seudonimo,ci,email,codfono,articulo,operadora,dia,medio,monto,banco,bauche,envio,dir1,estado,ciudad,codcel,tarjeta,sucuenta,obs,emaill) VALUES ('".$TXTIDENTIFICACION."', '".$TXTP_APELLIDO."','".$TXTS_APELLIDO."','".$TXTP_NOMBRE."','".$TXTS_NOMBRE."','".$CMBSEXO."','".$TXTDIRECCION."','".$TXTTELEFONO."','".$TXTTELEFONO2."','".$TXTCORREO."','".$cuponpedido."','".$Horacontrol."','".$Fechacontrol."','".$nombre."','".$seudonimo."','".$ci."','".$email."','".$codfono."','".$articulo."','".$operadora."','".$dia."','".$medio."','".$monto."','".$banco."','".$bauche."','".$envio."','".$dir1."','".$estado."','".$ciudad."','".$codcel."','".$tarjeta."','".$sucuenta."','".$obs."','".$emaill."')";
		
		$q ="INSERT INTO t_personal (cedula,p_apellido,s_apellido,p_nombre,s_nombre,sexo,direccion,celular,telefono,correo,seudonimo ) VALUES('".$TXTIDENTIFICACION."', '".$TXTP_APELLIDO."','".$TXTS_APELLIDO."','".$TXTP_NOMBRE."','".$TXTS_NOMBRE."','".$CMBSEXO."','".$TXTDIRECCION."','".$TXTTELEFONO."','".$TXTTELEFONO2."','".$TXTCORREO."','".$seudonimo."' )";
		//mysql_query("INSERT INTO t_personal (cedula,p_apellido,s_apellido,p_nombre,s_nombre,sexo,direccion,celular,telefono,correo,seudonimo ) VALUES('".$TXTIDENTIFICACION."', '".$TXTP_APELLIDO."','".$TXTS_APELLIDO."','".$TXTP_NOMBRE."','".$TXTS_NOMBRE."','".$CMBSEXO."','".$TXTDIRECCION."','".$TXTTELEFONO."','".$TXTTELEFONO2."','".$TXTCORREO."','".$seudonimo."' )")or die (mysql_error());

		$tabla1= mysql_query($q, $link) or  die(mysql_error());




		
		//if(CORRER_TRANSACCION($SQL)==1) 
		//{
				//echo "erro en sql";
				//unset($SQL);
				//return; 
		//}else{
					AUDITORIA($SQL);
					unset($SQL);
					$SQL1 = "select * from t_personal WHERE cedula ='".$TXTIDENTIFICACION."'";
					$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
					$ID_PERSONAL = mysql_result($SQL_CHK_EXISTENCIA,0,"id_personal");
					$SQL_TIPO_USUARIO=mysql_query("SELECT * FROM t_tipos_usuarios WHERE id_tipo_usuario = ".$TIPO_USUARIO."") or die("Error en el sql");
					if(mysql_num_rows($SQL_TIPO_USUARIO)!=0)
					{
					
						$SQL=array();
						$NOMBRE_USUARIO=$TXTIDENTIFICACION;
						//$CONTRASENA = md5('123456',false);
						$CONTRASENA =md5($password,false);
						
						if($ESTATUS_USUARIO=="BLOQUEADO")
						{
							$ESTATUS_USUARIO="BLOQUEADO";
						
						}
						if($ESTATUS_USUARIO=="0")
						{
							$ESTATUS_USUARIO="";
						
						}
						if($ESTATUS_USUARIO=="DESBLOQUEADO")
						{
							$ESTATUS_USUARIO="";
						
						}
						if($ESTATUS_USUARIO=="BLOQUEADO")
						{
							$ESTATUS_USUARIO="BLOQUEADO";
						
						}
						if($ESTATUS_USUARIO=="REESTABLECER")
						{
							$ESTATUS_USUARIO="";
							
						
						}
					}
						

						
						$qq ="INSERT INTO t_usuarios (id_tipo_usuario,id_personal,nombre_usuario,contrasena,estatus_usuario) VALUES(".$TIPO_USUARIO.",".$ID_PERSONAL.",'".$NOMBRE_USUARIO."','".$CONTRASENA."','".$ESTATUS_USUARIO."')";
						$tabla2= mysql_query($qq, $link) or  die(mysql_error());
					
								//LO REGISTRAMOS A VENDEDORES;
								$qq4 ="INSERT INTO usuarios (fecha,nick,email,contrasena,celular,creditos,id_personal) VALUES('".$fecha."', '".$TXTIDENTIFICACION."','".$EMAIL."','".$CONTRASENA."','".$TXTTELEFONO."','".$creditos."','".$ID_PERSONAL."')";
$tabla4= mysql_query($qq4, $link) or  die(mysql_error());


//echo "registro insertado <br>";

//$adm="http://www.loscursosvirtuales.net/pagos/administrador/index.php";
//$cabeceras = "From: ventas@loscursosvirtuales.net\r\nContent-type: text/html\r\n";
//$where_form_is="http".($HTTP_SERVER_VARS["HTTPS"]=="on"?"s":"")."://".$SERVER_NAME.strrev(strstr(strrev($PHP_SELF),"/"));



									//$asunto="Tienes un pedido nuevo de ".$_POST['seudonimo'];	
									//require("PHPMailer/class.phpmailer.php");	
									//$mail = new PHPMailer();
									////$mail->Mailer = "smtp";
									//$mail->Host = "mail.clientesoft.com.ve";
									//$mail->Port="25";
									//$mail->SMTPAuth = true;
									//$mail->Username = "info@clientesoft.com.ve";
									//$mail->Password = "19450237al";
									//$mail->CharSet = "UTF-8";
									//$mail->From = "info@clientesoft.com.ve";
									//$mail->FromName = "Ventas";
									//$mail->IsHTML(true);                                
									//$mail->Subject = $asunto;
									//$mail->Body    = $message;
									///$mail->AddAddress($cabeceras);
									//$mail->Send();	

//mail("ventas@loscursosvirtuales.net","Tienes un pedido nuevo de ".$_POST['seudonimo']."",$message,$cabeceras );
//mail($_POST['email'],"SE REGISTRO SU ORDEN, GRACIAS POR COMPRAR EN loscursosvirtuales.net",$confirmacion,$cabeceras );
//header("location: procesado.php");
echo"<script>location='reg_usuario.php'</script>";
}
?>