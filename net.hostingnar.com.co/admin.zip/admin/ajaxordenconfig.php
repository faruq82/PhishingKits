<script language='javascript' src="popcalendar.js"></script>
<script language='javascript' src="scriptbusqueda.js"></script>

<?php

	$STYLECELDAS = "onmouseover=this.style.backgroundColor='#f3f3f3' onmouseout=this.style.backgroundColor=''";
	$COLOR="#D8E3F5";
	$CABECERACELDAS="bgcolor=".$COLOR."";

	$CHECKBOX="checked";
	$db="nethn_admin";
	$DIR = mysql_connect("localhost","nethn_admin","admin32");
	mysql_select_db($db,$DIR)or die("Error al conectar a la base de datos seleccionada");
	mysql_query ("SET NAMES  'utf8'");
	echo "<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />";

	
		
	function REDIRIGIR($URL)
	{
		echo "
			<script language='javascript'>
				document.location='".$URL."';
			</script>
		";
	}	
	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
			
				alert('".$MSJ."');
				
			</script>
		";
	}
	
	function ASIG_VALOR($TIPO_INPUT,$LIMITE,$OBJETO,$VALOR)
	{
		//0 PARA CAJAS DE TEXTO
		//1 PARA COMBOBOX CON VALUE NUMERICO
		//2 PARA CHECKBOX
		//3 PARA COMBOBOX CON VALUE NUMERICO
		if($TIPO_INPUT==0)
		{
			echo "
				<script language='javascript'>
					if(!document.getElementById('".$OBJETO."'))
					{
						ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
					}else{
						document.getElementById('".$OBJETO."').value = '".$VALOR."';
					}
				</script>
			";
		}
		
		
		if($TIPO_INPUT==1)
		{
			echo "
				<script language='javascript'>
					i = 0;
					for(i=0;i<".$LIMITE.";i++)
					{
						if(!document.getElementById('".$OBJETO."'))
						{
							ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
						}else{
							document.getElementById('".$OBJETO."').selectedIndex = i;
							
							if(document.getElementById('".$OBJETO."').value==".$VALOR.")
							{
								document.getElementById('".$OBJETO."').selectedIndex = i;
								break;
							}
						}
					}
				</script>
			";
		}
		
		if($TIPO_INPUT==2)
		{
		
			if($VALOR=='SI') 
			{
			
				echo "
				
					<script language='javascript'>
						if(!document.getElementById('".$OBJETO."'))
						{
							ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
						}else{
							
								document.getElementById('".$OBJETO."').checked = true;
						}
					</script>
				";
			}else{
			
				echo "
					
						<script language='javascript'>
							if(!document.getElementById('".$OBJETO."'))
							{
								ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
							}else{
								
									document.getElementById('".$OBJETO."').checked = false;
							}
						</script>
					";
						
				
				}
			
		}
		 
		if($TIPO_INPUT==3)
		{
			echo "
				<script language='javascript'>
					i = 0;
					for(i=0;i<".$LIMITE.";i++)
					{
						if(!document.getElementById('".$OBJETO."'))
						{
							ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
						}else{
							document.getElementById('".$OBJETO."').selectedIndex = i;
							
							if(document.getElementById('".$OBJETO."').value=='".$VALOR."')
							{
								document.getElementById('".$OBJETO."').selectedIndex = i;
								break;
							}
						}
					}
				</script>
			";
		}
	}


	function MENU()
		
	{
				global $ID_USUARIO;
				$SQL = "select * from T_USUARIOS inner join T_TIPOS_USUARIOS  on T_USUARIOS.ID_TIPO_USUARIO=T_TIPOS_USUARIOS.ID_TIPO_USUARIO inner join T_TIPOS_USUARIOS_PRIVILEGIOS on T_TIPOS_USUARIOS.ID_TIPO_USUARIO=T_TIPOS_USUARIOS_PRIVILEGIOS.ID_TIPO_USUARIO inner join T_PRIVILEGIOS on  T_TIPOS_USUARIOS_PRIVILEGIOS.ID_PRIVILEGIO=T_PRIVILEGIOS.ID_PRIVILEGIO  where T_USUARIOS.ID_USUARIO=".$ID_USUARIO."  ORDER BY T_PRIVILEGIOS.NOMBRE";
				$QUERY = mysql_query($SQL)or die("no se pude realizar el sql");
				$menu = "<table border=0 cellpadding=0 cellspacing=0>
				<tr>
				<td><a href='inicio.php' onmouseout=MM_swapImgRestore(); onmouseover=MM_swapImage('inicio','','img/botones/_inicio.jpg',1);><img name='inicio' src='img/botones/inicio.jpg' border='0' id='inicio' alt='' /></a></td>
				
				</tr>
				
				";
			   	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
				$menu.="<tr><td><a href=".mysql_result($QUERY,$i,"URL")." onmouseout=MM_swapImgRestore(); onmouseover=MM_swapImage('menu_".$i."','','img/botones/".mysql_result($QUERY,$i,"IMAGEN2")."',1);><img name='menu_".$i."' src='img/botones/".mysql_result($QUERY,$i,"IMAGEN")."' border='0' id='menu_".$i."' alt='' /></a></td></tr>";
						
					//$menu.= "<tr><td><a href=".mysql_result($QUERY,$i,"URL")." onmouseout='MM_nbGroup('out')' onmouseover='MM_nbGroup('over','img/botones/".mysql_result($QUERY,$i,"IMAGEN")."','asig_vacaciones1.jpg','00000001_f4.jpg',1)' onclick='MM_nbGroup('down','navbar1','".mysql_result($QUERY,$i,"IMAGEN")."','asig_vacaciones1.jpg',1)'><img name='boton_".$i."' src=img/botones/".mysql_result($QUERY,$i,"IMAGEN")." border=0  id='boton_".$i."' alt='' /></a></td></tr>";
				}
				$menu .= "<tr>
		 		         <td><a href=login.php?XIAUEORPGDJD=WIUEHRIDKFL onmouseout=MM_swapImgRestore(); onmouseover=MM_swapImage('cerrar','','img/botones/_cerrar_sesion.jpg',1);><img name='cerrar' src='img/botones/cerrar_sesion.jpg' border='0' id='cerrar' alt='' /></a></td>
					     </tr>
						 </table>";
				echo $menu;
			

			
	}
	
	
	function AUDITORIA($INTRUCCION)
	{
		global $ID_USUARIO;
		$FECHA = date('20y-m-d');
		$FORMATO_HORA = getdate(time());
		$HORA= $FORMATO_HORA["hours"].":".$FORMATO_HORA["minutes"].":".$FORMATO_HORA["seconds"];
		$QUERYS=array();
		for($x=0;$x<count($INTRUCCION);$x++)
		{
			$INTRUCCION1= str_replace("'","|",$INTRUCCION[$x]);
			$QUERYS[]="CALL SP_T_AUDITORIAS(0,0,".$ID_USUARIO.",'".$INTRUCCION1."','".$FECHA."','".$HORA."')";
			
		}
		CORRER_TRANSACCION($QUERYS);
	}
	
	function CORRER_TRANSACCION($QUERY_ARRAY)
	{
		
	
		$QUERY_ERROR =  array();
		mysql_query("SET AUTOCOMMIT=0;
					START TRANSACTION;");
				
					for($i=0;$i<count($QUERY_ARRAY);$i++)
					{
							
						 	$QUERY= mysql_query($QUERY_ARRAY[$i]);
						 	if($QUERY=="")
							{
								$QUERY_ERROR[]=$QUERY_ARRAY[$i];
								
							}
							
					}
					if(count($QUERY_ERROR)==0)
					{
						mysql_query("COMMIT;");
						return O;
					
					}else{
					
						mysql_query("ROLLBACK;");
						for($i=0;$i<count($QUERY_ERROR);$i++)
						{
						
							global $ID_USUARIO;
							$FECHA = date('20y-m-d');
							$FORMATO_HORA = getdate(time());
							$HORA= $FORMATO_HORA["hours"].":".$FORMATO_HORA["minutes"].":".$FORMATO_HORA["seconds"];
							$INTRUCCION= str_replace("'","|",$QUERY_ERROR[$i]);
							mysql_query("CALL SP_T_EXCEPCIONES(0,0,".$ID_USUARIO.",'".$INTRUCCION."','','".$FECHA."','".$HORA."')");
							
						}
						unset($QUERY_ERROR);
						return 1;
					
					}
				
	
	
	}
	
	

	
	
	function COMBO_PARENTESCO()
	{
			
			echo "<td><select name='CMBPARENTESCO' id='CMBPARENTESCO' style='width:170px'>";
               	$QUERY= mysql_query("select * from T_PARENTESCOS  ");
				echo "<option value=-1></option>";	
                 mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_PARENTESCO").">".mysql_result($QUERY,$i,"PARENTESCO")."</option>";
				}
              	echo "</select></td> ";

	}
	
	function COMBO_MATERIAS()
	{
			
			echo "<td><select name='CMBMATERIAS' id='CMBMATERIAS'>";
               	$QUERY= mysql_query("select * from T_MATERIAS  ");
              	mysql_num_rows($QUERY);
              	echo "<option value=-1></option>";	
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_MATERIA").">".mysql_result($QUERY,$i,"MATERIA")." </option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_A_ESCOLAR()
	{
			
			echo "<td><select name='CMBAESCOLAR' id='CMBAESCOLAR'>";
               	$QUERY= mysql_query("select * from T_A_ESCOLAR  ORDER BY FECHA DESC");
				
              	mysql_num_rows($QUERY);
				
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					$AUX = mysql_result($QUERY,$i,"FECHA");
					$FECHA_ARRAY = explode("-",$AUX);
					$AUX = $FECHA_ARRAY[0];
					echo "<option value=".mysql_result($QUERY,$i,"ID_A_ESCOLAR").">".mysql_result($QUERY,$i,"DESCRIPCION")." </option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_A_ESCOLAR_ANO()
	{
			
			echo "<td><select name='CMBAESCOLAR_A' id='CMBAESCOLAR_A'>";
               	$QUERY= mysql_query("select * from T_A_ESCOLAR  ORDER BY FECHA DESC");
				
              	mysql_num_rows($QUERY);
				
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					$AUX = mysql_result($QUERY,$i,"FECHA");
					$FECHA_ARRAY = explode("-",$AUX);
					$AUX = $FECHA_ARRAY[0];
					echo "<option value=".$AUX.">".mysql_result($QUERY,$i,"DESCRIPCION")." </option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_AULAS()
	{
			
			echo "<td><select name='CMBAULAS' id='CMBAULAS'  style='width:80px'>";
               	$QUERY= mysql_query("select * from T_AULAS  ");
              	mysql_num_rows($QUERY);
				echo "<option value=-1></option>";
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_AULA").">".mysql_result($QUERY,$i,"AULA")." </option>";
				}
              	echo "</select></td> ";

	}
	
		function COMBO_ESTADOS()
	{
				
				echo "<select 'CMB_ESTADOS' id='CMBESTADOS' name='CMBESTADOS'  style='width:250px' onChange='cambiarciudad()' >";
               	$QUERY= mysql_query("select * from T_ESTADOS");
				echo "<option value=-1></option>";	
				for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_ESTADO").">".mysql_result($QUERY,$i,"ESTADO")."</option>";
				}
				echo "</select>";
				        	
	
	
	}
		function COMBO_PAIS()
	{
				
				echo "<select  id='CMBPAIS' name='CMBPAIS'  style='width:250px' onChange='cambiarestado()' >";
               	$QUERY= mysql_query("select * from T_PAIS");
			echo "<option value=-1></option>";	
                 	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_PAIS").">".mysql_result($QUERY,$i,"PAIS")."</option>";
				}
				echo "</select>";
				        	
	
	
	}
	function COMBO_ALTURA()
	{
			
			echo "<td><select name='CMBALTURA' id='CMBALTURA' >";
              	echo "<option value=-1></option>";
               	for($i=40;$i<221;$i++)
				{
					echo "<option value=".$i.">".$i."</option>";
				}
              	echo "</select></td> ";

	}
		function COMBO_PESO()
	{
			
			echo "<td><select name='CMBPESO' id='CMBPESO' >";
              	echo "<option value=-1></option>";
               	for($i=10;$i<201;$i++)
				{
					echo "<option value=".$i.">".$i."</option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_GRADOS()
	{
			
			echo "<td><select name='CMBGRADOS' id='CMBGRADOS'onChange='cargarseccion()' >";
               	$QUERY= mysql_query("select * from T_GRADOS order by ETAPA,GRADO,NIVEL");
              	echo "<option value=-1></option>";
				mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_GRADO").">".mysql_result($QUERY,$i,"GRADO")." ".mysql_result($QUERY,$i,"NIVEL")."</option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_CIUDADES()
	{
			
			echo "<select name='CMBCIUDADES' id='CMBCIUDADES' style='width:250px'>";
              	echo "<option value=-1></option>";	
                   	echo "</select>";

	}
	function COMBO_SEXO()
	{
			echo "<td><select name='CMBSEXO' id='CMBSEXO' style='width:170px'>";
			echo "<option value='M'>MASCULINO</option>";
			echo "<option value='F'>FEMENINO</option>";
			echo "</select></td> ";
	}
	
	function COMBO_ESTADOCIVIL()
	{
			echo "<td><select name='CMBCIVIL' id='CMBCIVIL' style='width:170px'>";
			echo "<option value='SO'>SOLTERO(A)</option>";
			echo "<option value='CA'>CASADO(A)</option>";
			echo "<option value='C0'>CONCUBINO(A)</option>";
			echo "<option value='DI'>DIVORCIADO(A)</option>";
			echo "<option value='VI'>VIUDO(A)</option>";
			echo "</select></td> ";
	}
	function COMBO_NIVEL()
	{
			echo "<td><select name='CMBNIVEL' id='CMBNIVEL'>";
			echo "<option value=PRIMARIA>PRIMARIA</option>";
			echo "<option value=BASICA>BASICA</option>";
			echo "<option value=DIVERSIFICADO>DIVERSIFICADO</option>";
			echo "</select></td> ";
	}
	function COMBO_SECCION()
	{
		echo "<select name='CMBSECCION' id='CMBSECCION'  style='width:100px' >"; 
		echo "<option value=-1></option>";
		foreach(range('A', 'Z') as $letras) 
		{ 
			echo "<option value=\"$letras\">$letras</option>"; 
		}
		echo "<option value='*'>*</option>";
		echo "</select>"; 
	} 
	function COMBO_PROFESION()
	{
		 echo "<select name='CMBPROFESION' id='CMBPROFESION' style='width:300px'>";
					$QUERY= mysql_query("select * from T_PROFESIONES  ");
					mysql_num_rows($QUERY);
					echo "<option value=-1></option>";	
					for($i=0;$i<mysql_num_rows($QUERY);$i++)
					{
						echo "<option value=".mysql_result($QUERY,$i,"ID_PROFESION").">".mysql_result($QUERY,$i,"PROFESION")." </option>";
					}
					echo "</select>";
	}
	
	function DESCONVERT_FECHAS($FECHA)
	{
		//DD-MM-YYYY
		$FECHA_ARRAY = explode("-",$FECHA);
		$AUX = $FECHA_ARRAY[2]."-".$FECHA_ARRAY[1]."-".$FECHA_ARRAY[0];
		return $AUX;
	}
	function COMBO_LAPSO()
	{
		$SQL = "select * from T_LAPSOS INNER JOIN T_LAPSOS_GLOBALES ON T_LAPSOS.ID_LAPSO_GLOBAL = T_LAPSOS_GLOBALES.ID_LAPSO_GLOBAL order by LAPSO_GLOBAL,LAPSO";
		$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
		echo "<select name='CMBLAPSO' id='CMBLAPSO' onChange=limpiar()>"; 
		echo "<option value='-1'>&nbsp;</option>";
		for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
		{ 
			echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"ID_LAPSO").">".mysql_result($BUSCAR_LAPSOS,$i,"LAPSO_GLOBAL")."-".mysql_result($BUSCAR_LAPSOS,$i,"LAPSO")."</option>"; 
		}
		echo "</select>"; 
	}
	function COMBO_ACTIVO()
	{
		echo "
			<td>
			<select name=CMBACTIVO ID=CMBACTIVO>
			<option value=SI>SI</option>
			<option value=NO>NO</option>
			</select>
			</td>
		";
	}
	
		function OBTENER_LITERAL($LITERAL)
	{
		$AUX="";
		$SQL = "select * from T_LITERALES";
		$BUSCAR_LITERALES = mysql_query($SQL)or die("no se pudo realizar la busqueda del literal");
		for($i=0;$i<mysql_num_rows($BUSCAR_LITERALES);$i++)
		{
			if(($LITERAL>=mysql_result($BUSCAR_LITERALES,$i,"INTERVALOINI")) and ($LITERAL<=mysql_result($BUSCAR_LITERALES,$i,"INTERVALOFIN")))
			{
				$AUX= mysql_result($BUSCAR_LITERALES,$i,"LITERAL");
			}	
		}
		return $AUX;
	}
	
	function COMBO_LITERALES()
	{
		$SQL = "select * from T_LITERALES order by INTERVALOFIN DESC";
		$BUSCAR_LITERALES = mysql_query($SQL)or die("no se pudo realizar la busqueda del literal");
		for($i=0;$i<mysql_num_rows($BUSCAR_LITERALES);$i++)
		echo "<select name='CMBLITERALES' id='CMBLITERALES'>"; 
		echo "<option value='-1'>&nbsp;</option>";
		for($i=0;$i<mysql_num_rows($BUSCAR_LITERALES);$i++)
		{ 
			echo "<option value=".mysql_result($BUSCAR_LITERALES,$i,"ID_LITERAL").">".mysql_result($BUSCAR_LITERALES,$i,"LITERAL")."</option>"; 
		}
		echo "</select>"; 
	}
	
	function COMBO_MESES()
	{
		$MES_ARRAY = array("ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO","JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE");
		echo "<select name='CMBMESES' id='CMBMESES'>";
		
		for($i=0;$i<12;$i++)
		{
			echo "<option value='".($i+1)."'>".$MES_ARRAY[$i]."</option>";
		}
		echo "</select>";
	}
	function CONVERT_FECHAS($FECHA)
	{
		//YYYY-MM-DD
		$FECHA_ARRAY = explode("-",$FECHA);
		$AUX = $FECHA_ARRAY[2]."-".$FECHA_ARRAY[1]."-".$FECHA_ARRAY[0];
		return $AUX;
	}

	function HABILITAR($OBJETO,$ACCION)
	{
		if($ACCION == 0)
		{
		echo "
			<script language='javascript'>
				document.getElementById('".$OBJETO."').disabled = true;
			</script>
		";
		}else{
		echo "
			<script language='javascript'>
				document.getElementById('".$OBJETO."').disabled = false;
			
			</script>
		";
		}
	}	
	
	function SABERDIA($DIA)
	{
		if($DIA==1)
		{ return "DOMINGO";}
		if($DIA==2)
		{ return "LUNES";}
		if($DIA==3)
		{ return "MARTES";}
		if($DIA==4)
		{ return "MIERCOLES";}
		if($DIA==5)
		{ return "JUEVES";}
		if($DIA==6)
		{ return "VIERNES";}
		if($DIA==7)
		{ return "SABADO";}
		
	}	
	function SABERMES($MES)
	{
		if($MES==1)
		{ return "ENERO";}
		if($MES==2)
		{ return "FEBRERO";}
		if($MES==3)
		{ return "MARZO";}
		if($MES==4)
		{ return "ABRIL";}
		if($MES==5)
		{ return "MAYO";}
		if($MES==6)
		{ return "JUNIO";}
		if($MES==7)
		{ return "JULIO";}
		if($MES==8)
		{ return "AGOSTO";}
		if($MES==9)
		{ return "SEPTIEMBRE";}
		if($MES==10)
		{ return "OCTUBRE";}
		if($MES==11)
		{ return "NOVIEMBRE";}
		if($MES==12)
		{ return "DICIEMBRE";}
	}
	function SABERQUINCENA($QUINCENA)
	{
		if($QUINCENA==1)
		{ return "1 ERA QUINCENA";}
		if($QUINCENA==2)
		{ return "2 DA QUINCENA";}
		
	}
	function CREAR_NOMBRE_USUARIO($NOMBRE_USUARIO)
	{
		$SQL= "SELECT * FROM T_USUARIOS WHERE NOMBRE_USUARIO = '".$NOMBRE_USUARIO."'";
		$QUERY = mysql_query($SQL);
		if(mysql_num_rows($QUERY)==0)
		{
			return $NOMBRE_USUARIO;
		}else{
			
			for($i=1;$i<100;$i++)
			{
				$NOMBRE_USUARIO_AUX = $NOMBRE_USUARIO."".$i;
				$SQL= "SELECT * FROM T_USUARIOS WHERE NOMBRE_USUARIO = '".$NOMBRE_USUARIO_AUX."'";
				$QUERY = mysql_query($SQL);
				if(mysql_num_rows($QUERY)==0)
				{
					$NOMBRE_USUARIO = $NOMBRE_USUARIO_AUX;
					$i=100;
				}
			}	
			
			return $NOMBRE_USUARIO;
			
		}
	}
	
	function SUMADIAS($fecha,$dia)
	{	
			list($year,$mon,$day) = explode('-',$fecha);	
			return date('Y-m-d',mktime(0,0,0,round($mon),round($day+$dia),round($year)));	
	}
	echo "<div id='nobodybusqueda'></div>"; 
	echo "<div id='nobody'></div>";
   
		
?>
