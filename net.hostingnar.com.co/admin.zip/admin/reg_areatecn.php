<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	$PROCESO = $_GET['PROCESO'];
	$TXTAULA = $_POST['TXTAULA'];
	$TXTDESCRIPCION = $_POST['TXTDESCRIPCION'];
	
	
	$BOTON = $_POST['BOTON'];
	
	if(!isset($BOTON))
	{	
		$BOTON = $_GET['BOTON'];
		if(!isset($BOTON))
		{
			$BOTON = "Guardar";
		}else{
			$BOTON = $BOTON;
			
		}
		
	}else{
		$BOTON = $BOTON;
		
	}
	
	function  LISTAR_AULAS()
	{
		global $STYLECELDAS,$CABECERACELDAS;
		echo "<br><table width=780><tr><td><b>Lista de Area Tecnol&oacute;gica.</b></td></tr><tr><td><hr align = center width=780></td></tr></table>";
              
	$QUERY_LISTAR_AULAS = mysql_query("select * from t_areatecn order by id_areatecn");
		if(mysql_num_rows($QUERY_LISTAR_AULAS)==0)
		{
                    echo "<br><table width=780><tr><td><b>No existen Area Tecnol&oacute;gica registrada.</b></td></tr></table>";

		}else{
				
				echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera'><th width=150>Area Tecnol&oacute;gica</th><th width=430>Descripci&oacute;n<th width=50>Act.</th><th width=50>Elim.</th></tr>";
				for($i=0;$i<mysql_num_rows($QUERY_LISTAR_AULAS);$i++)
				{	
					if($i%2==0)
					{
						echo"<tr ".$STYLECELDAS.">";
					}else{
						echo"<tr ".$STYLECELDAS." bgcolor=#F2F9F9>";
					}
						echo "<td align=left>".mysql_result($QUERY_LISTAR_AULAS,$i,"areatecn")."</td><td>".mysql_result($QUERY_LISTAR_AULAS,$i,"descripcion")."</td><td  align = center><a href=reg_areatecn.php?BOTON=Modificar&ID_AULA=".mysql_result($QUERY_LISTAR_AULAS,$i,"id_areatecn")."><img src=img/iconos/actualizar.png border=0 onmouseover=this.style.cursor='pointer' title='Modificar Registro'></a></td><td  align = center><a href=reg_areatecn.php?BOTON=Eliminar&ID_AULA=".mysql_result($QUERY_LISTAR_AULAS,$i,"id_areatecn")."><img src=img/iconos/eliminar_1.png border=0 onmouseover=this.style.cursor='pointer' title='Eliminar Registro'></a></td></tr>";

					
				}
					
			
			echo "</table>";
			
		}
		echo "<br>";

	}	
	
	
?>
<html >
<head>
<title>Tipos de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>
<script language="javascript">

var er_texto = /^[0-9]{4}$/;

	function validar()
	{
		_TXTAULA= document.getElementById('TXTAULA').value;
		if(!er_texto.test(_TXTAULA))
		{
			ALERT("-Error en campo area tecnica");
			return false;
		}
		
	}	
	
		function limpiar()
		{
			document.location = "reg_areatecn.php";
		
		}
</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
	
  <BR>
    	

    	
    	<form action ="<?php echo $URL ?>" method="post" onSubmit="return validar()">
    	<table align="center" border="0"  cellpadding="2" cellspacing="2" width="780">
        	
         
            <tr><td>Area Tecnol&oacute;gica</td><td><input type="text" name ="TXTAULA" id="TXTAULA" size="4" maxlength="4" >&nbsp;<font color='red'><label title='Requerido'>*</label></font></td></tr>
			    <tr><td>Descripci&oacute;n</td><td><input type="text" name ="TXTDESCRIPCION" id="TXTDESCRIPCION" size="80" maxlength="50" ></td></tr>
				<tr><td>&nbsp;</td></tr>
                 <tr><td colspan="2" align="left"><input type="reset" value="Limpiar" onClick="limpiar()"><input type="submit" value="<?php echo $BOTON?>" name="BOTON" id="BOTON"><input type="hidden" name ="ACCION" id="ACCION"><input type="hidden" name ="ID_AULA" id="ID_AULA" ></td></tr>
        </table>
        </form>
              
              
        <?php
		$BOTON = $_POST['BOTON'];
		if(!isset($BOTON))
		{	
			$BOTON = $_GET['BOTON'];
			if(!isset($BOTON))
			{
				$BOTON = "";
			}else{
				$BOTON = $BOTON;
				
			}
			
		}else{
			$BOTON = $BOTON;
			
		}
		$ACCION = $_POST['ACCION'];
		if($ACCION==1)
		{
			$SQL=array();
			$ID_AULA= $_POST['ID_AULA'];
			$SQL[] = "UPDATE t_areatecn  SET areatecn = '".$TXTAULA."', descripcion ='".$TXTDESCRIPCION."' WHERE id_areatecn = ".$ID_AULA."";
				
			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
			unset($SQL);
			
			ASIG_VALOR(0,0,"ACCION","");
			ASIG_VALOR(0,0,"ID_AULA","");
			echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
		
			$BOTON = "";
			
		}
		if($ACCION==2)
		{
			$ID_AULA = $_POST['ID_AULA'];
				
			$SQL=array();
			$SQL[] = "DELETE FROM t_areatecn WHERE id_areatecn = ".$ID_AULA."";
				
			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
			unset($SQL);
			ASIG_VALOR(0,0,"ACCION","");
			ASIG_VALOR(0,0,"ID_AULA","");
			
			echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			$BOTON = "";
		}
		if($BOTON=="Eliminar")
		{
			$ID_AULA = $_GET['ID_AULA'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from t_areatecn where id_areatecn =".$ID_AULA."");
			ASIG_VALOR(0,0,"TXTAULA",mysql_result($SQL_CHK_EXISTENCIA,0,"areatecn"));
			ASIG_VALOR(0,0,"TXTDESCRIPCION",mysql_result($SQL_CHK_EXISTENCIA,0,"descripcion"));
			ASIG_VALOR(0,0,"ID_AULA",mysql_result($SQL_CHK_EXISTENCIA,0,"id_areatecn"));
			ASIG_VALOR(0,0,"ACCION","2");
			
			
		}
		if($BOTON=="Modificar")
		{	
			
			
			
			$ID_AULA = $_GET['ID_AULA'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from t_areatecn where id_areatecn =".$ID_AULA."");
			ASIG_VALOR(0,0,"TXTAULA",mysql_result($SQL_CHK_EXISTENCIA,0,"areatecn"));
			ASIG_VALOR(0,0,"TXTDESCRIPCION",mysql_result($SQL_CHK_EXISTENCIA,0,"descripcion"));
			ASIG_VALOR(0,0,"ID_AULA",mysql_result($SQL_CHK_EXISTENCIA,0,"id_areatecn"));
			ASIG_VALOR(0,0,"ACCION","1");
		
		}
		if($BOTON=="Guardar")
		{
			 
		
			$SQL_CHK_EXISTENCIA = mysql_query("select * from t_areatecn where areatecn = '$TXTAULA' ");
		
			if(mysql_num_rows($SQL_CHK_EXISTENCIA)==0)
			{
				$SQL=array();
				$SQL[] = "INSERT INTO t_areatecn (areatecn,descripcion) VALUES ('".$TXTAULA."','".$TXTDESCRIPCION."');";
					
			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
			unset($SQL);
				echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			}else{
				MESSAGE('HUBO UN ERROR DURANTE LA OPERACION. EL REGISTRO YA SE ENCUENTRA ALMACENADO');
			}
			
			
		}
?> 

 <?php LISTAR_AULAS(); 
		piecera($PRIVILEGIO);
?>
</body>
</html>