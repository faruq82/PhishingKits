<?php

	session_name('MIORDEN');
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');

	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");

	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url))
		{
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");


		}

	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');

	}


?>
<html >
<head>
<title>Reportes</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/> 
</head>
<script language="javascript">




function objetoAjax()
{
	var xmlhttp=false;
	try
	{
		xmlhttp=new ActiveXObject("Msxml2.XMLHTTP");
	}
	catch(e)
	{
		try
		{
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		catch(E) { xmlhttp=false; }
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') { xmlhttp=new XMLHttpRequest(); }

	return xmlhttp;
}

function abrirVentana(p_url, p_nombre)
{

	 p_ancho = 1024;
	 p_alto = 800;
	 p_resizable = 'si';
	 p_scroll = 'si';
	 p_directories = 'si';
	 p_location = 'si';
	 p_menubar = 'si';
	 p_status = 'si'
	 p_titlebar = 'si'
	 p_toobar = 'si';

	ventana = window.open(p_url, p_nombre, " width = " + p_ancho + " height = " + p_alto + " resizable = " + p_resizable +
	" Scrollbars = " + p_scroll + " Directories = " + p_directories + " Location = " + p_location + " Menubar = " + p_menubar +
	" Status = " + p_status + " Titlebar = " + p_titlebar + " Toolbar = " + p_toobar) ;

}


var er_texto = /^[0-9]{6,10}$/;

function generar_diario()
{
   	if(document.getElementById('dateArrival').value=="")
	{
		alert("Debes ingresar la fecha inicial");
		return false;
	}

	abrirVentana("reporte_asistencia_diaria.php?FECHA="+document.getElementById('dateArrival').value+"","");


}



function generar_mensual()
{


	abrirVentana("reporte_asistencia_mensual.php?ANO="+document.getElementById('ano').value+"&CMBMESES="+document.getElementById('CMBMESES').value+"","");


}

function generar_empleados()
{
	
	abrirVentana("reporte_docentes.php","");
	
}

function generar_empleados2()
{
	
	abrirVentana("reporte_rutas.php","");
	
}

function buscar_reporte()
{
	var OPCION= document.getElementById('CMBREPORTES').value;
	switch (OPCION)
	{ 
		case "0":
					
			limpiar();	
		break; 
		case "1":
						
			empleados2();
		break; 
		case "2": 
			mensual();
		break; 
		case "3": 
			empleados();
		break; 
	}


}

function empleados()
{

                        ajax=objetoAjax();
			ajax.open("POST", "ajax_reportes.php",true);
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4) {
					document.getElementById('divresultado50').innerHTML = ajax.responseText;
				}
			}
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ACCION=1"); 
		 
}

function empleados2()
{

                        ajax=objetoAjax();
			ajax.open("POST", "ajax_reportes.php",true);
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4) {
					document.getElementById('divresultado50').innerHTML = ajax.responseText;
				}
			}
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ACCION=1"); 
		 
}
function diario()
{

			ajax=objetoAjax();
		
			ajax.open("POST", "ajax_reportes.php",true);
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4) {
					document.getElementById('divresultado50').innerHTML = ajax.responseText;
				}
			}
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ACCION=0"); 
		 
 

}
function mensual()
{


                        ajax=objetoAjax();
			ajax.open("POST", "ajax_reportes.php",true);
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4) {
					document.getElementById('divresultado50').innerHTML = ajax.responseText;
				}
			}
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ACCION=2");

}

function limpiar()
{

	borrar='&nbsp;';
	document.getElementById('divresultado50').innerHTML=borrar;

	

}
function Busqueda_Enter(key)
{

	if(key == 13) 
	{	
		mensaje();
	}
}


</script>
<body>

<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);
?>
     <br>
    
          <table border="0" width="780" align= center>
      

            
           
                <tr><td><select name='CMBREPORTES' id='CMBREPORTES' >
               
			
              	<option value=0 >Seleccione una opci&oacute;n</option>
			<option value=1  title="Lista de Rutas">Registro </option>
			<option value=3 title="Lista de Buses">Listado</option>
	
			
              	</select>&nbsp;&nbsp;Seleccione la opci&oacute;n que desea consultar.</td><tr>
			<tr><td>&nbsp;</td></tr>
			<tr><td><div id="divresultado50">&nbsp;</div></td></tr>
			
	             
	</table>
	 

   <BR>

<?php
	piecera($PRIVILEGIO);
?>
</body>
</html>

