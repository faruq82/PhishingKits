<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CECEIP ::: Formulario de Inscripcion alumnos</title>
<meta name="keywords" content="morning, theme, free templates, web design, templatemo, CSS, HTML" />
<meta name="description" content="Morning Theme, free CSS template by templatemo.com" />
<link href="../css/templatemo_style.css" rel="stylesheet" type="text/css" />
	<link type="text/css" href="admin.css" rel="stylesheet" />
	<link type="text/css" href="jquery.cleditor.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="../css/ddsmoothmenu.css" />
<script type="text/javascript" src="../scripts/jquery.min.js"></script>
<script type="text/javascript" src="../scripts/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>
	<script language="javascript"> 
function verifica(){ 
 
    if(document.form.nombre.value.length < 2){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe ingresar el Nombre"); //mensaje a la pantalla
 
        document.form.nombre.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }
 
    if(document.form.nick.value.length < 6){ 
 
        alert("Debe ingresar el Numero de Cedula"); 
 
        document.form.nick.focus(); 
 
        return false;
 
    }
	
	
 
    if(document.form.email.value.length < 1){ 
 
        alert("Debe ingresar el E-Mail"); 
 
        document.form.email.focus(); 
 
       return false;
    }
 
   	  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form.email.value))
      {}
      else 
     { alert("La dirección de email " + document.form.email.value + " es incorrecta.");
       document.form.email.focus();
	   return false;
     } 
 
    if(document.form.pais.value.length < 10){ 
 
        alert("Debe ingresar un número de teléfono"); 
 
        document.form.pais.focus(); 
 
        return false; 
 
    }

 
         // //document.form.submit(); //enviamos formulario    
 
} 
 
</script> 
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "templatemo_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<link rel="stylesheet" type="text/css" href="../css/styles.css" />
<script language="javascript" type="text/javascript" src="../scripts/mootools-1.2.1-core.js"></script>
<script language="javascript" type="text/javascript" src="../scripts/mootools-1.2-more.js"></script>
<script language="javascript" type="text/javascript" src="../scripts/slideitmoo-1.1.js"></script>
<script language="javascript" type="text/javascript">
	window.addEvents({
		'domready': function(){
			/* thumbnails example , div containers */
			new SlideItMoo({
						overallContainer: 'SlideItMoo_outer',
						elementScrolled: 'SlideItMoo_inner',
						thumbsContainer: 'SlideItMoo_items',		
						itemsVisible: 3,
						elemsSlide: 2,
						duration: 200,
						itemsSelector: '.SlideItMoo_element',
						itemWidth: 280,
						showControls:1});
		},
		
	});
</script>
    
<style type="text/css">
alinear {
	font-size: 12px;
}
alinearr {
	text-align: left;
}
#alinear {
	text-align: left;
}
ROJO {
	color: #F00;
}
.Estilo73 {font-size: 14px}
.Estilo13 {color: #000000}
.Estilo14 {color: #990000}
.Estilo75 {
	color: #000066;
	font-weight: bold;
	font-size: 9px;
}
.Estilo76 {color: #990000; font-weight: bold; font-size: 9px; }
.Estilo77 {
	color: #FFFFFF;
	font-weight: bold;
}
</style>
</head>
<body id="home">

<div id="templatemo_outer_wrapper">
	<div id="templatemo_wrapper">
    
    	<div id="templatemo_header">
    	  <div id="templatemo_menu" class="ddsmoothmenu">
              <ul>
                   <li><a href="../video/index.html" class="selected"><span></span>Home</a></li>
                    <li><a href="../video/escuela.html" target="_self"><span></span>Escuelas</a>
                      	<ul>
                        	<li>
                      <a href="../video/escuelainterce.html" target="_self">Escuelas de I.P</a></li>
                            <li><a href="../video/escuelaprofeta.html" target="_self">Escuelas de Profeta</a></li>
                            <li><a href="../video/escuelasalmista.html" target="_self">Escuelas de Salmistas</a></li>
                            <li><a href="../video/escuelacultura.html" target="_self">Escuelas de Cultura y Gobierno</a></li>
                            <li><a href="../video/escuela.html"></a></li>
                            <li><a href="../video/escuela.html"></a></li>
                            <li><a href="../video/escuela.html"></a></li>
                        </ul>
                    </li>
                    <li><a href=""><span></span>Descargas</a>
                      	<ul>
                            <li><a href="../video/palabraprofetica.html">Palabras Profeticas</a></li>
                            <li><a href="../video/reportaje.html">Reportajes</a></li>
                            <li><a href="../video/predicas.html">Enseñanzas</a></li>      
                               <li><a href="../video/vozprofetica.html">Programa radiales</a></li>
                            <li><a href="../video/convocatoria.html">Convocatoria</a></li>
                            <li><a href="../video/contacto.php">Pedidos</a></li>
                        </ul>
                    </li>
                  	<li><a href="../video/agenda.html"><span></span>Agenda</a></li>
                    <li><a href="../video/contacto.php"><span></span>Contacto</a></li>
            </ul>
                <br style="clear: left" />
          </div> <!-- end of templatemo_menu -->
            <div class="cleaner"></div>
            
		</div> <!-- end of templatemo header -->
        
        <div id="intro_text"></div>
        
        <div id="templatemo_middle">
        	<div id="SlideItMoo_outer">	
                <div id="SlideItMoo_inner">			
                    <div id="SlideItMoo_items">
                        <div class="SlideItMoo_element"> <a href="../agenda.html" target="_self"><img src="../images/gallery/011.jpg" alt="agenda redil" /></a>
                        </div>	
                        <div class="SlideItMoo_element"> <a href="../ministerioamigos.html" target="_self"><img src="../images/gallery/022.jpg" alt="product 2" /></a>
                        </div>
                        <div class="SlideItMoo_element"> <a href="../libre.html" target="_self"><img src="../images/gallery/libre.jpg" alt="libreria redil" /></a>
                        </div>
                        <div class="SlideItMoo_element"> <a href="http://ministerioredil.org/galeria/index.php" target="_blank"><img src="../images/gallery/gale.jpg" alt="galeria redil" /></a>
                        </div>
                        <div class="SlideItMoo_element"> <a href="../donacion.html"><img src="../images/gallery/dona.jpg" alt="donaciones redil" /></a>
                        </div>
                        <div class="SlideItMoo_element">
                                <a href="http://www.templatemo.com/page/6" target="_parent">
                                <img src="../images/gallery/066.jpg" alt="suscribete redil" /></a>
                        </div>
                    </div>			
                </div>
            </div>		   
        </div> <!-- end of templatemo_middle -->
       

			
        	    <table width="786" height="159" border="0" align="right">
        	      <tr>
        	        <td height="22" colspan="2" valign="top"></td>
       	          </tr>
        	      <tr>
        	        <td width="32" valign="top"><p class="Estilo73">&nbsp;</p>
       	            </td>
        	        <td width="744" valign="top">
		<form action ="act_alumnos_pre_ven.php" method="post" onSubmit="return validar()" >
        <table align="center" border="0" width="454" cellspacing=0 cellpadding=0>
            <tr><td width="631" height="60"><h3>Buscar Alumno</h3></td></tr>
        <tr><td>
            <table align="center" border="0" width="450" cellspacing=1 cellpadding=1>
            <tr><td align=left></td></tr><tr>
            <td height="29" align=left>Numero de Cedula: 
              <input type="text" name ="TXTCEDULA" id="TXTCEDULA" size="25" maxlength="25" onChange="javascript:this.value=this.value.toUpperCase()" style='text-align:left' value="" u></td></tr>
            <tr>
              <td  align="left">&nbsp;</td>
            </tr>
            <tr><td  align="left"><div align="center">
                    <input type="reset" value="Limpiar" >
                    <input type="submit" value=" Buscar " name="buscar" id="BOTON">
            </div></td></tr>
            </table>
         </td><td width="109">&nbsp;
       		  </td>
        </tr></table>
            
    </form>
    </td>
        	      </tr>
        	      <tr>
        	        <td valign="top">&nbsp;</td>
        	        <td valign="top">&nbsp;</td>
      	        </tr>
        	      <tr>
        	        <td valign="top">&nbsp;</td>
        	        <td valign="top">&nbsp;</td>
      	        </tr>
      </table>

    
    </div> <!-- end of templatemo_wrapper -->
</div> <!-- end of templatemo_outer_wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">
        Copyright © 2014 cecip online
          <div class="cleaner"></div>
    </div>
</div>
</body>
</html>