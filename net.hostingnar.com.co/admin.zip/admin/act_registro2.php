<?php



//include("ceoconexion.php");
include("ajaxordenconfig.php");

	$TXTNICK = $_POST['ci'];
	$TXTCONTRA = $_POST['ci'];
	$TXTAPELLIDO=$_POST['apellido'];
	$TXTNOMBRE=$_POST['nombre'];
	$TXTCI=$_POST['ci'];
	$TXTPROFESION=$_POST['profesion'];
	$TXTNACI=$_POST['naci'];
	$EDAD=$_POST['edad'];
	$TXTTELEFONO=$_POST['telefono'];
	$ID_PERSONAL =$_POST['ID_PERSONAL'];
	$ID_USUARIO =$_POST['ID_USUARIO'];
	$CMBSEXO=$_POST['sexo'];
	$ESCUELA=$_POST['CMBESCUELA'];
	$TXTPAIS=$_POST['CMBPAIS'];
	$TIPO_USUARIO ="2";
	$ESTATUS_USUARIO ="";
	$EMAIL =$_POST['email'];
	$TXTDIRECCION =$_POST['direccion'];
	$congregacion =$_POST['congregacion'];
	$direcongre =$_POST['direcongre'];
	$nommini =$_POST['nommini'];
	$telfmini =$_POST['telfmini'];
	$fecha = time();
	$ip = $_SERVER['REMOTE_ADDR'];

		

//$SQL4[] ="INSERT INTO alumnos_pre (fecha,contrasena,email,pais,sexo,direccion,ip,ci,profesion,nombre,apellido,telefono,edad,congregacion,direcongre,nomministro,telministro,fechana,escuela) VALUES('".$fecha."', '".$TXTNICK."','".$EMAIL."','".$TXTPAIS."','".$CMBSEXO."','".$TXTDIRECCION."','".$IP."','".$TXTCI."','".$TXTPROFESION."','".$TXTNOMBRE."','".$TXTAPELLIDO."','".$TXTTELEFONO."','".$EDAD."','".$congregacion."','".$nommini."','".$direcongre."','".$telfmini."','".$TXTNACI."','".$ESCUELA."')";
			$SQL[] = "UPDATE alumnos_pre SET contrasena= '".$TXTCONTRA."', email='".$EMAIL."', pais='".$TXTPAIS."', sexo='".$CMBSEXO."', direccion='".$TXTDIRECCION."', ip='".$ip."', nombre='".$TXTNOMBRE."', apellido='".$TXTAPELLIDO."', telefono='".$TXTTELEFONO."', edad='".$EDAD."', congregacion ='".$congregacion."', direcongre ='".$direcongre."', fechana='".$TXTNACI."', nomministro ='".$nommini."', telfmini ='".$telfmini."' WHERE ci= ".$TXTCI."";

			if(CORRER_TRANSACCION($SQL)==1) 
			{
					MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
			}else{
					
					MESSAGE('OPERACION REALIZADA CON EXITO.');
			}
		echo '<script>location="buscar_alumnos_ven.php" </script>';
		
							
			

?>
