<link href="estilo.css" rel="stylesheet" type="text/css">
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="header"  >
  <tr>
    <td width="89%" align="left" valign="top" style="border:none"><p><strong>Administrador de Cotizaciones</strong><br />

    <div>
      <table width="290" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="290"><?php 
 
require('conexiondb.php');
 

date_default_timezone_set('America/Caracas');  $fecha = time ();
$cd = date ( "j / n / Y", $fecha) ; 

$query = "SELECT COUNT(estatus) FROM cotizacion WHERE estatus =''"; 
$result = mysql_query($query) or die(mysql_error());
while($row = mysql_fetch_array($result)){
	echo "<span class='nuevo'>  Hay ".$row['COUNT(estatus)']." Cotizaciones sin Aprobar </span>";
	echo "<br>";
}
$query = "SELECT COUNT(*) FROM cotizacion WHERE Fechacontrol = '$cd'"; 
$result = mysql_query($query) or die(mysql_error());
while($row = mysql_fetch_array($result)){
	echo "<span class='cuenta'>  Hoy ingresaron ".$row['COUNT(*)']." Cotizaciones nuevas </span>";

}
echo "<br>";
$query = "SELECT * FROM cotizacion"; 
$result2 = mysql_query($query) or die(mysql_error());	
	$totalRows = mysql_num_rows($result2);
echo "Total de Cotizaciones: ".$totalRows."";

?>
</td>
            <td width="34" align="center" valign="middle"><img src="images/001_46.gif" width="24" height="24" hspace="5" vspace="5"></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
