<?php 
	$id = $_GET['id'];
	$cedula = $_GET['cedula'];
	require('ceoconexion.php');
   
		
		$sql = "UPDATE t_pagos SET status='' where id='$id'";
		$result = mysql_query($sql);
		
		$alumno = mysql_query("select * from alumnos_online WHERE ci=".$cedula." ");
		$id2 =mysql_result($alumno,0,"id");
		
		
		$sql2 = "UPDATE alumnos_online SET status='' where id='$id2'";
		$result2 = mysql_query($sql2);
		
		
		
	
//Para devolver a la p�gina donde se pidi� la acci�n
if (isset ($_GET['buscar'])== "") {
	$url = $_GET['from'];
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".$url."'>";
} 
else {
	$url = $_GET['from'];
	$url2 = $_GET['buscar'];
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".$url."&buscar=".$url2."'>";
} 
?>