<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CECEIP ::: Formulario de Inscripcion alumnos</title>
<meta name="keywords" content="morning, theme, free templates, web design, templatemo, CSS, HTML" />
<meta name="description" content="Morning Theme, free CSS template by templatemo.com" />
<link href="../css/templatemo_style.css" rel="stylesheet" type="text/css" />
	<link type="text/css" href="admin.css" rel="stylesheet" />
	<link type="text/css" href="jquery.cleditor.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="../css/ddsmoothmenu.css" />
<script type="text/javascript" src="../scripts/jquery.min.js"></script>
<script type="text/javascript" src="../scripts/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>
	<script language="javascript"> 
function verifica(){ 
 
    if(document.form.nombre.value.length < 2){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe ingresar el Nombre"); //mensaje a la pantalla
 
        document.form.nombre.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }
 
    if(document.form.nick.value.length < 6){ 
 
        alert("Debe ingresar el Numero de Cedula"); 
 
        document.form.nick.focus(); 
 
        return false;
 
    }
	
	
 
    if(document.form.email.value.length < 1){ 
 
        alert("Debe ingresar el E-Mail"); 
 
        document.form.email.focus(); 
 
       return false;
    }
 
   	  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form.email.value))
      {}
      else 
     { alert("La dirección de email " + document.form.email.value + " es incorrecta.");
       document.form.email.focus();
	   return false;
     } 
 
    if(document.form.pais.value.length < 10){ 
 
        alert("Debe ingresar un número de teléfono"); 
 
        document.form.pais.focus(); 
 
        return false; 
 
    }

 
         // //document.form.submit(); //enviamos formulario    
 
} 
 
</script> 
<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "templatemo_menu", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<link rel="stylesheet" type="text/css" href="../css/styles.css" />
<script language="javascript" type="text/javascript" src="../scripts/mootools-1.2.1-core.js"></script>
<script language="javascript" type="text/javascript" src="../scripts/mootools-1.2-more.js"></script>
<script language="javascript" type="text/javascript" src="../scripts/slideitmoo-1.1.js"></script>
<script language="javascript" type="text/javascript">
	window.addEvents({
		'domready': function(){
			/* thumbnails example , div containers */
			new SlideItMoo({
						overallContainer: 'SlideItMoo_outer',
						elementScrolled: 'SlideItMoo_inner',
						thumbsContainer: 'SlideItMoo_items',		
						itemsVisible: 3,
						elemsSlide: 2,
						duration: 200,
						itemsSelector: '.SlideItMoo_element',
						itemWidth: 280,
						showControls:1});
		},
		
	});
</script>
    
<style type="text/css">
alinear {
	font-size: 12px;
}
alinearr {
	text-align: left;
}
#alinear {
	text-align: left;
}
ROJO {
	color: #F00;
}
.Estilo73 {font-size: 14px}
.Estilo13 {color: #000000}
.Estilo14 {color: #990000}
.Estilo75 {
	color: #000066;
	font-weight: bold;
	font-size: 9px;
}
.Estilo76 {color: #990000; font-weight: bold; font-size: 9px; }
.Estilo77 {
	color: #FFFFFF;
	font-weight: bold;
}
</style>
</head>
<body id="home">

<div id="templatemo_outer_wrapper">
	<div id="templatemo_wrapper">
    
    	<div id="templatemo_header">
    	  <div id="templatemo_menu" class="ddsmoothmenu">
              <ul>
                   <li><a href="../video/index.html" class="selected"><span></span>Home</a></li>
                    <li><a href="../video/escuela.html" target="_self"><span></span>Escuelas</a>
                      	<ul>
                        	<li>
                      <a href="../video/escuelainterce.html" target="_self">Escuelas de I.P</a></li>
                            <li><a href="../video/escuelaprofeta.html" target="_self">Escuelas de Profeta</a></li>
                            <li><a href="../video/escuelasalmista.html" target="_self">Escuelas de Salmistas</a></li>
                            <li><a href="../video/escuelacultura.html" target="_self">Escuelas de Cultura y Gobierno</a></li>
                            <li><a href="../video/escuela.html"></a></li>
                            <li><a href="../video/escuela.html"></a></li>
                            <li><a href="../video/escuela.html"></a></li>
                        </ul>
                    </li>
                    <li><a href=""><span></span>Descargas</a>
                      	<ul>
                            <li><a href="../video/palabraprofetica.html">Palabras Profeticas</a></li>
                            <li><a href="../video/reportaje.html">Reportajes</a></li>
                            <li><a href="../video/predicas.html">Enseñanzas</a></li>      
                               <li><a href="../video/vozprofetica.html">Programa radiales</a></li>
                            <li><a href="../video/convocatoria.html">Convocatoria</a></li>
                            <li><a href="../video/contacto.php">Pedidos</a></li>
                        </ul>
                    </li>
                  	<li><a href="../video/agenda.html"><span></span>Agenda</a></li>
                    <li><a href="../video/contacto.php"><span></span>Contacto</a></li>
            </ul>
                <br style="clear: left" />
          </div> <!-- end of templatemo_menu -->
            <div class="cleaner"></div>
            
		</div> <!-- end of templatemo header -->
        
        <div id="intro_text"></div>
        
        <div id="templatemo_middle">
        	<div id="SlideItMoo_outer">	
                <div id="SlideItMoo_inner">			
                    <div id="SlideItMoo_items">
                        <div class="SlideItMoo_element"> <a href="../agenda.html" target="_self"><img src="../images/gallery/011.jpg" alt="agenda redil" /></a>
                        </div>	
                        <div class="SlideItMoo_element"> <a href="../ministerioamigos.html" target="_self"><img src="../images/gallery/022.jpg" alt="product 2" /></a>
                        </div>
                        <div class="SlideItMoo_element"> <a href="../libre.html" target="_self"><img src="../images/gallery/libre.jpg" alt="libreria redil" /></a>
                        </div>
                        <div class="SlideItMoo_element"> <a href="http://ministerioredil.org/galeria/index.php" target="_blank"><img src="../images/gallery/gale.jpg" alt="galeria redil" /></a>
                        </div>
                        <div class="SlideItMoo_element"> <a href="../donacion.html"><img src="../images/gallery/dona.jpg" alt="donaciones redil" /></a>
                        </div>
                        <div class="SlideItMoo_element">
                                <a href="http://www.templatemo.com/page/6" target="_parent">
                                <img src="../images/gallery/066.jpg" alt="suscribete redil" /></a>
                        </div>
                    </div>			
                </div>
            </div>		   
        </div> <!-- end of templatemo_middle -->
       

			
        	    <table width="786" height="159" border="0" align="right">
        	      <tr>
        	        <td height="22" colspan="2" valign="top"></td>
       	          </tr>
        	      <tr>
        	        <td width="32" valign="top"><p class="Estilo73">&nbsp;</p>
       	            </td>
        	        <td width="744" valign="top"><table width="746" border="0" align="center" cellpadding="0" cellspacing="0" >
                      <tr>
                        <td height="28" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="746" height="235" valign="top">
                  <?php
include("ceoconexion.php");
 $cedu = $_POST['TXTCEDULA'];
 $query = mysql_query("SELECT * FROM alumnos_pre WHERE ci='$cedu'");
 $datos = mysql_fetch_array($query); 

	if ($datos[ci] == $cedu){
		?>
                            <form action="act_registro2.php" method="post" name="form" id="form" onsubmit="return verifica()">
                              <table width="84%"  border="0" align="center" cellpadding="0" cellspacing="3">
                                <tr bgcolor="#45813B">
                                  <td width="37%" class="text"><span class="Estilo77">DATOS PERSONALES </span></td>
                                  <td width="63%" class="Estilo75">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>C.I / RIF:</strong></div></td>
                                  <td class="Estilo76"><input name="ci" type="text" id="ci" size="40" value="<?=$datos[ci]?>"/>
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Nombres: </strong></div></td>
                                  <td class="Estilo76"><input name="nombre" type="text" id="nombre" size="40" value="<?=$datos[nombre]?>"/>
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Apellidos:</strong></div></td>
                                  <td class="Estilo76"><input name="apellido" type="text" id="apellido" size="40" value="<?=$datos[apellido]?>" />
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Profesi&oacute;n</strong></div></td>
                                  <td class="Estilo76"><input name="profesion" type="text" id="profesion" size="40" value="<?=$datos[profesion]?>"/>
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Fecha de Nacimiento: </strong></div></td>
                                  <td class="Estilo76"><input name="naci" type="text" id="naci" size="40" value="<?=$datos[fechana]?>"/>                                  </td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Edad: </span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="edad" type="text" id="edad" size="40"  value="<?=$datos[edad]?>"/>
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Telefono: </span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="telefono" type="text" id="telefono" size="40" value="<?=$datos[telefono]?>"/>
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Sexo: </span></strong></div></td>
                                     <td class="Estilo75">    <span class="Estilo14">
									 <script type="text/javascript">
			
								document.getElementById('sexo').value="<?=$datos[sexo]?>";
							</script>
                                    <select name="sexo" id="sexo">
                                      <option value="M">Masculino</option>
                                      <option value="F">Femenino</option>
                                    </select>
                                  </span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Email </span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="email" type="text" id="email" size="40" value="<?=$datos[email]?>"/>
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text">&nbsp;</td>
                                  <td class="Estilo75">&nbsp;</td>
                                </tr>
                                <tr bgcolor="45813B">
                                  <td height="20" class="text Estilo77">DATOS DE LA CONGREGACION:</td>
                                  <td>&nbsp;</td>
                                </tr>
                                <tr>
                                  <td height="30" class="text"><div align="right"><strong><span class="t_rights">Nombre de la Congregacion:</span></strong></div></td>
                                  <td><span class="Estilo76">
                                    <input name="congregacion" type="text"  id="congregacion" size="40" value="<?=$datos[congregacion]?>"/>
                                  </span></td>
                                </tr>
                                <tr>
                                  <td class="t_rights"><div align="right"><strong> Direccion de la Congregacion:</strong></div></td>
                                  <td><span class="Estilo76">
                                    <input name="direcongre" type="text"  id="direcongre" size="40" value="<?=$datos[direcongre]?>"/>
                                    </span></td>
                                </tr>
                                <tr>
                                  <td ><div align="right"><strong>Apellido y Nombre del Ministro </strong></div></td>
                                  <td class="input Estilo13"><span class="Estilo76">
                                    <input name="nommini" type="text"  id="nommini" size="40" value="<?=$datos[nomministro]?>" />
                                    </span></td>
                                </tr>
                                <tr>
                                  <td ><div align="right"><strong>Numero de Contacto del Ministro </strong></div></td>
                                  <td class="input Estilo13"><span class="Estilo76">
                                    <input name="telfmini" type="text"  id="telfmini" size="40" value="<?=$datos[telministro]?>"/>
                                  </span></td>
                                </tr>
                                <tr>
                                  <td >&nbsp;</td>
                                  <td class="input Estilo13">&nbsp;</td>
                                </tr>
                                <tr bgcolor="#45813B">
                                  <td colspan="2" class="input Estilo13"><span class="text Estilo77">DATOS DE LA ESCUELA:</span></td>
                                </tr>
                                <tr>
                                  <td ><div align="right"><strong>Escuela: </strong></div></td>
                                  <td><?php
					include("ceoconexion.php");
				echo "<select name='CMBGRADOS' id='CMBESCUELA' >";
               	$QUERY= mysql_query("select * from t_actividades order by id_actividad");
              	echo "<option value=-1></option>";
				mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"id_actividad").">".mysql_result($QUERY,$i,"escuela")."</option>";
				}
              	echo "</select> "
					
					?></td>
                                </tr>
                                <tr>
                                  <td height="32">&nbsp;</td>
                                  <td><div align="right"><span class="Estilo76"><font face="Georgia, Times New Roman, Times, serif">(*) CAMPOS OBLIGATORIOS</font></span> </div></td>
                                </tr>
                                <tr>
                                  <td height="32"><span class="Estilo13"></span></td>
                                  <td><input name="registro" type="submit" id="registro" value=" Actualizar Datos " />
                                      <input name="borrar" type="reset" id="borrar" value=" Limpiar " /></td>
                                </tr>
                                <tr>
                                  <td colspan="2"><br />
                                      <span class="Estilo75"><strong><img src="img/padlock.gif" width="17" height="16" />Por motivos de seguridad guardaremos su IP actual, su IP  <?=$ip = $_SERVER['REMOTE_ADDR'];
																		?> ha sido guardada en nuestra base de datos.:</strong></span>
                                     
                                  </td>
                                </tr>
                                <tr>
                                  <td colspan="2"></td>
                                </tr>
                              </table>
                            </form>
							<? 
							}else{

								//header("Location: reg_alumnos_pre_ven.php");
								echo"<script>location='reg_alumnos_pre_ven.php'</script>";
							} ?>
							
</td>
                      </tr>
                    </table></td>
        	      </tr>
      </table>

    
    </div> <!-- end of templatemo_wrapper -->
</div> <!-- end of templatemo_outer_wrapper -->

<div id="templatemo_footer_wrapper">
	<div id="templatemo_footer">
        Copyright © 2014 cecip online
          <div class="cleaner"></div>
    </div>
</div>
</body>
</html>