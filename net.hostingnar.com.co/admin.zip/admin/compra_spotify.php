<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Alumnos online pendiente de pagos- Los 8 pedidos más recientes</title>
<script language="javascript">
function MM_goToURL() { //v3.0
var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
function MM_openBrWindow(theURL,winName,features) { //v2.0
window.open(theURL,winName,features);
}
</script>
<style type="text/css">
<!--

table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo3 {font-size: 18px; }
.Estilo4 {
	font-size: 24px;
	font-weight: bold;
}

-->
</style>
</head>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>

<?php  //include('header.php'); ?>

<div class="order"></div>
<?php 
//Imprecindible para saber la dirección y luego darla a las acciones
$urlactual= $_SERVER['REQUEST_URI'];
//echo $urlactual;
global $STYLECELDAS,$CABECERACELDAS;
// mySQL Table

    require('ceoconexion.php');
	$query = "select * from t_spotify";
    $result = mysql_query($query);
	mysql_query ("SET NAMES 'utf8'");
    $i = 0;

    while ($i < mysql_num_fields($result)) {
      $meta = mysql_fetch_field($result);
      $columns[$i] = $meta->name;
      $i++;
    }

   	echo "CUENTAS DIPONIBLE<BR>";
      echo "<table cellspacing=\"2\" cellpadding=\"2\" border=\"0\" width=\"100%\" class='normal'>\n";
   
    //for($i=1;$i<sizeof($columns);$i++) {
      
	  //echo "<td class='campos'><center><b>".$columns[$i]."</td>";
   // }
    echo "<th class='cabecera'><center> NOMBRE / DURACION </th>";
	echo "<th class='cabecera'><center>VALOR / CREDITO</th>";
	//echo "<th class='cabecera'><center>CREDITOS</th>";
	//echo "<th class='cabecera'><center>WHATSAPP</th>";
	//echo "<th class='cabecera'><center>COMPRADOR</th>";
	//echo "<th class='cabecera'><center>EMAIL</th>";

	
    //echo "<td class='cabecera'><center>Marcar Pagado</td>\n";
	echo "<td class='cabecera'><center>COMPRAR</td>\n";
	//echo "<td class='cabecera'><center>Editar</td>\n";
   // echo "<td class='cabecera' ><center>Eliminar</td>\n";
   // echo "<td class='campos' align=\"center\" valign=\"middle\">Imprimir ticket</td></tr>\n";


    //Inicio de paginacion
    (!empty($_GET['pag'])) ? ($pag = $_GET['pag']) : ($pag = '1');
  
	$result = mysql_query("SELECT COUNT(*) FROM t_spotify"); 
list($total) = mysql_fetch_row($result);
$tampag = 24;
$reg1 = ($pag-1) * $tampag;
$result = mysql_query("select * from t_spotify  WHERE tipo= 'A' ORDER BY id_areacomp DESC  LIMIT $reg1, $tampag");

//Mostrar paginacion
	echo "<div class='paginacion'>";
		echo paginar($pag, $total, $tampag, "compra_spotify.php?pag=");	
	echo "</div>";
//Fin Mostrar paginacion
    
    
    
  //$query = "select * from entradas";
  // $result = mysql_query($query);
    $j=0;

    //while($row=mysql_fetch_array($result)) {
	if(mysql_num_rows($result)<0){
      //echo "<tr>";
      
       }else{  
	//for($i=1;$i<sizeof($columns);$i++) {
	for($i=0;$i<mysql_num_rows($result);$i++){
	
	
					if($i%2==0)
					{
						echo"<tr ".$STYLECELDAS.">";
						
					}else{
						echo"<tr ".$STYLECELDAS." bgcolor=#F2F9F9>";
					}
					
	//$escuela=mysql_result($result,$i,"escuela");
	//$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");
	
	//$pais=mysql_result($result,$i,"pais");
	//$nompais = mysql_query("select * from T_PAIS WHERE ID_PAIS=".$pais." ");
	

		//echo "<td bgcolor='#DBFFB7'><center>".$row[$columns[$i]]."</td>";} 
		//echo "<td bgcolor='#DBFFB7'><center>".date("d/m/Y",mysql_result($result,$i,"fecha"))."</td>";
		
		echo "<td bgcolor='#DBFFB7'><center> ".mysql_result($result,$i,"url")."</td>";
		echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"descripcion")."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"creditos")."</td>";

		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"celular")."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".$pais."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($escuelas,0,"escuela")."</td>";
	$sql5 = "SELECT * FROM  t_usuarios WHERE id_usuario='$ID_USUARIO'";
	$result5=mysql_query($sql5);
	mysql_query ("SET NAMES 'utf8'");
	$row5 = mysql_fetch_assoc($result5);

	$j=$row[$columns[0]];
		echo "<td class='small'><center><a href='compra_spotifyf.php?id=".mysql_result($result,$i,"id_areacomp")."&id2=".$row5['id_personal']."&from=".$urlactual."'><img src='./img/001_06.gif' alt='comprar' border='0' /></a>";
	//echo "<td class='small'><center><a href='marcar_enviado.php?id=".$j."&from=".$urlactual."'><img src='./images/001_06.gif' alt='Marcar como Enviado' border='0' /></a>";
	//echo "<td class='small'><center><button class='boton' onClick=MM_openBrWindow('email2.php?id=".mysql_result($result,$i,"id")."','Detalles','scrollbars=no,menubar=no,toolbar=no,location=no,resizable=yes,width=570,height=500')><img src='./img/001_06.gif' alt='Marcar como Enviado' border='0' /></button>"; 
	//echo "<td class='small'><center><a href='marcar_enviado2.php?id=".mysql_result($result,$i,"id")."&from=".$urlactual."&cedula=".mysql_result($result,$i,"ci")."'><img src='./img/001_06.gif' alt='Marcar como Enviado' border='0' /></a>";
	//echo "<td class='small'><center><a href='marcar_en_espera2.php?id=".mysql_result($result,$i,"id")."&from=".$urlactual."&id2=".mysql_result($result,$i,"id_personal")."'><img src='./img/001_30_02.gif' alt='EDITAR' border='0' /></a>";
	//echo "<td class='small'><center><button class='boton' onClick=MM_openBrWindow('email2.php?id=".mysql_result($result,$i,"id")."','Detalles','scrollbars=no,menubar=no,toolbar=no,location=no,resizable=yes,width=420,height=500')><img src='./img/001_12.gif' alt='Mandar un correo' border='0' /></button>"; 
	//echo "<td class='small'><center><a href='borrar.php?id=".mysql_result($result,$i,"id")."&id2=".mysql_result($result,$i,"id_personal")."&from=".$urlactual."'><img src='./img/001_49.gif' alt='Borrar' border='0' /></a>";
	//echo "<td class='small'><center><a href='imprimir.php?id=".$j."'><img src='./images/print.gif' alt='Imprimir guia' border='0' /></a>";
	
	}
	}
	echo "</table>";

	//Funcion de paginacion
  function paginar($actual, $total, $por_pagina, $enlace) {
  $total_paginas = ceil($total/$por_pagina);
  $anterior = $actual - 1;
  $posterior = $actual + 1;
  if ($actual>1)
    $texto = "<a href=\"$enlace$anterior\">&laquo; Anterior </a> ";
  else
    $texto = "<b>&laquo;</b> ";
  for ($i=1; $i<$actual; $i++)
    $texto .= "<a href=\"$enlace$i\">$i</a> ";
  $texto .= "<b>$actual</b> ";
  for ($i=$actual+1; $i<=$total_paginas; $i++)
    $texto .= "<a href=\"$enlace$i\">$i</a> ";
  if ($actual<$total_paginas)
    $texto .= "<a href=\"$enlace$posterior\"> Siguiente &raquo;</a>";
  else
    $texto .= "<b>&raquo;</b>";
  return $texto;
}

echo "<div class='paginacion' align='left'>";
		echo paginar($pag, $total, $tampag, "compra_spotify.php?pag=");	
	echo "</div>";
//Fin Funcion de paginacion

  // mySQL ends

mysql_free_result($result);


?>
</form>
</p>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>