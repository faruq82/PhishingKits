<?php
	include("ajaxordenconfig.php");
	$TXTIDENTIFICACION = $_POST['TXTIDENTIFICACION'];
	$FECHA=$_POST['FECHA'];
  	$HORAE=$_POST['HORAE'];
    $HORAS=$_POST['HORAS'];
	$ID_GRADO=$_POST['ID_GRADO'];
	$CANTIDAD=$_POST['CANTIDAD'];
	//$ID_PROYECTO=$_POST['ID_PROYECTO'];
	$ID_AREACOMP=$_POST['ID_AREACOMP'];
	//$ID_AREATECN=$_POST['ID_AREATECN'];
	//$ID_HERRAMIENTA=$_POST['ID_HERRAMIENTA'];
	$ID_PERSONAL =$TXTIDENTIFICACION;
	$TXTOBSERVACION =$_POST['TXTOBSERVACION'];
	$ID_USUARIO =$_POST['ID_USUARIO'];
	$ACCION = $_POST['ACCION'];
        //$CMB1 = $_POST['CMB1'];
        //$CMB2 = $_POST['CMB2'];
        //$CMB3 = $_POST['CMB2'];
		$CMBGRADO = $_POST['CMBGRADO'];
       

	if($ACCION=="GUARDAR")
	{

		$SQL=array();
		$SQL1= "SELECT * FROM  t_actividades  WHERE id_personal  ='".$TXTIDENTIFICACION."'  ";
		$QUERY = mysql_query($SQL1);
		if(mysql_num_rows($QUERY)!=0)
		{
			 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'yaexiste'>";
			return; 
		}

		//$SQL[] ="INSERT INTO t_actividades (id_grado,id_areatecn,id_areacomp,id_herramienta,id_personal,fecha,horainicial,horafinal,id_proyecto,cantidad,observacion,camp1,camp2,camp3 ) VALUES(".$ID_GRADO.", ".$ID_AREATECN.",".$ID_AREACOMP.",".$ID_HERRAMIENTA.",".$ID_PERSONAL.",'".CONVERT_FECHAS($FECHA)."','".$HORAE."','".$HORAS."',".$ID_PROYECTO.",".$CANTIDAD.",'".$TXTOBSERVACION."',".$CMB1.",".$CMB2.",".$CMB3.")";
		$SQL[] ="INSERT INTO t_actividades (id_grado,id_areacomp,id_personal,fecha,horainicial,horafinal,cantidad,observacion ) VALUES('".$ID_GRADO."', '".$ID_AREACOMP."', '".$ID_PERSONAL."', '".CONVERT_FECHAS($FECHA)."', '".$HORAE."', '".$HORAS."', '".$CANTIDAD."', '".$TXTOBSERVACION."')";
		if(CORRER_TRANSACCION($SQL)==1)
		{
				 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
				unset($SQL);
				return;
		}else{

                   echo "<input type='hidden' id='AVISOMOFICIADO' value= ''>";
			return;
                }





			
		
	}
	
	
	
	
	
	if($ACCION=="BUSCAR")
	{
		if($TXTIDENTIFICACION!="")
		{
			//$SQL= "SELECT * FROM t_proyectos INNER JOIN t_actividades ON t_proyectos.id_proyecto = t_actividades.id_actividad WHERE proyecto  ='".$TXTIDENTIFICACION."' ";
					$SQL= "SELECT * FROM t_facilitadores where cedula ='".$TXTIDENTIFICACION."'";
					$ID_PERSONAL=$TXTIDENTIFICACION;
			$QUERY = mysql_query($SQL);
			if(mysql_num_rows($QUERY)!=0)
			{
				echo "<input type=hidden id='AVISO' value= '".mysql_result($QUERY,0,"cedula")."|".mysql_result($QUERY,0,"nombre")." ".mysql_result($QUERY,0,"apellido")."|".mysql_result($QUERY,0,"id_facilitador")."'>";
				
			}else{
				echo "<input type=hidden id='AVISO' value='noencontrado'>";
			}
			
		}
	}
	

	if($ACCION=="BUSCAR2")
	{
		if($CMBGRADO!="")
		{
			//$SQL= "SELECT * FROM t_proyectos INNER JOIN t_actividades ON t_proyectos.id_proyecto = t_actividades.id_actividad WHERE proyecto  ='".$TXTIDENTIFICACION."' ";
					$SQL= "SELECT * FROM t_grados where grado ='".$CMBGRADO."'";
					$ID_PERSONAL=$CMBGRADO;
			$QUERY = mysql_query($SQL);
			if(mysql_num_rows($QUERY)!=0)
			{
				echo "<input type=hidden id='AVISO' value= '".mysql_result($QUERY,0,"grado")."|".mysql_result($QUERY,0,"descripcion")."'>";
				
			}else{
				echo "<input type=hidden id='AVISO' value='noencontrado'>";
			}
			
		}
	}
		
		if($ACCION=="USUARIOS")
		{
			$TXTAPELLIDOS = $_POST['DATO'];
			$NRO = $_POST['NRO'];
			if(!empty($_POST['NRO']))
			{
				 $NRO=($NRO-1)*15;
						
			}else{
			
				 $NRO=0;
			}
			$SQL = "select * from t_usuarios inner join t_personal on t_usuarios.id_personal = t_personal.id_personal where t_usuarios.id_tipo_usuario = 2 AND (t_personal.cedula like '%".$TXTAPELLIDOS."%' OR t_personal.p_apellido like '%".$TXTAPELLIDOS."%' OR t_personal.s_apellido like '%".$TXTAPELLIDOS."%' OR t_personal.p_nombre like '%".$TXTAPELLIDOS."%' OR t_personal.s_nombre like '%".$TXTAPELLIDOS."%') ORDER BY t_personal.p_apellido,t_personal.s_apellido,t_personal.p_nombre,t_personal.s_nombre";
			$BUSQUEDA_ALUMNOS = mysql_query($SQL)or die("Imposible realizar el SQL");
			if(mysql_num_rows($BUSQUEDA_ALUMNOS)==0)
			{
				echo "<table width=697 border=0 cellpadding=0 cellspacing=0><tr><td><b>La busqueda no arrojo resultados</b></td></tr>";
				echo "</table><input type='hidden' id='cantidad' value=0><input type='hidden' id='datoviejo' value=".$TXTAPELLIDOS.">";
			}else{
				echo "<table width=697 border=0 cellpadding=0 cellspacing=0>";
				$CONTADOR=0;
				for($i=$NRO;$i<mysql_num_rows($BUSQUEDA_ALUMNOS);$i++)
				{
					$CONTADOR=$CONTADOR+1;
					echo "<tr ".$STYLECELDAS." onClick=VOLCAR_PERSONAL('".mysql_result($BUSQUEDA_ALUMNOS,$i,"cedula")."')><td width=97 align=center>"; echo mysql_result($BUSQUEDA_ALUMNOS,$i,"cedula");echo "</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"p_apellido")."</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"s_apellido")."</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"p_nombre")."</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"s_nombre")."</td></tr>";
					if($CONTADOR==15)
					{
						$i=mysql_num_rows($BUSQUEDA_ALUMNOS);
					}
					
				}	
				echo "</table><input type='hidden' id='cantidad' value=".ceil(mysql_num_rows($BUSQUEDA_ALUMNOS)/15)."><input type='hidden' id='datoviejo' value=".$TXTAPELLIDOS.">";
			}
			
		}
?>