<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Enviar e-mail</title>
<link href="estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div style="margin:10px">
  <?php

$firma = "



<p>
-- <br>
_____.__._._._._.._.._..._...-...--...---..----.---<br>
Ministerio Redil<br>
<br>
 Telf. 582613229424<br>.<br>
</p>";

$id = $_GET['id'];
require('ceoconexion.php');

//mysql_connect("localhost","root");
//mysql_select_db("pedidos");  

$sql = "SELECT * FROM alumnos_pre WHERE id='$id'";
$result=mysql_query($sql);
mysql_query ("SET NAMES 'utf8'");
$row = mysql_fetch_assoc($result);


echo "<div class='order'>Envio de e-mail al Alumno ".$row['nombre']." ".$row['apellido']."</div><br>" ;
echo "<form name='correo' method='post' action='enviar_email.php'>Correo  <input name='correo' type='text' value=' ".$row['email']."' size='40'><br>";
echo "Asunto <input name='asunto' type='text' value='' size='40'><br>";
echo "Mensaje <textarea name='mensaje' cols='45' rows='10'>".$firma."</textarea><br><br>";
echo "<input type='submit' name='button' value='Enviar e-mail'><input type='reset' name='button2' value='Limpiar'>";
echo "</form>"
?>
</div>
</body>