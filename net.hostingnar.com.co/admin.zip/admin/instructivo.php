<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "inicio.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>Horarios CECIP ONLINE</title>
<style type="text/css">
<!--

table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo1 {font-size: 16px}
.Estilo2 {font-size: 14px}
.Estilo3 {font-size: 14}

-->
</style>
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>

<table border="0" cellspacing="0" cellpadding="0"  width="780" class="normal">
  <tr>
    <td background="img/cafe.png" ><div align="center" class="Estilo1"><strong>INSTRUCTIVO AL ESTUDIANTE
    </strong></div>
    <p align="center" class="Estilo2">Bienvenido a la escuela de Intercesión Profética. A continuación te daremos un instructivo que te guiará paso a paso en lo que debes hacer para disfrutar de tus estudios.</p></td>
  </tr>
  <tr>
    <td><ul>
        <li><span class="Estilo1"><span class="Estilo2"><span class="Estilo3"><strong>PASO 1. </strong>Espera por tu Activación: Una vez hiciste tu inscripción debes esperar que tu pago sea confirmado por  el departamento de finanzas  y activada tu cuenta como estudiante en el sistema. Las activaciones de  los nuevos estudiantes se hacen de lunes a viernes durante horarios de oficina. </span></span></span></li>
      </ul>      <ul class="Estilo3">
        <li> <strong>PASO 2. </strong>Entra al portal web: www.ministerioredil.org/campus/</li>
      </ul>
      <ul class="Estilo3">
        <li><strong>PASO 3</strong>. Has clic en la escuela en la que te hayas registrado</li>
      </ul>
      <ul class="Estilo3">
        <li> <strong>PASO 4</strong>. HAZ LOGIN: Entra a “login” e introduce el  usuario y  la clave que creaste para registrarte, esto te conducirá a tu panel de estudiante. </li>
      </ul>
      <ul class="Estilo3">
        <li><strong>PASO 5. </strong>FAMILIARÍZATE CON TU PANEL DE ESTUDIANTE: Una vez que estés en tu panel de estudiante, tendrás acceso a todo el material digital de la escuela. Revisa cada botón para que te familiarices con los contenidos. </li>
      </ul>
      <ul class="Estilo3">
        <li><strong>PASO 6.</strong> DESCARGA TU MATERIAL. Entra en el botón “DESCARGA” en donde encontrarás tu manual digital, láminas de “Power Point” y videos que corresponden a los módulos de la escuela. </li>
      </ul>
      <ul class="Estilo3">
        <li><strong>PASO 7. </strong>ESCUCHA LOS AUDIOS: Empieza por el módulo uno (1) hasta que llegues al último módulo. Te recomendamos escoger un horario en donde puedas concentrarte y permitir que el Padre celestial te ministre. </li>
      </ul>
      <ul class="Estilo3">
        <li><strong>PASO 8</strong>. ELLENA TUS EVALUATIVOS: Después que escuches cada módulo deberás presionar el botón de “EVALUATIVOS”. Descarga el evaluativo que corresponda  al módulo que has escuchado, llénalo y envíalo utilizando el botón azul “SUBIR-EVALUATIVO”. Nota: Tu certificado de participación solo te será emitido cuando hayas enviado los evaluativos en totalidad.</li>
      </ul>
	   
	    <ul class="Estilo3">
        <li><strong>PASO 9 </strong>. ADQUIERE TU MATERIAL COMPLEMENTARIO. Hemos diseñado seminarios y talleres que están en audio y en video que complementan y profundizan el material que vas a estudiar en la escuela. Te recomendamos altamente que lo adquieras presionando el botón “LIBRERÍA”</li>
      </ul>
      <ul class="Estilo3">
        <li><strong>PASO 10 </strong>. ESCOGE A UN DISCÍPULO: Te recomendamos escoger a una persona con la que puedas compartir lo que estas aprendiendo en clase. Esto te ayudará a tener mayor claridad en el material y a crecer en impartición. “Debemos dar por gracia lo que por gracia hemos recibido”</li>
      </ul>	  
      <ul>
        <li class="Estilo3">•	Si tienes preguntas o dudas presiona el botón “ASESORÍA AL ESTUDIANTE”, envíanos tu pregunta e inmediatamente te responderá uno de nuestros  asesores en vivo durante los horarios de oficina. También puedes escribirnos directamente al correo académico:  escuelas@ministerioredil.org</strong></li>
      </ul>
      <p align="center" style="color: rgb(0, 0, 0); font-family: 'Times New Roman'; font-size: medium; font-style: normal; font-variant: normal; font-weight: bold; letter-spacing: normal; line-height: normal; orphans: auto; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: auto; word-spacing: 0px; -webkit-text-stroke-width: 0px;">&nbsp;</p>
    </td>
  </tr>
  <tr>
    <td height="68" background="img/cafe.png"><div align="center" class="Estilo1">
      <p align="center"><strong>Felicitaciones por tomar la decisión de ser parte de los miles que hoy anuncian, manifiestan y establecen la Voluntad del Padre sobre la tierra.</strong></p>
    </div></td>
  </tr>
</table>

<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
