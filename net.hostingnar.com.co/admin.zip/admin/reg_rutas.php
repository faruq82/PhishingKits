<?php 
	
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	
?>
<html >
<head>
<title>Registro de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>


<script language="javascript">
	var er_identificacion = /^[0-9]{6,11}$/;
        var er_can = /^[0-9]{1,3}$/;
	var er_texto = /^[a-zA-Z0-9\.+\_+\s+\,+\-+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+]{1,45}$/;
	var er_fecha = /^[0-9]{2}[\-]{1}[0-9]{2}[\-]{1}[0-9]{4}$/;
	var er_telefono = /^[0-9]{4}[\-]{1}[0-9]{7}$/;
        var er_hora =  /^[0-9]{2}[\:]{1}[0-9]{2}$/;

	


function BUSQUEDAPERSONAL()
{
			

	document.getElementById('nobodybusqueda').innerHTML="<div id='ventanabusqueda'  onmousedown=dragStart(event,'nobodybusqueda') style='visibility:visible'><table border=0 cellpadding=0 cellspacing=0 width=700  background='img/estructura/busqueda.png' valign=top ><tr valign=center ><td  colspan=2 width=697 align='right' valign=center>&nbsp;&nbsp;</td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr>" +
	"<tr valign=center><td width=350>&nbsp;&nbsp;Enter some information&nbsp;&nbsp;<input type=text name=TXTDATO id=TXTDATO onblur=this.value=this.value.toUpperCase()>&nbsp;<img src='img/iconos/buscar.png' title='Buscar' onClick='validarbusqueda()' style='cursor:pointer'></td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr>" +
	"<tr><td  colspan=2 ><table border=1 cellpadding=0 cellspacing=0 width=697 align=center><tr class='cabecera'><th align=center width=97>&nbsp;&nbsp;Identificacion</th><th align=left width=150>&nbsp;P. Apellido</th><th align=left width=150>&nbsp;S. Apellido</th><th align=left width=150>&nbsp;P. Nombre</th><th align=left width=150>&nbsp;S. Nombre</th></table></td></tr>" +
	"<tr height = 260  ><td colspan=2 valign=top><div id='busquedaarrojada'></div></td></tr>" +
	"<tr><td align=left><div id='CANTIDADLISTAS'>&nbsp;</div></td><td align= right ><input type=button value=Cerrar onClick=cerrarbusqueda()>&nbsp;&nbsp;</td></tr>" +
	"<tr><td  colspan=2 >&nbsp;</td></tr></table></div>";
	document.getElementById('TXTDATO').focus();	
	
	
}
function cerrar()
{
	document.getElementById('nobody').innerHTML="";
}
function cerrarbusqueda()
{
	document.getElementById('ventanabusqueda').style.visibility='hidden';
}
function validarbusqueda()
{
	if(document.getElementById('TXTDATO').value=="")
	{
		alert("Debe especificar el dato");
		return false;
	}else{
	
			cargandodatospersonal(0);
			
		}
}
function cargandodatospersonal(NRO)
{
	divResultado = document.getElementById('busquedaarrojada');
	ajax=objetoAjax();
	ajax.open("POST", "ajax_reg_actividades.php",true);
	ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
	if(NRO!=0)
	{
		dato = document.getElementById('datoviejo').value
		ajax.send("DATO="+dato+"&ACCION=USUARIOS&NRO="+NRO+"");
	}else{
		ajax.send("DATO="+document.getElementById('TXTDATO').value+"&ACCION=USUARIOS"); 
	}
	ajax.onreadystatechange=function(){
	if (ajax.readyState==4) {
			//mostrar resultados en esta capa
			divResultado.innerHTML = ajax.responseText;
			var muestra = "";
			var cantidad = document.getElementById('cantidad').value;
			for(i=0;i<cantidad;i++)
			{
				if(i==0)
				{
					muestra="&nbsp;<label style='cursor:pointer' onClick=cargandodatospersonal("+(i+1)+")><b>"+(i+1)+"</b></label>";
				}else{
					muestra = muestra+"-<label style='cursor:pointer' onClick=cargandodatospersonal("+(i+1)+")><b>"+(i+1)+"</b></label>"; 
				}
			}
			document.getElementById('TXTDATO').value=document.getElementById('datoviejo').value;
			document.getElementById('CANTIDADLISTAS').innerHTML=muestra;
		}
	}
		 
}
function VOLCAR_PERSONAL(IDENTIDAD)
{
	document.getElementById('TXTIDENTIFICACION').value=IDENTIDAD;
	document.getElementById('buscarimgpersonal').onclick();
	cerrarbusqueda();
}


function objetoAjax()
{ 
	var xmlhttp=false; 
	try 
	{ 
		xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); 
	}
	catch(e)
	{ 
		try
		{ 
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
		} 
		catch(E) { xmlhttp=false; }
	}
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') { xmlhttp=new XMLHttpRequest(); } 

	return xmlhttp; 
}


function limpiar()
{

	document.getElementById('TXTIDENTIFICACION').value = "";
	document.getElementById('TXTP_NOMBRE').value="";
	document.getElementById('dateArrival').value="";
	document.getElementById('ID_PERSONAL').value="";
	document.getElementById('HORAE').value="";
	document.getElementById('HORAS').value="";
	document.getElementById('CANTIDAD').value="";
	document.getElementById('TXTOBSERVACION').value="";
	if(document.getElementById('AVISO'))
	{document.getElementById('AVISO').value = '';
	}
	document.getElementById('SUBMIT').value =  "Guardar";
	document.getElementById('TXTIDENTIFICACION').focus()
    
}

function usuarios(ACCION)
{
	
	   if(ACCION=="BUSCAR")
	   {
		   var datos = new Array();
		   var TXTIDENTIFICACION = document.getElementById('TXTIDENTIFICACION').value;
		  
			  
		    if(!er_identificacion.test(TXTIDENTIFICACION))
			{
				alert("IDENTIFICACION ERRARDA");
				document.getElementById('TXTIDENTIFICACION').focus()
				return false;
			}
			mensaje("Buscando...");
		
			ajax=objetoAjax();
			ajax.open("POST", "ajax_reg_actividades.php",true);
			ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
			ajax.send("ID_PERSONAL="+ID_PERSONAL+"&TXTIDENTIFICACION="+encodeURIComponent(TXTIDENTIFICACION)+"&ACCION=BUSCAR"); 
			ajax.onreadystatechange=function() {
				if (ajax.readyState==4)
				{
					
				
					document.getElementById('divalerta').innerHTML = ajax.responseText;
					document.getElementById('divalerta').style.display='none';
					document.getElementById('divalerta').style.height = "0px";
					if(document.getElementById('AVISO'))
					{
						if(document.getElementById('AVISO').value=="noencontrado")
						{
							alert("NO HUBO RESULTADO");
							limpiar();
							return;
						}else{
							datos = document.getElementById('AVISO').value.split("|");
							document.getElementById('TXTIDENTIFICACION').value=datos[0];
							document.getElementById('TXTP_NOMBRE').value=datos[1];
                                                        document.getElementById('ID_PERSONAL').value=datos[2];
							document.getElementById('procesando').innerHTML ="";
							for(i=0;i<datos.length;i++)
							{
								delete datos[i];
							}
						}
					}else{
						alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
						return false;

					}
				}
			}

         }

		
		if(ACCION=="CARGAR")
		{
			document.getElementById('TXTIDENTIFICACION').focus()
			
		}
		
}


function guardar()
{

    var ID_USUARIO='<?php echo $ID_USUARIO;?>';
    var ID_PERSONAL=document.getElementById('ID_PERSONAL').value;
    var FECHA=document.getElementById('dateArrival').value;
    var HORAE=document.getElementById('HORAE').value;
    var HORAS=document.getElementById('HORAS').value;
    var ID_GRADO=document.getElementById('CMBGRADO').value;
    var CANTIDAD=document.getElementById('CANTIDAD').value;
    var ID_PROYECTO=document.getElementById('CMBPROYECTO').value;
    var ID_AREACOMP=document.getElementById('CMBAREACOMP').value;
    var ID_AREATECN = document.getElementById('CMBAREATECN').value;
    var ID_HERRAMIENTA = document.getElementById('CMBHERRAMIENTA').value;
    var TXTOBSERVACION = document.getElementById('TXTOBSERVACION').value;

    var CMB1 = document.getElementById('CMB1').value;
    var CMB2 = document.getElementById('CMB2').value;
    var CMB3 = document.getElementById('CMB3').value;

    if(ID_PERSONAL == "")
    {
            alert("ERROR EN EL DOCENTE");
            return false;
    }

    if(!er_fecha.test(FECHA))
    {
            alert("ERROR EN LA FECHA");
            return false;
    }
    if(!er_hora.test(HORAE))
     {
           alert("ERROR EN LA HORA DE ENTRADA");
            return false;


     }
     if(!er_hora.test(HORAS))
     {
           alert("ERROR EN LA HORA DE SALIDA");
            return false;


     }

     if(!er_can.test(CANTIDAD))
     {
           alert("ERROR EN LA CANTIDAD DE ALUMNOS");
            return false;


     }
     mensaje("Guardando...");
    ajax=objetoAjax();
    ajax.open("POST", "ajax_reg_actividades.php",true);
    ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    ajax.send("ID_PERSONAL="+encodeURIComponent(ID_PERSONAL)+"&FECHA="+encodeURIComponent(FECHA)+"&HORAE="+encodeURIComponent(HORAE)+"&HORAS="+encodeURIComponent(HORAS)+"&ID_USUARIO="+ID_USUARIO+"&ACCION=GUARDAR&ID_GRADO="+ID_GRADO+"&CANTIDAD="+CANTIDAD+"&ID_PROYECTO="+ID_PROYECTO+"&ID_AREACOMP="+ID_AREACOMP+"&ID_AREATECN="+ID_AREATECN+"&ID_HERRAMIENTA="+ID_HERRAMIENTA+"&TXTOBSERVACION="+encodeURIComponent(TXTOBSERVACION)+"&CMB1="+CMB1+"&CMB2="+CMB2+"&CMB3="+CMB3+"");
       ajax.onreadystatechange=function() {
    if (ajax.readyState==4)
    {


            document.getElementById('divalerta').innerHTML = ajax.responseText;
           document.getElementById('divalerta').style.display='none';
            document.getElementById('divalerta').style.height = "0px";
            if(document.getElementById('AVISOMOFICIADO'))
            {

                    if(document.getElementById('AVISOMOFICIADO').value=="yaexiste")
                    {

                            alert("HORARIO OCUPADO");
                         return;


                    }

                    if(document.getElementById('AVISOMOFICIADO').value=="")
                    {

                            alert("OPERACION EXITOSA");
                            limpiar();
                            return;


                    }
                    if(document.getElementById('AVISOMOFICIADO').value=="error")
                    {
                            alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
                            return false;
                    }
            }else{

                    alert("UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS");
                    return false;


            }

    }
    }

    
}
function Busqueda_Enter(key)
{

	if(key == 13) 
	{	
		usuarios('BUSCAR');
	}
}

</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
     <br>
     <table border="0" cellpadding="2" cellspacing="2" align="center" width="780" >    	
            <tr><td>Identificaci&oacute;n</td><td colspan="3"><table cellpadding="0" cellspacing="0" border=0><tr><td><input type="text" name="TXTIDENTIFICACION" id=TXTIDENTIFICACION size="20" maxlength="10" onChange="javascript:this.value=this.value.toUpperCase()" onKeyUp="javascript:Busqueda_Enter(event.keyCode)">&nbsp;<font color=red><label title='Required'>*</label></font>&nbsp;</td><td><img  style="cursor:pointer" id="buscarimgpersonal" src="img/iconos/buscar.png" title="Buscar" onClick="usuarios('BUSCAR')" /><img src="img/iconos/cargar.png" title="Busqueda Avanzada" onClick="BUSQUEDAPERSONAL()" style="cursor:pointer" ></td><td width=200><div id="procesando"></div></td></tr></table></td></tr>
            <tr><td>Docente</td><td ><input type="text" name ="TXTP_NOMBRE" id="TXTP_NOMBRE" size="80" ><input type="hidden" id="ID_PERSONAL">&nbsp;<font color='red'><label title='Required'>*</label></font></td></tr>
            <tr><td >Fecha</td><td ><input type=text id='dateArrival' name =TXTFECHA  onFocus="popUpCalendar(document.getElementById('dateArrival'),document.getElementById('dateArrival'),'dd-mm-yyyy');limpiar()" size="10">&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
            <tr><td>Hora Entrada</td><td><input type='text' name='HORAE' id='HORAE' size='5' maxlength='5'  >&nbsp;&nbsp;Hora Salida&nbsp;&nbsp;<input type='text' name='HORAS' id='HORAS' size='5' maxlength='5' >&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
            <tr><td>Grado</td><td><?php
         	$SQL = "select * from t_grados order by id_grado";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBGRADO' id='CMBGRADO'  >";
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"id_grado").">".mysql_result($BUSCAR_LAPSOS,$i,"grado")."</option>";
			}
			echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
          
         
             <tr><td>Cantidad de Alumnos</td><td><input type="text" name ="CANTIDAD" id="CANTIDAD" size="5" maxlength="3" >&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>

            <tr><td>Proyecto</td><td><?php
         	$SQL = "select * from t_proyectos order by proyecto";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBPROYECTO' id='CMBPROYECTO'  >";
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"id_proyecto").">".mysql_result($BUSCAR_LAPSOS,$i,"proyecto")."</option>";
			}
			echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
             <tr><td>Competencia</td><td><?php
         	$SQL = "select * from t_areacomp order by areacomp";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBAREACOMP' id='CMBAREACOMP'  >";
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"id_areacomp").">".mysql_result($BUSCAR_LAPSOS,$i,"areacomp")."</option>";
			}
			echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
             <tr><td>Area Tecnol&oacute;gica</td><td><?php
         	$SQL = "select * from t_areatecn order by areatecn";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBAREATECN' id='CMBAREATECN'  >";
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"id_areatecn").">".mysql_result($BUSCAR_LAPSOS,$i,"areatecn")." ".mysql_result($BUSCAR_LAPSOS,$i,"descripcion")."</option>";
			}
			echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>
              <tr><td>Herramienta Utilizada</td><td><?php
         	$SQL = "select * from t_herramientas order by herramienta";
			$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
			echo "<select name='CMBHERRAMIENTA' id='CMBHERRAMIENTA'  >";
			for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
			{
				echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"id_herramienta").">".mysql_result($BUSCAR_LAPSOS,$i,"herramienta")."</option>";
			}
			echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>

            <tr><td >Observaci&oacute;n</td><td ><input type=text id='TXTOBSERVACION' name =TXTOBSERVACION  size="80"></td></tr>


     </table>
      <table border="0" cellpadding="2" cellspacing="2" align="center" width="780" >
          <tr><td>Conoce y maneja las herramientas tecnol&oacute;gicas aplicadas seg&oacute;n la planificaci&oacute;n</td><td width="40%"><?php
            echo "<select name='CMB1' id='CMB1'  >";
            echo "<option value=2>SI</option>";
            echo "<option value=1>REGULAR</option>";
            echo "<option value=0>NO</option>";
            
            echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>

               <tr><td>Aplica estrategias pedag&oacute;gicas interactivas </td><td><?php
            echo "<select name='CMB2' id='CMB2'  >";
            echo "<option value=1>SI</option>";
            echo "<option value=0>NO</option>";
            echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>

     <tr><td>Demuestra compromiso com programa Aulas Virtualles </td><td><?php
            echo "<select name='CMB3' id='CMB3'  >";
            echo "<option value=1>SI</option>";
            echo "<option value=0>NO</option>";
            echo "</select>";
           ?>&nbsp;<font color=red><label title='Required'>*</label></font></td></tr>

     
             <tr><td colspan="2" align="left">&nbsp;</td></tr>
 <tr><td colspan="2" align="left"><input type="button" value="Limpiar" name="BOTON" id="reset" onClick="limpiar()"><input type="button" value="Guardar" name="SUBMIT" id="SUBMIT" onClick="guardar()"></td></tr>

</table>
       	<div id="resultado"></div>
  
   <BR>
 
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
