<link href="estilo.css" rel="stylesheet" type="text/css">
<form action="buscar.php" method="get"><div class="ordenar">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td height="36"> <input name="buscar" type="text" id="input" value="Buscar por cedula, nombre, email..." size="50" onfocus="if(this.value=='Buscar por cedula, nombre, email...')this.value='';" /><input name="Submit" type="submit" id="boton" onclick="enviar(form)" value="" /></td>
      <td width="2%" align="right">&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td align="right">
       </td>
    </tr>
  </table>
  </div>
</form>
