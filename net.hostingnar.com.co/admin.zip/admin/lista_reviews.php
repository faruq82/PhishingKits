<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista reviews</title>
<script language="javascript">
function MM_goToURL() { //v3.0
var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
function MM_openBrWindow(theURL,winName,features) { //v2.0
window.open(theURL,winName,features);
}
</script>
</head>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>

<?php  //include('header.php'); ?>

<div class="order"></div>
 <?php include('ordenar.php');?>



<?php 
//Imprecindible para saber la dirección y luego darla a las acciones
$urlactual= $_SERVER['REQUEST_URI'];
//echo $urlactual;
global $STYLECELDAS,$CABECERACELDAS;
// mySQL Table

    require('ceoconexion.php');
	$query = "select * from reviews";
    $result = mysql_query($query);
	mysql_query ("SET NAMES 'utf8'");
    $i = 0;

    while ($i < mysql_num_fields($result)) {
      $meta = mysql_fetch_field($result);
      $columns[$i] = $meta->name;
      $i++;
    }

   	echo "Lista de reviews <BR>";
      echo "<table cellspacing=\"2\" cellpadding=\"2\" border=\"0\" width=\"100%\" class='consulta'>\n";
   
    //for($i=1;$i<sizeof($columns);$i++) {
      
	  //echo "<td class='campos'><center><b>".$columns[$i]."</td>";
   // }
    echo "<th class='cabecera'><center>FECHA</th>";
	echo "<th class='cabecera'><center>NICK</th>";
	echo "<th class='cabecera'><center>NOMBRE</th>";
	echo "<th class='cabecera'><center>MENSAJE</th>";
	//echo "<th class='cabecera'><center>NOMBRE DEL ALUMNO</th>";
	//echo "<th class='cabecera'><center>EMAIL</th>";
	//echo "<th class='cabecera'><center>PAIS</th>";
	//echo "<th class='cabecera'><center>ESCUELA</th>";
	
    echo "<td class='cabecera'><center>Marcar Activo</td>\n";
	echo "<td class='cabecera'><center>Marcar Inactivo</td>\n";
	//echo "<td class='cabecera'><center>Enviar un Email</td>\n";
	echo "<td class='cabecera' ><center>Eliminar</td>\n";
   // echo "<td class='campos' align=\"center\" valign=\"middle\">Imprimir ticket</td></tr>\n";


    //Inicio de paginacion
    (!empty($_GET['pag'])) ? ($pag = $_GET['pag']) : ($pag = '1');
  
	$result = mysql_query("SELECT COUNT(*) FROM reviews"); 
list($total) = mysql_fetch_row($result);
$tampag = 24;
$reg1 = ($pag-1) * $tampag;
$result = mysql_query("select * from reviews ORDER BY id DESC  LIMIT $reg1, $tampag");

//Mostrar paginacion
	echo "<div class='paginacion'>";
		echo paginar($pag, $total, $tampag, "lista_reviews.php?pag=");	
	echo "</div>";
//Fin Mostrar paginacion
    
    
    
  //$query = "select * from entradas";
  // $result = mysql_query($query);
    $j=0;

    //while($row=mysql_fetch_array($result)) {
	if(mysql_num_rows($result)<0){
      //echo "<tr>";
      
       }else{  
	//for($i=1;$i<sizeof($columns);$i++) {
	for($i=0;$i<mysql_num_rows($result);$i++){
	
	
					if($i%2==0)
					{
						echo"<tr ".$STYLECELDAS.">";
						
					}else{
						echo"<tr ".$STYLECELDAS." bgcolor=#F2F9F9>";
					}
					
	$id_cli=mysql_result($result,$i,"id_cliente");
	$nnick = mysql_query("select * from cliente WHERE id=".$id_cli." ");
	
	if (mysql_result($result,$i,"status") == 'A')
		{
		//echo "<td bgcolor='#DBFFB7'><center>".$row[$columns[$i]]."</td>";} 
		echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"fecha")."</td>";
		
		echo "<td bgcolor='#DBFFB7'><center>".mysql_result($nnick,0,"nick")."</td>";
		echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"nombre")."</td>";
		echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"mensaje")."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"nombre")." ".mysql_result($result,$i,"apellido")."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($result,$i,"email")."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($nompais,0,"PAIS")."</td>";
		//echo "<td bgcolor='#DBFFB7'><center>".mysql_result($escuelas,0,"escuela")."</td>";
		}
	else
        	{
			//echo "<td bgcolor='#FFB9B9'><center>".$row[$columns[$i]]."</td>";
		echo "<td bgcolor='#FFB9B9'><center>".mysql_result($result,$i,"fecha")."</td>";
		
		echo "<td bgcolor='#FFB9B9'><center>".mysql_result($nnick,0,"nick")."</td>";
		echo "<td bgcolor='#FFB9B9'><center>".mysql_result($result,$i,"nombre")."</td>";
		echo "<td bgcolor='#FFB9B9'><center>".mysql_result($result,$i,"mensaje")."</td>";
		//echo "<td bgcolor='#FFB9B9'><center>".mysql_result($result,$i,"email")."</td>";
		//echo "<td bgcolor='#FFB9B9'><center>".mysql_result($nompais,0,"PAIS")."</td>";
		//echo "<td bgcolor='#FFB9B9'><center>".mysql_result($escuelas,0,"escuela")."</td>";
			}
      

	$j=$row[$columns[0]];
	$ID_USUARIOO=$ID_USUARIO;
	//echo "<td class='small'><center><a href='marcar_enviado.php?id=".$j."&from=".$urlactual."'><img src='./images/001_06.gif' alt='Marcar como Enviado' border='0' /></a>";
	//echo "<td class='small'><center><button class='boton' onClick=MM_openBrWindow('email2.php?id=".mysql_result($result,$i,"id")."','Detalles','scrollbars=no,menubar=no,toolbar=no,location=no,resizable=yes,width=570,height=500')><img src='./img/001_06.gif' alt='Marcar como Enviado' border='0' /></button>"; 
	echo "<td class='small'><center><a href='marcar_enviado2.php?id=".mysql_result($result,$i,"id")."&from=".$urlactual."'><img src='./img/001_06.gif' alt='Marcar como Enviado' border='0' /></a>";
	echo "<td class='small'><center><a href='marcar_en_espera2.php?id=".mysql_result($result,$i,"id")."&from=".$urlactual."'><img src='./img/001_29.gif' alt='Marcar en Espera' border='0' /></a>";
	//echo "<td class='small'><center><button class='boton' onClick=MM_openBrWindow('email2.php?id=".mysql_result($result,$i,"id")."','Detalles','scrollbars=no,menubar=no,toolbar=no,location=no,resizable=yes,width=420,height=500')><img src='./img/001_12.gif' alt='Mandar un correo' border='0' /></button>"; 
	echo "<td class='small'><center><a href='borrar22.php?id=".mysql_result($result,$i,"id")."&from=".$urlactual."'><img src='./img/001_49.gif' alt='Borrar' border='0' /></a>";
	//echo "<td class='small'><center><a href='imprimir.php?id=".$j."'><img src='./images/print.gif' alt='Imprimir guia' border='0' /></a>";
	
	}
	}
	echo "</table>";

	//Funcion de paginacion
  function paginar($actual, $total, $por_pagina, $enlace) {
  $total_paginas = ceil($total/$por_pagina);
  $anterior = $actual - 1;
  $posterior = $actual + 1;
  if ($actual>1)
    $texto = "<a href=\"$enlace$anterior\">&laquo; Anterior </a> ";
  else
    $texto = "<b>&laquo;</b> ";
  for ($i=1; $i<$actual; $i++)
    $texto .= "<a href=\"$enlace$i\">$i</a> ";
  $texto .= "<b>$actual</b> ";
  for ($i=$actual+1; $i<=$total_paginas; $i++)
    $texto .= "<a href=\"$enlace$i\">$i</a> ";
  if ($actual<$total_paginas)
    $texto .= "<a href=\"$enlace$posterior\"> Siguiente &raquo;</a>";
  else
    $texto .= "<b>&raquo;</b>";
  return $texto;
}

echo "<div class='paginacion' align='left'>";
		echo paginar($pag, $total, $tampag, "lista_reviews.php?pag=");	
	echo "</div>";
//Fin Funcion de paginacion

  // mySQL ends

mysql_free_result($result);


?>
</form>
</p>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>