<html>
<head>
<link rel="shortcut icon" href="favicon.ico">
<title>Aplicacion Web</title>
</head>
<FRAMESET border="0" frameBorder="NO" frameSpacing="0" rows= 0,*>

  <FRAME id="arriba" name="arriba" noresize="noresize" scrolling="no" src="vacio.php">

  <FRAME id=abajo name=abajo noResize src="login.php">

</FRAMESET><noframes></noframes>
 </html>