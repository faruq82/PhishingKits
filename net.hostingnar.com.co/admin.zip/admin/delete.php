<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "encuesta.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
?>	
<html >
<head>
<title>Tipos de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<?php $page = 'polls'; @include ("template.php"); ?>
	<tr>
		<td colspan="4">
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td align="center" height="25"><a href="encuesta.php" class="text">encuesta</a> > <b>Borrar Encuesta</b></td>
				</tr>
			</table>
			<br>
			<?php function complete () { ?>
			<table width="100%"  border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td align="center" height="25"><meta http-equiv="refresh" content="2;URL=encuesta.php"><b>Se a eliminado satisfactoriamente:</b></td>
				</tr>
			</table>
			<br>
			<?php } function ask () { ?>
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr align="center" class="text">
					<td height="25" colspan="2">�Est� seguro que desea borrar la encuesta<b><?= $_REQUEST['poll']; ?></b>?</td>
				</tr>
				<tr class="text">
					<td width="50%" height="25" align="center">
						<form action="delete.php" method="post" name="frmDelete">
						<input name="poll" type="hidden" value="<?= $_REQUEST['poll']; ?>">
						<input name="stage" type="hidden" value="2">
						<input name="btnSubmit" type="submit" class="text" value="Si, borrarla!">
						</form>
					</td>
					<td width="50%" align="center">
						<form action="encuesta.php" method="get" name="frmSave">
						<input name="btnSubmit" type="submit" class="text" value="No, Guardarla">
						</form>
					</td>
				</tr>
			</table>
			<?php
			
			}
			
			if (isset ($_REQUEST['stage'])) {
			
				include ("encueta/config.php");
				
				$myrow = mysql_fetch_array (mysql_query ("SELECT pollid, title FROM polls WHERE pollid='$_REQUEST[poll]'"));
				
				$results = mysql_query ("SELECT blockedid, polls FROM blocked WHERE polls LIKE '%$myrow[title]%'");
				$numrows = mysql_num_rows ($results);
				
				if ($numrows > 0) {
				
					while ($blockrow = mysql_fetch_array ($results)) {
					
						$polls = ereg_replace ($myrow['title'].";", "", $blockrow['polls']);
						
						mysql_query ("UPDATE blocked SET polls='$polls' WHERE blockedid='$blockrow[blockedid]'");
						
					}
						
					mysql_query ("DELETE FROM blocked WHERE polls=''");
				
				}
				
				mysql_query ("DELETE FROM polls WHERE pollid='$_REQUEST[poll]'");
				mysql_query ("DELETE FROM options WHERE pollid='$_REQUEST[poll]'");		
				mysql_query ("DELETE FROM ip WHERE title='$myrow[title]'");
				
				$pollrows = mysql_num_rows (mysql_query ("SELECT pollid FROM polls"));
				
				if ($pollrows == 0) {
				
					mysql_query ("TRUNCATE blocked");
					mysql_query ("TRUNCATE ip");
					
				}
			
				complete ();
				
			} else {
			
				ask ();
				
			}
			
			?>
		</td>
	</tr>
</table>
 <?php  
		piecera($PRIVILEGIO);
?>
</body>
</html>