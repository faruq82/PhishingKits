<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "registrados.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<?
include("../config.php");
include("../functions/index.php");
?>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<html>
<head><title>Usuarios</title>
</head><!--


AQUI PUEDES PONER CODIGOS HTML


-->
<?php

// Usuarios.php

	$query = mysql_query("SELECT * FROM configuracion");
	$datos = mysql_fetch_array($query);
	
	//include("estilos/".$datos[estilo]);
	
	echo"<body>";
	if(!$_GET[id]){ include("menu.php"); }  else {
	if(file_exists("$_GET[id].php")){
		include("$_GET[id].php");
	} else {
		error(_404_,"0");
	}
	}
	

?>
<!--
<?php  
		piecera($PRIVILEGIO);
?>

AQUI PUEDES PONER CODIGOS HTML


--></body></html>