<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "registrados.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>


<?php

include("../config.php");
include("../pfvariables.php");

if($_COOKIE[id] && $_COOKIE[nick] && $_COOKIE[contrasena]){

# Mensajes

$msg_query = mysql_query("SELECT * FROM mensajes WHERE nuevo='0' and destinatario='$_COOKIE[nick]'");
$nuevos = mysql_num_rows($msg_query);

$msg2_query = mysql_query("SELECT * FROM mensajes WHERE destinatario='$_COOKIE[nick]'");
$total = mysql_num_rows($msg2_query);

 #---

echo _BIENVENIDO." <b>".$_COOKIE[nick]."</b><br><br>";
echo"- <a href=".$pagina."?".$get."=perfil>"._EDITAR_PERFIL."</a><br>";
if($puntos == "si"){

echo"- <a href=\"javascript:;\" onClick=\"window.open('puntos.php?show=puntos','','resizable=no, height=120, width=300,screenX=250,screenY=300,top=200,left=250');\">"._PUNTOS_TITULO."</a><br>";

}
echo"- <a href=".$pagina."?".$get."=mensajes>"._MENSAJES_PRIVADOS."</a> (".$nuevos."/".$total.")<br>";
echo"- <a href=desconectar.php>"._DESCONECTAR."</a><br>";



if($puntos == "si"){

echo "<br><b>"._PUNTOS_TITULO."</b><br>";

	if($_COOKIE[id]){
	 $infouser = mysql_query("SELECT * FROM usuarios WHERE id='$_COOKIE[id]'");
	 $info = mysql_fetch_array($infouser);
	 
	$query = mysql_query("SELECT * FROM puntos");
	while($datos = mysql_fetch_array($query)){

 		if($info[puntos] >= $datos[minimo]){
		
			echo"- <a href=".$datos[pagina]." target=_blank>".$datos[texto]."</a><br>";
	
	}
	}
	
	$query = mysql_query("SELECT * FROM puntos ORDER BY minimo ASC LIMIT 1");
	$datos = mysql_fetch_array($query);
	$minimopuntos = $datos[minimo];
	
	if($info[puntos] < $minimopuntos){ echo _NECESITAS_MINIMO_PUNTOS_1_." <b>".$minimopuntos."</b> "._NECESITAS_MINIMO_PUNTOS_2_; }
}
}
} else {

 echo _BIENVENIDO.", <b>"._ANONIMO."</b><br><br>";
 echo"<form name=\"Login\" method=\"post\" action=\"entrar.php\">
  "._USUARIO_LOGIN."<br>
  <input type=\"text\" name=\"username\" id=\"username\" value=\"".$_GET[nick]."\">
  <br>
  "._CONTRASENA_LOGIN." <br>
  <input type=\"password\" name=\"password\" id=\"password\" value=\"".$_GET[contrasena]."\">
  <br>
  <br>
  <input type=\"submit\" name=\"entrar\" value=\""._LOGIN."\"><br><br>
  - <a href=".$pagina."?".$get."=registro>"._REGISTRAR."</a><br>
  - <a href=".$pagina."?".$get."=contrasena>"._CONTRASENA."</a>
</form>";

}


//echo"<hr>";
//pf_Stats();
//echo"<hr>";
//pf_Online();
//echo"<hr>";
?>
<?php  
		piecera($PRIVILEGIO);
?>