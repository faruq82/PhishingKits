<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ceoconexion.php");
	function REDIRIGIR($URL)
	{
		echo "
			<script language='javascript'>
				document.location='".$URL."';
			</script>
		";
	}	
	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
			
				alert('".$MSJ."');
				
			</script>
		";
	}
	
	
	
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	//$url = $_SERVER["REQUEST_URI"] ;
	$url = "descargas.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	
			$ID_AULA = $_GET['ID_AULA'];
			$ID_PERSONAL = $_GET['ID_PERSONAL'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from alumnos_online where id =".$ID_AULA." AND status='Pagado' AND escuela =".$ID_PERSONAL." " );
		
					if(mysql_num_rows($SQL_CHK_EXISTENCIA)==0)
						{
							MESSAGE('ESCUELA PENDIENTE DE PAGO... COMUNIQUESE A CONTROL DE ESTUDIO.');
							REDIRIGIR('inicio.php');
							
						}else{
						$escuela=$ID_PERSONAL;
						
						    $SQLL= "SELECT * FROM t_actividades2 WHERE id_actividad='".$escuela."' ";
							$QUERYY= mysql_query($SQLL) or die("error es busqueda de archivos de la escuela");
							
							if(mysql_num_rows($QUERYY)==0)
							{
							MESSAGE("ARCHIVOS NO disponible solicite soporte");
							REDIRIGIR('inicio.php');
							
	
							}else{
								//$urldes=mysql_result($QUERYY,0,"url");
								//REDIRIGIR("$urldes");	
								//header ("Location: http://www.kitimprimibles.com/kitoystore/TOY_1.rar"); // esta es la ruta del nombre del archivo a redirigir o descargar
								//header("Content-type: application/force-download");
//$id=$_GET['id'];
switch($_GET['id']) 
{ 
case '': 
header ("Location: http://www.ministerioredil.org/campus/"); // esta sera la pagina que aparecera al abrir el archivo por defecto
break;



case "audioprofetica1":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/bienvenida Escuela de Intercesion Profetica.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "audioprofetica2":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/instructivo Escuela de Intercesion Profetica.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica3":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 1 LA INTERCESION PROFETICA UN ESTILO DE VIDA.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica4":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 2 El Codigo de Vida del IP.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica5":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 3. LOS PRINCIPIOS QUE REIGEN LA INTERCESION PROFETICA.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "audioprofetica6":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 4. EL PODER DE LA INTERCESION PROFETICA.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica7":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 5. LA IDENTIDAD Y EL PROPOSITO DEL INTERCESOR PROFETICO.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica8":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 6. EL PROCESO DE FORMACION DE IP.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica9":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 7. LAS ETAPAS DEL PROCESO DE FORMACION.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica10":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 8. EL MOVER DE LOS DONES DEL ESPIRITU EN EL IP.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "audioprofetica11":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 9. LA DINAMICA DE LA INTERCESION PROFETICA.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica12":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 10. LA ORACION EN LA INTERCESION PROFETICA.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica13":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 11. LA PROCLAMACION EN LA INTERCESION PROFETICA.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "audioprofetica14":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MODULO 12. LOS ENEMIGOS DEL INTERCESOR PROFETICO.mp3"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "manualprofetica1":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/audioescuip/MANUAL PRIMER NIVEL 2015 La Dinamica de la Intercesion Profetica.pdf"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "laminaprofetica1":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/ESCUELA DE INTERCESION PROFETICA.pptx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofetica1":
header ("Location: http://www.ministerioredil.org/evaluativos2015/modulo1-nivel1.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofetica2":
header ("Location: http://www.ministerioredil.org/evaluativos2015/modulo1-nivel2.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica3":
header ("Location: http://www.ministerioredil.org/evaluativos2015/modulo1-nivel3.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica4":
header ("Location: http://www.ministerioredil.org/evaluativos2015/modulo1-nivel4.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica5":
header ("Location: http://www.ministerioredil.org/evaluativos2015/modulo1-nivel5.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica6":
header ("Location: http://www.ministerioredil.org/evaluativos2015/modulo1-nivel6.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofetica7":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelainter/Modulo-7.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofetica8":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelainter/Modulo-8.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica9":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelainter/Modulo-9.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica10":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelainter/Modulo-10.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica11":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelainter/Modulo-11.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofetica12":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelainter/Modulo-12.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar



case "evaluativoprofeta1":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-1.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta2":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-2.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta3":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-3.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta4":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-4.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta5":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-5.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofeta6":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-6.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


case "evaluativoprofeta7":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-7.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta8":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-8.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta9":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-9.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta10":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-10.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta11":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-11.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "evaluativoprofeta12":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/evaescuelaprofeta/Modulo-12.docx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar



case "laminasprofetas":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/ESCUELA PARA PROFETAS.pptx"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar

case "manuelprofetas":
header ("Location: http://www.cecip.com.ve/escuelaonlineaudios/escuelaprofetas2014/MANUAL DE ESCUELA PARA PROFETAS.pdf"); // esta es la ruta del nombre del archivo a redirigir o descargar
header("Content-type: application/force-download");
break; // y este para terminar


default: 
header ("Location: http://www.ministerioredil.org/campus/"); // esto al igual que el primero es el header por default que aparecera al acceder al archivo directamente osea redirigira para alla si quieren accesar al archivo directamente desde el navegador 
} 

							}
						}	
?>