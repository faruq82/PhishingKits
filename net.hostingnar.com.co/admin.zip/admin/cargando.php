<?php 	
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	include('ordenconfig.php');

if($_POST["TXTUSUARIO"] && $_POST["TXTCONTRASENA"]){	
	
	$TXTCONTRASENA= $_POST['TXTCONTRASENA'];
	$TXTUSUARIO= $_POST['TXTUSUARIO'];
	$TXTCONTRASENA= md5($TXTCONTRASENA,false);
	$SQL= "SELECT * FROM t_usuarios WHERE contrasena = '".$TXTCONTRASENA."' AND  nombre_usuario = '".$TXTUSUARIO."' ";
	$QUERY= mysql_query($SQL) or die("error al tomar el nombre de sesion");
	
	if(mysql_num_rows($QUERY)==0)
	{
		MESSAGE("Usuario no Registrado");
		REDIRIGIR("login.php");
	
	}else{
	
		$ID_USUARIO= mysql_result($QUERY,0,"id_usuario");
		$SQLA = array();
		$SQLA[]=$SQL;
		unset($SQLA);
	
	}
	
	if(isset($ID_USUARIO))
	{
		 $_SESSION['ID_USUARIO2']= $ID_USUARIO;
		 REDIRIGIR("inicio.php");		
		 
	}else{
	
		MESSAGE("Error al crear la sesion");
		REDIRIGIR("login.php");
	}

} else {

 if($_GET["TXTUSUARIO"] && $_GET["TXTCONTRASENA"]){
	$TXTCONTRASENA= $_GET['TXTCONTRASENA'];
	$TXTUSUARIO= $_GET['TXTUSUARIO'];
	$TXTCONTRASENA= md5($TXTCONTRASENA,false);
	$SQL= "SELECT * FROM t_usuarios WHERE contrasena = '".$TXTCONTRASENA."' AND  nombre_usuario = '".$TXTUSUARIO."' ";
	$QUERY= mysql_query($SQL) or die("error al tomar el nombre de sesion");
	if(mysql_num_rows($QUERY)==0)
	{
		MESSAGE("Usuario no Registrado getttt");
		REDIRIGIR("login.php");
	
	}else{
	
		$ID_USUARIO= mysql_result($QUERY,0,"id_usuario");
		$SQLA = array();
		$SQLA[]=$SQL;
		unset($SQLA);
	
	}
	
	if(isset($ID_USUARIO))
	{
		 $_SESSION['ID_USUARIO2']= $ID_USUARIO;
		 REDIRIGIR("inicio.php");		
		 
	}else{
	
		MESSAGE("Error al crear la sesion");
		REDIRIGIR("login.php");
	}

  }

}		
	
?>

