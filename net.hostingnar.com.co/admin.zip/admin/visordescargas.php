<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>Archivos a descargar CECIP ONLINE</title>
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table width="780" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><?php

	$archivo = $_GET['archivo'];
	$cedula = $_GET['cedula'];
	$escuela = $_GET['escuela'];
	require('ceoconexion.php');
  
		//$sql = "UPDATE alumnos_online SET ci=$cedula where id='$id'";
		//$result = mysql_query($sql);
		
		$alumno = mysql_query("select * from alumnos_online WHERE ci=".$cedula." AND escuela =".$escuela." ");
		$escuelaid =mysql_result($alumno,0,"id");
		//$escuela =mysql_result($alumno,0,"ci");
		//$nombre =mysql_result($alumno,0,"nombre")." ".mysql_result($alumno,0,"apellido");
	
	
	
	//$escuela= mysql_result($alumno,0,"escuela");
	$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");
	echo " <br><strong>Nombre de la Escuela:</strong> ".mysql_result($escuelas,0,"escuela");
	//$archivo =mysql_result($escuelas,0,"fichero");
	
		include($archivo);

?></td>
  </tr>
</table>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>