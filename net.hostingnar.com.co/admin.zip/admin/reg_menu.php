<?php 
		session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
	$PROCESO = $_GET['PROCESO'];
	$TXTNOMBRE = $_POST['TXTNOMBRE'];
	$CATEGORIA = $_POST['CATEGORIA'];
	$DESCRIPCION = $_POST['DESCRIPCION'];
	$TXTURL = $_POST['TXTURL'];
//	$TXTIMAGEN = $_POST['TXTIMAGEN'];
	$NOMBRE_ARCHIVOPHP = $_FILES['FICHEROPHP']['name']; 
	$TIPO_ARCHIVOPHP = $_FILES['FICHEROPHP']['type']; 
	$DIRECTORIOPAG="";
	//$NOMBRE_ARCHIVOIMAGEN = $_FILES['FICHEROIMAGEN']['name']; 
//	$TIPO_ARCHIVOIMAGEN = $_FILES['FICHEROIMAGEN']['type']; 
//	$DIRECTORIOIMAGEN="img/menu/";
	
	
	$BOTON = $_POST['BOTON'];
	
	if(!isset($BOTON))
	{	
		$BOTON = $_GET['BOTON'];
		if(!isset($BOTON))
		{
			$BOTON = "Guardar";
		}else{
			$BOTON = $BOTON;
			
		}
		
	}else{
		$BOTON = $BOTON;
		
	}
	
		function LISTAR_PRIVILEGIOS()
	{
		global $STYLECELDAS, $CABECERACELDAS;
		echo "<b>Lista de Opciones.</b><br><hr align = center width=780><br>";
		$QUERY_LISTA_PRIVILEGIOS = mysql_query("select * from t_privilegios order by categoria,nombre");
		if(mysql_num_rows($QUERY_LISTA_PRIVILEGIOS)==0)
		{
			echo "<b>No existen opciones registradas.</b>";
		}else{
				
				echo "<table align=center width=780 border = 0 cellpadding = 2 cellspacing = 2><tr class='cabecera' ><th width=50>ID. Privilegio</th><th width=240>Nombre</th><th width=240>url</th><th width=150>Categoria</th><th width=50>Act.</th><th width=50>Elim.</th></tr>";
				for($i=0;$i<mysql_num_rows($QUERY_LISTA_PRIVILEGIOS);$i++)
				{
					if($i%2==0)
					{
						echo "<tr ".$STYLECELDAS."><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"id_privilegio")."</td><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"nombre")."</td><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"url")."</td><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"categoria")."</td><td  align = center><a href=reg_menu.php?BOTON=Modificar&ID_PRIVILEGIO=".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"id_privilegio")."><img src=img/iconos/actualizar.png border=0></a></td><td  align = center><a href=reg_menu.php?BOTON=Eliminar&ID_PRIVILEGIO=".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"id_privilegio")."><img src=img/iconos/eliminar_1.png border=0></a></td></tr>";
					}else{
						echo "<tr ".$STYLECELDAS." bgcolor=#F2F9F9><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"id_privilegio")."</td><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"nombre")."</td><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"url")."</td><td align=center>".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"categoria")."</td><td  align = center><a href=reg_menu.php?BOTON=Modificar&ID_PRIVILEGIO=".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"id_privilegio")."><img src=img/iconos/actualizar.png border=0></a></td><td  align = center><a href=reg_menu.php?BOTON=Eliminar&ID_PRIVILEGIO=".mysql_result($QUERY_LISTA_PRIVILEGIOS,$i,"id_privilegio")."><img src=img/iconos/eliminar_1.png border=0></a></td></tr>";
					}
				}
			
			echo "</table>";
			
		}
		echo "<br>";

	}
	
?>
<html >
<head>
<title>Registro de Opciones del Menu</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>


<script type="text/javascript">
</script>

<script language="javascript">
var er_texto = /^[a-zA-Z\.+\/+\_+\s+\u00d1+]{1,50}$/;
	function validar()
	{
	
		_TXTNOMBRE= document.getElementById('TXTNOMBRE').value;
		if(_TXTNOMBRE == "")
		{
			ALERT("ERROR EN EL NOMBRE");
			return false;
		}
		_TXTCATEGORIA= document.getElementById('CATEGORIA').value;
		if(_TXTCATEGORIA == "")
		{
			ALERT("ERROR EN LA CATEGORIA");
			return false;
		}
		_TXTDESCRIPCION= document.getElementById('DESCRIPCION').value;
		if(_TXTDESCRIPCION == "")
		{
			ALERT("ERROR EN LA DESCRIPCION");
			return false;
		}
	
	
	
		
	}
	function limpiar()
		{
			document.location="reg_menu.php";
		}
</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
	
  <BR>
    	
    	<form action ="<?php echo $URL?>" method="post" enctype="multipart/form-data" onSubmit="return validar()">
    	<table align="center" border="0" cellpadding="2" cellspacing="2" width="780">
        	
         
            <tr><td>Nombre</td><td><input type="text" name ="TXTNOMBRE" id="TXTNOMBRE" size="60" maxlength="50"  >&nbsp;<font color='red'><label title='Requerido'>*</label></font></td></tr>
            <tr><td>Url Path Destino</td><td><input type="text" name ="TXTURL" id="TXTURL" size="60" maxlength="25" ></td></tr>
             <?php HABILITAR('TXTURL',0);?>
              <tr><td>Cargar Url Path Destino</td><td><input name="FICHEROPHP"  id="FICHEROPHP" type="file" size="60"></td></tr>
             	 <tr><td>Categoria</td><td><input type="text" name ="CATEGORIA" id="CATEGORIA" size="60" maxlength="50"  >&nbsp;<font color='red'><label title='Requerido'>*</label></font></td></tr>
		 <tr><td>Descripci&oacute;n</td><td><textarea name ="DESCRIPCION" id="DESCRIPCION" cols=67 maxlength="200"></textarea>&nbsp;<font color='red'><label title='Requerido'>*</label></font></td></tr> 
              <tr><td colspan="2"><input type="hidden" name ="ACCION" id="ACCION"></td></tr>
              <tr><td colspan="2"><input type="hidden" name ="ID_PRIVILEGIO" id="ID_PRIVILEGIO" ></td></tr>
         
              
              <tr><td colspan="2" align="left"><input type="reset" value="Limpiar" onClick="limpiar()"><input type="submit" value="<?php echo $BOTON?>" name="BOTON" id="BOTON"></td></tr>
        </table>
        </form>
              
              
        <?php
		$BOTON = $_POST['BOTON'];
		if(!isset($BOTON))
		{	
			$BOTON = $_GET['BOTON'];
			if(!isset($BOTON))
			{
				$BOTON = "";
			}else{
				$BOTON = $BOTON;
				
			}
			
		}else{
			$BOTON = $BOTON;
			
		}
		$ACCION = $_POST['ACCION'];
		if($ACCION==1)
		{
			$ID_PRIVILEGIO = $_POST['ID_PRIVILEGIO'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from t_privilegios where id_privilegio =".$ID_PRIVILEGIO."");
			
			
			if($NOMBRE_ARCHIVOPHP!="")
			{
				if(!strpos($NOMBRE_ARCHIVOPHP,"php")) 
				{ 
					MESSAGE( "Se permiten solo archivos .php.");
					$NOMBRE_ARCHIVOPHP = mysql_result($SQL_CHK_EXISTENCIA,0,"URL");
				}else{ 
				/*	if (!move_uploaded_file($_FILES['FICHEROPHP']['tmp_name'],$DIRECTORIOPAG.$NOMBRE_ARCHIVOPHP))
					{ 
						    MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION. SOLO ARCHIVOS .php");
						  	$NOMBRE_ARCHIVOPHP = mysql_result($SQL_CHK_EXISTENCIA,0,"URL");
					}
					*/
				}
			}else{ 
			
					$NOMBRE_ARCHIVOPHP = mysql_result($SQL_CHK_EXISTENCIA,0,"URL");
			}
		/*
			if($NOMBRE_ARCHIVOIMAGEN!="")
			{
				if(!(strpos($TIPO_ARCHIVOIMAGEN,"jpeg"))) 
				{ 
					MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION. SOLO ARCHIVOS .jpeg.");
					$NOMBRE_ARCHIVOIMAGEN= mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGEN");
				}else{ 
					if (!move_uploaded_file($_FILES['FICHEROIMAGEN']['tmp_name'],$DIRECTORIOIMAGEN.$NOMBRE_ARCHIVOIMAGEN))
					{ 
						  MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION.."); 
						  $NOMBRE_ARCHIVOIMAGEN= mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGEN");
					} 
				}
			}else{ 
		
				$NOMBRE_ARCHIVOIMAGEN = mysql_result($SQL_CHK_EXISTENCIA,0,"IMAGEN");
			}
			*/
			
			
			$SQL=array();
			$SQL[] = "UPDATE t_privilegios SET nombre = '".$TXTNOMBRE."', url ='".$NOMBRE_ARCHIVOPHP."', imagen ='xxx', imagen2 ='_xxx', categoria = '".$CATEGORIA."',descripcion = '".$DESCRIPCION."' WHERE id_privilegio = ".$ID_PRIVILEGIO."";
			
			if(CORRER_TRANSACCION($SQL)==1) 
			{
				 MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION.");
			}else{
				
				 MESSAGE("OPERACION REALIZADA CON EXITO.");
				
			}
			unset($SQL);
			ASIG_VALOR(0,0,"ACCION","");
			ASIG_VALOR(0,0,"ID_PRIVILEGIO","");
			echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
		
			$BOTON = "";
			
		}
		if($ACCION==2)
		{
			$ID_PRIVILEGIO = $_POST['ID_PRIVILEGIO'];
			$SQL=array();
			$SQL[] = "DELETE FROM t_privilegios WHERE id_privilegio = ".$ID_PRIVILEGIO."";
			if(CORRER_TRANSACCION($SQL)==1) 
			{
				 MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION.");
			}else{
				
				 MESSAGE("OPERACION REALIZADA CON EXITO.");
				
			}
			unset($SQL);
			ASIG_VALOR(0,0,"ACCION","");
			ASIG_VALOR(0,0,"ID_PRIVILEGIO","");
			
			echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			$BOTON = "";
		}
		if($BOTON=="Eliminar")
		{
			$ID_PRIVILEGIO = $_GET['ID_PRIVILEGIO'];
			$SQL_CHK_EXISTENCIA =mysql_query("select * from t_privilegios where id_privilegio =".$ID_PRIVILEGIO."");
			ASIG_VALOR(0,0,"TXTNOMBRE",mysql_result($SQL_CHK_EXISTENCIA,0,"nombre"));
			ASIG_VALOR(0,0,"TXTURL",mysql_result($SQL_CHK_EXISTENCIA,0,"url"));
			
			ASIG_VALOR(0,0,"ID_PRIVILEGIO",mysql_result($SQL_CHK_EXISTENCIA,0,"id_privilegio"));
			ASIG_VALOR(0,0,"DESCRIPCION",mysql_result($SQL_CHK_EXISTENCIA,0,"descripcion"));
			ASIG_VALOR(0,0,"CATEGORIA",mysql_result($SQL_CHK_EXISTENCIA,0,"categoria"));
			ASIG_VALOR(0,0,"ACCION","2");
			
			
		}
		if($BOTON=="Modificar")
		{
			$ID_PRIVILEGIO = $_GET['ID_PRIVILEGIO'];
			$SQL_CHK_EXISTENCIA = mysql_query("select * from t_privilegios where id_privilegio =".$ID_PRIVILEGIO."");
			ASIG_VALOR(0,0,"TXTNOMBRE",mysql_result($SQL_CHK_EXISTENCIA,0,"nombre"));
			ASIG_VALOR(0,0,"TXTURL",mysql_result($SQL_CHK_EXISTENCIA,0,"url"));
			ASIG_VALOR(0,0,"ID_PRIVILEGIO",mysql_result($SQL_CHK_EXISTENCIA,0,"id_privilegio"));
			ASIG_VALOR(0,0,"DESCRIPCION",mysql_result($SQL_CHK_EXISTENCIA,0,"descripcion"));
			ASIG_VALOR(0,0,"CATEGORIA",mysql_result($SQL_CHK_EXISTENCIA,0,"categoria"));
			ASIG_VALOR(0,0,"ACCION","1");
		
		}
		if($BOTON=="Guardar")
		{
		
		
			$SQL_CHK_EXISTENCIA = mysql_query("select * from t_privilegios where  url = '$NOMBRE_ARCHIVOPHP'");
		
			if(mysql_num_rows($SQL_CHK_EXISTENCIA)==0)
			{
			
			
			
				 
				if($NOMBRE_ARCHIVOPHP!="")
				{
					if(!strpos($NOMBRE_ARCHIVOPHP,"php")) 
					{ 
						MESSAGE( "Se permiten solo archivos .php.");
						$NOMBRE_ARCHIVOPHP="";
					}else{ /*
						if (!move_uploaded_file($_FILES['FICHEROPHP']['tmp_name'],$DIRECTORIOPAG.$NOMBRE_ARCHIVOPHP))
						{ 
							  MESSAGE( "OCURRIO UN ERROR DURANTE LA OPERACION. SOLO ARCCHIVOS .php"); 
							  $NOMBRE_ARCHIVOPHP="";
						} */
					}
				} 

				/*
				if($NOMBRE_ARCHIVOIMAGEN!="")
				{
					if(!(strpos($TIPO_ARCHIVOIMAGEN,"jpeg"))) 
					{ 
						MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION. SOLO ARCHIVOS .jpg");
						$NOMBRE_ARCHIVOIMAGEN="";
					}else{ 
						if (!move_uploaded_file($_FILES['FICHEROIMAGEN']['tmp_name'],$DIRECTORIOIMAGEN.$NOMBRE_ARCHIVOIMAGEN))
						{ 
							  MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION."); 
							  $NOMBRE_ARCHIVOIMAGEN="";
						} 
					}
				} 
				*/
				
				$SQL=array();
				$SQL[] = "INSERT INTO t_privilegios (nombre,url, imagen, imagen2,categoria,descripcion) VALUES ('".$TXTNOMBRE."','".$NOMBRE_ARCHIVOPHP."', 'xxx', '_xxx','".$CATEGORIA."','".$DESCRIPCION."');";
				if(CORRER_TRANSACCION($SQL)==1) 
					{
						 MESSAGE("OCURRIO UN ERROR DURANTE LA OPERACION.");
					}else{
					
						 MESSAGE("OPERACION REALIZADA CON EXITO.");
						
					}
			unset($SQL);
				echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			}else{
				MESSAGE('ESTE REGISTRO YA SE ENCUENTRA ALMACENADO');
			}
			
			
		}
?> 

  <?php LISTAR_PRIVILEGIOS(); 
		piecera($PRIVILEGIO);
?>

</body>
</html>