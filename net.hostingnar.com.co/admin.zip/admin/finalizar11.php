<?php
ob_start("ob_gzhandler");
session_start(); 
$carro=$_SESSION['carro']; 
?>
<html>
<head>
<title>REPORTE DE PAGO:::: prefabricados y agregados KAIROS C.A</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="style.css" rel="stylesheet" type="text/css">
<script src="AC_RunActiveContent.js" type="text/javascript"></script>
<style type="text/css">
<!--
.Estilo19 {color: #000000; font-weight: bold; }
.Estilo20 {color: #000000}
-->
</style>
<script language="javascript"> 
function verifica(){

    if(document.form.bauche.value == ""){ 
 
        alert("Debe Ingresar el Numero del pago"); 
 
        document.form.bauche.focus(); 
 
       return false;
    }
	
	    if(document.form.monto.value == 0){ 
 
        alert("Debe Ingresar el el monto del pago"); 
 
        document.form.monto.focus(); 
 
       return false;
    }
	
		    if(document.form.banco.value == ""){ 
 
        alert("Debe Seleccionar el Banco"); 
 
        document.form.banco.focus(); 
 
       return false;
    }
			    if(document.form.tipodeposito.value == ""){ 
 
        alert("Debe Seleccionar la forma de pago"); 
 
        document.form.tipodeposito.focus(); 
 
       return false;
    }

 }				
				
</script>
</head>

<body bottommargin="0" leftmargin="0" rightmargin="0" topmargin="0" bgcolor="#29353E" >
<table width="780" height="100%"  border="0" align="center" cellpadding="0" cellspacing="0">
  
  <tr>
    <td height="163" align="left" valign="top"><table width="780" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td>
<script type="text/javascript">
AC_FL_RunContent( 
'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0','width','780','height','163','src','35cabinet.swf','quality','high','pluginspage','http://www.macromedia.com/go/getflashplayer','movie','35cabinet','menu','false'); //end AC code
</script>
<noscript>		
		<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" width="780" height="163">
          <param name="movie" value="35cabinet.swf">
          <param name="quality" value="high"><param name="LOOP" value="false">
          <embed src="35cabinet.swf" width="780" height="163" loop="false" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>
        </object></noscript></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="81" align="left" valign="top"><table width="780" height="163" border="0" cellpadding="0" cellspacing="0">
      <tr align="left" valign="top">
        <td><img src="baner.jpg" width="780" height="163"></td>
        </tr>
    </table></td>
  </tr>
  <tr bgcolor="454F56">
    <td height="59" align="left" valign="top"><table height="55" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr align="center" valign="middle">
        <td width="105" background="images/q_bg1.gif"><a href="index.php" class="qmnu">INICIO</a></td>
        <td width="10">&nbsp;</td>
        <td width="105" background="images/q_bg1.gif"><a href="nosotros.php" class="qmnu">QUIENES SOMOS</a></td>
        <td width="8">&nbsp;</td>
        <td width="105" background="images/q_bg1.gif"><a href="servicios.php" class="qmnu">SERVICIOS</a></td>
        <td width="8">&nbsp;</td>
        <td width="105" background="images/q_bg1.gif"><a href="galeria/index.php" class="qmnu">GALERIA</a></td>
        <td width="8">&nbsp;</td>
        <td width="105" background="images/q_bg1.gif"><a href="productos.php" class="qmnu">PRODUCTOS</a></td>
        <td width="8">&nbsp;</td>
        <td width="105" background="images/q_bg1.gif"><a href="cotizacion.php" class="qmnu">COTIZACION</a></td>
        <td width="8" >&nbsp;</td>
        <td width="100" background="images/q_bg1.gif"><a href="contacto.php" class="qmnu">CONTACTANOS</a></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td align="left" valign="top"><table width="780" height="208%" border="0" cellpadding="0" cellspacing="0">
      <tr align="left" valign="top">
        <td ><table width="509" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <th width="10" scope="row">&nbsp;</th>
            <td width="499"><?php

include("config.php");
include("pfvariables.php");

if($_COOKIE[id] && $_COOKIE[nick] && $_COOKIE[contrasena]){

# Mensajes

$resp1 = mysql_query("select * from usuarios where nick='$_COOKIE[nick]'") ;
$datos1 = mysql_fetch_array($resp1) ;

 #---

echo" <table width='100%' border='0' cellspacing='0' cellpadding='0' align='center'> ";
             echo" <tr>";
                echo"<td width='100'>";
				echo " Cliente: <b>&nbsp;".$datos1[nombre]."</b>&nbsp;&nbsp;<a href=desconectar.php >Cerrar Sesi�n</a></td>";
             
              echo" </tr>";
            echo"</table><br>";
			
			}
			?>
			</td>
          </tr>
        </table></td>
      </tr>
      <tr align="left" valign="top">
        <td ><br>
        <h1 align="center">FINALIZAR COMPRA </h1>
        <br>
		  <br>
		
		 </td>
      </tr>
      <tr align="left" valign="top">
        <td ><style type="text/css">
<!--
.prod { font-family: Verdana, Arial, Helvetica, sans-serif; 
 font-size: 9px; 
 color: #333333; 
}
-->
</style>
          <?
include("config.php");
include("login.php");

if($_POST[editar]){

									$articulos =$_POST["producto"];
									$fecha= $_POST["dia"] . " " . $_POST["mes"] . " " . $_POST["ano"] ;
									$email=$_POST["email"] ;
									mysql_query("INSERT INTO pagos (codcotiza,articulos,total,cliente,tipopago,bauchue,fecha) VALUES ('".$_POST["cuponpedido"]."','".$articulos."','".$_POST["total"]."','".$_POST["nombre"]."','".$_POST["tipodeposito"]."','".$_POST["bauche"]."','".$fecha."')");
									
									//Estoy recibiendo el formulario, compongo el cuerpo
									$cuerpo = "Formulario de Pago \n\n\n";
									$cuerpo = "===== INFORMACION DE CLIENTE ===== \n\n";
									$cuerpo .= "Nombre del Cliente: " . $_POST["nombre"] . "\n";
									$cuerpo .= "Direccion: " . $_POST["direccion"] . "\n";
									//$cuerpo .= "Cedula o Rif: " . $_POST["cedula"] . "\n";
									$cuerpo .= "Email: " . $_POST["email"] . "\n";
									$cuerpo .= "Tipo de Pago: " . $_POST["tipodeposito"] . "\n";
									$cuerpo .= "Banco: " . $_POST["banco"] . "\n";
									//$cuerpo .= "Su numero de cuenta: " . $_POST["sucuenta"] . "\n";
									$cuerpo .= "Fecha de Deposito: " . $_POST["dia"] . " " . $_POST["mes"] . " " . $_POST["ano"] ."\n";
									$cuerpo .= "Monto: " . $_POST["moneda"] ." ". $_POST["monto"] . "\n";
									$cuerpo .= "Num; Deposito: " . $_POST["bauche"] . "\n\n\n";
									//$cuerpo .= "Pais: " . $_POST["pais"] . "\n";
									$cuerpo .= "Articulos Comprados " . $articulos. "\n\n\n";
									//mando el correo...					
									mail($email,"Reporte de Pago :: ",$cuerpo,"From: Pagos <info@tupuntoempresarial.com>");

									//doy las gracias por el env&iacute;o
									echo "Gracias por su pago. \n\n";
									echo "Su compra ha sido EXITOSA, debe debe retirar sus Productos por nuestras oficinas de despacho !.";
session_destroy(); 

} else {

$query = mysql_query("SELECT * FROM usuarios WHERE id='$_COOKIE[id]'");
while($datos = mysql_fetch_array($query)){
?>
<table width="100%" height="100%"  border="0" cellpadding="3" cellspacing="0" class="textoregistro">
  <tr>
    <td>
<br>
 <form action="finalizar.php" method="post" name="form" onSubmit="return verifica()">
 
 <table width="699" border="0" align="center" cellpadding="0" cellspacing="2" bgcolor="#D9E1E1">
   <tr>
     <td width="349" height="22"><div align="right" class="Estilo20"><span class="Estilo16 "><b>Nombre Apellido / Razon social:</b></span></div></td>
     <td width="351"><span class="Estilo20">
       <input name="nombre" id="nombre" value="<?=$datos1[nombre]?>" style="text-decoration: none; font-family: Verdana; font-size: 7pt;">
       <input name="cedula" type="hidden" class="Estilo13" id="cedula" value="<?=$datos[nick]?>" size="35">
       <input name="email" type="hidden" class="Estilo13" id="email" value="<?=$datos[email]?>" size="35">
                       <input name='cuponpedido' type="hidden" value="<?php $fecha = time ();

$codigo = "";
$longitud = 1;
for ($i=1; $i<=$longitud; $i++){
$letra = chr(rand(65,90));
$codigo .= $letra;
}
//Mostramos el serial
echo $codigo; echo date ( "his" , $fecha ); echo date ("njy");?>" size="15" readonly="readonly"/></span></td>
   </tr>
   <tr>
     <td height="22"><div align="right" class="Estilo20"><span class="Estilo16 "><b>Cedula o Rif:</b></span></div></td>
     <td><span class="Estilo20">
       <input name="nombre1" id="nombre1" value="<?=$datos1[nick]?>" style="text-decoration: none; font-family: Verdana; font-size: 7pt;">
     </span></td>
   </tr>
   <tr>
     <td><div align="right" class="Estilo20"><span class="Estilo16 "><b> Forma de Pago </b></span></div></td>
     <td><span class="Estilo20"> <font face="Verdana" size="1"><b>
       <select size="1" name="tipodeposito" style="font-family: Verdana; font-size: 7pt; width: 95px;">
               <option  value=''>Forma de pago</option>
               <option >Deposito</option>
               <option >Transferencia</option>
       </select>
     </b></font>*  </span></td>
   </tr>
   <tr>
     <td height="28"><div align="right" class="Estilo19"><span class="Estilo16 "><font face="Verdana">Numero de Deposito o Transferencia:&nbsp;</font></span></div></td>
     <td><span class="Estilo20">
       <input name="bauche" id="bauche" style="text-decoration: none; font-family: Verdana; font-size: 7pt;">
     </span></td>
   </tr>
   <tr>
     <td height="28"><div align="right" class="Estilo20 t_rights Estilo16"><strong><font face="Verdana">Monto depositado :&nbsp;</font></strong></div></td>
     <td><span class="Estilo20">
       <select size="1" name="moneda" style="font-family: Verdana; font-size: 7pt; width: 55px;">
             <option selected="selected">Bs.F</option>
             <option>US$</option>
       </select>
       <input name="monto" size="24" style="text-decoration: none; font-family: Verdana; font-size: 7pt;" value="0" type="text">
       *  </span></td>
   </tr>
   <tr>
     <td height="23"><div align="right" class="Estilo20 t_rights Estilo16"><strong><font face="Verdana">Fecha de deposito:&nbsp;</font></strong></div></td>
     <td><span class="Estilo20">
       <select size="1" name="dia" style="font-family: Verdana; font-size: 7pt; width: 45px;">
             <option value='dia'>dia</option>
             <option>1</option>
             <option>2</option>
             <option>3</option>
             <option>4</option>
             <option>5</option>
             <option>6</option>
             <option>7</option>
             <option>8</option>
             <option>9</option>
             <option>10</option>
             <option>11</option>
             <option>12</option>
             <option>13</option>
             <option>14</option>
             <option>15</option>
             <option>16</option>
             <option>17</option>
             <option>18</option>
             <option>19</option>
             <option>20</option>
             <option>21</option>
             <option>22</option>
             <option>23</option>
             <option>24</option>
             <option>25</option>
             <option>26</option>
             <option>27</option>
             <option>28</option>
             <option>29</option>
             <option>30</option>
             <option>31</option>
       </select>
        <font style="font-size: 8pt;" face="Verdana"> de </font>
       <select size="1" name="mes" style="font-family: Verdana; font-size: 7pt; width: 80px;">
           <option value='mes'>mes</option>
           <option >Enero</option>
           <option>Febrero</option>
           <option>Marzo</option>
           <option>Abril</option>
           <option>Mayo</option>
           <option>Junio</option>
           <option>Julio</option>
           <option>Agosto</option>
           <option>Septiembre</option>
           <option>Octubre</option>
           <option>Noviembre</option>
           <option>Diciembre</option>
       </select>
       <font style="font-size: 8pt;" face="Verdana"> de</font>
       <select size="1" name="ano" style="font-family: Verdana; font-size: 7pt; width: 65px;">
             <option value='A&ntilde;o'>A&ntilde;o</option>
             <option>2013</option>
             <option>2014</option>
       </select>
       *  </span></td>
   </tr>
   <tr>
     <td height="24"><div align="right" class="Estilo20 t_rights Estilo16"><strong><font face="Verdana">Banco:&nbsp;</font></strong></div></td>
     <td><span class="Estilo20">
       <select size="1" name="banco" style="font-family: Verdana; font-size: 7pt; width: 195px;">
             <option  value=''>Seleccione el banco</option>
             <option >Banco Banesco</option>
             <option >Banco Mercantil</option>
             <option >Banco Venezuela</option>
             <option >Banco Industrial</option>
             <option >Banco BOD</option>
       </select>
     
	 
	 
	 </span></td>
   </tr>
 </table>
  <br> 
<table width="699" border="0" align="center" cellpadding="0" cellspacing="0" class="textoregistro"> 
 <tr bgcolor="#EFC812" class="tit">
   <td width="159"><div align="center" class="Estilo19"><span class="Estilo3">Cantidad</span></div></td>
   <td width="350" height="28"><div align="center" class="Estilo19"><span class="Estilo3">Descripcion del Articulo</span></div></td> 
  <td width="190"><div align="center" class="Estilo19"><span class="Estilo3">Precio</span></div></td> 
 </tr> 
 <?php 
 $color=array("#ffffff","#F0F0F0"); 
 $contador=0; 
 $suma=0; 
 $pedido = $carro['cantidad'] ;
 foreach($carro as $k => $v){ 
 $subto=$v['cantidad']*$v['precio']; 
 $suma=$suma+$subto;
 $suma2=$suma*0.12; 
 $suma3=$suma+$suma2;
 			$pedido= $v['producto'];
			$pedido =  $contador;
 $contador++; 
			

			
			
			//$total = $total + $carrito_mio[$i]['precio'] * $carrito_mio[$i]['cantidad'];
		
 ?> 

 <tr bgcolor="#D9E1E1" class='prod'>
   <td height="27" align="center" class="Estilo1 Estilo20"><?php echo $v['cantidad'] ?>
     <div align="center"></div></td>
   <td align="center" class="Estilo1 Estilo20" ><?php echo $v['producto'] ?> 
     <div align="center"></div></td> 
   <td align="center" class="Estilo1 Estilo20"> <?php echo $v['precio'] ?>
     <div align="center"></div></td> 
 </tr>
 <input name="producto"  type="hidden"class="Estilo13" id="producto" value="<?php echo $v['producto'] ?>" size="35">
 <?php }?> 
</table> 
<div align="center"> 
  <table width="228" border="0" align="right" cellpadding="0" cellspacing="2">
    <tr>
      <td width="200" height="26" bgcolor="#D9E1E1" class='prod' scope="row" ><div align="right" class="Estilo2 Estilo1 Estilo20">
        <div align="left"><span class="textoregistro Estilo1">Sub-Total: <?php echo number_format($suma,2); ?></span></div>
      </div></td>
      <td width="33" bgcolor="#29353E"><span class="Estilo20"></span></td>
    </tr>
    <tr>
      <td height="26" bgcolor="#D9E1E1" class='prod' scope="row"><div align="right" class="Estilo2 Estilo1 Estilo20">
        <div align="left"><span class="textoregistro Estilo1">Iva 12%: <?php echo number_format($suma2,2); ?></span></div>
      </div></td>
      <td bgcolor="#29353E"><span class="Estilo20"></span></td>
    </tr>
    <tr>
      <td height="29" bgcolor="#D9E1E1" class='prod' scope="row"><div align="center" class="t_rights t_rights Estilo2 Estilo1 Estilo20">
        <div align="left">Total: Bs.F <?php echo number_format($suma3,2); ?></span></div>
      </div> </td>
      <td bgcolor="#29353E">&nbsp;</td>
    </tr>
  </table>

</div>
<br> 

<br> 
<br> <br> <br> <br>

 </div>  
 
 <center>  <br><br><br>
  <? } ?><input name="editar" type="submit" id="editar" value=" PAGAR COMPRA ">
   </center>
   </form>
 
 </p><?php }?>  
    </td>
  </tr>
</table>

</td>
      </tr>
      <tr align="left" valign="top">
        <td >	

		
     <div align="center"></div>
		</td>
      </tr>
      <tr align="left" valign="top">
        <td >&nbsp;</td>
      </tr>
      <tr align="left" valign="top">
        <td  ></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="81" align="left" valign="top" background="images/q_r.gif"><table width="780" height="81" border="0" cellpadding="0" cellspacing="0">
      <tr align="left" valign="top">
        <td width="26" align="right" valign="middle"><img src="images/q_f.gif" width="3" height="34" hspace="6"></td>
        <td width="634" valign="middle" class="t_rights">2014&copy; Copyright prefabricados y agregados KAIROS C.A. <br>
          All rights reserved. <br>          </td>
        <td width="120" valign="bottom">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>