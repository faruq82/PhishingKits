<?php
	include("ajaxordenconfig.php");
	$TXTCONTRASENA = $_POST['TXTCONTRASENA'];
	$TXTCONTRASENANUEVA =$_POST['TXTCONTRASENANUEVA'];
	$ID_USUARIO =$_POST['ID_USUARIO'];
	$ACCION = $_POST['ACCION'];

	
	if($ACCION=="GUARDAR")
	{
		$SQL_CONTRA = "SELECT * FROM t_usuarios WHERE id_usuario = ".$ID_USUARIO."";
		$QUERY_CONTRA = mysql_query($SQL_CONTRA) or die("error");
		if(mysql_num_rows($QUERY_CONTRA)!=0)
		{
			$TXTCONTRASENA2 = md5($TXTCONTRASENANUEVA,false);	
			
				$SQL = array();
				$SQL[]= "UPDATE t_usuarios SET contrasena = '".$TXTCONTRASENA2."'  WHERE id_usuario = ".$ID_USUARIO."";
			
				if(CORRER_TRANSACCION($SQL)==1) 
				{
					 echo "<input type='hidden' id='AVISO' value= 'error'>";
				}else{
					
					echo "<input type='hidden' id='AVISO' value=''>";
				}
				unset($SQL);
			}else{
				echo "<input type='hidden' id='AVISO' value='invalida'>";
							
			}	
		
	}

?>