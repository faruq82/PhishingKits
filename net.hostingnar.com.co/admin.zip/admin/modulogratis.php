<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
	<title>CENTRO EDUCATIVO CECIP</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,900,800,700,600,500,300,200,100' rel='stylesheet' type='text/css'>
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-26080345-2', 'auto');
  ga('send', 'pageview');

</script>
	<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.carouFredSel-5.5.0-packed.js" type="text/javascript"></script>
<script src="js/functions.js" type="text/javascript"></script>
<style type="text/css">
#wrapper .shell .container .main .cols .col p {
	text-align: justify;
}
#wrapper .shell .container .main .entries .entry p {
	font-family: "Century Gothic";
	font-style: normal;
}
#wrapper .shell .container .main .cols .col table tr td table tr td ul li p {
	font-size: 16px;
}
strong {
	color: #F00;
}
#wrapper .shell .container .main .cols .col table tr td table tr td strong {
	color: #000;
	text-align: left;
}
strong {
	color: #F00;
}
strong {
	color: #000;
}
.Estilo4 {color: #333333;
	font-weight: bold;
	font-size: 11px;
}
.Estilo7 {color: #333333; font-size: 11px; }
.Estilo8 {font-size: 12px}
.Estilo8 {font-size: 11px}
.Estilo3 {COLOR: #ff6600
}
.Estilo541 {FONT-SIZE: 12px; COLOR: #003366; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif
}
.Estilo57 {FONT-SIZE: 11px; COLOR: #ffffff; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif
}
.Estilo61 {color: #FFFFFF}
.Estilo801 {font-size: 14px; font-family: "Century Gothic"; }
.Estilo81 {color: #FFFF00}
.Estilo611 {	color: #000
}
</style>
<script language="javascript"> 

function verifica(){ 
 
    if(document.form.CMBPAIS.value==-1){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe ingresar el Pais"); //mensaje a la pantalla
 
        document.form.CMBPAIS.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }
 
    if(document.form.nombre.value.length < 2){ 
 
        alert("Debe ingresar su nombre"); 
 
        document.form.nombre.focus(); 
 
        return false;
 
    }
 
    if(document.form.email.value.length < 1){ 
 
        alert("Debe ingresar el E-Mail"); 
 
        document.form.email.focus(); 
 
       return false;
    }
 
   	  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form.email.value))
      {}
      else 
     { alert("La dirección de email " + document.form.email.value + " es incorrecta.");
       document.form.email.focus();
	   return false;
     } 
 
    if(document.form.telefono.value.length < 1){ 
 
        alert("Debe ingresar un número de teléfono"); 
 
        document.form.telefono.focus(); 
 
        return false; 
 
    }
	 

        document.form.submit(); //enviamos formulario    
 
} 
 
</script> 


</head>
<body>
<!-- wrapper -->
<div id="wrapper">
	<!-- shell -->
	<div class="shell">
		<!-- container -->
		<div class="container">
			<!-- header -->
			<header id="header">
				<h1 id="logo"><a href="#">Retina</a></h1>
				<!-- search -->

				<!-- end of search -->
				<div class="cl">&nbsp;</div>
		  </header>
			<!-- end of header -->
			<!-- navigaation -->
			<nav id="navigation">
				<a href="home.html" title="principal" target="_self" class="nav-btn">HOME<span></span></a>
				<ul>
	        <li class="active"><a href="home.html" title="principal" target="_self">HOME</a></li>
					<li><a href="http://centroeducativocecip.com/index2.php" target="_self">LOGIN</a></li>
					<li><a href="estudiantes.html" title="ESTUDIANTES" target="_self">ESTUDIANTE</a></li>
					<li><a href="cecip.html" title="ESCUELAS" target="_self">ESCUELAS</a></li>
					<li><a href="contacto.php" title="CONTACTO" target="_self">CONTACTOS</a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
					<li><a href="#"></a></li>
				</ul>
				<div class="cl">&nbsp;</div>
			</nav>
			<!-- end of navigation -->
			<!-- slider-holder -->
			<div class="slider-holder">
				
				<!-- slider -->
			  <div class="slider">
					<div class="socials">
						<a href="http://www.facebook.com/redil.ministerio" title="facebook" target="_blank" class="facebook-ico">facebook-ico</a>
						<a href="http://www.twitter.com/MinisterioRedil" title="twitter" target="_blank" class="twitter-ico">twitter-ico</a>
						<a href="http://www.youtube.com/user/reddeintercesores" title="youtube" target="_blank" class="skype-ico">skype-ico</a>
						<a href="http://instagram.com/ministerioredil" title="instagram" target="_blank" class="rss-ico">rss-ico</a>
					  <div class="cl">&nbsp;</div>
					</div>

				<div class="arrs">
						<a href="#" class="prev-arr"></a>
						<a href="#" class="next-arr"></a>
			    </div>

				  <ul>
					  <li id="img1"></li>
				  </ul>
			  </div>
				<!-- end of slider -->

				<!-- thumbs --><!-- end of thumbs -->
			</div>

			<!-- main -->
			<div class="main">

				<div class="featured">
				  <h4>Bienvenido al <strong>Centro Educativo y Cultural del Intercesor Profético.</strong> CECIP</h4>
					<a href="http://centroeducativocecip.com/reg_alumnos_online.php" target="_self" class="blue-btn">INSCRIBETE AQUI.</a>
				</div>

				<section class="cols">
				  <div class="col">
<table width="955" height="224" border="0">
		      <tr>
				        <td width="408" valign="top"><p><strong>La cobertura de CECIP esta creciendo por toda Latinoamerica y tu puedes ser parte de esta visión y trabajo. Si deseas formar parte del Centro Eduativo CECIP contactanos y llena el siguiente formulario para cualquier duda que tengas estamos para servirte.</strong></p></td>
				        <td width="408" align="center" valign="middle"><span class="Estilo611"><img src="css/images/donaciones.png" width="194" height="52"></span></td>
	          </tr>
				      <tr>
				        <td valign="top"><font face="Verdana, Arial, Helvetica, sans-serif">
				               <?
								if (!$HTTP_POST_VARS){
								?>
				          </font>
				           <form action="modulogratis.php" method="post" name="form" id="form" onSubmit="return verifica()">
				            <table width="100%" border="0">
				              <tr bgcolor="" background="">
				                <td colspan="2"><div align="left"><span class="blue_text Estilo9"><font face="Verdana, Arial, Helvetica, sans-serif"><br />
				                  </font></span> <font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif"><br />
				                    </font></div></td>
			                  </tr>
				              <tr background="images/day_camp.gif">
				                <td colspan="2"><div align="center" class="Estilo4"><font face="Verdana, Arial, Helvetica, sans-serif">LLENE EL FORMULARIO PARA DESCARGAR EL ARCHIVO</font></div></td>
			                  </tr>
				              <tr>
				                <td width="31%"><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">NOMBRE :</font></div></td>
				                <td width="69%"><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
				                  <input name="nombre" type="text" id="nombre" size="40" />
*				                  </font></span></td>
			                  </tr>
				              <tr>
				                <td><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">TELEFONO:</font></div></td>
				                <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
				                  <input name="telefono" type="text" id="telefono" size="40" />
*				                  </font></span></td>
			                  </tr>
				              <tr>
				                <td><div align="right"><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">EMAIL:</font></span></div></td>
				                <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
				                  <input name="email" type="text" id="email" size="40" />
			                    *
</font></span></td>
			                  </tr>
				              <tr background="images/day_camp.gif">
				                <td><div align="right" class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">PAIS :</font></div></td>
				                <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
				                  <?php 
								  include("ceoconexion.php");
								  				echo "<select  id='CMBPAIS' name='CMBPAIS'  style='width:250px' onChange='cambiarestado()' >";
               	$QUERY= mysql_query("select * from T_PAIS ORDER BY PAIS");
			echo "<option value=-1></option>";
                 	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"PAIS").">".mysql_result($QUERY,$i,"PAIS")."</option>";
				}
				echo "</select>";
								   ?><div style="display:none" >
								   <input name='fecha' id="fecha" type="text" value="<?php echo date ( "j / n / Y" )?>" size="20" readonly="readonly"   />
				                   </div> </font></span></td>
			                  </tr>
				              <tr>
				                <td>&nbsp;</td>
				                <td><span class="Estilo8"></span></td>
			                  </tr>
				              <tr>
				                <td>&nbsp;</td>
				                <td><span class="Estilo7"><font face="Verdana, Arial, Helvetica, sans-serif">
				                  <input name="submit" type="submit" value="Enviar Información" />
				                  </font></span></td>
			                  </tr>
			                </table>
				            <div align="center"> </div>
			              </form>
				          <font face="Verdana, Arial, Helvetica, sans-serif">
				            <?
								}else{
									//Estoy recibiendo el formulario, compongo el cuerpo
									$cuerpo = "Formulario de CONTACTO <br><br>";
									$cuerpo = "===== INFORMACION DEL USUARIO ===== <br>";
									$cuerpo .= "Nombre: " . $HTTP_POST_VARS["nombre"] . "<br>";
									$cuerpo .= "Telefono: " . $HTTP_POST_VARS["telefono"] . "<br>";
									$cuerpo .= "Email: " . $HTTP_POST_VARS["email"] . "<br>";
									$cuerpo .= "Pais: " . $HTTP_POST_VARS["CMBPAIS"] . "<br><br>";
									//$cuerpo .= "Banco: " . $HTTP_POST_VARS["empresa"] . "\n";
									$cuerpo .= '<a href="http://www.centroeducativocecip.com/Manual Descubriendo La Intercesion Profetica-gratis.pdf">PARA DESCARGAR EL MODULO I CLICK AQUI</a>';


									$nombre=$HTTP_POST_VARS["nombre"];
									$telefono=$HTTP_POST_VARS["telefono"];
									$email=$HTTP_POST_VARS["email"];
									$pais=$HTTP_POST_VARS["CMBPAIS"];
									$fecha=$HTTP_POST_VARS["fecha"];

									
										include("ceoconexion.php");
												$query22 = mysql_query("SELECT * FROM descargas WHERE email='$email'");
												if(mysql_num_rows($query22)>0){	

													echo "<br><br><br><br>";
													echo "El email <b>$email</b> ya se encuentra registrado<br><br>";
													echo "MODULO I DE REGALO - Manual Descubriendo La Intercesion Profetica<br>";
													echo '<a href="http://www.centroeducativocecip.com/Manual Descubriendo La Intercesion Profetica-gratis.pdf" target="_blank">PARA DESCARGAR EL MODULO I CLICK AQUI</a>';
													echo "<br><br>";
     		  
												} else { 
									 				mysql_query("INSERT INTO descargas (nombre,email,telefono,pais,fecha) 
	   		 										VALUES ('$nombre','$email','$telefono','$pais','$fecha')")or die (mysql_error());


									//mando el correo...
													$email1=$HTTP_POST_VARS["email"];
									
													//mail($email1,"Modulo I Descubriendo La Intercesion Profetica",$cuerpo,"From: cecip_online@centroeducativocecip.com\r\nContent-type: text/html\r\n");
									$asunto="Modulo I Descubriendo La Intercesion Profetica";	
									require("PHPMailer/class.phpmailer.php");	
									$mail = new PHPMailer();
									$mail->Mailer = "smtp";
									$mail->Host = "mail.centroeducativocecip.com";
									$mail->Port="25";
									$mail->SMTPAuth = true;
									$mail->Username = "cecip_online@centroeducativocecip.com";
									$mail->Password = "LXM71HE3i";
									$mail->CharSet = "UTF-8";
									$mail->From = "cecip_online@centroeducativocecip.com";
									$mail->FromName = "Cecip";
									$mail->IsHTML(true);                                
									$mail->Subject = $asunto;
									$mail->Body    = $cuerpo;
									$mail->AddAddress($email1);
									$mail->Send();											
													
													
													
													
													mail("cecip_online@centroeducativocecip.com","TIENE UN NUEVO REGISTRO",$cuerpo,"From: Contacto $email1");
									
													echo "<br><br><br><br>";
													echo "MODULO I DE REGALO - Manual Descubriendo La Intercesion Profetica<br>";
													echo '<a href="http://www.centroeducativocecip.com/Manual Descubriendo La Intercesion Profetica-gratis.pdf" target="_blank">PARA DESCARGAR EL MODULO I CLICK AQUI</a>';
													echo "<br><br>";
									


									//doy las gracias por el env&iacute;o
													echo "Gracias por darnos tu informacion. acabamos de enviarte el modulo 1 a tu correo.\n";
													echo "<br>Revise en la bandeja de Spam o No deseado  <br>";
													echo "Tambien le estaremos enviando el link del modulo I a Su EMail!.";

												}
								}
								?>
			              </font></td>
				        <td valign="top"><table width="521" border="0">
				          <tr>
				            <td width="515"><table width="493" height="518" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#EDF3F8">
				              <tr>
				                <td width="493" height="20" bgcolor="#5282C9" class="Estilo57" ><strong>Donaciones dentro de los EE.UU</strong></td>
			                  </tr>
				              <tr>
				                <td height="90" class="Estilo541"><strong>A nombre de <span class="Estilo3">Redil,Corp</span></strong>
				                  <blockquote>
				                    <table width="136" border="0">
				                      <tr>
				                        <td height="62">Banco Wells Fargo&nbsp;&nbsp; <br />
				                          # 
				                          5232312263<br />
				                          checking account</td>
			                          </tr>
			                        </table>
				                    <p>&nbsp;</p>
			                      </blockquote></td>
			                  </tr>
				              <tr>
				                <td height="20" bgcolor="#5282C9" ><p align="center"><span class="Estilo61"><strong><strong>Donaciones con tarjeta de cr&eacute;dito fuera de Venezuela ( USD) </strong></span></p></td>
			                  </tr>
				              <tr>
				                <td height="68" ><table width="175" border="0" align="center" cellpadding="0" cellspacing="0">
				                  <tr>
				                    <td><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
				                      <input type="hidden" name="cmd" value="_s-xclick" />
				                      <input type="hidden" name="hosted_button_id" value="CZ7EMGNBCT9L6" />
				                      <input type="image" src="https://www.paypalobjects.com/es_XC/i/btn/btn_donateCC_LG.gif" border="0" name="submit2" alt="PayPal, la forma más segura y rápida de pagar en línea." />
				                      <img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1" />
				                      </form></td>
			                      </tr>
				                  </table></td>
			                  </tr>
				              <tr>
				                <td height="220"><table width="487"  border="0" align="center" cellpadding="1" cellspacing="1">
				                  <tbody>
				                    <tr>
				                      <th width="430" height="20" bgcolor="#5282c9" class="Estilo57" scope="col"> <p><span class="Estilo61"><strong><strong>Donaciones dentro de Venezuela.</strong></span></p></th>
			                        </tr>
				                    <tr>
				                      <td class="Estilo541" bgcolor="#edf3f8" height="100"><table width="321" border="0">
				                        <tr>
				                          <td width="315"><strong>A nombre de <span class="Estilo3">FUNDACION REDIL</span></strong></td>
			                            </tr>
				                        </table>
				                        <p>&nbsp;</p>
				                        <blockquote>
				                          <ul>
				                            <li>Banco Venezuela: 01020347310000095044</li>
				                            <li>RIF J- 40112407-0</li>
			                              </ul>
			                            </blockquote></td>
			                        </tr>
				                    <tr>
				                      <td class="Estilo541" bgcolor="#edf3f8" height="24"><span class="Estilo801">Direcci&oacute;n en Venezuela: Sector Sierra Maestra, calle 13 entre Av. 7 y 8. Tel&eacute;fonos: 58-(261) 3229424- 58-(424)-6170987</span></td>
			                        </tr>
				                    <tr>
				                      <td class="Estilo541" bgcolor="#edf3f8" height="24"><span class="Estilo801">Para contactarnos fuera del pais: Toll Free Number 1 (844) 627-6508 ó 1 (786) 315-6394 </span></td>
			                        </tr>
				                    <tr>
				                      <td class="Estilo541" bgcolor="#edf3f8" height="22"><span class="Estilo801">P.O BOX 836144 Miami, Florida, 33283 </span></td>
			                        </tr>
				                    <tr>
				                      <td class="Estilo541" bgcolor="#000000" height="22">Correo Electronico:<a href="mailto:cecip_online@centroeducativocecip.com" class="Estilo81">cecip_online@centroeducativocecip.com</a></td>
			                        </tr>
			                      </tbody>
				                  </table></td>
			                  </tr>
				              </table></td>
			              </tr>
				          <tr>
				            <td>&nbsp;</td>
			              </tr>
			            </table></td>
			          </tr>
				      <tr>
				        <td colspan="2" valign="top"><img src="css/images/Libreriadavar.gif" alt="REDESSOCIALES" width="924" height="205" border="0" usemap="#MapMap" /></td>
			          </tr>
			        </table>
				    <map name="MapMap" id="Map">
				      <area shape="rect" coords="6,4,915,198" href="http://www.ministerioredil.org/tienda" target="_blank" />
			        </map>
				    <h3>&nbsp;</h3>
				  </div>
				</section>
			</div>
			<!-- end of main -->
			<div class="cl">&nbsp;</div>
			
			<!-- footer -->
			<div id="footer"><img src="css/images/paypal.jpg" alt="en la imagen se pueden ver varias personas reunidas estudiando" width="950" height="50" hspace="12" border="0" align="middle" usemap="#MapMap2">
			  <map name="MapMap2">
			    <area shape="rect" coords="3,600,576,832" href="http://www.ministerioredil.org/tienda" target="_blank" />
			    <area shape="rect" coords="69,355,501,396" href="salmistas.html" target="_self" alt="salmistas">
			    <area shape="rect" coords="69,295,501,341" href="culturaygobierno.html" target="_self" alt="culturaygobierno">
			    <area shape="rect" coords="68,240,501,279" href="profetas.html" target="_self" alt="profeta">
			    <area shape="rect" coords="67,181,503,221" href="escuelaintersecion.html" target="_self" alt="escuelaintersecion">
			    <area shape="rect" coords="4,406,564,592" href="http://centroeducativocecip.com/reg_alumnos_online.php" target="_self">
		      </map>
		  </div>
			<!-- end of footer -->
		</div>
		<!-- end of container -->
	</div>
	<!-- end of shell -->
</div>
<!-- end of wrapper -->

<map name="Map">
  <area shape="rect" coords="11,9,327,72" href="#">
</map>
</body>
</html>