<?php
			include("ajaxordenconfig.php");
			
			
			
			$ACCION = $_POST['ACCION'];
			$ID_USUARIO = $_POST['ID_USUARIO'];
			
			if($ACCION==0)
			{
					$ID_TIPO_USUARIO = $_POST['ID_TIPO_USUARIO'];
					if($ID_TIPO_USUARIO==-1)
					{
						echo("<b>&nbsp;&nbsp;&nbsp;&nbsp;Debe seleccionar un tipo de usuario.</b>");
					}else{
					
							$SQL ="SELECT * FROM t_privilegios ORDER BY nombre";
							$BUSCAR_PRIVILEGIOS= mysql_query($SQL) or die ("Error en el SQL privilegios");
							if(mysql_num_rows($BUSCAR_PRIVILEGIOS)==0)
							{
								echo "No existen privilegios registrados";
							
							}else{
									
									
									echo "<br><table border=0 cellpadding=2 cellspacing=2 width=780>
									<tr class='cabecera'><th align=left>Opci&oacute;n</th><th align=left>Descripci&oacute;n</th><th>Habilitar</th></tr>";
									for($i=0;$i<mysql_num_rows($BUSCAR_PRIVILEGIOS);$i++)
									{
											if($i%2==0)
											{
												echo "<tr ".$STYLECELDAS.">";
											}else{
												echo "<tr bgcolor=#F2F9F9 ".$STYLECELDAS.">";
											}
										
										$ID_PRIVILEGIO = mysql_result($BUSCAR_PRIVILEGIOS,$i,"id_privilegio");
										
										$QUERY_ESTADO = mysql_query("select * from t_tipos_usuarios_privilegios INNER JOIN t_privilegios ON  t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_tipos_usuarios_privilegios.id_privilegio = ".$ID_PRIVILEGIO." AND id_tipo_usuario = ".$ID_TIPO_USUARIO." ");
										
										//$QUERY_ESTADO = mysql_query("select * from T_TIPOS_USUARIOS_PRIVILEGIOS WHERE ID_PRIVILEGIO = ".$ID_PRIVILEGIO." AND ID_TIPO_USUARIO = ".$ID_TIPO_USUARIO."");
		
										if(mysql_num_rows($QUERY_ESTADO)!=0)
										{
											$ESTADO="checked";
										}else{
											$ESTADO = "";	
										}						
										 $NOMBRE=str_replace(" ","_",mysql_result($BUSCAR_PRIVILEGIOS,$i,"nombre"));
										echo"<td >".mysql_result($BUSCAR_PRIVILEGIOS,$i,"nombre")."</td><td>".mysql_result($BUSCAR_PRIVILEGIOS,$i,"descripcion")."</td><td align=center ><input type='checkbox' name='campos[".mysql_result($BUSCAR_PRIVILEGIOS,$i,"id_privilegio")."]' value=".mysql_result($BUSCAR_PRIVILEGIOS,$i,"id_privilegio")." id='campos_".$i."' ".$ESTADO." ></td></tr>";
										
									}
									echo "<input type='hidden' id='TXTLISTA' name='TXTLISTA' value=".$i.">";
							}
							echo "</table>";
						}
			}
			
			
			if($ACCION==1)
			{
				$ID_TIPO_USUARIO= $_POST['ID_TIPO_USUARIO'];
				if(!empty($_POST['campos_eliminar']))
				{
					$campos_eliminar= $_POST['campos_eliminar'];	
					$ARRAY_ID_PRIVILEGIOS_ELIMINAR = explode(",",$campos_eliminar);
					
					$SQL=array();
					
							
						
						
						for($i=0;$i<count($ARRAY_ID_PRIVILEGIOS_ELIMINAR);$i++)
						{
							if($ARRAY_ID_PRIVILEGIOS_ELIMINAR[$i]!="")
							{
									
									$SQL_QUERY =mysql_query("SELECT * FROM t_tipos_usuarios_privilegios where id_tipo_usuario = ".$ID_TIPO_USUARIO." AND id_privilegio = ".$ARRAY_ID_PRIVILEGIOS_ELIMINAR[$i]."");	
									if(mysql_num_rows($SQL_QUERY)!=0)
									{
										$SQL[]="DELETE FROM t_tipos_usuarios_privilegios where id_tipo_usuario = ".$ID_TIPO_USUARIO." AND id_privilegio = ".$ARRAY_ID_PRIVILEGIOS_ELIMINAR[$i]."";
									}
							}
						}
						if(CORRER_TRANSACCION($SQL)==1) 
						{
							 echo "<input type=hidden id='AVISO' name='AVISO' value= 'error'>";
							return; 
						}else{
							
							
						}
						unset($SQL);
					
				}
				
				$SQL=array();
				if(!empty($_POST['campos']))
				{
					$campos= $_POST['campos'];	
					
				
					
						$ARRAY_ID_PRIVILEGIOS = explode(",",$campos);
						for($i=0;$i<count($ARRAY_ID_PRIVILEGIOS);$i++)
						{
							
							if($ARRAY_ID_PRIVILEGIOS[$i]!="")
							{
								$SQL_QUERY =mysql_query("SELECT * FROM t_tipos_usuarios_privilegios where id_tipo_usuario = ".$ID_TIPO_USUARIO." AND id_privilegio = ".$ARRAY_ID_PRIVILEGIOS[$i]."");
								if(mysql_num_rows($SQL_QUERY)==0)
								{
									
									$SQL[]= "INSERT INTO t_tipos_usuarios_privilegios (id_tipo_usuario,id_privilegio) VALUES  (".$ID_TIPO_USUARIO.",".$ARRAY_ID_PRIVILEGIOS[$i].")";
								}
							}
						
						}
				}
			
				if(CORRER_TRANSACCION($SQL)==1) 
				{
					 echo "<input type=hidden id='AVISO' name='AVISO' value= 'error'>";
				}else{
					
					echo "<input type=hidden id='AVISO' name='AVISO' value=''>";
				}
				unset($SQL);
					
			}				
					
?>
