<?php
$link =mysql_connect("localhost","nethn_admin","admin32") or die ('problema conectando porque :' . mysql_error());
mysql_select_db("nethn_admin",$link);

?>
