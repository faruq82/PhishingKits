<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
	<link rel="stylesheet" href="./images/reset.css" />
	<link rel="stylesheet" href="./images/bootstrap.css" />
	<link rel="stylesheet" href="./images/styles.css" />
    <style type="text/css">
<!--
.Estilo21 {
	color: #000000;
	font-weight: bold;
}
-->
    </style>
</head>

<body>





<table width="" height="427" border="0" align="left">
  <tr>
    <td width="500" height="423" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif">&nbsp;
      </font>
	  
			<div class="span8">
		
			<p class="Estilo21">SU PAGO ESTA SIENDO PROCESADO, CUALQUIER DUDA PUEDE NOTIFICARLA AL EMAIL pagos@ministerioredil.org</p>



			<div id="ajax-console-success"></div>
	</td>
  </tr>
</table>
</body>
</html>
