<?php

$id = $_GET['id'];
$id2 = $_GET['id2'];
	require('ceoconexion.php');
	
		$query = "delete from usuarios where id='$id'";
		$result = mysql_query($query);

		$query1 = "delete from  t_personal where id_personal='$id2'";
		$result1 = mysql_query($query1);

		$query2 = "delete from   t_usuarios where id_personal='$id2'";
		$result2 = mysql_query($query2);

//Para devolver a la p�gina donde se pidi� la acci�n
if (isset ($_GET['buscar'])== "") {
	$url = $_GET['from'];
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".$url."'>";
} 
else {
	$url = $_GET['from'];
	$url2 = $_GET['buscar'];
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".$url."&buscar=".$url2."'>";
}
?>