<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "encuesta.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
?>	
<html >
<head>
<title>Tipos de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<?php $page = 'polls'; @include ("template.php"); ?>
	<tr>
		<td colspan="4">
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td align="center" height="25"><a href="encuesta.php" class="text">Encuesta</a> > <b>Ver una Encuesta</b></td>
				</tr>
			</table>
			<br>
			<?php 
			
			function view () { 
			
				include ("encueta/config.php");
				
				$polls = mysql_fetch_array (mysql_query ("SELECT * FROM polls WHERE pollid='$_REQUEST[poll]'"));
				
				$years = floor ($polls['vote'] / 31557600);
				$months = floor (($polls['vote'] - ($years * 31557600)) / 2629800);
				$days = floor (($polls['vote'] - (($years * 31557600) + ($months * 2629800))) / 86400);
				$hours = floor (($polls['vote'] - (($years * 31557600) + ($months * 2629800) + ($days * 86400))) / 3600);
				$minutes = floor (($polls['vote'] - (($years * 31557600) + ($months * 2629800) + ($days * 86400) + ($hours * 3600))) / 60);
				$seconds = floor (($polls['vote'] - (($years * 31557600) + ($months * 2629800) + ($days * 86400) + ($hours * 3600) + ($minutes * 60))));
			
			?>
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Encuestaid:</b></td>
					<td width="75%" colspan="4" align="center"><?= $polls['pollid']; ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Creada:</b></td>
					<td width="75%" colspan="4" align="center"><?= $polls['subdate']; ?></td>
				</tr>
				<tr class="text">
					<td width="25%" height="25" colspan="5">&nbsp;</td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Titulo:</b></td>
					<td width="75%" colspan="4" align="center"><?= $polls['title']; ?></td>
				</tr>
				<?php
				
				$sum = mysql_fetch_assoc (mysql_query ("SELECT SUM(votes) AS total FROM options WHERE pollid='$_REQUEST[poll]'"));
				
				$result = mysql_query ("SELECT optionid, options, images, votes, order_id FROM options WHERE pollid='$_REQUEST[poll]' ORDER BY order_id ASC");
				
				while ($options = mysql_fetch_array ($result)) {
				
					$percent = @round (($options['votes'] / $sum['total']) * 100);
					
					if ($options['images'] == 'random') {
					
						if ($handle = opendir ($dir)) {
			  
							while (false !== ($file = readdir ($handle))) {
													
								if ($file != '.' && $file != '..') {
								
									$files[] = $file;
								
								}				
								
							}
							
							shuffle ($files);
						}
						
						$rand = rand (0, (count ($files) - 1));
						
						$options['images'] = $files[$rand];
						
					}
				
				?>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Opciones<?= $options['order_id']; ?>:</b></td>
					<td width="37%" align="right">(opcionid = <?= $options['optionid']; ?>) <?= $options['options']; ?> </td>
					<td width="25%" align="left" bgcolor="#CCCCCC"><img src="<?= $dir; ?>/<?= $options['images']; ?>" width="<?= ($percent * 2) + 10; ?>" height="17" alt="<?= $options['options']; ?>"></td>
					<td width="4%" align="left"><?= $percent ?>%</td>
					<td width="9%" align="left"><?= $options['votes']; ?> Votes</td>
				</tr>
				<?php } ?>
				<tr class="text">
					<td width="92%" height="25" colspan="4">&nbsp;</td>
					<td width="8%" align="left"><b><?= $sum['total']; ?> Votes</b></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Inicio:</b></td>
					<td width="75%" colspan="4" align="center"><?= $polls['starts']; ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Temina:</b></td>
					<td width="75%" colspan="4" align="center"><?= $polls['expires']; ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>El usuario puede votar:</b></td>
					<td width="75%" colspan="4" align="center">A&ntilde;o: <?= $years; ?> | Mes: <?= $months; ?> | Dia: <?= $days; ?> | Hora: <?= $hours; ?> | Minutos: <?= $minutes; ?> | Segundos: <?= $seconds; ?></td>
				</tr>
				<tr class="text">
					<td align="right" height="25"><b>Habilitar votar:</b></td>
					<td colspan="4" align="center"><?= ucfirst ($polls['voting']); ?></td>
				</tr>
				<tr class="text">
					<td align="right" height="25"><b>Activar Resultados:</b></td>
					<td colspan="4" align="center"><?= ucfirst ($polls['graph']); ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Ver resultados de la votaci&oacute;n:</b></td>
					<td width="75%" colspan="4" align="center"><?= ucfirst ($polls['results']); ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Ver cantidad votos:</b></td>
					<td width="75%" colspan="4" align="center"><?= ucfirst ($polls['resultsvotes']); ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Usar proteccion de IP:</b></td>
					<td width="75%" colspan="4" align="center"><?= ucfirst ($polls['ip']); ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Usar protecci&oacute;n de cookies:</b></td>
					<td width="75%" colspan="4" align="center"><?= ucfirst ($polls['cookies']); ?></td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25"><b>Status:</b></td>
					<td width="75%" colspan="4" align="center"><?= ucfirst ($polls['status']); ?></td>
				</tr>
				<tr class="text">
					<td width="25%" height="25" colspan="5">&nbsp;</td>
				</tr>
				<tr class="text">
					<td width="25%" align="right" height="25" valign="top"><b>Direcciones IP bloqueadas:</b></td>
					<td width="75%" colspan="4" align="center">
						<?php
							
						$result = mysql_query ("SELECT ip FROM blocked WHERE polls LIKE '%$polls[title]%'");
						$numrows = mysql_num_rows ($result);
							
						if ($numrows > 0) {
							
							while ($blocked = mysql_fetch_array ($result)) {
							
								echo $blocked['ip']."<br>";
									
							}
								
						} else {
							
							echo "None";
								
						}
							
						?>
					</td>
				</tr>
			</table>
			<br>
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td align="center" height="25"><a href="encuesta.php" class="text"><< volver</a></td>
				</tr>
			</table>
			<?php
			
			}
			
			view ();
			
			?>
		</td>
	</tr>
</table>
 <?php  
		piecera($PRIVILEGIO);
?>
</body>
</html>