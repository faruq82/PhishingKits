<script language='javascript' src="popcalendar.js"></script>
<script language='javascript' src="scriptbusqueda.js"></script>
<noscript><meta http-equiv="refresh" content="0;url=noscript.php" /></noscript>
<?php

	$STYLECELDAS = "onmouseover=this.style.backgroundColor='#9CF' onmouseout=this.style.backgroundColor=''";
	$CABECERACELDAS="bgcolor=#96BEE2";
	
	$CHECKBOX="checked";
	$db="nethn_admin";
	$DIR = mysql_connect("localhost","nethn_admin","admin32");
	mysql_select_db($db,$DIR)or die("Error al conectar a la base de datos seleccionada");
	mysql_query ("SET NAMES  'utf8'");

	echo "
	
	<style type='text/css'>
	<!--
	.cabecera{ color: white ;background-color:#172C3D;}
	.cabecera2{ color: white ;background-color:#006666;}
	#ventana{ position:absolute; left:35%; top:30%}
	#ventanabusqueda{ position:absolute; left:20%; top:30%}
	.consulta {background-color: #EEF8FF;}

	-->
	</style>
	";

	echo "<meta http.equiv='content-type' content='text/html; charset=utf-8'>
            <link href='style/style.css' rel='stylesheet' type='text/css' media='screen' />";



			
	function cabecera($ID_PRIVILEGIO,$ID_USUARIO)
	{
		global $FECHA_LETRA;  
		$RUTAIMAGENCABECERA='./img/estructura/titulo.png';
                $NOMBREEMPRESA = "Panel Control";
           
		if($ID_PRIVILEGIO!=0)
		{
		   $sql = "select * from t_usuarios  inner join t_tipos_usuarios on t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario where t_usuarios.id_usuario=".$ID_USUARIO."";
                    $BUSQUEDA_NOMBRESUCURSAL= mysql_query($sql);
	        if(mysql_num_rows($BUSQUEDA_NOMBRESUCURSAL)==0)
                {
                    $NOMBRESUCURSAL = "Administrator";
                }else{
                    $NOMBRESUCURSAL = ucfirst(strtolower(mysql_result($BUSQUEDA_NOMBRESUCURSAL,0,'tipo_usuario')));
                }
                $sql = "SELECT t_privilegios.nombre FROM  t_privilegios WHERE t_privilegios.id_privilegio = ".$ID_PRIVILEGIO."";
			$QUERY_P = mysql_query($sql)or die("no se pude realizar el sql");
			$sql = "SELECT t_personal.p_nombre,t_personal.p_apellido,t_usuarios.id_tipo_usuario FROM  t_personal inner join t_usuarios on t_personal.id_personal = t_usuarios.id_personal  WHERE t_usuarios.id_usuario= ".$ID_USUARIO."";
			$QUERY_N = mysql_query($sql)or die("no se pude realizar el sql");
			echo "
				<div id='nobodybusqueda'  name='nobodybusqueda' style='POSITION: absolute;'></div>
	<div id='nobody' name='nobody' style='POSITION: absolute;'></div>
	<div id='wrapper' >
		<div id='wrapper2'>
			<div id='header' style='background-image:url($RUTAIMAGENCABECERA);background-repeat:no-repeat;'>
				<div id='logo'>
						
						
				</div>
				<div id='menu'>
                      <!--Menu-->
				</div>
			</div>
			
				<table width='1024' border='0' align='center' cellpadding='0' cellspacing='0'  >
				<tr><td align=center>
				
				<div id='page'>			
				<table width='995' border='0' cellpadding='0' cellspacing='0'  align='center'>
				<tr><td height='35' >
				
					<table width='970' border='0' align='center' cellpadding='0' cellspacing='0'>
					<tr  valign=middle style='height:45px'><td width=20% align='left'>&nbsp;".$FECHA_LETRA."</td><td width=50% align=center>";?> 
					<?php
			$sql22 = "SELECT * FROM  t_grados";
			$resultado22 = mysql_query($sql22)or die("no se pude realizar el sql");
			$numero=0;	
				
				 
echo "<marquee  BGCOLOR=#028DD5; direction='left';  scrollamount='4';  id='marque'><FONT FACE=arial COLOR=white SIZE=4>";
 
while($row=mysql_fetch_assoc($resultado22)){
 
	?>
 
	<?php
 
	//echo " {$row['tpo_evento']}:{$row['evento']}"."<br>";
 
  echo "{$row['nombre']}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
 
	$numero++;

}	 
				 
echo "</FONT><br></marquee></td>";
 			 
				 ?>
                 
                 
                 	
<?php	
		echo "
                    <td width=20% align=right>".mysql_result($QUERY_N, 0, "P_NOMBRE")." ".mysql_result($QUERY_N, 0, "P_APELLIDO")."  (<a href='login.php?XIAUEORPGDJD=WIUEHRIDKFL' title='Cerrar Sesi&oacute;n'> Salir </a>)&nbsp;&nbsp;</td></tr>

					</table>
					
				
				</td></tr>
				<tr ><td >
				
				<table width='970' border='0' align='center' cellpadding='1' cellspacing='1' bgcolor=white  >
				<tr><td valign=top width =160 align=center>";
				menu_principal(mysql_result($QUERY_N,0,"id_tipo_usuario"),$ID_PRIVILEGIO);
				echo "</td>

				</td><td valign=top>
				<table width='800' border='0' align='center' cellpadding='0' cellspacing='0' bgcolor=white  >
				<tr ><td height='80' background='img/estructura/cafe2.png'><font color=white><h3>&nbsp;&nbsp;&nbsp;".mysql_result($QUERY_P,0,"nombre")."</h3></font></td></tr>
				
				<tr><td align=center>";
		}else{
			
			echo "
				<table width='1024' border='0' align='center' cellpadding='0' cellspacing='0'  >
				<tr><td align=center>
				<table width='995' border='0' cellpadding='0' cellspacing='0' align='center'>
				<tr><td height='35' >
					<table width='970' border='0' align='center' cellpadding='0' cellspacing='0'>
					<tr><td >&nbsp;&nbsp;Usuario Actual: Iniciar Sesi&oacute;n</td><td align=right>".$FECHA_LETRA."</td></tr>
					</table>
					
				
				</td></tr>
				<tr ><td >
				
				<table width='970' border='0' align='center' cellpadding='1' cellspacing='1' bgcolor=white  >
				<tr><td valign=top>
				<table width='970' border='0' align='center' cellpadding='0' cellspacing='0' bgcolor=white  >
				<tr><td height='80' background='img/estructura/cafe2.png' ><font color=white><h3>&nbsp;&nbsp;&nbsp;Iniciar Sesi&oacute;n</h3></font>			</td></tr>
				
				<tr><td align=center>";
			
		}
		
		
	}
	
	function piecera($ID_PRIVILEGIO)
	{
		if($ID_PRIVILEGIO!=0)
		{
			$sql = "SELECT t_privilegios.descripcion FROM  t_privilegios WHERE t_privilegios.id_privilegio = ".$ID_PRIVILEGIO."";
			$QUERY_P = mysql_query($sql)or die("no se pude realizar el sql");
			echo "
			
				</td></tr>
				</table>
				</td></tr>
				</table>
				</td></tr>
				<tr><td height=0></td></tr>
				<tr><td height=0>
								</td></tr>
				<tr><td height=0 align=center valign=bottom></td></tr>
				</table>
				</td></tr></table>
				
				
				
			";
			
			
			$ESTADISTICA="";
				
				$ESTADISTICA=$ESTADISTICA."<table  border='0' cellspacing=4 cellpadding=4 style='width:300px'>";
                //$QUERY3= mysql_query("select T_USUARIOS.NOMBRE_USUARIO,T_TIPOS_USUARIOS.TIPO_USUARIO FROM T_PERSONAL INNER JOIN T_USUARIOS ON T_PERSONAL.ID_PERSONAL = T_USUARIOS.ID_PERSONAL INNER JOIN T_TIPOS_USUARIOS ON T_USUARIOS.ID_TIPO_USUARIO = T_TIPOS_USUARIOS.ID_TIPO_USUARIO WHERE MD5(T_USUARIOS.ID_USUARIO)='".$ID_USUARIO."'") or die("Error");
					//$ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Nombre de Usuario</td><td align=right> ".mysql_result($QUERY3, 0, "NOMBRE_USUARIO")."</td></tr>";
               //$ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Tipo de Usuario</td><td align=right>".ucwords(strtolower(mysql_result($QUERY3, 0, "TIPO_USUARIO")))."</td></tr>";
         
               $ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Direcci&oacute;n IP</td><td align=right>".$_SERVER['REMOTE_ADDR']."  </td></tr>";
		 
		
			/*	$QUERY5= mysql_query("select TIME_FORMAT( HORA_AUDITORIA, '%h:%i %p' ) AS HORA, FECHA_AUDITORIA AS FECHA_LETRA from T_AUDITORIAS WHERE ID_USUARIO = ".$ID_USUARIO." AND T_AUDITORIAS.INSTRUCCION LIKE '%SELECT * FROM T_USUARIOS%' ");
				if(mysql_num_rows($QUERY5)>1)
				{

                    $FECHA_LETRA = DESCONVERT_FECHAS(mysql_result($QUERY5,mysql_num_rows($QUERY5)-2,"FECHA_LETRA"))." ".mysql_result($QUERY5,mysql_num_rows($QUERY5)-2,"HORA");
		
				}else{
					 $FECHA_LETRA = DESCONVERT_FECHAS(mysql_result($QUERY5,0,"FECHA_LETRA"))." ".mysql_result($QUERY5,0,"HORA");
				}
				
    		   $ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Ultima Visita</td ><td align=right> ".$FECHA_LETRA."</td></tr>";
                $ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Visitas al Sistema </td ><td align=right> ".mysql_num_rows($QUERY5)."</td></tr>";
				
                $QUERY6= mysql_query("select COUNT(*) AS NUMERO from T_AUDITORIAS WHERE T_AUDITORIAS.INSTRUCCION LIKE '%SELECT * FROM T_USUARIOS%' AND DATE_FORMAT(FECHA_AUDITORIA, '%c-%d-%Y') = DATE_FORMAT( ADDTIME( NOW( ) , '0 0:30:0' ) , '%c-%d-%Y' ) AND ID_USUARIO = ".$ID_USUARIO."" );
			
                           
             $ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Visitas (Hoy)</td ><td align=right> ".mysql_result($QUERY6,0,"NUMERO")."</td></tr>";*/
			
			$VISITAS=explode(",",$_SESSION['VISITA']);
			$ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Ultima Visita</td ><td align=right> ".$VISITAS[0]."</td></tr>";
			$ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Visitas al Sistema </td ><td align=right> ".$VISITAS[1]."</td></tr>";
			$ESTADISTICA=$ESTADISTICA."<tr><td align='left'>Visitas (Hoy)</td ><td align=right> ".$VISITAS[2]."</td></tr>";
			
			 $ESTADISTICA=$ESTADISTICA."</table>";
				
					
				echo"
                <!-- end #Menu -->
                <div style='clear: both;'>&nbsp;</div>
                    <div id='widebar'>
						<div id='colA'>
						
						
					</div>   
                    
					
					
					
					<dl class='list1'>
</dl>
				</div>
				<div id='colC'>
							
							<ul class='list2'>
								
							</ul>
				</div>
                    <div style='clear: both;'>&nbsp;</div>
                    
				</div>
                ";			
			
			
			
		echo "
			</div>
			<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id='footer'>
		<p>Todos los Derechos Reservados 2018. <br></p>
	</div>
</div>
<!-- end #wrapper -->

              

            ";
			
		}else{
			
				echo "
				</td></tr>
				</table>
				</td></tr>
				</table>
				</td></tr>
				<tr><td height=10></td></tr>
				<tr><td height=25>
				<table width='970' border='0' align='center' cellpadding='0' cellspacing='0'  bgcolor='#001500' height=25 >
				<tr  background='img/estructura/ayuda.jpg'><td><font color=white>&nbsp;&nbsp;<b>Ayuda:</b>&nbsp;&nbsp;</font></td>
				<td><marquee scrolldelay=100><font color=white>Para ingresar al sistema debe iniciar sesi&oacute;n, complete los datos correspondientes y presione el boton 'Entrar' para validar su cuenta. Recuerde que el sistema solo admite n&uacute;meros y letras sin caracteres especiales.</font></marquee></td></tr>
				</table>
				</td></tr>
				<tr><td height=25 align=center valign=bottom><font color=white>Desarrollado por bavaroexcursions</font></td></tr>
				</table>
				</td></tr></table>
				
			";
		}
	}
function menu_principal($ID_TIPO_USUARIO,$ID_PRIVILEGIO)
{
		global $COLOR;
	            
	      	$SQL = "select t_privilegios.categoria,t_privilegios.url,t_privilegios.nombre  from t_tipos_usuarios  inner join t_tipos_usuarios_privilegios on t_tipos_usuarios.id_tipo_usuario=t_tipos_usuarios_privilegios.id_tipo_usuario inner join t_privilegios on  t_tipos_usuarios_privilegios.id_privilegio=t_privilegios.id_privilegio  where t_tipos_usuarios_privilegios.id_tipo_usuario = ".$ID_TIPO_USUARIO."   ORDER BY t_privilegios.categoria";
                 $QUERY = mysql_query($SQL)or die("no se pude realizar el sql");
                $sql = "SELECT t_privilegios.categoria FROM  t_privilegios WHERE t_privilegios.id_privilegio = ".$ID_PRIVILEGIO."";
		$QUERY_P = mysql_query($sql)or die("no se pude realizar el sql");


		$AUXCAT="";
		if(mysql_num_rows($QUERY)!=0)
              {
						  
					echo "<table border=1 cellpadding=2 cellspacing=2 width=150>";
					
					
					for($j=0;$j<mysql_num_rows($QUERY);$j++)
					{
						
						if($AUXCAT!=mysql_result($QUERY,$j,"categoria"))
						{	
							$AUXCAT=mysql_result($QUERY,$j,"categoria");
                                                        if(mysql_result($QUERY_P,0,"categoria")==$AUXCAT)
                                                        {
                                                            echo" </table></div><table border=0 cellpadding=0 cellspacing=1 width=150><tr   style='background: url(img/estructura/categoria_5_p.png) no-repeat' onClick=menu('".mysql_result($QUERY,$j,"categoria")."') ><td height=25 align=left  onmouseover=this.style.cursor='pointer' ><label onmouseover=this.style.cursor='pointer' ><b>&nbsp;&nbsp;".mysql_result($QUERY,$j,"categoria")."</b></label></td></tr></table><div id='".mysql_result($QUERY,$j,"categoria")."' ><table border=0 cellpadding=0 cellspacing=1 width=150 >";
                                                        }else{

                                                             echo" </table></div><table border=0 cellpadding=0 cellspacing=0 width=150><tr  style='background: url(img/estructura/categoria_5_p.png) no-repeat'  onClick=menu('".mysql_result($QUERY,$j,"categoria")."') ><td height=25   onmouseover=this.style.cursor='pointer' background='img/estructura/categoria.jpg'><label onmouseover=this.style.cursor='pointer' >&nbsp;".mysql_result($QUERY,$j,"categoria")."</label></td></tr></table><div id='".mysql_result($QUERY,$j,"categoria")."'><table border=0 cellpadding=0 cellspacing=1 width=150 >";

                                                        }
						}
						
				
									   
							 echo "<tr height=25  ><td align='left' onmouseover=this.style.cursor='pointer'  onClick=document.location='".mysql_result($QUERY,$j,"url")."'  ><label  onmouseover=this.style.cursor='pointer' >&nbsp;".mysql_result($QUERY,$j,"nombre")."</label></td></tr>";
							
						 
					}
					echo "</table></div>";
							
               }else{
			
						echo "<table border=0 cellpadding=0 cellspacing=0 width=150>";
						echo "<tr  bgcolor=#000000 onClick=menu('Principal')><td height=25 align='left'  onmouseover=this.style.cursor='pointer'   ><label><font color='white' onmouseover=this.style.cursor='pointer'><b>&nbsp;Principal</b></font></label></td></tr></table>

			<div id='Principal'><table border=0 cellpadding=0 cellspacing=2 width=150 >";
						 echo "<tr height=25  bgcolor=#f7f7f7 ><td  onmouseover=this.style.cursor='pointer'   onClick=document.location='inicio.php'  ><label onmouseover=this.style.cursor='pointer' title='Volver al inicio'>&nbsp;Inicio</label></td></tr>";
						 echo "<tr height=25  bgcolor=#f7f7f7 ><td  onmouseover=this.style.cursor='pointer'   onClick=document.location='login.php?XIAUEORPGDJD=WIUEHRIDKFL'><label onmouseover=this.style.cursor='pointer' title='Permite cerrar la sesi&oacute;n que se encuentre activa'>&nbsp;Cerrar sesi&oacute;n</label></td></tr></table></div>"; 
					
		}
            //echo "<tr><td></td></tr>";
            
            echo "<table border=0 cellpadding=0 cellspacing=0 width=150><tr style='background: url(img/estructura/fincategoria1.jpg)  no-repeat' height=20 ><td >&nbsp;</td></tr></table>";
	
	
	
	
	
	

}
		
	function REDIRIGIR($URL)
	{
		echo "
			<script language='javascript'>
				document.location='".$URL."';
			</script>
		";
	}	
	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
			
				alert('".$MSJ."');
				
			</script>
		";
	}
	
	function ASIG_VALOR($TIPO_INPUT,$LIMITE,$OBJETO,$VALOR)
	{
		//0 PARA CAJAS DE TEXTO
		//1 PARA COMBOBOX CON VALUE NUMERICO
		//2 PARA CHECKBOX
		//3 PARA COMBOBOX CON VALUE NUMERICO
		if($TIPO_INPUT==0)
		{
			echo "
				<script language='javascript'>
					if(!document.getElementById('".$OBJETO."'))
					{
						ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
					}else{
						document.getElementById('".$OBJETO."').value = '".$VALOR."';
					}
				</script>
			";
		}
		
		
		if($TIPO_INPUT==1)
		{
			echo "
				<script language='javascript'>
					i = 0;
					for(i=0;i<".$LIMITE.";i++)
					{
						if(!document.getElementById('".$OBJETO."'))
						{
							ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
						}else{
							document.getElementById('".$OBJETO."').selectedIndex = i;
							
							if(document.getElementById('".$OBJETO."').value==".$VALOR.")
							{
								document.getElementById('".$OBJETO."').selectedIndex = i;
								break;
							}
						}
					}
				</script>
			";
		}
		
		if($TIPO_INPUT==2)
		{
		
			if($VALOR=='SI') 
			{
			
				echo "
				
					<script language='javascript'>
						if(!document.getElementById('".$OBJETO."'))
						{
							ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
						}else{
							
								document.getElementById('".$OBJETO."').checked = true;
						}
					</script>
				";
			}else{
			
				echo "
					
						<script language='javascript'>
							if(!document.getElementById('".$OBJETO."'))
							{
								ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
							}else{
								
									document.getElementById('".$OBJETO."').checked = false;
							}
						</script>
					";
						
				
				}
			
		}
		 
		if($TIPO_INPUT==3)
		{
			echo "
				<script language='javascript'>
					i = 0;
					for(i=0;i<".$LIMITE.";i++)
					{
						if(!document.getElementById('".$OBJETO."'))
						{
							ALERT('ERROR CRITICO. NO SE ENCUENTRA EL OBJETO ".$OBJETO."');
						}else{
							document.getElementById('".$OBJETO."').selectedIndex = i;
							
							if(document.getElementById('".$OBJETO."').value=='".$VALOR."')
							{
								document.getElementById('".$OBJETO."').selectedIndex = i;
								break;
							}
						}
					}
				</script>
			";
		}
	}


	
	

	
	function CORRER_TRANSACCION($QUERY_ARRAY)
	{
		
	
		$QUERY_ERROR =  array();
		mysql_query("SET AUTOCOMMIT=0;	START TRANSACTION;");

                for($i=0;$i<count($QUERY_ARRAY);$i++)
                {

                                $QUERY= mysql_query($QUERY_ARRAY[$i]);
                                if($QUERY=="")
                                {
                                        $QUERY_ERROR[]=$QUERY_ARRAY[$i];

                                }

                }
                if(count($QUERY_ERROR)==0)
                {
                        mysql_query("COMMIT;");
                        return O;

                }else{

                        mysql_query("ROLLBACK;");
                        return 1;

                }
				
	
	
	}
	
	

	
	
	function COMBO_PARENTESCO()
	{
			
			echo "<select name='CMBPARENTESCO' id='CMBPARENTESCO' style='width:170px'>";
               	$QUERY= mysql_query("select * from T_PARENTESCOS  ");
				echo "<option value=-1></option>";	
                 mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_PARENTESCO").">".mysql_result($QUERY,$i,"PARENTESCO")."</option>";
				}
              	echo "</select>";

	}
	
	function COMBO_MATERIAS()
	{
			
			echo "<td><select name='CMBMATERIAS' id='CMBMATERIAS'>";
               	$QUERY= mysql_query("select * from T_MATERIAS  ");
              	mysql_num_rows($QUERY);
              	echo "<option value=-1></option>";	
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_MATERIA").">".mysql_result($QUERY,$i,"MATERIA")." </option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_A_ESCOLAR()
	{
			
			echo "<td><select name='CMBAESCOLAR' id='CMBAESCOLAR'>";
               	$QUERY= mysql_query("select * from T_A_ESCOLAR  ORDER BY FECHA DESC");
				
              	mysql_num_rows($QUERY);
				
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					$AUX = mysql_result($QUERY,$i,"FECHA");
					$FECHA_ARRAY = explode("-",$AUX);
					$AUX = $FECHA_ARRAY[0];
					echo "<option value=".mysql_result($QUERY,$i,"ID_A_ESCOLAR").">".mysql_result($QUERY,$i,"DESCRIPCION")." </option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_A_ESCOLAR_ANO()
	{
			
			echo "<td><select name='CMBAESCOLAR_A' id='CMBAESCOLAR_A'>";
               	$QUERY= mysql_query("select * from T_A_ESCOLAR  ORDER BY FECHA DESC");
				
              	mysql_num_rows($QUERY);
				
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					$AUX = mysql_result($QUERY,$i,"FECHA");
					$FECHA_ARRAY = explode("-",$AUX);
					$AUX = $FECHA_ARRAY[0];
					echo "<option value=".$AUX.">".mysql_result($QUERY,$i,"DESCRIPCION")." </option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_AULAS()
	{
			
			echo "<td><select name='CMBAULAS' id='CMBAULAS'  style='width:80px'>";
               	$QUERY= mysql_query("select * from T_AULAS  ");
              	mysql_num_rows($QUERY);
				echo "<option value=-1></option>";
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_AULA").">".mysql_result($QUERY,$i,"AULA")." </option>";
				}
              	echo "</select></td> ";

	}
	
		function COMBO_ESTADOS()
	{

				echo "<select 'CMBESTADOS' id='CMBESTADOS' name='CMBESTADOS'  style='width:250px' onChange='cambiarciudad()' >";
               	$QUERY= mysql_query("select * from T_ESTADOS ORDER BY ESTADO");
			echo "<option value=-1></option>";
                 	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_ESTADO").">".mysql_result($QUERY,$i,"ESTADO")."</option>";
				}
				echo "</select>";



	}
	
		function COMBO_PAIS()
	{

				echo "<select  id='CMBPAIS' name='CMBPAIS'  style='width:250px' onChange='cambiarestado()' >";
               	$QUERY= mysql_query("select * from T_PAIS ORDER BY PAIS");
			echo "<option value=-1></option>";
                 	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_PAIS").">".mysql_result($QUERY,$i,"PAIS")."</option>";
				}
				echo "</select>";



	}
	function COMBO_ALTURA()
	{
			
			echo "<td><select name='CMBALTURA' id='CMBALTURA' >";
              	echo "<option value=-1></option>";
               	for($i=40;$i<221;$i++)
				{
					echo "<option value=".$i.">".$i."</option>";
				}
              	echo "</select></td> ";

	}
		function COMBO_PESO()
	{
			
			echo "<td><select name='CMBPESO' id='CMBPESO' >";
              	echo "<option value=-1></option>";
               	for($i=10;$i<201;$i++)
				{
					echo "<option value=".$i.">".$i."</option>";
				}
              	echo "</select></td> ";

	}
	function COMBO_GRADOS()
	{
			
			echo "<td><select name='CMBGRADOS' id='CMBGRADOS'onChange='cargarseccion()' >";
               	$QUERY= mysql_query("select * from T_GRADOS order by ETAPA,GRADO,NIVEL");
              	echo "<option value=-1></option>";
				mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_GRADO").">".mysql_result($QUERY,$i,"GRADO")." ".mysql_result($QUERY,$i,"NIVEL")."</option>";
				}
              	echo "</select></td> ";

	}

	function COMBO_CIUDADES()
	{

			echo "<select name='CMBCIUDADES' id='CMBCIUDADES' style='width:250px'>";
			echo "<option value=-1></option>";
			echo "</select>";

	}
	function COMBO_SEXO()
	{
			echo "<td><select name='CMBSEXO' id='CMBSEXO' style='width:170px'>";
			echo "<option value='M'>MASCULINO</option>";
			echo "<option value='F'>FEMENINO</option>";
			echo "</select></td> ";
	}
	
		function COMBO_DIAS()
	{
			echo "<select name='CMBDIA' id='CMBDIA' style='width:170px'>";
			echo "<option value='DOMINGO'>DOMINGO</option>";
			echo "<option value='LUNES'>LUNES</option>";
			echo "<option value='MARTES'>MARTES</option>";
			echo "<option value='MIERCOLES'>MIERCOLES</option>";
			echo "<option value='JUEVES'>JUEVES</option>";
			echo "<option value='VIERNES'>VIERNES</option>";
			echo "</select> ";
	}
	
	function COMBO_ESTADOCIVIL()
	{
			echo "<td><select name='CMBCIVIL' id='CMBCIVIL' style='width:170px'>";
			echo "<option value='SO'>SOLTERO(A)</option>";
			echo "<option value='CA'>CASADO(A)</option>";
			echo "<option value='C0'>CONCUBINO(A)</option>";
			echo "<option value='DI'>DIVORCIADO(A)</option>";
			echo "<option value='VI'>VIUDO(A)</option>";
			echo "</select></td> ";
	}
	function COMBO_NIVEL()
	{
			echo "<td><select name='CMBNIVEL' id='CMBNIVEL'>";
			echo "<option value=PRIMARIA>PRIMARIA</option>";
			echo "<option value=BASICA>BASICA</option>";
			echo "<option value=DIVERSIFICADO>DIVERSIFICADO</option>";
			echo "</select></td> ";
	}
	function COMBO_SECCION()
	{
		echo "<select name='CMBSECCION' id='CMBSECCION'  style='width:100px' >"; 
		echo "<option value=-1></option>";
		foreach(range('A', 'Z') as $letras) 
		{ 
			echo "<option value=\"$letras\">$letras</option>"; 
		}
		echo "<option value='*'>*</option>";
		echo "</select>"; 
	} 
	function COMBO_PROFESION()
	{
		 echo "<select name='CMBPROFESION' id='CMBPROFESION' style='width:300px'>";
					$QUERY= mysql_query("select * from T_PROFESIONES  ");
					mysql_num_rows($QUERY);
					echo "<option value=-1></option>";	
					for($i=0;$i<mysql_num_rows($QUERY);$i++)
					{
						echo "<option value=".mysql_result($QUERY,$i,"ID_PROFESION").">".mysql_result($QUERY,$i,"PROFESION")." </option>";
					}
					echo "</select>";
	}
	
	function DESCONVERT_FECHAS($FECHA)
	{
		//DD-MM-YYYY
		$FECHA_ARRAY = explode("-",$FECHA);
		$AUX = $FECHA_ARRAY[2]."-".$FECHA_ARRAY[1]."-".$FECHA_ARRAY[0];
		return $AUX;
	}
	function COMBO_LAPSO()
	{
		$SQL = "select * from T_LAPSOS INNER JOIN T_LAPSOS_GLOBALES ON T_LAPSOS.ID_LAPSO_GLOBAL = T_LAPSOS_GLOBALES.ID_LAPSO_GLOBAL order by LAPSO_GLOBAL,LAPSO";
		$BUSCAR_LAPSOS = mysql_query($SQL)or die("no se pudo realizar el SQL");
		echo "<select name='CMBLAPSO' id='CMBLAPSO' onChange=limpiar()>"; 
		echo "<option value='-1'>&nbsp;</option>";
		for($i=0;$i<mysql_num_rows($BUSCAR_LAPSOS);$i++)
		{ 
			echo "<option value=".mysql_result($BUSCAR_LAPSOS,$i,"ID_LAPSO").">".mysql_result($BUSCAR_LAPSOS,$i,"LAPSO_GLOBAL")."-".mysql_result($BUSCAR_LAPSOS,$i,"LAPSO")."</option>"; 
		}
		echo "</select>"; 
	}
	function COMBO_ACTIVO()
	{
		echo "
			<td>
			<select name=CMBACTIVO ID=CMBACTIVO>
			<option value=SI>SI</option>
			<option value=NO>NO</option>
			</select>
			</td>
		";
	}
	
		function OBTENER_LITERAL($LITERAL)
	{
		$AUX="";
		$SQL = "select * from T_LITERALES";
		$BUSCAR_LITERALES = mysql_query($SQL)or die("no se pudo realizar la busqueda del literal");
		for($i=0;$i<mysql_num_rows($BUSCAR_LITERALES);$i++)
		{
			if(($LITERAL>=mysql_result($BUSCAR_LITERALES,$i,"INTERVALOINI")) and ($LITERAL<=mysql_result($BUSCAR_LITERALES,$i,"INTERVALOFIN")))
			{
				$AUX= mysql_result($BUSCAR_LITERALES,$i,"LITERAL");
			}	
		}
		return $AUX;
	}
	
	function COMBO_LITERALES()
	{
		$SQL = "select * from T_LITERALES order by INTERVALOFIN DESC";
		$BUSCAR_LITERALES = mysql_query($SQL)or die("no se pudo realizar la busqueda del literal");
		for($i=0;$i<mysql_num_rows($BUSCAR_LITERALES);$i++)
		echo "<select name='CMBLITERALES' id='CMBLITERALES'>"; 
		echo "<option value='-1'>&nbsp;</option>";
		for($i=0;$i<mysql_num_rows($BUSCAR_LITERALES);$i++)
		{ 
			echo "<option value=".mysql_result($BUSCAR_LITERALES,$i,"ID_LITERAL").">".mysql_result($BUSCAR_LITERALES,$i,"LITERAL")."</option>"; 
		}
		echo "</select>"; 
	}
	
	function COMBO_MESES()
	{
		$MES_ARRAY = array("ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO","JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE");
		echo "<td><select name='CMBMESES' id='CMBMESES'>";
		echo "<option value='-1'>--</option>";
		for($i=0;$i<12;$i++)
		{
			echo "<option value='".($i+1)."'>".$MES_ARRAY[$i]."</option>";
		}
		echo "</select></td>";
	}
	function CONVERT_FECHAS($FECHA)
	{
		//YYYY-MM-DD
		$FECHA_ARRAY = explode("-",$FECHA);
		$AUX = $FECHA_ARRAY[2]."-".$FECHA_ARRAY[1]."-".$FECHA_ARRAY[0];
		return $AUX;
	}

	function HABILITAR($OBJETO,$ACCION)
	{
		if($ACCION == 0)
		{
		echo "
			<script language='javascript'>
				document.getElementById('".$OBJETO."').disabled = true;
			</script>
		";
		}else{
		echo "
			<script language='javascript'>
				document.getElementById('".$OBJETO."').disabled = false;
			
			</script>
		";
		}
	}	
	
	function SABERDIA($DIA)
	{
		if($DIA==1)
		{ return "DOMINGO";}
		if($DIA==2)
		{ return "LUNES";}
		if($DIA==3)
		{ return "MARTES";}
		if($DIA==4)
		{ return "MIERCOLES";}
		if($DIA==5)
		{ return "JUEVES";}
		if($DIA==6)
		{ return "VIERNES";}
		if($DIA==7)
		{ return "SABADO";}
		
	}	
	function SABERMES($MES)
	{
		if($MES==1)
		{ return "ENERO";}
		if($MES==2)
		{ return "FEBRERO";}
		if($MES==3)
		{ return "MARZO";}
		if($MES==4)
		{ return "ABRIL";}
		if($MES==5)
		{ return "MAYO";}
		if($MES==6)
		{ return "JUNIO";}
		if($MES==7)
		{ return "JULIO";}
		if($MES==8)
		{ return "AGOSTO";}
		if($MES==9)
		{ return "SEPTIEMBRE";}
		if($MES==10)
		{ return "OCTUBRE";}
		if($MES==11)
		{ return "NOVIEMBRE";}
		if($MES==12)
		{ return "DICIEMBRE";}
	}
	function SABERQUINCENA($QUINCENA)
	{
		if($QUINCENA==1)
		{ return "1 ERA QUINCENA";}
		if($QUINCENA==2)
		{ return "2 DA QUINCENA";}
		
	}
	function CREAR_NOMBRE_USUARIO($NOMBRE_USUARIO)
	{
		$SQL= "SELECT * FROM T_USUARIOS WHERE NOMBRE_USUARIO = '".$NOMBRE_USUARIO."'";
		$QUERY = mysql_query($SQL);
		if(mysql_num_rows($QUERY)==0)
		{
			return $NOMBRE_USUARIO;
		}else{
			
			for($i=1;$i<100;$i++)
			{
				$NOMBRE_USUARIO_AUX = $NOMBRE_USUARIO."".$i;
				$SQL= "SELECT * FROM T_USUARIOS WHERE NOMBRE_USUARIO = '".$NOMBRE_USUARIO_AUX."'";
				$QUERY = mysql_query($SQL);
				if(mysql_num_rows($QUERY)==0)
				{
					$NOMBRE_USUARIO = $NOMBRE_USUARIO_AUX;
					$i=100;
				}
			}	
			
			return $NOMBRE_USUARIO;
			
		}
	}
	
	function SUMADIAS($fecha,$dia)
	{	
			list($year,$mon,$day) = explode('-',$fecha);	
			return date('Y-m-d',mktime(0,0,0,round($mon),round($day+$dia),round($year)));	
	}
	echo "<div id='nobodybusqueda' style='LEFT: 100px; TOP: 50px; POSITION: absolute;'></div>"; 
	echo "<div id='nobody'></div>";
	echo "<div id='divalerta' style='POSITION: fixed; top:0;'></div>"; 
   
   $FECHA_ARRAY = explode("-",date('Y-m-d'));
	$ANOFIRMA =$FECHA_ARRAY[0];
	
	$SQL_FECHA_ACTUAL ="SELECT DATE_FORMAT( ADDTIME( NOW( ) , '0 7:30:0' ) , '%h:%i %p' ) AS HORA, DATE_FORMAT( ADDTIME( NOW( ) , '0 7:30:0' ) , '%w-%d-%c-%Y' ) AS FECHA_LETRA";
	$QUERY_FECHA_ACTUAL = mysql_query($SQL_FECHA_ACTUAL)or die("no se puede realizar el sql, busqueda de usuario abortada");
	
	$FECHA_LETRAS = explode("-",mysql_result($QUERY_FECHA_ACTUAL,$i,"FECHA_LETRA"));
	
	$FECHA_LETRA = ucfirst(strtolower(SABERDIA($FECHA_LETRAS[0]+1)))." ".$FECHA_LETRAS[1]." de ".ucfirst(strtolower(SABERMES($FECHA_LETRAS[2])))." del ".$FECHA_LETRAS[3];
	$HORA = mysql_result($QUERY_FECHA_ACTUAL,0,"HORA");
	
?>

