<?php
	session_name('MIORDEN');
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ceorep.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	if($ID_USUARIO != "")
	{
		$VERIFICAR = mysql_query("select * from t_usuarios where id_usuario=".$ID_USUARIO."");
	
		if(mysql_num_rows($VERIFICAR)== 0)
		{
			MESSAGE('-Error al iniciar sesion.');
			REDIRIGIR('login.php');
		}
	}else
	{
		REDIRIGIR('login.php');
	}
	
		




require('pdf/fpdf.php');
class PDF extends FPDF
{
	
	
	
	function Tabla($ID_A_ESCOLAR)
	{
	
		$SQL = "select * from t_actividades order by id_actividad";

		$BUSQUEDA_DOCENTES= mysql_query($SQL)or die("error en el sql para buscar rutas");
		$this->SetTextColor(255,255,255);
		$this->SetFont('Arial','IB',10);
		$this->SetX(12); 
		$this->Cell(10,6,"Nro",1,0,'C',1);
		$this->Cell(50,6,"Nombre Chofer",1,0,'L',1);
		$this->Cell(16,6,"Cedula",1,0,'L',1);
		$this->Cell(20,6,"Unidad",1,0,'L',1);
		$this->Cell(20,6,"Capac.",1,0,'L',1);
		$this->Cell(30,6,"Hora S.",1,0,'L',1);
		$this->Cell(30,6,"Hora L.",1,0,'L',1);
		$this->Cell(40,6,"destino",1,0,'L',1);
		$this->Ln();
			
		$this->SetTextColor(0,0,0);
		$this->SetFont('Arial','I',9);
		$fill=false;
		for($i=0;$i<mysql_num_rows($BUSQUEDA_DOCENTES);$i++)
		//for($i=0;$i<500;$i++)
		{
			$this->SetX(20);
			if($i%2==0)
			{
				$this->SetFillColor(255,255,255);
			}else{
				$this->SetFillColor(223,232,244);
			}
			$this->SetX(12);
			$this->SetFont('Arial','IB',9);
			$this->Cell(10,6,$i+1,1,0,'C',1);
			$this->SetFont('Arial','I',9);
			$this->Cell(50,6,mysql_result($BUSQUEDA_DOCENTES,$i,"observacion")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"observacion"),1,0,"L",1);
			$this->Cell(16,6,mysql_result($BUSQUEDA_DOCENTES,$i,"id_personal")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"id_personal"),1,0,"L",1);
			$this->Cell(20,6,mysql_result($BUSQUEDA_DOCENTES,$i,"id_grado")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"id_grado"),1,0,"L",1);
			$this->Cell(20,6,mysql_result($BUSQUEDA_DOCENTES,$i,"cantidad")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"cantidad"),1,0,"L",1);
			$this->Cell(30,6,mysql_result($BUSQUEDA_DOCENTES,$i,"horainicial")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"horainicial"),1,0,"L",1);
			$this->Cell(30,6,mysql_result($BUSQUEDA_DOCENTES,$i,"horainicial")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"horafinal"),1,0,"L",1);
			$this->Cell(40,6,mysql_result($BUSQUEDA_DOCENTES,$i,"id_areacomp")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"id_areacomp"),1,0,"L",1);
			//$this->Cell(35,6,number_format(mysql_result($BUSQUEDA_DOCENTES,$i,"grado"),0,"","."),1,0,'C',1);
			
			//$this->Cell(30,6,mysql_result($BUSQUEDA_DOCENTES,$i,"grado"),1,0,"C",1);
			$this->Ln();
			$fill=!$fill;
		}
		$this->SetX(12);
		$this->Cell(180,0,'','T');
		$this->SetFont('Arial','IB',10);
		$this->Ln(2);
		$this->SetX(12);
		$this->Cell(150,6,"TOTAL DE RUTAS: ".mysql_num_rows($BUSQUEDA_DOCENTES),0,0,'L',0);
	
	
	
	}
	
		function Cabecera($AUX)
		{
			$AUX2 = $AUX-1;
			global $HORA,$FECHA_LETRA;
			$this->SetFont('Arial','',10);
			
				$NOMBRE_ESCUELA="RUTAS FORANEAS ";
				$TIPO_ESCUELA="IUTM";
			
			$this->Image("img/estructura/logo.jpg",12,5,30);
			$w=165; //ANCHO DE LA TABLA
			$m=116;//
			$this->Ln(3);
                        $this->SetX($m);
			$this->Cell($w,4,$TIPO_ESCUELA,0,0,'L',0);
			$this->Ln();
			$this->SetX($m);
			$this->Cell($w,4,$NOMBRE_ESCUELA,0,0,'L',0);
			$this->Cell(45,4,$FECHA_LETRA,0,0,'R',0);
			$this->Ln();	

			$this->SetX(12); 
			$this->Cell(190,0.5,"",0,0,'C',true);
		
		
		
		}


		function Footer()
		{
			global $ANOFIRMA;
			//Posici�n a 1,5 cm del final
			$this->SetY(-10);
			$this->SetTextColor(128);
			$this->SetFont('Arial','I',10);
			$this->Cell(40,10,'Todos los Derechos Reservados rutasforaneasiutm.com'.$ANOFIRMA);
			$this->Cell(0,10,'Pag '.$this->PageNo(),0,0,'R');
		
		
		}
	

	
	
		function Titulo()
	{
			
		
		$this->SetTextColor(0,0,0);
		$this->SetFont('Arial','BU',11);
		$w=$this->GetStringWidth("LISTADO DE BUSES")+6;
		$this->SetY(28);
			
		$this->Ln(2);
		$this->SetX((210-$w)/2);
		$this->Cell($w,9," LISTADO DE BUSES ",0,0,'C',false);		
		$this->Ln(12);	
		
	
	}



}



$pdf=new PDF('P','mm','letter');
$pdf->AddPage();
$pdf->Cabecera($AUX);
$pdf->Titulo();
$pdf->Tabla($ID_A_ESCOLAR);
$pdf->Output();

?>