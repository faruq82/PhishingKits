<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	//$url = $_SERVER["REQUEST_URI"] ;
	$url = "compra_netflix.php" ;
	
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
$id = $_GET['id'];
require('ceoconexion.php');

//mysql_connect("localhost","root");
//mysql_select_db("pedidos");  

$sql = "SELECT * FROM alumnos_online WHERE id='$id'";
$result=mysql_query($sql);
mysql_query ("SET NAMES 'utf8'");
$row = mysql_fetch_assoc($result);
?>
<html>
<head>

<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language='javascript' src="scriptbusqueda.js"></script>
<script language="JavaScript" type="text/JavaScript">

var er_texto = /^[0-9]{4}$/;

	function validar()
	{

		
	 if(document.pago.creditodi.value<= 0)
     { alert(" NO DISPONE DE CREDITO PARA PODER REALIZAR LA COMPRA, DEBE COMUNICARSE CON VENTAS AL Whatsapp: +573113761056 ");
      return false;
      
	 }
	 
	 if(document.pago.creditodi.value< document.pago.vacredito.value)
     { alert(" NO DISPONE DE CREDITO PARA PODER REALIZAR LA COMPRA, DEBE COMUNICARSE CON VENTAS AL Whatsapp: +573113761056 ");
      return false;
      
	 } 
		
	}	
	

</script>
</script>
<style type="text/css">
<!--
.Estilo17 {color: #333333}
.Estilo20 {color: #FF0000}
.Estilo23 {font-family: Verdana, Arial, Helvetica, sans-serif; color: #333333; }
body {
	background-color: #FFFFFF;
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
.Estilo24 {
	color: #000000}
.Estilo27 {
	color: #0000FF;
	font-size: 12px;
}
.Estilo28 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 18px;
}
.Estilo29 {font-size: 18px}
table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo3 {font-size: 18px; }
.Estilo4 {
	font-size: 24px;
	font-weight: bold;
}
-->
</style>

</head>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<?php
$id = $_GET['id'];
$id2 = $_GET['id2'];
require('ceoconexion.php');
	
$sql = "SELECT * FROM alumnos_online WHERE id_personal='$id2'";
$result=mysql_query($sql);
mysql_query ("SET NAMES 'utf8'");
$row = mysql_fetch_assoc($result);

$sql1 = "SELECT * FROM t_hbo WHERE id_areacomp='$id'";
$result1=mysql_query($sql1);
mysql_query ("SET NAMES 'utf8'");
$row1 = mysql_fetch_assoc($result1);

        ?>
<form action='compra_hbone.php' method='post' name="pago" id="pago"onSubmit="return validar()">
               


<table border="0" cellpadding="2" cellspacing="2" align="center" width="780" class='normal' >
  <tr>
    <td colspan="2" align="center">
      </td>
  </tr>
  <tr bgcolor="#5fa6d7">
    <td height="28" colspan="2" align="center" class="headline2">Datos del comprador</td>
  </tr>
  <tr>
    <td colspan="2">              

      </td>
  </tr>
  <tr>
    <td width="234"  class="title Estilo17"><div align="right" class="Estilo24"> Usuario:</div></td>
    <td width="533"><?php  echo $row['nick']; ?><input tabIndex=1 size=30 name=seudonimo id=seudonimo value=<?php  echo $row['nick']; ?> type="hidden"></td>
    </tr>
  <tr>
    <td  class="title Estilo17"><div align="right" class="Estilo24"> Credito disponible:</div></td>
    <td ><?php  echo $row['creditos']; ?><input id=creditodi  tabIndex=7 maxLength=30 size=30 name=creditodi value=<?php  echo $row['creditos']; ?> type="hidden"></td>
  </tr>
  <tr>
    <td  class="title Estilo17"><div align="right" class="Estilo24"> Nombre Cuenta:</div></td>
    <td ><?php  echo $row1['url']; ?>
      <input name="nombre" type="hidden" id="nombre" tabindex="7" value="<?php  echo $row1['areacomp']; ?>   " size="80" ></td>
  </tr>
  <tr>
    <td  class="title Estilo17"><div align="right" class="Estilo24"> Valor Cuenta:</div></td>
    <td ><?php  echo $row1['descripcion']; ?><input id=vacredito  tabIndex=7 maxLength=30 size=20 name=vacredito value=<?php  echo $row1['descripcion']; ?> type="hidden"></td>
  </tr>
  <tr>
    <td colspan="2" align="center" class="headline2 Estilo17"><div align="right"><span class="Estilo24"></span></div></td>
  </tr>
  <tr>
    <td align="center"><input id=idpersonal  tabIndex=7 maxLength=30 size=30 name=idpersonal value=<?php  echo $id2; ?> type="hidden">
      <input id=id  tabIndex=7 maxLength=30 size=30 name=id value=<?php  echo $row1['id_areacomp']; ?> type="hidden"></td>
    <td ><input style="FONT-WEIGHT: bold; FONT-SIZE: 10pt" name="pago" type="submit" id="pago" value=" COMPRAR " ></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td align="center">&nbsp;</td>
    </tr>
  <tr>
    <td colspan="2" align="center">&nbsp;</td>
  </tr>
</table>
</form>


<?php    
	piecera($PRIVILEGIO);
?>

</body>
</html>
