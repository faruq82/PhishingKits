<?php
	include("ajaxordenconfig.php");
	$TXTIDENTIFICACION = $_POST['TXTIDENTIFICACION'];
	$TXTP_APELLIDO=$_POST['P_APELLIDO'];
	$TXTS_APELLIDO=$_POST['S_APELLIDO'];
	$TXTP_NOMBRE=$_POST['P_NOMBRE'];
	$TXTS_NOMBRE=$_POST['S_NOMBRE'];
	$TXTTELEFONO=$_POST['TXTTELEFONO'];
	$TXTTELEFONO2=$_POST['TXTTELEFONO2'];
	$TXTCORREO=$_POST['CORREO'];
	$CMBSEXO=$_POST['SEXO'];
	$TXTDIRECCION=$_POST['DIRECCION'];
	$ID_PERSONAL =$_POST['ID_PERSONAL'];
	$ID_USER =$_POST['ID_USER'];
	$ID_USUARIO =$_POST['ID_USUARIO'];
	$TIPO_USUARIO =$_POST['TIPO_USUARIO'];
	$ESTATUS_USUARIO =$_POST['ESTATUS_USUARIO'];
	$CMBSUCURSAL =$_POST['CMBSUCURSAL'];
	$ACCION = $_POST['ACCION'];

	if($ACCION=="GUARDAR")
	{
		$SQL=array();
		$SQL1= "SELECT * FROM  t_personal  WHERE cedula  ='".$TXTIDENTIFICACION."'  ";
		$QUERY = mysql_query($SQL1);
		if(mysql_num_rows($QUERY)!=0)
		{
			 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'yaexiste'>";
			return; 
		}
		
		$SQL[] ="INSERT INTO t_personal (cedula,p_apellido,s_apellido,p_nombre,s_nombre,sexo,direccion,celular,telefono,correo ) VALUES('".$TXTIDENTIFICACION."', '".$TXTP_APELLIDO."','".$TXTS_APELLIDO."','".$TXTP_NOMBRE."','".$TXTS_NOMBRE."','".$CMBSEXO."','".$TXTDIRECCION."','".$TXTTELEFONO."','".$TXTTELEFONO2."','".$TXTCORREO."')";
		if(CORRER_TRANSACCION($SQL)==1) 
		{
				 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
				unset($SQL);
				return; 
		}else{
					AUDITORIA($SQL);
					unset($SQL);
					$SQL1 = "select * from t_personal WHERE cedula ='".$TXTIDENTIFICACION."'";
					$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
					$ID_PERSONAL = mysql_result($SQL_CHK_EXISTENCIA,0,"id_personal");
					$SQL_TIPO_USUARIO=mysql_query("SELECT * FROM t_tipos_usuarios WHERE id_tipo_usuario = ".$TIPO_USUARIO."") or die("Error en el sql");
					if(mysql_num_rows($SQL_TIPO_USUARIO)!=0)
					{
					
						$SQL=array();
						$NOMBRE_USUARIO=$TXTIDENTIFICACION;
						$CONTRASENA = md5('123456',false);
						
						if($ESTATUS_USUARIO=="BLOQUEADO")
						{
							$ESTATUS_USUARIO="BLOQUEADO";
						
						}
						if($ESTATUS_USUARIO=="0")
						{
							$ESTATUS_USUARIO="";
						
						}
						if($ESTATUS_USUARIO=="DESBLOQUEADO")
						{
							$ESTATUS_USUARIO="";
						
						}
						if($ESTATUS_USUARIO=="BLOQUEADO")
						{
							$ESTATUS_USUARIO="BLOQUEADO";
						
						}
						if($ESTATUS_USUARIO=="REESTABLECER")
						{
							$ESTATUS_USUARIO="";
							
						
						}
						$SQL[] ="INSERT INTO t_usuarios (id_tipo_usuario,id_personal,nombre_usuario,contrasena,estatus_usuario) VALUES(".$TIPO_USUARIO.",".$ID_PERSONAL.",'".$NOMBRE_USUARIO."','".$CONTRASENA."','".$ESTATUS_USUARIO."')";
						
						if(CORRER_TRANSACCION($SQL)==1) 
						{
							 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
						}else{
							
							echo "<input type='hidden' id='AVISOMOFICIADO' value=''>";
						}
						unset($SQL);

					}else{
						
						 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
						
					}
				}
			
		
	}
	
	
	
	
	
	
	if($ACCION=="MODIFICAR")
	{
		$SQL=array();
		$SQL1= "SELECT * FROM t_personal  WHERE cedula  ='".$TXTIDENTIFICACION."' and NOT id_personal=".$ID_PERSONAL." ";
		$QUERY = mysql_query($SQL1);
		if(mysql_num_rows($QUERY)!=0)
		{
			 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'yaexiste'>";
			return; 
		}
		
		$SQL[] ="UPDATE t_personal SET cedula = '".$TXTIDENTIFICACION."',p_apellido = '".$TXTP_APELLIDO."',s_apellido = '".$TXTS_APELLIDO."',p_nombre = '".$TXTP_NOMBRE."',s_nombre = '".$TXTS_NOMBRE."',correo = '".$TXTCORREO."',sexo = '".$CMBSEXO."',direccion ='".$TXTDIRECCION."',celular = '".$TXTTELEFONO."',telefono = '".$TXTTELEFONO2."' WHERE id_personal = ".$ID_PERSONAL."";
		if(CORRER_TRANSACCION($SQL)==1) 
		{
				 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
				unset($SQL);
				return; 
		}else{
			AUDITORIA($SQL);
			unset($SQL);
			$SQL1= "SELECT * FROM  t_usuarios WHERE id_usuario  =".$ID_USER."";
			$QUERY = mysql_query($SQL1);
			$CONTRASENA=mysql_result($QUERY,0,"contrasena");
			$NOMBRE_USUARIO=mysql_result($QUERY,0,"nombre_usuario");
			
			if($ESTATUS_USUARIO=="0")
			{
				$ESTATUS_USUARIO=mysql_result($QUERY,0,"estatus_usuario");
			
			}
			if($ESTATUS_USUARIO=="DESBLOQUEADO")
			{
				$ESTATUS_USUARIO="";
			
			}
			if($ESTATUS_USUARIO=="BLOQUEADO")
			{
				$ESTATUS_USUARIO="BLOQUEADO";
			
			}
			if($ESTATUS_USUARIO=="REESTABLECER")
			{
				$ESTATUS_USUARIO=mysql_result($QUERY,0,"estatus_usuario");
				$CONTRASENA=md5("123456",false);
			
			}
			$SQL_TIPO_USUARIO=mysql_query("SELECT * FROM t_tipos_usuarios WHERE id_tipo_usuario = ".$TIPO_USUARIO."") or die("Error en el sql");
			if(mysql_num_rows($SQL_TIPO_USUARIO)!=0)
			{
				$SQL=array();
				
				$SQL[]= "UPDATE t_usuarios SET id_tipo_usuario = ".$TIPO_USUARIO.",id_personal = ".$ID_PERSONAL.",nombre_usuario = '".$NOMBRE_USUARIO."',contrasena = '".$CONTRASENA."',estatus_usuario = '".$ESTATUS_USUARIO."' WHERE id_usuario = ".$ID_USER."";
				if(CORRER_TRANSACCION($SQL)==1) 
				{
					 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
				}else{
					
					echo "<input type='hidden' id='AVISOMOFICIADO' value=''>";
				}
				unset($SQL);

			}else{
				
				 echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
				
			}
		}
			
		
	}

	if($ACCION=="BUSCAR")
	{
		if($TXTIDENTIFICACION!="")
		{
			$SQL= "SELECT * FROM t_personal INNER JOIN t_usuarios ON t_personal.id_personal = t_usuarios.id_personal WHERE cedula  ='".$TXTIDENTIFICACION."'";
			
			$QUERY = mysql_query($SQL);
			if(mysql_num_rows($QUERY)!=0)
			{
				echo "<input type=hidden id='AVISO' value= '".mysql_result($QUERY,0,"cedula")."|".mysql_result($QUERY,0,"p_apellido")."|".mysql_result($QUERY,0,"s_apellido")."|".mysql_result($QUERY,0,"p_nombre")."|".mysql_result($QUERY,0,"s_nombre")."|".mysql_result($QUERY,0,"id_personal")."|".mysql_result($QUERY,0,"id_usuario")."|".mysql_result($QUERY,0,"id_tipo_usuario")."|".mysql_result($QUERY,0,"nombre_usuario")."|".mysql_result($QUERY,0,"celular")."|".mysql_result($QUERY,0,"telefono")."|".mysql_result($QUERY,0,"correo")."|".mysql_result($QUERY,0,"sexo")."|".mysql_result($QUERY,0,"direccion")."|".mysql_result($QUERY,0,"estatus_usuario")."|0'>";
				
			}else{
				echo "<input type=hidden id='AVISO' value='noencontrado'>";
			}
			
		}
	}
	
		
		if($ACCION=="USUARIOS")
		{
			$TXTAPELLIDOS = $_POST['DATO'];
			$NRO = $_POST['NRO'];
			if(!empty($_POST['NRO']))
			{
				 $NRO=($NRO-1)*15;
						
			}else{
			
				 $NRO=0;
			}
			$SQL = "select * from t_personal where t_personal.cedula like '%".$TXTAPELLIDOS."%' OR t_personal.p_apellido like '%".$TXTAPELLIDOS."%' OR t_personal.s_apellido like '%".$TXTAPELLIDOS."%' OR t_personal.p_nombre like '%".$TXTAPELLIDOS."%' OR t_personal.s_nombre like '%".$TXTAPELLIDOS."%' ORDER BY t_personal.p_apellido,t_personal.s_apellido,t_personal.p_nombre,t_personal.s_nombre";
			$BUSQUEDA_ALUMNOS = mysql_query($SQL)or die("Imposible realizar el SQL");
			if(mysql_num_rows($BUSQUEDA_ALUMNOS)==0)
			{
				echo "<table width=697 border=0 cellpadding=0 cellspacing=0><tr><td><b>La busqueda no arrojo resultados</b></td></tr>";
				echo "</table><input type='hidden' id='cantidad' value=0><input type='hidden' id='datoviejo' value=".$TXTAPELLIDOS.">";
			}else{
				echo "<table width=697 border=0 cellpadding=0 cellspacing=0>";
				$CONTADOR=0;
				for($i=$NRO;$i<mysql_num_rows($BUSQUEDA_ALUMNOS);$i++)
				{
					$CONTADOR=$CONTADOR+1;
					echo "<tr ".$STYLECELDAS." onClick=VOLCAR_PERSONAL('".mysql_result($BUSQUEDA_ALUMNOS,$i,"cedula")."')><td width=97 align=center>"; echo mysql_result($BUSQUEDA_ALUMNOS,$i,"cedula");echo "</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"p_apellido")."</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"s_apellido")."</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"p_nombre")."</td><td width=150>".mysql_result($BUSQUEDA_ALUMNOS,$i,"s_nombre")."</td></tr>";
					if($CONTADOR==15)
					{
						$i=mysql_num_rows($BUSQUEDA_ALUMNOS);
					}
					
				}	
				echo "</table><input type='hidden' id='cantidad' value=".ceil(mysql_num_rows($BUSQUEDA_ALUMNOS)/15)."><input type='hidden' id='datoviejo' value=".$TXTAPELLIDOS.">";
			}
			
		}
?>