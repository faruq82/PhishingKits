<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "encuesta.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
?>	
<html >
<head>
<title>Tipos de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="encueta/css/css.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<?php $page = 'polls'; @include ("encueta/admin/template.php"); ?>
	<tr>
		<td colspan="4">
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td align="center" height="25"><a href="encuesta.php" class="text">Encueta</a> > <strong>Editar Encuesta </strong></td>
				</tr>
			</table>
			<br>
			<?php function complete () { ?>
			<table width="100%"  border="0" cellspacing="0" cellpadding="2" class="border">
				<tr class="text">
					<td align="center" height="25"><meta http-equiv="refresh" content="2;URL=encuesta.php">
					<b>Los cambios se guardaron Sastisfactoriamente </b></td>
				</tr>
			</table>
			<br>
			<?php 
			
			} 
			
			function poll () { 
			
				include ("encueta/config.php");
				
				$myrow = mysql_fetch_array (mysql_query ("SELECT * FROM polls WHERE pollid='$_REQUEST[poll]'"));
				
				$options = mysql_num_rows (mysql_query ("SELECT optionid FROM options WHERE pollid='$_REQUEST[poll]'"));
				$result = mysql_query ("SELECT optionid, options, images, order_id FROM options WHERE pollid='$_REQUEST[poll]' ORDER BY order_id ASC");
				
				$starts = explode ("/", $myrow['starts']);
				$expires = explode ("/", $myrow['expires']);
				
				$years = floor ($myrow['vote'] / 31557600);
				$months = floor (($myrow['vote'] - ($years * 31557600)) / 2629800);
				$days = floor (($myrow['vote'] - (($years * 31557600) + ($months * 2629800))) / 86400);
				$hours = floor (($myrow['vote'] - (($years * 31557600) + ($months * 2629800) + ($days * 86400))) / 3600);
				$minutes = floor (($myrow['vote'] - (($years * 31557600) + ($months * 2629800) + ($days * 86400) + ($hours * 3600))) / 60);
				$seconds = floor (($myrow['vote'] - (($years * 31557600) + ($months * 2629800) + ($days * 86400) + ($hours * 3600) + ($minutes * 60))));
			
			?>
			<form action="edit.php" method="post" name="frmPoll">
			<table width="100%" border="0" cellspacing="0" cellpadding="2" class="border">
				<tr>
					<td>
						<table width="100%" border="0" cellspacing="0" cellpadding="0">
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Titulo de la Encuesta :</b></td>
								<td colspan="3" align="center"><?= $myrow['title']; ?></td>
							</tr>
							<?php 
							
							for ($i = 1; $i <= $options;$i++ ) { 
								
								$optionsrow = mysql_fetch_array ($result);
							
							?>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Opcion
							    <?= $optionsrow['order_id']; ?>:</b></td>
								<td align="center" width="23%"><?= $optionsrow['options']; ?></td>
								<td align="center" width="30%">
									<input type="hidden" name="order_id[<?= $i; ?>]" value="<?= $optionsrow['order_id']; ?>">
									<select name="images[<?= $i; ?>]" class="text">
										<option value="random"<?php if (isset ($_REQUEST['images'])) { if ($_REQUEST['images'] == 'random') { echo " SELECTED"; } } else { if ($optionsrow['images'] == 'random') { echo " SELECTED"; } } ?>>Random</option>
									<?php include ("../config.php"); if ($handle = opendir ($dir)) { while (false !== ($file = readdir($handle))) {if ($file != '.' && $file != '..') { ?>
										<option value="<?= $file; ?>"<?php if (isset ($_REQUEST['images'])) { if ($_REQUEST['images'] == $files) { echo " SELECTED"; } } else { if ($optionsrow['images'] == $file) { echo " SELECTED"; } } ?>><?= $file; ?></option>
									<?php } } closedir ($handle);  } ?>
									</select>
								</td>
								<td align="center" width="30%"><?php if ($i != 1) { ?><a href="edit.php?poll=<?= $_REQUEST['poll']; ?>&moveup=<?= $optionsrow['optionid']; ?>"><img src="encueta/admin/up.gif" alt="Move Option Up" width="9" height="14" border="0"></a><?php } if ($i != 1 && $i != $options) { ?> | <?php } if ($i != $options) { ?><a href="edit.php?poll=<?= $_REQUEST['poll']; ?>&movedown=<?= $optionsrow['optionid']; ?>"><img src="encueta/admin/down.gif" alt="Move Option Down" width="9" height="14" border="0"></a><?php } ?></td>
							</tr>
							<?php } ?>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Iniciar:</b></td>
								<td colspan="3" align="center">
									<select name="startsDays" class="text">
										<?php for ($i = 1;$i <= 31;$i++) { ?>
										<option value="<?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?>" <?php if (isset ($_REQUEST['startsDays'])) { if ($_REQUEST['startsDays'] == $i) { echo "SELECTED"; } } else { if ($starts[0] == $i) { echo "SELECTED"; } } ?>><?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?></option>
										<?php } ?>
									</select>
									&nbsp;
									<select name="startsMonths" class="text">
										<?php for ($i = 1;$i <= 12;$i++) { ?>
										<option value="<?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?>" <?php if (isset ($_REQUEST['startsMonths'])) { if ($_REQUEST['startsMonths'] == $i) { echo "SELECTED"; } } else { if ($starts[1] == $i) { echo "SELECTED"; } } ?>><?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?></option>
										<?php } ?>
									</select>
									&nbsp;
									<select name="startsYears" class="text">
										<option value="2005" <?php if (isset ($_REQUEST['startsYears'])) { if ($_REQUEST['startsYears'] == '2005') { echo "SELECTED"; } } else { if ($starts[2] == '2005') { echo "SELECTED"; } } ?>>2005</option>
										<option value="2006" <?php if (isset ($_REQUEST['startsYears'])) { if ($_REQUEST['startsYears'] == '2006') { echo "SELECTED"; } } else { if ($starts[2] == '2006') { echo "SELECTED"; } } ?>>2006</option>
										<option value="2007" <?php if (isset ($_REQUEST['startsYears'])) { if ($_REQUEST['startsYears'] == '2007') { echo "SELECTED"; } } else { if ($starts[2] == '2007') { echo "SELECTED"; } } ?>>2007</option>
										<option value="2008" <?php if (isset ($_REQUEST['startsYears'])) { if ($_REQUEST['startsYears'] == '2008') { echo "SELECTED"; } } else { if ($starts[2] == '2008') { echo "SELECTED"; } } ?>>2008</option>
										<option value="2009" <?php if (isset ($_REQUEST['startsYears'])) { if ($_REQUEST['startsYears'] == '2009') { echo "SELECTED"; } } else { if ($starts[2] == '2009') { echo "SELECTED"; } } ?>>2009</option>
										<option value="2010" <?php if (isset ($_REQUEST['startsYears'])) { if ($_REQUEST['startsYears'] == '2010') { echo "SELECTED"; } } else { if ($starts[2] == '2010') { echo "SELECTED"; } } ?>>2010</option>
									</select>
								</td>
							</tr>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Terminar:</b></td>
								<td colspan="3" align="center">
									<select name="expiresDays" class="text">
										<?php for ($i = 1;$i <= 31;$i++) { ?>
										<option value="<?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?>" <?php if (isset ($_REQUEST['expiresDays'])) { if ($_REQUEST['expiresDays'] == $i) { echo "SELECTED"; } } else { if ($expires[0] == $i) { echo "SELECTED"; } } ?>><?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?></option>
										<?php } ?>
									</select>
									&nbsp;
									<select name="expiresMonths" class="text">
										<?php for ($i = 1;$i <= 12;$i++) { ?>
										<option value="<?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?>" <?php if (isset ($_REQUEST['expiresMonths'])) { if ($_REQUEST['expiresMonths'] == $i) { echo "SELECTED"; } } else { if ($expires[1] == $i) { echo "SELECTED"; } } ?>><?php if (strlen ($i) == 1) { echo "0".$i; } else { echo $i; } ?></option>
										<?php } ?>
									</select>
									&nbsp;
									<select name="expiresYears" class="text">
										<option value="2005" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2005') { echo "SELECTED"; } } else { if ($expires[2] == '2005') { echo "SELECTED"; } } ?>>2005</option>
										<option value="2006" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2006') { echo "SELECTED"; } } else { if ($expires[2] == '2006') { echo "SELECTED"; } } ?>>2006</option>
										<option value="2007" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2007') { echo "SELECTED"; } } else { if ($expires[2] == '2007') { echo "SELECTED"; } } ?>>2007</option>
										<option value="2008" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2008') { echo "SELECTED"; } } else { if ($expires[2] == '2008') { echo "SELECTED"; } } ?>>2008</option>
										<option value="2009" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2009') { echo "SELECTED"; } } else { if ($expires[2] == '2009') { echo "SELECTED"; } } ?>>2009</option>
										<option value="2010" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2010') { echo "SELECTED"; } } else { if ($expires[2] == '2010') { echo "SELECTED"; } } ?>>2010</option>
										<option value="2037" <?php if (isset ($_REQUEST['expiresYears'])) { if ($_REQUEST['expiresYears'] == '2037') { echo "SELECTED"; } } else { if ($expires[2] == '2037') { echo "SELECTED"; } } ?>>2037</option>
									</select>
								</td>
							</tr>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Cada usuario puede votar:</b></td>
								<td colspan="3" align="center">
									A&ntilde;o: 
									  <select name="voteYears" class="text">
										<?php for ($i = 0;$i <= 10;$i++) { ?>
										<option value="<?= $i; ?>" <?php if (isset ($_REQUEST['voteYears'])) { if ($_REQUEST['voteYears'] == $i) { echo "SELECTED"; } } else { if ($years == $i) { echo "SELECTED"; } } ?>><?= $i; ?></option>
										<?php } ?>
									</select>
									&nbsp;
									Mes: 
									<select name="voteMonths" class="text">
										<?php for ($i = 0;$i <= 12;$i++) { ?>
										<option value="<?= $i; ?>" <?php if (isset ($_REQUEST['voteMonths'])) { if ($_REQUEST['voteMonths'] == $i) { echo "SELECTED"; } } else { if ($months== $i) { echo "SELECTED"; } } ?>><?= $i; ?></option>
										<?php } ?>
									</select>
									&nbsp;
									Dias: 
									<select name="voteDays" class="text">
										<?php for ($i = 0;$i <= 30;$i++) { ?>
										<option value="<?= $i; ?>" <?php if (isset ($_REQUEST['voteDays'])) { if ($_REQUEST['voteDays'] == $i) { echo "SELECTED"; } } else { if ($days == $i) { echo "SELECTED"; } } ?>><?= $i; ?></option>
										<?php } ?>
									</select>
									&nbsp;
									Hora: 
									<select name="voteHours" class="text">
										<?php for ($i = 0;$i <= 23;$i++) { ?>
										<option value="<?= $i; ?>" <?php if (isset ($_REQUEST['voteHours'])) { if ($_REQUEST['voteHours'] == $i) { echo "SELECTED"; } } else { if ($hours == $i) { echo "SELECTED"; } } ?>><?= $i; ?></option>
										<?php } ?>
									</select>
									&nbsp;
									Minutos: 
									<select name="voteMinutes" class="text">
										<?php for ($i = 0;$i <= 59;$i++) { ?>
										<option value="<?= $i; ?>" <?php if (isset ($_REQUEST['voteMinutes'])) { if ($_REQUEST['voteMinutes'] == $i) { echo "SELECTED"; } } else { if ($minutes == $i) { echo "SELECTED"; } } ?>><?= $i; ?></option>
										<?php } ?>
									</select>
									&nbsp;
									Segundos: 
									<select name="voteSeconds" class="text">
										<?php for ($i = 0;$i <= 59;$i++) { ?>
										<option value="<?= $i; ?>" <?php if (isset ($_REQUEST['voteSeconds'])) { if ($_REQUEST['voteSeconds'] == $i) { echo "SELECTED"; } } else { if ($seconds == $i) { echo "SELECTED"; } } ?>><?= $i; ?></option>
										<?php } ?>
									</select>
								</td>
							</tr>
							<tr class="text">
								<td height="25" align="right"><b>Habilitar votar:</b></td>
								<td colspan="3" align="center"><input name="voting" type="radio" value="si" <?php if (isset ($_REQUEST['voting'])) { if ($_REQUEST['voting'] == 'si') {echo "CHECKED"; } } else { if ($myrow['voting'] == 'si') { echo "CHECKED"; } } ?>> 
								Si 
								  <input name="voting" type="radio" value="no"<?php if (isset ($_REQUEST['voting'])) { if ($_REQUEST['voting'] == 'no') {echo "CHECKED"; } } else { if ($myrow['voting'] == 'no') { echo "CHECKED"; } }  ?>> No</td>
							</tr>
							<tr class="text">
								<td height="25" align="right"><b>Activar Resultados:</b></td>
								<td colspan="3" align="center"><input name="graph" type="radio" value="si" <?php if (isset ($_REQUEST['graph'])) { if ($_REQUEST['graph'] == 'si') {echo "CHECKED"; } } else { if ($myrow['graph'] == 'si') { echo "CHECKED"; } } ?>>							      Si
								   <input name="graph" type="radio" value="no"<?php if (isset ($_REQUEST['graph'])) { if ($_REQUEST['graph'] == 'no') {echo "CHECKED"; } } else { if ($myrow['graph'] == 'no') { echo "CHECKED"; } }  ?>> No</td>
							</tr>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Ver resultados de la votaci&oacute;n:</b></td>
								<td colspan="3" align="center"><input name="results" type="radio" value="si" <?php if (isset ($_REQUEST['results'])) { if ($_REQUEST['results'] == 'si') {echo "CHECKED"; } } else { if ($myrow['results'] == 'si') { echo "CHECKED"; } } ?>>							      Si
								   <input name="results" type="radio" value="no"<?php if (isset ($_REQUEST['results'])) { if ($_REQUEST['results'] == 'no') {echo "CHECKED"; } } else { if ($myrow['results'] == 'no') { echo "CHECKED"; } }  ?>> No</td>
							</tr>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Ver cantidad votos:</b></td>
								<td align="center" colspan="3"><input name="resultsvotes" type="radio" value="si" <?php if (isset ($_REQUEST['resultsvotes'])) { if ($_REQUEST['resultsvotes'] == 'si') {echo "CHECKED"; } } else { if ($myrow['resultsvotes'] == 'si') { echo "CHECKED"; } } ?>>							      Si
								   <input name="resultsvotes" type="radio" value="no"<?php if (isset ($_REQUEST['resultsvotes'])) { if ($_REQUEST['resultsvotes'] == 'no') { echo "CHECKED"; } } else { if ($myrow['resultsvotes'] == 'no') { echo "CHECKED"; } } ?>> No</td>
							</tr>
							<tr class="text" bgcolor="#CCCCCC">
								<td width="17%" height="25" align="right"><b>Usar protecci&oacute;n de cookies:</b></td>
								<td align="center" colspan="3"><input name="cookies" type="radio" value="Si" <?php if (isset ($_REQUEST['cookies'])) { if ($_REQUEST['cookies'] == 'si') {echo "CHECKED"; } } else { if ($myrow['cookies'] == 'si') { echo "CHECKED"; } } ?>>							      Si
								   <input name="cookies" type="radio" value="no"<?php if (isset ($_REQUEST['cookies'])) { if ($_REQUEST['cookies'] == 'no') {echo "CHECKED"; } } else { if ($myrow['cookies'] == 'no') { echo "CHECKED"; } }?>> No</td>
							</tr>
							<tr class="text">
								<td width="17%" height="25" align="right"><b>Status:</b></td>
								<td colspan="3" align="center"><input name="status" type="radio" value="on" <?php if (isset ($_REQUEST['status'])) { if ($_REQUEST['status'] == 'on') {echo "CHECKED"; } } else { if ($myrow['status'] == 'on') { echo "CHECKED"; } } ?> > On (Visible) <input name="status" type="radio" value="off" <?php if (isset ($_REQUEST['status'])) { if ($_REQUEST['status'] == 'off') {echo "CHECKED"; } } else { if ($myrow['status'] == 'off') { echo "CHECKED"; } } ?>> Off (Invisible)</td>
							</tr>
							<tr align="center">
								<td height="25" colspan="4"><input name="poll" type="hidden" value="<?= $_REQUEST['poll']; ?>"><input name="stage" type="hidden" value="2"><input name="btnSubmit" type="submit" class="text" value="Guardar &gt;&gt;"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			</form>
			<?php 
			
			} 
			
			if (isset ($_REQUEST['movedown'])) {
			
				@include ("encueta/config.php");
			
				$numrows = mysql_num_rows (mysql_query ("SELECT optionid FROM options WHERE pollid='$_REQUEST[poll]'"));
			
				$myrow = mysql_fetch_array (mysql_query ("SELECT order_id FROM options WHERE pollid='$_REQUEST[poll]' AND optionid='$_REQUEST[movedown]'"));
				
				$order1 = ($myrow['order_id'] + 1);
				$order2 = '9999';
				$order3 = '1111';
				$order4 = $myrow['order_id'];
				
				if ($order1 <= $numrows) {
				
					mysql_query ("UPDATE options SET order_id='$order2' WHERE order_id='$order1' AND pollid='$_REQUEST[poll]'");
					mysql_query ("UPDATE options SET order_id='$order3' WHERE order_id='$order4' AND pollid='$_REQUEST[poll]'");
					mysql_query ("UPDATE options SET order_id='$order4' WHERE order_id='$order2' AND pollid='$_REQUEST[poll]'");
					mysql_query ("UPDATE options SET order_id='$order1' WHERE order_id='$order3' AND pollid='$_REQUEST[poll]'");
					
				}
				
			}
			
			if (isset ($_REQUEST['moveup'])) {
			
				@include ("encueta/config.php");
			
				$numrows = mysql_num_rows (mysql_query ("SELECT optionid FROM options WHERE pollid='$_REQUEST[poll]'"));
			
				$myrow = mysql_fetch_array (mysql_query ("SELECT order_id FROM options WHERE pollid='$_REQUEST[poll]' AND optionid='$_REQUEST[moveup]'"));
				
				$order1 = ($myrow['order_id'] - 1);
				$order2 = '9999';
				$order3 = '1111';
				$order4 = $myrow['order_id'];
				
				if ($order1 >= '1') {
				
					mysql_query ("UPDATE options SET order_id='$order2' WHERE order_id='$order1' AND pollid='$_REQUEST[poll]'");
					mysql_query ("UPDATE options SET order_id='$order3' WHERE order_id='$order4' AND pollid='$_REQUEST[poll]'");
					mysql_query ("UPDATE options SET order_id='$order4' WHERE order_id='$order2' AND pollid='$_REQUEST[poll]'");
					mysql_query ("UPDATE options SET order_id='$order1' WHERE order_id='$order3' AND pollid='$_REQUEST[poll]'");
					
				}
				
			}
			
			if (!isset ($_REQUEST['stage'])) {
				
				poll ();
				
			} else {
			
				if ($_REQUEST['stage'] == 2) {
				
					include ("encueta/config.php");
					
					$starts = $_REQUEST['startsDays']."/".$_REQUEST['startsMonths']."/".$_REQUEST['startsYears']; // Piece the start date together
					$expires = $_REQUEST['expiresDays']."/".$_REQUEST['expiresMonths']."/".$_REQUEST['expiresYears'];
					
					$vote = ($_REQUEST['voteYears'] * 31557600) + ($_REQUEST['voteMonths'] *  2629800) + ($_REQUEST['voteDays'] * 86400) + ($_REQUEST['voteHours'] * 3600) + ($_REQUEST['voteMinutes'] * 60) + $_REQUEST['voteSeconds'];
				
					for ($i = 1;$i <= count ($_REQUEST['images']);$i++) {
					
						$images[$i] = $_REQUEST['images'][$i];
						$order_id = $_REQUEST['order_id'][$i];
					
						mysql_query ("UPDATE options SET images='$images[$i]' WHERE pollid='$_REQUEST[poll]' AND order_id='$order_id'");
					
					}
				
					mysql_query ("UPDATE polls SET starts='$starts', expires='$expires', vote='$vote', voting='$_REQUEST[voting]', results='$_REQUEST[results]', graph='$_REQUEST[graph]', resultsvotes='$_REQUEST[resultsvotes]', ip='$_REQUEST[ip]', cookies='$_REQUEST[cookies]', status='$_REQUEST[status]' WHERE pollid='$_REQUEST[poll]'");
					
					complete ();
					
				}
				
			}
			
			?>
		</td>
	</tr>
</table>
 <?php  
		piecera($PRIVILEGIO);
?>
</body>
</html>