<?php
	$db="nethn_admin";
	$DIR = mysql_connect("localhost","nethn_admin","admin32");
	mysql_select_db($db,$DIR)or die("Error al conectar a la base de datos seleccionada");
	mysql_query ("SET NAMES  'utf8'");
	
?>
