<?php
	
	echo "
	<script language=javascript>
		alert('Usted ha accedido a un sitio prohibido. Sera redirigido a la pagina principal de LidSoftware');
		document.location='http://www.lidsoftware.com';
	</script>";
?>