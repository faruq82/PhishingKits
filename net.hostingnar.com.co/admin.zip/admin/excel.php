<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>

<html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Pragma"content="no-cache">
<meta http-equiv="expires"content="0">  
</head>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>

    <h3>Seleccionar archivo Excel</h3>
    <form name="frmload" method="post" action="excel.php" enctype="multipart/form-data">
		Seleccione Escuela<?php
					
				echo "<select name='CMBAESCOLAR' id='CMBAESCOLAR' >";
               	$QUERY= mysql_query("select * from t_actividades order by id_actividad");
              	echo "<option value=-1></option>";
				mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"id_actividad").">".mysql_result($QUERY,$i,"escuela")."</option>";
				}
              	echo "</select> "
					
					?>
		
		
		
        <input type="file" name="file" /> &nbsp; &nbsp; &nbsp; <input type="submit" value="--- IMPORTAR ---" />
    </form>
<?php
// Test CVS

require_once 'Excel/reader.php';


// ExcelFile($filename, $encoding);
$data = new Spreadsheet_Excel_Reader();


// Set output Encoding.
$data->setOutputEncoding('CP1251');
//$data->setOutputEncoding('CPa25a');
/***
* if you want you can change 'iconv' to mb_convert_encoding:
* $data->setUTFEncoder('mb');
*
**/

/***
* By default rows & cols indeces start with 1
* For change initial index use:
* $data->setRowColOffset(0);
*
**/



/***
*  Some function for formatting output.
* $data->setDefaultFormat('%.2f');
* setDefaultFormat - set format for columns with unknown formatting
*
* $data->setColumnFormat(4, '%.3f');
* setColumnFormat - set format for column (apply only to number fields)
*
**/

//$data->read('comprador.xls');

$file_to_include= $_FILES['file']['tmp_name'];

$data->read($file_to_include);

/*


 $data->sheets[0]['numRows'] - count rows
 $data->sheets[0]['numCols'] - count columns
 $data->sheets[0]['cells'][$i][$j] - data from $i-row $j-column

 $data->sheets[0]['cellsInfo'][$i][$j] - extended info about cell
    
    $data->sheets[0]['cellsInfo'][$i][$j]['type'] = "date" | "number" | "unknown"
        if 'type' == "unknown" - use 'raw' value, because  cell contain value with format '0.00';
    $data->sheets[0]['cellsInfo'][$i][$j]['raw'] = value if cell without format 
    $data->sheets[0]['cellsInfo'][$i][$j]['colspan'] 
    $data->sheets[0]['cellsInfo'][$i][$j]['rowspan'] 
*/

error_reporting(E_ALL ^ E_NOTICE);


for ($i = 1; $i <= $data->sheets[0]['numRows']; $i++) {


		echo "<br>";
		$nomministro="";
		$telministro="";
		$pais="VE";
		
		$apellido =$data->sheets[0]['cells'][$i][2];
		
		$nombre =$data->sheets[0]['cells'][$i][3];
		
		$cedula =$data->sheets[0]['cells'][$i][5];
		
		$direccion =$data->sheets[0]['cells'][$i][4];
		
		$profesion=$data->sheets[0]['cells'][$i][6];
		$fechana =$data->sheets[0]['cells'][$i][7];
		$edad =$data->sheets[0]['cells'][$i][9];
		$sexo =$data->sheets[0]['cells'][$i][11];
		
		$celular= "0".$data->sheets[0]['cells'][$i][13].$data->sheets[0]['cells'][$i][14];
		$email =$data->sheets[0]['cells'][$i][15];
		$congregacion=$data->sheets[0]['cells'][$i][16];
		$direcongre=$data->sheets[0]['cells'][$i][17];
		$nomministro=$data->sheets[0]['cells'][$i][18];
		
		$celular2= "0".$data->sheets[0]['cells'][$i][19].$data->sheets[0]['cells'][$i][20];
		
		$celularr=str_replace("(",'',str_replace(")",'',str_replace(" ",'',str_replace(".",'',str_replace("-",'',$celular)))));
		
		$telministro=str_replace("(",'',str_replace(")",'',str_replace(" ",'',str_replace(".",'',str_replace("-",'',$celular2)))));

		//echo "".$celularr."";
		echo "nombre: ".$nombre." <br>Apellido: ".$apellido." <br> Cedula: ".$cedula." <br> Direccion: ".$direccion." <br> Profesion: ".$profesion." <br> FechaNAci: ".$fechana." <br> Edad: ".$edad." <br> Sexo: ".$sexo." <br> Email: ".$email." <br> Congre: ".$congregacion." <br> Direccion congre: ".$direcongre." <br>";
		
	
				$CMBAESCOLAR = $_POST['CMBAESCOLAR'];
				$SQL_CHK_EXISTENCIA = mysql_query("select * from alumnos_pre where ci = '$cedula' ");
	
	//if(!mysql_query("INSERT INTO usuarios (nick,contrasena,email,fecha,nombre,pais,sexo,boletin,ip,conectado,puntos,n_dia,n_mes,n_ano,messenger) VALUES ('$nick','$contrasena','$email','$fecha','$nombre','$pais','$sexo','$boletin','$ip','$fecha','$puntos','$n_dia','$n_mes','$n_ano','$messenger')")){
			
			
			if(mysql_num_rows($SQL_CHK_EXISTENCIA)==0)
			{
				$SQL=array();
				$SQL[] = "INSERT INTO alumnos_pre (email,pais,sexo,direccion,ci,profesion,nombre,apellido,telefono,edad,congregacion,direcongre,nomministro,telministro,fechana,escuela) VALUES ('".$email."','".$pais."','".$sexo."','".$direccion."','".$cedula."','".$profesion."','".$nombre."','".$apellido."','".$celularr."','".$edad."','".$congregacion."','".$direcongre."','".$nomministro."','".$telministro."','".$fechana."','".$CMBAESCOLAR."');";
					
			if(CORRER_TRANSACCION($SQL)==1) 
			{
					echo 'HUBO UN ERROR DURANTE LA OPERACION.<br>';
			}else{
					
					echo 'OPERACION REALIZADA CON EXITO. <br>' ;
			}
			unset($SQL);
				echo "
					<script language='javascript'>
						document.getElementById('BOTON').value = 'Guardar';
					</script>
				";
			}else{
				echo '<br>EL REGISTRO YA SE ENCUENTRA ALMACENADO EN LA BASE DE DATOS <br>';
			}
	
	//for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) {
		//echo "".$data->sheets[0]['cells'][1][$j]."";
	//}
	//echo "\n";

}


//print_r($data);
//print_r($data->formatRecords);
?>

</body>
</html>