<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "inicio.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<html >
<head>
<title>Aplicacion web</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<script type="text/javascript">
</script>
<style type="text/css">
<!--

table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo3 {font-size: 18px; }
.Estilo4 {
	font-size: 24px;
	font-weight: bold;
}

-->
</style>
</head>
<body>

<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<table width="780" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="625">
	<table width="780" border="0" align="center" cellpadding="0" cellspacing="0" >
      <tr>
        <td width="37">&nbsp;</td>
        <td width="510">&nbsp;</td>
        <td colspan="2"><?php 
	$sql5 = "SELECT * FROM  t_usuarios WHERE id_usuario='$ID_USUARIO'";
	$result5=mysql_query($sql5);
	mysql_query ("SET NAMES 'utf8'");
	$row5 = mysql_fetch_assoc($result5);
	
	$id_personal=$row5['id_personal'];
	$query221 = mysql_query("SELECT * FROM alumnos_online WHERE id_personal='$id_personal' ");
	if(mysql_num_rows($query221)>0){	
	echo "<br><b>USUARIO: </b>".mysql_result($query221,0,"nick");
	//echo "<br>";
	echo "<br><b>CREDITOS DISPONIBLE: </b>".mysql_result($query221,0,"creditos");
	echo "<br>";	
			
		}
		?></td>
        </tr>
      <tr>
        <td >&nbsp;</td>
        <td colspan="2"><?php

	$sql5 = "SELECT * FROM  t_usuarios WHERE id_usuario='$ID_USUARIO'";
	$result5=mysql_query($sql5);
	mysql_query ("SET NAMES 'utf8'");
	$row5 = mysql_fetch_assoc($result5);
	
	$id_personal=$row5['id_personal'];
		$query22 = mysql_query("SELECT * FROM alumnos_online WHERE id_personal='$id_personal' ");

if(mysql_num_rows($query22)>0){	


	$idusu= $id_personal;

		global $STYLECELDAS,$CABECERACELDAS;
		
		echo "<br><table width=780><tr><td><b>CUENTAS REGISTRADAS. </b></td></tr><tr><td></td></tr></table>";
              
	$QUERY_LISTAR_AULAS = mysql_query("select * from t_cuentas WHERE id_personal=".$idusu." ");
	
		if(mysql_num_rows($QUERY_LISTAR_AULAS)==0)
		{
         echo "<br><table width=780><tr><td><b>No tienes cuentas registradas.</b></td></tr></table>";

		}else{
				

				
				echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2 class=normal><tr><th width=100 class='cabecera'>DATOS DE LA CUENTA</th><th width=400 class='cabecera'>TIPO</tr>";
				for($i=0;$i<mysql_num_rows($QUERY_LISTAR_AULAS);$i++)
				{	
													
						echo "<td align=left>".mysql_result($QUERY_LISTAR_AULAS,$i,"nombre")."</td><td>".mysql_result($QUERY_LISTAR_AULAS,$i,"tipo")."</td></tr>";
					
				
					
				}
					
			
			
			echo "</table>";
			
		}
		echo "<br>";

}else{


echo "<br><table width=780><tr><td><b>No tienes cuentas registradas.</b></td></tr></table>";

}


		




?></td>
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td >&nbsp;</td>
        <td colspan="2">&nbsp;</td>
        <td >&nbsp;</td>
      </tr>
      <tr>
        <td >&nbsp;</td>
        <td colspan="2"><strong>Contacto:</strong> hostingnar@gmail.com<br>
          <strong>Whatsapp: </strong>+573113761056</td>
        <td width="74" >&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
<br>
<br><br><br><br>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
