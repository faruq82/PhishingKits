<?php
	$STYLECELDAS = "onmouseover=this.style.backgroundColor='#f3f3f3' onmouseout=this.style.backgroundColor=''";
	$CABECERACELDAS="bgcolor=aece9d";

	$CHECKBOX="checked";
	$db="rutasfor_foraneas";
	$DIR = mysql_connect("localhost","rutasfor_admin","admin32");
	mysql_select_db($db,$DIR)or die("Error al conectar a la base de datos seleccionada");
	function REDIRIGIR($URL)
	{
		echo "
			<script language='javascript'>
				document.location='".$URL."'; 
			</script>
		";
	}	
	function MESSAGE($MSJ)
	{
	
		
		echo "
			<script language='javascript'>
				//function ALERT(MSJ)
				//{
					// Sexy = new SexyAlertBox();
						//Sexy.alert('<h1>rutasforareasiutm</h1><em>versi&oacute;n 1.1</em><br/><br/><p>'+MSJ+'</p>');		
		
			
				//}
				alert('".$MSJ."');
				
			</script>
		";
	}
	
	
	function CONVERT_FECHAS($FECHA)
	{
		//YYYY-MM-DD
		if($FECHA=="")
		{
			$AUX="";
			return $AUX;
		}
		$FECHA_ARRAY = explode("-",$FECHA);
		$AUX = $FECHA_ARRAY[2]."-".$FECHA_ARRAY[1]."-".$FECHA_ARRAY[0];
		return $AUX;
	}
	function DESCONVERT_FECHAS($FECHA)
	{
		//DD-MM-YYYY
		if($FECHA=="")
		{
			$AUX="";
			return $AUX;
		}
		$FECHA_ARRAY = explode("-",$FECHA);
		$AUX = $FECHA_ARRAY[2]."-".$FECHA_ARRAY[1]."-".$FECHA_ARRAY[0];
		return $AUX;
	}
	
	function NACIONALIDAD($NACIONALIDAD)
	{
		//DD-MM-YYYY
		if($NACIONALIDAD>27)
		{
			$AUX="EXTRANJERA";
			return $AUX;
		}else{
		
			$AUX="VENEZOLANA";
			return $AUX;
		}
		
	}
	function DESCONVERT_E_CIVIL($E_CIVIL)
	{
			switch ($E_CIVIL)
			{ 
					case "": 
						$AUX=""; 
					break; 
					case "SO": 
						$AUX="SOLTERO(A)"; 
					break; 
					case "CA": 
						$AUX="CASADO(A)"; 
					break; 
					case "CO": 
						$AUX="CONCUBINO(A)"; 
					break; 
					case "DI": 
						$AUX="DIVORCIADO(A)"; 
					break; 
					case "VI": 
						$AUX="VIUDO(A)"; 
					break; 
			} 
			return $AUX;
	}
	function DESCONVERT_SEXO($SEXO)
	{
			switch ($SEXO)
			{ 
					case "": 
						$AUX=""; 
					break; 
					case "M": 
						$AUX="MASCULINO"; 
					break; 
					case "F": 
						$AUX="FEMENINO"; 
					break; 
					 
			} 
			return $AUX;
	}
	
	function CONVERT_NUMERO($NUMERO)
	{		
	
			$NUMERO= str_replace("/","-",$NUMERO);	
			$AUX= substr($NUMERO,0,1);
			$NUMERO =substr($NUMERO,1,2);
			if($AUX==3)
			{
				$AUX="TERCER";
			}	
			 
			return $AUX.$NUMERO;
	}
	
	function SABEREDAD($edad){
		list($anio,$mes,$dia) = explode("-",$edad);
		$anio_dif = date("Y") - $anio;
		$mes_dif = date("m") - $mes;
		$dia_dif = date("d") - $dia;
		if ($dia_dif < 0 || $mes_dif < 0)
		$anio_dif--;
		return $anio_dif;
	}
		
	function SABERCEDULA($ID_USUARIO,$DB,$DIRECCION_PRINCIPAL)
	{	
		
		CHANGE_DB($DIRECCION_PRINCIPAL,"lidsoftw","3jFtHqikCs","lidsoftw_LIDACCESO");
		$SQL = "select * from T_USUARIOS where T_USUARIOS.ID_USUARIO=".$ID_USUARIO."";
		$CEDULAENCONTRADA = mysql_query($SQL)or die("no se puede realizar el sql, busqueda de usuario abortada");
		$DIR = $DIRECCION_PRINCIAPAL;
		
		return mysql_result($CEDULAENCONTRADA,0,"CEDULA");
		
	}
	
	function SABERMES($MES)
	{
		if($MES==1)
		{ return "Enero";}
		if($MES==2)
		{ return "Febrero";}
		if($MES==3)
		{ return "Marzo";}
		if($MES==4)
		{ return "Abril";}
		if($MES==5)
		{ return "Mayo";}
		if($MES==6)
		{ return "Junio";}
		if($MES==7)
		{ return "Julio";}
		if($MES==8)
		{ return "Agosto";}
		if($MES==9)
		{ return "Septiembre";}
		if($MES==10)
		{ return "Octubre";}
		if($MES==11)
		{ return "Noviembre";}
		if($MES==12)
		{ return "Diciembre";}
	}
	
	function SABERDIA($DIA)
	{
		if($DIA==1)
		{ return "DOMINGO";}
		if($DIA==2)
		{ return "LUNES";}
		if($DIA==3)
		{ return "MARTES";}
		if($DIA==4)
		{ return "MIERCOLES";}
		if($DIA==5)
		{ return "JUEVES";}
		if($DIA==6)
		{ return "VIERNES";}
		if($DIA==7)
		{ return "SABADO";}
		
	}	
	
	function SABERQUINCENA($QUINCENA)
	{
		if($QUINCENA==1)
		{ return "1 ERA QUINCENA";}
		if($QUINCENA==2)
		{ return "2 DA QUINCENA";}
		
	}


        function timeToMinutes($time)
	{
		$horaSplit = explode(":", $time);
		if( count($horaSplit) < 3 )
		{
			$horaSplit[2] = 0;
		}
		# Pasamos los elementos a segundos
		$horaSplit[0] = $horaSplit[0] * 60 * 60;
		$horaSplit[1] = $horaSplit[1] * 60;
		return (($horaSplit[0] + $horaSplit[1] + $horaSplit[2]) / 60);
	}

	function minutesToHours($mins)
	{
		$hours = floor($mins / 60);
		$minutes = $mins-($hours * 60);
		if (!$minutes) {
			$minutes = "00";
		}
		else if ($minutes <= 9) {
			$minutes = "0".$minutes;
		}
		return ("{$hours}:{$minutes}");
	}
	function minutesToHours1($mins)
	{
		$hours = floor($mins / 60);
		$minutes = $mins-($hours * 60);
		$minutes=round($minutes );
		if (!$minutes) {
			$minutes = "00";
		}
		else if ($minutes <= 9) {
			$minutes = "0".$minutes;
		}
		return ("{$hours}:{$minutes}");
	}

	function SUMADIAS($fecha,$dia)
	{
			list($year,$mon,$day) = explode('-',$fecha);
			return date('Y-m-d',mktime(0,0,0,round($mon),round($day+$dia),round($year)));
	}
	$FECHA_ARRAY = explode("-",date('Y-m-d'));
	$ANOFIRMA =$FECHA_ARRAY[0];
	
	$SQL_FECHA_ACTUAL ="SELECT DATE_FORMAT( ADDTIME( NOW( ) , '0 5:00:0' ) , '%h:%i %p' ) AS HORA, DATE_FORMAT( ADDTIME( NOW( ) , '0 5:00:0' ) , '%w-%d-%c-%Y' ) AS FECHA_LETRA";
	$QUERY_FECHA_ACTUAL = mysql_query($SQL_FECHA_ACTUAL)or die("no se puede realizar el sql, busqueda de usuario abortada");
	
	$FECHA_LETRAS = explode("-",mysql_result($QUERY_FECHA_ACTUAL,$i,"FECHA_LETRA"));
	
	$FECHA_LETRA = ucfirst(strtolower(SABERDIA($FECHA_LETRAS[0]+1)))." ".$FECHA_LETRAS[1]." de ".ucfirst(strtolower(SABERMES($FECHA_LETRAS[2])))." del ".$FECHA_LETRAS[3];
	$HORA = mysql_result($QUERY_FECHA_ACTUAL,0,"HORA");
	
	
	
	

?>
