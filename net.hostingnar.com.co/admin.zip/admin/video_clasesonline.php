<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "clasesonline.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

	$cedula = $_GET['cedula'];
	$email= $_GET['email'];
	$nombre= $_GET['nombre'];
	
$query22 = mysql_query("SELECT * FROM asistencia_faci WHERE cedula='$cedula' ");
if(mysql_num_rows($query22)>0){	

 } else {
	mysql_query("INSERT INTO asistencia_faci (cedula,email,nombre) VALUES ('".$cedula ."','".$email."','".$nombre."')");
 }

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>CLASE EN VIVO CECIP ONLINE</title>
<style type="text/css">
<!--
.Estilo1 {	color: #000000;
	font-weight: bold;
}

table.fancy {
	border-top:2px solid #333;
	margin-bottom:20px;
	border-bottom:1px solid #f4f4f4;
}

table.fancy th {
	color:#666;
	text-transform:uppercase;
	font-size:13px;
	padding:10px 20px;
	vertical-align:middle;
	background:#f5f5f5;
	font-family:Arial, Helvetica, sans-serif;
	border-top:1px solid #f4f4f4;
}

table.fancy td {
	line-height:20px;
	padding:10px 20px;
	font-size:11px;
	border-bottom:1px solid #e5e5e5;
	border-top:1px solid #f4f4f4;
	text-align:center;
}

table.normal {
	border:1px solid #fff;
	
	border-radius: 5px;
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;	
	
	-moz-box-shadow: 1px 1px 0px #999;
	-webkit-box-shadow: 1px 1px 0px #999;
	box-shadow: 1px 1px 0px #999;
}

table.fullwidth {
	width:100%;
}

table.normal td {
	padding:5px 15px;
}

table.normal thead th {
	background: -moz-linear-gradient(top,#fbfbfb,#f5f5f5);
	background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#f5f5f5));
	text-transform:uppercase;
	font-size:10px;
	font-weight:normal;
	border-bottom:1px solid #ccc;
	text-shadow:-1px -1px #fff;
	padding:5px 15px;
	text-align:left;

}

table.normal thead th:hover {
	cursor:pointer;
}

table.normal tbody {
	border-top:1px solid #fff;
	background:#f4f4f4;
}

table.normal tbody tr.odd td {
	background:#fafafa;
}

table.normal tbody td {
	font-size:11px;
	vertical-align:middle;
}
.Estilo2 {font-size: 18px}
.Estilo3 {font-size: 18px; font-weight: bold; }

-->
</style>
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<?php

	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	if(mysql_num_rows($datos22)==0)
	{
		echo "NO SE ENCUENTRA REGISTRADO EN NINGUNA ESCUELA";
		
	
	}else{
	
?>
<table width="780" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th scope="row"><?php  
	
	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	$email = mysql_result($SQL_CHK_EXISTENCIA,0,"correo");
	$nombre = mysql_result($SQL_CHK_EXISTENCIA,0,"p_nombre")." ".mysql_result($SQL_CHK_EXISTENCIA,0,"p_apellido");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	$escuela= mysql_result($datos22,0,"escuela");
	
	$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");
	$archivo =mysql_result($escuelas,0,"fichero");
	
	echo " <br><strong>Nombre de la Escuela:</strong> ".mysql_result($escuelas,0,"escuela");
						
						if (mysql_result($datos22,0,"status") == 'Pagado')
						{
							echo " <br><br>
						<table width='780' border='0' cellspacing='2' cellpadding='2'>
  <tr>
    <th width='623' scope='row'><table width='333'  border='0' align='center' cellpadding='0' cellspacing='0'>
        <tr align='left' valign='top'>
          <td width='' height='' align='center' style=''><iframe src='videostreaming.html' name='video' width='600' marginwidth='0' height='450' marginheight='0' align='center' scrolling='No' frameborder='0' id='video' border='0'>El explorador no admite los marcos flotantes o no esta configurado actualmente para mostrarlos.</iframe>
          </td>
        </tr>
    </table></th>
    <td width='290'><a href='videostreaming.html' target='video' class='Estilo87' ><<<<-CLICK PARA ACTUALIZAR EL VIDEO</a> </td>
  </tr>
</table>";
							//include($archivo);
							

echo "
<table width='780' border='0' cellspacing='2' cellpadding='2' class='normal'>
  <tr>
    <th width='623' scope='row'><iframe src='preguntas1.php' name='pregunta' width='600' marginwidth='0' height='450' marginheight='0' align='center' scrolling='yes' frameborder='0' id='video' border='0'>El explorador no admite los marcos flotantes o no esta configurado actualmente para mostrarlos.</iframe>
      </td>
    <td width='290' valign='top'><a href='preguntas1.php' target='pregunta'><<<<-VER PREGUNTAS</a> </td>
  </tr>
</table>";

echo "
							<iframe src='nuevapregunta1.php?cedula=$cedula&nombre=$nombre&email=$email' name='pregunta2' width='600' marginwidth='0' height='300' marginheight='0' align='center' scrolling='no' frameborder='0' id='video' border='0'>El explorador no admite los marcos flotantes o no esta configurado actualmente para mostrarlos.</iframe>
							
							<div align='center'><a href='tutorias.php'><img src='http://ministerioredil.org/campus/img/bnasesoria.gif' ></a></div><br><br>
							
							";
							
							
						}else{
							echo " <br> <br>ClASE ONLINE NO DISPONIBLE.. ESCUELA PENDIENTE DE PAGO.::  <br>DEBE REALIZAR EL PAGO DE LA ESCUELA";
						}
	
	
	
	echo " <br>";
?></th>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
  </tr>
</table>
<?php 
	}

?>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
