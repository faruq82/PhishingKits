<?php

	$id = $_POST['id'];
	$id_personal = $_POST['idpersonal'];
	$creditos = $_POST['creditos'];
	require('ceoconexion.php');
   
		
		//$sql = "UPDATE t_pagos SET status='' where id='$id'";
		//$result = mysql_query($sql);
		
		$alumno = mysql_query("select * from alumnos_online WHERE ci=".$cedula." ");
		$id2 =mysql_result($alumno,0,"id");

		
		$sql2 = "UPDATE alumnos_online SET creditos='$creditos' where id='$id'";
		$result2 = mysql_query($sql2);
		
	echo"<script>location='lista_vendedores.php'</script>";	
?>