<?php 
	$XIAUEORPGDJD =$_GET['XIAUEORPGDJD'];
		if(isset($XIAUEORPGDJD))
		{
			if($XIAUEORPGDJD=="WIUEHRIDKFL")
			{
				session_name("MIORDEN");
				session_start();
				session_unset();
				session_destroy(); 
				
			}
		}
	include('ordenconfig.php');
	
	
?>

<html>
<head>
<?php
  //  head();
?>
<title>Control Estudiantil Online</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body>
<script type="text/javascript">
var er_texto =  /^[a-zA-Z0-9\s+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+\u00e1+\u00e9+\u00ed+\u00f3+\u00fa+\u00f1+]{4,15}$/;

	
function validar()
    {
		var TXTUSUARIO=document.getElementById('TXTUSUARIO').value;
		if(!er_texto.test(TXTUSUARIO))
		{
			ALERT("ERROR EN EL NOMBRE DE USUARIO. SOLO SE PERMITE NUMEROS Y LETRAS");
			return false;
		} 
		
		var TXTCONTRA=document.getElementById('TXTCONTRASENA').value;
		if(!er_texto.test(TXTCONTRA))
		{
			ALERT("ERROR EN LA CONTRASE\u00d1A. SOLO SE PERMITE NUMEROS Y LETRAS (DE 4 A 15 CARACTERES)");
			return false;
		} 
		
		document.getElementById('BOTON').disabled=true;
        
        
    }


	
</script>

<div id="wrapper">
	<div id="wrapper2">
		<div id='header' style='background-image:url(img/baner-online-cecip.jpg);background-repeat:no-repeat'>
			<div id="logo">
			<?php
				 
				// echo " <img  src='img/logos/logoCabecera.png' alt=''   >
                 // <h1>".$DES." ".$NOMBREESCUELA."</h1>";
			?>	  
			</div>
			
		</div>
		<!-- end #header -->
		<div id="page">
			<div id="content" style='width:960px;float: left;padding-left: 20px;'>
				<div class="login">
               
			<table  border="0" width="100%" cellspacing=6 cellpadding=0 >
                            <tr ><td align=left><font size="3"><strong>Bienvenido a CECIP ONLINE.</strong></font></td><td align=right><?PHP //echo $FECHA_LETRA; ?></td></tr>
            </table>
			 
            
			
			<div style='padding-bottom: 9px;width:0px;float:left;'> <img src="img/banner33.gif" width="470" height="400" hspace="4" vspace="4"><br>
			</div>

                <?php

				//$ESTADISTICA="";
                //$QUERY= mysql_query("select COUNT(*) AS NUMERO from T_ESTRATEGIAS");
               // $QUERY1= mysql_query("select COUNT(*) AS NUMERO from T_NOTAS_ESTRATEGIAS");
               // $QUERY2= mysql_query("select COUNT(*) AS NUMERO  from T_INDICADORES");
                //$QUERY3= mysql_query("select COUNT(*) AS NUMERO  from T_NOTAS_INDICADORES");
                //$QUERY4= mysql_query("select COUNT(*) AS NUMERO  from T_USUARIOS");
				//$QUERY5= mysql_query("select COUNT(*) AS NUMERO  from T_VISITAS ");
                //$QUERY6= mysql_query("select COUNT(*) AS NUMERO  from T_VISITAS WHERE  DATE_FORMAT(FECHA, '%c-%d-%Y') = DATE_FORMAT(NOW(), '%c-%d-%Y' )" );
				//$ESTADISTICA=$ESTADISTICA."<table  border='0' cellspacing=4 cellpadding=4 style='width:300px'>
                                //    <tr><td>Usuarios en el Sistema</td><td align=right> ".mysql_result($QUERY4, 0, "NUMERO")."</td></tr>";
              // $ESTADISTICA=$ESTADISTICA."<tr><td width='60%'>Estrategias Creadas</td><td align=right>".mysql_result($QUERY, 0, "NUMERO")."</td></tr>";
               // $ESTADISTICA=$ESTADISTICA."<tr><td>Notas Arrojadas</td><td align=right> ".mysql_result($QUERY1, 0, "NUMERO")." </td></tr>";
               // $ESTADISTICA=$ESTADISTICA."<tr><td>Indicadores Cargados</td><td align=right> ".mysql_result($QUERY2, 0, "NUMERO")."</td></tr>";
               // $ESTADISTICA=$ESTADISTICA."<tr><td>literales Arrojados</td><td align=right> ".mysql_result($QUERY3, 0, "NUMERO")."</td></tr>";
           
                //$ESTADISTICA=$ESTADISTICA."<tr><td>Visitas al Sistema </td ><td align=right> ".mysql_result($QUERY5, 0, "NUMERO")."</td></tr>";
				//$ESTADISTICA=$ESTADISTICA."<tr><td>Visitas al Sistema (Hoy)</td ><td align=right> ".mysql_result($QUERY6, 0, "NUMERO")."</td></tr>";
                //$ESTADISTICA=$ESTADISTICA."</table>";
                ?>
					<div  align="center"><font size="5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Recordar contraseña</b></font>    </div><br>
					<br><div id="entry">
<?php

//include("config.php");

# Recordatorio de contraseña

if($_POST["nick"]){

$infoquery = mysql_query("SELECT * FROM t_usuarios WHERE nombre_usuario='$_POST[nick]'");
$info =      mysql_fetch_array($infoquery);
$id_personal=$info[id_personal];
$id_usuario=$info[id_usuario];

	$SQL1 = "select * from t_personal WHERE id_personal ='".$id_personal."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$email = mysql_result($SQL_CHK_EXISTENCIA,0,"correo");
	$nombre = mysql_result($SQL_CHK_EXISTENCIA,0,"p_nombre")." ".mysql_result($SQL_CHK_EXISTENCIA,0,"p_apellido");
	
if(mysql_num_rows($infoquery) != 0){


$clave="123456789";
$TXTCONTRASENA= md5($clave,false);

mysql_query("UPDATE t_usuarios SET contrasena='$TXTCONTRASENA' WHERE id_usuario='$id_usuario'") or die(mysql_error());;

$mensaje = "Nueva Contraseña: ".$clave.    "  Nombre del Alumno: ".$nombre;

mail($email,"Datos de Acceso",$mensaje,"From: Contacto <escuelas@ministerioredil.org>");

echo "Se ha enviado un e-mail a tu correo electronico con la contraseña .. Revise en su Bandeja de Spam o No deseado";

//header("Location: video.php");

} else {

MESSAGE("No existe ningun alumno con este e-mail o nombre de usuario","0");
header("Location: index2.php");
}
} else {

?>
Escribe tu  Nombre de Usuario para que se te envie la nueva contraseña.<br> Se te enviará una nueva contraseña debido a que la tuya está encriptada .<br>
<br>
<form action="" method="post" name="form" id="form">
  Nombre de Usuario 
  <input name="nick" type="text" id="nick">
  <input name="recordar" type="submit" id="recordar" value=" Enviar Contraseña ">
</form>
<?php
}
?>
				</div>
				
			</div>
			<!-- end #content -->
		
		
			<div style="clear: both;">&nbsp;</div>
			<div id="widebar">
				<div id="colA">
					<h3>Estadisticas del Instituto</h3>
					<dl class="list1">
                                            <dd>
                                          
						<?php
						//echo $ESTADISTICA;
						?>
                                          
                                            </dd>
					</dl>
				</div>
				<div id="colB" style='background-image:url(img/estructura/logitos.png);background-repeat:no-repeat' >
					<h3>Sitios Web de Interes</h3>
					<dl class="list1">
						<dt>&nbsp;</dt>
						<dd><a TARGET='_blank' href='http://www.ministeriojorgeporras.org.ve'>Ministerio Internacional Jesuscristo es el Señor</a></dd>
						<dt>&nbsp;</dt>
						<dd><a TARGET='_blank' href='http://translate.google.es/'>Traductor de palabras de Google</a></dd>
						<dt>&nbsp;</dt>
						<dd><a TARGET='_blank' href='https://mail.google.com/'>Correo Electr&oacute;nico Gmail</a></dd>
						<dt>&nbsp;</dt>
						<dd><a TARGET='_blank' href='https://home.live.com/?mkt=es-es'>Correo Electr&oacute;nico Hotmail</a></dd>
						<dt>&nbsp;</dt>
						<dd><a TARGET='_blank' href='http://www.universidadteologicayeshua.com'>Universidad Teologia Yeshua</a></dd>
						<dt>&nbsp;</dt>
						<dd><a TARGET='_blank' href='http://www.youtube.com/'>Youtube. Broadcast Yourself.</a></dd>
                                        </dl>
				</div>
				<div id="colC">
					<h3>Citas Celebres</h3>
					<ul class="list2">
                                            <li style="padding-left:35px;" >
												<?php
                                                   
													//echo $CITAS;
                                                ?>
                                            </li>
                                          <!--  <li>
                                                <table cellpadding='0' cellspacing='0' border='0' style="width:300px">
                                                <tr><td><font size=2><font color=green>D&iacute;a de la Semana</font>&nbsp;&nbsp;<font color=blue><u>D&iacute;a Feriado</u></font>&nbsp;&nbsp;<font color=Red>D&iacute;a Libre</font>&nbsp;&nbsp;<font color=Black><u><b>Hoy</b></u></font></font><td></tr>
                                                </table>
                                            </li>-->
					</ul>
				</div>
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #widebar -->
		</div>
		<!-- end #page -->
	</div>
	<!-- end #wrapper2 -->
	<div id="footer">
		<p>Todos los Derechos Reservados 2014. CECIP.<br>
		  </p>
                
                  <a href="http://validator.w3.org/check?uri=referer"><img
                  src="http://www.w3.org/Icons/valid-html401" alt="Valid HTML 4.01 Transitional" height="31" ></a>
                <a href="http://jigsaw.w3.org/css-validator/check/referer"><img style="border:0;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss-blue" alt="¡CSS Válido!" ></a>

              
	</div>
</div>
</body>
</html>
