<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
<title>Archivos a descargar CECIP ONLINE</title>
</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<?php

	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."'";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	if(mysql_num_rows($datos22)==0)
	{
		echo "NO SE ENCUENTRA REGISTRADO EN NINGUNA ESCUELA";
		
	
	}else{
	
?>
<table width="780" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th scope="row">&nbsp;</th>
  </tr>
  <tr>
    <th scope="row"><?php  
	
	$SQL1 = "select * from t_personal WHERE id_personal ='".$ID_USUARIO."'";
	$SQL_CHK_EXISTENCIA= mysql_query($SQL1) or die ('Error al buscar el id del personal');
	$cedula = mysql_result($SQL_CHK_EXISTENCIA,0,"cedula");
	
	$resp = "select * from alumnos_online WHERE ci ='".$cedula."' AND status2=''";
	$datos22 = mysql_query($resp) or die("no se pude realizar el sql");
	if(mysql_num_rows($datos22)==0) {
		echo"<b>EL ALUMNO NO TIENE ESCUELA PENDIENTE PARA CURSAR..</b>";
    } else {
	
							
		//echo $datos[nombre];
							//include($archivo);
							
							
	
	//$nomescuela= mysql_result($datos22,0,"escuela");
	$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$escuela." ");
	//$archivo =mysql_result($escuelas,0,"fichero");
	
	echo " <br><strong>CLICK SOBRE LA ESCUELA PARA VER LOS ARCHIVOS:</strong><br><br> ";
						
						//if (mysql_result($datos22,0,"status") == 'Pagado')
						//{
				for($i=0;$i<mysql_num_rows($datos22);$i++)
				{	
					$escuela=mysql_result($datos22,$i,"escuela");
					$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad='$escuela' ");
					$archivo =mysql_result($escuelas,0,"fichero");
						if (mysql_result($datos22,$i,"status") == 'Pagado')
						{
							echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera2'><td width=300><font color=white>NOMBRE DE LA ESCUELA</font></td></tr>";
							echo"<tr ".$STYLECELDAS." bgcolor=#DBFFB7>";
							echo "<td align=left><a href='visordescargas.php?archivo=$archivo&cedula=$cedula&escuela=$escuela'>".mysql_result($escuelas,0,"escuela")."</a> </td></tr>";
							
							
						}else{
							
							echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera2'><td width=300><font color=white>NOMBRE DE LA ESCUELA</font></td><td width=150><font color=white>PRECIO EN Bs.F</font></td> <td width=150> <font color=white>PRECIO EN DOLARES</font></td> <td width=118><font color=white>PAGAR ESCUELA</font></td></tr>";
							//echo "<table align=center width=780 border = 0 bordercolor = #CCCCCC cellpadding = 2 cellspacing = 2><tr class='cabecera2'><td width=300><font color=white>NOMBRE DE LA ESCUELA</font></td></tr>";
							echo"<tr ".$STYLECELDAS." bgcolor=#FFB9B9>";
							
							echo "<td align=left>".mysql_result($escuelas,0,"escuela")."</td><td> Bs.F: <a href='pagosven.php'>".mysql_result($escuelas,0,"precio_bs")."</a></td><td width=150> $: <a href='pagosext.php'>".mysql_result($escuelas,0,"precio_usd")."</a></td><td  width=118 align = center><a href=tipopagos.php><img src=img/pagar.jpg border=0 onmouseover=this.style.cursor='pointer' title='Realizar pago'></a></td></tr>";
							//echo "<td align=left>".mysql_result($escuelas,0,"escuela")."</td></tr>";
							
						}
				
				}


							
							
						//}else{
							//echo " <br> <br>ARCHIVOS NO DISPONIBLE.. ESCUELA PENDIENTE DE PAGO.::  <br>DEBE REALIZAR EL PAGO DE LA ESCUELA
							//echo " <br> <br>ARCHIVOS NO DISPONIBLE..::  <br>DEBE REALIZAR EL PAGO DEL MATERIAL PARA DESCARGARLO						
							//<br><br><div align='center'><a href='tipopagos.php'><img src='http://centroeducativocecip.com/img/bnpagar.jpg'></a></div>";
							//echo " <br> <br>Su inscripción será verificada por la coordinación de estudios online.<br>";
						
						//}
	
	
		
	
	}
	echo " <br>";
?></th>
  </tr>
  <tr>
    <th scope="row">&nbsp;</th>
  </tr>
</table>
<?php 
	}

?>
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>
