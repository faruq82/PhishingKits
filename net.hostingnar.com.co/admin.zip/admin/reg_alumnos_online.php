<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=0" />
	<title>REDIL ONLINE</title>
	<link rel="shortcut icon" type="image/x-icon" href="css/images/favicon.ico" />
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
		<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-26080345-2', 'auto');
  ga('send', 'pageview');

</script>
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,900,800,700,600,500,300,200,100' rel='stylesheet' type='text/css'>
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-26080345-2', 'auto');
  ga('send', 'pageview');

</script>
	<script src="js/jquery-1.8.0.min.js" type="text/javascript"></script>
	<!--[if lt IE 9]>
		<script src="js/modernizr.custom.js"></script>
	<![endif]-->
	<script src="js/jquery.carouFredSel-5.5.0-packed.js" type="text/javascript"></script>
<script src="js/functions.js" type="text/javascript"></script>
<style type="text/css">
#wrapper .shell .container .main .cols .col p {
	text-align: justify;
}
#wrapper .shell .container .main .entries .entry p {
	font-family: "Century Gothic";
	font-style: normal;
}
.Estilo1 {color: #FFFFFF}
</style>
<script language="javascript"> 
function verifica(){ 
 var er_texto =  /^[a-zA-Z0-9\s+\u00d1+\u00c1+\u00c9+\u00cd+\u00d3+\u00da+\u00e1+\u00e9+\u00ed+\u00f3+\u00fa+\u00f1+]{4,15}$/;

    if(document.form.nick.value.length < 4){ 
 
        alert("Debe ingresar el Nombre de Usuario MAXIMO 8 CARACTERES y MINIMO 4"); 
 
        document.form.nick.focus(); 
 
        return false;
 
    }
	
	    if(document.form.nick.value.length > 8){ 
 
        alert("Debe ingresar el Nombre de Usuario MENOR A 8 CARACTERES"); 
 
        document.form.nick.focus(); 
 
        return false;
 
    }
	
		var TXTUSUARIO=document.getElementById('nick').value;
		if(!er_texto.test(TXTUSUARIO))
		{
			alert("ERROR EN EL NOMBRE DE USUARIO. SOLO SE PERMITE NUMEROS Y LETRAS");
			return false;
		} 


    if(document.form.nombre.value.length < 2){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe ingresar su Nombre"); //mensaje a la pantalla
 
        document.form.nombre.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }
	
	    if(document.form.contrasena.value.length < 2){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe ingresar su Contraseña"); //mensaje a la pantalla
 
        document.form.contrasena.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }
	
	 
    if(document.form.apellido.value.length < 2){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe ingresar su Apellido"); //mensaje a la pantalla
 
        document.form.apellido.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }
	
	
    if(document.form.CMBESCUELA.value==-1){ //si el largo de nombre es menor a 2 caracteres
 
        alert("Debe Seleccionar su escuela a Cursar"); //mensaje a la pantalla
 
        document.form.CMBESCUELA.focus(); //el puntero del mouse queda en nombre
 
        return false; //devolvemos un cero para dejar de validar
 
    }	
 

 
    if(document.form.email.value.length < 1){ 
 
        alert("Debe ingresar el E-Mail"); 
 
        document.form.email.focus(); 
 
       return false;
    }
 
   	  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(document.form.email.value))
      {}
      else 
     { alert("La dirección de email " + document.form.email.value + " es incorrecta.");
       document.form.email.focus();
	   return false;
     } 
 
    if(document.form.telefono.value.length < 10){ 
 
        alert("Debe ingresar un número de Teléfono"); 
 
        document.form.telefono.focus(); 
 
        return false; 
 
    }

 function numeros(){
var key=window.event.keyCode;
if (key < 48 || key > 57){
window.event.keyCode=0;
}
}
         // //document.form.submit(); //enviamos formulario    
 
} 
 
</script> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<!-- wrapper -->
<div id="wrapper">
	<!-- shell -->
	<div class="shell">
		<!-- container -->
	  <div class="container">
			<!-- header -->
			
            <!-- end of header -->
            <!-- navigaation -->
            <nav id="navigation"> <a href="home.html" title="principal" target="_self" class="nav-btn">HOME<span></span></a>
<ul>
	        <li class="active"><a href="http://ministerioredil.org/index.html" title="principal" target="_self">HOME</a></li>
					<li><a href="index2.php" title="login" target="_self">LOGIN</a></li>
					<li><a href="http://ministerioredil.org/escuelainterce.html	" title="cecip" target="_self">ESCUELAS</a></li>
					<li><a href="http://ministerioredil.org/contacto.php" title="CONTACTO" target="_self">CONTACTOS</a></li>
			</ul>
				<div class="cl">&nbsp;</div>
			</nav>
			<!-- end of navigation -->
			<!-- slider-holder -->

<img src="img/baner-online-cecip.jpg" width="1000" height="312">		  <div class="main"></div>



			  </section>
                <table width="900" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="650">					<form action="registrar.php" method="post" name="form" id="form" onsubmit="return verifica()">
        	    <table width="606" height="159" border="0" align="center">
        	      <tr>
        	        <td width="32" valign="top"><p class="Estilo73">&nbsp;</p>
       	            </td>
        	        <td width="564" valign="top"><table width="564" border="0" align="center" cellpadding="0" cellspacing="0" >
                      <tr>
                        <td height="28" valign="top">&nbsp;</td>
                      </tr>
                      <tr>
                        <td width="564" height="235" valign="top">                            
                              <table width="84%"  border="0" align="center" cellpadding="0" cellspacing="3">
                                <tr bgcolor="#45813B">
                                  <td class="text"><span class="Estilo77 Estilo1">DATOS PERSONALES </span></td>
                                  <td class="Estilo75">&nbsp;</td>
                                </tr>
                                <tr>
                                  <td width="37%" class="text"><div align="right"><strong><span class="t_rights"> NICK (nombre de Usuario): </span></strong></div></td>
                                  <td width="63%" class="Estilo75"><span class="Estilo14">
                                    <input name="nick" type="text" id="nick" size="40" onChange="javascript:this.value=this.value.toUpperCase()" />
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)&nbsp; 8 Caracteres</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Contrase&ntilde;a: </span></strong></div></td>
                                  <td class="Estilo76">                                    <input name="contrasena" type="password" id="contrasena" size="40" />                                  <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Repetir Contrase&ntilde;a: </span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="contrasena2" type="password" id="contrasena2" size="40" />
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Nombres: </strong></div></td>
                                  <td class="Estilo76"><input name="nombre" type="text" id="nombre" size="40" onChange="javascript:this.value=this.value.toUpperCase()"/>
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Apellidos:</strong></div></td>
                                  <td class="Estilo76"><input name="apellido" type="text" id="apellido" size="40" onChange="javascript:this.value=this.value.toUpperCase()"/>
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>C.I / ID / DNI:</strong></div></td>
                                  <td class="Estilo76"><input name="ci" type="text" id="ci" size="40" onKeypress="numeros()"/>
                                      <font size="1" face="Georgia, Times New Roman, Times, serif">(*)  &nbsp;solo numeros</font></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Profesi&oacute;n</strong></div></td>
                                  <td class="Estilo76"><input name="profesion" type="text" id="profesion" size="40" onChange="javascript:this.value=this.value.toUpperCase()"/>  &nbsp;</td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong>Fecha de Nacimiento: </strong></div></td>
                                  <td class="Estilo76"><input name="naci" type="text" id="naci" size="40" onChange="javascript:this.value=this.value.toUpperCase()"/>
                                  <font size=1 color=gray>Ej. 99/99/999</font> </td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Telefono: </span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="telefono" type="text" id="telefono" size="40" onChange="javascript:this.value=this.value.toUpperCase()"/>
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Sexo: </span></strong></div></td>
                                  <td class="Estilo75"> <span class="Estilo14">
                                    <select name="sexo" id="sexo">
                                      <option value="M">Masculino</option>
                                      <option value="F">Femenino</option>
                                    </select>
                                  </span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Email </span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="email" type="text" id="email" size="40" />
                                    <font size="1" face="Georgia, Times New Roman, Times, serif">(*)</font></span></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Pais:</span></strong></div></td>
                                  <td class="Estilo75"><?php 
								  include("ceoconexion.php");
								  				echo "<select  id='CMBPAIS' name='CMBPAIS'  style='width:250px' onChange='cambiarestado()' >";
               	$QUERY= mysql_query("select * from T_PAIS ORDER BY PAIS");
			echo "<option value=-1></option>";
                 	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_PAIS").">".mysql_result($QUERY,$i,"PAIS")."</option>";
				}
				echo "</select>";
				
								   ?></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Estado:</span></strong></div></td>
                                  <td class="Estilo75"><?php 
								   include("ceoconexion.php");
								echo "<select 'CMB_ESTADOS' id='CMBESTADOS' name='CMBESTADOS'  style='width:250px' onChange='cambiarciudad()' >";
               	$QUERY= mysql_query("select * from T_ESTADOS");
				echo "<option value=-1></option>";	
				for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"ID_ESTADO").">".mysql_result($QUERY,$i,"ESTADO")."</option>";
				}
				echo "</select>";
				
								   ?></td>
                                </tr>
                                <tr>
                                  <td class="text"><div align="right"><strong><span class="t_rights"> Ciudad:</span></strong></div></td>
                                  <td class="Estilo75"><span class="Estilo14">
                                    <input name="CMBCIUDAD" type="text" id="CMBCIUDAD" size="40" />
                                  </span></td>
                                </tr>
                                <tr bgcolor="#45813B">
                                  <td colspan="2" class="input Estilo13"><span class="text Estilo77 Estilo1">DATOS DE LA ESCUELA:</span></td>
                                </tr>
                                <tr>
                                  <td ><div align="right"><strong>Escuela: </strong></div></td>
                                  <td>					
					<?php
					
				echo "<select name='CMBESCUELA' id='CMBESCUELA' >";
               	$QUERY= mysql_query("select * from t_actividades2 order by id_actividad");
              	echo "<option value=-1></option>";
				mysql_num_rows($QUERY);
               	for($i=0;$i<mysql_num_rows($QUERY);$i++)
				{
					echo "<option value=".mysql_result($QUERY,$i,"id_actividad").">".mysql_result($QUERY,$i,"escuela")."</option>";
				}
              	echo "</select> "
					
					?>
					</td>
                                </tr>
                                <tr>
                                  <td >&nbsp;</td>
                                  <td><div align="right"><span class="Estilo76"><font face="Georgia, Times New Roman, Times, serif">(*) CAMPOS OBLIGATORIOS</font></span> </div></td>
                                </tr>
                                <tr>
                                  <td ><span class="Estilo13"></span></td>
                                  <td><input name="registro" type="submit" id="registro" value=" Registrar " />
                                      <input name="borrar" type="reset" id="borrar" value=" Limpiar " /></td>
                                </tr>
                                <tr>
                                  <td colspan="2"><br />
                                      <span class="Estilo75"><strong><img src="img/padlock.gif" width="17" height="16" />Por motivos de seguridad guardaremos su IP actual, su IP  <?=$ip = $_SERVER['REMOTE_ADDR'];
																		?> ha sido guardada en nuestra base de datos.:</strong></span>
                                     
                                  </td>
                                </tr>
                                <tr>
                                  <td colspan="2"></td>
                                </tr>
                              </table>
                         
                        </td>
                      </tr>
                    </table></td>
        	      </tr>
      </table>
	     </form></td>
                    <td width="350" valign="top"><br><br><p><strong>PASOS PARA INSCRIBIRTE:</strong></p>
                      <p><strong>&nbsp;</strong><strong>PASO 1: </strong>Has clic en la escuela de tu preferencia, regístrate como nuevo estudiante, crea tu usuario y tu password con el que luego podrás hacer“LOGIN” en tu panel de estudiante y tener acceso a todo el material.</p><br>
                      <p><strong>&nbsp;</strong><strong>PASO 2: </strong>Has el pago de la escuela según el método de tu preferencia. </p><br>
                      <p><strong></strong><strong>PASO 3: </strong>Cuando confirmemos tu pago te enviaremosa tu correo electrónico una carta de bienvenida y un instructivo que te guiará paso a paso en el programa educativo. A partir de ese momento tendrás pleno acceso a todo el material digital de la escuela. </p><br>
                      <p><strong>&nbsp;</strong><strong>PASO 4: </strong>Si tienes alguna pregunta te puedes comunicar al número gratuito 1(844) 627-6508 y si estas en Venezuela al (0261)322-9424 o escribirnos directamente al correo académico escuelas@ministerioredil.org</p><br>
                    </td>
                  </tr>
                </table>
</div>
			<!-- end of main -->
			<div class="cl">&nbsp;</div>
			
			<!-- footer -->
			<div id="footer">
				<p class="copy">&copy; Copyright 2015<span>|</span>Design by <a href="http://clientesoft.com" target="_blank">clientesoft.com</a></p>
				<div class="cl">&nbsp;</div>
	  </div>
			<!-- end of footer -->
  </div>
		<!-- end of container -->
</div>
	<!-- end of shell -->
</div>

<!-- end of wrapper -->
</body>
</html>