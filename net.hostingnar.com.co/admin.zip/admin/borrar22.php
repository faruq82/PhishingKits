<?php

$id = $_GET['id'];


	require('ceoconexion.php');
	
		$query = "delete from  reviews where id='$id'";
		$result = mysql_query($query);
		
			

//Para devolver a la p�gina donde se pidi� la acci�n
if (isset ($_GET['buscar'])== "") {
	$url = $_GET['from'];
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".$url."'>";
} 
else {
	$url = $_GET['from'];
	$url2 = $_GET['buscar'];
	echo "<META HTTP-EQUIV='Refresh' CONTENT='0; URL=".$url."&buscar=".$url2."'>";
}
?>