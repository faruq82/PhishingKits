<?php

	
	session_name('MIORDEN');
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ceorep.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	if($ID_USUARIO != "")
	{
		$VERIFICAR = mysql_query("select * from t_usuarios where id_usuario=".$ID_USUARIO."");
	
		if(mysql_num_rows($VERIFICAR)== 0)
		{
			MESSAGE('-Error al iniciar sesion.');
			REDIRIGIR('login.php');
		}
	}else
	{
		REDIRIGIR('login.php');
	}
	
		




require('pdf/fpdf.php');
class PDF extends FPDF
{
	
	
	
	function Tabla($ID_A_ESCOLAR)
	{
	
		$SQL = " SELECT * FROM t_personal inner join t_usuarios on t_personal.id_personal = t_usuarios.id_personal WHERE  t_usuarios.id_tipo_usuario=2 ORDER BY p_apellido, s_apellido, p_nombre, s_nombre ";

		$BUSQUEDA_DOCENTES= mysql_query($SQL)or die("error en el sql para buscar el docente");
		$this->SetTextColor(255,255,255);
		$this->SetFont('Arial','IB',10);
		$this->SetX(12); 
		$this->Cell(10,6,"Nro",1,0,'C',1);
		$this->Cell(60,6,"APELLIDOS",1,0,'L',1);
		$this->Cell(60,6,"NOMBRES",1,0,'L',1);
		$this->Cell(35,6,"IDENTIFICACION",1,0,'C',1);
		$this->Cell(30,6,"TELEFONO",1,0,'C',1);
		$this->Ln();
			
		$this->SetTextColor(0,0,0);
		$this->SetFont('Arial','I',9);
		$fill=false;
		for($i=0;$i<mysql_num_rows($BUSQUEDA_DOCENTES);$i++)
		//for($i=0;$i<500;$i++)
		{
			$this->SetX(20);
			if($i%2==0)
			{
				$this->SetFillColor(255,255,255);
			}else{
				$this->SetFillColor(223,232,244);
			}
			$this->SetX(12);
			$this->SetFont('Arial','IB',9);
			$this->Cell(10,6,$i+1,1,0,'C',1);
			$this->SetFont('Arial','I',9);
			$this->Cell(60,6,mysql_result($BUSQUEDA_DOCENTES,$i,"p_apellido")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"s_apellido"),1,0,"L",1);
			$this->Cell(60,6,mysql_result($BUSQUEDA_DOCENTES,$i,"p_nombre")." ".mysql_result($BUSQUEDA_DOCENTES,$i,"s_nombre"),1,0,"L",1);
			$this->Cell(35,6,number_format(mysql_result($BUSQUEDA_DOCENTES,$i,"cedula"),0,"","."),1,0,'C',1);
			
			$this->Cell(30,6,mysql_result($BUSQUEDA_DOCENTES,$i,"celular"),1,0,"C",1);
			$this->Ln();
			$fill=!$fill;
		}
		$this->SetX(12);
		$this->Cell(180,0,'','T');
		$this->SetFont('Arial','IB',10);
		$this->Ln(4);
		$this->SetX(12);
		$this->Cell(150,6,"TOTAL DE DOCENTES: ".mysql_num_rows($BUSQUEDA_DOCENTES),0,0,'L',0);
	
	
	
	}
	
		function Cabecera($AUX)
		{
			$AUX2 = $AUX-1;
			global $HORA,$FECHA_LETRA;
			$this->SetFont('Arial','',10);
			
				$NOMBRE_ESCUELA="PATRIA GRANDE";
				$TIPO_ESCUELA="UNIDAD EDUCATIVA";
			
			$this->Image("img/estructura/logo.jpg",12,5,15);
			$w=130; //ANCHO DE LA TABLA
			$m=28;//
			$this->Ln(5);
                        $this->SetX($m);
			$this->Cell($w,4,$TIPO_ESCUELA,0,0,'L',0);
			$this->Ln();
			$this->SetX($m);
			$this->Cell($w,4,$NOMBRE_ESCUELA,0,0,'L',0);
			$this->Cell(45,4,$FECHA_LETRA,0,0,'R',0);
			$this->Ln();	
			$this->SetX($m);
			$this->Cell($w,4,"AULAS VIRTUALES",0,0,'L',0);
			$this->Cell(44,4,$HORA,0,0,'R',0);
			$this->Ln();	
			$this->SetFillColor(79,130,187);
			$this->SetX(12); 
			$this->Cell(190,1,"",0,0,'C',true);
			$this->Ln();
			$this->Cell(190,0.5,"",0,0,'C',False);
			$this->Ln();
			$this->SetX(12); 
			$this->Cell(190,0.5,"",0,0,'C',true);
		
		
		
		}


		function Footer()
		{
			global $ANOFIRMA;
			//Posici�n a 1,5 cm del final
			$this->SetY(-10);
			$this->SetTextColor(128);
			$this->SetFont('Arial','I',10);
			$this->Cell(40,10,'Todos los Derechos Reservados LIDSOFTWARE '.$ANOFIRMA);
			$this->Cell(0,10,'Pag '.$this->PageNo(),0,0,'R');
		
		
		}
	

	
	
		function Titulo()
	{
			
		
		$this->SetTextColor(0,0,0);
		$this->SetFont('Arial','BU',11);
		$w=$this->GetStringWidth("LISTADO DE DOCENTES")+6;
		$this->SetY(28);
			
		$this->Ln(2);
		$this->SetX((210-$w)/2);
		$this->Cell($w,9," LISTADO DE DOCENTES ",0,0,'C',false);		
		$this->Ln(12);	
		
	
	}



}



$pdf=new PDF('P','mm','letter');
$pdf->AddPage();
$pdf->Cabecera($AUX);
$pdf->Titulo();
$pdf->Tabla($ID_A_ESCOLAR);
$pdf->Output();

?>