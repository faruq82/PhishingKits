<?php 
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
	
?>
<html >
<head>
<title>Cambio de Contrase&ntilde;a</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
</head>
<script language="javascript">
	var er_password = /^[0-9A-Za-z]{6,16}$/;
	var er_texto = /^[A-Z\s+\u00d1+]{1,25}$/;

	
	function objetoAjax()
	{ 
		var xmlhttp=false; 
		try 
		{ 
			xmlhttp=new ActiveXObject("Msxml2.XMLHTTP"); 
		}
		catch(e)
		{ 
			try
			{ 
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP"); 
			} 
			catch(E) { xmlhttp=false; }
		}
		if (!xmlhttp && typeof XMLHttpRequest!='undefined') { xmlhttp=new XMLHttpRequest(); } 
	
		return xmlhttp; 
	}
	
	function limpiar()
	{
		document.getElementById('TXTCONTRASENA').value="";
		document.getElementById('TXTCONTRASENANUEVA').value="";
		document.getElementById('TXTCONTRASENA2').value="";
		document.getElementById('TXTCONTRASENA').focus();
	}
	function guardar()
	{
		var ID_USUARIO='<?php echo $ID_USUARIO;?>';
		var divResultado = document.getElementById('resultado');
		var _TXTCONTRASENA = document.getElementById('TXTCONTRASENA').value;
		if(!er_password.test(_TXTCONTRASENA))
		{
			alert("ERROR EN CAMPO CONTRASE\u00d1A. DEBE SER DE 6 A 16 LETRAS O NUMEROS SIN CARACTERES ESPECIALES");
			document.getElementById('TXTCONTRASENA').focus();
			return false;
		}
		var _TXTCONTRASENANUEVA = document.getElementById('TXTCONTRASENANUEVA').value;
		if(!er_password.test(_TXTCONTRASENANUEVA))
		{
			alert("ERROR EN CAMPO NUEVA CONTRASE\u00d1A. DEBE SER DE 6 A 16 LETRAS O NUMEROS SIN CARACTERES ESPECIALES");
			return false;
		}

		if(document.getElementById('TXTCONTRASENANUEVA').value!=document.getElementById('TXTCONTRASENA2').value)
		{
			alert("ERROR EN CAMPO CONTRASE\u00d1A. NO COINCIDEN");
			return false;
			
		}
		mensaje('Cargando...');
		ajax=objetoAjax();
		ajax.open("POST", "ajax_reg_cambiar_contrasena.php",true);
		ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		ajax.send("TXTCONTRASENA="+encodeURIComponent(_TXTCONTRASENA)+"&ID_USUARIO="+ID_USUARIO+"&ACCION=GUARDAR&TXTCONTRASENANUEVA="+encodeURIComponent(_TXTCONTRASENANUEVA)+""); 
		ajax.onreadystatechange=function() {
			if (ajax.readyState==4)
			{
				document.getElementById('divalerta').innerHTML = "";
				document.getElementById('divalerta').style.display='none';
				document.getElementById('divalerta').style.height = "0px";
				document.getElementById('resultado').innerHTML = ajax.responseText;
				if(document.getElementById('AVISO'))
				{
					if(document.getElementById('AVISO').value=="")
					{
								
						alert("REGISTRO GUARDADO CON EXITO");
						limpiar();
					
											
					}
					if(document.getElementById('AVISO').value=="error")
					{
						alert("IMPOSIBLE GUARDAR LA CONTRASE\u00d1A. HUBO UN ERROR DURANTE LA OPERACION.");
						return false;
					}
					if(document.getElementById('AVISO').value=="invalida")
					{
						alert("Imposible guardar. Contrase\u00f1a Invalida");
						document.getElementById('TXTCONTRASENA').focus();
						return false;
					}
				}else{

					alert("IMPOSIBLE GUARDAR LA CONTRASE\u00d1A. HUBO UN ERROR DURANTE LA OPERACION.");
					return false;
				

				}
								
			}
		}
	}
	
	
function cargar()		
{
	document.getElementById('TXTCONTRASENA').focus();
}
		
	

</script>
<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
     <br>
       <table border=0 cellpadding="2" cellspacing="2" width="780" align="center">
        <tr><td ><B>Normas para cambiar su contrase&ntilde;a:</B></td></tr>
        <tr><td ><p align="justify">Cambiar la contrase&ntilde;a es muy sencillo, Ingresa tu contrase&ntilde;a anterior (es decir la que tienes actualmente) y la nueva contrase&ntilde;a, debajo te pedira que la repitas para confirmarla y por ultimo da clic en Guardar&zwnj;. Recuerda solo se admite entre 6 y 15 caracteres, combinando n&uacute;meros y letras, los cararcteres especiales no son permitidos.</p></td></tr>
        </table>
    


	<br>
    
     <table border="0" cellpadding="2" cellspacing="0" align="center" width="780" >    	
            <tr><td width=130>Contrase&ntilde;a Anterior</td><td><input type="password" name ="TXTCONTRASENA" id="TXTCONTRASENA" size="25" maxlength="25" >&nbsp;<font color="#FF0000">*</font></td></tr>
			<tr><td>Nueva Contrase&ntilde;a</td><td><input type="password" name ="TXTCONTRASENANUEVA" id="TXTCONTRASENANUEVA" size="25" maxlength="25" >&nbsp;<font color="#FF0000">*</font></td></tr>
            <tr><td>Repetir contrase&ntilde;a&nbsp;&nbsp;</td><td><input type="password" name ="TXTCONTRASENA2" id="TXTCONTRASENA2" size="25" maxlength="25" >&nbsp;<font color="#FF0000">*</font></td></tr>
            <tr><td colspan="2"><input type="hidden" name ="ACCION" id="ACCION"></td></tr>
            <tr><td colspan="2"><input type="hidden" name ="ID_USUARIO" id="ID_USUARIO" ></td></tr>
           
                        
              <tr><td><input type="submit" value="Guardar" name="BOTON" id="BOTON" onClick="guardar()">&nbsp;&nbsp;</td><td ><div id="resultado"></div></td></tr>
        </table>
        <br>
        
        
        
           <table border=0 cellpadding="2" cellspacing="2" width="780" align="center">
        <tr><td ><B> Pasos que deben evitarse:</B></td></tr>
        <tr><td><li>No utilice una contrase&ntilde;a que se ofrezca como ejemplo de buena contrase&ntilde;a.</li></td></tr>
        <tr><td><li>No utilice informaci&oacute;n personal en la contrase&ntilde;a (como su nombre, fecha de nacimiento, etc.) </li></td></tr>
        <tr><td><li>No utilice palabras o acr&oacute;nimos que figuren en el diccionario.</li></td></tr>
        <tr><td><li>No utilice patrones de teclado (asdf) ni números en secuencia (1234). </li></td></tr>
        <tr><td><li>No repita caracteres (aa11).</li></td></tr>
        </table>
    
        <br>
 <br>
		
	   <BR>
 
<?php    
	piecera($PRIVILEGIO);
?>
</body>
</html>