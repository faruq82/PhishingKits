<?php



//include("ceoconexion.php");
include("ajaxordenconfig.php");

	$TXTNICK = $_POST['nick'];
	$TXTCONTRA = $_POST['contrasena'];
	$TXTAPELLIDO=$_POST['apellido'];
	$TXTNOMBRE=$_POST['nombre'];
	$TXTCI=$_POST['ci'];
	$TXTPROFESION=$_POST['profesion'];
	$TXTNACI=$_POST['naci'];
	$EDAD=$_POST['edad'];
	$TXTTELEFONO=$_POST['telefono'];
	$ID_PERSONAL =$_POST['ID_PERSONAL'];
	$ID_USUARIO =$_POST['ID_USUARIO'];
	$CMBSEXO=$_POST['sexo'];
	$ESCUELA=$_POST['CMBESCUELA'];
	$TXTPAIS=$_POST['CMBPAIS'];
	$ESTADOS=$_POST['CMBESTADOS'];
	$CIUDAD=$_POST['CMBCIUDAD'];
	$TIPO_USUARIO ="2";
	$ESTATUS_USUARIO ="";
	$EMAIL =$_POST['email'];
	$TXTDIRECCION =$_POST['direccion'];
	$congregacion =$_POST['congregacion'];
	$direcongre =$_POST['direcongre'];
	$nommini =$_POST['nommini'];
	$telfmini =$_POST['telfmini'];
	$fecha = time();
	$ip = $_SERVER['REMOTE_ADDR'];
	
$mensaje =

"<!DOCTYPE html>
		<html>
			<head>
				<style type=\"text\/css\">
					body{font-size: 12px; font-family: \"Helvetica Neue\", Arial, Helvetica, sans-serif; color: #222; }
					.table{border: 1px solid #56647d; width:580px; padding:20px; }
					.capa{ width:100%;}
				</style>
			
			    <style type=\"text/css\">
<!--
.Estilo1 {font-size: 16px}
.Estilo2 {font-size: 14px}
.Estilo3 {font-size: 14}
-->
                </style>
			</head>
			<body>

<table width=\"100%\" border=\"0\" cellspacing=\"5\" cellpadding=\"5\">
  <tr>
    <td>
      <table  border=\"0\">
        <tr>
          <td><p><img src=\"http://ministerioredil.org/images/paolaporras.png\" width=\"231\" height=\"375\" hspace=\"3\" vspace=\"5\" align=\"left\" >Bienvenido (a), ".$TXTNOMBRE." ".$TXTAPELLIDO." a nuestro programa educativo. Para nosotros es de sumo gozo el poder contar con tu participaci&oacute;n y saber que vamos a contribuir entu proceso de formaci&oacute;n y capacitaci&oacute;n ministerial.</p>
            <p>Esta escuela fue creada con el fin de levantar una nueva generaci&oacute;n que anuncien, manifiesten y establezcan la voluntad del Padre celestial sobre la tierra y tengan un estilo de vida alineado a la cultura de Su Reino.</p>
            <p>Hemos dise&ntilde;ado nuestro programa educativo,para causar en ti, un poderoso despertar y activaci&oacute;n en breve tiempo. Ense&ntilde;amos e impartimos lo que el Padre celestial nos ha revelado que ser&aacute; relevante para el cumplimiento de tu encomienday prop&oacute;sito de vida.Es por esto que en cada lecci&oacute;n encontrar&aacute;s ense&ntilde;anzas pr&aacute;cticas que podr&aacute;s aplicar en tu vida diaria. </p>
            <p>S&eacute; que est&aacute;s listo(a) para emprender este gran viaje de aprendizaje, en donde la revelaci&oacute;n de la verdad abrir&aacute; tus ojos espirituales, te ubicar&aacute; y afirmar&aacute; en tu identidad, te direccionar&aacute; a tu prop&oacute;sito de vida y te activar&aacute; para que puedas cumplir con tu encomienda. </p>
            <p>Todo nuestro equipo ministerial est&aacute; comprometido a apoyarte y acompa&ntilde;arte en este proceso de formaci&oacute;n hasta que llegues a la meta que el Padre ha puesto delante de ti y as&iacute; te unas a los miles que hoy anuncian, manifiestan y establecen Su voluntad en la tierra. </p>
            <p>Con gran regocijo, </p>
            <p>Profeta Paola Santamar&iacute;a de Porras</p>
            <p>Fundadora - Presidente</p></td>
        </tr>
        <tr>
          <td><table border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  width=\"100%\" class=\"normal\">
            <tr>
              <td background=\"http://centroeducativocecip.com/img/cafe.png\" ><div align=\"center\" class=\"Estilo1\">
                <div align=\"center\"><strong>INSTRUCTIVO AL ESTUDIANTE </strong></div>
              </div>
                  <p align=\"center\" class=\"Estilo2\">Bienvenido a la escuela de Intercesi&oacute;n Prof&eacute;tica. A continuaci&oacute;n te daremos un instructivo que te guiar&aacute; paso a paso en lo que debes hacer para disfrutar de tus estudios.</p></td>
            </tr>
            <tr>
              <td><ul>
                  <li><span class=\"Estilo1\"><span class=\"Estilo2\"><span class=\"Estilo3\"><strong>PASO 1. </strong>Espera por tu Activaci&oacute;n: Una vez hiciste tu inscripci&oacute;n debes esperar que tu pago sea confirmado por el departamento de finanzas y activada tu cuenta como estudiante en el sistema. Las activaciones de los nuevos estudiantes se hacen de lunes a viernes durante horarios de oficina. </span></span></span></li>
              </ul>
                  <ul class=\"Estilo3\">
                    <li> <strong>PASO 2. </strong>Entra al portal web: www.ministerioredil.org/campus/</li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 3</strong>. Has clic en la escuela en la que te hayas registrado</li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li> <strong>PASO 4</strong>. HAZ LOGIN: Entra a &ldquo;login&rdquo; e introduce el usuario y la clave que creaste para registrarte, esto te conducir&aacute; a tu panel de estudiante. </li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 5. </strong>FAMILIAR&Iacute;ZATE CON TU PANEL DE ESTUDIANTE: Una vez que est&eacute;s en tu panel de estudiante, tendr&aacute;s acceso a todo el material digital de la escuela. Revisa cada bot&oacute;n para que te familiarices con los contenidos. </li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 6.</strong> DESCARGA TU MATERIAL. Entra en el bot&oacute;n &ldquo;DESCARGA&rdquo; en donde encontrar&aacute;s tu manual digital, l&aacute;minas de &ldquo;Power Point&rdquo; y videos que corresponden a los m&oacute;dulos de la escuela. </li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 7. </strong>ESCUCHA LOS AUDIOS: Empieza por el m&oacute;dulo uno (1) hasta que llegues al &uacute;ltimo m&oacute;dulo. Te recomendamos escoger un horario en donde puedas concentrarte y permitir que el Padre celestial te ministre. </li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 8</strong>. ELLENA TUS EVALUATIVOS: Despu&eacute;s que escuches cada m&oacute;dulo deber&aacute;s presionar el bot&oacute;n de &ldquo;EVALUATIVOS&rdquo;. Descarga el evaluativo que corresponda al m&oacute;dulo que has escuchado, ll&eacute;nalo y env&iacute;alo utilizando el bot&oacute;n azul &ldquo;SUBIR-EVALUATIVO&rdquo;. Nota: Tu certificado de participaci&oacute;n solo te ser&aacute; emitido cuando hayas enviado los evaluativos en totalidad.</li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 9 </strong>. ADQUIERE TU MATERIAL COMPLEMENTARIO. Hemos dise&ntilde;ado seminarios y talleres que est&aacute;n en audio y en video que complementan y profundizan el material que vas a estudiar en la escuela. Te recomendamos altamente que lo adquieras presionando el bot&oacute;n &ldquo;LIBRER&Iacute;A&rdquo;</li>
                  </ul>
                  <ul class=\"Estilo3\">
                    <li><strong>PASO 10 </strong>. ESCOGE A UN DISC&Iacute;PULO: Te recomendamos escoger a una persona con la que puedas compartir lo que estas aprendiendo en clase. Esto te ayudar&aacute; a tener mayor claridad en el material y a crecer en impartici&oacute;n. &ldquo;Debemos dar por gracia lo que por gracia hemos recibido&rdquo;</li>
                  </ul>
                  <ul>
                    <li class=\"Estilo3\">Si tienes preguntas o dudas presiona el bot&oacute;n &ldquo;ASESOR&Iacute;A AL ESTUDIANTE&rdquo;, env&iacute;anos tu pregunta e inmediatamente te responder&aacute; uno de nuestros asesores en vivo durante los horarios de oficina. Tambi&eacute;n puedes escribirnos directamente al correo acad&eacute;mico: escuelas@ministerioredil.org</li>
                  </ul>
                </td>
            </tr>
            <tr>
              <td height=\"68\" background=\"http://centroeducativocecip.com/img/cafe.png\"><div align=\"center\" class=\"Estilo1\">
                <div align=\"center\"></div>
              </div></td>
            </tr>
            <tr>
              <td><strong>Felicitaciones por tomar la decisi�n de ser parte de los miles que hoy anuncian, manifiestan y establecen la Voluntad del Padre sobre la tierra.</strong></strong></td>
            </tr>
          </table>
</td>
        </tr>
      </table></td>
  </tr>
</table>

</body>
</html>";
		
//$SQL1= "SELECT * FROM  t_personal  WHERE correo='$EMAIL' or cedula='$TXTCI' ";
$SQL1= "SELECT * FROM  t_personal  WHERE correo='$EMAIL' ";
$QUERY = mysql_query($SQL1);
if(mysql_num_rows($QUERY)>0)
			
{
			 //echo "<input type='hidden' id='AVISOMOFICIADO' value= 'yaexiste'>";
			MESSAGE('HUBO UN ERROR DURANTE LA OPERACION. EL EMAIL YA SE ENCUENTRA REGISTRADO.. DEBE INICIAR SESION');
			REDIRIGIR("login.php");
			//return; 
} else { 
	
	
	
	
$SQL11= "SELECT * FROM  t_usuarios  WHERE nombre_usuario='$TXTNICK ' ";
$QUERY1 = mysql_query($SQL11);
if(mysql_num_rows($QUERY1)>0)
	{
			 //echo "<input type='hidden' id='AVISOMOFICIADO' value= 'yaexiste'>";
		MESSAGE('HUBO UN ERROR DURANTE LA OPERACION. EL NOMBRE DE USUARIO/NICK YA SE ENCUENTRA REGISTRADO.. DEBE INICIAR SESION');
		REDIRIGIR("login.php");		
	} else {		
	
	
	$SQL12= "SELECT * FROM  t_personal  WHERE cedula='$TXTCI' ";
	$QUERY2 = mysql_query($SQL12);
	if(mysql_num_rows($QUERY2)>0)
		{
			 //echo "<input type='hidden' id='AVISOMOFICIADO' value= 'yaexiste'>";
		MESSAGE('HUBO UN ERROR DURANTE LA OPERACION. EL NUMERO DE CEDULA YA SE ENCUENTRA REGISTRADO.. DEBE INICIAR SESION');
		REDIRIGIR("login.php");		
		} else {	
			//$SQL=array();
			$SQL[] ="INSERT INTO t_personal (cedula,p_apellido,p_nombre,sexo,direccion,telefono,correo ) VALUES('".$TXTCI."', '".$TXTAPELLIDO."','".$TXTNOMBRE."','".$CMBSEXO."','".$TXTDIRECCION."','".$TXTTELEFONO."','".$EMAIL."')";
			if(CORRER_TRANSACCION($SQL)==1) 
			{
				 //echo "<input type='hidden' id='AVISOMOFICIADO' value= 'error'>";
				 MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
				 REDIRIGIR("reg_alumnos_online.php");
				//unset($SQL);
				//return; 
			}else{
					//AUDITORIA($SQL);
					//unset($SQL);
					$SQL2 = "select * from t_personal WHERE cedula ='".$TXTCI."'";
					$SQL_CHK_EXISTENCIA= mysql_query($SQL2) or die ('Error al buscar el id del personal');
					$ID_PERSONAL = mysql_result($SQL_CHK_EXISTENCIA,0,"id_personal");
					$SQL_TIPO_USUARIO=mysql_query("SELECT * FROM t_tipos_usuarios WHERE id_tipo_usuario = ".$TIPO_USUARIO."") or die("Error en el sql");
					if(mysql_num_rows($SQL_TIPO_USUARIO)!=0)
					{
					
						$SQL3=array();
						$NOMBRE_USUARIO=$TXTNICK;
						$CONTRASENA = md5($TXTCONTRA,false);
						//$CONTRASENA = md5('123456',false);
						$ESTATUS_USUARIO="";
						$SQL3[] ="INSERT INTO t_usuarios (id_tipo_usuario,id_personal,nombre_usuario,contrasena,estatus_usuario) VALUES(".$TIPO_USUARIO.",".$ID_PERSONAL.",'".$NOMBRE_USUARIO."','".$CONTRASENA."','".$ESTATUS_USUARIO."')";
						
						if(CORRER_TRANSACCION($SQL3)==1) 
						{
							 MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
							 REDIRIGIR("reg_alumnos_online.php");
						}else{						
								//LO REGISTRAMOS A LA ESCUELA;
								$SQL4[] ="INSERT INTO alumnos_online (fecha,nick,email,pais,estado,sexo,direccion,ip,ci,profesion,nombre,apellido,telefono,edad,congregacion,direcongre,nomministro,telministro,fechana,escuela) VALUES('".$fecha."', '".$TXTNICK."','".$EMAIL."','".$TXTPAIS."','".$ESTADOS."','".$CMBSEXO."','".$TXTDIRECCION."','".$IP."','".$TXTCI."','".$TXTPROFESION."','".$TXTNOMBRE."','".$TXTAPELLIDO."','".$TXTTELEFONO."','".$EDAD."','".$congregacion."','".$nommini."','".$direcongre."','".$telfmini."','".$TXTNACI."','".$ESCUELA."')";
								if(CORRER_TRANSACCION($SQL4)==1) 
								{
							 		//MESSAGE('HUBO UN ERROR DURANTE LA OPERACION.');
									echo 'HUBO UN ERROR NO SE REGISTRO EN LA ESCUELA SELECCIONADA.';
									// REDIRIGIR("reg_alumnos_online.php");
								}else{
							
								//MESSAGE('OPERACION REALIZADA CON EXITO.');
									echo 'EL ALUMNO FUE INSCRITO EN LA ESCUELA CORRECTAMENTE...';
									//unset($SQL4);
								}



									$escuelas = mysql_query("select * from t_actividades2 WHERE id_actividad=".$ESCUELA." ");
									$nombreescuela =mysql_result($escuelas,0,"escuela");

									echo 'REDIRECCIONANDO AL PANEL DEL ALUMNO.';
							
									
									$cuerpo = "===== INFORMACION DEl ALUMNO ===== <br>";
									$cuerpo .= "Nombre: " . $TXTNOMBRE . "<br>";
									$cuerpo .= "Apellido: " . $TXTAPELLIDO . "<br>";
									$cuerpo .= "NOMBRE DE USUARIO(NICK): " . $TXTNICK . "<br>";
									$cuerpo .= "Email: " .$EMAIL. "<br>";
									$cuerpo .= "Telefono: " . $TXTTELEFONO . "<br>";
									$cuerpo .= "ESCUELA: " .$nombreescuela. "<br>";
									
									$cuerpo2 = "===== INFORMACION DEl ALUMNO ===== <br><br>";
									$cuerpo2 .= "Nombre: " . $TXTNOMBRE . "<br>";
									$cuerpo2 .= "Apellido: " . $TXTAPELLIDO . "<br>";
									$cuerpo2 .= "NOMBRE DE USUARIO(NICK): " . $TXTNICK . "<br>";
									$cuerpo2 .= "Email: " .$EMAIL. "\n";
									$cuerpo2 .= "Telefono: " . $TXTTELEFONO . "<br>";
									$cuerpo2 .= "ESCUELA: " .$nombreescuela. "<br>";
									

									//mando el correo...									
									mail("escuelas@ministerioredil.org","Se Registro un nuevo Alumno",$cuerpo2,"From: Redil <escuelas@ministerioredil.org>");
									
									//mail($EMAIL,"Registro de ALUMNO",$cuerpo,"From: Cecip <cecip_online@centroeducativocecip.com>");
									$asunto="Registro de ALUMNO";
									
									//mando el correo de la carta...
									//$cabeceras = "From: contacto@ministerioredil.org\r\nContent-type: text/html\r\n";
									//mail($EMAIL,"CARTA DE BIENVENIDA DE LA FUNDADORA",$mensaje,$cabeceras);
									$asutocarta="CARTA DE BIENVENIDA DE LA FUNDADORA";
									
									require("PHPMailer/class.phpmailer.php");	
									$mail = new PHPMailer();
									$mail->Mailer = "smtp";
									$mail->Host = "mail.ministerioredil.org";
									$mail->Port="25";
									$mail->SMTPAuth = true;
									$mail->Username = "escuelas@ministerioredil.org";
									$mail->Password = "LXM71HE3i";
									$mail->CharSet = "UTF-8";
									$mail->From = "escuelas@ministerioredil.org";
									$mail->FromName = "Redil";
									$mail->IsHTML(true);                                
									$mail->Subject = $asutocarta;
									$mail->Body    = $mensaje;
									$mail->AddAddress($EMAIL);
									$mail->Send();
									
									//require("PHPMailer/class.phpmailer.php");	
									$mail = new PHPMailer();
									$mail->Mailer = "smtp";
									$mail->Host = "mail.ministerioredil.org";
									$mail->Port="25";
									$mail->SMTPAuth = true;
									$mail->Username = "escuelas@ministerioredil.org";
									$mail->Password = "LXM71HE3i";
									$mail->CharSet = "UTF-8";
									$mail->From = "escuelas@ministerioredil.org";
									$mail->FromName = "Redil";
									$mail->IsHTML(true);                                
									$mail->Subject = $asunto;
									$mail->Body    = $cuerpo;
									$mail->AddAddress($EMAIL);
									$mail->Send();
																		
									
									
									$NOMBRE_USUARIO = $_POST['nick'];
									$TXTCONTRA = $_POST['contrasena'];
									echo '<script>location="cargando.php?TXTUSUARIO='.$NOMBRE_USUARIO.'&TXTCONTRASENA='.$TXTCONTRA.'" </script>';
							
							
							
						}
			
					}else{
						
						 MESSAGE('UNABLE TO PERFORM THE OPERATION, THERE WAS AN ERROR IN THE PROCESS');
						 //REDIRIGIR("reg_alumnos_online.php");
						
					}
				}
	  }			
	}				
}						


?>
