<?php
	session_name('MIORDEN'); 
	session_register('ID_USUARIO2');
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = "newsadmin.php" ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}
require("admin/NewsSql.inc.php");
$db = new NewsSQL($DBName);
//include("./usercheck.php");
$PicturePath = "photo/";
$result = $db->getnewsbyid($newsid);
$catalogid = $result[0]["catalogid"];
$title = $result[0]["title"];
$content = $result[0]["content"];
$viewnum = $result[0]["viewnum"];
$rating = $result[0]["rating"];
$picture = $result[0]["picture"];
$ratenum = $result[0]["ratenum"];
$source = $result[0]["source"];
$sourceurl = $result[0]["sourceurl"];
$isdisplay = $result[0]["isdisplay"];
?>
<html >
<head>
<title>Tipos de Usuarios</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body>
<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>
<form action="newsadmin.php" method="POST" ENCTYPE="multipart/form-data">
<input type="hidden" name="newsid" value="<?php print "$newsid"; ?>">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr> 
    <td align="center" valign="top"> 

      <hr width="90%" size="1" noshade>
      <table width="90%" border="0" cellspacing="0" cellpadding="4" height="300">
        <tr> 
          <td align="center"> 
            <table width="400" border="0" cellspacing="1" cellpadding="4" bgcolor="#F2F2F2">
              <tr bgcolor="#FFFFFF"> 
                <td width="183"><?php print "$admin_title"; ?> :</td>
                <td width="198"><input type="text" name="title" value="<? print "$title"; ?>"></td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td><?php print "$admin_content"; ?> :</td>
                <td><textarea name="content" cols="30" rows="5"><?php print "$content"; ?></textarea></td>
              </tr>                
              <tr bgcolor="#FFFFFF"> 
                <td>
                <?php print "$admin_picture"; ?> :
                <?php
                if (!empty($picture)){
                ?>
                <br><input type="submit" name="DP1" value="<?php print "$admin_del"; ?>">
                <?php
                }
                ?>
                </td>
                <td>
                <?php
                if (!empty($picture)){
                ?>
                <img src="<?php print "$PicturePath$picture"; ?>"><br>
                <?php
                }
                ?>
                <input type="file" name="userfile">
                </td>
              </tr>
              <tr bgcolor="#FFFFFF"> 
                <td><?php print "$admin_source"; ?>  :</td>
                <td><input type="text" name="source" value="<?php print "$source"; ?>"></td>
              </tr> 
              <tr bgcolor="#FFFFFF"> 
                <td>Publicado :</td>
                <td>
                <select name="isdisplay">
                <?php
                switch($isdisplay){
                
                case "1":
                ?>
                <option value="1" selected><?php print "$admin_yes"; ?></option>
                <option value="0"><?php print "$admin_no"; ?></option>                
                <?php
                break;
                
                case "0":
                ?>
                <option value="1"><?php print "$admin_yes"; ?></option>
                <option value="0" selected><?php print "$admin_no"; ?></option>
                <?php
                break;                
                }
                ?>
                </select>
                </td>
              </tr>                      
            </table> 
            <p>
            <input type="submit" name="editnews" value="<?php print "$admin_ok"; ?>">             
            </p>                      
          </td>
        </tr>
      </table>
      
    </td>
</tr>
<tr>
    <td align="center" valign="top" height="40">&nbsp;</td>
  </tr>
</table>
</form>
 <?php  
		piecera($PRIVILEGIO);
?>
</body>
</html>