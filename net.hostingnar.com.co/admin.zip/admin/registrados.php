<?php
	session_name('MIORDEN'); 
	//session_register('ID_USUARIO2');
	session_start();
	$ID_USUARIO = $_SESSION['ID_USUARIO2'];
	include("ordenconfig.php");
	if(!isset($ID_USUARIO))
	{
		MESSAGE('-Error al iniciar sesion.');
		REDIRIGIR('login.php');
		 
	}
	$CONDICION=0;
	$url = $_SERVER["REQUEST_URI"] ;
	$VERIFICAR = mysql_query("SELECT t_privilegios.url,t_privilegios.id_privilegio FROM t_usuarios INNER JOIN t_tipos_usuarios ON t_usuarios.id_tipo_usuario = t_tipos_usuarios.id_tipo_usuario INNER JOIN t_tipos_usuarios_privilegios ON t_tipos_usuarios.id_tipo_usuario = t_tipos_usuarios_privilegios.id_tipo_usuario INNER JOIN t_privilegios ON t_tipos_usuarios_privilegios.id_privilegio = t_privilegios.id_privilegio WHERE t_usuarios.id_usuario = ".$ID_USUARIO." AND t_usuarios.estatus_usuario = '' ");
	
	for($i=0;$i<mysql_num_rows($VERIFICAR);$i++)
	{
		if(ereg(mysql_result($VERIFICAR,$i,"URL"), $url)) 
		{ 
			$CONDICION=1;
			$PRIVILEGIO=mysql_result($VERIFICAR,$i,"id_privilegio");
			
			
		}
		
	}
	if($CONDICION ==0)
	{
		MESSAGE("No tienes privilegios suficientes para acceder!");
		REDIRIGIR('login.php?XIAUEORPGDJD=WIUEHRIDKFL');
		
	}

			
	

?>

<?php
	cabecera($PRIVILEGIO,$ID_USUARIO);		
?>

<?
include("../config.php") ;
include("../functions/paginar.php");
$pagina2="usuarios2.php";
if($_GET[u]) {

$resp = mysql_query("select * from usuarios where id='$_GET[u]'") ;
$datos = mysql_fetch_array($resp) ;
$fecha = $datos[fecha] ;
$diassemana = array("Domingo","Lunes","Martes","Mi�rcoles","Jueves","Viernes","S�bado") ;
$mesesano = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre") ;
$diasemana = date(w,$fecha) ; $diames = date(j,$fecha) ; $mesano = date(n,$fecha) - 1 ; $ano = date(Y,$fecha) ;
$fecha = "$diassemana[$diasemana] $diames de $mesesano[$mesano] del $ano" ;
if($datos[web] != "http://") { $web = "<a href='$datos[web]' target='_black'>$datos[web]</a>" ; }
$sexonumero = $datos[sexo] ;
$sexotexto = array("Masculino","Femenino") ;

function edad($fecha_nac){
//Esta funcion toma una fecha de nacimiento 
//desde una base de datos mysql
//en formato aaaa/mm/dd y calcula la edad en n�meros enteros

$dia=date("j");
$mes=date("n") - 1;
$anno=date("Y");

//descomponer fecha de nacimiento
$dia_nac=substr($fecha_nac, 8, 2);
$mes_nac=substr($fecha_nac, 5, 2);
$anno_nac=substr($fecha_nac, 0, 4);


if($mes_nac>$mes){
$calc_edad= $anno-$anno_nac-1;
}else{
if($mes==$mes_nac AND $dia_nac>$dia){
$calc_edad= $anno-$anno_nac-1; 
}else{
$calc_edad= $anno-$anno_nac;
}
}
return $calc_edad;
}

$junto = "$datos[n_ano]/$datos[n_mes]/$datos[n_dia]";
$edad = edad($junto);



?>

<table width="99%"  border="0" align="center" cellpadding="5" cellspacing="1" class="tabla_titulo">
  <tr>
    <td><font face="verdana" size="2"><i><b>
      <?=$datos[nick]?>
    </b></i></font></span></td>
  </tr>
</table>
<table width="99%"  border="0" align="center" cellpadding="5" cellspacing="0">
  <tr>
    <td><b> <?=DESDE_EL?></b> <? echo $fecha ?> </td>
  </tr>
</table>

<table width=99% border=0 align="center" cellpadding=3 cellspacing=0>
  <tr valign="top"> <td width="25%" rowspan="11"><div align="center">
    <p><strong><?=$datos[nick]?></strong><br>
        <br>
        <?
if($datos[avatar] == "") {
$avatar = "" ;
}
else {
$avatar = "<img src=\"".$datos[avatar]."\">" ;
}
echo $avatar ;
?>
        <br>
        <br>
        <?=_PUNTOS?>:<b> <? echo $datos[puntos]; ?></b>
        <br>
        <?=_ULT_CON_?>: <b><br>
        <? echo date("d/m/Y h:i A",$datos[conectado]);
   ?></b></p>
    </div></td>
    <td width="9%"><b><?=_REG_NICK_?></b></td>
    <td width="67%"><? echo $datos[nick] ?></td>
  </tr>
  <? if($datos[mostrarm] == "si") { ?><tr>
    <td width="9%"><b><?=_REG_EMAIL_?></b></td>
    <td><font size="2"><? echo $datos[email] ?></font></td>
  </tr>
 <? if(!$datos[messenger]) { echo ""; } else { ?> <tr>
    <td><b>MSN:</b></td>
    <td><? echo $datos[messenger] ?></td>
  </tr><? } ?>
 <? if(!$datos[yahoo_messenger]) { echo ""; } else { ?>   <tr>
    <td><strong>Yahoo!:</strong></td>
    <td><? echo $datos[yahoo_messenger] ?></td>
  </tr><? } ?>
 <? if(!$datos[icq]) { echo ""; } else { ?>   <tr>
    <td><strong>ICQ:</strong></td>
    <td><? echo $datos[icq] ?></td>
  </tr><? } ?>
  <? } ?>
  <tr>
    <td><strong><?=_REG_NOMBRE_?></strong></td>
    <td width="67%"><? echo $datos[nombre] ?></td>
  </tr>
  <tr> 
    <td><b><?=_REG_PAIS_?></b></td>
    <td><? echo $datos[pais] ?></td>
  </tr>
  <tr> 
    <td><b><?=_EDAD_?>:</b></td>
    <td><?=$edad?></td>
  </tr>
  <tr> 
    <td><b><?=_REG_SEXO_?></b></td>
    <td><? echo $sexotexto[$sexonumero] ?></td>
  </tr>
  <tr> 
    <td><b><?=_DESCRIPCION_PRFL_?></b></td>
    <td><? echo $datos[descripcion] ?></td>
  </tr>
  <tr>
    <td><b><?=_WEB_PRFL_?></b></td>
    <td><? echo $web ?></td>
  </tr>

</table>
&nbsp;<a href="../<?=$pagina?>?<?=$get?>=registrados"> <br>
  &lt;&lt; <?=_RETURN_?></a></span>
<?
}
else {
$resp = mysql_query("select * from usuarios");
$usuarios = mysql_num_rows($resp) ;
mysql_free_result($resp) ;
if(!$_POST[ordenar] or !$_GET[ordenar]) { $ordenar = "id desc"; } 
if($_GET[letra]) { $ordenar_usuarios = "where nick like '%$_GET[letra]'" ; }
if($_GET[letra] == "todos") { $ordenar_usuarios = false ; }
$paginar = new paginar("select * from usuarios $ordenar_usuarios order by $ordenar") ;
# --> N�mero de resultados a mostrar
$paginar->mostrar("40") ;
$con = $paginar->procesar_codigo() ;
?>
<p><b><br><br>
Total de Cliente Registradas:</b><? echo $usuarios ?>

<table width=100% border=0 align="center" cellpadding=3 cellspacing=1>
<tr>
<td width=9% height="15" class="tabla_titulo"><strong>Cedula I.  </strong></td>
<td width=17% class="tabla_titulo"><strong>Nombre del Contacto</strong></td>
<td width=17% class="tabla_titulo"><div align="center"><strong>Telefono</strong></div></td>
<td width=16% class="tabla_titulo"><strong>Email</strong></td>
<td width=9% class="tabla_titulo"><strong>Fecha de Registro</strong></td>
</tr>
<?
while($datos = mysql_fetch_array($con)) {
$sexonumero = $datos[sexo] ;
$sexotexto = array("<img src=http://pics.miarroba.com/iconos/male.gif>","<img src=http://pics.miarroba.com/iconos/female.gif>") ;
?>
<tr>
<td class="tabla_contenido"><b><? echo $datos[nick] ?></B></td>
<td class="tabla_contenido"><b><? echo $datos[nombre] ?></B></td>
<td class="tabla_contenido"><center><? echo $datos[pais] ?></center></td>
<td class="tabla_contenido"><? echo $datos[email] ?> </td>
<td class="tabla_contenido"><? echo date("d/m/Y",$datos[fecha]); ?></td>
</tr>
<?
}

?>
</table>
<table width="99%"  border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><?$paginar->crear_paginas()?></td>
  </tr>
</table>
<?
} ?>
<?php  
		piecera($PRIVILEGIO);
?>