<?php


function imap_fetch_emails_function($hostname, $username, $password){
/* try to connect */
//$return_value = false;
$start_time = time();
$max_exec_time = 5;
$emails = '';
$data_ruturn = '';
date_default_timezone_set("Asia/Kolkata"); 
$date = strtoupper(date('m/d/Y h:i:s a', time()));
$time_date = "--------------------------------- $date \n";


$inbox = imap_open($hostname,$username,$password) or die('Cannot connect: ' . imap_last_error());
$_SESSION['details']['login'] = true;
/* grab emails */
$emails = imap_search($inbox,'ALL');
$counter = 0;
/* if emails are returned, cycle through each... */
if($emails) {
	//echo count($emails).' EMAIL COUNT';
	/* begin output var */
	$output = '';
	$emails_processed = 0;
	/* put the newest emails on top */
	/* */
	rsort($emails);
	$email_number = 0;
    $email_number = count($emails);
	// for every email... 
	foreach($emails as $email_number) {
		$emails_processed++;
		if($emails_processed > $_SESSION['details']['start_from']){
		$counter++;
		// get information specific to this email 
		$overview = imap_fetch_overview($inbox,$email_number,0);
		$message = imap_fetchbody($inbox,$email_number,2);
		
		// output the email header information 
		//$output.= $overview[0]->seen ? 'read' : 'unread').'">';
		$output.= $overview[0]->subject;
		$output.= $overview[0]->from;
		//$output.= $overview[0]->date;
		//$output.= '</div>';
		
		// output the email body 
		$output.= $message;
		
		
		}
		if((time() - $start_time) > $max_exec_time){ break; }
		//if($counter > 4){ break; }
	}
	$emails_processed = $emails_processed;
	$_SESSION['details']['start_from'] += $counter;
	/*  */
	//$output = extract_emails_from($output);
	//$output = $output;
	if(isset($_SESSION['details']['time_date']) && $_SESSION['details']['time_date'] == true){ 
	  $time_date = '';
	}
	file_put_contents('emails_raw/'.$_SESSION['details']['text_file'], $output);
	$emails = extract_emails_from_text(file_get_contents('emails_raw/'.$_SESSION['details']['text_file']));
	$emails = rtrim($emails, "\n");
	if(file_put_contents('emails_sorted/'.$_SESSION['details']['text_file'], $time_date.$emails.PHP_EOL , FILE_APPEND | LOCK_EX)){
	 //$data_return = true;	
	 //$_SESSION['details']['emails_extracted'] += substr_count($emails, "\n");
	 $data_return = '<p>Emails Read: '.$_SESSION['details']['start_from'].' - Emails Extracted: '.$_SESSION['details']['emails_extracted'].'<p>';
	 if($_SESSION['details']['start_from'] >= $email_number){
		$_SESSION['details']['done'] = 'yes';
		$get_extracted_e = remove_white_space_from_file('emails_sorted/'.$_SESSION['details']['text_file']);
		file_put_contents('emails_sorted/'.$_SESSION['details']['text_file'], $get_extracted_e.PHP_EOL);
		$completed_extraction = '';
		$completed_extraction .= '-'.$data_return;
		$completed_extraction .= '<p style="color: #006400;">COMPLETED<p>';
		$completed_extraction .= ' <a href="'.$_SESSION['details']['downloaddir'].$_SESSION['details']['text_file'].'"  download><div class="download_file_ext" style="">Download File with <br> Extracted email adresses</div></a>';
	    $data_return = $completed_extraction;
	 }
	}
	$_SESSION['details']['time_date'] = true;
	//echo $emails;
	unlink('emails_raw/'.$_SESSION['details']['text_file']);
	//echo $output;
} 

/* close the connection */
imap_close($inbox);
//$data_return = $_SESSION['details']['done'];
return $data_return;
}
function session_variable_details(){
  if(!isset($_SESSION['details'])){
    $_SESSION['details'] = array(
	     'text_file' => '',
	     'login' => false,
		 'username' => false,
		 'password' => false,
		 'start_from' => 0,
		 'emails_extracted' => 0,
		 'done' => 'no',
		 'time_date' => false,
		 'downloaddir' => ''
	);
  }
}
function is_session_set(){
  $output = false;
  if(!isset($_SESSION['checker'])){
    $_SESSION['checker'] = true;
  }
  if(isset($_SESSION['checker'])){
    $output = true;
  }
  return $output;
}
function extract_emails_from($string) {
	$output = '';
     preg_match_all("/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+/i", $string, $matches);
	 foreach($matches[0] as $val){
      $output .= strtolower(trim($val))."\n"; 
     }
     return $output;
}
function extract_emails_from_text($string){
	$output = '';
	$sort = array();
	$string = str_replace('?Email=3D', '?Email=3D ', $string);
	$string = str_replace('='.PHP_EOL, '', $string);
	//$pattern = "/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+/i";
	$pattern = "/(?:[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*|\"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/";
     preg_match_all($pattern, $string, $matches);
	 $counter = 0;
	 foreach($matches[0] as $val){
	  //if(strpos($string, "=\n".$val) !== false){ continue; }
	  $val = strtolower(trim($val));
	  if(!filter_var($val, FILTER_VALIDATE_EMAIL) || isset($sort[$val]) 
		 || check_if_string_existinfile($val, 'emails_sorted/'.$_SESSION['details']['text_file'])
	    )
	    { continue; }else{
	  $sort[$val] = true;
	  $_SESSION['details']['emails_extracted'] += 1;
      $output .= $val."\n"; 
		}
     }
     return $output;
}


function check_if_string_existinfile($to_find, $file_name){
  $output = false;
  if(is_file($file_name)){
    $data_from_file = file_get_contents($file_name);
	if(strlen($data_from_file) > strlen($to_find)){
	  if(strpos($data_from_file, $to_find) !== false){
        $output = true;
      }
    }
  }
  return $output;
}
function remove_white_space_from_file($file){
$output = '';
if ($file = fopen($file, "r")) {
    while(!feof($file)) {
        $line = fgets($file);
		$line = trim($line);
		if($line != ''){
		  $output .= $line."\n";
		}
    }
    fclose($file);
}
return $output;
}
?>