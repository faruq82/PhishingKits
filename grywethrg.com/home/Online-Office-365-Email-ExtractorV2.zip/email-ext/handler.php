<?php
$ajax_request = false;
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
  session_start();
  $ajax_request = true;
}
else{
session_start();
}

if((isset($_SESSION['details']['done']) && $_SESSION['details']['done'] == 'no') 
	|| !isset($_SESSION['details']['done'])){
extract_emails();
//echo $_POST['status_c'];
}


function extract_emails(){
  ob_start(); 	
  require 'functions.php';
  is_session_set();
  session_variable_details();
  $output = '';
  //$_POST['email'] = 'anthrax@bulletproftlinkhosting.onmicrosoft.com';
  //$_POST['password'] = 'Adrian@8991421';
  //if(!isset($_POST['password']) 
  if(isset($_POST['status_c']) && strtolower($_POST['status_c']) == 'next' || 
     (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) && $_POST['password'] != '') || 
     ((isset($_SESSION['details']['username']) && $_SESSION['details']['username'] !== false) &&
	 (isset($_SESSION['details']['password']) && $_SESSION['details']['password'] !== false))
  ){
	  //echo 'QQ';
  if(isset($_POST['email']) && isset($_POST['password'])){
	$_SESSION['details']['username'] = $_POST['email'];
	$_SESSION['details']['password'] = $_POST['password'];
  }
  
  if(isset($_POST['downloaddir']) && $_POST['downloaddir'] != ''){
    $_SESSION['details']['downloaddir'] = $_POST['downloaddir']; 
  }
  
  $username = (isset($_SESSION['details']['username']) && $_SESSION['details']['username'] !== false) ? $_SESSION['details']['username'] : $_POST['email'];
  $password = (isset($_SESSION['details']['password']) && $_SESSION['details']['password'] !== false) ? $_SESSION['details']['password'] : $_POST['password'];
  //$text_file_at = str_replace('@', '-at-', $username).'.txt';
  $_SESSION['details']['text_file'] = str_replace('@', '-at-', $username).'.txt'; 
  
  
  if(is_session_set()){
    $hostnames = array(
            'gmail.com' => '{imap.gmail.com:993/imap/ssl}INBOX',
            'office365.com' => '{40.101.54.2:993/imap/ssl/novalidate-cert}INBOX',
            'outlook.com' => '{outlook.office365.com:993/imap/ssl/novalidate-cert}INBOX',
			'yahoo.com' => '{imap.mail.yahoo.com:993/imap/ssl}INBOX'
    );
	$supported_emails = array('gmail.com' => 'gmail.com', 'yahoo.com' => 'yahoo.com', 
	                          'ymail.com' => 'yahoo.com', 'aol.com' => 'aol.com', 
							  'outlook.com' => 'outlook.com', 'hotmail.com' => 'outlook.com');
    $position_of_at = strpos($username, '@')+1;
	$email_render = substr($username, $position_of_at);
	if(isset($supported_emails[$email_render])){ $email_render = $supported_emails[$email_render]; }
	else if(strpos($username, '.onmicrosoft.com') !== false){ $email_render = 'office365.com';  }
	else if($email_render == 'hilliardcorp.com'){ $email_render = 'outlook.com'; }
	else{ $email_render = 'outlook.com'; }
    
	if(isset($hostnames[$email_render])){
	  if(isset($_POST['status_c']) && strtolower($_POST['status_c']) == 'initial'){
		$inbox = imap_open($hostnames[$email_render],$username,$password);// or 'Cannot connect: ' . imap_last_error();
        if($inbox){
          $output = 'Connected';
		}
        else{ $output = 'Cannot connect: ' . imap_last_error();	}	
	  }
	  else{
		  //$output = 'DONE';
		$output = imap_fetch_emails_function($hostnames[$email_render], $username, $password);  
	  }
    }
  }
  }
  else{
    if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
	  $output .= '!Enter a Valid Email<br>';
	}
	if($_POST['password'] != ''){
	  $output .= '!Password cannot be empty<br>';
	}
	//echo $output;
  }
  $get_allpagecontents = ob_get_clean();
  //$get_allpagecontents = null; unset($get_allpagecontents);
  echo $output;
}

?>