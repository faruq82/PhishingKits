<?php

if(!isset($_SESSION['checker'])){
session_start();
session_destroy();   
session_unset();
}

session_start();
require 'index.html';
//$start_time = time();
//echo $start_time;
function get_download_dir(){
 $output = false;
 $uri = $_SERVER['REQUEST_URI'];	
 $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
 $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
 $output = substr($url, 0, strrpos($url, '/')+1) . 'emails_sorted/';
 return $output;
}
?>