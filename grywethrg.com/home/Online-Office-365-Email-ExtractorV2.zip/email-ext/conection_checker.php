<?php
//echo  $output = 'Conected';
connection_checker();
function connection_checker(){
$output = '';
$ajax_request = false;
if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
  session_start();
  $ajax_request = true;
}
else{
session_start();
}
  require 'functions.php';
  is_session_set();
  //session_variable_details();
  if(isset($_SESSION['details']['login']) && $_SESSION['details']['login'] == true){
	 $output = 'Conected';
	}
  
  echo $output;
}


?>