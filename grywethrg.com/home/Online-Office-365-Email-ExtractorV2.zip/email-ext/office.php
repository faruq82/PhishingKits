<?php

/* connect to gmail */
//$hostname = '{40.101.54.2:993/imap/ssl/novalidate-cert}INBOX';
$hostname = '{imap.gmail.com:993/imap/ssl}INBOX';
//$hostname = '{mail.hilliardcorp.:993/imap/ssl}INBOX';
//$hostname = '{outlook.office365.com:993/imap/ssl/novalidate-cert}INBOX';
//$hostname = '{imap.aol.com:993/imap/ssl}INBOX';

//$username = 'anthrax@bulletproftlinkhosting.onmicrosoft.com';
$username = 'evansmwakio@gmail.com';
//$username = 'smalandra@hilliardcorp.com';
//$username = 'evansonmwakio@hotmail.com';
//$username = 'evansonmwakio@aol.com';
//$password = 'Adrian@8991421';
//$password = 'hpDah55';$password = 'chucho4177';//$password = '';





//$emails = '';
$output = imap_fetch_emails_function($hostname, $username, $password);

//echo $output;

function imap_fetch_emails_function($hostname, $username, $password){
/* try to connect */
//$return_value = false;
$start_time = time();
$max_exec_time = 4;
$emails = '';
date_default_timezone_set("Asia/Kolkata"); 
$date = strtoupper(date('m/d/Y h:i:s a', time()));
$time_date = "--------------------------------- $date \n";
$output = '';

$inbox = imap_open($hostname,$username,$password) or die('Cannot connect: ' . imap_last_error());

/* grab emails */
$emails = imap_search($inbox,'ALL');
$counter = 0;
/* if emails are returned, cycle through each... */
if($emails) {
	echo count($emails).' EMAIL COUNT <br>';
	/* begin output var */
	
	
	/* put the newest emails on top */
	/* */
	rsort($emails);
	
	// for every email... 
	foreach($emails as $email_number) {
		
		// get information specific to this email 
		$overview = imap_fetch_overview($inbox,$email_number,0);
		$message = imap_fetchbody($inbox,$email_number,2);
		
		// output the email header information 
		//$output.= $overview[0]->seen ? 'read' : 'unread').'">';
		$output.= $overview[0]->subject;
		$output.= $overview[0]->from;
		//$output.= $overview[0]->date;
		//$output.= '</div>';
		
		// output the email body 
		$output.= $message;
		
		$counter++;
		if((time() - $start_time) > $max_exec_time){ break; }
		//if($counter > 4){ break; }
	}
	/*  */
	//$output = extract_emails_from($output);
	//$output = $output;
	
	file_put_contents('emails_raw/office.txt', $output);
	$emails = extract_emails_from_text(file_get_contents('emails_raw/office.txt'));
	file_put_contents('emails_sorted/emails.txt', $time_date.$emails.PHP_EOL , FILE_APPEND | LOCK_EX);
	echo $emails."<br>Emails COUNTED - $counter";
} 

/* close the connection */
imap_close($inbox);

return $emails;
}
function extract_emails_from($string) {
	$output = '';
	$sort = array();
     preg_match_all("/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+/i", $string, $matches);
	 foreach($matches[0] as $val){
	  $val = strtolower(trim($val));
	  if(!filter_var($string, FILTER_VALIDATE_EMAIL) || isset($sort[$val])){ continue; }
	  $sort[$val] = true;
      $output .= $val."\n"; 
     }
     return $output;
}
function extract_emails_from_text($string){
	$output = '';
	$sort = array();
	$string = str_replace('?Email=3D', '?Email=3D ', $string);
	$string = str_replace('='.PHP_EOL, '', $string);
	//$pattern = "/[\._a-zA-Z0-9-]+@[\._a-zA-Z0-9-]+/i";
	$pattern = "/(?:[a-z0-9!#$%&'*+=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+=?^_`{|}~-]+)*|\"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/";
     preg_match_all($pattern, $string, $matches);
	 foreach($matches[0] as $val){
	  //if(strpos($string, "=\n".$val) !== false){ continue; }
	  $val = strtolower(trim($val));
	  if(!filter_var($val, FILTER_VALIDATE_EMAIL) || isset($sort[$val]) ){ continue; }
	  $sort[$val] = true;
      $output .= $val."\n"; 
     }
     return $output;
}
?>