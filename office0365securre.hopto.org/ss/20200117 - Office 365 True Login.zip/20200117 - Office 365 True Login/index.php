<?php

$ea = $_GET['ea'];
$ip = getenv("REMOTE_ADDR");
header("Location: auth/");
?>
