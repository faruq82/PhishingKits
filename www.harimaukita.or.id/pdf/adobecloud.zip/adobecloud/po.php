
<html>

<head>

<link rel="SHORTCUT ICON" href="files/favicon.ico"/>

<title>Document</title>
<META http-equiv="refresh" content="2; url=error.php">
</head>

<body>


	<img src="files/pic.jpg" width="350" height="450">


</body>
</html>