<?php

$to ="info.shimalayastartradingco@yandex.com,donshaffy1@yandex.ru,donshaffy2@gmail.com";

?>