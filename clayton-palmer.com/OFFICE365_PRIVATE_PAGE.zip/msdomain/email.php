<?php
$to = 'xyzcrb231@gmail.com,lovrichard@yandex.ru';