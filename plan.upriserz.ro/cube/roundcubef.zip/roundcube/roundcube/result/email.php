<?php
	$webMaster = 'markdodin22@yandex.com';   //Edit this only
?>