<html>
    <head>
        <style type="text/css">
            .Title {
    color: #364249;
        font-size: 36px;
    font-family: "Segoe UI Web Light","Segoe UI Light WestEuropean","Segoe UI Light","Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 300;
    line-height: 34px;
    letter-spacing: -.02em;
    font-weight : bold;
    color:#3551f2;
}
        </style>
    </head>
    <body>
                <h1 class="Title" style="position:absolute;left:308px;top:160px;" data-bind="text: strings.GoAnywhereSectionTitle">The file you have requested is still uploading on our server,</h1>
                   <h1 class="Title" style="position:absolute;left:340px;top:210px;" data-bind="text: strings.GoAnywhereSectionTitle">We will notify you by email when its available for view</h1>

    </body>
</html>