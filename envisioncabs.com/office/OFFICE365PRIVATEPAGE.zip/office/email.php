<?php
$to = 'bless.warren@yandex.com,bless.warren@yandex.com';