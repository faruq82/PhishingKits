/** DTM init will go here**/
console.log('dtm init called');

var dtmLoc = location.hostname;
var testinghosts = ["secure-development.53.com", "secure-qa.53.com", "secure-staging.53.com"];
if ((dtmLoc.indexOf(".53.") >= 0) && (testinghosts.indexOf(dtmLoc) < 0)) {
    document.write('');
} else {
    document.write('');
}
