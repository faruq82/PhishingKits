var dtmLoc = location.hostname; 
var testinghosts = ["secure-development.53.com"
                   ,"secure-qa.53.com"
                   ,"secure-staging.53.com"
                  ];



//stage Akamai, prod CMS
if((dtmLoc.indexOf(".53.") >= 0) && (testinghosts.indexOf(dtmLoc) < 0)){
  document.write('<script src="//www.53.com/content/dam/fifth-third/dtm/www/e251f8161031ba53e6aefc36918d7e8f02c5e526/satelliteLib-0bf6a6472452184702edffb1fed34b2831ac0b7a.js"></script>');
  console.log('PROD DTM');
} else {
  document.write('<script src="//assets.adobedtm.com/e251f8161031ba53e6aefc36918d7e8f02c5e526/satelliteLib-0bf6a6472452184702edffb1fed34b2831ac0b7a-staging.js"></script>');
  console.log('STAGE Akamai DTM');
}


// // INCLUDE LOGIN SCRIPT TO DOM
 //$.getScript( "/apps/ib/rib/logon/remoteLogon.js", function(){
 //});

