_satellite.pushAsyncScript(function(event, target, $variables){
  if(digitalData.page.pageInfo.pageName ==  "/accounts"){
  (function(){
   var t = document.createElement('img');
   var cb = Math.random() * 10000000000000;
   t.src = "https://20725374p.rfihub.com/ca.html?rb=23544&ca=20725374&ra="+cb+"&_o=63307519&_t=rlsa&redirect=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/983180037/?guid=ON&amp;script=0&url=https://www.xplusonermktg.net/audiences/~poe_encoded.64222717.nodes.%2C~";
   t.async = 'true';
   var s = document.getElementsByTagName('script')[0];
   s.parentNode.insertBefore(t, s); 
  })();
}

});
