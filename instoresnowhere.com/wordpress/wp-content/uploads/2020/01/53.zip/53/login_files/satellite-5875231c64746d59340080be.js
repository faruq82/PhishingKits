_satellite.pushAsyncScript(function(event, target, $variables){
  (function(){
  var cb = Math.random() * 10000000000000;
  var img = document.createElement('img');
  img.src ="https://ad.doubleclick.net/ddm/activity/src=6268884;type=invmedia;cat=rjchuzqn;dc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=" + cb + "?";
  img.async = 'true';
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(img, s); 
})();
});
