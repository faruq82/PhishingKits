/**
 * Created by t66259a on 7/20/15.
 */
;(function (name, context, factory) {

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = factory();
    }
    else if (typeof define === 'function' && define.amd) {
        define(function() {
            return (context[name] = factory());
        });
    }
    else {
        context[name] = factory();
    }
}('Environment', this, function () {
    var Environment = function () {
    };
    if(this.Environment){
        //Check to see if the function is already on the context (this), if so, extend it.
      Environment = this.Environment;
    }

    var IB_URL_PREFIX = "https://www.53.com/content/fifth-third/en";
    var IB_ALIAS_URL_PREFIX = "https://www.53.com";

    Environment.ABOUT_LINK = IB_ALIAS_URL_PREFIX + "/ftb-about";
    Environment.CUSTOMER_SERVICE_LINK = IB_ALIAS_URL_PREFIX + "/ftb-service";
    Environment.CAREERS_LINK = IB_ALIAS_URL_PREFIX + "/ftb-careers";
    Environment.JOBSEEKERS_TOOLKIT_LINK = IB_ALIAS_URL_PREFIX + "/ftb-jobseeker";
    Environment.MEDIA_CENTER_LINK = IB_ALIAS_URL_PREFIX + "/ftb-media";
    Environment.PRIVACY_LINK = IB_ALIAS_URL_PREFIX + "/ftb-security";
     Environment.FAQ = IB_URL_PREFIX + "/site/personal-banking/account-management-services/faq.html";
    Environment.MOBILE_BANKING_LINK = IB_URL_PREFIX + "/personal-banking/bank/banking-on-the-go.html";

    Environment.OPEN_ACCOUNT_LINK = IB_ALIAS_URL_PREFIX;
    Environment.LENDEASY_LOAN_CALC_LINK = IB_ALIAS_URL_PREFIX + "/ftb-ob-loan-lendeasy-calc";

    Environment.OVERDRAFT_DEMO = IB_ALIAS_URL_PREFIX + "/ftb-overdraft-solutions";
    Environment.OVERDRAFT_DISCLOSURE = IB_ALIAS_URL_PREFIX + "/ftb-ob-od-legal";

    var APP_URL_PREFIX = "https://apps.53.com";

    Environment.BAL_LINK = IB_ALIAS_URL_PREFIX + "/ftb-locations";

    Environment.HARLAND_CHECK_ORDER_LINK = "http://www.ordermychecks.com";

    Environment.LOGOUT_URL = IB_ALIAS_URL_PREFIX + "/logout.html";
    Environment.LOGIN_URL = IB_ALIAS_URL_PREFIX + "/ftb-login";
    Environment.LOGOUT_URL_PB = IB_ALIAS_URL_PREFIX + "/wealth-management/";

    Environment.MIRADOR_MY_TEAM = "https://www.miradorfamilywealth.com/family-wealth-advisors.html";

    Environment.IAS_LINK = "https://timetrade.com/app/fifththirdbank/workflows/53PAL/schedule";

    return Environment;
}));