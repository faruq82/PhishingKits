_satellite.pushAsyncScript(function(event, target, $variables){
  (function() {
 var w = window, d = document;
 var s = d.createElement('script');
 var ecif = _satellite.getVar('ecifid');
 s.setAttribute('async', 'true');
 s.setAttribute('type', 'text/javascript');
 s.setAttribute('src', '//c1.rfihub.net/js/tc.min.js');
 var f = d.getElementsByTagName('script')[0];
 f.parentNode.insertBefore(s, f);
 if (typeof w['_rfi'] !== 'function') {
   w['_rfi']=function() {
   w['_rfi'].commands = w['_rfi'].commands || [];
   w['_rfi'].commands.push(arguments);
  };
 }
 _rfi('setArgs', 'ver', '9');
 _rfi('setArgs', 'rb', '23544');
 _rfi('setArgs', 'ca', '20697839');
 _rfi('setArgs', '_o', '63307519');
 _rfi('setArgs', '_t', 'gintbnk');
 _rfi('setArgs', 'ssv_ecif', ecif);
 _rfi('track');
})();
});
