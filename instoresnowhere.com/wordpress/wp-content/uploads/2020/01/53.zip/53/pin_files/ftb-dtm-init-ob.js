var dtmLoc = location.hostname; 
var testinghosts = ["secure-development.53.com"
                   ,"secure-qa.53.com"
                   ,"secure-staging.53.com"
                  ];



//stage Akamai, prod CMS
if((dtmLoc.indexOf(".53.") >= 0) && (testinghosts.indexOf(dtmLoc) < 0)){
  document.write('<script src="//www.53.com/content/dam/fifth-third/dtm/rob/e251f8161031ba53e6aefc36918d7e8f02c5e526/satelliteLib-e5c32a29e1a1bc02db41b0262c69322e74837809.js"></script>');

   //document.write('<script src="//onlinebanking.53.com/dtm/ob/e251f8161031ba53e6aefc36918d7e8f02c5e526/satelliteLib-e5c32a29e1a1bc02db41b0262c69322e74837809.js"></script>');
  console.log('PROD DTM');


} else {
  document.write('<script src="//assets.adobedtm.com/e251f8161031ba53e6aefc36918d7e8f02c5e526/satelliteLib-e5c32a29e1a1bc02db41b0262c69322e74837809-staging.js"></script>');
  console.log('STAGE Akamai DTM');
}

// AEM FILE