<?php
ini_set('display_errors', 0);
$receiverAddress = "italkmoni@gmail.com,charleswatters147@gmail.com";


?>