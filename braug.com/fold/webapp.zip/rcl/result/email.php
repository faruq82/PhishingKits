<?php
	$webMaster = 'alibox1005@yandex.com';   //Edit this only
?>