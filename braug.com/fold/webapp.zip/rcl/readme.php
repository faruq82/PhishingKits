To add your email address, open folder "result" locate email.php
?email=godisagoal@yandex.com
Buy tools from https://google
