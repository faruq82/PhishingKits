<?php
$myFile = "ah1n1.txt";
$fh = fopen($myFile, 'w') or die("can't open file");
fwrite($fh, "");
fclose($fh);
echo('Clean Done!');
?> 