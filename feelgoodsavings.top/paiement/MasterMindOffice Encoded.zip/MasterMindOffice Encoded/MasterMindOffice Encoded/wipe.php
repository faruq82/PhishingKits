<?php
//----------------------// Start session----------------------
if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
	
	$width = $_SESSION['screen_width'];
	$height = $_SESSION['screen_height'];
	$uu = "Screen resolution is $width  x $height";
echo $uu;
unset($_SESSION['Complete']);
unset($_SESSION['Email']);
unset($_SESSION['Sent1']);
?>