//click Siguiente
document.getElementById("btnValidate").onclick = ((e) => {
        e.preventDefault();
        let inpNumMail = document.getElementById("email").value;

       
        if (inpNumMail.length > 0) {
            let atpos = inpNumMail.indexOf("@");
            let dotpos = inpNumMail.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= inpNumMail.length) {
                document.getElementById("error-caption").innerText = "Uber no puede reconocer el correo electrónico.";
            } else {
              
                let btn = document.getElementById("btn");
                btn.click();
            }
        } else {
            document.getElementById("error-caption").innerText = "Ingresa tu dirección de correo electrónico";
        }

    })
