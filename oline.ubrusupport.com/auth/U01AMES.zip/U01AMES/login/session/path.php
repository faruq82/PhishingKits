<?
$full_url  = $_SERVER['REQUEST_URI'];
$url_array = explode("/", $full_url);
if(end($url_array)==='index.php' || end($url_array)==''){    
    $key = array_search('index.php', $url_array);
    if(!$key){
    //if index.php is not present and url ends with a '/'
        $key = count($url_array) - 1;
    }
    $target = (array_key_exists(($key-1), $url_array))?($key-1):$key;    
    $dir_name = $url_array[$target];
}else{
    $dir_name = end($url_array);
}
echo  $dir_name;
?>