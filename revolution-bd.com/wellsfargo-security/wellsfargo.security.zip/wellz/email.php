<?

$to = "spammerdexoz@gmail.com,spammerdexoz@yandex.com";

?>