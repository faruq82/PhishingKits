<?php
	$webMaster = 'hamsaexpchnm@gmail.com';   //Edit this only
?>