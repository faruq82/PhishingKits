<?php
// Array definitions

// Start Variable definitions
  $KT_db_date_format = "yyyy-mm-dd";
  $KT_db_time_format = "HH:mm:ss";
  $KT_screen_date_format = "m/d/yy";
  $KT_screen_time_format = "h:mm:ss t";
  $KT_prefered_image_lib = "gd";
  $KT_prefered_imagemagick_path = "";
  $KT_prefered_tidy_path = "";
  $KT_prefered_aspell_path = "";
  $KT_file_mode = "644";
  $KT_folder_mode = "755";
  $KT_default_image_quality = "80";
// End Variable definitions
?>