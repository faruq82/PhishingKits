<?php
/*
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2007 Adobe Systems Incorporated
 * All Rights Reserved
 * 
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the 
 * terms of the Adobe license agreement accompanying it. If you have received this file from a 
 * source other than Adobe, then your use, modification, or distribution of it requires the prior 
 * written permission of Adobe.
 */

$res = array(
'SQL_ERROR' => '<strong>Error creating Dynamic Include:</strong><br/>%s<br/><strong>SQL:</strong><br/>%s<br/>',
'MISSING_FIELD' => '<strong>Error creating Dynamic Include:</strong><br/>The field \'%s\' is not in the recordset.<br/>',
'PHP_CHDIR_FAILED' => '<strong>Error including file:</strong><br/>Could not change directory to \'%s\'. Set execute permissions on this folder.<br/>',
);
?>