(function($){
  $(document).ready(function() {
	
	// Redirect if not the top level window
	
	//box sync needs a frame
	var needsframe = navigator.userAgent.indexOf('Box Sync') != -1	
  
	if(self !== top && !needsframe) { window.top.location.href = window.location.href; }

    //add placeholder text into inputs for older browsers;

    if(!Modernizr.input.placeholder){
      $("input").each(function(){
        if($(this).val()=="" && $(this).attr("placeholder")!=""){
          $(this).val($(this).attr("placeholder"));  
          
          $(this).css('color', '#aaa');
          
          $(this).keydown(function(){
            if($(this).val()==$(this).attr("placeholder")) {
              $(this).val("");
              $(this).css('color', 'black');
            }
            
          });
          
          
          
          
          $(this).blur(function(){
            if($(this).val()=="") $(this).val($(this).attr("placeholder"));
          });
        }
      });
    }
    
    $('#netid_text').focus();
    
    $('.input_wrapper > input').each(function(index, el){
      $(el).focus(function(evt){
        $(evt.currentTarget).parent().addClass('active');
      });
      
      $(el).blur(function(evt){
        $(evt.currentTarget).parent().removeClass('active');
      })
      
    });
    
    
    
    $("#query").submit(function(evt){
      if(!$('#netid_text').val() || $('#netid_text').val() == $('#netid_text').attr('placeholder')){
        $('#netid_text').parent().addClass('animated shake');
          window.setTimeout(function(){
          $('#netid_text').parent().removeClass('shake');  
        }, 500);
        
        $('#netid_text').focus();
        return false;
      }
      
      if(!$('#password_text').val() || $('#password_text').val() == $('#password_text').attr('placeholder')){
        
        $('#password_text').parent().addClass('animated shake');
          window.setTimeout(function(){
          $('#password_text').parent().removeClass('shake');  
        }, 500);
        
        $('#password_text').focus();
        return false;
      }
    
    });
    
  });
})(jQuery)