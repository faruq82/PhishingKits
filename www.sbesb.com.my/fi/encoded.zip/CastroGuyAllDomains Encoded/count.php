<?php
           
           if(!isset($_SESSION['counter'])) { // It's the first visit in this session
             $handle = fopen("counter.txt", "r"); 
             if(!$handle){ 
             
               } 
              else { 
                $counter = ( int ) fread ($handle,20) ;
                fclose ($handle) ;
                $counter++ ; 
                
                $handle = fopen("counter.txt", "w" ) ; 
                fwrite($handle,$counter) ; 
                fclose ($handle) ;
                $_SESSION['counter'] = $counter;
                }

           } else { // It's not the first time, do not update the counter but show the total hits stored in session
             $counter = $_SESSION['counter'];
             
           }
?>