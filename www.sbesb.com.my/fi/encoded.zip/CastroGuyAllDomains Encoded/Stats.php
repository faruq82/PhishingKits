<?php
if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
require("count.php"); //Kick Out File		
echo" <p> Visitor Count: ". $counter . " </p> " ;

//--unset($_SESSION['counter']);
?>