<?

$to = "news@authorangeraallen.com, glemanski@yandex.ru";

?>