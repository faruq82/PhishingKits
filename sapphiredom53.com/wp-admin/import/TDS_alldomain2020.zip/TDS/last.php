<?php

$email = $_GET['email'];
$domain = explode('@', $email);
$end = count($domain) - 1;
$domain = $domain[$end];
header('Location: http://' . $domain);

?>