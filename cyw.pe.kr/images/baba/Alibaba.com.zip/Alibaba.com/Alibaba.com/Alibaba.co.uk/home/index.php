<html class="rwd rwd-l" idmmzcc-ext-docid="153683968"><head><script src="//cmap.alibaba.com/ml.html?callback=landing8978252&amp;cna=3bw9EfTyjFECASRKAo4n2aNT"></script>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge"><!-- ??IE8,7?????? -->
		<title>Alibaba&nbsp;Manufacturer&nbsp;Directory&nbsp;-&nbsp;Suppliers,&nbsp;Manufacturers,&nbsp;Exporters&nbsp;&amp;amp;&nbsp;Importers&nbsp;</title>
        <meta name="data-spm" content="a2700">
		<meta name="keywords" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers">
		<meta name="description" content="Alibaba Manufacturer Directory - Suppliers, Manufacturers, Exporters &amp; Importers">
		<link rel="icon" href="https://login.alibaba.com/favicon.ico" type="image/x-icon"/>

												
								
				
				
		
	
<link href="https://stylessl.aliunicorn.com/css/6v/??apollo/core/core-sc.css,apollo/core/rwd-sc.css,apollo/core/rwd-sc-ie8.css,apollo/mod/feedback/feedback-sc.css,run/common/switch-language/switch-language.css,apollo/mod/footer/footer-v4-sc.css,run/login/home/home-buyer.css,run/login/home/login-fix.css?t=15967a68e_1435ab11ae" rel="stylesheet" type="text/css" media="all">

<script type="text/javascript" src="https://stylessl.aliunicorn.com/js/6v/biz/login/home/??preload.js?t=630906a9_626294dd08"></script>




</head>
	<body data-spm="homelogin"><script id="beacon-aplus" src="https://u.alicdn.com/js/aplus_en.js" exparams="userid=&amp;aplus&amp;ali_beacon_id=36%2e73%2e231%2e75%2e1488974567562%2e630904%2e4&amp;ali_apache_id=36%2e73%2e231%2e75%2e1488974564603%2e407437%2e8&amp;ali_apache_track=%22%22&amp;ali_apache_tracktmp=&amp;dmtrack_c={}&amp;pageid=245175aa0ab9ea5b1489230663&amp;hn=enlogin010185234091%2eoc27&amp;asid=AQAAAABH28NYrHNCZwAAAAAjYkbDBfffDA=="></script>

		
				
		<header id="header" class="container">
			<div id="ali-logo" class="util-left">
				<a href="https://www.alibaba.com?spm=a2700.homelogin.0.0.2cj05Q" title="Manufacturers" data-spm-anchor-id="a2700.homelogin.0.0">Alibaba.com</a>
			</div>
			<div id="header-switch" class="util-left">
				<a id="overShowForTranslate" href="javascript:;">
					<span id="overshowTranslate" class="mn-cs" rel="en_US"> English </span>
					<i class="ml-hollow-arrow"><em></em><b></b></i>
				</a>
				<div id="overshowTranslateContent" style="display: none; z-index: 99; position: absolute; left: 0px; top: 14.3px;" data-widget-cid="widget-1">
					<div class="topHack"></div>
					<ul id="languagesContainer"><li><a data-role="item" href="javascript:void(0)" rel="zh_CN"> ?? </a></li><li><a data-role="item" href="javascript:void(0)" rel="zh_TW"> ?? </a></li><li><a data-role="item" href="javascript:void(0)" rel="es_ES"> Espa�ol </a></li><li><a data-role="item" href="javascript:void(0)" rel="pt_PT"> Portugu�s </a></li><li><a data-role="item" href="javascript:void(0)" rel="de_DE"> Deutsch </a></li><li><a data-role="item" href="javascript:void(0)" rel="fr_FR"> Fran�ais </a></li><li><a data-role="item" href="javascript:void(0)" rel="it_IT"> Italiano </a></li><li><a data-role="item" href="javascript:void(0)" rel="ru_RU"> P?????? </a></li><li><a data-role="item" href="javascript:void(0)" rel="ko_KR"> ??? </a></li><li><a data-role="item" href="javascript:void(0)" rel="ja_JP"> ??? </a></li><li><a data-role="item" href="javascript:void(0)" rel="ar_SA"> ????? ??????? </a></li><li><a data-role="item" href="javascript:void(0)" rel="tr_TR"> T�rk </a></li><li><a data-role="item" href="javascript:void(0)" rel="th_TH"> ??????? </a></li><li><a data-role="item" href="javascript:void(0)" rel="vi_VN"> ti?ng Vi?t </a></li><li><a data-role="item" href="javascript:void(0)" rel="nl_NL"> nederlands </a></li><li><a data-role="item" href="javascript:void(0)" rel="hi_IN">??????</a></li><li><a data-role="item" href="javascript:void(0)" rel="iw_HE">?????</a></li><li><a data-role="item" href="javascript:void(0)" rel="in_ID">bahasa Indonesia</a></li></ul>
					<div class="botHack"></div>
				</div>
			</div>
		</header>

		<hr>

		<div id="content" class="main container util-clearfix">
		
    <!-- tangram:1405 begin-->

<div id="screen-banner">
</div>

<div id="banner" data-spm="banner" class="col-m-36 hidden-s hidden-xs hidden-xxs" style="margin: 0;">
        <!-- tangram:645 begin-->




<div style="height:350px;width:585px;margin:0px auto;">
<a href="https://activity.alibaba.com/page/vote-for-new-Trade-Assurance-features.html?tracelog=login_votelp" target="_blank">
		<img src="https://img.alicdn.com/tps/TB1awf5PXXXXXXLXFXXXXXXXXXX-585-350.jpg">
</a>
</div>

<!-- tangram:645 end-->
</div>

<div id="action-container" class="util-clearfix">
    <div id="action-banner" class="util-clearfix" data-spm="actionbanner">
        <a href="https://activity.alibaba.com/page/MegaMarch-Sourcing-Consumer-Goods.html?tracelog=mega_dengluye" target="_blank">
            &nbsp;
        </a>
    </div>

    <div id="login-form-wrapper" data-spm="login" class="util-clearfix col-m-24 col-xs-60">
    	<div class="inner">
    		<div id="login-form">
    			<div id="standardlogin" class="xman-embed" data-widget-cid="widget-3"><div class="xman-content ui-tab" data-role="content" data-widget-cid="widget-5"><div class="xman-wrapper ui-tab">
	<ul class="ui-tab-nav" style="display: none;">
  
	<li class="ui-tab-trigger ui-tab-active">
		<a href="javascript:void(0);">Sign in to Alibaba.com</a>
	</li>

	</ul>

	<div class="ui-tab-body ui-tab-content">
	<div data-widget-cid="widget-4" class="ui-tab-pane ui-tab-panel"><style type="text/css">
  iframe#alibaba-login-box {
    display: block !important;
    visibility: visible !important;
  }
</style>


<div id="signin-server-feedback" class="ui-feedback ui-feedback-standalone" style="display: none;"></div>



  <div id="alibaba-login-iframe" class="iframe-show iframe-loaded">

  	

  	<div id="alibaba-login-iframe-loading"></div>

  <iframe id="alibaba-login-box" src="images/login.htm" scrolling="no" style="border: medium none; visibility: visible;" width="100%" height="250" frameborder="none"></iframe></div>

  <div id="join-link" class="ui-form-item util-clearfix">
       <a href="javascript:void(0)" data-mobile="true" id="login-mobile" class="mobile">
          <span class="mobile-login" data-role="mobile">
          
          Mobile number sign in
          
          </span>
          <span class="account-login" data-role="account">
          
          Email sign in
          
          </span>
        </a>
  	<a id="xman_join_btn" class="util-right" style="font-size:12px;" href="http://us.my.alibaba.com/user/join/join_step1.htm?return_url=http%3A%2F%2Fwww.alibaba.com" title="join in">
      Join Free
    </a>
  </div>
  
  

    <!-- ????????? - start -->
    <div id="xloginPartnerWrapper">
    	<div id="xloginPartner">
    		<span id="sign-with">Sign in with:</span>
        
        <!-- ???????? - start -->
    		<ul class="third-party-main">

          <!-- ?????????? -->
      		
      			<li>
              <a href="javascript:void(0);" alt="facebook" class="third-party-item facebook" data-url="https://www.facebook.com/dialog/oauth?client_id=124207444332529&amp;scope=email,user_work_history&amp;display=popup&amp;state=c4b8633b19c44be1aef2991f0440bb7c&amp;redirect_uri=https%3A%2F%2Flogin.alibaba.com%2Foauth_sign.htm%3FpartnerName%3Dfacebook" data-domdot="id:18210">
                facebook
              </a>
            </li>
      		
      			<li>
              <a href="javascript:void(0);" alt="linkedin" class="third-party-item linkedin" data-url="https://www.linkedin.com/uas/oauth2/authorization?response_type=code&amp;client_id=75ix33gpecih2n&amp;scope=r_basicprofile,r_emailaddress&amp;state=c4b8633b19c44be1aef2991f0440bb7c&amp;redirect_uri=https%3A%2F%2Flogin.alibaba.com%2Foauth_sign.htm%3FpartnerName%3Dlinkedin" data-domdot="id:18211">
                linkedin
              </a>
            </li>
      		

    		</ul>
        <!-- ???????? - end -->

    	</div>
    </div>
    <!-- ????????? - end -->

  


</div></div>
</div>
</div>
<div class="loading-box"></div></div>
    		</div>
    
    		    
    		    			    		    
    		    		<div id="advisory" class="util-clearfix">
    			    				<img src="images/TB1ROn8OpXXXXbZaXXXXXXXXXXX-32-31.png" style="vertical-align:middle; margin-right:5px;" height="25" border="0">Can't sign in? <a href="https://gcx.alibaba.com/icbu/anna/portal.htm?pageId=6090&amp;_param_digest_=b635ef82725207200efba8781431d7df" target="_blank">Get help here</a>
    			    		</div>
    		    	</div>
    </div>

</div>

<style type="text/css">
    #login-form {
        background-color:#fff;
    }
    
    body {
        margin:0px;
    }
    
    #content {
        padding:0px;
    }
    #screen-banner {
        position:absolute;
        top:101px;
        left:0px;
        width:100%;
        height:600px;
        background:url('https://img.alicdn.com/tps/TB1o1kePVXXXXbrXVXXXXXXXXXX-2200-600.jpg') center center no-repeat;
    }
    
    #banner {
        display: none;
    }
    
    #action-container {
        position:relative;
        max-width:1200px;
        min-height:600px;
    }
    
    #action-banner {
        float:left;
        width:60%;
        height: 600px;
    }
    
    #action-banner a {
        display:block;
        width:100%;
        height:100%;
        text-decoration:none;
    }
    
    
    #login-form-wrapper {
        float:left;
        margin-right:0px;
        margin-top: 40px;
        margin-bottom: 0px;
        padding-bottom: 0px;
    }
    
    #advisory {
        padding:10px 0px;
    }
    
    #ui-footer {
        position:relative;
        left:auto;
        bottom:auto;
    }
    
    
    @media (max-width: 1022px) {
        #screen-banner {
            display:none;
        }
        
        #login-form-wrapper {
            margin-top:60px;
        }
        
        #action-banner {
            display:none;
        }
        
    }
    
</style>
<!-- tangram:1405 end-->



		</div>
				<!--TMS:1281516-->
<style>
/* footer css */
</style>

<div class="skin-default" data-name="mm-sc-new-footer" data-skin="default" data-guid="1409634827621" id="guid-1409634827621" data-version="110" data-type="3"><div class="module" data-spm="a271py"><div class="mm-sc-new-footer">







	<link type="text/css" rel="stylesheet" href="images/footer.css">







<footer id="ui-footer" class="ui-footer ui-footer-wrapper">
	<hr>
	<div class="ui-footer-seo">
						<p class="ui-footer-seo-language">
			<i class="global-site"></i> Alibaba.com Site: <a href="http://www.alibaba.com/">International</a> - <a href="http://spanish.alibaba.com/">Espa�ol</a> - <a href="http://portuguese.alibaba.com/">Portugu�s</a> - <a href="http://german.alibaba.com/">Deutsch</a> - <a href="http://french.alibaba.com/">Fran�ais</a> - <a href="http://italian.alibaba.com/">Italiano</a> - <a href="http://hindi.alibaba.com/">?????</a> - <a href="http://russian.alibaba.com/">P??????</a> - <a href="http://korean.alibaba.com/">???</a> - <a href="http://japanese.alibaba.com/">???</a> - <a href="http://arabic.alibaba.com/">????? ???????</a> - <a href="http://thai.alibaba.com/">???????</a> - <a href="http://turkish.alibaba.com/">T�rk</a> - <a href="http://dutch.alibaba.com/">Nederlands</a> - <a href="http://vietnamese.alibaba.com/">ti?ng Vi?t</a> - <a href="http://indonesian.alibaba.com/">Indonesian</a> - <a href="http://hebrew.alibaba.com/">?????</a>		</p>
				
				<p class="ui-footer-seo-brand">
			<a rel="nofollow" href="http://www.alibabagroup.com/en/global/home">Alibaba Group</a>
			| <a rel="nofollow" target="_blank" href="https://www.taobao.com/">Taobao Marketplace</a>
			| <a rel="nofollow" target="_blank" href="https://www.tmall.com/">Tmall.com</a>
			| <a rel="nofollow" target="_blank" href="https://ju.taobao.com/">Juhuasuan</a>
			| <a rel="nofollow" target="_blank" href="http://www.aliexpress.com/">AliExpress</a>
			| <a rel="nofollow" target="_blank" href="https://www.alibaba.com/">Alibaba.com International</a>
			| <a rel="nofollow" target="_blank" href="http://www.1688.com/">1688.com</a>
			| <a rel="nofollow" target="_blank" href="http://www.alimama.com/">Alimama</a>
			| <a rel="nofollow" target="_blank" href="https://www.alitrip.com/">Alitrip</a>
			<br>
			<a rel="nofollow" target="_blank" href="http://www.aliyun.com/">Alibaba Cloud Computing</a>
			| <a rel="nofollow" target="_blank" href="http://www.yunos.com/">YunOS</a>
			| <a rel="nofollow" target="_blank" href="https://aliqin.tmall.com/">AliTelecom</a>
			| <a rel="nofollow" target="_blank" href="http://www.net.cn/">HiChina</a>
			| <a rel="nofollow" target="_blank" href="http://www.autonavi.com/">Autonavi</a>
			| <a rel="nofollow" target="_blank" href="http://www.uc.cn/">UCWeb</a>
			| <a rel="nofollow" target="_blank" href="http://www.umeng.com/">Umeng</a>
			| <a rel="nofollow" target="_blank" href="http://www.xiami.com/">Xiami</a>
			| <a rel="nofollow" target="_blank" href="http://www.ttpod.com/">TTPod</a>
			| <a rel="nofollow" target="_blank" href="https://www.laiwang.com/">Diandianchong</a>
			| <a rel="nofollow" target="_blank" href="http://www.dingtalk.com/?lwfrom=20150202135600390">DingTalk</a>
			| <a rel="nofollow" target="_blank" href="https://intl.alipay.com/index.htm">Alipay</a>
		</p>
		

		<p class="ui-footer-policy">
			<a href="http://rule.alibaba.com/rule/detail/2047.htm" rel="nofollow">Product Listing Policy</a>
			- <a href="http://rule.alibaba.com/rule/detail/2049.htm" rel="nofollow">Intellectual Property Policy and Infringement Claims</a>
			- <a href="http://rule.alibaba.com/rule/detail/2034.htm" rel="nofollow">Privacy Policy</a>
			- <a href="http://rule.alibaba.com/rule/detail/2041.htm" rel="nofollow">Terms of Use</a>
					</p>

		<p class="ui-footer-copyright">
			<a rel="nofollow" href="http://www.alibaba.com/trade/servlet/page/static/copyright_policy">�</a> 1999-2017 Alibaba.com. All rights reserved.		</p>
	</div>
</footer>

			
</div>

<div id="ServerId" style="color:whitesmoke;text-align:center;background:whitesmoke">  </div>

</div></div>

<script>
seajs.Module.define('mm-sc-new-footer', function(require, exports) {
	// ???????
	exports.init = function(box, module) {
		// code here
	};
});
</script>
<script>(function(f){var e,d,c;e=f.replace(/#/ig,"").split(",");for(var b=0,a=e.length;b<a;b++){d=document.getElementById(e[b]);c=d.getAttribute("data-name");seajs.use(c,function(g){g.init(d,c)})}})('#guid-1409634827621');</script>
						<!-- dragoon check -->



<div id="_umfp" style="display:block;position:absolute;top:-5000px;left:-5000px;width:1px;height:1px;overflow:hidden"><img src="images/clear.png"></div><div class="ui-autocomplete" data-widget-cid="widget-6" style="width: 308px; z-index: 99; display: none; position: absolute; left: -9999px; top: -9999px;">
    <ul class="ui-autocomplete-ctn" data-role="items">
        
    </ul>
</div></body></html>