$(document).ready(function(){
	//Supprimer les headers actifs
	$("#menu.header__nav").find("li").each( function(elmt){
		$(this).find("a").removeClass("active");
	});
	
	//repositionner le header actif
	var headerSelectionne = $("#menuSelectionne").val();
	$("#" + headerSelectionne).addClass("active");
	
	//Fonctions d'accessbilit� - menu cach� + focus sur la croix de fermeture du bandeau
	var effectuerFermeture = true;
	if(typeof cookieNameBandeau == 'undefined' || typeof cookieDomainBandeau == 'undefined' || typeof cookiePathBandeau == 'undefined'){
		effectuerFermeture = false;
		cookieNameBandeau = "";
		cookieDomainBandeau = "";
		cookiePathBandeau = "";
	}
	$("#bandeauInfosConnexion").on("click",appelFermetureBandeau(cookieNameBandeau,cookieDomainBandeau,cookiePathBandeau,effectuerFermeture));
	$("#accesMenuProfil").on("click",clicAccesMenuProfil);
	$("#accesFAQ").on("click",clicAccesFAQ);
	
	/**
	 * Code pour l'accessibilit�
	 * permettant lors du focus sur un lien du menu cach� de l'afficher
	 */
	var classeInvisibilite = $('#menuAccessibilite').attr('data-access-helper');  
	
	//Afficher le menu cach� quand on arrive dessus et focus le premier lien
	$("#menuAccessibilite a").on('focus', function(e){
		if( $('#menuAccessibilite').hasClass(classeInvisibilite)){
			$('#menuAccessibilite').removeClass(classeInvisibilite);
		}
	});
	//Remettre le menu cach� invisible
	$("#menuAccessibilite a").on('blur', function(e){
    	$('#menuAccessibilite').addClass(classeInvisibilite);
	});
    //Lors de l'appui sur Entr�e sur un menu cach�, envoie vers le menu correspondant
	$('#menuAccessibilite').on('keydown.access', 'a', function(e) {
		if (e.keyCode === 13) {
			var target = $(this).attr("href");
			if (target.indexOf('#') !== -1) {
				e.preventDefault();
				$(target).find('a:visible').first().focus();
			}
		}
	});
});

/**
 * Modification du cookie pour indiquer la fermeture du bandeau
 * @param nomCookie
 * @param domaineCookie
 * @param cheminCookie
 */
function appelFermetureBandeau(nomCookie, domaineCookie, cheminCookie, effectuerFermeture){
	return function() {
		if(effectuerFermeture){
			document.cookie = nomCookie + "=false;" + ";domain=" + domaineCookie + ";path=" + cheminCookie;
		}
	};
}

/**
 * Permet lors du clic sur ce lien d'aller directement sur le menu Mon Profil et de l'ouvrir
 */
function clicAccesMenuProfil(){
	$('.dropdown-trigger').click();
	$('.dropdown-trigger').focus();
}

/**
 * Permet lors du clic sur ce lien d'aller directement sur la FAQ
 */
function clicAccesFAQ(){
	$('.faq__link').click();
}
