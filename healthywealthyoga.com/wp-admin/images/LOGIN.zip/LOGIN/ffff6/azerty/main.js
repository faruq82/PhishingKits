/**
 * Common js
 * */
var Q4X = (function ($) {

    // Constructor
    function Q4x () {
        this.name = "Q4X";
        this.version = "V.0.3";
    }
    // Q4X functions
    Q4x.prototype = {
        init: function () {
            $(window).load(Q4X.load);
            Q4X.layout();
            Q4X.components();
        },
        load: function () {
            /**
             * Require page Load to access element full size
             * */

            // Collapse Grid equal height components
            var $collapseGrid = $('#collapse-grid');
            if($collapseGrid.length) {
                Q4X.equalHeight($('.collapse__toggle', $collapseGrid));
            }
            // Card components, equal height
            var $cardGroups = $('[data-type="card-group"]');
            if($cardGroups.length) {
                $cardGroups.each(function () {
                    var $cards = $(this).find('.card');
                    $cards.length ? Q4X.equalHeight($cards) : '';
                });
            }
        },
        layout: function () {
            /**
             * Override & extend functions
             * */
            // Add placeholder support on IE9
            $('input, textarea').placeholder();
            /**
             * All Layout javaScript functions
             * */
            // Instantiate bannerExpand plugin
            var $expandBanner = $('.expand-banner__trigger');
            if($expandBanner.length) {
                $expandBanner.bannerExpand();
            }
            // Instantiate faqSearch plugin
            var $faqSearch = $('.faq-search');
            if($faqSearch.length > 0) {
                $faqSearch.faqSearch();
            }
            // Collapse plugin @extend for profile use
            var focusout; // Store setTimeout // TODO optimization
            $('.profile.collapse').on('focusout', function (e) {
                var that = this,
                    $el = $(that).find('.collapse__toggle'),
                    plug = $el.data('plugin_collapse');

                focusout ? clearTimeout(focusout) : '';
                focusout = setTimeout(function (e) {
                    var active = document.activeElement;
                    if(!$(that).find(active).length && active) {
                        plug.collapseClose();
                        if(active.tagName === "BODY") {
                            $el.focus();
                        }
                    }}, 150)
            }).on('keydown', function (e) {
                var that = this;
                var key = e.which || e.keyCode;
                if(key === 27) {
                    var $el = $(that).find('.collapse__toggle'),
                        plug = $el.data('plugin_collapse');
                    if(plug.open) {
                        e.preventDefault();
                        e.stopPropagation();

                        plug.collapseClose();
                        $el.focus();
                    }
                }
            });
            
            $('.consultation-cpte .split div:first-child').on('focusout', function (e) {
                var that = this,
                    $el = $(that).find('.collapse__toggle');

                focusout ? clearTimeout(focusout) : '';
                focusout = setTimeout(function (e) {
                    var active = document.activeElement;
                    if(!$(that).find(active).length && active) {
                        if(active.tagName === "BODY") {
                            $el.focus();
                            $el.css("background","#FFF");
                        }
                    }}, 150)
            });
            //Q4X V2: ERELEVE - Dans les popin e-relev�, on donne le lien � la page principale
            $('.releve-nav').on('click', function (e) {
            	e.preventDefault();
            	if($(this).attr('href') != "#"){
            		parent.location.href=$(this).attr('href');
            	}
            	
            });

        },
        components: function () {
            /**
             * Instantiate all components plugins
             * */
            // Initialize Collapse plugin
            $('.collapse__toggle[data-toggle="collapse"]').collapse();

            // Initialize CollapseSibling plugin
            $('.collapse__toggle[data-toggle="collapse-sibling"]').collapseSibling();
            
            /* tiles
             ................................ */
            var tile = 0;
           
           $('.tile').each(function () {
                var tiles =  $(this).parent().width();
                width = tiles-40;
                tile++;
                
                width = width/3;   
                $(this).css("width",width)
                 
            });
            
             /* liste detail des operations */                                   
            $('.operations.collapse__nav').each(function () {
                //nombre de lignes ayant pour class "last" ou "line" ou "title"
                var nbLast =  $(this).find("li.last").length;
                var nbRow =  $(this).find("li.line").length;
                var nbTitle =  $(this).find("li.title").length;

                //variables hauteur fixe de chaque ligne correspondant aux class "last", "line" et "title"
                var heightL = nbLast * 30;
                var heightR = nbRow * 25;
                var heightT = nbTitle * 33;
                var fixHeightLast = 20;
                var heightList = heightL + heightR + heightT + fixHeightLast;
                $(this).parent().css("height",heightList+"px");
            });
            
            /* survol de l'icone affiche un tooltip supprime - valide par guillaume daillier comme code mort */

            $('.tabtip').on('keypress', function (event) {
                
                    var id = $(this).attr("data-target");
                    $(id).modal('show');
            })
          /*  Checkbox dans header collapse  */
            $('.btn-check').on('click', function (e) {
                if ( $(this).parents("div.collapse__header").hasClass("checked")  ) {
                    $(this).parents("div.collapse__header").removeClass("checked");
                    /*R�partition du changement dans le champs hidden pour r�percution*/
                    $("#"+$(this).attr("for")+"_position").val(false);
                    /*Si le bouton est s�lectionn�, on d�pli la famille (on test si la famille n'est pas d�j� d�pli�)*/
                    if($(this).parents("div.collapse__header").find("a.collapse__toggle").attr("aria-expanded")=="true"){
                    	$(this).parents("div.collapse__header").find("a.collapse__toggle").click();
                    }
                } else  {
                    $(this).parents("div.collapse__header").addClass("checked");
                    /*R�partition du changement dans le champs hidden pour r�percution*/
                    $("#"+$(this).attr("for")+"_position").val(true);
                    /*Si le bouton est d�s�lectionn�, on repli la famille (on test si la famille n'est pas d�j� repli�)*/
                    if($(this).parents("div.collapse__header").find("a.collapse__toggle").attr("aria-expanded")=="false"){
                    	$(this).parents("div.collapse__header").find("a.collapse__toggle").click();
                    }
                }
                /* Mettre a jour la toolbox : V72 - CU233 - Correction Fiche 60532 */
                if ($(this).hasClass("btn-digi") && $(this).parents("div.collapse__header").hasClass("checked")) {
                    $(".adh_digiposte").removeClass("hide");
                } else if ($(this).hasClass("btn-digi") && !$(this).parents("div.collapse__header").hasClass("checked")) {
                    $(".adh_digiposte input").removeAttr("checked");
                    $(".adh_digiposte").addClass("hide");
                }
            })

            /* Animation li�e aux exigences client sur maquette lot21.b */
            /* Inutile pour la production */
            $('.btn-modify').on('click', function (e) {
                    $("div.adh_digiposte").removeClass("hide");
            })

            $('.btn-modal').on('click', function (e) {

                var focusedItem = $( document.activeElement );
                focusedItem.blur();
                $(this).blur();
                setVoiceOverFocus (focusedItem);
                $('header').attr('aria-hidden','true');
                 $('main').attr('aria-hidden','true');
                $('footer').attr('aria-hidden','true');



               // $('.modal').attr('aria-hidden','false');
            })



            function setVoiceOverFocus(element) {
                var focusInterval = 10; // ms, time between function calls
                var focusTotalRepetitions = 10; // number of repetitions

                element.attr('tabindex', '0');
                element.blur();

                var focusRepetitions = 0;
                var interval = window.setInterval(function() {
                    element.focus();
                    focusRepetitions++;
                    if (focusRepetitions >= focusTotalRepetitions) {
                        window.clearInterval(interval);
                    }
                }, focusInterval);
            }

            $('.modal .close').on('click', function (e) {
                $('header').attr('aria-hidden','false');
                $('main').attr('aria-hidden','false');
                $('footer').attr('aria-hidden','false');
                //$('.modal').attr('aria-hidden','true');
            })

            $('.modal').on('click', function (e) {
                $('header').attr('aria-hidden','false');
                $('main').attr('aria-hidden','false');
                $('footer').attr('aria-hidden','false');
                //$('.modal').attr('aria-hidden','true');
            })

            $('.modal').on( 'focus', function( event ) {
               var $close = $('h1.modal-title');
                $close.focus();
            });

            function display( select ) {
                var a = [];
                for ( var i = 0; i < select.length; i++ ) {
                    console.log( select[ i ].innerHTML );

                }

            }
            /* Input select component lot21b */
            var $selects = $('.select-list select');
            for ( var i = 0; i < $selects.length; i++ ) {
                var classeName = ".appendList-"+[ i ];
                $('.'+$selects[i].className).select2({
                    minimumResultsForSearch: Infinity,
                    dropdownParent: $(classeName)
                });
            }  
           
            $('.consultation-cpte .collapse__toggle').on('click', function (e) {    
                
                    if ( $(this).attr("aria-expanded") === "false" ) {
                      $(this).css("background","#FFF");
                    } else  {
                       $(this).css("background","#E4E4E4");
                    }
            })
            /* tabulation radio */
           
            $('.tabLi').on('keypress', function (event) {    
                var keycode = (event.keyCode ? event.keyCode : event.which);
                $(this).css("outline","default");
                if (keycode == 13 || keycode == 37 || keycode == 38 || keycode == 39 || keycode == 40 || keycode == 32) {
                    var radio = $(this).find("input[type=radio]"); RadioButton_to_Checkbox($(radio),"enter");
                }   
                event.stopPropagation();
            })
            
            /* tabulation checkbox */
            $('.mdrnCheck').on('keypress', function (event) {    
                var keycode = (event.keyCode ? event.keyCode : event.which);
                if (keycode == 13) {
                     Checkbox_to_RadioButton($("input[type=checkbox]"),"enter");
                }   
                event.stopPropagation();
            })
            $('.tabLi input[type=radio]').on('click', function (event) {    
                var radio = $(this);
                $(this).css("outline","default");
               
                RadioButton_to_Checkbox($(radio),"enter");
                
            })
            $('.tabLi').on('click', function (event) {    
                var radio = $(this).find("input[type=radio]");
                $(this).css("outline","none");
               
                RadioButton_to_Checkbox($(radio),"enter");
                
            })
            
            $('.mdrnCheck').on('click', function (event) {    
                
                Checkbox_to_RadioButton($("input[type=checkbox]"),"enter");
                
            })
            function RadioButton_to_Checkbox(box,myEvent){
                if(myEvent == "enter")
                {
                    var $box = $(box);
                    if($box.attr('checked')) {
                       // $box.attr('checked',false); 
                    }
                        
                    else {
                        $box.attr('checked',true); 
                    }
                        
                }
                $('input:radio[name=' + box.name + ']').each(function(){
                    if (this != box) {
                        $(this).attr('checked', false);
                        $(this).parent().attr("title","D�sactiv�"); 
                    }
                });
            }
            function Checkbox_to_RadioButton(box,myEvent){
                if(myEvent == "enter")
                {
                    var $box = $(box);
                    if($box.attr('checked')) {
                        $box.attr('checked',false);
                        $('.mdrnCheck').attr("title","D�sactiv�"); 
                    }
                        
                    else {
                        $box.attr('checked',true);
                        $('.mdrnCheck').attr("title","Activ�"); 
                    }
                        
                }
                $('input:checkbox[name=' + box.name + ']').each(function(){
                    if (this != box)
                        $(this).attr('checked', false);
                });
            }
            
            $('.toggle_text').on('click', function (e) {
                 if (  $(this).text().indexOf( "Cacher" ) >= 0 ){
                      $(this).html("<span class='visually-hidden'>Afficher les d�tails des frais</span>R�duire");
                    } 
                else if (  $(this).text().indexOf( "Afficher" ) >=0 ){
                      $(this).html("<span class='visually-hidden'>Cacher les d�tails des frais</span>En savoir plus");
                    } 
            })
            
            $('input.tt-input').on('focusout', function (e) {  
                
                
                icon.toggle( "slow", function() {
                   
                  });
                    
            })
            
            //Le code specifique a l'ecran saisieIntitules a ete externalise dans saisieIntitules.js
            
			$('i.delete').on('click', function (e) {
                var input = $(this).parent().find("input");
                input.focus();
                $(this).addClass("visually-hidden");
                $(this).parent().addClass("edit-lib");
                $(this).parent().attr("aria-hidden","true");
                input.addClass("edit");
                input.attr("value","");
                var $form = $(this).parents("form");
                if ($form.hasClass("email")) {
                    input.attr("placeholder","nom@exemple.fr");
                } else {
                    input.attr("placeholder","Saisir un libell� personnalis�");
                }
            })


            $('input.readonly').on('click', function (e) {
                    $(this).parent().parent().find(".icon-cross").addClass("visually-hidden");
                    $(this).parent().find(".tt-menu").addClass("visually-hidden");

                    $(this).parent().addClass("edit-lib");
                    $(this).addClass("edit");
                    $(this).attr("value","");
                    $(this).attr("placeholder","Saisir un libell� personnalis�");
            })
            $('input.readonly').on('focusout', function (e) {
                    $(this).parent().parent().find(".icon-cross").removeClass("visually-hidden");

            })
            // Enable alert removing
            var $alerts = $('.alert__close');
            if($alerts.length > 0) {
                var $focusables = $(':focusable');
                $alerts.on('click', function (e) {
                    e.preventDefault();
                    $(this).parents('.alert').remove();
                    var current = $focusables.index(this),
                        next = $focusables.eq(current + 1).length  ? $focusables.eq(current + 1) : $focusables.eq(0);
                    next.focus();
                });
            }
        },
        equalHeight: function ($els) {
            var h = 0;
            $els.each(function () {
                $(this).innerHeight() > h ? h = $(this).innerHeight() : '';
            }).css('height', h);

            return $els;
        }
    };

    return new Q4x;
})(jQuery);
$(document).ready(function(){
    /**
     *
     * */
    Q4X.init();
});

