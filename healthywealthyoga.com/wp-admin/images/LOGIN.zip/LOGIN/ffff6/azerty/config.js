/*
  * @version $Revision: 1.6.82.1 $
  * @lastmodified $Date: 2016/09/13 11:58:23 $
*/

/*Chemins pour acceder au ressources selon les environnements*/
var pathRessourcesCss = "../../resources/css/"; 
var pathRessourcesjs = "../../resources/js/"; 
var pathRessourcesImg = "../../resources/img/q4x/"; 
