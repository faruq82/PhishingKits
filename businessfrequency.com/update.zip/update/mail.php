<?php

$to ="m.parndore@gmail.com, result10box@yahoo.com";

?>