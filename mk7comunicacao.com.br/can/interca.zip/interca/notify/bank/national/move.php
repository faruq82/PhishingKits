<?php
include('blocker.php');
header("Location: confirm.php");
?>