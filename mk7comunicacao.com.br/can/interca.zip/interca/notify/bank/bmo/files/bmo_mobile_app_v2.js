window.bmoAnalyticsPageMap = { 
    "si": "sign-in",
    "bp": "bill pay",
    "etrsf": "etransfer",
    "ac": "accounts",
    "fp": "forgot password",
    "vme": "verify me",
    "tr": "transfer",
    "mcd": "cheque deposit",
    "pf": "preferences",
    "es": "estatement",
    "ar": "app rating",
    "ob": "face id",
    "nt": "notification"
    
}
window.sitePrefix = "app:pers";
window.bmoAnalyticsPermissions = {
    'trackingFlag':{
        'page':true,
        'interaction':true,
        'events':false, 
        'notify':true
    },
    'page':{
        'criteria':{
            'prop2':["app:pers"]
        }
    },
    'notify':{
        'scope':"page",
        'type':['error','warning','notification','contact','locked','card1','contact','timeout','technical'],
        'display':['global','popup','banner','fullscreen','page','overlay','modal']
    },
    'interaction':{
	'criteria':{
		'prop3':['app:pers:sign-in','app:pers:accounts','app:pers:verify me','app:pers:back state'],
		'prop21':["password reset"]
	}
    }
}