
/* JavaScript content from lib/e9f82624cf1d9ed9b3f9882ceaf5e5c5cee1c21f/scripts/satellite-5d3a152064746d64730009f5.js in folder common */
_satellite.pushAsyncScript(function(event, target, $variables){
  var lang = s.prop14 || "";
var appVersion = s.eVar91 || "";
var os = s.eVar92 || "";

var pp = "sign-in:sign-in";
var forgotPasswordData = {
    'analyticsMetaData': {
        'page': {
            'name': 'password-reset:initiate',
            'pageType': 'tool',
            'toolStatus': 'start'
        },
      'previous':{
        'state':pp,
      },
        'tool': {
            'name': 'password reset',
            'events': 'event292'
        },
        'environment': {
            'language': lang,
            'device': {
              'appVersion':appVersion,
                'os': os
            },
        }
    }
}

bmoAnalytics.track("page",forgotPasswordData);
window.ppageName = forgotPasswordData.analyticsMetaData.page.name;
});
