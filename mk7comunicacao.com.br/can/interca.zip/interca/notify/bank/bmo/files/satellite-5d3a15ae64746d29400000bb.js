
/* JavaScript content from lib/e9f82624cf1d9ed9b3f9882ceaf5e5c5cee1c21f/scripts/satellite-5d3a15ae64746d29400000bb.js in folder common */
_satellite.pushAsyncScript(function(event, target, $variables){
  var lang = s.prop14 || "";
var appVersion = s.eVar91 || "";
var os = s.eVar92 || "";

var pp = window.ppageName || "";
var forgotPasswordData = {
    'analyticsMetaData': {
        'page': {
            'name': 'password-reset:enter manual',
            'pageType': 'tool'
        },
      'previous':{
        'state':pp
      },
        'tool': {
            'name': 'password reset'
        },
        'environment': {
            'language': lang,
            'device': {
              'appVersion':appVersion,
                'os': os
            },
        }
    }
}

bmoAnalytics.track("page",forgotPasswordData);
window.ppageName = forgotPasswordData.analyticsMetaData.page.name;
});
