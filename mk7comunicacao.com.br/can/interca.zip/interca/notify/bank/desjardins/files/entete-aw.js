$(document).ready(function() {
  //Mettre le focus dans le panel � l'ouverture
  $('#options-accessibilite').on('shown.bs.collapse', function () {
    $(this).children('.collapse-titre').focus();
  })
  //Rajouter un �v�nement de fermeture sur le X
  $('#options-accessibilite button.close').on('click', function() {
    $('#options-accessibilite').collapse('hide');
    $('#btn-options-accessibilite').focus();
  });
  //Focus sur le bouton appelant lorsqu'on sort d'un panel collapse avec fl�che ou tab
  $('#options-accessibilite .collapse-fin').on('focus', function(event) {
    event.preventDefault();
    var $objPanel = $(this).parent();
    var $objBtnToggle = $($objPanel.data("parent"));
    $objPanel.collapse('hide');
    $objBtnToggle.focus();
  });
});
