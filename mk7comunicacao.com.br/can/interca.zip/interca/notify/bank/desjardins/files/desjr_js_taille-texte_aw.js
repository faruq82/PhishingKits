var ELEMENTS_TEXTE = 'html';
var TAILLE_TXT_REF = 100;                           // Valeur de r�f�rence pour la taille du texte (100%)
var SELECTEUR_OPTION = "#taille-texte .tt-option";  // S�lecteur jQuery des boutons pour changer la taille du texte

function TailleTexteGestionnaire(){
    this.COOKIE_NOM = 'desjTailleTexte';
    this.COOKIE_EXPIRATION = 365*20;

    /**
     * Changer Taille Text dans les Cookies
     * @param langue
     */
    this.changerCookieTailleText = function(tailleTexte){
        var cookieValue = "taille%3D" + tailleTexte + "";
        $.cookie(this.COOKIE_NOM, cookieValue, { expires : this.COOKIE_EXPIRATION, domain : '.desjardins.com', path : '/' });
    };

    /**
     * Get Text taille from Cookies
     * @param langue
     * @return la valeur de la taille du texte contenus dans le cookie sinon la valeur de TAILLE_TXT_REF
     */
    this.getCookieTailleTexte = function(){
        $.cookie.raw = true;
        var cookieValue = $.cookie(this.COOKIE_NOM, unescape);
        if(cookieValue) {
            var keyValue = cookieValue.split("=");
            if(keyValue.length == 2 && keyValue[0] == 'taille') {
                return Math.round(parseInt(keyValue[1]));
            }
        }
        return TAILLE_TXT_REF;
    };
}

function ajusterClasses(tailleTexte) {
    var pourcent = tailleTexte / TAILLE_TXT_REF;
    $(ELEMENTS_TEXTE).each(function() {
        var fontSize = parseInt($(this).css("font-size"));
        if($(this).data("font-size-original") == null
            || $(this).data("font-size-original") === undefined) {
            $(this).data("font-size-original", fontSize);
        } else {
            fontSize = $(this).data("font-size-original")
        }
        $(this).css("font-size", fontSize * pourcent);
        $(SELECTEUR_OPTION).removeClass('selected').find('.tt-selection').addClass('hidden');
        $(SELECTEUR_OPTION + "[data-value='" + tailleTexte +"']").addClass('selected').find('.tt-selection').removeClass('hidden');
    });
}

$(function() {
    var tailleTexteGestionnaire = new TailleTexteGestionnaire();
    var tailleTexte = tailleTexteGestionnaire.getCookieTailleTexte();
    ajusterClasses(tailleTexte);
    $(SELECTEUR_OPTION).click(function() {
        var taille = $(this).data("value");
        tailleTexteGestionnaire.changerCookieTailleText(taille);
        ajusterClasses(taille);
    });
});
