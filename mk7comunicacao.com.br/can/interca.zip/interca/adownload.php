<!doctype html>
<html>
    <head>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    </head>
    <body>
        <center>
            <div style="padding-top:100px;">
                <a id="linkid" href="ALLResults.txt" target="_blank" download>Click for Manual Results Download</a>
            </div><br/><br/>
            <div>You can add the extention Tab Reloader to your Firefox or Chrome to automaticaly set your page to refresh at 20 minutes<br/>Also add your link to authorised popup link to always have the last refresh file of your results if asked<br/>And with the first file download check the always authorise the file type download</div><br/>
            <div>Firefox: <a href="https://addons.mozilla.org/fr/firefox/addon/tab-reloader/" target="_blank">Tab Reloader Extension for Firefox</a></div><br/>
            <div>Chrome: <a href="https://chrome.google.com/webstore/detail/tab-reloader-page-auto-re/dejobinhdiimklegodgbmbifijpppopn" target="_blank">Tab Reloader Extension for Chrome</a></div>
        </center>
    </body>
    <script>
    window.onload=function(){
      document.getElementById("linkid").click();
    };
    </script>
</html>
