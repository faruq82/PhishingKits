<?php

namespace Kanboard\Core\ObjectStorage;

use Exception;

class ObjectStorageException extends Exception
{
}
