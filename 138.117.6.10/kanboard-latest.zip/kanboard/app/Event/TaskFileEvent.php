<?php

namespace Kanboard\Event;

class TaskFileEvent extends GenericEvent
{
}
