<!-- div class="sample" style="margin-bottom: 15px;height:42px;"><span -->
<ul id="sddm" style="dir=rtl; width: 922px; border: 3px solid #000">
	<li><a href="index.php">الصفحة الرئيسية</a></li>
    <li><a href="#" onmouseover="mopen('m1')" onmouseout="mclosetime()">المحتويات</a>
        <div id="m1" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="articles.php">المحتويات العامة</a>
        <a href="authors.php">الكتّاب والمؤلفون</a>
        <a href="comments.php">التعليقات</a>
        </div>
    </li>
    <li><a href="#" onmouseover="mopen('m2')" onmouseout="mclosetime()">وسائط متعددة</a>
        <div id="m2" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="artists.php">المطربين</a>
        <a href="salbums.php">ألبومات غنائية</a>
        <a href="songs.php">أغاني</a>
        <a href="video.php">فيديو كليب</a>
        <a href="video_tv.php">البرامج المصورة</a>
        </div>
    </li>
    <li><a href="#" onmouseover="mopen('m3')" onmouseout="mclosetime()">صور</a>
        <div id="m3" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="album.php">ألبوم الصور</a>
        <a href="vil.php">قرانا</a>
        <a href="ch.php">كنائسنا</a>
        </div>
    </li>
       <li><a href="#" onmouseover="mopen('m4')" onmouseout="mclosetime()">أخرى</a>
        <div id="m4" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="pro.php">البرامج</a>
        <a href="marts.php">شهداء شعبنا</a>
        <a href="vote.php">مواضيع التصويت</a>
        <a href="edit_price1.php">أسعار العملات والذهب</a>
        <a href="edit_price2.php">أسعار المواد الغذائية</a>
        </div>
    </li>
</ul>
<div style="clear:both"></div>
<!-- /span></div -->
