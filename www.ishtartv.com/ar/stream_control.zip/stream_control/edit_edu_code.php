<link href="dentry.css" rel="stylesheet" type="text/css" />
<table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="481">&nbsp;</td>
    <td width="19">&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="middle" class="bold" dir=rtl>&#1575;&#1604;&#1585;&#1580;&#1575;&#1569; &#1573;&#1583;&#1582;&#1575;&#1604; &#1585;&#1602;&#1605; &#1578;&#1587;&#1580;&#1610;&#1604;&#1603; </td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="left" valign="middle"><form name="form1" method="post" action="">
      <input type="text" name="textfield">
        </form>    </td>
    <td>&nbsp;</td>
  </tr>
</table>
