<ul id="sddm" style="dir=rtl; width: 920px; background-image:url(images/background.gif); background-repeat:repeat-x;border: 1px solid #09C">
	<li><a href="index.php">الصفحة الرئيسية</a></li>
<!-- <li><a href="students.php">الطلبة النازحين</a></li> -->
    <li><a href="#" onmouseover="mopen('m1')" onmouseout="mclosetime()">المحتويات</a>
        <div id="m1" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="authors.php">الكتّاب والمؤلفون</a>
        <a href="articles.php">المحتويات العامة</a>
        <a href="comments.php">التعليقات</a>
        </div>
    </li>
    <li><a href="#" onmouseover="mopen('m2')" onmouseout="mclosetime()">وسائط متعددة</a>
        <div id="m2" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="artists.php">المطربين</a>
        <a href="salbums.php">ألبومات غنائية</a>
        <a href="songs.php">أغاني</a>
        <a href="video.php">فيديو كليب</a>
        <a href="tv.php">البرامج المصورة</a>
        </div>
    </li>
       <li><a href="#" onmouseover="mopen('m4')" onmouseout="mclosetime()">أخرى</a>
        <div id="m4" onmouseover="mcancelclosetime()" onmouseout="mclosetime()">
        <a href="pro.php">البرامج</a>
        <a href="marts.php">شهداء شعبنا</a>
        <a href="#">مواضيع التصويت</a>
        </div>
    </li>
</ul>
<div style="clear:both"></div>
