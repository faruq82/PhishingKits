<textarea dir="rtl" id="<?php echo $obj_name; ?>" name="<?php echo $obj_name; ?>" rows=10 cols=90>
<?php

 if(isset($_SESSION[$obj_name]))
    {
    $sContent[$obj_name]=stripslashes($_SESSION[$obj_name]); /*** remove (/) slashes ***/
    echo encodeHTML($sContent[$obj_name]);
    }
  ?>
  </textarea>
  
  
 <script>
    var oEdit1 = new InnovaEditor("oEdit1");

    oEdit1.width=775;
    oEdit1.height=350;

    /***************************************************
    ADDING CUSTOM BUTTONS
    ***************************************************/

    //oEdit1.arrCustomButtons = [["CustomName1","alert('Command 1 here.')","Caption 1 here","btnCustom1.gif"],
    //["CustomName2","alert(\"Command '2' here.\")","Caption 2 here","btnCustom2.gif"],
    //["CustomName3","alert('Command \"3\" here.')","Caption 3 here","btnCustom3.gif"]]


    /***************************************************
    RECONFIGURE TOOLBAR BUTTONS
    ***************************************************/

    oEdit1.tabs=[
    ["tabHome", "Home", ["grpEdit", "grpFont", "grpPara", "grpPage"]],
    ["tabStyle", "Objects & Styles", ["grpObjects", "grpLinks", "grpTables", "grpStyles"]]
    ];

    oEdit1.groups=[
    ["grpEdit", "", ["Undo", "Redo", "Search", "SpellCheck", "ClearAll", "BRK", "Cut", "Copy", "Paste", "PasteWord", "PasteText", "RemoveFormat"]],
    ["grpFont", "", ["FontName", "FontSize", "BRK", "Bold", "Italic", "Underline","Strikethrough","Superscript","Subscript", "ForeColor", "BackColor"]],
    ["grpPara", "", ["Paragraph", "Indent", "Outdent", "LTR", "RTL", "BRK", "JustifyLeft", "JustifyCenter","JustifyRight","JustifyFull", "Numbering","Bullets"]],
    ["grpPage", "", ["Save", "Print", "Preview", "BRK", "FullScreen", "XHTMLSource"]],
    ["grpObjects", "", ["Image", "Flash","Media", "CustomObject", "BRK","CustomTag", "Characters", "Line", "Form"]],
    ["grpLinks", "", ["Hyperlink","InternalLink", "BRK", "Bookmark"]],
    ["grpTables", "", ["Table", "BRK", "Guidelines"]],
    ["grpStyles", "", ["StyleAndFormatting", "Styles", "BRK", "Absolute"]],
    ["grpCustom", "", ["CustomName1","CustomName2", "BRK","CustomName3"]]
    ];


    /***************************************************
    OTHER SETTINGS
    ***************************************************/
    oEdit1.css="//www.ishtartv.com/ar/control/style/test.css";//Specify external css file here

    oEdit1.cmdAssetManager = "modalDialogShow('/opt/site/ar/main/assetmanager/assetmanager.php',800,800)"; //Command to open the Asset Manager add-on.
    oEdit1.cmdInternalLink = "modelessDialogShow('links.htm',365,270)"; //Command to open your custom link lookup page.
    oEdit1.cmdCustomObject = "modelessDialogShow('//www.ishtartv.com/ar/control/editor/scripts/moz/objects.htm',365,270)"; //Command to open your custom content lookup page.


    oEdit1.customColors=["#ff4500","#ffa500","#808000","#4682b4","#1e90ff","#9400d3","#ff1493","#a9a9a9"];//predefined custom colors

    oEdit1.mode="XHTMLBody"; //Editing mode. Possible values: "HTMLBody" (default), "XHTMLBody", "HTML", "XHTML"



    oEdit1.REPLACE("<?php echo $obj_name; ?>");
  </script>
