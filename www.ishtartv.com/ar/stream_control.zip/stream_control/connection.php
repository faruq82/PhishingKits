<?php
     	////// Web Host ////////////
        define ("DB_HOST" ,"localhost");
        define ("DB_NAME", "ishtartv_db");
        define ("DB_USER", "ishtartv_backer");
        define ("DB_PASS", "yo928yo*#O@YE(@2jfjfjfjfsdlfk");

        try {
             	$pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS, array(PDO::ATTR_PERSISTENT => true));
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
                $pdo->query("SET NAMES 'utf8'");
                $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
               #echo 'ERROR: ' . $e->getMessage();
               echo "<h2>Coming back soon!</h2>";
        }

	// back-compaitability
        #if(!$conn) {
        #	$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS);
        #	mysqli_select_db(DB_NAME,$conn); // or die("No database found");
        #	mysqli_query("SET NAMES 'utf8'");
        #}

?>

<?php 
	#if(!$conn) {
	#	$conn = mysql_pconnect("localhost", $db_username, $db_password);
	#	mysql_select_db($db_name,$conn);
	#	mysql_query("SET NAMES 'utf8'");
	#}
?>
