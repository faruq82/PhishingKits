 <?php
 // random key generator 
function getrand() { 
// random key paramters 
$keyset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; 
$length = 4; // first 14 chars of transaction_id are date, last 4 random 

// Random Key Generator 
$randkey = ""; 
$max = strlen($keyset)-1; 

for ($i=0; $i<$length; $i++) { 
$randkey .= substr($keyset, rand(0,$max), 1); 
} 
$date = date("YmdHis"); //puts in format YYYYMMDDhhmmss 
$rand_str = $randkey; 
$transactionID = $date . $rand_str;
return $transactionID; 
} 
?>