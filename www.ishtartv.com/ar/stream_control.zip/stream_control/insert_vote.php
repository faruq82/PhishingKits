﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="//www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>قناة عشتار الفضائية - إدخال تصويت</title>
<link href="dentry.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="cal.js"></script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="menu.css" rel="stylesheet" type="text/css" />
<script src="menu.js"></script>
</head>

<body>
<div class="divstyle"><?php include("header.php"); ?><?php include("menu.php"); ?>
<table width="922" border="0" align="center" cellpadding="0" cellspacing="0" dir=rtl>
  <tr><td>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right" class='bold_title' valign="middle" dir=rtl>إضافة تصويت <br />
    <br /></td>
  </tr>
  <tr>
    <td align="right">
<?php
	include("img_resize.php");
	include("connection.php");
	////////////// Empty Session array before new record ///////////////////////////////
	if (!isset($_POST['submit'])) { /*session_start();*/ $_SESSION = array(); /*session_destroy();*/}
	
	//session_start();
	if(!$_SESSION['vtodate']) { $_SESSION['vtodate']="0000-00-00"; }
	if(!$_SESSION['vfromdate']) { $_SESSION['vfromdate']="0000-00-00"; }
	$insert_vote=true;
	$show_form=true;
	$error = array('vtodate'=>'','vfromdate'=>'','vquestion'=>'');
	if (isset($_POST['submit'])) {
		$_SESSION['vtodate']= $_POST['vtodate'];
		$_SESSION['vfromdate']= $_POST['vfromdate'];
		$_SESSION['vquestion']= $_POST['vquestion'];
	
		
		
		
		if(strlen(trim($_POST['vquestion'])) < 1 ){ 
			$error['vquestion']= "يجب أن تدخل الموضوع";
			$insert_vote= false;
			}
			
		if(strlen($_POST['vfromdate']) < 1 || preg_match("#^ +#",$_POST['vfromdate']) || $_POST['vfromdate']=='0000-00-00'){ 
			$error['vfromdate']= "يجب أن تدخل التاريخ";
			$insert_vote= false;
			}
		if(!preg_match("#....-..-..#", $_POST['vfromdate'])){
			$error['vfromdate']= "أدخل التاريخ بصورة صحيحة";
			$insert_vote= false;
			}
		
		if(strlen($_POST['vtodate']) < 1 || preg_match("#^ +#",$_POST['vtodate']) || $_POST['vtodate']=='0000-00-00'){ 
			$error['vtodate']= "يجب أن تدخل التاريخ";
			$insert_vote= false;
			}
		if(!preg_match("#....-..-..#", $_POST['vtodate'])){
			$error['vtodate']= "أدخل التاريخ بصورة صحيحة";
			$insert_vote= false;
			}

	if($insert_vote==true){
		$conn = mysql_connect("localhost", $db_username,$db_password );
		 
		 
		
		$v_vtodate=$_POST['vtodate'];
		$v_vfromdate=$_POST['vfromdate'];
		$v_vquestion=$_POST['vquestion'];	
		
		$v_vtodate=(get_magic_quotes_gpc()) ? $v_vtodate : addslashes($v_vtodate);
		$v_vfromdate=(get_magic_quotes_gpc()) ? $v_vfromdate : addslashes($v_vfromdate);
		$v_vquestion=(get_magic_quotes_gpc()) ? $v_vquestion : addslashes($v_vquestion);
		
		$sql = "insert into `vote` values(NULL, '$v_vfromdate', '$v_vtodate', '$v_vquestion',0 ,0 ,0 , 'NO')";
		$result = $pdo->query($sql);
		
		
		echo "<br>". "<span class='bold'>". "تم إدخال التصويت" . "</span><br><br><br>";
		echo "<span class='bold'>"."<a href='vote_insert.php'>إضافة تصويت جديد</a></span>";
		echo "&nbsp;&nbsp;|&nbsp;&nbsp;<span class='bold'>"."<a href='vote.php'>الرجوع إلى صفحة التصويتات</a></span><br><br>";
		$show_form=false;
		//session_start();
		$_SESSION = array();
		//session_destroy();

		} 
	} 
	if ($show_form==true) {

?>


	<?php
	 	if($error['vtodate'] !='') { echo "<br><span class='red'>".$error['vtodate']."</span>"; }
		if($error['vfromdate'] !='') { echo "<br><span class='red'>".$error['vfromdate']."</span>"; }
		if($error['vquestion'] !='') { echo "<br><span class='red'>".$error['vquestion']."</span>"; }
	?>
	<form name='insertForm' action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="normal">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        
        <tr>
          <td width="87%" height="33" align="right" valign="top"><a href="javascript:openCalendar('lang=ar-utf-8&server=1&collation_connection=utf8_general_ci','insertForm','vfromdate','date')"><img src="images/b_calendar.png" width="16" height="16" border="0" /></a>
            <input name="vfromdate" type="text" class="normal" id="vfromdate" value="<?php echo $_SESSION['vfromdate'] ?>" /></td>
          <td width="11%" align="right" valign="top" class="bold">من تاريخ </td>
          <td width="2%" align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="31" align="right" valign="top"><a href="javascript:openCalendar('lang=ar-utf-8&amp;server=1&amp;collation_connection=utf8_general_ci','insertForm','vtodate','date')"><img src="images/b_calendar.png" width="16" height="16" border="0" /></a>
            <input name="vtodate" type="text" class="normal" id="vtodate" value="<?php echo $_SESSION['vtodate'] ?>" /></td>
          <td align="right" valign="top" class="bold">إلى تاريخ </td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="191" align="right" valign="top"><textarea dir=rtl name="vquestion" cols="80" rows="12" class="normal" id="vquestion"><?php echo $_SESSION['vquestion'] ?></textarea></td>
          <td align="right" valign="top"><label class="bold">موضوع التصويت </label></td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="33" colspan="2" align="right" valign="middle"><hr /></td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="33" align="right" valign="top"><label>
            <input name="submit" type="submit" class="normal" id="submit" value="حفظ" />
            <input name="Reset" type="reset" class="normal" value="إالغاء" />
          </label></td>
          <td align="right" valign="top" class="bold">&nbsp;</td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
      </table>

	</form>
	<?php
	}
	?>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</td></tr></table></div>  
</body>
</html>
