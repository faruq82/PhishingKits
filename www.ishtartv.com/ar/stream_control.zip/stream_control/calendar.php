﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="//www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Ishtar TV</title>
<?php
/* $Id: calendar.php,v 2.8 2005/11/18 12:50:49 cybot_tm Exp $ */
/*global $datefmt, $month, $day_of_week;

        if ($format == '') {
            $format = $datefmt;
        }

        if ($timestamp == -1) {
            $timestamp = time();
        }

        $date = preg_replace('@%[aA]@', $day_of_week[(int)strftime('%w', $timestamp)], $format);
        $date = preg_replace('@%[bB]@', $month[(int)strftime('%m', $timestamp)-1], $date);
*/
//require_once('common.lib.php');
//require_once('header_http.inc.php');
/*$month_names = array("كانون الثاني","شباط","آذار","نيسان","أيار","حزيران","تموز","آب","أيلول","تشرين الأول","تشرين الثاني","كانون الأول"); 
$day_names = array("الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت","الأحد");*/
$page_title = "Ishtar TV";
//require('header_meta_style.inc.php');
?>

<script type="text/javascript" src="cal.js"></script>

</head>
<link href="calendar.css" rel="stylesheet" type="text/css">
<body onLoad="initCalendar();">
<div id="calendar_data"></div>
<div id="clock_data"></div>
</body>
</html>
