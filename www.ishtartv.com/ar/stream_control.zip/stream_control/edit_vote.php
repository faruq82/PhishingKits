﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="//www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>قناة عشتار الفضائية - تحديث التصويت</title>
<link href="dentry.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="cal.js"></script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<link href="menu.css" rel="stylesheet" type="text/css" />
<script src="menu.js"></script>
</head>

<body>
<div class="divstyle"><?php include("header.php"); ?><?php include("menu.php"); ?>
<table width="922" border="0" align="center" cellpadding="0" cellspacing="0" dir=rtl>
  <tr><td>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td></td>
  </tr>
  <tr>
    <td align="right" class='bold_title' valign="middle" dir=rtl>تحديث تصويت <br />
      <br /></td>
  </tr>
  <tr>
    <td align="right">
<?php
	
	//////////// Initializing Enviroments ///////////////////////
	
	include("img_resize.php");
	include("connection.php");
	//session_start();
	
	
	//////////// Get the Old Values //////////////////////////		
	$id= $_REQUEST['id'];
	

if (!isset($_POST['submit'])) { /*session_start();*/ $_SESSION = array(); /*session_destroy();*/}
	
	
	$conn = mysql_connect("localhost", $db_username,$db_password );
	 
	 
	$sql = "SELECT * FROM `vote` WHERE `id`='$id'";
	$result = $pdo->query($sql);
		
		
		while($a=$result->fetch(PDO::FETCH_BOTH))
		{		
			$g_id = $a['id'];
			$g_fromdate = $a['fromdate']; 
			$g_todate = $a['todate'];
			$g_question = $a['question'];
		}
		mysql_close();	
		
		//session_start();
		
		$_SESSION['vlfromdate']= $g_fromdate;
		$_SESSION['vltodate']= $g_todate;
		$_SESSION['vlquestion']= $g_question;
	

	
	
	if(!$_SESSION['vltodate']) { $_SESSION['vltodate']="0000-00-00"; }
	if(!$_SESSION['vlfromdate']) { $_SESSION['vlfromdate']="0000-00-00"; }
	$edit_vote=true;
	$show_form=true;
	$error = array('vtodate'=>'','vfromdate'=>'','vquestion'=>'');
	
			/////////// Start Updating Process if the Form Submitted /////////////////////////
	if (isset($_POST['submit'])) {
		$_SESSION['vltodate']= $_POST['vltodate'];
		$_SESSION['vlfromdate']= $_POST['vlfromdate'];
		$_SESSION['vlquestion']= $_POST['vlquestion'];
	
			
		if(strlen(trim($_POST['vlquestion'])) < 1 ){ 
			$error['vquestion']= "يجب أن تدخل الموضوع";
			$edit_vote= false;
			}
			
		if(strlen($_POST['vlfromdate']) < 1 || preg_match("#^ +#",$_POST['vlfromdate']) || $_POST['vlfromdate']=='0000-00-00'){ 
			$error['vfromdate']= "يجب أن تدخل التاريخ";
			$edit_vote= false;
			}
		if(!preg_match("#....-..-..#", $_POST['vlfromdate'])){
			$error['vfromdate']= "أدخل التاريخ بصورة صحيحة";
			$edit_vote= false;
			}
		
		if(strlen($_POST['vltodate']) < 1 || preg_match("#^ +#",$_POST['vltodate']) || $_POST['vltodate']=='0000-00-00'){ 
			$error['vtodate']= "يجب أن تدخل التاريخ";
			$edit_vote= false;
			}
		if(!preg_match("#....-..-..#", $_POST['vltodate'])){
			$error['vtodate']= "أدخل التاريخ بصورة صحيحة";
			$edit_vote= false;
			}
		

	if($edit_vote==true){
		$conn = mysql_connect("localhost", $db_username,$db_password );
		 
		 
		
		$v_vtodate=$_POST['vltodate'];
		$v_vfromdate=$_POST['vlfromdate'];
		$v_vquestion=$_POST['vlquestion'];	
		
		$v_vtodate=(get_magic_quotes_gpc()) ? $v_vtodate : addslashes($v_vtodate);
		$v_vfromdate=(get_magic_quotes_gpc()) ? $v_vfromdate : addslashes($v_vfromdate);
		$v_vquestion=(get_magic_quotes_gpc()) ? $v_vquestion : addslashes($v_vquestion);
		
		
		if ($v_vfromdate!=$g_fromdate) {
			$sql = "update `vote` set `fromdate` = '$v_vfromdate' where `id`='$id'";
			$result = $pdo->query($sql);
		}
		if ($v_vtodate!=$g_todate) {
			$sql = "update `vote` set `todate` = '$v_vtodate' where `id`='$id'";
			$result = $pdo->query($sql);
		}
		if ($v_vquestion!=$g_question) {
			$sql = "update `vote` set `question` = '$v_vquestion' where `id`='$id'";
			$result = $pdo->query($sql);
		}
		
		
		mysql_close();	
		echo "<br>". "<span class='bold'>". "تم تحديث التصويت" . "</span><br>";
		echo "<span class='bold'>"."<a href='vote.php'>رجوع</a></span><br><br>";
		$show_form=false;
		//session_start();
		$_SESSION = array();
		//session_destroy();

		} 
	} 
	if ($show_form==true) {

?>


	<?php
	 	if($error['vfromdate'] !='') { echo "<br><span class='red'>".$error['vfromdate']."</span>"; }
		if($error['vtodate'] !='') { echo "<br><span class='red'>".$error['vtodate']."</span>"; }
		if($error['vquestion'] !='') { echo "<br><span class='red'>".$error['vquestion']."</span>"; }
	?>
	<form name='insertForm' action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="normal">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        
        <tr>
          <td width="87%" height="33" align="right" valign="top"><a href="javascript:openCalendar('lang=ar-utf-8&server=1&collation_connection=utf8_general_ci','insertForm','vlfromdate','date')">
            <input name="id" type="hidden" id="id" value="<?php echo $id; ?>" />
            <img src="images/b_calendar.png" width="16" height="16" border="0" /></a>
            <input name="vlfromdate" type="text" class="normal" id="vlfromdate" value="<?php echo $_SESSION['vlfromdate'] ?>" /></td>
          <td width="11%" align="right" valign="top" class="bold">من تاريخ </td>
          <td width="2%" align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="31" align="right" valign="top"><a href="javascript:openCalendar('lang=ar-utf-8&amp;server=1&amp;collation_connection=utf8_general_ci','insertForm','vltodate','date')"><img src="images/b_calendar.png" width="16" height="16" border="0" /></a>
            <input name="vltodate" type="text" class="normal" id="vltodate" value="<?php echo $_SESSION['vltodate'] ?>" /></td>
          <td align="right" valign="top" class="bold">إلى تاريخ </td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="191" align="right" valign="top"><textarea dir=rtl name="vlquestion" cols="80" rows="12" class="normal" id="vlquestion"><?php echo $_SESSION['vlquestion'] ?></textarea></td>
          <td align="right" valign="top"><label class="bold">موضوع التصويت </label></td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="33" colspan="2" align="right" valign="middle"><hr /></td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="33" align="right" valign="top"><label>
            <input name="submit" type="submit" class="normal" id="submit" value="حفظ" />
            <input name="Reset" type="reset" class="normal" value="إلغاء" />
          </label></td>
          <td align="right" valign="top" class="bold">&nbsp;</td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
      </table>

	</form>
	<?php
	}
	?>	</td>
  </tr>
</table>
</td></tr></table></div>  
</body>
</html>
