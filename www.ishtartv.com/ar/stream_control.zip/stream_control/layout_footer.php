                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <nav class="pull-left">
                        <ul>
                            <li>
                                <a href="#">
                                    
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    
                                </a>
                            </li>
                        </ul>
                    </nav>
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                      
                    </p>
                </div>
            </footer>
        </div>
    </div>
</body>
<!--   Core JS Files   -->
<script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/material.min.js" type="text/javascript"></script>
<script src="js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
<!-- Library for adding dinamically elements -->
<script src="js/arrive.min.js" type="text/javascript"></script>
<!-- Forms Validations Plugin -->
<script src="js/jquery.validate.min.js"></script>

<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="js/moment.min.js"></script>

<!--  Notifications Plugin, full documentation here: //bootstrap-notify.remabledesigns.com/    -->
<script src="js/bootstrap-notify.js"></script>
<!--   Sharrre Library    -->

<script src="js/bootstrap-datetimepicker.js"></script>

<!--  Plugin for Select, full documentation here: //silviomoreto.github.io/bootstrap-select -->
<script src="js/jquery.select-bootstrap.js"></script>

<!-- Plugin for Fileupload, full documentation here: //www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="js/jasny-bootstrap.min.js"></script>

<!-- Material Dashboard javascript methods -->
<script src="js/material-dashboard.js?v=1.2.0"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="js/demo.js"></script>
<script type="text/javascript" src="cal.js"></script>
<script src="colors.js" type="text/javascript"></script>
<script type="text/javascript">
    $(document).ready(function() {
        var image_counter = <?php echo $image_starter; ?>;
        var number_of_images = 150;
        var file_counter = <?php echo $file_starter; ?>;
        var number_of_files = 10;
        var video_counter = <?php echo $video_starter; ?>;
        var number_of_videos = 10;

        image_counter += 1;
        file_counter += 1;
        video_counter += 1;

        $('#date').datetimepicker({ format: 'YYYY-MM-DD' });
        $('#virtual_date').datetimepicker({ format: 'YYYY-MM-DD' });
        $("#more_images").click(
            function() {
                $('#img_wrap'+image_counter).show();
                if (image_counter > number_of_images) {
                    $("#more_images").hide();
                } else {
                    image_counter += 1;
                }
            });
        $("#more_files").click(
            function() {
                $('#file_wrap'+file_counter).show();
                if (file_counter > number_of_files) {
                    $("#more_files").hide();
                } else {
                    file_counter += 1;
                }
            });
        $("#more_videos").click(
            function() {
                $('#video_wrap'+video_counter).show();
                if (video_counter > number_of_videos) {
                    $("#more_videos").hide();
                } else {
                    video_counter += 1;
                }
            });
        // Javascript method's body can be found in assets/js/demos.js
        //demo.initDashboardPageCharts();

        //demo.initVectorMap();
    });
</script>

<script src='tinymce/js/tinymce/tinymce.min.js'></script>
<script>
tinymce.init({
    selector: "textarea#text",theme: "modern",width: 680,height: 300,
    plugins: [
         "advlist autolink link image lists charmap print preview hr anchor pagebreak",
         "searchreplace wordcount visualblocks visualchars insertdatetime media nonbreaking",
         "table contextmenu directionality emoticons paste textcolor code"
   ],
   toolbar1: "undo redo | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | styleselect",
   toolbar2: "| responsivefilemanager | link unlink anchor | image media | forecolor backcolor  | print preview code ",
   image_advtab: true ,
   
   external_filemanager_path:"/ar/main/filemanager/",
   filemanager_title:"Responsive Filemanager" ,
   external_plugins: { "filemanager" : "/ar/main/filemanager/plugin.min.js"}
 });

</script>


</html>
