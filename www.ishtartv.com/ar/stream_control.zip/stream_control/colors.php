<script src="colors.js"></script>
<input dir=rtl name="title" type="text" class="bold" id="title" size="50" value="<?php echo $_SESSION['title'] ?>" style="text-align:right" /> 
            * اللون <a href="javascript:pickColor('title_');" id="title_"
style="border: 1px solid #000000; font-family:Verdana; font-size:18px;
text-decoration: none; background-color: <?php echo $_SESSION['title_color']; ?>">&nbsp;&nbsp;&nbsp;</a>
            <input id="title_color" size="7" type="hidden" title="color" name="title_color" value="<?php echo $_SESSION['title_color'] ?>">
            <script language="javascript">relateColor('title_', getObj('title_color').value);</script>