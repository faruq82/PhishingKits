<?php
		$nums = 200;
		$padd = 2;
?>