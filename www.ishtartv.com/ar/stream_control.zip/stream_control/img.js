function more_img() {
	n = 150;
	if
	document.getElementById()
}