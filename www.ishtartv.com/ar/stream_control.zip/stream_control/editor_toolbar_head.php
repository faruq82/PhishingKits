<script type="text/javascript" src="//www.ishtartv.com/ar/control/editor/scripts/innovaeditor.js"></script>
<?php
function encodeHTML($sHTML)
   {
    $sHTML=preg_replace("#&#","&amp;",$sHTML);
    $sHTML=preg_replace("#<#","&lt;",$sHTML);
    $sHTML=preg_replace("#>#","&gt;",$sHTML);
    return $sHTML;
   }
?>