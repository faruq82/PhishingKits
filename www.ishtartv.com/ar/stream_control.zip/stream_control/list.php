<?php 


include "layout_header.php"; ?>

<?php
# THIS FUNCTION CREATED THE URL
function pagination_link($id, $page_num){
	return $_SERVER['PHP_SELF'].'?page_num='.$page_num.'&amp;'.'sect='.$_SESSION['sect'].'&amp;'.'q='.$_SESSION['q'];
}
###### PAGINATION FUNCTION ###### 
function pagination($num_of_items, $items_per_page, $id, $page_num, $max_links){
	$total_pages = ceil($num_of_items/$items_per_page);
	echo '<ul id="pagination-digg">';
	if($page_num) {
		if($page_num >1){ 
			$prev = '<li class="previous"><a href="'.pagination_link($id, ($page_num -1)).'">الصفحة السابقة</a></li>'; 
			$first = '<li class="previous"><a href="'.pagination_link($id, 1).'">الصفحة الأولى</a></li>'; 
		}
		else
			{
			$prev = '<li class="previous-off">الصفحة السابقة</a></li>'; 
			$first = '<li class="previous-off">الصفحة الأولى</li>'; 
			}
				
	}
	if($page_num <$total_pages){ 
		$next = '<li class="next"><a href="'.pagination_link($id, ($page_num+1)).'">الصفحة التالية</a></li>'; 
		$last = '<li class="next"><a href="'.pagination_link($id, $total_pages).'">الصفحة الأخيرة</a></li>';
	} else {
		$next = '<li class="next-off">الصفحة التالية</li>'; 
		$last = '<li class="next-off">الصفحة الأخيرة</li>';		
	}
	echo $first;
	echo $prev;
	$loop = 0;
	if($page_num >= $max_links) {
		$page_counter = ceil($page_num - ($max_links-1));
	} else {
		$page_counter = 1;
	}
	if($total_pages < $max_links){
		$max_links = $total_pages;
	}
	do{ 
		if($page_counter == $page_num) {
			echo '<li class="active">'.$page_counter.'</li>'; 
		} else {
			echo '<li><a href="'.pagination_link($id, ($page_counter)).'">'.$page_counter.'</a></li>';
		} 
		$page_counter++; $current_page=($page_counter+1);
		$loop++;
	} while ($max_links > $loop);
echo $next;
echo $last;
echo '</ul>';
}
?>

<?php
    $q =  $_REQUEST['q'];
    if($search_field=="" or !$search_field) $search_field = 'title';
    if($_REQUEST['q']) { $_SESSION['q'] = $_REQUEST['q']; }

	$pdo->query("SET NAMES 'utf8'");
    $sql= "SELECT count(*) FROM `$table` WHERE 1 = 1";
	if($q!="") $sql .= " AND `$search_field` LIKE '%$q%'"; 

	$result = $pdo->query($sql);
	
	$counta = $result->fetch(PDO::FETCH_NUM);
	$counta = $counta[0];

# CONFIGURATION EXAMPLE
$num_of_items = $counta;
$items_per_page = 50;
$max_links = 20;

if($_GET['page_num']){
	$page_num = $_GET['page_num'];
} else {
	$page_num = 1;
}
?>



<?php
	
	$sql = "SELECT count(*) FROM `$table`";
	$result = $pdo->query($sql);
	$row = $result->fetch(PDO::FETCH_NUM);
	$total_records = $row[0];

	$sql = "SELECT * FROM `$table` WHERE 1 = 1";
    if($q!="") $sql .= " AND `$search_field` LIKE '%$q%'";

    $sql .= " ORDER BY `$order_field` $order limit ".($page_num-1)*$items_per_page.", $items_per_page";
	$result = $pdo->query($sql);	

	$c = $start + (($page_num-1)*$items_per_page);
?>


<div class="row">
    <div class="col-md-12">
        <div class="card section">
            <div class="card-header card-header-icon" data-background-color="primary">
                <i class="material-icons">assignment</i> <h3><?php echo $list_label; ?> (<?php echo $total_records; ?>)</h3>
            </div>

            <div class="card-content">
                <h4 class="card-title" style="display: none;">Simple Table</h4>

                <div class="col-md-6">
                 <a href="<?php echo $add; ?>" class="btn btn-info btn-round"><i class="material-icons">keyboard_arrow_left</i> <?php echo $add_label; ?> </a>
                </div>
                <div class="col-md-6">
                    <form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF'] ?>" class="form-horizontal">
                             <!-- Search -->
                                <label class="col-sm-2 label-on-left">بحث</label>
                                <div class="col-sm-10">
                                    <div class="form-group label-floating is-empty">
                                        <label class="control-label"></label>
                                            <input dir=rtl name="q" type="text" id="q" value="<?php echo $_SESSION['q'] ?>" class="form-control" /> 
                                        </label>
                                    </div>
                                 <span class="material-input"></span>
                                </div>
                            

                            <input name="Submit" type="submit" class="btn btn-warning btn-round" value="تطبيق" />
              
                        
                    </form>
                </div>
                <div class="col-md-12">

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-right1"></th>
                                <?php 
                                	foreach ($fields as $field) {
                                ?>
                                	<th><?php echo $field['label']; ?></th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>

<?php
	while($a=$result->fetch(PDO::FETCH_ASSOC))
	{		
		$id = $a[$id_field]; 
		
		$c+=1;
				
?>

                        
                            <tr>
                                <td class="td-actions text-right1">
                                    <a href="<?php echo $edit; ?>?id=<?php echo $id; ?>" rel="tooltip" class="btn btn-success btn-simple" data-original-title="" title="">
                                        <i class="material-icons">edit</i>
                                    </a>
                                    <a href="<?php echo $remove; ?>?id=<?php echo $id; ?>" rel="tooltip" class="btn btn-danger btn-simple" data-original-title="" title="">
                                        <i class="material-icons">close</i>
                                    </a>
                                </td>
                                <?php 
                                	foreach ($fields as $field) {
                                		$fname = $field['name'];
                                		if ($field['type'] == 'profile') {
                                			$ext = pathinfo($a[$fname], PATHINFO_EXTENSION);
                                			if($ext=='') {
                                				$ext = '.jpg';
                                				$a[$fname] .= $ext;
                                			}
                                		}
                                        if($field['external']=='Yes') {
                                            $s = $field['name'];
                                            $sql4 = "SELECT `".$field['query_field']."` FROM `".$field['table']."` WHERE `".$field['field']."`='".$a[$s]."'";
                                            $result4 = $pdo->query($sql4);
                                            $b = $result4->fetch(PDO::FETCH_BOTH);
                                            $a['artist'] = $b['name'];
                                        }	
                                ?>
                                <td>
                                	<?php if($field['link']=='Yes') { ?>
                                		<a href=<?php echo $edit; ?>?id=<?php echo $id; ?>>
                                	<?php } ?>
                                	<?php if($field['type']=='profile') { ?>
                                		
                                		<?php if($a[$fname]!=='.jpg' && $a[$fname]!=='') { ?>
                                		<img src="<?php echo $field['path']; ?>/<?php echo $a[$fname]; ?>" style="width: 50px; border: none" border="0" />
                                		<?php } else { ?>
                                		<img src="//www.ishtartv.com/public/ar/authors_images/nopicture.jpg" style="width: 50px; border: none" border="0" />
                                			
                                		<?php } ?>
                                		
                                	<?php } elseif($field['type']=='text') { ?>
                                		<?php echo $a[$fname]; ?>
                                	<?php } else { ?>
                                		<?php echo $a[$fname]; ?>
                                	<?php } // endif type ?>
                                	<?php if($field['link']=='Yes') { ?>		
                                		</a>
                                	<?php } ?>	
                                </td>
                                <?php } // foreach ?>
                            </tr>
<?php } ?>



                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
    
<div class="row">
    <div class="col-md-12">
   		<div class="card">
            <div class="card-content">
		    	<div align="center">
					<?php echo pagination($num_of_items, $items_per_page, $id, $page_num, $max_links); ?> 
				</div>
				<br /><br />
			</div>
		</div>
	</div>
</div>	
<?php include "layout_footer.php"; ?>