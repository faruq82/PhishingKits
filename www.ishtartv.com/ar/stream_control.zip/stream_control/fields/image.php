<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
<div class="col-sm-10">
<div _ngcontent-c1="" id="img_wrap0" class="col-md-4 col-sm-4">
    <legend _ngcontent-c1=""></legend>
    <div _ngcontent-c1="" class="fileinput fileinput-new text-center" data-provides="fileinput">
        <div _ngcontent-c1="" class="fileinput-new thumbnail">
        	<?php if($_SESSION[$f_field]) { 
                $filename = pathinfo($_SESSION[$f_field], PATHINFO_FILENAME);
                $filename .= ".jpg";
                ?>
            	<img src="<?php echo $f_path; ?>/<?php echo $filename; ?>" alt="...">
            	<?php } else { ?>
                <img _ngcontent-c1="" alt="..." src="img/image_placeholder.jpg">
        	<?php } ?>
        </div>
        <div _ngcontent-c1="" class="fileinput-preview fileinput-exists thumbnail"></div>
        <?php if(1==2) { ?>
        <input name='desc1' align='right' id='desc1' dir='rtl' value='<?php echo $_SESSION["desc1"]; ?>' type='text' size='40' class="form-control" />
        <?php } ?>
        <div _ngcontent-c1="">
            <span _ngcontent-c1="" class="btn btn-rose btn-round btn-file">
                <span class="fileinput-new"><?php if($_SESSION[$f_field]) { ?>تغيير<?php } else { ?>إضافة<?php } ?></span>
    			<span class="fileinput-exists">تغيير</span>
                <input name="<?php echo $f_field; ?>" type="file" accept="image/jpeg" id="<?php echo $f_field; ?>" value="<?php echo $filename; ?>">
            </span>

            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> تراجع</a>
            <?php if($_SESSION[$f_field]) { ?>
                <input name='<?php echo $f_remove; ?>' class="btn btn-danger btn-round" type='submit' id='<?php echo $f_remove; ?>' value='مسح' />
                <?php } ?>
        </div>
    </div>
</div>
<div style="clear: both;"></div>
</div>