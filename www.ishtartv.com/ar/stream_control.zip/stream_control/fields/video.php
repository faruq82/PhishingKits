<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
<div class="col-sm-10">

<div _ngcontent-c1="" id="video_wrap" class="col-md-4 col-sm-4">
    <legend _ngcontent-c1=""></legend>
    <div _ngcontent-c1="" class="fileinput fileinput-new text-center" data-provides="fileinput">
        <div _ngcontent-c1="" class="fileinput-new thumbnail" style="background: url(img/image_placeholder4.jpg)">
        <?php if($_SESSION[$f_field]) { 
    	    $filename = pathinfo($_SESSION[$f_field], PATHINFO_FILENAME);
 			$filename .= ".mp4";
  			echo "<br /><p>أسم الفايل: ".$filename."</p>";
            echo "<br /><a href='".$f_path.$filename."' class='btn btn-info btn-round' target='_blank'>تحميل الفيديو</a><br /><br />";
			} else {  ?>
            <img _ngcontent-c1="" alt="..." src="img/image_placeholder5.jpg">
        	<?php } ?>
        </div>
        <div _ngcontent-c1="" class="fileinput-preview fileinput-exists thumbnail" style=" background: url(img/image_placeholder4.jpg)">
        	<?php if($_SESSION[$f_field]) { 
    	    $filename = pathinfo($_SESSION[$f_field], PATHINFO_FILENAME);
 			$filename .= ".mp4";
  			echo "<br /><p>أسم الفايل: ".$filename."</p>";
            echo "<br /><br /><a href='".$f_path.$filename."' class='btn btn-info btn-round' target='_blank'>تحميل الفيديو</a><br /><br />";
			} else { 
			echo "<br /><span dir=rtl class='red'>لم يتم إضافة فايل</span><br /><br />";  
			} 
	?> 
        </div>
        <div _ngcontent-c1="">
            <span _ngcontent-c1="" class="btn btn-rose btn-round btn-file">
                <span class="fileinput-new"><?php if($_SESSION[$f_field]) { ?>تغيير<?php } else { ?>إضافة<?php } ?></span>
    			<span class="fileinput-exists">تغيير</span>
                <input name="<?php echo $f_field; ?>" type="file" accept="video/mp4,video/x-m4v,video/*" class="normal" id="<?php echo $f_field; ?>" value="<?php echo $_SESSION[$f_field] ?>" />
            </span>
            <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> تراجع</a>
            <?php if($_SESSION[$f_field]) { ?>
            <input name='<?php echo $f_remove; ?>' class="btn btn-danger btn-round" type='submit' id='<?php echo $f_remove; ?>' value='حذف' />
            <?php } ?>
        </div>
    </div>
</div>

</div>