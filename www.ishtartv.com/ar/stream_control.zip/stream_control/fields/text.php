<!-- Text -->
<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
<div class="col-sm-10">
    <div class="form-group label-floating is-empty">
        <label class="control-label"></label>
            <input dir=rtl name="<?php echo $f_field; ?>" type="text" id="<?php echo $f_field; ?>" value="<?php echo $_SESSION[$f_field] ?>" class="form-control" /> 
            <?php if($help_text) { ?><p style="color: #FF9800;"><?php echo $help_text; ?></p><?php } ?>
        </label>
    </div>
   <span class="material-input"></span>
</div>