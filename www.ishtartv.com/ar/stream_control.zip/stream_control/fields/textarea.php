<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
    <div class="col-sm-10">
        <div class="form-group label-floating is-empty">
            <label class="control-label"></label>
                <textarea id="<?php echo $f_field; ?>" name="<?php echo $f_field; ?>" class="form-control"><?php echo $_SESSION[$f_field]; ?></textarea>
            </label>
        </div>
       <span class="material-input"></span>
    </div>