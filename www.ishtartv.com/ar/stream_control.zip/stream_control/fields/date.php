<!-- Date -->
<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
<div class="col-sm-10">
    <div class="form-group label-floating is-empty">
        <label class="control-label"></label>

   		<div class="form-group">
            <div class='input-group date' id='datetimepicker1'>
            <!--<span class="input-group-addon">
                    <i class="material-icons">insert_invitation</i>
                </span>-->
               <!-- <a href="javascript:openCalendar('lang=ar-utf-8&amp;server=1&amp;collation_connection=utf8_general_ci','insertForm','date','date')"><i class="material-icons">insert_invitation</i></a>-->
        <input name="<?php echo $f_field; ?>" type="text" class="form-control" id="<?php echo $f_field; ?>" value="<?php echo $_SESSION[$f_field] ?>" />
                
            </div>
        </div>

    	<span class="material-input"></span>
	</div>
</div>