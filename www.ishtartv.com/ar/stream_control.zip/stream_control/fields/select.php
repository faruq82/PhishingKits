<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
    <div class="col-sm-10">
        <div class="form-group label-floating is-empty">
            <label class="control-label"></label>
            <select name="<?php echo $f_field; ?>" id="<?php echo $f_field; ?>" class="form-control">
		          <option value=''>لا يوجد</option>
		   			<?php
						
						$sql1 = "SELECT `$f_query_id`, `$f_query_field` FROM `$f_query_table` ORDER BY `$f_query_order_field` $f_query_order";
						$result1 = mysql_query($sql1, $conn) or die(mysql_error());	
						while($a1 = mysql_fetch_array($result1))
						{		
							if($_SESSION[$f_field] && $_SESSION[$f_field]==$a1[$f_query_id])
							{	
								echo "<option value='".$a1[$f_query_id]."' selected='selected'>".$a1[$f_query_field]."</option>";
							} else {
							echo "<option value='".$a1[$f_query_id]."'>".$a1[$f_query_field]."</option>";
							}
						}
		            ?>
		    </select>
        <span class="material-input"></span>
    </div>
</div>