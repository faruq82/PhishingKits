<div class="col-md-3 col-sm-4" style="float: none;">
<legend><?php echo $f_label; ?></legend>
<div class="fileinput fileinput-new text-center" data-provides="fileinput">
    <div class="fileinput-new thumbnail img-circle">
    	<?php if($_SESSION[$f_field]) { 
            $filename = pathinfo($_SESSION[$f_field], PATHINFO_FILENAME);
            $filename .= ".jpg";
        ?>
    	<img src="http://www.ishtartv.com/public/authors_images/<?php echo $filename; ?>" alt="...">
    	<?php } else { ?>
        <img src="img/placeholder.jpg" alt="...">
    	<?php } ?>
    </div>
    <div class="fileinput-preview fileinput-exists thumbnail img-circle"></div>
    <div>
        <span class="btn btn-round btn-rose btn-file">
            <span class="fileinput-new"><?php if($_SESSION[$f_field]) { ?>تغيير<?php } else { ?>أضافة<?php } ?></span>
            <span class="fileinput-exists">تغيير</span>
            <input name="<?php echo $f_field; ?>" type="file" accept="image/jpeg" id="<?php echo $f_field; ?>" value="<?php echo $_SESSION[$f_field] ?>" /></td>
        </span>
        <br>
        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> تراجع</a>
        <?php if($_SESSION[$f_field]) { ?>
        <input name="<?php echo $f_remove; ?>" type="submit" class="btn btn-danger" id="<?php echo $f_remove; ?>" value="مسح" />
        <?php } ?>
    </div>
</div>
</div>