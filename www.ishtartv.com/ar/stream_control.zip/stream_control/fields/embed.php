<!-- Embed -->
<label class="col-sm-2 label-on-left"><?php echo $f_label; ?></label>
    <div class="col-sm-10">
        <div class="form-group label-floating is-empty">
            <label class="control-label"></label>
                <textarea name='<?php echo $f_field; ?>' type='text' class="form-control" id='<?php echo $f_field; ?>' rows="4" cols="50"><?php echo $_SESSION[$f_field]; ?></textarea>
            </label>
        </div>
       <span class="material-input"></span>
    </div>