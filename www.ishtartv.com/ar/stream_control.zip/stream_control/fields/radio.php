<label class="col-sm-2 label-on-left"></label>
    <div class="col-sm-10">
        <div class="form-group label-floating is-empty">

        <div _ngcontent-c1="" class="togglebutton">
            <label _ngcontent-c1="">
                <input type="checkbox" name="<?php echo $f_field; ?>" id="<?php echo $f_field; ?>" value="<?php echo $f_value; ?>" <?php if($_SESSION[$f_field]==$f_value) { echo "checked='checked'";} ?>/> <?php echo $f_label; ?>
            </label>
        </div>
       <span class="material-input"></span>
    </div>
</div>