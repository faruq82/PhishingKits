<hr />
<input name="submit" type="submit" class="btn btn-primary btn-round" id="submit" value="حفظ" />
<a href='<?php echo $f_back; ?>' class="btn btn-info btn-round"> رجوع</a>