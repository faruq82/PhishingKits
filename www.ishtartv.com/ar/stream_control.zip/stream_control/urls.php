<?php
	# SITE/STATIC Folder
	define ("STATIC_URL", "//www.ishtartv.com/ar/main/");
	define ("STATIC_PATH", "/opt/site/ar/main/");	
	# PUBLIC FOLDER
	define ("PUBLIC_URL", "//www.ishtartv.com/public/ar/");
	define ("PUBLIC_PATH", "/home/ishtartv/public_html/public/ar/");
	# Upload Folder
	define ("UPLOAD_PATH", "/home/ishtartv/public_html/upload/");
	# Articles
	define ("ARTICLES_IMAGES_PATH", "/home/ishtartv/public_html/public/ar/articles_images/");
	define ("ARTICLES_IMAGES_URL", "//www.ishtartv.com/public/ar/articles_images/");
	define ("ARTICLES_FILES_PATH", "/home/ishtartv/public_html/public/ar/articles_files/");
	define ("ARTICLES_FILES_URL", "//www.ishtartv.com/public/ar/articles_files/");
	define ("ARTICLES_VIDEOS_PATH", "/home/ishtartv/public_html/public/ar/articles_video/");
	define ("ARTICLES_VIDEOS_URL", "//www.ishtartv.com/public/ar/articles_video/");

	# Authors
	define ("AUTHORS_IMAGES_PATH", "/home/ishtartv/public_html/public/ar/authors_images/");
	define ("AUTHORS_IMAGES_URL", "//www.ishtartv.com/public/ar/authors_images/");

	# Videos
	define ("VIDEO_PATH", "/home/ishtartv/public_html/storage/ar/video/");
	define ("VIDEO_URL", "//www.ishtartv.com/storage/ar/video/");
	# vide thumbs
	define ("VIDEO_THUMBS_PATH", "/home/ishtartv/public_html/public/ar/video_thumbs/");
	define ("VIDEO_THUMBS_URL", "//www.ishtartv.com/public/ar/video_thumbs/");

	# Video TVs
	define ("VIDEO_TV_PATH", "/home/ishtartv/public_html/storage/ar/video_tv/");
	define ("VIDEO_TV_URL", "//www.ishtartv.com/storage/ar/video_tv/");
	# vide TV  thumbs
	define ("VIDEO_TV_THUMBS_PATH", "/home/ishtartv/public_html/public/ar/video_tv_thumbs/");
	define ("VIDEO_TV_THUMBS_URL", "//www.ishtartv.com/public/ar/video_tv_thumbs/");

?>