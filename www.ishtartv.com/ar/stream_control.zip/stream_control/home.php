<?php
        include("connection.php");
        include("sec.php");

        foreach ($sec as $key => $value)
        {
            $sql= "select count(*) from `articles` where `section`='$key'";
            $result = $pdo->query($sql);
            $row = $result->fetch(PDO::FETCH_NUM);
            $totals[$key] = $row[0];

            if($key=='naz7') $sec[$key] = 'النازحون...';
        }
    
        $sql= "select count(*) from `author`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);    
        $rest_totals['authors'] = $row[0];

        $sql= "select count(*) from `comments` where `valid`=0";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $total_comments_pending = $row[0];
        
        $sql= "select count(*) from `programs`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['pro']= $row[0];
        
        // No of Video TV
        $sql= "select count(*) from `video_tv`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['tv']= $row[0];
        
        // No of Video
        $sql= "select count(*) from `video`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['video']= $row[0];
        
        // No of Songs
        $sql= "select count(*) from `songs`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['songs'] = $row[0];
        
        // No of Artists 
        $sql= "select count(*) from `artists`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['artists'] = $row[0];
        
        // No of Albums
        $sql= "select count(*) from `albums`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['salbums'] = $row[0];
        
        // No of votes
        $sql= "select count(*) from `vote`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $total_vote = $row[0];       
        
        // No of Marts 
        $sql= "select count(*) from `marts`";
        $result = $pdo->query($sql);
        $row = $result->fetch(PDO::FETCH_NUM);
        $rest_totals['marts'] = $row[0];

        $colors = array("#FD9B15", "#EC4A47", "#57B05B", "#13B9CE", '#00BCD4', '#999999', '#E91E63', '#3B5998');
        
        $rest = array('authors'=>'الكتّاب', 'tv'=>'البرامج المصورة', 'pro'=>'البرامج', 'video'=>'فيديو كليبات', 'songs'=>'الأغاني', 'salbums'=>'ألبومات غنائية', 'artists'=>'المطربين', 'marts'=>'شهداء شعبنا');
        $rest_icons = array('authors'=>'people', 'tv'=>'videocam', 'pro'=>'tv', 'video'=>'music_video', 'songs'=>'queue_music', 'salbums'=>'library_music', 'artists'=>'people_outline', 'marts'=>'airline_seat_flat');
?>
<div class="row">
    <?php foreach ($sec as $key => $value) { ?> 
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="" style="background: <?php echo $colors[array_rand($colors)]; ?>">
                <a href="articles.php?sect=<?php echo $key; ?>"><i class="material-icons"><?php echo $sec_icons[$key]; ?></i></a>
            </div>
            <div class="card-content">
                <a href="articles.php?sect=<?php echo $key; ?>"><p class="category"><?php echo $value; ?></p>
                <h3 class="title"><?php echo $totals[$key]; ?></h3></a>
            </div>
            <div class="card-footer" style="display: none;">
                <div class="stats">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <a href="articles.php?sect=<?php echo $key; ?>">القائمة ...</a>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>

    <?php foreach ($rest as $key => $value) { ?> 
    <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="card card-stats">
            <div class="card-header" data-background-color="" style="background: <?php echo $colors[array_rand($colors)]; ?>">
                <a href="articles.php?sect=<?php echo $key; ?>"><i class="material-icons"><?php echo $rest_icons[$key]; ?></i></a>
            </div>
            <div class="card-content">
                <a href="<?php echo $key; ?>.php"><p class="category"><?php echo $value; ?></p>
                <h3 class="title"><?php echo $rest_totals[$key]; ?></h3></a>
            </div>
            <div class="card-footer" style="display: none;">
                <div class="stats">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <a href="articles.php?sect=<?php echo $key; ?>">القائمة ...</a>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    

</div>