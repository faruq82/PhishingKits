<div class="row">
    <div class="col-md-12">
        <div class="card section">
            <div class="card-header card-header-icon" data-background-color="primary">
                <i class="material-icons">assignment</i> <h3><?php echo $card_title; ?></h3>
            </div>
            <div class="card-content">
            	<div class="row">
    				<div class="col-md-12">