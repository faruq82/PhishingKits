<?php $colnames = array(
    "fullname" => "الاسم الرباعي واللقب",
    "birthdate" => "تاريخ الولادة",
    "birthplace" => "محل الولادة",
    "former_moh" => "محل السكن السابق_محافظة",
    "former_qatha" => "محل السكن السابق_قضاء",
    "former_nahia" => "محل السكن السابق_ناحية",
    "former_qaria" => "محل السكن السابق_قرية",
    "recent_moh" => "محل السكن الحالي_محافظة",
    "recent_qatha" => "محل السكن الحالي_قضاء",
    "recent_nahia" => "محل السكن الحالي_ناحية",
    "recent_qaria" => "محل السكن الحالي_قرية",
    "former_univ" => "الجامعة السابقة",
    "recent_univ" => "الجامعة الحالية",
    "college_inist" => "الكلية او المعهد",
    "dept" => "القسم او الفرع",
    "stage" => "المرحلة الدراسية الحالية",
    "phone" => "رقم الهاتف",
    "date" => "تاريخ ملئ الاستمارة",
    "other_info" => "معلومات اخرى",
    "notes" => "ملاحظات",
);


function map_colnames($input)
{
    global $colnames;
    return isset($colnames[$input]) ? $colnames[$input] : $input;
}

function cleanData(&$str)
{
    if($str == 't') $str = 'TRUE';
    if($str == 'f') $str = 'FALSE';
    if(preg_match("/^0/", $str) || preg_match("/^\+?\d{8,}$/", $str) || preg_match("/^\d{4}.\d{1,2}.\d{1,2}/", $str)) {
        $str = "'$str";
    }
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"';
    $str = mb_convert_encoding($str, 'UTF-16LE', 'UTF-8');
}

// filename for download
$filename = "students_data_" . date('Ymd') . ".csv";

header("Content-Disposition: attachment; filename=\"$filename\"");
header("Content-Type: text/csv; charset=utf-8");
echo "\xEF\xBB\xBF"; // UTF-8 BOM
$out = fopen("php://output", 'w');

include("connection.php");

$flag = false;
$sql = "SELECT "
    ."`fullname`, "
    ."`birthdate`, "
    ."`birthplace`, "
    ."`former_moh`, "
    ."`former_qatha`, "
    ."`former_nahia`, "
    ."`former_qaria`, "
    ."`recent_moh`, "
    ."`recent_qatha`, "
    ."`recent_nahia`, "
    ."`recent_qaria`, "
    ."`former_univ`, "
    ."`recent_univ`, "
    ."`college_inist`, "
    ."`dept`, "
    ."`stage`, "
    ."`phone`, "
    ."`date`, "
    ."`other_info`, "
    ."`notes` "
    ."FROM `form` ORDER BY `fullname`";
$result = mysql_query($sql,$conn) or die('Query failed!');
$flag = false;
while($row = mysql_fetch_assoc($result)) {
    if(!$flag) {
        // display field/column names as first row
        #$firstline = array_map("map_colnames", array_keys($row));
        fputcsv($out, array_values($colnames), ',', '"');
        $flag = true;
    }
    #array_walk($row, 'cleanData');
    fputcsv($out, $row, ',', '"');
}
fclose($out);
exit;
?>
<?php
/*
// output headers so that the file is downloaded rather than displayed
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=data.csv');

// create a file pointer connected to the output stream
$output = fopen('php://output', 'w');

// output the column headings
fputcsv($output, array('Column 1', 'Column 2', 'Column 3'));

// fetch the data
mysql_connect('localhost', 'username', 'password');
mysql_select_db('database');
$rows = mysql_query('SELECT field1,field2,field3 FROM table');

// loop over the rows, outputting them
while ($row = mysql_fetch_assoc($rows)) fputcsv($output, $row);
*/
?>