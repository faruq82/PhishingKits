<?php
#ini_set('display_errors', 1);
#ini_set('display_startup_errors', 1);
#error_reporting(E_ALL);
include("connection.php");
$id= $_GET['id'];
$sql = "SELECT * FROM `video` WHERE `id`=$id";
$result = $pdo->query($sql);	
$a = $result->fetch(PDO::FETCH_BOTH);
#echo "Converting ...";
$path_parts = pathinfo($a['fname']);
$filename = $path_parts['filename'];
echo "<pre>";
echo 'ffmpeg -i "'.$filename.'.mp4" -pix_fmt yuv420p -vcodec libx264 -vpre ultrafast -crf 0 "'.$filename.'-1.mp4"';
echo "<br />";
echo 'mv "'.$filename.'.mp4" "'.$filename.'-2.mp4"';
echo "<br />";
echo 'mv "'.$filename.'-1.mp4" "'.$filename.'.mp4"';
echo "<br />";
echo 'chown ishtartv:ishtartv "'.$filename.'.mp4"';
echo "</pre>";

#$output = shell_exec('ffmpeg -i "'.$filename.'.mp4" -pix_fmt yuv420p -vcodec libx264 -vpre ultrafast -crf 0 "'.$filename.'-1.mp4"');
#echo "<pre>$output</pre>";
#echo "Backup the original file ...";
#$output = shell_exec('mv "'.$filename.'.mp4" "'.$filename.'-2.mp4"');
#echo "<pre>$output</pre>";
#echo "Copy the new one ...";
#$output = shell_exec('mv "'.$filename.'-1.mp4" "'.$filename.'.mp4"');
#echo "<pre>$output</pre>";
?>