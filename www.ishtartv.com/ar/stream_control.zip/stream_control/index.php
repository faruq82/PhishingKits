﻿<?php $active=8; include "layout_header.php"; ?>
<?php $card_title="تعديل رابط البث المباشر"; include "layout_card_header.php"; ?>

<?php
	////////////// Empty Session array before new record ///////////////////////////////
	if (!isset($_POST['submit'])) { /*session_start();*/ $_SESSION = array();/* session_destroy();*/}
	
	$insert=true;
	$show_form=true;
	
	$id= $_REQUEST['id'];
	 
	 
	$sql = "SELECT * FROM `stream` WHERE `id`=1";
	$result = $pdo->query($sql);	
		while($a=$result->fetch(PDO::FETCH_BOTH))
		{		
            $embed = $a['value'];
		}
		
        $_SESSION['embed'] = base64_decode($embed);
	
	
	$error = array('embed'=>'');
	if (isset($_POST['submit'])) {
        $_SESSION['embed']= $_POST['embed'];
		
		if(strlen(trim($_POST['embed'])) < 1 ){ 
			$error['embed']= "رجاءاً أدخل الرابط";
			$insert= false;
			}

	if($insert==true){

        $a_embed=$_POST['embed'];
	    $a_embed= base64_encode($a_embed);
		if ($a_embed!=$embed) {
			$sql = "UPDATE `stream` SET `value` = '$a_embed' WHERE `id`=1";
			$result = $pdo->query($sql);
		} 

?>

	<div class="alert alert-success">
	    <button type="button" aria-hidden="true" class="close">
	        <i class="material-icons">close</i>
	    </button>
	    <span>
	    	<i class="material-icons">check</i>
	       تم تحديث رابط البث المباشر
	    </span>
	</div>
	<a href='index.php' class="btn btn-info btn-round"> الرجوع إلى صفحة تعديل رابط البث المباشر</a>



<?php				
		$show_form=false;
		//session_start();
		$_SESSION = array();
		//session_destroy();

		} 
	} 
	

	if ($show_form==true) {

?>


	<?php
		if($error['embed'] !='') { echo "<br><span class='red'>".$error['embed']."</span>"; }
	?>
	<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" name='insertForm' class="normal">
 
    	<!-- id -->
    	<?php $f_field = 'id'; $f_value = $aid; include "fields/hidden.php"; ?>

		<!-- Embed -->
	    <?php $f_label = 'رابط البث المباشر'; $f_field = 'embed'; include "fields/embed.php"; ?>

	    <!-- Save -->
        <?php $f_back = 'index.php'; include "fields/submit.php"; ?>

	</form>
	<?php
	}
	?>

<?php include "layout_card_footer.php"; ?>
<?php include "layout_footer.php"; ?>