<style type="text/css">
<!--
body {
	margin-left: 8px;
	margin-top: 8px;
	margin-right: 8px;
	margin-bottom: 8px;
	font-family: arial;
	font-size: 14px;
	background-color: #F9F9FB;
	background-image: url(images/bbg.png);
	background-repeat: repeat-x;
}
-->
</style>
<table width="922" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><img src="images/header.jpg" width="922" /></td>
  </tr>
</table>
