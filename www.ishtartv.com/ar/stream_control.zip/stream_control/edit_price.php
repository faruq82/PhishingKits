﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "//www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="//www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>قناة عشتار الفضائية - تحديث الأسعار</title>
<link href="dentry.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="cal.js"></script>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body>

<?php include("header.php");?>
<?php include("footer.php"); ?><?php include("rand.php"); ?><br /><br />
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="right" class='bold_title' valign="middle" dir=rtl>إدخال الاسعار<br /><br /></td>
  </tr>
  <tr>
    <td align="right">
<?php
	include("img_resize.php");
	include("connection.php");
	
	////////////// Empty Session array before new record ///////////////////////////////
	if (!isset($_POST['submit'])) { /*session_start();*/ $_SESSION = array(); /*session_destroy();*/}
	
	
	//session_start();
	//////////// Get the Old Values //////////////////////////		
	$id= $_REQUEST['id']; 
	//$id2= $_GET['id'];
	$conn = mysql_connect("localhost", $db_username,$db_password );
	 
	 
	$sql = "SELECT * FROM `prices` WHERE `id`='$id'";
	$result = $pdo->query($sql);	
		
		while($a=$result->fetch(PDO::FETCH_BOTH))
		{		
			//$id2 = $a['id'];
			$dollar = $a['dollar'];
			$euro = $a['euro'];
			$gold = $a['gold'];

		}
		//mysql_close();
			
		$_SESSION['dollar']= $dollar;
		$_SESSION['euro']= $euro;
		$_SESSION['gold']= $gold;	
	
	
	$insert=true;
	$show_form=true;
	
	$error = array('dollar'=>'','euro'=>'','gold'=>'');
	if (isset($_POST['submit'])) {
		$_SESSION['dollar']= $_POST['dollar'];
		$_SESSION['euro']= $_POST['euro'];
		$_SESSION['gold']= $_POST['gold'];


	if(strlen(trim($_POST['dollar'])) < 1 ){ 
			$error['dollar']= "يجب أن تدخل سعر الدولار";
			$insert= false;
			}

	if(strlen(trim($_POST['euro'])) < 1 ){ 
			$error['euro']= "يجب أن تدخل سعر اليورو";
			$insert= false;
			}

	if(strlen(trim($_POST['gold'])) < 1 ){ 
			$error['gold']= "يجب أن تدخل سعر الذهب";
			$insert= false;
			}
			
	if($insert==true){
		$conn = mysql_connect("localhost", $db_username,$db_password );
		 
		 
		
		echo $_POST['dollar'];
		$pp_dollar= $_POST['dollar'];
		$pp_euro= $_POST['euro'];
		$pp_gold= $_POST['gold'];
		
		///////////////////////// Compare before Update and Update if Different //////////////////////////
		
		$conn = mysql_connect("localhost", $db_username,$db_password );
		 
		 
		$date_new = date("Y-m-d h:i:s");
		//if ($pp_dollar!=$dollar) {
			$sql = "update `prices` set `dollar` = '$pp_dollar' where `id`='$id'";
			echo $sql;
			$result = $pdo->query($sql);
			//$sql = "update `prices` set `date` = '$date_new' where `id`='$id'";
			//$result = $pdo->query($sql);
		//}
		
		if ($pp_euro!=$euro) {
			$sql = "update `prices` set `euro` = '$pp_euro' where `id`='$id'";
			$result = $pdo->query($sql);
			//$sql = "update `prices` set `date` = '$date_new' where `id`='$id'";
			//$result = $pdo->query($sql);
		}
		
		if ($pp_gold!=$gold) {
			$sql = "update `prices` set `gold` = '$pp_gold' where `id`='$id'";
			$result = $pdo->query($sql);
			//$sql = "update `prices` set `date` = '$date_new' where `id`='$id'";
			//$result = $pdo->query($sql);
		}
		
		mysql_close();	
		echo "<br>". "<a href='prices.php' class='bold'>". "تم تحديث الأسعار" . "</a><br><br><br>";
		$show_form=false;
		//session_start();
		$_SESSION = array();
		//session_destroy();

		}
	} 
	if ($show_form==true) {

?>


	<?php
	 	if($error['dollar'] !='') { echo "<br><span class='red'>".$error['dollar']."</span>"; }
		if($error['euro'] !='') { echo "<br><span class='red'>".$error['euro']."</span>"; }
		if($error['gold'] !='') { echo "<br><span class='red'>".$error['gold']."</span>"; }
		
	?>
	<form name='insertForm' action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" class="normal" enctype="multipart/form-data">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td dir="rtl" height="31" align="right" valign="top"><input align="right" name="dollar" type="text" class="normal" id="dollar" dir="rtl" value="<?php echo $_SESSION['dollar'] ?>" size="60" />
          </td>
          <td align="right" valign="top" class="bold">الدولار</td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td dir="rtl" height="31" align="right" valign="top"><input align="right" name="euro" type="text" class="normal" id="euro" dir="rtl" value="<?php echo $_SESSION['euro'] ?>" size="60" />          </td>
          <td align="right" valign="top" class="bold">اليورو</td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        
        <tr>
          <td width="87" dir=rtl height="31" align="right" valign="top">
              <input align="right" name="gold" type="text" class="normal" id="gold" dir="rtl" value="<?php echo $_SESSION['gold'] ?>" size="60" />       </td>
          <td width="11%" align="right" valign="top" class="bold">الذهب</td>
          <td width="2%" align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="33" colspan="2" align="right" valign="middle"><hr /></td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
        <tr>
          <td height="33" align="right" valign="top"><label>
            <input name="submit" type="submit" class="normal" id="submit" value="حفظ" />
            <input name="Reset" type="reset" class="normal" value="إلغاء" />
          </label></td>
          <td align="right" valign="top" class="bold"><input name="id" type="hidden" id="id" value="<?php echo $_GET['id'];; ?>" /></td>
          <td align="right" valign="middle">&nbsp;</td>
        </tr>
      </table>
 
      </form>
	         <?php
	}
	?>
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<?php include("footer.php"); ?>
</body>
</html>
