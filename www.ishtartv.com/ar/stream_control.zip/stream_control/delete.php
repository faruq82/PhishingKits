<?php include "layout_header.php"; ?>
<?php include "layout_card_header.php"; ?>

<?php
	
	$id = $_REQUEST['id'];
  
  # display row name
  $sql = "SELECT `$query_field` FROM `$table` WHERE `$field`=? LIMIT 1";
  $res = $pdo->prepare($sql);
  $res->execute(array($id));


  $a = $res->fetch(PDO::FETCH_ASSOC);

  if(isset($_POST['yes'])) {
	 
	   $sql = "DELETE FROM `$table` WHERE `$field`=? LIMIT 1";
     $result = $pdo->prepare($sql);
     $result->execute(array($id));
?>
  <div class="alert alert-success">
      <button type="button" aria-hidden="true" class="close">
          <i class="material-icons">close</i>
      </button>
      <span>
        <i class="material-icons">check</i>
          تم الحذف
      </span>
  </div>
  
  <a href='<?php echo $back; ?>' class="btn btn-info"> الرجوع </a>

<?php	
    
	}
	elseif(isset($_POST['no'])) { echo '<meta http-equiv="refresh" content="0;URL='.$back.'" />'; }
 	else {
?>
<h4><i class="material-icons">cancel</i> هل أنت متأكد من حذف (<?php echo $a[$query_field]; ?>)؟</h4>

<form id="form1" name="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']?>">
      <input type="hidden" name="id" value="<?php echo $id ?>" />
      <label>
      <input name="yes" type="submit" class="btn btn-danger" id="yes" value=" نعم" />
      <input name="no" type="submit" class="btn" id="no" value="لا" />
      </label>
    </form>
    
<?php
}
?>

<?php include "layout_card_footer.php"; ?>
<?php include "layout_footer.php"; ?>