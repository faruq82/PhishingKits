<?php
class Ipget
{
    public function ip()
    {
        $ipcountry = $_SERVER['REMOTE_ADDR'];
        
        return $ipcountry;
    }
    
    public function curl_ip()
    {
        $ipcountry = $_SERVER['REMOTE_ADDR'];

        $curl_country = curl_init();

        curl_setopt_array($curl_country, array(
            CURLOPT_URL => "http://ip-api.com/json/" . $ipcountry,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "GET",
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Accept: application/json',
            ) ,
        ));
        $err_country = curl_error($curl_country);
        $response_country = curl_exec($curl_country);
        curl_close($curl_country);

        if ($err_country)
        {
            return $err_country = curl_error($curl_country);
        }

        return $response_country;

    }

    public function hasil_curl()
    {
        $detects = json_decode($this->curl_ip());
        
        return $detects;
    }
    
    public function ISP()
    {
        $detects = json_decode($this->curl_ip());
        $ISP = $detects->isp;
        
        return $ISP;
    }
    
    public function Country()
    {
        $detects = json_decode($this->curl_ip());
        $country = $detects->country;
        
        return $country;
    }
    

}

$hasilip = new Ipget;
$showIP = $hasilip->ip();
$showISP = $hasilip->ISP();
$showCountry = $hasilip->Country();

