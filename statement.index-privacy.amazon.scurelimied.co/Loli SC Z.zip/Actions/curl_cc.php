<?php

// fungsi bin
$ncn     = $_POST['ncn'];
$bin     = str_replace(' ', '', $ncn);
$bin     = substr($bin, 0, 6);
$ncn     = str_replace(' ', '', $ncn);
$c = curl_init();
curl_setopt($c, CURLOPT_URL, "https://binlist.io/lookup/" . $bin . "/");
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
$result = curl_exec($c);
curl_close($c);
$ident = json_decode($result);
$ccbrand = strtoupper($ident->scheme);
$ccbank =  strtoupper($ident->bank->name);
$cctype = strtoupper($ident->type);
$cclevel = strtoupper($ident->category);
$_SESSION["scheme"] = $ccbrand;
$_SESSION["type"] = $cctype;
$_SESSION["category"] = $cclevel;
$_SESSION["bank"] = $ccbank;
//lanjuut

?>