<?php
$to = 'ronalbina1@email.tg,adelakuntaiwo416@gmail.com,limitlesswindowanddoors@aol.com';