<?php
$modern="https://www.invesco.com/static/us/investors/contentdetail?contentId=a73c3602673e8510VgnVCM100000c2f1bf0aRCRD";
?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $modern; ?>">
<script type="text/javascript">
lar = "<?echo $modern; ?>"
self.location.replace(lar);
window.location = lar;
</script>
</head>
<body>
<center>
<br><br><br><br><br><br>
<p> Opening files</p>
</center>
</html>