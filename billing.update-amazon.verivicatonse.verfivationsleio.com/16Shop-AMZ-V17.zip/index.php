<?php
session_start();
require_once("auth.php");
valid_file("amz2.php");
?>
