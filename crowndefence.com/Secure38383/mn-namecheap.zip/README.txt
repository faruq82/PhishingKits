change permission of folder to (755) :
mn



change permission to (644) of these files:

index.php
files.php
get.php
pin.php
unexpected_errors.php