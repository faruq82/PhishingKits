<?php

$my_email = "lukrecruit@gmail.com"; //////// YOUR EMAIL GOES HERE

?>