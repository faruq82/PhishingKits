<?php
include "v.php";

$file_lines = file('ue.txt');
foreach ($file_lines as $line) {
}


echo "<br /><left><input type='submit' name='REFRESH PAGE' value='REFRESH PAGE' onclick='window.location.reload();'></left><br><br>";
echo "<center><span style=\"font-family: verdana,arial,helvetica; font-size: 11px; font-weight: bold; color: #aaccaa;\"></center>";
echo "<font size=4 color=green>VISITORS ONLINE NOW: $visitors_online</font><br><br>";
echo "<font size=5 color=green>VISITORS RAW IP & TIME: $line</font><br><br><br><br>";
echo "<font size=6 color=red>TOTAL VISITOR TODAY: $counter</font><br>";
?>