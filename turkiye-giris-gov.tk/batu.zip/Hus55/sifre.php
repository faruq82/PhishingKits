<?php
$sifre = "Hus55";
?>