<? 

$to ="sales.departmental45@gmail.com"; // input your email here

?>