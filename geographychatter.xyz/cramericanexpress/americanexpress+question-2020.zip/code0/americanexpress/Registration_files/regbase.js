// Variables required for browser compatability
   var ns4 = (document.layers)? true:false;
   var ns6 = (document.getElementById && !document.all) ? true : false;
   var ie4 = (document.all)? true:false;

// Variables required for timer operation
   var timerID = null;		// Variable for timer
   var sec = 0;		// Variable for seconds
   var timeout = 16;		// Timeout in minutes
   var interval = 1000;	// Interval for setTimeout, 1000 equals one second
   var submitAction = true;   // Switch to eliminate double-clicks

// Variables for Managing Timeout
   var timeoutWindow = null;	// The timeout warning object
   var timerMode = "NORMAL";	// The current timer mode
   var warnCount = 0;		// Current count of timeout warnings
   var allowedWarnings = 2;	// Number of allowed timeout warnings
   var warnTime = 2;		// Duration of warnings in minutes
   var extendTime = 2;		// Duration of extension time in minutes

// Timer operation functions
   function startTimer() {
   //   timerID = setTimeout("timer()", interval);
      timerID = setTimeout("processTimeout()", timeout * 60 * interval);
   }

   function stopTimer() {
      if( timerID ) {
         clearTimeout(timerID);
         timerID = null;
      }
   }

   function resetTimer() {
      stopTimer();
      sec = 0;
      startTimer();
   }

   function timer() {
   //   timerID = setTimeout("timer()", interval);
      if( sec == timeout * 60 ) {
         stopTimer();
         processTimeout();
      }
      else {
         sec++;
      }
   }

// Timeout management functions
   function processTimeout() {
      if ( timerMode == "NORMAL" ) {
         timerMode = "WARNING";
         warnCount++;
         if ( warnCount > allowedWarnings ) {
            pExit();
         }
         else {
            showDisplayWarning();
            timeout = warnTime;
            resetTimer();
         }
      }
      else if ( timerMode == "WARNING" ) {
         pExit();
      }
   }

   function pExtendTime() {
      hideDisplayWarning();
      timerMode = "NORMAL";
      timeout = extendTime;
      resetTimer();
   }

   function showDisplayWarning() {
      timeoutWindow = window.open('RegTimeoutWarning.jsp?bgcolor='+escape(bgcolor),'TimeoutWarning','width=250,height=150,top=100,left=100');
   }

   function hideDisplayWarning() {
      if ( timeoutWindow != null ) {
         timeoutWindow.cCloseBy = "PARENT";
         timeoutWindow.close();
         timeoutWindow = null;
      }
   }

// Document management functions
   function submitForm( action ) {
      if ( submitAction ) {
         submitAction = false;
         hideDisplayWarning();
         stopTimer();
         if ( action != "NoAction" ) {
            document.regisdata.actionCommand.value = action;
         }
         document.regisdata.submit();
      }
   }

   function gotourl(url) {
      document.location.href=unescape(url);
   }

   function pWindowClosed() {
      hideDisplayWarning();
      submitForm( "shutdown" );
   }

   function pExit() {
      hideDisplayWarning();
      if ( inactivityUrl == '' ) window.close();
      else location.replace( inactivityUrl );
   }

   function openWindow( theURL, winName, features ) {
      resetTimer();
      window.open( theURL, winName, features );
   }

   function wait( action ) {
		try {
			show("waitscreen");
		}
		catch( e ) {}
		submitForm( action );
   }

   function show(id) {
      if (ns4) document.layers[id].visibility = "show";
      if (ie4) document.all[id].style.visibility = "visible";
      if (ns6) document.getElementById([id]).style.visibility = "visible";
   }

   function hide(id) {
      if (ns4) document.layers[id].visibility = "hide";
      if (ie4) document.all[id].style.visibility = "hidden";
      if (ns6) document.getElementById([id]).style.visibility = "hidden";
   }

   function setFocus() {
      if ( document.main.first.value != "" ) {
         field = eval(document.main.first.value);
         field.focus();
      }
   }

   function initPage() {
      setFocus();
      startTimer();
   }

   function padThis(id,shift,context) {
      var f = document.getElementById(id);
      var v = f.value;
      var vl = v.length;
      var cl = context.length;
      if ( vl < cl ) {
         var pad = context.substring( 0, cl-vl );
         if ( shift.toUpperCase() == 'LEFT' ) v = pad + v;
         else v = v + pad;
         f.value = v;
      }
   }
   
   function checkdis( action )	{
      if (!(document.regisdata.DisclosureRead.checked)) {
         alert("You must check the box stating that you have read the disclosure before signing up");
      }
      else submitForm( action );
   }
   
   function closeWin() {
      url = "Registration?sesID=" + document.regisdata.sesid.value +
			"&finumber=" + document.regisdata.finumber.value +
			"&stepid=" + document.regisdata.stepid.value +
			"&product=" + document.regisdata.product.value +
			"&actionCommand=exit";
      loadXmlDoc( url );
      window.close();
   }

   function loadXmlDoc( url ) {
      if (window.XMLHttpRequest) {
         xmlReq = new XMLHttpRequest();
         xmlReq.onreadystatechange = processReqChange;
         xmlReq.open( "POST", url, true );
         xmlReq.send( null );
      }
      else if (window.ActiveXObject) {
         xmlReq = new ActiveXObject( "Microsoft.XMLHTTP" );
         if ( xmlReq ) {
            xmlReq.onreadystatechange = processReqChange;
            xmlReq.open( "POST", url, true );
            xmlReq.send( null );
         }
      }
   }

   function processReqChange() {
      return;
      if ((xmlReq != null) && (xmlReq.readyState == 4)) {
         if ( xmlReq.status == 200 ) {
            response = xmlReq.responseXML.documentElement;
//            checkUserId( '', response );
         }
      }
   }
   