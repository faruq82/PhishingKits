function addEvent(elm, evType, fn, useCapture) {
	if (elm.addEventListener) { 
		elm.addEventListener(evType, fn, useCapture); 
		return true; 
	}
	else if (elm.attachEvent) { 
		var r = elm.attachEvent('on' + evType, fn); 
		EventCache.add(elm, evType, fn);
		return r; 
	}
	else {
		elm['on' + evType] = fn;
	}
}

function getEventSrc(e) {
	if (!e) e = window.event;
	if (e.originalTarget) return e.originalTarget;
	else if (e.srcElement) return e.srcElement;
}

function addLoadEvent(func) {
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	}
	else {
		window.onload = 
			function() {
				oldonload();
				func();
			}
	}
}

var EventCache = function(){
	var listEvents = [];
	return {
		listEvents : listEvents,
	
		add : function(node, sEventName, fHandler, bCapture){
			listEvents.push(arguments);
		},
	
		flush : function(){
			var i, item;
			for(i = listEvents.length - 1; i >= 0; i = i - 1){
				item = listEvents[i];
				
				if(item[0].removeEventListener){
					item[0].removeEventListener(item[1], item[2], item[3]);
				};
				
				/* From this point on we need the event names to be prefixed with 'on" */
				if(item[1].substring(0, 2) != "on"){
					item[1] = "on" + item[1];
				};
				
				if(item[0].detachEvent){
					item[0].detachEvent(item[1], item[2]);
				};
				
				item[0][item[1]] = null;
			};
		}
	};
}();

addEvent(window,'unload',EventCache.flush, false);

var toolTipLib = { 
	xCord : 0,
	yCord : 0,
	obj : null,
	tipElements : ['a','abbr','acronym','div'],
	attachToolTipBehavior: function() {
		if ( !document.getElementById ||
			!document.createElement ||
			!document.getElementsByTagName ) {
			return;
		}
		var i,j;
		addEvent(document,'mousemove',toolTipLib.updateXY,false);
		if ( document.captureEvents ) {
				document.captureEvents(Event.MOUSEMOVE);
		}
		for ( i=0;i<toolTipLib.tipElements.length;i++ ) {
			var current = document.getElementsByTagName(toolTipLib.tipElements[i]);
			for ( j=0;j<current.length;j++ ) {
				var tiptext = current[j].getAttribute('title');
				if ( tiptext != null && tiptext != "" ) {
					addEvent(current[j],'mouseover',toolTipLib.tipOver,false);
					addEvent(current[j],'mouseout',toolTipLib.tipOut,false);
					current[j].setAttribute('tip',tiptext);
					current[j].removeAttribute('title');
				}
			}
		}
	},
	updateXY : function(e) {
		if ( document.captureEvents ) {
			toolTipLib.xCord = e.pageX;
			toolTipLib.yCord = e.pageY;
		} else if ( window.event.clientX ) {
			toolTipLib.xCord = window.event.clientX+document.documentElement.scrollLeft;
			toolTipLib.yCord = window.event.clientY+document.documentElement.scrollTop;
		}
	},
	tipOut: function(e) {
		if ( window.tID ) {
			clearTimeout(tID);
		}
		if ( window.opacityID ) {
			clearTimeout(opacityID);
		}
		var l = getEventSrc(e);
		var div = document.getElementById('toolTip');
		if ( div ) {
			div.parentNode.removeChild(div);
		}
		showallselectboxes();
		window.status = "";
	},
	checkNode : function(obj) {
		var trueObj = obj;
		var nodenm = trueObj.nodeName.toLowerCase();
		var ret;
		for ( i=0;i<toolTipLib.tipElements.length;i++ ) {
			if ( nodenm == toolTipLib.tipElements[i] ) {
				ret = trueObj;
				i = toolTipLib.tipElements.length;
			}
		}
		if (!ret) ret = trueObj.parentNode;
		return ret;
	},
	tipOver : function(e) {
		toolTipLib.obj = getEventSrc(e);
		tID = setTimeout("toolTipLib.tipShow()",500)
	},
	tipShow : function() {
		hideallselectboxes();
		var newDiv = document.createElement('div');
		var scrX = Number(toolTipLib.xCord);
		var scrY = Number(toolTipLib.yCord);
		var tp = parseInt(scrY+15);
		var lt = parseInt(scrX+10);
		var anch = toolTipLib.checkNode(toolTipLib.obj);
		var addy = '';
		var access = '';
		var nodenm = anch.nodeName.toLowerCase();
		if ( nodenm == 'a' ) {
			addy = (anch.href.length > 25 ? anch.href.toString().substring(0,25)+"..." : anch.href);
			var access = ( anch.accessKey ? ' <span>['+anch.accessKey+']</span> ' : '' );
		} else {
			addy = anch.firstChild.nodeValue;
		}
		newDiv.id = 'toolTip';
		document.getElementsByTagName('body')[0].appendChild(newDiv);
		newDiv.style.opacity = '.1';
		newDiv.innerHTML = "<p>"+anch.getAttribute('tip')+"<em>"+access+addy+"</em></p>";
		if ( parseInt(document.documentElement.clientWidth+document.documentElement.scrollLeft) < parseInt(newDiv.offsetWidth+lt) ) {
			newDiv.style.left = parseInt(lt-(newDiv.offsetWidth+10))+'px';
		} else {
			newDiv.style.left = lt+'px';
		}
		if ( parseInt(document.documentElement.clientHeight+document.documentElement.scrollTop) < parseInt(newDiv.offsetHeight+tp) ) {
			newDiv.style.top = parseInt(tp-(newDiv.offsetHeight+10))+'px';
		} else {
			newDiv.style.top = tp+'px';
		}
		toolTipLib.tipFade('toolTip',10);
		window.status = anch.getAttribute('tip');
	},
	tipFade: function(div,opac) {
		var obj = document.getElementById(div);
		var passed = parseInt(opac);
		var newOpac = parseInt(passed+10);
		if ( newOpac < 90 ) {
			obj.style.opacity = '.'+newOpac;
			obj.style.filter = "alpha(opacity:"+newOpac+")";
			opacityID = setTimeout("toolTipLib.tipFade('toolTip','"+newOpac+"')",20);
		}
		else { 
			obj.style.opacity = '.99';
			obj.style.filter = "alpha(opacity:99)";
		}
	}
};

var selectboxes = new Array();

function hideallselectboxes() {
	if (document.all) {
		selectboxes = new Array();
		for(ix=0; ix < document.forms[0].elements.length; ix++) {
			objectid = document.forms[0].elements[ix].id;
			objectx = document.forms[0].elements[ix];
			if (document.forms[0].elements[ix].type == "select-one") {
				if(document.forms[0].elements[ix].visibility != "hidden") {
					selectboxes[selectboxes.length] = ix;
					document.forms[0].elements[ix].style.visibility = "hidden";
//					alert("id="+selectboxes[selectboxes.length-1]);
				}
			}
		}
	}
}

function showallselectboxes() {
	if (document.all) {
//	alert("selectboxes.length="+selectboxes.length);
		for(ix=0; ix < selectboxes.length; ix++) {
//			alert("id="+selectboxes[ix]);
			document.forms[0].elements[selectboxes[ix]].style.visibility = "visible";
		}
	}
}

addEvent(window,'load',toolTipLib.attachToolTipBehavior,false);