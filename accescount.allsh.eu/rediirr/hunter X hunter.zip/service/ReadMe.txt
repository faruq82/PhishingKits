*******************
Hunter x Hunter V2
*******************
email.php ----> $adresse_email ="taboiterez";
Scama (True login, True CC,VBV 3D secure cod) Cni|Passeport|Permis de conduire|Justificatif de domicile.

Base Yakuza V2
Remasterezed by isoka


Pour bloquer les ip allez dans
.htacess
Repérer < ' deny from 88.22.44.66/22 ' >
l'ip est bloqué sur le port 22 ssh
----------------------------------------------------------------------------------------------------------------------