<?php
error_reporting(0);
session_start();
include('../lang/language.php');
include('../card_details.php');
?>