<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Continue</title>
<link rel="shortcut icon" href="images/fav_office.ico" />
<meta HTTP-EQUIV="REFRESH" content="2;index_all.php">
<style type="text/css">
body
{
   background-color: #FFFFFF;
   background-image: url(images/bg.png);
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:1366px;height:124px;text-align:left;z-index:0;">
<img src="images/ori.png" id="Image2" alt="" align="top" border="0" style="width:1366px;height:124px;"></div>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:619px;top:351px;width:32px;height:32px;text-align:left;z-index:1;">
<img src="images/load.gif" id="Image1" alt="" align="top" border="0" style="width:32px;height:32px;"></div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:313px;height:124px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:2;">
<a href="index.php"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:313px;height:124px;"></a></div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:1159px;top:8px;width:183px;height:43px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:3;">
<a href="index.php"><img src="images/klik.png" id="Image4" alt="" align="top" border="0" style="width:183px;height:43px;"></a></div>
<div id="bv_Image5" style="margin:0;padding:0;position:absolute;left:1223px;top:65px;width:111px;height:51px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:4;">
<a href="index.php"><img src="images/klik.png" id="Image5" alt="" align="top" border="0" style="width:111px;height:51px;"></a></div>
</body>
</html>