define("poly/lib/_base", [ "require", "exports", "module" ], function(require, exports) {
    var toString;
    toString = {}.toString, exports.isFunction = function(o) {
        return "function" == typeof o;
    }, exports.isString = function(o) {
        return "[object String]" == toString.call(o);
    }, exports.toString = function(o) {
        return toString.apply(o);
    }, exports.createCaster = function(caster, name) {
        return function(o) {
            if (null == o) throw new TypeError(name + " method called on null or undefined");
            return caster(o);
        };
    };
}), define("poly/object", [ "./lib/_base" ], function() {
    function createFlameThrower(feature) {
        return function() {
            throw new Error("poly/object: " + feature + " is not safely supported.");
        };
    }
    function has(feature) {
        var prop = featureMap[feature];
        return prop in refObj;
    }
    function PolyBase() {}
    function hasProp(object, name) {
        return object.hasOwnProperty(name);
    }
    function _keys(object) {
        var result = [];
        for (var p in object) hasProp(object, p) && result.push(p);
        return result;
    }
    function failIfShimmed(failTest) {
        var shouldThrow;
        shouldThrow = "function" == typeof failTest ? failTest : function() {
            return failTest;
        };
        for (var feature in shims) Object[feature] = shouldThrow(feature) ? createFlameThrower(feature) : shims[feature];
    }
    function assertIsObject(o) {
        if ("object" != typeof o) throw new TypeError("Object.getPrototypeOf called on non-object");
    }
    var refObj, refProto, has__proto__, hasNonEnumerableProps, getPrototypeOf, keys, featureMap, shims, secrets, protoSecretProp, undef, hasOwnProp = "hasOwnProperty";
    return refObj = Object, refProto = refObj.prototype, has__proto__ = "object" == typeof {}.__proto__, 
    hasNonEnumerableProps = function() {
        for (var p in {
            valueOf: 1
        }) return !1;
        return !0;
    }(), getPrototypeOf = has__proto__ ? function(object) {
        return assertIsObject(object), object.__proto__;
    } : function(object) {
        return assertIsObject(object), protoSecretProp && object[protoSecretProp](secrets) ? object[protoSecretProp](secrets.proto) : object.constructor ? object.constructor.prototype : refProto;
    }, keys = hasNonEnumerableProps ? function(masked) {
        return function(object) {
            for (var m, result = _keys(object), i = 0; m = masked[i++]; ) hasProp(object, m) && result.push(m);
            return result;
        };
    }([ "constructor", hasOwnProp, "isPrototypeOf", "propertyIsEnumerable", "toString", "toLocaleString", "valueOf" ]) : _keys, 
    featureMap = {
        "object-create": "create",
        "object-freeze": "freeze",
        "object-isfrozen": "isFrozen",
        "object-seal": "seal",
        "object-issealed": "isSealed",
        "object-getprototypeof": "getPrototypeOf",
        "object-keys": "keys",
        "object-getownpropertynames": "getOwnPropertyNames",
        "object-defineproperty": "defineProperty",
        "object-defineproperties": "defineProperties",
        "object-isextensible": "isExtensible",
        "object-preventextensions": "preventExtensions",
        "object-getownpropertydescriptor": "getOwnPropertyDescriptor"
    }, shims = {}, secrets = {
        proto: {}
    }, protoSecretProp = !has("object-getprototypeof") && !has__proto__ && hasNonEnumerableProps && hasOwnProp, 
    protoSecretProp && function(_hop) {
        refProto[hasOwnProp] = function(name) {
            return name == protoSecretProp ? !1 : _hop.call(this, name);
        };
    }(refProto[hasOwnProp]), has("object-create") || (Object.create = shims.create = function(proto, props) {
        var obj;
        if ("object" != typeof proto) throw new TypeError("prototype is not of type Object or Null.");
        if (PolyBase.prototype = proto, obj = new PolyBase(), PolyBase.prototype = null, 
        protoSecretProp) {
            var orig = obj[protoSecretProp];
            obj[protoSecretProp] = function(name) {
                return name == secrets ? !0 : name == secrets.proto ? proto : orig.call(this, name);
            };
        }
        return arguments.length > 1 && Object.defineProperties(obj, props), obj;
    }), has("object-freeze") || (Object.freeze = shims.freeze = function(object) {
        return object;
    }), has("object-isfrozen") || (Object.isFrozen = shims.isFrozen = function() {
        return !1;
    }), has("object-seal") || (Object.seal = shims.seal = function(object) {
        return object;
    }), has("object-issealed") || (Object.isSealed = shims.isSealed = function() {
        return !1;
    }), has("object-getprototypeof") || (Object.getPrototypeOf = shims.getPrototypeOf = getPrototypeOf), 
    has("object-keys") || (Object.keys = keys), has("object-getownpropertynames") || (Object.getOwnPropertyNames = shims.getOwnPropertyNames = function(object) {
        return keys(object);
    }), has("object-defineproperty") && has("object-defineproperties") || (Object.defineProperty = shims.defineProperty = function(object, name, descriptor) {
        return object[name] = descriptor && descriptor.value, object;
    }), has("object-defineproperties") && has("object-create") || (Object.defineProperties = shims.defineProperties = function(object, descriptors) {
        var names, name;
        for (names = keys(descriptors); name = names.pop(); ) Object.defineProperty(object, name, descriptors[name]);
        return object;
    }), has("object-isextensible") || (Object.isExtensible = shims.isExtensible = function(object) {
        var prop = "_poly_";
        try {
            for (;prop in object; ) prop += "_";
            return object[prop] = 1, hasProp(object, prop);
        } catch (ex) {
            return !1;
        } finally {
            try {
                delete object[prop];
            } catch (ex) {}
        }
    }), has("object-preventextensions") || (Object.preventExtensions = shims.preventExtensions = function(object) {
        return object;
    }), has("object-getownpropertydescriptor") || (Object.getOwnPropertyDescriptor = shims.getOwnPropertyDescriptor = function(object, name) {
        return hasProp(object, name) ? {
            value: object[name],
            enumerable: !0,
            configurable: !0,
            writable: !0
        } : undef;
    }), {
        failIfShimmed: failIfShimmed
    };
}), define("poly/string", [ "./lib/_base" ], function(base) {
    function checkFeature(feature) {
        var prop = featureMap[feature];
        return base.isFunction(proto[prop]);
    }
    function neg() {
        return !1;
    }
    function remove(str, rx) {
        return str.replace(rx, "");
    }
    function checkShims() {
        has("string-trim") || (proto.trim = function() {
            return remove(remove(toString(this), trimLeftRx), trimRightRx);
        }), has("string-trimleft") || (proto.trimLeft = function() {
            return remove(toString(this), trimLeftRx);
        }), has("string-trimright") || (proto.trimRight = function() {
            return remove(toString(this), trimRightRx);
        });
    }
    var featureMap, has, toString, proto = String.prototype;
    featureMap = {
        "string-trim": "trim",
        "string-trimleft": "trimLeft",
        "string-trimright": "trimRight"
    }, has = checkFeature, toString = base.createCaster(String, "String");
    var trimRightRx, trimLeftRx;
    return trimRightRx = /\s+$/, trimLeftRx = /^\s+/, checkShims(), {
        setWhitespaceChars: function(wsc) {
            trimRightRx = new RegExp(wsc + "$"), trimLeftRx = new RegExp("^" + wsc), has = neg, 
            checkShims();
        }
    };
}), function(origDate) {
    define("poly/date", [ "./lib/_base" ], function(base) {
        function has(feature) {
            var prop = featureMap[feature];
            return prop in origDate || prop in origProto;
        }
        function isInvalidDate(date) {
            return !isFinite(date);
        }
        function fix2(number) {
            return (10 > number ? "0" : "") + number;
        }
        function isoParse(str) {
            var result;
            return result = invalidDate, str.replace(isoParseRx, function(a, y, m, d, h, n, s, ms, tzs, tzh, tzm) {
                var adjust = 0;
                return y >= 0 && 100 > y && (y = +y + 400, adjust = -126227808e5), result = Date.UTC(y, (m || 1) - 1, d || 1, h || 0, n || 0, s || 0, ms || 0) + adjust, 
                tzh = +(tzs + tzh), tzm = +(tzs + tzm), (tzh || tzm) && (result -= 36e5 * (tzh + tzm / 60), 
                (tzh > 23 || -23 > tzh || tzm > 59) && (result = invalidDate), result > maxDate && (result = invalidDate)), 
                "";
            }), result;
        }
        function checkIsoCompat() {
            var newDate = function() {
                return function(y, m, d, h, mn, s, ms) {
                    var len, result;
                    return this instanceof newDate ? (len = arguments.length, result = 0 === len ? new origDate() : 1 === len ? new origDate(base.isString(y) ? newDate.parse(y) : y) : new origDate(y, m, d == undef ? 1 : d, h || 0, mn || 0, s || 0, ms || 0), 
                    result.constructor = newDate, result) : origDate.apply(this, arguments);
                };
            }();
            isoCompat() ? Date != origDate && (Date = origDate) : (newDate.now = origDate.now, 
            newDate.UTC = origDate.UTC, newDate.prototype = origProto, newDate.prototype.constructor = newDate, 
            newDate.parse = function(str) {
                var result;
                return result = isoParse("" + str), isInvalidDate(result) && (result = origParse(str)), 
                result;
            }, copyPropsSafely(newDate, origDate), Date = newDate);
        }
        function copyPropsSafely(dst, src) {
            for (var p in src) ownProp.call(src, p) && !ownProp.call(dst, p) && (dst[p] = src[p]);
        }
        var origProto, origParse, featureMap, maxDate, invalidDate, isoCompat, isoParseRx, ownProp, undef;
        return origProto = origDate.prototype, origParse = origDate.parse, ownProp = Object.prototype.hasOwnProperty, 
        maxDate = 864e13, invalidDate = 0/0, isoCompat = function() {
            return origDate.parse("+275760-09-13T00:00:00.000Z") == maxDate;
        }, isoParseRx = /^([+\-]\d{6}|\d{4})(?:-(\d{2}))?(?:-(\d{2}))?(?:T(\d{2}):(\d{2})(?::(\d{2})(?:.(\d{1,3}))?)?(?:Z|([+\-])(\d{2})(?::(\d{2}))?)?)?$/, 
        featureMap = {
            "date-now": "now",
            "date-tojson": "toJSON",
            "date-toisostring": "toISOString"
        }, has("date-now") || (origDate.now = function() {
            return +new Date();
        }), has("date-toisostring") || (origProto.toISOString = function() {
            if (isInvalidDate(this)) throw new RangeError("toISOString called on invalid value");
            return [ this.getUTCFullYear(), "-", fix2(this.getUTCMonth() + 1), "-", fix2(this.getUTCDate()), "T", fix2(this.getUTCHours()), ":", fix2(this.getUTCMinutes()), ":", fix2(this.getUTCSeconds()), ".", (this.getUTCMilliseconds() / 1e3).toFixed(3).slice(2), "Z" ].join("");
        }), has("date-tojson") || (origProto.toJSON = function() {
            return this.toISOString();
        }), checkIsoCompat(), {
            setIsoCompatTest: function(testFunc) {
                isoCompat = testFunc, checkIsoCompat();
            }
        };
    });
}(Date), define("poly/array", [ "./lib/_base" ], function(base) {
    function toArrayLike(o) {
        return "[object String]" == base.toString(o) ? o.split("") : toObject(o);
    }
    function isArray(o) {
        return "[object Array]" == toString.call(o);
    }
    function has(feature) {
        var prop = featureMap[feature];
        return base.isFunction(proto[prop]);
    }
    function returnTruthy() {
        return 1;
    }
    function returnValue(val) {
        return val;
    }
    function _iterate(arr, lambda, continueFunc, context, start, inc) {
        var alo, len, i, end;
        if (alo = toArrayLike(arr), len = alo.length >>> 0, start === undef && (start = 0), 
        inc || (inc = 1), end = 0 > inc ? -1 : len, !base.isFunction(lambda)) throw new TypeError(lambda + " is not a function");
        if (start == end) return !1;
        if (end >= start ^ inc > 0) throw new TypeError("Invalid length or starting index");
        for (i = start; i != end; i += inc) if (i in alo && !continueFunc(lambda.call(context, alo[i], i, alo), i, alo[i])) return !1;
        return !0;
    }
    var featureMap, toObject, _reduce, _find, undef, proto = Array.prototype, toString = {}.toString;
    featureMap = {
        "array-foreach": "forEach",
        "array-every": "every",
        "array-some": "some",
        "array-map": "map",
        "array-filter": "filter",
        "array-reduce": "reduce",
        "array-reduceright": "reduceRight",
        "array-indexof": "indexOf",
        "array-lastindexof": "lastIndexOf"
    }, toObject = base.createCaster(Object, "Array"), has("array-foreach") || (proto.forEach = function(lambda) {
        _iterate(this, lambda, returnTruthy, arguments[1]);
    }), has("array-every") || (proto.every = function(lambda) {
        return _iterate(this, lambda, returnValue, arguments[1]);
    }), has("array-some") || (proto.some = function(lambda) {
        return _iterate(this, lambda, function(val) {
            return !val;
        }, arguments[1]);
    }), has("array-map") || (proto.map = function(lambda) {
        var arr, result;
        return arr = this, result = new Array(arr.length), _iterate(arr, lambda, function(val, i) {
            return result[i] = val, 1;
        }, arguments[1]), result;
    }), has("array-filter") || (proto.filter = function(lambda) {
        var arr, result;
        return arr = this, result = [], _iterate(arr, lambda, function(val, i, orig) {
            return val && result.push(orig), 1;
        }, arguments[1]), result;
    }), has("array-reduce") && has("array-reduceright") || (_reduce = function(reduceFunc, inc, initialValue, hasInitialValue) {
        var reduced, startPos, initialValuePos;
        if (startPos = initialValuePos = inc > 0 ? -1 : toArrayLike(this).length >>> 0, 
        hasInitialValue) reduced = initialValue; else if (_iterate(this, returnValue, function(val, i) {
            reduced = val, initialValuePos = i;
        }, null, startPos + inc, inc), initialValuePos == startPos) throw new TypeError();
        return _iterate(this, function(item, i, arr) {
            reduced = reduceFunc(reduced, item, i, arr);
        }, returnTruthy, null, initialValuePos + inc, inc), reduced;
    }, has("array-reduce") || (proto.reduce = function(reduceFunc) {
        return _reduce.call(this, reduceFunc, 1, arguments[1], arguments.length > 1);
    }), has("array-reduceright") || (proto.reduceRight = function(reduceFunc) {
        return _reduce.call(this, reduceFunc, -1, arguments[1], arguments.length > 1);
    })), has("array-indexof") && has("array-lastindexof") || (_find = function(arr, item, from, forward) {
        var len = toArrayLike(arr).length >>> 0, foundAt = -1;
        return from = isNaN(from) ? forward ? 0 : len - 1 : Number(from), 0 > from && (from = len + from - 1), 
        _iterate(arr, returnValue, function(val, i) {
            return val === item && (foundAt = i), -1 == foundAt;
        }, null, from, forward ? 1 : -1), foundAt;
    }, has("array-indexof") || (proto.indexOf = function(item) {
        return _find(this, item, arguments[1], !0);
    }), has("array-lastindexof") || (proto.lastIndexOf = function(item) {
        return _find(this, item, arguments[1], !1);
    })), Array.isArray || (Array.isArray = isArray);
}), define("poly/function", [ "./lib/_base" ], function(base) {
    function has(feature) {
        var prop = featureMap[feature];
        return base.isFunction(proto[prop]);
    }
    var bind, featureMap, slice = [].slice, proto = Function.prototype;
    return featureMap = {
        "function-bind": "bind"
    }, has("function-bind") || (bind = function(obj) {
        var args = slice.call(arguments, 1), self = this, nop = function() {}, bound = function() {
            return self.apply(this instanceof nop ? this : obj || {}, args.concat(slice.call(arguments)));
        };
        return nop.prototype = this.prototype || {}, bound.prototype = new nop(), bound;
    }, proto.bind = bind), {};
}), define("poly/xhr", [], function() {
    function assignCtor(ctor) {
        window.XMLHttpRequest = ctor;
    }
    function tryProgId(progId) {
        try {
            return new ActiveXObject(progId), assignCtor(function() {
                return new ActiveXObject(progId);
            }), !0;
        } catch (ex) {}
    }
    var progIds;
    if ("undefined" == typeof XMLHttpRequest) for (assignCtor(function() {
        throw new Error("poly/xhr: XMLHttpRequest not available");
    }), progIds = [ "Msxml2.XMLHTTP", "Microsoft.XMLHTTP", "Msxml2.XMLHTTP.4.0" ]; progIds.length && tryProgId(progIds.shift()); ) ;
}), function(global) {
    define("poly/setImmediate", [ "./lib/_base" ], function(base) {
        function has(name) {
            return base.isFunction(testCache[name]) && (testCache[name] = testCache[name](global)), 
            testCache[name];
        }
        function add(name, test, now) {
            testCache[name] = now ? test(global, d, el) : test;
        }
        function aliasMicrosoftImplementation(attachTo) {
            attachTo.setImmediate = global.msSetImmediate, attachTo.clearImmediate = global.msClearImmediate;
        }
        function installPostMessageImplementation(attachTo) {
            function isStringAndStartsWith(string, putativeStart) {
                return "string" == typeof string && string.substring(0, putativeStart.length) === putativeStart;
            }
            function onGlobalMessage(event) {
                if (event.source === global && isStringAndStartsWith(event.data, MESSAGE_PREFIX)) {
                    var handle = event.data.substring(MESSAGE_PREFIX.length);
                    tasks.runIfPresent(handle);
                }
            }
            var MESSAGE_PREFIX = "cujojs/poly.setImmediate" + Math.random();
            global.addEventListener("message", onGlobalMessage, !1), attachTo.setImmediate = function() {
                var handle = tasks.addFromSetImmediateArguments(arguments);
                return global.postMessage(MESSAGE_PREFIX + handle, "*"), handle;
            };
        }
        function installReadyStateChangeImplementation(attachTo) {
            attachTo.setImmediate = function() {
                var handle = tasks.addFromSetImmediateArguments(arguments), scriptEl = global.document.createElement("script");
                return scriptEl.onreadystatechange = function() {
                    tasks.runIfPresent(handle), scriptEl.onreadystatechange = null, scriptEl.parentNode.removeChild(scriptEl), 
                    scriptEl = null;
                }, global.document.documentElement.appendChild(scriptEl), handle;
            };
        }
        function installSetTimeoutImplementation(attachTo) {
            attachTo.setImmediate = function() {
                var handle = tasks.addFromSetImmediateArguments(arguments);
                return global.setTimeout(function() {
                    tasks.runIfPresent(handle);
                }, 0), handle;
            };
        }
        var testCache, tasks;
        testCache = {}, tasks = function() {
            function Task(handler, args) {
                this.handler = handler, this.args = Array.prototype.slice.call(args);
            }
            var nextHandle, tasksByHandle, currentlyRunningATask;
            return nextHandle = 1, tasksByHandle = {}, currentlyRunningATask = !1, Task.prototype.run = function() {
                if (base.isFunction(this.handler)) this.handler.apply(void 0, this.args); else {
                    var scriptSource = "" + this.handler;
                    eval(scriptSource);
                }
            }, {
                addFromSetImmediateArguments: function(args) {
                    var handler, argsToHandle, task, thisHandle;
                    return handler = args[0], argsToHandle = Array.prototype.slice.call(args, 1), task = new Task(handler, argsToHandle), 
                    thisHandle = nextHandle++, tasksByHandle[thisHandle] = task, thisHandle;
                },
                runIfPresent: function(handle) {
                    if (currentlyRunningATask) global.setTimeout(function() {
                        tasks.runIfPresent(handle);
                    }, 0); else {
                        var task = tasksByHandle[handle];
                        if (task) {
                            currentlyRunningATask = !0;
                            try {
                                task.run();
                            } finally {
                                delete tasksByHandle[handle], currentlyRunningATask = !1;
                            }
                        }
                    }
                },
                remove: function(handle) {
                    delete tasksByHandle[handle];
                }
            };
        }(), add("setimmediate", function(g) {
            return base.isFunction(g.setImmediate);
        }), add("ms-setimmediate", function(g) {
            return base.isFunction(g.msSetImmediate);
        }), add("post-message", function(g) {
            var postMessageIsAsynchronous, oldOnMessage;
            return postMessageIsAsynchronous = !0, oldOnMessage = g.onmessage, g.postMessage ? (g.onmessage = function() {
                postMessageIsAsynchronous = !1;
            }, g.postMessage("", "*"), g.onmessage = oldOnMessage, postMessageIsAsynchronous) : !1;
        }), add("script-onreadystatechange", function(g) {
            return "document" in g && "onreadystatechange" in g.document.createElement("script");
        }), has("setimmediate") || (has("ms-setimmediate") ? aliasMicrosoftImplementation(global) : (has("post-message") ? installPostMessageImplementation(global) : has("script-onreadystatechange") ? installReadyStateChangeImplementation(global) : installSetTimeoutImplementation(global), 
        global.clearImmediate = tasks.remove));
    });
}(this.global || this), define("poly/all", [ "./object", "./string", "./date", "./array", "./function", "./json", "./xhr", "./setImmediate" ], function(object, string, date) {
    return {
        failIfShimmed: object.failIfShimmed,
        setWhitespaceChars: string.setWhitespaceChars,
        setIsoCompatTest: date.setIsoCompatTest
    };
}), define("poly/poly", [ "./all" ], function(all) {
    var poly = {};
    for (var p in all) poly[p] = all[p];
    return poly.version = "0.5.2", poly;
}), define("poly", [ "poly/poly" ], function(main) {
    return main;
}), function(define) {
    define("wire/lib/object", [], function() {
        function isObject(it) {
            return it && "[object Object]" == Object.prototype.toString.call(it);
        }
        function inherit(parent) {
            return parent ? Object.create(parent) : {};
        }
        function mixin(to, from) {
            return from ? Object.keys(from).reduce(function(to, key) {
                return to[key] = from[key], to;
            }, to) : to;
        }
        var hasOwn;
        return hasOwn = Object.prototype.hasOwnProperty.call.bind(Object.prototype.hasOwnProperty), 
        {
            hasOwn: hasOwn,
            isObject: isObject,
            inherit: inherit,
            mixin: mixin
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/loader", [ "require", "when", "./object" ], function(require) {
        function getModuleLoader(platformLoader, parentLoader) {
            var loadModule = "function" == typeof platformLoader ? wrapPlatformLoader(platformLoader) : parentLoader || wrapPlatformLoader(require);
            return {
                load: loadModule,
                merge: function(specs) {
                    return when(specs, function(specs) {
                        return when.resolve(Array.isArray(specs) ? mergeAll(specs, loadModule) : "string" == typeof specs ? loadModule(specs) : specs);
                    });
                }
            };
        }
        function mergeAll(specs, loadModule) {
            return when.reduce(specs, function(merged, module) {
                return "string" == typeof module ? when(loadModule(module), function(spec) {
                    return mixin(merged, spec);
                }) : mixin(merged, module);
            }, {});
        }
        var when, mixin, wrapPlatformLoader;
        return when = require("when"), mixin = require("./object").mixin, wrapPlatformLoader = "object" == typeof exports ? function(require) {
            return function(moduleId) {
                try {
                    return when.resolve(require(moduleId));
                } catch (e) {
                    return when.reject(e);
                }
            };
        } : function(require) {
            return function(moduleId) {
                var deferred = when.defer();
                return require([ moduleId ], deferred.resolve, deferred.reject), deferred.promise;
            };
        }, getModuleLoader;
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/advice", [ "require", "when" ], function(require) {
        function after(f, advice) {
            return function() {
                return advice.call(this, f.apply(this, arguments));
            };
        }
        function beforeAsync(f, advice) {
            return function() {
                var self, args;
                return self = this, args = arguments, when(args, function() {
                    return advice.apply(self, args);
                }).then(function() {
                    return f.apply(self, args);
                });
            };
        }
        function afterAsync(f, advice) {
            return function() {
                var self = this;
                return when(arguments, function(args) {
                    return f.apply(self, args);
                }).then(function(result) {
                    return advice.call(self, result);
                });
            };
        }
        var when;
        return when = require("when"), {
            after: after,
            beforeAsync: beforeAsync,
            afterAsync: afterAsync
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/WireContext", [ "require", "./object" ], function(require) {
        function WireContext() {}
        var object, undef;
        return object = require("./object"), WireContext.inherit = function(parent, api) {
            var contextApi, context;
            return contextApi = object.inherit(parent), object.mixin(contextApi, api), WireContext.prototype = contextApi, 
            context = new WireContext(), WireContext.prototype = undef, context;
        }, WireContext;
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("when/sequence", [ "require", "./when" ], function(require) {
        var when, slice;
        return when = require("./when"), slice = Array.prototype.slice, function(tasks) {
            function addResult(result) {
                return results.push(result), results;
            }
            var results = [];
            return when.all(slice.call(arguments, 1)).then(function(args) {
                return when.reduce(tasks, function(results, task) {
                    return when(task.apply(null, args), addResult);
                }, results);
            });
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/array", [], function() {
        function delegateArray(array) {
            return array ? [].concat(array) : [];
        }
        function fromArguments(args, index) {
            return slice.call(args, index || 0);
        }
        function union(a1, a2) {
            return a1.length ? a2.length ? a2.reduce(function(union, a2item) {
                return -1 === union.indexOf(a2item) && union.push(a2item), union;
            }, a1.slice()) : a1.slice() : a2.slice();
        }
        var slice = [].slice;
        return {
            delegate: delegateArray,
            fromArguments: fromArguments,
            union: union
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/WireProxy", [ "require", "./object", "./array" ], function(require) {
        function WireProxy(target) {
            Object.defineProperty(this, "target", {
                value: target
            });
        }
        function createProxy(target) {
            return new WireProxy(target);
        }
        function extendProxy(proxy, extensions) {
            if (!isProxy(proxy)) throw new Error("Cannot extend non-WireProxy");
            return object.mixin(Object.create(proxy), extensions);
        }
        function isProxy(it) {
            return it instanceof WireProxy;
        }
        function getTarget(it) {
            return isProxy(it) ? it.target : it;
        }
        function cloneThing(thing, options) {
            var deep, inherited, clone, prop;
            if (deep = options.deep, inherited = options.inherited, "object" != typeof thing) return thing;
            if (thing instanceof Date) return new Date(thing.getTime());
            if (thing instanceof RegExp) return new RegExp(thing);
            if (Array.isArray(thing)) return deep ? thing.map(function(i) {
                return cloneThing(i, options);
            }) : thing.slice();
            clone = thing.constructor ? new thing.constructor() : {};
            for (prop in thing) (inherited || object.hasOwn(thing, prop)) && (clone[prop] = deep ? cloneThing(thing[prop], options) : thing[prop]);
            return clone;
        }
        var object, array;
        return object = require("./object"), array = require("./array"), WireProxy.prototype = {
            get: function(property) {
                return this.target[property];
            },
            set: function(property, value) {
                return this.target[property] = value, value;
            },
            invoke: function(method, args) {
                var target = this.target;
                return "string" == typeof method && (method = target[method]), method.apply(target, array.fromArguments(args));
            },
            destroy: function() {},
            clone: function(options) {
                var target = this.target;
                return "function" == typeof target ? target.bind() : "object" != typeof target ? target : cloneThing(target, options || {});
            }
        }, WireProxy.create = createProxy, WireProxy.isProxy = isProxy, WireProxy.getTarget = getTarget, 
        WireProxy.extend = extendProxy, WireProxy;
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/ComponentFactory", [ "require", "when", "./object", "./WireProxy" ], function(require) {
        function ComponentFactory(lifecycle, plugins, pluginApi) {
            this.plugins = plugins, this.pluginApi = pluginApi, this.lifecycle = lifecycle, 
            this.proxies = [];
        }
        var when, object, WireProxy, undef;
        return when = require("when"), object = require("./object"), WireProxy = require("./WireProxy"), 
        ComponentFactory.prototype = {
            create: function(component) {
                var found;
                return found = this.getFactory(component.spec), found ? this._create(component, found.factory, found.options) : when.reject(component);
            },
            _create: function(component, factory, options) {
                var instance, self;
                return instance = when.defer(), self = this, factory(instance.resolver, options, this.pluginApi.contextualize(component.id)), 
                instance.promise.then(function(instance) {
                    return self.processComponent(component, instance);
                });
            },
            processComponent: function(component, instance) {
                var self, proxy;
                return self = this, proxy = this.createProxy(instance, component), self.initInstance(proxy).then(function(proxy) {
                    return self.startupInstance(proxy);
                }).then(WireProxy.getTarget);
            },
            initInstance: function(proxy) {
                return this.lifecycle.init(proxy);
            },
            startupInstance: function(proxy) {
                return this.lifecycle.startup(proxy);
            },
            createProxy: function(instance, component) {
                var proxy;
                return WireProxy.isProxy(instance) ? (proxy = instance, instance = WireProxy.getTarget(proxy)) : proxy = WireProxy.create(instance), 
                component && (proxy.id = component.id, proxy.metadata = component), this.initProxy(proxy);
            },
            initProxy: function(proxy) {
                var proxiers = this.plugins.proxiers;
                return proxy = proxiers.reduce(function(proxy, proxier) {
                    var overridden = proxier(proxy);
                    return WireProxy.isProxy(overridden) ? overridden : proxy;
                }, proxy), this._registerProxy(proxy), proxy;
            },
            destroy: function() {
                function shutdownComponents() {
                    return when.reduce(proxies, function(_, proxy) {
                        return lifecycle.shutdown(proxy);
                    }, undef);
                }
                function destroyComponents() {
                    return when.reduce(proxies, function(_, proxy) {
                        return proxy.destroy();
                    }, undef);
                }
                var proxies, lifecycle;
                return proxies = this.proxies, lifecycle = this.lifecycle, shutdownComponents().then(destroyComponents);
            },
            _registerProxy: function(proxy) {
                proxy.metadata && (proxy.path = proxy.metadata.path, this.proxies.push(proxy));
            },
            getFactory: function(spec) {
                var f, factories, found;
                factories = this.plugins.factories;
                for (f in factories) if (object.hasOwn(spec, f)) {
                    found = {
                        factory: factories[f],
                        options: {
                            options: spec[f],
                            spec: spec
                        }
                    };
                    break;
                }
                return found;
            }
        }, ComponentFactory;
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/lifecycle", [ "require", "when" ], function(require) {
        function Lifecycle(plugins, pluginApi) {
            this._plugins = plugins, this._pluginApi = pluginApi;
        }
        function createLifecyclePhase(steps) {
            return steps = generateSteps(steps), function(proxy) {
                var plugins, pluginApi;
                return plugins = this._plugins, pluginApi = this._pluginApi.contextualize(proxy.id), 
                when.reduce(steps, function(unused, step) {
                    return processFacets(step, proxy, pluginApi, plugins);
                }, proxy);
            };
        }
        function processFacets(step, proxy, api, plugins) {
            var promises, metadata, options, name, spec, facets, safeNames, unprocessed;
            promises = [], metadata = proxy.metadata, spec = metadata.spec, facets = plugins.facets, 
            safeNames = Object.create(plugins.factories, safeNonFacetNames), unprocessed = [];
            for (name in spec) name in facets ? (options = spec[name], options && processStep(promises, facets[name], step, proxy, options, api)) : name in safeNames || unprocessed.push(name);
            return unprocessed.length ? when.reject(unrecognizedFacets(proxy, unprocessed, spec)) : when.all(promises).then(function() {
                return processListeners(step, proxy, api, plugins.listeners);
            }).yield(proxy);
        }
        function processListeners(step, proxy, api, listeners) {
            for (var listenerPromises = [], i = 0; i < listeners.length; i++) processStep(listenerPromises, listeners[i], step, proxy, {}, api);
            return when.all(listenerPromises);
        }
        function processStep(promises, processor, step, proxy, options, api) {
            var facet, pendingFacet;
            processor && processor[step] && (pendingFacet = when.defer(), promises.push(pendingFacet.promise), 
            facet = Object.create(proxy), facet.options = options, processor[step](pendingFacet.resolver, facet, api));
        }
        function generateSteps(steps) {
            return steps.reduce(reduceSteps, []);
        }
        function reduceSteps(lifecycle, step) {
            return lifecycle.push(step + ":before"), lifecycle.push(step), lifecycle.push(step + ":after"), 
            lifecycle;
        }
        function unrecognizedFacets(proxy, unprocessed, spec) {
            return new Error("unrecognized facets in " + proxy.id + ", maybe you forgot a plugin? " + unprocessed.join(", ") + "\n" + JSON.stringify(spec));
        }
        var when, safeNonFacetNames;
        return when = require("when"), safeNonFacetNames = {
            id: {
                value: 1
            }
        }, Lifecycle.prototype = {
            init: createLifecyclePhase([ "create", "configure", "initialize" ]),
            startup: createLifecyclePhase([ "connect", "ready" ]),
            shutdown: createLifecyclePhase([ "destroy" ])
        }, Lifecycle;
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("when/timeout", [ "require", "./when" ], function(require) {
        var when, setTimer, cancelTimer;
        return when = require("./when"), "object" == typeof vertx ? (setTimer = function(f, ms) {
            return vertx.setTimer(ms, f);
        }, cancelTimer = vertx.cancelTimer) : (setTimer = setTimeout, cancelTimer = clearTimeout), 
        function(msec, trigger) {
            if ("number" == typeof trigger) {
                var tmp = trigger;
                trigger = msec, msec = tmp;
            }
            return when.promise(function(resolve, reject, notify) {
                var timeoutRef = setTimer(function() {
                    reject(new Error("timed out after " + msec + "ms"));
                }, msec);
                when(trigger, function(value) {
                    cancelTimer(timeoutRef), resolve(value);
                }, function(reason) {
                    cancelTimer(timeoutRef), reject(reason);
                }, notify);
            });
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/resolver", [ "require", "when", "when/timeout", "./object" ], function(require) {
        function Resolver(resolvers, pluginApi) {
            this._resolvers = resolvers, this._pluginApi = pluginApi;
        }
        var when, timeout, object;
        return when = require("when"), timeout = require("when/timeout"), object = require("./object"), 
        Resolver.prototype = {
            isRef: function(it) {
                return it && object.hasOwn(it, "$ref");
            },
            parse: function(it) {
                return this.isRef(it) ? this.create(it.$ref, it) : this.create(it, {});
            },
            create: function(name, options) {
                var self, split, resolver;
                return self = this, split = name.indexOf("!"), resolver = name.substring(0, split), 
                name = name.substring(split + 1), {
                    resolver: resolver,
                    name: name,
                    options: options,
                    resolve: function(fallback, onBehalfOf) {
                        return this.resolver ? self._resolve(resolver, name, options, onBehalfOf) : fallback(name, options);
                    }
                };
            },
            _resolve: function(resolverName, name, options, onBehalfOf) {
                var deferred, resolver, api;
                return deferred = when.defer(), resolverName ? (resolver = this._resolvers[resolverName], 
                resolver ? (api = this._pluginApi.contextualize(onBehalfOf), resolver(deferred.resolver, name, options || {}, api)) : deferred.reject(new Error("No resolver plugin found: " + resolverName))) : deferred.reject(new Error("Cannot resolve ref: " + name)), 
                deferred.promise;
            }
        }, Resolver;
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/plugin/priority", [], function() {
        function prioritizeReverse(list) {
            return list.sort(byReversePriority);
        }
        function byReversePriority(a, b) {
            var aPriority, bPriority;
            return aPriority = a.priority || defaultPriority, bPriority = b.priority || defaultPriority, 
            bPriority > aPriority ? -1 : aPriority > bPriority ? 1 : 0;
        }
        var basePriority, defaultPriority;
        return basePriority = -99, defaultPriority = 0, {
            basePriority: basePriority,
            sortReverse: prioritizeReverse
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/instantiate", [], function() {
        function defineConstructorIfPossible(instance, ctor) {
            try {
                Object.defineProperty(instance, "constructor", {
                    value: ctor,
                    enumerable: !1
                });
            } catch (e) {}
        }
        function isConstructor(func) {
            var p, is = !1;
            for (p in func.prototype) if (p !== undef) {
                is = !0;
                break;
            }
            return is;
        }
        var undef;
        return function(ctor, args, forceConstructor) {
            var begotten, ctorResult;
            return forceConstructor || isConstructor(ctor) ? (begotten = Object.create(ctor.prototype), 
            defineConstructorIfPossible(begotten, ctor), ctorResult = ctor.apply(begotten, args), 
            ctorResult !== undef && (begotten = ctorResult)) : begotten = ctor.apply(undef, args), 
            begotten === undef ? null : begotten;
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/plugin/registry", [ "require", "when", "../array", "../object", "./priority", "../instantiate" ], function(require) {
        function PluginRegistry() {
            this.plugins = [], this._namespaces = {}, this.contextListeners = [], this.listeners = [], 
            this.proxiers = [], this.resolvers = {}, this.factories = {}, this.facets = {};
        }
        function discoverPlugin(module) {
            var plugin;
            return "function" == typeof module.wire$plugin ? plugin = module.wire$plugin : "function" == typeof module && (plugin = module), 
            plugin;
        }
        function getNamespace(spec) {
            var namespace;
            return "object" == typeof spec && nsKey in spec && (namespace = spec[nsKey]), namespace;
        }
        function addNamespace(namespace, namespaces) {
            if (namespace && namespace in namespaces) throw new Error("plugin namespace already in use: " + namespace);
            namespaces[namespace] = 1;
        }
        function allowPlugin(plugin, existing) {
            return "function" == typeof plugin && -1 === existing.indexOf(plugin);
        }
        function addPlugin(src, registry, namespace) {
            var newPluginName, namespacedName;
            for (newPluginName in src) {
                if (namespacedName = makeNamespace(newPluginName, namespace), object.hasOwn(registry, namespacedName)) throw new Error("Two plugins for same type in scope: " + namespacedName);
                registry[namespacedName] = src[newPluginName];
            }
        }
        function makeNamespace(pluginName, namespace) {
            return namespace ? namespace + nsSeparator + pluginName : pluginName;
        }
        var when, array, object, priority, instantiate, nsKey, nsSeparator;
        return when = require("when"), array = require("../array"), object = require("../object"), 
        priority = require("./priority"), instantiate = require("../instantiate"), nsKey = "$ns", 
        nsSeparator = ":", PluginRegistry.prototype = {
            scanModule: function(module, spec, namespace) {
                var self, pluginFactory;
                return pluginFactory = discoverPlugin(module), allowPlugin(pluginFactory, this.plugins) ? (this.plugins.push(pluginFactory), 
                self = this, when(instantiate(pluginFactory, [ spec ]), function(plugin) {
                    plugin && self.registerPlugin(plugin, namespace || getNamespace(spec));
                }).yield()) : when.resolve();
            },
            registerPlugin: function(plugin, namespace) {
                addNamespace(namespace, this._namespaces), addPlugin(plugin.resolvers, this.resolvers, namespace), 
                addPlugin(plugin.factories, this.factories, namespace), addPlugin(plugin.facets, this.facets, namespace), 
                this.listeners.push(plugin), plugin.context && this.contextListeners.push(plugin.context), 
                this._registerProxies(plugin.proxies);
            },
            _registerProxies: function(proxiesToAdd) {
                proxiesToAdd && (this.proxiers = priority.sortReverse(array.union(this.proxiers, proxiesToAdd)));
            }
        }, PluginRegistry;
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/scope", [ "require", "when", "when/sequence", "./array", "./object", "./loader", "./ComponentFactory", "./lifecycle", "./resolver", "./WireProxy", "./plugin/registry" ], function(require) {
        function Scope(parent, options) {
            this.parent = parent || {}, object.mixin(this, options);
        }
        function resolveDeepName(name, scope) {
            var parts = name.split(".");
            return parts.length > 2 ? when.reject('Only 1 "." is allowed in refs: ' + name) : when.reduce(parts, function(scope, segment) {
                return segment in scope ? scope[segment] : when.reject("Cannot resolve ref: " + name);
            }, scope);
        }
        function noop() {}
        var when, defer, sequence, array, object, loader, ComponentFactory, Lifecycle, Resolver, WireProxy, PluginRegistry, undef;
        return when = require("when"), sequence = require("when/sequence"), array = require("./array"), 
        object = require("./object"), loader = require("./loader"), ComponentFactory = require("./ComponentFactory"), 
        Lifecycle = require("./lifecycle"), Resolver = require("./resolver"), WireProxy = require("./WireProxy"), 
        PluginRegistry = require("./plugin/registry"), defer = when.defer, Scope.prototype = {
            init: function(spec) {
                return this._inherit(this.parent), this._init(), this._configure(), this._startup(spec).yield(this);
            },
            _inherit: function(parent) {
                this.instances = this._inheritInstances(parent), this.components = object.inherit(parent.components), 
                this.path = this._createPath(this.name, parent.path), this.plugins = parent.plugins, 
                this.initializers = array.delegate(this.initializers), this.destroyers = array.delegate(this.destroyers), 
                this.moduleLoader = loader(this.require, parent.moduleLoader).load;
            },
            _inheritInstances: function(parent) {
                return object.inherit(parent.instances);
            },
            _createChild: function(spec, options) {
                var destroyTasks = this.destroyers;
                return this.createContext(spec, this, options).then(function(child) {
                    return destroyTasks.push(function() {
                        return child.destroy();
                    }), child;
                });
            },
            _init: function() {
                this._pluginApi = this._initPluginApi();
            },
            _initPluginApi: function() {
                function addComponent(component, id) {
                    var def, instance;
                    return def = self._createComponentDef(id), instance = self.componentFactory.processComponent(def, component), 
                    self._makeResolvable(def, instance);
                }
                function addInstance(instance, id) {
                    return self._makeResolvable(self._createComponentDef(id), instance), when.resolve(instance);
                }
                var self, pluginApi;
                return self = this, pluginApi = {}, pluginApi.contextualize = function(name) {
                    function contextualApi(spec, id) {
                        return self._resolveItem(self._createComponentDef(id, spec));
                    }
                    return contextualApi.createChild = self._createChild.bind(self), contextualApi.loadModule = self.getModule.bind(self), 
                    contextualApi.resolver = self.resolver, contextualApi.addComponent = addComponent, 
                    contextualApi.addInstance = addInstance, contextualApi.resolveRef = function(ref) {
                        var onBehalfOf = arguments.length > 1 ? arguments[2] : name;
                        return self._resolveRef(ref, onBehalfOf);
                    }, contextualApi.getProxy = function(nameOrComponent) {
                        var onBehalfOf = arguments.length > 1 ? arguments[2] : name;
                        return self.getProxy(nameOrComponent, onBehalfOf);
                    }, contextualApi;
                }, pluginApi;
            },
            _configure: function() {
                var plugins, pluginApi;
                plugins = this.plugins, pluginApi = this._pluginApi, this.resolver = this._createResolver(plugins, pluginApi), 
                this.componentFactory = this._createComponentFactory(plugins, pluginApi), this._destroy = function() {
                    return this._destroy = noop, this._executeDestroyers().then(this._destroyComponents.bind(this)).then(this._releaseResources.bind(this));
                };
            },
            _startup: function(spec) {
                var self = this;
                return this._executeInitializers().then(function() {
                    var parsed = self._parseSpec(spec);
                    return self._createComponents(parsed).then(function() {
                        return self._awaitInstances(parsed);
                    });
                });
            },
            destroy: function() {
                return this._destroy();
            },
            _destroy: noop,
            _destroyComponents: function() {
                var instances = this.instances;
                return this.componentFactory.destroy().then(function() {
                    for (var p in instances) delete instances[p];
                });
            },
            _releaseResources: function() {
                this.instances = this.components = this.parent = this.resolver = this.componentFactory = this._pluginApi = this.plugins = undef;
            },
            getModule: function(moduleId) {
                return "string" == typeof moduleId ? this.moduleLoader(moduleId) : when.resolve(moduleId);
            },
            getProxy: function(nameOrComponent, onBehalfOf) {
                var componentFactory = this.componentFactory;
                return "string" == typeof nameOrComponent ? when(this._resolveRefName(nameOrComponent, {}, onBehalfOf), function(component) {
                    return componentFactory.createProxy(component);
                }) : componentFactory.createProxy(nameOrComponent);
            },
            _createResolver: function(plugins, pluginApi) {
                return new Resolver(plugins.resolvers, pluginApi);
            },
            _createComponentFactory: function(plugins, pluginApi) {
                var self, factory, init, lifecycle;
                return self = this, lifecycle = new Lifecycle(plugins, pluginApi), factory = new ComponentFactory(lifecycle, plugins, pluginApi), 
                init = factory.initInstance, factory.initInstance = function() {
                    return when(init.apply(factory, arguments), function(proxy) {
                        return self._makeResolvable(proxy.metadata, proxy);
                    });
                }, factory;
            },
            _executeInitializers: function() {
                return sequence(this.initializers, this);
            },
            _executeDestroyers: function() {
                return sequence(this.destroyers, this);
            },
            _parseSpec: function(spec) {
                var instances, components, plugins, id, d;
                instances = this.instances, components = {};
                for (id in spec) "$plugins" === id || "plugins" === id ? plugins = spec[id] : object.hasOwn(instances, id) || (d = defer(), 
                components[id] = this._createComponentDef(id, spec[id], d.resolver), instances[id] = d.promise);
                return {
                    plugins: plugins,
                    components: components,
                    instances: instances
                };
            },
            _createComponentDef: function(id, spec, resolver) {
                return {
                    id: id,
                    spec: spec,
                    path: this._createPath(id, this.path),
                    resolver: resolver
                };
            },
            _createComponents: function(parsed) {
                var self, components;
                return self = this, components = parsed.components, when.map(Object.keys(components), function(name) {
                    return self._createScopeItem(components[name]);
                });
            },
            _awaitInstances: function(parsed) {
                var instances = parsed.instances;
                return when.map(Object.keys(instances), function(id) {
                    return instances[id];
                });
            },
            _createScopeItem: function(component) {
                var self, item;
                return self = this, item = this._resolveItem(component).then(function(resolved) {
                    return self._makeResolvable(component, resolved), resolved;
                }), component.resolver.resolve(item), item;
            },
            _makeResolvable: function(component, instance) {
                var id = component.id;
                return null != id && (this.instances[id] = WireProxy.getTarget(instance)), instance;
            },
            _resolveItem: function(component) {
                var item, spec;
                return spec = component.spec, item = this.resolver.isRef(spec) ? this._resolveRef(spec, component.id) : this._createItem(component);
            },
            _createItem: function(component) {
                var created, spec;
                return spec = component.spec, created = Array.isArray(spec) ? this._createArray(component) : object.isObject(spec) ? this._createComponent(component) : when.resolve(spec);
            },
            _createArray: function(component) {
                var self, id, i;
                return self = this, id = component.id, i = 0, when.map(component.spec, function(item) {
                    var componentDef = self._createComponentDef(id + "[" + i++ + "]", item);
                    return self._resolveItem(componentDef);
                });
            },
            _createComponent: function(component) {
                var self = this;
                return this.componentFactory.create(component).otherwise(function(reason) {
                    if (reason !== component) throw reason;
                    var options = {
                        createContext: self.createContext
                    };
                    return new Scope(self, options).init(component.spec).then(function(childScope) {
                        return object.mixin({}, childScope.instances);
                    });
                });
            },
            _resolveRef: function(ref, onBehalfOf) {
                var scope;
                return ref = this.resolver.parse(ref), scope = onBehalfOf == ref.name && this.parent.instances ? this.parent : this, 
                this._doResolveRef(ref, scope.instances, onBehalfOf);
            },
            _resolveRefName: function(refName, options, onBehalfOf) {
                var ref = this.resolver.create(refName, options);
                return this._doResolveRef(ref, this.instances, onBehalfOf);
            },
            _doResolveRef: function(ref, scope, onBehalfOf) {
                return ref.resolve(function(name) {
                    return resolveDeepName(name, scope);
                }, onBehalfOf);
            },
            _createPath: function(name, basePath) {
                var path = basePath || this.path;
                return path && name ? path + "." + name : name;
            }
        }, Scope;
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/plugin/wirePlugin", [ "require", "when", "../object" ], function(require) {
        function wrapChild(promise) {
            return {
                promise: promise
            };
        }
        function wireResolver(resolver, _, __, wire) {
            resolver.resolve(wire.createChild);
        }
        var when, object;
        return when = require("when"), object = require("../object"), function() {
            function wireFactory(resolver, componentDef, wire) {
                function init(context) {
                    var initialized;
                    return provide && (initialized = when(wire(provide), function(provides) {
                        object.mixin(context.instances, provides);
                    })), initialized;
                }
                function createChild(mixin) {
                    var spec, config;
                    spec = mixin ? [].concat(module, mixin) : module, config = {
                        initializers: [ init ]
                    };
                    var child = wire.createChild(spec, config);
                    return defer ? child : when(child, function(child) {
                        return object.hasOwn(child, "$exports") ? child.$exports : child;
                    });
                }
                var options, module, provide, defer, waitParent, result;
                if (options = componentDef.options, object.isObject(options) && "spec" in options ? (module = options.spec, 
                waitParent = options.waitParent, defer = options.defer, provide = options.provide) : module = options, 
                defer) result = createChild; else if (waitParent) {
                    var childPromise = when(ready.promise, function() {
                        return createChild();
                    });
                    result = wrapChild(childPromise);
                } else result = createChild();
                resolver.resolve(result);
            }
            var ready = when.defer();
            return {
                context: {
                    ready: function(resolver) {
                        ready.resolve(), resolver.resolve();
                    }
                },
                resolvers: {
                    wire: wireResolver
                },
                factories: {
                    wire: wireFactory
                }
            };
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/functional", [ "require", "when" ], function(require) {
        function partial(f, args) {
            return 1 == arguments.length ? f : (args = slice.call(arguments, 1), function() {
                return f.apply(this, args.concat(slice.call(arguments)));
            });
        }
        function compose(funcs) {
            var first;
            return first = funcs[0], funcs = funcs.slice(1), function() {
                var context = this;
                return funcs.reduce(function(result, f) {
                    return conditionalWhen(result, function(result) {
                        return f.call(context, result);
                    });
                }, first.apply(this, arguments));
            };
        }
        function conditionalWhen(promiseOrValue, onFulfill, onReject) {
            return when.isPromise(promiseOrValue) ? when(promiseOrValue, onFulfill, onReject) : onFulfill(promiseOrValue);
        }
        var when, slice;
        return when = require("when"), slice = [].slice, compose.parse = function(proxy, composeString, wire) {
            function createProxyInvoker(proxy, method) {
                return function() {
                    return proxy.invoke(method, arguments);
                };
            }
            function createBound(proxy, bindSpec) {
                var target, method;
                if (target = bindSpec.split("."), target.length > 2) throw new Error('Only 1 "." is allowed in refs: ' + bindSpec);
                return target.length > 1 ? (method = target[1], target = target[0], target ? when(getProxy(target), function(proxy) {
                    return createProxyInvoker(proxy, method);
                }) : function(target) {
                    return target[method].apply(target, slice.call(arguments, 1));
                }) : proxy && "function" == typeof proxy.get(bindSpec) ? createProxyInvoker(proxy, bindSpec) : resolveRef(bindSpec);
            }
            var bindSpecs, resolveRef, getProxy;
            return "string" != typeof composeString ? wire(composeString).then(function(func) {
                return createProxyInvoker(proxy, func);
            }) : (bindSpecs = composeString.split(/\s*\|\s*/), resolveRef = wire.resolveRef, 
            getProxy = wire.getProxy, when.reduce(bindSpecs, function(funcs, bindSpec) {
                return when(createBound(proxy, bindSpec), function(func) {
                    return funcs.push(func), funcs;
                });
            }, []).then(function(funcs) {
                var context = proxy && proxy.target;
                return (1 == funcs.length ? funcs[0] : compose(funcs)).bind(context);
            }));
        }, {
            compose: compose,
            partial: partial
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/invoker", [], function() {
        return function(methodName, args) {
            return function(target) {
                return target[methodName].apply(target, args);
            };
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/plugin/basePlugin", [ "require", "when", "../object", "../functional", "../instantiate", "../invoker" ], function(require) {
        function asArray(it) {
            return Array.isArray(it) ? it : [ it ];
        }
        function invoke(func, proxy, args, wire) {
            return when(wire(args, func, proxy.path), function(resolvedArgs) {
                return proxy.invoke(func, asArray(resolvedArgs));
            });
        }
        function invokeAll(facet, wire) {
            var options = facet.options;
            if ("string" == typeof options) return invoke(options, facet, [], wire);
            var promises, funcName;
            promises = [];
            for (funcName in options) promises.push(invoke(funcName, facet, options[funcName], wire));
            return whenAll(promises);
        }
        function mixin(target, src) {
            var name, s;
            for (name in src) s = src[name], name in target && (target[name] === s || name in obj && obj[name] === s) || (target[name] = s);
            return target;
        }
        function doMixin(target, introduction, wire) {
            return introduction = "string" == typeof introduction ? wire.resolveRef(introduction) : wire(introduction), 
            when(introduction, mixin.bind(null, target));
        }
        function mixinFacet(resolver, facet, wire) {
            var target, intros;
            target = facet.target, intros = facet.options, Array.isArray(intros) || (intros = [ intros ]), 
            resolver.resolve(when.reduce(intros, function(target, intro) {
                return doMixin(target, intro, wire);
            }, target));
        }
        function literalFactory(resolver, spec) {
            resolver.resolve(spec.options);
        }
        function protoFactory(resolver, componentDef, wire) {
            var parentRef, promise;
            parentRef = componentDef.options, promise = "string" == typeof parentRef ? wire.resolveRef(parentRef) : wire(parentRef), 
            resolver.resolve(promise.then(Object.create));
        }
        function propertiesFacet(resolver, facet, wire) {
            var properties, path, setProperty, propertiesSet;
            properties = facet.options, path = facet.path, setProperty = facet.set.bind(facet), 
            propertiesSet = when.map(Object.keys(facet.options), function(key) {
                return wire(properties[key], facet.path).then(function(wiredProperty) {
                    setProperty(key, wiredProperty);
                });
            }), resolver.resolve(propertiesSet);
        }
        function invokerFactory(resolver, componentDef, wire) {
            var invoker = wire(componentDef.options).then(function(invokerContext) {
                return createInvoker(invokerContext.method, invokerContext.args);
            });
            resolver.resolve(invoker);
        }
        function invokerFacet(resolver, facet, wire) {
            resolver.resolve(invokeAll(facet, wire));
        }
        function cloneFactory(resolver, componentDef, wire) {
            var sourceRef, options, cloned;
            wire.resolver.isRef(componentDef.options.source) ? (sourceRef = componentDef.options.source, 
            options = componentDef.options) : (sourceRef = componentDef.options, options = {}), 
            cloned = wire(sourceRef).then(function(ref) {
                return when(wire.getProxy(ref), function(proxy) {
                    if (!proxy.clone) throw new Error("No clone function found for " + componentDef.id);
                    return proxy.clone(options);
                });
            }), resolver.resolve(cloned);
        }
        function moduleFactory(resolver, componentDef, wire) {
            resolver.resolve(wire.loadModule(componentDef.options));
        }
        function instanceFactory(resolver, componentDef, wire) {
            function createInstance(module, args) {
                return "function" == typeof module ? instantiate(module, args, isConstructor) : Object.create(module);
            }
            var create, args, isConstructor, module, instance;
            create = componentDef.options, "string" == typeof create ? module = wire.loadModule(create) : wire.resolver.isRef(create) ? module = wire(create) : object.isObject(create) && create.module ? (module = wire.loadModule(create.module), 
            args = create.args ? wire(asArray(create.args)) : [], isConstructor = create.isConstructor) : module = create, 
            instance = when.join(module, args).spread(createInstance), resolver.resolve(instance);
        }
        function composeFactory(resolver, componentDef, wire) {
            var options, promise;
            options = componentDef.options, promise = "string" == typeof options ? functional.compose.parse(undef, options, wire) : when(wire(options), function(funcArray) {
                return functional.compose(funcArray);
            }), resolver.resolve(promise);
        }
        var when, object, functional, instantiate, createInvoker, whenAll, obj, pluginInstance, undef;
        return when = require("when"), object = require("../object"), functional = require("../functional"), 
        instantiate = require("../instantiate"), createInvoker = require("../invoker"), 
        whenAll = when.all, obj = {}, pluginInstance = {
            factories: {
                module: moduleFactory,
                create: instanceFactory,
                literal: literalFactory,
                prototype: protoFactory,
                clone: cloneFactory,
                compose: composeFactory,
                invoker: invokerFactory
            },
            facets: {
                properties: {
                    configure: propertiesFacet
                },
                mixin: {
                    configure: mixinFacet
                },
                init: {
                    initialize: invokerFacet
                },
                ready: {
                    ready: invokerFacet
                },
                destroy: {
                    destroy: invokerFacet
                }
            }
        }, pluginInstance.facets.introduce = pluginInstance.facets.mixin, function() {
            return pluginInstance;
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/plugin/defaultPlugins", [ "require", "./wirePlugin", "./basePlugin" ], function(require) {
        return [ require("./wirePlugin"), require("./basePlugin") ];
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/graph/DirectedGraph", [], function() {
        function DirectedGraph() {
            this.vertices = {};
        }
        return DirectedGraph.prototype = {
            addEdge: function(from, to) {
                this._getOrCreateVertex(to), this._getOrCreateVertex(from).edges[to] = 1;
            },
            _getOrCreateVertex: function(name) {
                var v = this.vertices[name];
                return v || (v = this.vertices[name] = {
                    name: name,
                    edges: {}
                }), v;
            },
            removeEdge: function(from, to) {
                var outbound = this.vertices[from];
                outbound && delete outbound.edges[to];
            },
            eachVertex: function(lambda) {
                var vertices, v;
                vertices = this.vertices;
                for (v in vertices) lambda(vertices[v]);
            },
            eachEdgeFrom: function(vertex, lambda) {
                var v, e, vertices;
                if (vertices = this.vertices, v = vertices[vertex]) for (e in v.edges) lambda(v, vertices[e]);
            }
        }, DirectedGraph;
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/graph/tarjan", [], function() {
        function pushStack(stack, vertex) {
            stack.push(vertex), vertex.onStack = 1;
        }
        function popStack(stack) {
            var v = stack.pop();
            return v && delete v.onStack, v;
        }
        var undef;
        return function(digraph) {
            function findStronglyConnected(dg, v) {
                var vertices, vertex;
                if (v.index = v.lowlink = index, index += 1, pushStack(stack, v), dg.eachEdgeFrom(v.name, function(v, w) {
                    w.index === undef ? (findStronglyConnected(dg, w), v.lowlink = Math.min(v.lowlink, w.lowlink)) : w.onStack && (v.lowlink = Math.min(v.lowlink, w.index));
                }), v.lowlink === v.index) {
                    if (vertices = [], stack.length) do vertex = popStack(stack), vertices.push(vertex); while (v !== vertex);
                    vertices.length && scc.push(vertices);
                }
            }
            var index, stack, scc;
            return index = 0, stack = [], scc = [], digraph.eachVertex(function(v) {
                delete v.index, delete v.lowlink, delete v.onStack;
            }), digraph.eachVertex(function(v) {
                v.index === undef && findStronglyConnected(digraph, v);
            }), scc;
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/graph/formatCycles", [], function() {
        return function(cycles) {
            return cycles.map(function(sc) {
                return "[" + sc.map(function(v) {
                    return v.name;
                }).join(", ") + "]";
            }).join(", ");
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory();
}), function(define) {
    define("wire/lib/graph/trackInflightRefs", [ "require", "when/timeout", "./tarjan", "./formatCycles" ], function(require) {
        function trackInflightRef(refGraph, cycleTimeout, refPromise, refName, onBehalfOf) {
            return onBehalfOf = onBehalfOf || "?", refGraph.addEdge(onBehalfOf, refName), timeout(refPromise, cycleTimeout).then(function(resolved) {
                return refGraph.removeEdge(onBehalfOf, refName), resolved;
            }, function() {
                var stronglyConnected, cycles;
                if (stronglyConnected = findStronglyConnected(refGraph), cycles = stronglyConnected.filter(function(node) {
                    return node.length > 1;
                }), cycles.length) throw new Error("Possible circular refs:\n" + formatCycles(cycles));
                return refPromise;
            });
        }
        var timeout, findStronglyConnected, formatCycles, refCycleCheckTimeout;
        return timeout = require("when/timeout"), findStronglyConnected = require("./tarjan"), 
        formatCycles = require("./formatCycles"), refCycleCheckTimeout = 5e3, function(graph, resolver, cycleTimeout) {
            var create = resolver.create;
            return "number" != typeof cycleTimeout && (cycleTimeout = refCycleCheckTimeout), 
            resolver.create = function() {
                var ref, resolve;
                return ref = create.apply(resolver, arguments), resolve = ref.resolve, ref.resolve = function() {
                    var inflight = resolve.apply(ref, arguments);
                    return trackInflightRef(graph, cycleTimeout, inflight, ref.name, arguments[1]);
                }, ref;
            }, resolver;
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/Container", [ "require", "when", "./advice", "./WireContext", "./scope", "./plugin/registry", "./plugin/defaultPlugins", "./graph/DirectedGraph", "./graph/trackInflightRefs" ], function(require) {
        function Container() {
            Scope.apply(this, arguments);
        }
        var when, advice, WireContext, Scope, PluginRegistry, defaultPlugins, DirectedGraph, trackInflightRefs, slice, scopeProto, undef;
        return when = require("when"), advice = require("./advice"), WireContext = require("./WireContext"), 
        Scope = require("./scope"), PluginRegistry = require("./plugin/registry"), defaultPlugins = require("./plugin/defaultPlugins"), 
        DirectedGraph = require("./graph/DirectedGraph"), trackInflightRefs = require("./graph/trackInflightRefs"), 
        slice = Array.prototype.slice, scopeProto = Scope.prototype, Container.prototype = Object.create(scopeProto, {
            _inheritInstances: {
                value: function(parent) {
                    var publicApi = {
                        wire: this._createChild.bind(this),
                        destroy: this.destroy.bind(this),
                        resolve: this._resolveRef.bind(this)
                    };
                    return WireContext.inherit(parent.instances, publicApi);
                }
            },
            _init: {
                value: advice.after(scopeProto._init, function() {
                    return this.plugins = new PluginRegistry(), this._installDefaultPlugins();
                })
            },
            _startup: {
                value: advice.after(scopeProto._startup, function(started) {
                    var self = this;
                    return when(started).otherwise(function(e) {
                        return self._contextEvent("error", e).yield(started);
                    });
                })
            },
            _installDefaultPlugins: {
                value: function() {
                    return this._installPlugins(defaultPlugins);
                }
            },
            _installPlugins: {
                value: function(plugins) {
                    function installPlugin(pluginSpec, namespace) {
                        var module, t;
                        return t = typeof pluginSpec, "string" == t ? (module = pluginSpec, pluginSpec = {}) : module = "string" == typeof pluginSpec.module ? pluginSpec.module : pluginSpec, 
                        self.getModule(module).then(function(plugin) {
                            return registry.scanModule(plugin, pluginSpec, namespace);
                        });
                    }
                    if (!plugins) return when.resolve();
                    var self, registry, installed;
                    return self = this, registry = this.plugins, installed = Array.isArray(plugins) ? plugins.map(function(plugin) {
                        return installPlugin(plugin);
                    }) : Object.keys(plugins).map(function(namespace) {
                        return installPlugin(plugins[namespace], namespace);
                    }), when.all(installed);
                }
            },
            _createResolver: {
                value: advice.after(scopeProto._createResolver, function(resolver) {
                    return trackInflightRefs(new DirectedGraph(), resolver, this.refCycleTimeout);
                })
            },
            _contextEvent: {
                value: function(type, data) {
                    var api, listeners;
                    return this.contextEventApi || (this.contextEventApi = this._pluginApi.contextualize(this.path)), 
                    api = this.contextEventApi, listeners = this.plugins.contextListeners, when.reduce(listeners, function(undef, listener) {
                        var d;
                        return listener[type] ? (d = when.defer(), listener[type](d.resolver, api, data), 
                        d.promise) : undef;
                    }, undef);
                }
            },
            _createComponents: {
                value: advice.beforeAsync(scopeProto._createComponents, function(parsed) {
                    var self = this;
                    return this._installPlugins(parsed.plugins).then(function() {
                        return self._contextEvent("initialize");
                    });
                })
            },
            _awaitInstances: {
                value: advice.afterAsync(scopeProto._awaitInstances, function() {
                    return this._contextEvent("ready");
                })
            },
            _destroyComponents: {
                value: advice.beforeAsync(scopeProto._destroyComponents, function() {
                    return this._contextEvent("shutdown");
                })
            },
            _releaseResources: {
                value: advice.beforeAsync(scopeProto._releaseResources, function() {
                    return this._contextEvent("destroy");
                })
            }
        }), Container;
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(define) {
    define("wire/lib/context", [ "require", "./loader", "./Container" ], function(require) {
        var loader, Container;
        return loader = require("./loader"), Container = require("./Container"), function createContext(specs, parent, options) {
            options || (options = {}), parent || (parent = {}), options.createContext = createContext;
            var moduleLoader = loader(options.require, parent.moduleLoader);
            return moduleLoader.merge(specs).then(function(spec) {
                var container = new Container(parent, options);
                return container.init(spec).then(function(self) {
                    return self.instances;
                });
            });
        };
    });
}("function" == typeof define ? define : function(factory) {
    module.exports = factory(require);
}), function(rootSpec, define) {
    define("wire/wire", [ "require", "./lib/context" ], function(require) {
        function wire(spec, options) {
            return rootContext || (rootContext = createContext(rootSpec, null, rootOptions)), 
            rootContext.then(function(root) {
                return root.wire(spec, options);
            });
        }
        var createContext, rootContext, rootOptions;
        return wire.version = "0.10.1", createContext = require("./lib/context"), rootOptions = {
            require: require
        }, wire.load = function(name, require, callback) {
            var errback = callback.error || function(e) {
                setTimeout(function() {
                    throw e;
                }, 0);
            };
            wire(name.split(","), {
                require: require
            }).then(callback, errback);
        }, wire.pluginBuilder = "./builder/rjs", wire.cramPlugin = "./builder/cram", wire;
    });
}(this.wire || {}, "function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), define("wire", [ "wire/wire" ], function(main) {
    return main;
}), define("jpmc/wire", [ "poly", "wire" ], function(poly, wire) {
    return wire;
}), function(define) {
    define("wire/lib/dom/base", [ "require", "../WireProxy", "../plugin/priority" ], function(require) {
        function addClass(el, className) {
            var newClass;
            newClass = _stripClass(el.className, className), el.className = newClass + (newClass && className ? " " : "") + className;
        }
        function removeClass(el, className) {
            el.className = _stripClass(el.className, className);
        }
        function toggleClass(el, className) {
            var unalteredClass;
            unalteredClass = el.className.replace(trimLeadingRx, ""), el.className = _stripClass(el.className, className), 
            unalteredClass == el.className && (el.className = unalteredClass + (unalteredClass && className ? " " : "") + className);
        }
        function _stripClass(tokens, removes) {
            var rx;
            return removes ? (removes = removes.replace(splitClassNamesRx, function(m, inner, edge) {
                return edge ? "" : "|";
            }), rx = new RegExp(classRx.replace("classNames", removes), "g"), tokens.replace(rx, "").replace(trimLeadingRx, "")) : tokens;
        }
        function byId(id) {
            return document.getElementById(id);
        }
        function queryAll(selector, root) {
            return (root || document).querySelectorAll(selector);
        }
        function query(selector, root) {
            return (root || document).querySelector(selector);
        }
        function placeAt(node, refNode, location) {
            var parent, i;
            if ("length" in refNode) {
                for (i = 0; i < refNode.length; i++) placeAt(0 === i ? node : node.cloneNode(!0), refNode[i], location);
                return node;
            }
            if (parent = refNode.parentNode, isNaN(location)) if ("at" == location) refNode.innerHTML = "", 
            _appendChild(refNode, node); else if ("last" == location) _appendChild(refNode, node); else if ("first" == location) _insertBefore(refNode, node, refNode.firstChild); else if ("before" == location) _insertBefore(parent, node, refNode); else {
                if ("after" != location) throw new Error("Unknown dom insertion command: " + location);
                refNode == parent.lastChild ? _appendChild(parent, node) : _insertBefore(parent, node, refNode.nextSibling);
            } else 0 > location && (location = 0), _insertBefore(refNode, node, refNode.childNodes[location]);
            return node;
        }
        function _insertBefore(parent, node, refNode) {
            parent.insertBefore(node, refNode);
        }
        function _appendChild(parent, node) {
            parent.appendChild(node);
        }
        function isNode(it) {
            return "object" == typeof Node ? it instanceof Node : it && "object" == typeof it && "number" == typeof it.nodeType && "string" == typeof it.nodeName;
        }
        function NodeProxy() {}
        function proxyNode(proxy) {
            return isNode(proxy.target) ? WireProxy.extend(proxy, NodeProxy.prototype) : proxy;
        }
        var WireProxy, priority, classRx, trimLeadingRx, splitClassNamesRx, nodeProxyInvoke;
        return WireProxy = require("../WireProxy"), priority = require("../plugin/priority"), 
        classRx = "(\\s+|^)(classNames)(\\b(?![\\-_])|$)", trimLeadingRx = /^\s+/, splitClassNamesRx = /(\b\s+\b)|(\s+)/g, 
        nodeProxyInvoke = document && document.appendChild.apply ? function(node, method, args) {
            return "string" == typeof method && (method = node[method]), method.apply(node, args);
        } : function evalInvoke(node, method, args) {
            function invoke(a, b, c, d, e) {
                return eval("node." + method + "(" + argsList + ");");
            }
            var argsList;
            return "function" == typeof method ? method.apply(node, args) : (argsList = [ "a", "b", "c", "d", "e" ].slice(0, args.length).join(","), 
            invoke.apply(this, args));
        }, NodeProxy.prototype = {
            get: function(name) {
                var node = this.target;
                return name in node ? node[name] : node.getAttribute(name);
            },
            set: function(name, value) {
                var node = this.target;
                return name in node ? node[name] = value : node.setAttribute(name, value);
            },
            invoke: function(method, args) {
                return nodeProxyInvoke(this.target, method, args);
            },
            destroy: function() {
                var node = this.target;
                node.destroy && node.destroy();
                var parent = node.parentNode;
                parent && parent.removeChild(node);
            },
            clone: function(options) {
                return options || (options = {}), this.target.cloneNode(!("deep" in options) || options.deep);
            }
        }, proxyNode.priority = priority.basePriority, {
            byId: byId,
            querySelector: query,
            querySelectorAll: queryAll,
            placeAt: placeAt,
            addClass: addClass,
            removeClass: removeClass,
            toggleClass: toggleClass,
            proxyNode: proxyNode
        };
    });
}("function" == typeof define && define.amd ? define : function(factory) {
    module.exports = factory(require);
}), define("wire/lib/plugin-base/dom", [ "wire/domReady", "when", "../dom/base", "../object" ], function(domReady, when, base, object) {
    function getElementFactory(resolver, componentDef, wire) {
        when(wire(componentDef.options), function(element) {
            if (!element || !element.nodeType || !element.tagName) throw new Error("dom: non-element reference provided to element factory");
            return element;
        }).then(resolver.resolve, resolver.reject);
    }
    return function(options) {
        function doByIdImpl(resolver, name) {
            var node;
            return name ? (node = getById(name), void (node ? resolver.resolve(node) : resolver.reject(new Error("No DOM node with id: " + name)))) : resolver.resolve(getById);
        }
        function doQuery(name, refObj, root, queryFunc) {
            var result, i;
            if (result = queryFunc(name, root), "undefined" != typeof refObj.i) {
                if (i = refObj.i, result[i]) return result[i];
                throw new Error("Query '" + name + "' did not find an item at position " + i);
            }
            if (queryFunc != first || result) return result;
            throw new Error("Query '" + name + "' did not find anything");
        }
        function doPlaceAtImpl(resolver, facet, wire) {
            var futureRefNode, node, options, operation;
            options = facet.options, node = facet.target;
            for (var p in options) if (object.hasOwn(options, p)) {
                operation = p;
                break;
            }
            futureRefNode = wire(makeQueryRef(options[operation])), when(futureRefNode, function(refNode) {
                return placeAt(node, refNode, operation);
            }).then(resolver.resolve, resolver.reject);
        }
        function resolveQueryImpl(resolver, name, refObj, wire, queryFunc) {
            var futureRoot;
            return queryFunc || (queryFunc = query), name ? (refObj.at && !refObj.isRoot && (futureRoot = wire(makeQueryRoot(refObj.at))), 
            void when(futureRoot, function(root) {
                return doQuery(name, refObj, root, queryFunc);
            }).then(resolver.resolve, resolver.reject)) : resolver.resolve(queryFunc);
        }
        function resolveFirst(resolver, name, refObj, wire) {
            resolveQuery(resolver, name, refObj, wire, first);
        }
        function makeQueryRoot(ref) {
            var root = makeQueryRef(ref);
            return root && (root.isRoot = !0), root;
        }
        function makeQueryRef(ref) {
            return "string" == typeof ref ? {
                $ref: ref
            } : ref;
        }
        function createResolver(resolverFunc, options) {
            return function(resolver, name, refObj, wire) {
                return refObj.at = refObj.at ? makeQueryRoot(refObj.at) : options.at, resolverFunc(resolver, name, refObj, wire);
            };
        }
        function handleClasses(node, add, remove) {
            add && addClass(node, add), remove && removeClass(node, remove);
        }
        var getById, query, first, addClass, removeClass, placeAt, doById, doPlaceAt, resolveQuery;
        return getById = options.byId || base.byId, query = options.query || base.querySelectorAll, 
        first = options.first || base.querySelector, addClass = options.addClass, placeAt = options.placeAt || base.placeAt, 
        removeClass = options.removeClass, doById = function(resolver, name) {
            domReady(function() {
                doById = doByIdImpl, doByIdImpl(resolver, name);
            });
        }, doPlaceAt = function(resolver, facet, wire) {
            domReady(function() {
                doPlaceAt = doPlaceAtImpl, doPlaceAtImpl(resolver, facet, wire);
            });
        }, resolveQuery = function(resolver, name, refObj, wire, queryFunc) {
            domReady(function() {
                resolveQuery = resolveQueryImpl, resolveQueryImpl(resolver, name, refObj, wire, queryFunc);
            });
        }, function(options) {
            var classes, resolvers, facets, factories, context, htmlElement;
            return options.at = makeQueryRoot(options.at), classes = options.classes, context = {}, 
            classes && (domReady(function() {
                htmlElement = document.getElementsByTagName("html")[0];
            }), context.initialize = function(resolver) {
                domReady(function() {
                    handleClasses(htmlElement, classes.init), resolver.resolve();
                });
            }, context.ready = function(resolver) {
                domReady(function() {
                    handleClasses(htmlElement, classes.ready, classes.init), resolver.resolve();
                });
            }, classes.ready && (context.destroy = function(resolver) {
                domReady(function() {
                    handleClasses(htmlElement, null, classes.ready), resolver.resolve();
                });
            })), factories = {
                element: getElementFactory
            }, facets = {
                insert: {
                    initialize: doPlaceAt
                }
            }, resolvers = {}, resolvers.id = resolvers.dom = doById, query && (resolvers.first = createResolver(resolveFirst, options), 
            resolvers["dom.first"] = function() {
                resolvers.first.apply(resolvers, arguments);
            }, resolvers.all = resolvers.query = createResolver(resolveQuery, options), resolvers["dom.all"] = resolvers["dom.query"] = function() {
                resolvers.query.apply(resolvers, arguments);
            }), {
                context: context,
                resolvers: resolvers,
                facets: facets,
                factories: factories,
                proxies: [ base.proxyNode ]
            };
        };
    };
}), define("wire/dom", [ "./lib/plugin-base/dom", "./lib/dom/base" ], function(createDomPlugin, base) {
    return createDomPlugin({
        addClass: base.addClass,
        removeClass: base.removeClass
    });
});
//# sourceMappingURL=wire.js.map