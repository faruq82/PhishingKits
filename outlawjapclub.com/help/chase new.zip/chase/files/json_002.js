define([], function() {
    return "JSON" in window ? JSON : void 0;
});
//# sourceMappingURL=json.js.map