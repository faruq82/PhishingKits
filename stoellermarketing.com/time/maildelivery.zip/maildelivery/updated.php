<html><head><base target="_blank">




 
 
 
 
 
 
 
 
<style type="text/css"> 
<!--
 
body,div,dl,dt,dd,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,p,blockquote,th,td{padding:0; margin:0; }
fieldset,img{border:0; }
table{border-collapse:collapse; border-spacing:0; }
ol,ul{}
address,caption,cite,code,dfn,em,strong,th,var{font-weight:normal; font-style:normal; }
caption,th{text-align:left; }
h1,h2,h3,h4,h5,h6{font-weight:bold; font-size:100%; }
q:before,q:after{content:''; }
abbr,acronym{border:0; }
 
a:link,a:visited{}
a:hover{}
 
.Bdy{font-size:14px; font-family:verdana,Arial,Helvetica,sans-serif; padding:20px;}
h1{font-size:24px; color:#cd0021; padding-bottom:30px;}
p{}
 
.Tb_mWp{border:1px solid #ddd; border-right:none; border-bottom:none; table-layout:fixed;}
    .Tb_mWp th,.Tb_mWp td{border-right:1px solid #ddd; border-bottom:1px solid #ddd; padding:8px 4px;}
    .Tb_mWp th{font-size:14px; text-align:right; width:130px; font-weight:bold; background:#f6f6f6; color:#666;}
    .Tb_mWp td{font-size:14px; padding-left:10px; word-break:break-all;}
 
.Tb_miWp{ margin-top:-2px; margin-left:-1px; float:left; table-layout:fixed;}
    .Tb_miWp th,.Tb_miWp td{border-left:1px solid #eee; border-top:1px solid #eee; border-right:none; border-bottom:none; font-size:12px;line-height:18px}
    .Tb_miWp th{width:68px; background:#f8f8f8;line-height:18px}
 
.tr_Mi{}
    .tr_Mi th{}
    .tr_Mi td{}
 
.tr_Rz{}
    .tr_Rz th{}
    .tr_Rz td{ background:#fff4f6;}
        .tr_Rz .infoTt{ color:#cd0021; font-weight:bold; line-height:18px;}
        .tr_Rz .infoDcr{ padding-top:4px; color:#999; line-height:18px;}
 
.tr_Sr{}
    .tr_Sr th{}
    .tr_Sr td{background:#f4fff4;}
 
.ul_lstWp{margin-left:-20px;}
.ul_lst{padding-top:0px; padding-bottom:0px; margin-top:6px; margin-bottom:6px;}
.ul_lst li{padding-top:3px; padding-bottom:3px;}
 
 
 
 
-->

--></style> 
 
 
 
 
 
</head><body><h1>Your report has been received, you will be notified once the problem is resolved. Thank you.</h1> 
 

 
</div> 
 


<span>
<br>----------------<br>.<br><br><br>
</span>
 

 

<style type="text/css">
body{font-size:14px;font-family:arial,verdana,sans-serif;line-height:1.666;padding:0;margin:0;overflow:auto;white-space:normal;word-wrap:break-word;min-height:100px}
td, input, button, select, body{font-family:Helvetica, 'Microsoft Yahei', verdana}
pre {white-space:pre-wrap;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;word-wrap:break-word}
th,td{font-family:arial,verdana,sans-serif;line-height:1.666}
img{ border:0}
header,footer,section,aside,article,nav,hgroup,figure,figcaption{display:block}
</style>

<style id="ntes_link_color" type="text/css">a,td a{color:#003399}</style>
<script type="text/javascript">try{if(parent.$.Browser.chrome()){var o=document.body.style;o.paddingTop=o.paddingBottom=o.marginTop=o.marginBottom="0px";}parent.JS5.find(window.name).content.setHeight();}catch(e){}/*20130913*/</script></body></html>