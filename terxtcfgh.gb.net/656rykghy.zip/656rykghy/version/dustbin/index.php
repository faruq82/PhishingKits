<?php

//Here to protect dis folder.
//send everyone to index
header("Location: ../index.php");
//////////////////////////////////////////\\
//\\files saved here are for d page
//\\really shouldn't be deleted
//\\unless u know wat u're doin
//////////////////////////////////////////\\
?>
