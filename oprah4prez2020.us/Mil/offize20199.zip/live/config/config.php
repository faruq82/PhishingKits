<?php
$to = 'hack@hackaton.com';
$backup = 1;