<?php
include 'header.php'
?>
<body>
    <div id="wrapper">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="#">Korkai</a>
          </div>
          <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
              <li class="active"><a href="">Home</a></li>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Page 1 <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="#">Page 1-1</a></li>
                  <li><a href="#">Page 1-2</a></li>
                  <li><a href="#">Page 1-3</a></li>
                </ul>
              </li>
              <li><a href="#">Page 2</a></li>
              <li><a href="#">Page 3</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
              <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
            </ul>
          </div>
        </div>
      </nav>
      <div id="map"></div>
    </div>

<script src="./js/jquery-3.2.1.min.js"></script>
<script src="./js/leaflet.js"></script>
<script src="./js/easy-button.js"></script>
<script src="./js/TileLayer.Grayscale.js"></script>
<script src="./js/swal.js"></script>
<script src="./js/alertify.min.js"></script>
<script src="./js/index.js"></script>
<script src="./js/L.Icon.Pulse.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<div id="la">



</div>
<script>
L.easyButton('fa-info', function(btn, map) {
var pre = document.createElement('pre');
pre.style.maxHeight = "400px";
pre.style.margin = "0";
pre.style.padding = "24px";
pre.style.whiteSpace = "pre-wrap";
pre.style.textAlign = "left";
pre.appendChild(document.createTextNode($('#la').text()));
alertify.confirm(pre, function(){
       
    }).set({labels:{ok:'Ok', cancel: ''}, padding: false});
 }).addTo(map);

</script>
</body>
</html>
