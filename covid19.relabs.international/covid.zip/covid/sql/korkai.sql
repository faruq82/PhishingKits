 // create a database  
CREATE DATABASE salvation
USE salvation

// create a table studentdetails   
CREATE TABLE IF NOT EXISTS salvationdetails 
(
  id int(11) NOT NULL AUTO_INCREMENT,
  lat DECIMAL(10, 8) NOT NULL, 
  lng DECIMAL(11, 8) NOT NULL,
  name char(50) NOT NULL,
  address varchar(150) NOT NULL,
  mnumber bigint(20) NOT NULL,
  pincode bigint(20) NOT NULL,
  need varchar(500) NOT NULL,
  upi varchar(50) NOT NULL,
  registrationDate DATETIME,
  PRIMARY KEY (id),
  UNIQUE KEY mnumber (mnumber)
) 

CREATE TABLE IF NOT EXISTS thoughts
(
id int(11) NOT NULL AUTO_INCREMENT,
  lat DECIMAL(10, 8) NOT NULL, 
  lng DECIMAL(11, 8) NOT NULL,
  name char(500) NOT NULL,
  thoughts varchar(500) NOT NULL,
  registrationDate DATETIME,
    PRIMARY KEY (id)
  
) 

CREATE TABLE IF NOT EXISTS coviddata
(
  id int(11) NOT NULL AUTO_INCREMENT,
  PatientNumber VARCHAR(15),
  DateAnnounced DATE,
  AgeBracket int(3),
  Gender CHAR(1),
  DetectedCity CHAR(20),
  DetectedDistrict CHAR(20),
  DetectedState CHAR(20),
  CurrentStatus CHAR(20),
  Notes VARCHAR(150),
  Suspected VARCHAR(10),
  Nationality VARCHAR(20),
  PRIMARY KEY (id)
  
)
CREATE TABLE IF NOT EXISTS annam 
(
  id int(11) NOT NULL AUTO_INCREMENT,
  storeid int(11) NOT NULL,
  lat DECIMAL(10, 8) NOT NULL, 
  lng DECIMAL(11, 8) NOT NULL,
  name char(50) NOT NULL,
  address varchar(150) NOT NULL,
  mnumber bigint(20) NOT NULL,
  need varchar(500) NOT NULL,
  upi varchar(50) NOT NULL,
  orderdatetime DATETIME,
  PRIMARY KEY (id),
  UNIQUE KEY mnumber (mnumber)
) 

CREATE TABLE IF NOT EXISTS coordinates
(
  id int(11) NOT NULL AUTO_INCREMENT,
  lat DECIMAL(10, 8) NOT NULL, 
  lng DECIMAL(11, 8) NOT NULL,
  counts int(11) NOT NULL,
  PRIMARY KEY (id)
  
) 

CREATE TABLE IF NOT EXISTS coviddata
(
  id int(11) NOT NULL AUTO_INCREMENT,
  state VARCHAR(30) NOT NULL,
  city VARCHAR(50) NOT NULL,
  lat DECIMAL(10, 8) NOT NULL, 
  lng DECIMAL(11, 8) NOT NULL,
  counts int(11) NOT NULL,
  PRIMARY KEY (id)
  
) 

CREATE TABLE IF NOT EXISTS food 
(
  id int(11) NOT NULL AUTO_INCREMENT,
  lat DECIMAL(10, 8) NOT NULL, 
  lng DECIMAL(11, 8) NOT NULL,
  name char(50) NOT NULL,
  address varchar(150) NOT NULL,
  mnumber bigint(20) NOT NULL,
  registrationDate DATETIME,
  PRIMARY KEY (id),
  UNIQUE KEY mnumber (mnumber)
) 


SELECT 
    DetectedState, COUNT(DetectedState),
    CurrentStatus,  COUNT(CurrentStatus)
FROM
    coviddata
GROUP BY 
    DetectedState , 
    CurrentStatus 

HAVING  COUNT(DetectedState) > 1
    AND COUNT(CurrentStatus) > 1 ;