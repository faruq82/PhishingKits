<?php
include 'header.php';
?>
<style>
#banner {
  position: absolute;
  left: 20%;
  right: 20%;
  bottom: 12px;
  height: 50px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 4px;
  z-index: 1001;
  text-align: center;
}
</style>
<body>
<div id="map"></div>
<div id="la"></div>
<script src="./js/heatmap.min.js"></script>
<script src="./js/leaflet-heatmap.js"></script>
<script src="./js/heatindex.js"></script>
<?php 
include 'footer.php'
?>
</body>
</html>
