<?php
include 'config.php';

    $sql = "SELECT * FROM countdata";

    $rs = mysqli_query($con,$sql);

    if (!$rs) {

        echo "An SQL error occured.\n";

        exit;

    }   
    $json = array(

        'data'  => array()
     );
     while($row = mysqli_fetch_assoc($rs)) {
        $data = array(
             $row['city'],
             $row['lat'],
             $row['lng'],
             $row['counts'],

             );
         # Add feature arrays to feature collection array
         array_push($json['data'], $data);
     }
     
     header('Content-type: application/json');
     echo json_encode($json, JSON_NUMERIC_CHECK);

    $db = NULL;

?>