<?php
include 'header.php'
?>
<body>
<div id="map"></div>

<script src="./js/thoughtsmarker.js"></script>
<?php
include 'footer.php'
?>
</body>
</html>
