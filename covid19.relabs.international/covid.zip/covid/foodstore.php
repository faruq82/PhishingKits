<?php
include 'config.php';
$lat = $con -> real_escape_string($_POST['lat']);
$lng = $con -> real_escape_string($_POST['lng']);
$name = $con -> real_escape_string($_POST['name']);
$address = $con -> real_escape_string($_POST['address']);
$mnumber = $con -> real_escape_string($_POST['mnumber']);


$query="insert into food values('','$lat','$lng','$name','$address','$mnumber',now())";
if (!$con -> query($query)) {
    printf("%d Your Requested has beeb submitted. Wait for the delivery\n");
  } else {
    header("Location:getfood.php");
  }
  
  $con -> close();
  ?>