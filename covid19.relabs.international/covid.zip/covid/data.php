<?php
include 'header.php'
?>
<link href='DataTables/datatables.min.css' rel='stylesheet' type='text/css'>
<script src="DataTables/datatables.min.js"></script>

    <body>

        <div >
            <!-- Table -->
            <table id='salTable' class='display dataTable'>
                <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Date</th>
                    <th>Address</th>
                    <th>Need</th>
                    <th>Pincode</th>
                    <th>Location</th>
                </tr>
                </thead>
                
            </table>
        </div>
        
        <!-- Script -->
        <script>
        $(document).ready(function(){
            $('#salTable').DataTable({
                'processing': true,
                'serverSide': true,
                'serverMethod': 'post',
                'ajax': {
                    'url':'ajaxfile.php'
                },
                
                'columns': [
                    { data: 'id' },
                    { data: 'name' },
                    { data: 'registrationDate' },
                    { data: 'address' },
                    { data: 'need' },
                    { data:  'pincode'},
                    {
                        data: 'location',
                        "render": function(data, type, row, meta){
            if(type === 'display'){
                data = '<a href="https://www.openstreetmap.org/#map=14/' + row.lat + '/'+ row.lng+'" target="_blank">Click here</a>';
            }

            return data;}
                    }
                   ]
            });
        });
        </script>


    </body>

</html>
