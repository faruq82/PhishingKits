var southWest = L.latLng(13.496472765758952, 76.35498046875),
    northEast = L.latLng(7.743651345263343, 80.91430664062499)
// bounds = L.latLngBounds(southWest, northEast);
/*var map = new L.Map('map', {
    center: [9.59262549583373, 79.4036865234375],
    maxBounds: bounds,
    zoom: 7,
    zoomControl: false
});*/
//watermark
/*var testData = {
    max: 2,
    data: [{ lat: 13.084622, lng: 80.248357, count: 13, city: 'chennai' },
    { lat: 11.016844, lng: 76.955833, count: 1, city: 'coimbatore' },
    { lat: 8.741222, lng: 77.694626, count: 1, city: 'Tirunelveli' },
    { lat: 11.27564, lng: 77.58794, count: 3, city: 'erode' },
    { lat: 11.664325, lng: 78.146011, count: 5, city: 'salem' },
    { lat: 12.932063, lng: 79.333466, count: 1, city: 'ranipet' },
    { lat: 9.939093, lng: 78.121719, count: 1, city: 'madurai' },
    { lat: 11.110695, lng: 77.348045, count: 1, city: 'tiruppur' },
    { lat: 10.8155, lng: 78.69651, count: 1, city: 'trichy' }
    ]
};*/
var geoData

$.ajax({
    url: "heatmap.php",
    type: "GET",
    datatype: "json",
    success: function (data) {
        //alert("ajax transfer successful ");
        geoData = data;
        //console.log(geoData.data.length)  //For debugging:
        var cfg = {
            "radius": 0.3,
            "maxOpacity": .8,
            "scaleRadius": true,
            "useLocalExtrema": true,
            latField: 'lat',
            lngField: 'lng',
            valueField: 'count'
        };

        var heatmapLayer = new HeatmapOverlay(cfg);
        heatmapLayer.setData(geoData);
        var baseLayer = L.tileLayer.grayscale('https://a.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 17,
            minZoom: 5,
            noWrap: true,
            attribution: ' &copy; <a href="https://leafletjs.com" target="_blank">Leaflet</a> | <a href="https://openstreetmap.org" target="_blank">openstreetmap</a> | <a href="https://github.com/vignesan" target="_blank">Relabs</a> '
        });
        var map = new L.Map('map', {
            center: [21.9430455334, 78.1787109375],
            // maxBounds: bounds,
            zoom: 5,
            zoomControl: true,
            layers: [baseLayer, heatmapLayer]
        });
        map.attributionControl.setPrefix('');
        L.Control.Watermark = L.Control.extend({
            onAdd: function (map) {
                var img = L.DomUtil.create('img');
                img.src = './css/images/logo.png';
                img.style.width = '50px';
                return img;
            },
        });
        L.control.watermark = function (opts) {
            return new L.Control.Watermark(opts);
        }
        L.control.watermark({ position: 'bottomleft' }).addTo(map);
    }

})