/* Copyright (C) 2020  Vignesan Selvam

    Korkai is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Korkai is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. */
var geoData

$.ajax({
    url: "clustermap.php",
    type: "GET",
    datatype: "json",
    success: function (data) {
        //alert("ajax transfer successful ");
        geoData = data;
        //console.log(geoData.data)
        var southWest = L.latLng(13.496472765758952, 76.35498046875),
            northEast = L.latLng(7.743651345263343, 80.91430664062499),
            bounds = L.latLngBounds(southWest, northEast);
        var map = new L.Map('map', {
            center: [21.9430455334, 78.1787109375],
            //maxBounds: bounds,
            zoom: 5,
            zoomControl: true
        });
        map.attributionControl.setPrefix('');
        //watermark
        L.control.scale().addTo(map);

        L.Control.Watermark = L.Control.extend({
            onAdd: function (map) {
                var img = L.DomUtil.create('img');
                img.src = './css/images/logo.png';
                img.style.width = '50px';
                return img;
            },
        });
        L.control.watermark = function (opts) {
            return new L.Control.Watermark(opts);
        }
        L.control.watermark({ position: 'bottomleft' }).addTo(map);
        L.tileLayer.grayscale('https://a.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 17,
            minZoom: 3,
            noWrap: true,
            attribution: ' &copy; <a href="https://leafletjs.com" target="_blank">Leaflet</a> | <a href="https://openstreetmap.org" target="_blank">openstreetmap</a> | <a href="https://github.com/vignesan" target="_blank">Relabs</a> '
        }).addTo(map);
        /*var lc = L.control.locate({
            position: 'bottomright',
        }).addTo(map);*/
        var addressPoints = [
            [13.084622, 80.248357, 'chennai', 25],
            [11.016844, 76.955833, 'coimbatore', 10],
            [8.741222, 77.694626, 'Tirunelveli', 3],
            [11.27564, 77.58794, 'erode', 10],
            [11.664325, 78.146011, 'salem', 15],
            [12.932063, 79.333466, 'ranipet', 20],
            [9.939093, 78.121719, 'madurai', 30],
            [11.110695, 77.348045, 'tiruppur', 100],
            [10.8155, 78.69651, 'trichy', 150]


        ]

        var mcg = L.markerClusterGroup({
            chunkedLoading: true,
            //singleMarkerMode: true,
            spiderfyOnMaxZoom: true
        });

        for (var i = 0; i < geoData.data.length; i++) {
            //console.log(addressPoints.length)
            var a = geoData.data[i];
            for (var j = 0; j < a[3]; j++) {
                var title = a[0];
                var content = '<h4>' + title + '</h4>Data Provider:<a href="http://covid19india.org">covid19india.org</a>'
                //console.log(a[3])
                var marker = L.marker(new L.LatLng(a[1] + 0.01 * Math.random(), a[2] + 0.02 * Math.random()));
                marker.bindPopup(content);
                mcg.addLayer(marker);
                //console.log(i)

            }

        }

        map.addLayer(mcg);
       
    }

})