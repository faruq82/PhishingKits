/* Copyright (C) 2020  Vignesan Selvam

    Korkai is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Korkai is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>. */

    var southWest = L.latLng(13.496472765758952, 76.35498046875),
    northEast = L.latLng(7.743651345263343, 80.91430664062499),
    bounds = L.latLngBounds(southWest, northEast);
var map = new L.Map('map', {
    center: [9.59262549583373, 79.4036865234375],
    maxBounds: bounds,
    zoom: 7,
    zoomControl: false
});
map.attributionControl.setPrefix('');
//watermark
L.Control.Watermark = L.Control.extend({
    onAdd: function (map) {
        var img = L.DomUtil.create('img');
        img.src = './css/images/logo.png';
        img.style.width = '50px';
        return img;
    },
});
L.control.watermark = function (opts) {
    return new L.Control.Watermark(opts);
}
L.control.watermark({ position: 'bottomleft' }).addTo(map);
L.tileLayer.grayscale('https://a.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 17,
    minZoom: 7,
    noWrap: true,
    attribution: ' &copy; <a href="https://leafletjs.com" target="_blank">Leaflet</a> | <a href="https://openstreetmap.org" target="_blank">openstreetmap</a> | <a href="https://github.com/vignesan" target="_blank">Relabs</a> '
}).addTo(map);
/*var lc = L.control.locate({
    position: 'bottomright',
}).addTo(map);*/
var Icon = L.icon({
    iconUrl: "./css/images/marker-icon-2x.png",
    iconSize: [25, 25]
});

var current_position, current_accuracy, marker3, lat1, lon1, cssIcon, marker;
function onLocationFound(e) {
    if (current_position) {
        map.removeLayer(current_position);
        map.removeLayer(current_accuracy);
    }
    var radius = e.accuracy / 8;
    lat = e.latlng.lat;
    lng = e.latlng.lng;

    var zoom = 10;
    map.setView(e.latlng, zoom, {
        "animate": true,
        "pan": {
            "duration": 5
        }
    });
    $.getJSON("marker.php", function (data) {

    for (var i = 0; i < data.length; i++) {
        lon1 = data[i].lng;
        lat1 = data[i].lat;
        R = 6378.137;
        dLat = lat1 * Math.PI / 180 - lat * Math.PI / 180;
        dLon = lon1 * Math.PI / 180 - lng * Math.PI / 180;
        a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat * Math.PI / 180) * Math.cos(lat1 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        d = R * c;
        z = d * 1;
        if (z <= 5) {
            
        var location = new L.LatLng(data[i].lat, data[i].lng);

        var id = data[i];

        var name = data[i].name;

        var addr1 = data[i].address;

        var marker = new L.Marker(location, {

            icon: Icon,

            title: name

        });

        var content = "<h4>"+ name +"<br/></h4><form action='./store.php' method='post'><input type='hidden' name='lat' value="+id+" ><input type='hidden' name='lat' value="+lat+" ><input type='hidden' name='lng' value="+lng+" ><label for='name'>Enter your name:</label><br /><input type='text' name='name' required><br /><label for='address'>Enter your address:</label><br /><input type='text' name='address' required><br /><label for='mnum'>Enter mobile number</label><br /><input type='number' name='mnumber' required><br /><label for='mnum'>Enter your pincode</label><br /><input type='number' name='pincode' required><br /><label for='need'>Enter your need:</label><br /><input type='text' name='need' required><label for='upi'>Enter your UPI ID or UPI phone number</label><br /><input type='text' name='upi' required><br /><br /><input type='submit' value='Submit'></form>"


        marker.bindPopup(content, {

            maxWidth: '200'

        });
        marker.addTo(map);
            

        }

    }
});
}
map.on('locationfound', onLocationFound);
L.easyButton('fa-map-marker', function (btn, map) {
    map.locate({ setView: true });
}).addTo(map);
var marker;
/*map.on('click', 
		function(e){    
            
            if (marker) { // check
                map.removeLayer(marker); // remove
            }
          
            lat = e.latlng.lat;
            lng = e.latlng.lng;
            
		 		
		 	marker=	L.marker(e.latlng).addTo(map);
		 	});

*/