<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0 minimum-scale=1, maximum-scale=1">
<title>Relabs</title>  

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="./css/leaflet.css"/>
<link rel="stylesheet" href="./css/korkai.css"/>
<link rel="stylesheet" href="./css/sweetalert.css" /> 
<link rel="stylesheet" href="./css/easy-button.css" />     
<link rel="stylesheet" href="./css/alertify.min.css" />
<link rel="stylesheet" href="./css/default.min.css" /> 
<link rel="stylesheet" href="./css/L.Icon.Pulse.css" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<script src="./js/jquery-3.2.1.min.js"></script>
<script src="./js/leaflet.js"></script>
<script src="./js/easy-button.js"></script>
<script src="./js/TileLayer.Grayscale.js"></script>
<script src="./js/swal.js"></script>
<script src="./js/alertify.min.js"></script>
<script src="./js/L.Icon.Pulse.js"></script>
<script src="./js/about.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>