<?php
include 'header.php'
?>
<link rel="stylesheet" href="./css/MarkerCluster.css"/>
<link rel="stylesheet" href="./css/MarkerCluster.Default.css" /> 
<body>
  
 <div id="map"></div>

 <script src="./js/leaflet.markercluster-src.js"></script>
<script src="./js/clusterindex.js"></script>
<?php
include 'footer.php'
?>
</body>
</html>
