<?php
/* Database connection start */
$db_host = 'localhost'; 
$db_user = 'root'; 
$db_pass = 'root'; 
$db_name = 'salvation';
$con=mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if ($con->connect_error)
{
    die('Connect Error (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}


