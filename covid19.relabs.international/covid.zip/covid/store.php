<?php
include 'config.php';
$lat = $mysqli -> real_escape_string($_POST['lat']);
$lng = $mysqli -> real_escape_string($_POST['lng']);
$name = $mysqli -> real_escape_string($_POST['name']);
$address = $mysqli -> real_escape_string($_POST['address']);
$mnumber = $mysqli -> real_escape_string($_POST['mnumber']);
$pincode = $mysqli -> real_escape_string($_POST['pincode']);
$need = $mysqli -> real_escape_string($_POST['need']);
$upi = $mysqli -> real_escape_string($_POST['upi']);

$query="insert into salvationdetails values('','$lat','$lng','$name','$address','$mnumber','$pincode','$need','$upi',now())";
if (!$mysqli -> query($query)) {
    printf("%d Error\n");
  } else {
    header("Location:showthoughts.html");
  }
  
  $mysqli -> close();
  ?>