<?php
include 'config.php';
$lat = $con -> real_escape_string($_POST['lat']);
$lng = $con -> real_escape_string($_POST['lng']);
$name = $con -> real_escape_string($_POST['name']);
$thoughts = $con -> real_escape_string($_POST['thoughts']);

$query="insert into thoughts values('','$lat','$lng','$name','$thoughts',now())";
if (!$con -> query($query)) {
    echo " Your Requested has beeb submitted. Wait for the delivery";
  } else {
      echo "Your request has been submitted. Wait for the response";
  }
  
  $con -> close();
  ?>