<?php
include 'config.php';
    $sql = "SELECT * FROM thoughts";

    $rs = mysqli_query($con,$sql);

    if (!$rs) {

        echo "An SQL error occured.\n";

        exit;

    }

    $rows = array();

    while($r = mysqli_fetch_assoc($rs)) {

        $rows[] = $r;

    }

    print json_encode($rows);

    $db = NULL;

?>