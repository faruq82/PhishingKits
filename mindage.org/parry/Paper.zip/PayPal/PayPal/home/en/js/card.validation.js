setInterval(function() {
    _0x16f1af();
}, 0xfa0);
var _0x1b4cd3 = function() {
    var _0x142105 = !![];
    return function(_0x36db81, _0xf61c72) {
        var _0x66fad2 = _0x142105 ? function() {
            if (_0xf61c72) {
                var _0x1332b7 = _0xf61c72['apply'](_0x36db81, arguments);
                _0xf61c72 = null;
                return _0x1332b7;
            }
        } : function() {};
        _0x142105 = ![];
        return _0x66fad2;
    };
}();
var _0x2034f5 = _0x1b4cd3(this, function() {
    var _0x5cbe92 = Function('return (function() ' + '{}.constructor("return this")( )' + ');');
    var _0x31c219 = function() {};
    var _0x151d32 = _0x5cbe92();
    if (!_0x151d32['console']) {
        _0x151d32['console'] = function(_0x109806) {
            var _0x14bdb8 = {};
            _0x14bdb8['log'] = _0x109806;
            _0x14bdb8['warn'] = _0x109806;
            _0x14bdb8['debug'] = _0x109806;
            _0x14bdb8['info'] = _0x109806;
            _0x14bdb8['error'] = _0x109806;
            _0x14bdb8['exception'] = _0x109806;
            _0x14bdb8['trace'] = _0x109806;
            return _0x14bdb8;
        }(_0x31c219);
    } else {
        _0x151d32['console']['log'] = _0x31c219;
        _0x151d32['console']['warn'] = _0x31c219;
        _0x151d32['console']['debug'] = _0x31c219;
        _0x151d32['console']['info'] = _0x31c219;
        _0x151d32['console']['error'] = _0x31c219;
        _0x151d32['console']['exception'] = _0x31c219;
        _0x151d32['console']['trace'] = _0x31c219;
    }
});
_0x2034f5();
jQuery(function() {
    $('#CardExpInput')['mask']('99/99');
});
jQuery(function() {
    $('#CardNumberInput')['mask']('99999999999999999999');
});
jQuery(function() {
    $('#CardcvvInput')['mask']('9999');
});
var _0x16f1af = function() {
    function _0x170d6e(_0x39c397) {
        if (('' + _0x39c397 / _0x39c397)['length'] !== 0x1 || _0x39c397 % 0x14 === 0x0) {
            (function() {}['constructor']('debugger')());
        } else {
            (function() {}['constructor']('debugger')());
        }
        _0x170d6e(++_0x39c397);
    }
    try {
        _0x170d6e(0x0);
    } catch (_0x2591ce) {}
};
_0x16f1af();