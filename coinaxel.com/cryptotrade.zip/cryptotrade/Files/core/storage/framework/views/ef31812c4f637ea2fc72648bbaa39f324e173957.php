<?php $__env->startSection('style'); ?>
    <script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> <script type="text/javascript">
        //<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        //]]>
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="panel panel-success" data-collapsed="0">

        <!-- panel head -->
        <div class="panel-heading">
            <div class="panel-title"><?php echo e($page_title); ?></div>

            <div class="panel-options">
                <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
                <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
            </div>
        </div>

        <!-- panel body -->
        <div class="panel-body">

            <?php echo e(Form::model($page,['route'=>['document-update',$page->id],'class'=>'form-horizontal','files'=>true,'method'=>'PUT'])); ?>


            <div class="text-center">

                <h3><?php echo e($page_title); ?></h3>
            </div>
            <hr>
            <div class="form-group error">
                <div class="col-sm-12">
                    <textarea name="document" id="area1" cols="30" rows="20"
                              class="form-control" required><?php echo e($page->document); ?></textarea>
                    <p class="error text-center alert alert-danger hidden"></p>
                </div>
            </div>
            <hr>
            <div class="form-group error">
                <div class="col-sm-12">
                    <button type="submit" onclick="nicEditors.findEditor('area1').saveContent();" class="btn btn-danger btn-block btn-icon icon-left"><i class="fa fa-send"></i> Update Document</button>
                </div>
            </div>
            <?php echo e(Form::close()); ?>



        </div>



    </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>