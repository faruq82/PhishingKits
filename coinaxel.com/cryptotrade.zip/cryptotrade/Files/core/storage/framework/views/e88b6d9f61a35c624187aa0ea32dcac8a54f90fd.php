
<?php $__env->startSection('style'); ?>
    <style>
        span.label{
            font-size: 12px; !important;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <script type="text/javascript">
        jQuery( document ).ready( function( $ ) {
            var $table4 = jQuery( "#table-4" );

            $table4.DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        } );
    </script>

    <table class="table table-striped table-hover table-bordered datatable" id="table-4">
        <thead>
        <tr>
            <th>Sl No</th>
            <th>Date Time</th>
            <th>Invest Plan</th>
            <th>Invest ID</th>
            <th>Invest Amount</th>
            <th>Invest Commission</th>
            <th>Repeat Time</th>
            <th>Repeat Compound</th>
            <th>Status</th>
        </tr>
        </thead>
        <tbody>
        <?php  $i = 0; ?>
        <?php $__currentLoopData = $deposit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php  $i++; ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td width="10%"><?php echo e(date('d-F-Y h:s:i A',strtotime($p->created_at))); ?></td>
                <td><span class="aaaa"><strong><?php echo e($p->plan->name); ?></strong></span></td>
                <td>#<?php echo e($p->deposit_number); ?></td>
                <td><?php echo e($p->amount); ?> - <?php echo e($basic->currency); ?></td>
                <td width="13%"><?php echo e($p->percent); ?> %</td>
                <td><?php echo e($p->time); ?> - times</td>
                <td><span class="aaaa"><strong><?php echo e($p->compound->name); ?></strong></span></td>
                <td>
                    <?php if($p->status == 0): ?>
                        <span class="label label-secondary"><i class="fa fa-spinner"></i> Running</span>
                    <?php else: ?>
                        <span class="label label-success"><i class="fa fa-check" aria-hidden="true"></i> Completed</span>
                    <?php endif; ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>

    <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel"> <i class='fa fa-exclamation-triangle'></i> Confirmation..!</h4>
                </div>

                <div class="modal-body">
                    <strong>Are you sure you want to Delete this.?</strong>
                </div>

                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('delete-news')); ?>" class="form-inline">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="id" class="abir_id" value="0">

                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger"><i class="fa fa-check"></i> Yes I'm Sure..!</button>
                    </form>
                </div>

            </div>
        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    <script>
        $(document).ready(function () {

            $(document).on("click", '.delete_button', function (e) {
                var id = $(this).data('id');
                $(".abir_id").val(id);

            });

        });
    </script>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/datatables.css')); ?>">

    <script src="<?php echo e(asset('assets/dashboard/js/datatables.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>