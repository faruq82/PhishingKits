<?php $__env->startSection('style'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/cus.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><i class="fa fa-send"></i> <strong><?php echo e($page_title); ?></strong></div>
                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="col-sm-12 text-center">
                                <div class="panel panel-info">
                                    <div class="panel-heading">
                                        <h3 style="font-size: 28px;"><b>
                                                <?php if($fund->payment_type == 1): ?>
                                                    Paypal
                                                <?php elseif($fund->payment_type == 2): ?>
                                                    Perfect Money
                                                <?php elseif($fund->payment_type == 3): ?>
                                                    BTC - ( BlockChain )
                                                <?php else: ?>
                                                    Credit Card
                                                <?php endif; ?>
                                            </b></h3>
                                    </div>
                                    <div style="font-size: 18px;padding: 18px;" class="panel-body text-center">
                                        <?php if($fund->payment_type == 1): ?>
                                            <?php  $img = $payment->paypal_image  ?>
                                        <?php elseif($fund->payment_type == 2): ?>
                                            <?php  $img = $payment->perfect_image  ?>
                                        <?php elseif($fund->payment_type == 3): ?>
                                            <?php  $img = $payment->btc_image  ?>
                                        <?php else: ?>
                                            <?php  $img = $payment->stripe_image  ?>
                                        <?php endif; ?>
                                        <img width="100%" class="image-responsive" src="<?php echo e(asset('assets/images')); ?>/<?php echo e($img); ?>" alt="">
                                    </div>
                                    <hr>
                                    <div class="panel-footer">
                                        <a href="<?php echo e(url('user/fund-add')); ?>" class="btn btn-info btn-block btn-icon icon-left"><i
                                                    class="fa fa-arrow-left"></i> Back to Payment Method Page</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="panel panel-info panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                                <!-- panel head -->
                                <div class="panel-heading">
                                    <div class="panel-title"><i class="fa fa-money"></i> <strong><?php echo e($page_title); ?></strong></div>
                                </div>
                                <!-- panel body -->
                                <div class="panel-body">
                                    <div class="text-center">
                                        <h3>Current Balance : <strong><?php echo e(Auth::user()->amount); ?> - <?php echo e($basic->currency); ?></strong></h3>
                                    </div>
                                    <hr>
                                    <div class="row">
                                        <h4 style="text-align: center;"> SEND EXACTLY <strong><?php echo e($btc); ?> BTC </strong> TO <strong><?php echo e($add); ?></strong><br>
                                            <?php echo $code; ?> <br>
                                            <strong>SCAN TO SEND</strong> <br><br>
                                            <strong style="color: red;">NB: 3 Confirmation required to Credited your Account</strong>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div><!---ROW-->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>