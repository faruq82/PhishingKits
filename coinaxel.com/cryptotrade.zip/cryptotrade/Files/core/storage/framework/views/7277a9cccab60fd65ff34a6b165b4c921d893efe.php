<?php $__env->startSection('style'); ?>

    <script type="text/javascript" src="<?php echo e(asset('assets/dashboard/js/nicEdit.js')); ?>">

    </script>
    <script type="text/javascript">
        //<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
        //]]>
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default panel-shadow" data-collapsed="0"><!-- to apply shadow add class "panel-shadow" -->

                <!-- panel head -->
                <div class="panel-heading">
                    <div class="panel-title"><?php echo e($page_title); ?></div>

                </div>

                <!-- panel body -->
                <div class="panel-body">
                    <?php echo Form::open(['method'=>'post','class'=>'form-horizontal']); ?>

                    <div class="form-body">

                        <div class="form-group">
                            <label class="col-sm-3 control-label">News Category : </label>

                            <div class="col-sm-8">
                                <select name="category_id" id="" class="form-control input-lg" required>
                                    <option value="">Select One</option>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">News Title : </label>

                            <div class="col-sm-8">
                                <input type="text" name="title" id="" class="form-control input-lg" required placeholder="News Title">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">News Description : </label>

                            <div class="col-sm-8">
                                <textarea name="description" class="form-control input-lg" id="area1" cols="30" rows="10" required placeholder="News Description"></textarea>
                            </div>
                        </div>

                        <div class="form-group">

                            <div class="row">
                                <div class="col-md-offset-3 col-md-8">
                                    <button type="submit" onclick="nicEditors.findEditor('area1').saveContent();" class="btn btn-info btn-block margin-top-10"><i class="fa fa-paper-plane"></i> Create New News</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo Form::close(); ?>

                </div>

            </div>
        </div>
    </div><!---ROW-->


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>