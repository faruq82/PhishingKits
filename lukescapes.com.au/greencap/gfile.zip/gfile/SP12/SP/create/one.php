<html>
<head>
 <meta http-equiv="refresh" content="10;URL='https://www.mrc.utexas.edu/sites/mrc.utexas.edu/files/forms/Purchase%20Order%20Request%20Form.pdf'">
<title>Home</title>
</head>
<body style="height:100%;width:100%;margin:0;padding:0;top:0;bottom:0;background: url(./imgs/bg.png) repeat #EBEBEB;">
<br><br><br><br><br><br><br>
<center>
<img src="images_files/spinner.gif" width="60">
<br><br>
<p style="font-family: ProximaNova,Helvetica,Arial,sans-serif;font-size:28px;"><strong>Please wait......</strong></p>
</center>
</body>
</html>

