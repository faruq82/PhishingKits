	//supprime une valeur par d�faut
	function removeDefaultValue(current, defaultValue, classname){
		if (current.value == defaultValue) {
			current.value = '';
			current.className=classname;
		}
	}
	
	//ajoute une valeur par d�faut
	function addDefaultValue(current, defaultValue, classname){
		if (current.value == '') {
			current.value = defaultValue;
			current.className=classname;
		}
	}
	
   //change la couleur d'un champ input (ex: passage du gris de la valeur par d�faut au noir de la saisie) 	 
   function changeTextInputColor(id, defaultValue, classname){
		for(i=0; i<document.forms[0].elements.length; i++){
			if((document.forms[0].elements[i].id.indexOf(id)!=-1) && ((document.forms[0].elements[i].value=='') || (document.forms[0].elements[i].value==defaultValue))){
				document.forms[0].elements[i].className=classname;
				document.forms[0].elements[i].value=defaultValue;
			}
		}
	}
	
	//met les attributs autocomplete � off pour les elements d'un formulaire
	function setAutoCompleteOff(form){
		form.setAttribute("autocomplete", "off");
		for(i=0; i<form.elements.length; i++){
			form.elements[i].setAttribute("autocomplete", "off");
		}
	}
	
	//passe � la case suivante si la valeur saisie est correcte
	//gere aussi les del et l'utilisation des fleches
	function Autotab(current, name, evenement) {
		if(evenement != undefined){
			var touche = window.event ? evenement.keyCode : evenement.which;
			var reg = new RegExp('^[0-9]{1}', 'g');
			var regSept = new RegExp('^[0-9aAbB]{1}', 'g');
			var next = current + 1;
			var previous = current - 1;
			if (touche == 8){
				if(current!=1){
					document.getElementById(name+previous).focus();
					document.getElementById(name+previous).value=document.getElementById(name+previous).value;
					document.getElementById(name+previous).select();
				}
				document.getElementById(name+current).style="border: solid 1px #B75190; background-color: #FFFFFF;";
			} else {
				if(touche == 39 && (current!=13)){
					document.getElementById(name+next).focus();
					document.getElementById(name+next).select();
				} else if(touche == 37 && (current!=1)){
					document.getElementById(name+previous).focus();
					document.getElementById(name+previous).select();
				} else if ((touche == 9) && (document.getElementById(name+current).value!='')){
					document.getElementById(name+current).select();
				} else { 
					if(((document.getElementById(name+current).value!='') && (reg.test(document.getElementById(name+current).value)) && current != 7)
					   || ((document.getElementById(name+current).value!='') && (regSept.test(document.getElementById(name+current).value)) && current == 7)){
						document.getElementById(name+current).style="border: solid 1px #B75190; background-color: #FFFFFF;";
						if (current != 13){
							document.getElementById(name+next).focus();
							document.getElementById(name+next).select();
						}
					} else{
						if (document.getElementById(name+current).value != ''){ 
					   		document.getElementById(name+current).style="border: solid 1px #FF0000; background-color: #FFFEDB;";
					   	}
						document.getElementById(name+current).focus();
					}
				}
			}
		}
	}
	
	//renvoie le curseur � la premi�re case vide du nir
	function moveCursorToFirstEmptyCase(current, contexte, elementname) {
		//si la saisie contient des * alors on efface le nir
		var effaceNir = true;
		for (i=8; i<14; i++) {
			if (document.getElementById(contexte + elementname +i).value != '*'){
				effaceNir = false;
			}
		}
		if(effaceNir == true){
			for (j=1; j<14; j++) {
				document.getElementById(contexte + elementname +j).value = '';
			}
		}
		
		
		if (document.getElementById(contexte + elementname + current).value == ''){
			for (i=1; i<current+1; i++) {
				if (document.getElementById(contexte + elementname +i).value == ''){
					document.getElementById(contexte + elementname +i).focus();
					break;
				}
			}
		} else {
			document.getElementById(contexte + elementname + current).select();
		}
	}
	
	//s�pare le nir suite au coller
	function splitNir(current, contexte, elementname){
		var contenu = document.getElementById(contexte + elementname + current).value;
		if(contenu.length > 1){
			for (i=0; (i<13 && i<contenu.length); i++) {
				var next = current + i;
				if(next<14){
					document.getElementById(contexte + elementname + next).value = contenu.charAt(i);
					document.getElementById(contexte + elementname + next).focus();
					//setTimeout(function() {document.getElementById(contexte + elementname + next).focus();}, 10);
				}				
			}
		}
	}
	
	//valorise la longueur maximal
	function setMaxLength(elementid, max){
		for(i=0; i<document.forms[0].elements.length; i++){
			if (document.forms[0].elements[i].id.indexOf(elementid)!=-1){
				document.forms[0].elements[i].maxLength = max;
			}
		}
	}
	
	//compte les charact�res d'un textarea et tronque les caract�res en trop
	function countChar(idTextArea, idCountInput, max) {
	  var n = document.getElementById(idTextArea).value;
	  //gestion des retour � la ligne fin de ligne
	  var regrn = new RegExp('\r\n|\n\r', 'g');
	  var regn = new RegExp('\n|\r', 'g');
	  var regbr = new RegExp('<br>', 'g');
	  n = n.replace(regrn, "<br>");
	  n = n.replace(regn, "<br>");
	  n = n.replace(regbr, "\r\n");
	  if (mb_strlen(n) > max) { 
	    document.getElementById(idTextArea).value = n.substring(0,max);
	    document.getElementById(idTextArea).scrollTop=document.getElementById(idTextArea).scrollHeight;
	    return false;
	  } else {
	    var o = document.getElementById(idCountInput);
	    o.innerHTML = mb_strlen(n);
	  }
	}
	
	//renvoi la taille en byte d'une chaine
	function mb_strlen(str) {
	    var len = 0;
	    for(var i = 0; i < str.length; i++) {
	        len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? 2 : 1;
	    }
	    return len;
	}
	
	//desactive les boutons d'un formulaire pendant 10s
	function desactiveBoutonsTmp(idForm){
		var fPrev = function(evenement){evenement.preventDefault();};
		$(idForm).getElements('.r_btsubmit, .r_btretour').each(function(elt){
			if(elt.get('tag')==='a'){
				elt.addEvent('click',fPrev);
				elt.addEvent('keypress',fPrev);
				elt.addClass('r_disabled');
			} else {
				elt.setProperty('disabled', 'true');
			}
		});
		setTimeout(function(){	
				$(idForm).getElements('.r_btsubmit, .r_btretour').each(function(elt){
					if(elt.get('tag')==='a'){
						elt.removeEvent('click',fPrev);
						elt.removeEvent('keypress',fPrev);
						elt.removeClass('r_disabled');
					} else {
						elt.removeProperty('disabled');
					}
				});
			},10000);
	}
	
	
	// valorise le champ date avec la valeur du nir
	// valorise mindate et maxdate pour ouvrir le cal au bon endroit
	function initCalendarWithNir(nirInput, dnaInput, defaultMinDate, defaultMaxDate) {
		
		var nir = nirInput.value;
		var dna = dnaInput.value;
		
		// Si la date de naissance est deja remplie
		if (dna.length == 10) {
			return;
		}
		
		// Si le champ est enti�rement rempli (ie : nir.length == 13)
		if (nir.length == 13) {
		
			var year = nir.substring(1, 3);
			var month = nir.substring(3, 5);
			
			var pivotalYear = String(new Date().getFullYear()).substring(2,4);
			var fullYear;
			if (year < pivotalYear) {
				fullYear = '20' + year;
			} else {
				fullYear = '19' + year;
			}
			var mindate = formatterJJMMAAAA(fullYear, month-1, 1);
			var maxdate = formatterJJMMAAAA(fullYear, month, 0);
			dnaInput.set('data-mindate', mindate);
			dnaInput.set('data-maxdate', maxdate);
			dnaInput.set('value', mindate.substring(2, 10));
		} 
		else {
			dnaInput.set('data-mindate', defaultMinDate);
			dnaInput.set('data-maxdate', defaultMaxDate);
		}
	};
	
	// Formatte en String (jj/mm/aaaa)
	// @args - year, l'annee
	// @args - month : le mois
	// @args - day : le jour
	function formatterJJMMAAAA(pYear, pMonth, pDay) {
		// Controle des param�tres d'entr�e
		if (isNaN(pYear) || isNaN(pMonth) || isNaN(pDay))
			return '';
		
		var day, month, year;
		
		if (pMonth > 12) {
		
			if (pDay == 0) {
				month = pMonth;
				
			}
			else month = pMonth + 1;
			day = '' + pDay;
			year = '' + pYear;
		
		} else {
		
			// Permet de construire les dates min et max
			// day = 0 => fin du mois precedent
			// day = 1 => premier jour du mois
			var date = new Date(pYear, pMonth, pDay);
			
			// Correction du mois JS [0 - 11] alors que en 'francais' [1 - 12]
			month = '' + (date.getMonth() + 1);
	        day = '' + date.getDate();
	        year = date.getFullYear();
        }

	    if (month.length < 2) month = '0' + month;
	    if (day.length < 2) day = '0' + day;
	
	    return [day, month, year].join('/');
	};