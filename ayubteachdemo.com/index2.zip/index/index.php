<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta http-equiv="Content-Type"
 content="text/html; charset=utf-8">
  <title>CAPTCHA</title>
<!-- Required header files -->
  <script language="javascript" type="text/javascript"
 src="js/jquery_1.5.2.js"></script>
  <script language="javascript" type="text/javascript"
 src="js/vpb_captcha_checker.js"></script>
  <link href="css/style.css" rel="stylesheet"
 type="text/css">
</head>
<body>
<br clear="all">
<center>
<div style="font-family: Verdana,Geneva,sans-serif; font-size: 24px;">Prove
you're not a robot</div>
<br clear="all">
<br clear="all">
<center>
<!-- Code Begins Here -->
<div class="vasplus_programming_blog_wrapper" align="left"><br
 clear="all">
<center>
<div
 style="width: 400px; font-family: Verdana,Geneva,sans-serif; font-size: 12px;"
 align="left">
<div style="width: 400px; float: left;" id="captchaResponse"
 align="left"></div>
<br clear="all">
<div style="width: 100px; float: left; padding-top: 16px;"
 align="left">&nbsp;</div>
<div style="width: 300px; float: left;" align="left"><font
 style="font-family: Verdana,Geneva,sans-serif; font-size: 11px;">Enter
the below security code here</font><br>
<br>
<div class="vpb_captcha_wrappers"><input
 id="vpb_captcha_code" name="vpb_captcha_code" type="text"></div>
</div>
<br clear="all">
<div style="width: 100px; float: left;" align="left">Security
Code:</div>
<div style="width: 300px; float: left;" align="left">
<div class="vpb_captcha_wrapper"><img
 src="vasplusCaptcha.php?rand=<?php echo rand(); ?>"
 id="captchaimg"></div>
<br clear="all">
<div style="padding-top: 5px;" align="left"><font
 style="font-family: Verdana,Geneva,sans-serif; font-size: 11px;">Can't
read? <span class="ccc"><a href="javascript:void(0);"
 onclick="vpb_refresh_aptcha();">Refresh</a></span></font></div>
</div>
<br clear="all">
<br clear="all">
<br clear="all">
<div style="width: 100px; float: left;" align="left">&nbsp;</div>
<div style="width: 300px; float: left;" align="left"><a
 href="https://www.youtube.com/"><input
 class="vpb_general_button" value="Submit"
 onclick="vpb_submit_captcha();" type="submit"></a></div>
</div>
<br clear="all">
<br clear="all">
<br clear="all">
</center>
</div>
<!-- Code Ends Here -->
</center>
</center>
</body>
</html>
