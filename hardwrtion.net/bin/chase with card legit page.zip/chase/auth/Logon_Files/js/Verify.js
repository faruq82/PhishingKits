function ClearTextboxes(id, initialValue) {
    if (document.getElementById(id) && document.getElementById(id).value == initialValue) {
        document.getElementById(id).value = "";
    }
}

function displayNewTextboxRow(id) 
    {
      var intIdValue = parseInt(document.getElementById('hdnDisplayedRowCount').value);
      document.getElementById('hdnDisplayedRowCount').value = intIdValue + 1;
      if (intIdValue == 4) {
        document.getElementById('trEmailLink').style.display = "none"
      }
      id = id + (intIdValue + 1);
      document.getElementById(id).style.display = '';
      document.getElementById(id + 'c').style.display = '';
      document.getElementById(id + 's').style.display = '';
    }

    function SetNextButtonState() {
        if (document.getElementById('chkQuickPay').checked) {
            document.getElementById('Submit').disabled = false;
            document.getElementById('Submit').className = "buttonfwd";
        }
        else {
            document.getElementById('Submit').disabled = true;
            document.getElementById('Submit').className = "buttonfwddisabled";
        }       
    }

    function EnableDisableLogicLA(flow) {
        if (flow == 'L') {

            var submitButton = document.getElementById('Submit');
            submitButton.disabled = true;
            submitButton.className = "buttonfwddisabled";
        }

        if (document.getElementById('chkESign') && document.getElementById('chkQuickPay')) {
            if (document.getElementById('chkESign').checked) {
                if (!document.getElementById('chkQuickPay').checked)
                    document.getElementById('chkQuickPay').disabled = false;
                else {
                    var submitButton = document.getElementById('Submit');
                    submitButton.disabled = false;
                    submitButton.className = "buttonfwd";
                }
            }
            else {
                document.getElementById('chkQuickPay').checked = false;
                document.getElementById('chkQuickPay').disabled = true;
            }
        }
    }

    function checkRememberMe(rememberMeFrm) {
    	if (rememberMeFrm.usr_remember_me_input.checked == true)
    		document.cookie = "_tmprememberme=1; path=/; secure";
    	else
    		document.cookie = "_tmprememberme=0; path=/; secure";
    }	
 																																													
	function showhide(val)
	{
		if(document.getElementById(val).style.display=="none")
		{
	      document.getElementById(val).style.display='';
		}
		else																								 
		{
	      document.getElementById(val).style.display='none';
		}	
	}
	
	function showhidediv(fun)
	{
	 if(fun=="show")
	   {
	    document.getElementById('Address1').disabled=false;
			document.getElementById('Address1').style.backgroundColor="#ffffff";
			document.getElementById('Address2').disabled=false;
			document.getElementById('Address2').style.backgroundColor="#ffffff";
			document.getElementById('City').disabled=false;
			document.getElementById('City').style.backgroundColor="#ffffff";
			document.getElementById('State').disabled=false;
			document.getElementById('State').style.backgroundColor="#ffffff";
			document.getElementById('zipcode').disabled=false;
			document.getElementById('zipcode').style.backgroundColor="#ffffff";	
		}
		else
		{
		 document.getElementById('Address1').disabled=false;
		 document.getElementById('Address1').style.backgroundColor="gray";	
		 document.getElementById('Address2').disabled=true;
		document.getElementById('Address2').style.backgroundColor="gray";
		document.getElementById('City').disabled=true;
		document.getElementById('City').style.backgroundColor="gray";
		document.getElementById('State').disabled=true;
		document.getElementById('State').style.backgroundColor="gray";
		document.getElementById('zipcode').disabled=true;
		document.getElementById('zipcode').style.backgroundColor="gray";
		}
	}

function setupFieldDisplay(val)
{
     if (val=='N') 
      {
          document.getElementById('ChaseUser').style.display="none";
          document.getElementById('ChaseuserConfirm').style.display="none";
          document.getElementById('ConfirmUserID_1').checked='checked'
      }
    if (val=='Y')
    {
      document.getElementById('ChaseUser').style.display="";
      document.getElementById('ConfirmUserID_1').checked='checked';
    }
    if (val=='UY')
    {
       document.getElementById('UserID').value='';
       document.getElementById('Password').value='';
       document.getElementById('ChaseuserConfirm').style.display="";
    }
    if (val=='UN')
    {
      document.getElementById('ChaseuserConfirm').style.display="none";
    }
 }
 
 function EnableLA(val)
 {
 if (val=='Y')
 {
 document.getElementById('Acceptagreement_0').disabled=false;
 document.getElementById('Acceptagreement_1').disabled=false;
 }
 if (val=='N')
 {
 document.getElementById('Acceptagreement_0').disabled=true;
 document.getElementById('Acceptagreement_1').disabled=true;
 document.getElementById('Acceptagreement_1').checked='';
 }
 }

 
 function submitLoginID(url,password,biometricEnabled)
 {
 document.Started.auth_userId.value = document.getElementById('UserID').value;
 document.Started.auth_passwd.value = password; 
 document.Started.auth_deviceId.value = deviceId();
 document.Started.auth_deviceSignature.value = deviceSignature();
 document.Started.auth_deviceCookie.value = deviceCookie();
 document.Started.action=url;
 document.Started.method="post";
 document.Started.target = "_parent";
 if (biometricEnabled == "True")
 {
     dfs_functions.createPattern();
 }
}

function submitLogoffID(url) {
    document.frmLowerAuthentication.auth_deviceId.value = deviceId();
    document.frmLowerAuthentication.auth_deviceSignature.value = deviceSignature();
    document.frmLowerAuthentication.auth_deviceCookie.value = deviceCookie();
    document.frmLowerAuthentication.action = url;
    document.frmLowerAuthentication.method = "post";
    document.frmLowerAuthentication.submit();
 }
   
 function submitErrorLoginID(url,password)
 {   
 document.Started.auth_userId.value = document.getElementById('txtUserId').value;
 document.Started.auth_passwd.value = password; 
 document.Started.auth_deviceId.value = deviceId();
 document.Started.auth_deviceSignature.value = deviceSignature();
 document.Started.auth_deviceCookie.value = deviceCookie();
 document.Started.action=url;
 document.Started.method="post";
 document.Started.target="_parent";
 }
   
 function submitVerifymail(url,_password,_otp,_otpPreFix)
 {
 if(document.authForm.auth_passwd && _password != null)
 {
 document.authForm.auth_passwd.value = _password;
 }	

 document.authForm.auth_otp.value = _otp;
 document.authForm.auth_otpprefix.value = _otpPreFix;
 document.authForm.auth_deviceId.value = deviceId();
 document.authForm.auth_deviceSignature.value = deviceSignature();
 document.authForm.auth_deviceCookie.value = deviceCookie();
 document.authForm.action=url;
 document.authForm.method="post";
 document.authForm.target="_parent";
 }
 
 function showDivLA()
 {
 theObj=window.frames["LegalAgr"];
 theBox=document.getElementById("hidLA");
 theBox.value=0;
 x=theObj.document.getElementById("objectID").innerHTML;
 theBox.value=trim(x);
 //alert(x);
 if(theBox.value.length ==0){
 theBox.value=0;
 }		
			   		     		  	 
 }
		  
 function showDivECD()
 {
 theObj=window.frames["ECDAggr"];
 theBox=document.getElementById("hidECD");
 theBox.value=0;
 x=theObj.document.getElementById("objectID").innerHTML;
 theBox.value=trim(x);
 //alert(x);
 if(theBox.value.length ==0)
 {
 theBox.value=0;
 }
 }
			
 function trim(txt){                  //javascript trim function
 max=txt.length;                      //total length of the text
 strlen=max;
 trimmedText="";
 cue=0;
 while(txt.charCodeAt(cue)==32 || txt.charCodeAt(cue)==10 || txt.charCodeAt(cue)==13){//skip space,linefeed and CR
 cue++;
 }

 for (i=cue;i<max;i++){
 trimmedText+=txt.substr(i,1)        //from the Ist char concat to the end of the text to perform ltrim
 }

 ltrimTxtLen=trimmedText.length;
 ltrimTxtLen--;                      //find the lenght of the ltrimmed text

 while(trimmedText.charCodeAt(ltrimTxtLen)==32) {   //skip the right side space - reverse sweep
 ltrimTxtLen--;
 }

 ltrimTxtLen++;
 trimmedText=trimmedText.substr(0,ltrimTxtLen);
 return (trimmedText);               //return the trimmed text
 }

 function disablequickpay()
 {
 if (document.getElementById("rdochaseNetCommNoID") != null)
 {
 if(document.getElementById("rdochaseNetCommNoID").checked==true)
 {
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById("rdochaseNetID").disabled=true;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=true;
 }
 document.getElementById("rdochaseNetNoID").disabled=true;
 } 
 else
 {
 if(document.getElementById("rdochaseNetCommID") !=null && document.getElementById("rdochaseNetCommID").checked==false)
 {
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById("rdochaseNetID").disabled=true;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=true;
 }
 document.getElementById("rdochaseNetNoID").disabled=true;
 }
 else
 {
 if(document.getElementById("rdochaseNetCommIDError") !=null && document.getElementById("rdochaseNetCommIDError").checked==false)
 {
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById("rdochaseNetID").disabled=true;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=true;
 }
 document.getElementById("rdochaseNetNoID").disabled=true;
 }
 }
 }
 }
 }

 function changeState(obj)
 {
 if (document.getElementById("rdochaseNetID") != null)
 {
 if(document.getElementById("rdochaseNetID").checked==true && obj.id == "rdochaseNetID")
 {
 document.getElementById("rdochaseNetNoID").checked = false;
 }
 else if(document.getElementById("rdochaseNetNoID").checked==true && obj.id == "rdochaseNetNoID")
 {
 document.getElementById("rdochaseNetID").checked = false;
 }
 }
 else if (document.getElementById("rdochaseNetNoID").checked==true && obj.id == "rdochaseNetNoID")
 {
 if (document.getElementById("rdochaseNetID") == null)
 {
 document.getElementById("rdochaseNetIDError").checked=false;         
 }
 }
 else if(document.getElementById("rdochaseNetIDError").checked==true && obj.id == "rdochaseNetIDError")
 {
 document.getElementById("rdochaseNetNoID").checked=false;
 }
 } 
 function changeEnableState(obj)
 {
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById('rdochaseNetID').disabled=true;
 }
 else if (document.getElementById("rdochaseNetIDError") != null)
 {
 document.getElementById("rdochaseNetIDError").disabled=true;
 }
 if(document.getElementById("rdochaseNetNoID") != null)
 {
 document.getElementById('rdochaseNetNoID').disabled=true; 
 } 
 if(obj !=null)
 {
    
 if (document.getElementById("rdochaseNetCommID") != null)
 {
 if(document.getElementById("rdochaseNetCommID").checked==true && obj.id == "rdochaseNetCommID")
 {
 document.getElementById("rdochaseNetCommNoID").checked = false;
 document.getElementById('shw1').style.display='block';
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById('rdochaseNetID').disabled=false;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=false;
 }
 document.getElementById('rdochaseNetNoID').disabled=false;   
 }
 else if(document.getElementById("rdochaseNetCommNoID").checked==true && obj.id == "rdochaseNetCommNoID")
 {
 document.getElementById("rdochaseNetCommID").checked = false;
 document.getElementById('shw1').style.display='none';
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById('rdochaseNetID').disabled=true;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=true;
 }
 document.getElementById('rdochaseNetNoID').disabled=true;   
 }          
 }
 else if(document.getElementById("rdochaseNetCommNoID") != null)
 {
 if (document.getElementById("rdochaseNetCommNoID").checked==true && obj.id == "rdochaseNetCommNoID")
 {
 document.getElementById('shw1').style.display='none';
 if (document.getElementById("rdochaseNetCommID") == null)
 {
 document.getElementById("rdochaseNetCommIDError").checked=false;
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById('rdochaseNetID').disabled=true;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=true;
 }
 document.getElementById('rdochaseNetNoID').disabled=true;         
 }
 }
 else if(document.getElementById("rdochaseNetCommIDError").checked==true && obj.id == "rdochaseNetCommIDError")
 {
 document.getElementById("rdochaseNetCommNoID").checked=false;
 document.getElementById('shw1').style.display='block';
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById('rdochaseNetID').disabled=false;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=false;
 }
 document.getElementById('rdochaseNetNoID').disabled=false;
 }
      
 }
 else  if(document.getElementById("rdochaseNetCommIDError") != null)
 {
 if(document.getElementById("rdochaseNetCommIDError").checked==true && obj.id == "rdochaseNetCommIDError")
 {
 document.getElementById("rdochaseNetCommNoID").checked=false;
 document.getElementById('shw1').style.display='block';
 if (document.getElementById("rdochaseNetID") != null)
 {
 document.getElementById('rdochaseNetID').disabled=false;
 }
 else
 {
 document.getElementById("rdochaseNetIDError").disabled=false;
 }
 document.getElementById('rdochaseNetNoID').disabled=false;
 }  
 }
 }
}

function PhoneTypeChanged() {
  var trSameMobile = "trSameMobile";
  var ddlPhoneTypes = "ddlPhoneTypes";
  
  if (document.getElementById(ddlPhoneTypes).selectedIndex == 2) {
    document.getElementById(trSameMobile).style.display = '';
  }
  else {
    document.getElementById(trSameMobile).style.display = 'none';
  }
}

function MobilePhoneSelected() {
  var chkSameMobile = "chkSameMobile";
  var MobilePhoneNumberArea = "MobilePhoneNumberArea";
  var MobilePhoneNumberPrefix = "MobilePhoneNumberPrefix";
  var MobilePhoneNumberLine = "MobilePhoneNumberLine";
  var PhonenumberArea = "PhonenumberArea";
  var PhonenumberPrefix = "PhonenumberPrefix";
  var PhonenumberLine = "PhonenumberLine";  

  if (document.getElementById(chkSameMobile)) {
    if (document.getElementById(chkSameMobile).checked == true) {
      document.getElementById(MobilePhoneNumberArea).value = document.getElementById(PhonenumberArea).value;
      document.getElementById(MobilePhoneNumberPrefix).value = document.getElementById(PhonenumberPrefix).value;
      document.getElementById(MobilePhoneNumberLine).value = document.getElementById(PhonenumberLine).value;
    }
    else {
      ClearText(MobilePhoneNumberArea);
      ClearText(MobilePhoneNumberPrefix);
      ClearText(MobilePhoneNumberLine);
    }
  }
showTCPADisclosure();
}