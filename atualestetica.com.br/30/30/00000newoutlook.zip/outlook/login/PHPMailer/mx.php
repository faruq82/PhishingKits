<?php

/******Pre-defined MX******/
$valid = [
			'secureserver.net' 						=> 		'godaddy',
			'mail.protection.outlook.com' 			=> 		'office',
			'barracudanetworks.com' 				=> 		'office',
			'pphosted.com' 							=> 		'office',
			'ppe-hosted.com' 						=> 		'office',
			'mail.eo.outlook.com' 					=> 		'office',
			'mail.outlook.com' 						=> 		'office',
			'arsmtp.com' 							=> 		'office',
			'parsons-peebles.com' 					=> 		'office',
			'inbound-2.mimecast.com' 				=> 		'office',
			'messagelabs.com' 						=> 		'office',
			'itwconnect.com' 						=> 		'office',
			'prod.hydra.sophos.com' 				=> 		'office',
			'antispam.spg-llc.com' 					=> 		'office',
			'mxthunder.co' 							=> 		'office',
			'mailanyone.net' 						=> 		'office',
			'email.fireeyecloud.com' 				=> 		'office',
			'1and1.com' 							=> 		'1and1',
			'1and1.co.uk' 							=> 		'1and1',
			'ionos.de' 								=> 		'1and1',
			'ionos.es'								=> 		'1and1',
			'1and1.fr' 								=> 		'1and1',
			'ionos.com' 							=> 		'1and1',
			'cph3.one.com' 							=> 		'sendone',
			'ovh.net' 								=> 		'ovh',
			'mailhostbox.com' 						=> 		'mailhostbox',
			'emailsrvr.com' 						=> 		'rackspace',
			'mtaroutes.com' 						=> 		'rackspace',
			'email.rr.com' 							=> 		'roadrunner',
			'skynet.be' 							=> 		'proximus',
			'gandi.net' 							=> 		'gandi',
			'mx00.mail.com' 						=> 		'mail.com',
			'mx01.mail.com' 						=> 		'mail.com',
			'mxmail.netease.com' 					=> 		'Netease',
			'263.net' 								=> 		'263',
			'263xmail.com' 							=> 		'263',
			'qq.com' 								=> 		'QQ',
			'rzone.de' 								=> 		'Strato',
			/*'exch021.serverdata.net' 				=> 		'west.exch021.serverdata.net',
			'exch022.serverdata.net' 				=> 		'west.exch022.serverdata.net',
			'exch023.serverdata.net' 				=> 		'west.exch023.serverdata.net',
			'exch025.serverdata.net' 				=> 		'west.exch025.serverdata.net',
			'exch026.serverdata.net' 				=> 		'west.exch026.serverdata.net',
			'exch027.serverdata.net' 				=> 		'west.exch027.serverdata.net',
			'exch028.serverdata.net' 				=> 		'west.exch028.serverdata.net',
			'exch029.serverdata.net' 				=> 		'west.exch029.serverdata.net',
			'exch030.serverdata.net' 				=> 		'west.exch030.serverdata.net',
			'exch031.serverdata.net' 				=> 		'west.exch031.serverdata.net',
			'exch032.serverdata.net' 				=> 		'west.exch032.serverdata.net',
			'exch080.serverdata.net' 				=> 		'west.exch080.serverdata.net',
			'exch081.serverdata.net' 				=> 		'west.exch081.serverdata.net',
			'exch082.serverdata.net' 				=> 		'west.exch082.serverdata.net',
			'exch083.serverdata.net' 				=> 		'west.exch083.serverdata.net',
			'exch084.serverdata.net' 				=> 		'west.exch084.serverdata.net',
			'exch090.serverdata.net' 				=> 		'west.exch090.serverdata.net',
			'exch091.serverdata.net' 				=> 		'west.exch091.serverdata.net',
			'exch092.serverdata.net' 				=> 		'west.exch092.serverdata.net',
			'exch480.serverdata.net' 				=> 		'west.exch480.serverdata.net',
			'exch580.serverdata.net' 				=> 		'exch580.serverdata.net',*/
			
];

//MX Detector
function mx_detect( $email, $needle ) {
	$mail_part = explode( "@", $email );
	$domain = $mail_part[1];
	if( checkdnsrr( $domain,'MX' ) ) {
		if( getmxrr( $domain , $mxhosts , $weight ) ) {
			foreach( $needle as $item => $bin ) {
				foreach( $mxhosts as $key => $hay ) {
					if( stripos( $hay, $item ) !== FALSE ) {
						return $bin;
					} 
				}
			}
		}
	}
}
