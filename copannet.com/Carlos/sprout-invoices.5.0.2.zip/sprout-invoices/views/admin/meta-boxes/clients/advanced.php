<div id="client_fields" class="admin_fields clearfix">
	<?php sa_admin_fields( $fields ); ?>
</div>