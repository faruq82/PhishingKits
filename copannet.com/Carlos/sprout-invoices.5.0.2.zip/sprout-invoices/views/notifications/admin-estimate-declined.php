---------------------------------------------
Estimate Declined
---------------------------------------------

[estimate_subject]

Estimate ID: [estimate_id]
[estimate_edit_url]
Client: [client_name]
[client_edit_url]
Amount: [estimate_total]

Bummer!

---------------------------------------------
