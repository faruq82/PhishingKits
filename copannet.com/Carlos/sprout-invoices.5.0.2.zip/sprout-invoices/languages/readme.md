#  Sprout Invoices i18n #

  To help translate, review, or improve a translation,join our WP-Translations Community at
  https://www.transifex.com/projects/p/sprout-invoices/

  More info at http://wp-translations.org/

