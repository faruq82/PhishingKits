# jQuery Bootstrap-style Dropdowns #

Copyright [A Beautiful Site, LLC.](http://abeautifulsite.net/)

Licensed under the MIT license: http://opensource.org/licenses/MIT

## Demo & Documentation ##

http://labs.abeautifulsite.net/jquery-dropdown/