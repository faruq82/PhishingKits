<?php
if (!@ini_get("zlib.output_compression")) @ob_start("ob_gzhandler");

define('ACPUBLIC', true);
define('ACP_USER_NOAUTH', true);

// require main include file
require_once(dirname(__FILE__) . '/admin/prepend.inc.php');
require_once(ac_global_functions('smarty.php'));

// Preload the language file
ac_lang_get('public');

$smarty = new AC_Smarty('public');

$action = ac_http_param('action');
$smarty->assign("action", $action);

$smarty->assign("_", $site["p_link"]);

$smarty->assign('site', $site);
$smarty->assign('plink', ac_site_plink());

$smarty->assign('jsSite', ac_array_keys_remove($site, array('serial', 'av', 'avo', 'ac', 'acu', 'acec', 'acar', 'acad', 'acff', 'smpass')));
$smarty->assign('jsAdmin', ac_array_keys_remove($admin, array('password')));

$smarty->display("mainjs.inc.js");

?>
