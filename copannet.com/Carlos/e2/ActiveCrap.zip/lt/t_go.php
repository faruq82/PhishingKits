<?PHP

require_once(dirname(dirname(__FILE__)) . '/lt.php');

?>
