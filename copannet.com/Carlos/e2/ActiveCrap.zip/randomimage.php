<?php
require_once(dirname(__FILE__) . '/ac_global/scripts/randomimage.php');
?>