So this ActiveCrap faggot called me "scumbag" just because someone need my help to install this crap on his server. Now this is time for revenge, yes revenge is sweet right? Everybody knows.
Talk to your hand bitch we know about software piracy because that is why we are exists, you don't even need to tell us about morality and ethics shit you son-of-a-bitch go tell your mother about moral so she can get you more level to study PHP and not getting money by sucking cock.

This t3h small p0wer of reveng3r.

- Unknown Indonesian -


  Install Instructions		/docs/Install.htm

  Upgrade Instructions		/docs/Upgrade.htm

  Customizations		/docs/customize.txt
