<?php

class AC_Iterator {
	var $rs;

	function AC_Iterator(&$rs, &$link) {
		$this->rs =& $rs;
	}

	function assoc() {
		return ac_sql_fetch_assoc($this->rs);
	}

	function row() {
		return ac_sql_fetch_row($this->rs);
	}
}

?>
