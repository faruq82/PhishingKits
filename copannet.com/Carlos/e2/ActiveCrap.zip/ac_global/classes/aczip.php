<?php

require_once(ac_global('pclzip/pclzip.lib.php'));

class ACZIPBuilder extends PclZip {

	function ACZIPBuilder($name) {
		return parent::PclZip($name);
	}

}

?>