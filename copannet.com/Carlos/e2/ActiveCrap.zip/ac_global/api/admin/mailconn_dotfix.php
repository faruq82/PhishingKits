<?php
// init.php

@set_magic_quotes_runtime(0);
ini_set('magic_quotes_runtime', 0);
error_reporting(E_ALL);

require_once(dirname(dirname(dirname(dirname(__FILE__))))) . '/admin/prepend.inc.php';
require_once(dirname(dirname(dirname(__FILE__)))) . '/functions/basic.php';
require_once(dirname(dirname(dirname(__FILE__)))) . '/functions/ajax.php';
require_once(dirname(dirname(dirname(__FILE__)))) . '/functions/mail.php';
require_once(dirname(dirname(dirname(__FILE__)))) . '/functions/mailer.php';


if ( !isset($site) ) $site = ac_site_get();
if ( !isset($admin) ) $admin = ac_admin_get();


// Preload the language file
ac_lang_get('admin');



ac_ajax_declare('mailconn_dotfix', 'ac_api_mailconn_dotfix');
ac_ajax_run();


?>
