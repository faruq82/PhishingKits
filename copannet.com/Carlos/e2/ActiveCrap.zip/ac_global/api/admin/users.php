<?php

require_once ac_global_functions('sql.php');
require_once ac_global_functions('auth.php');

function users_select($type, $parentid, $id = 0) {
    $id = intval($id);

    if (!ac_auth_isconnected())
        ac_auth_connect();

    if ($parentid > 0) {
        $mine = ac_sql_select_list($q = "
            SELECT
                `absid`
            FROM
                `#admin`
            WHERE
                `parentid` = '$parentid'
            OR  `id`       = '$parentid'
		");
    } elseif ($parentid == 0) {
        $mine = array();
    } else {
        $mine = ac_sql_select_list("
            SELECT
                `absid`
            FROM
                `#admin`
        ");
    }

    $ary = array();

    switch ($type) {
        case 'one':
            $rs = mysql_query("
                SELECT
                    *
                FROM
                    `acp_globalauth`
                WHERE
                    `id` = '$id'
                AND `id` IN ('".implode("','", $mine)."')
			", $GLOBALS['auth_db_link']);

            if ($row = mysql_fetch_assoc($rs)) {
                return $row;
            }
            break;

        case 'list':
            $rs = mysql_query("
                SELECT
                    auth.*
                FROM
                    `acp_globalauth` auth
                WHERE
                    `id` IN ('".implode("','", $mine)."')
                ", $GLOBALS['auth_db_link']);

            while ($row = mysql_fetch_assoc($rs)) {
                $row['parentid'] = intval(ac_sql_select_one("SELECT parentid FROM #admin WHERE absid = '$row[id]'"));
                $ary[] = $row;
            }

            return $ary;

        case 'list_global':
            $all = ac_sql_select_list("SELECT `absid` FROM `#admin`");
            $rs  = mysql_query("
                SELECT
                    *
                FROM
                    `acp_globalauth`
                WHERE
                    `id` NOT IN ('".implode("','", $all)."')
                ", $GLOBALS['auth_db_link']);

            while ($row = mysql_fetch_assoc($rs))
                $ary[] = $row;

            return $ary;

        default:
            break;
    }

    return array();
}

function users_select_count($parentid) {
    $parentid = intval($parentid);
    if ($parentid > 0) {
        return ac_sql_select_one("
            SELECT
                COUNT(*)
            FROM
                `#admin`
            WHERE
                `parentid` = '$parentid'
            OR  `id`       = '$parentid'
        ");
    } else {
        return 0;
    }
}

function users_import($absid, $parentid = 0) {
    $user = ac_auth_record_id($absid);

    require_once ac_global_smarty_plugins('modifier.ac_clear_prefix.php');

    $ary = array(
        "user"  => smarty_modifier_ac_clear_prefix($user['username'], 'num'),
        "absid" => $absid,
        "parentid" => $parentid,
    );

    if ($parentid == 0)
        $ary["parentid"] = ac_admin_parent_of($GLOBALS["admin"]);
    elseif ($parentid == -1)
        unset($ary["parentid"]);

    ac_sql_insert("#admin", $ary);

    $ret = array(
        'id' => ac_sql_insert_id()
    );

    ac_ihook('ac_users_context_import', $ret['id'], $user);
    return $ret;
}

function users_update($absid, $parentid = 0) {
    $absid  = intval($absid);
    $user   = ac_auth_record_id($absid);

    require_once ac_global_smarty_plugins('modifier.ac_clear_prefix.php');

    $ary = array(
        "user"      => smarty_modifier_ac_clear_prefix($user['username'], 'num'),
        "parentid"  => $parentid,
    );

    if ($parentid == 0)
        $ary["parentid"] = $GLOBALS["admin"]["id"];
    elseif ($parentid == -1)
        unset($ary["parentid"]);

    ac_sql_update("#admin", $ary, "`absid` = '$absid' AND `parentid` != '0'");
    $adminid = ac_sql_select_one("id", "#admin", "`absid` = '$absid'");
    ac_ihook('ac_users_context_update', $adminid);
}

function users_delete($absid) {
    $absid = intval($absid);
    $id    = ac_sql_select_one("id", "#admin", "`absid` = '$absid'");
    ac_sql_delete("#admin", "`id` = '$id'");
    ac_ihook('ac_users_context_delete', $id, $absid);

    if (ishosted())
        ac_sql_delete("acp_globalauth", "`id` = '$absid'");

    return $id;
}

?>
