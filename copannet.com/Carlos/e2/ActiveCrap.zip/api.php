<?php
// public side switch
define('ACPUBLIC', true);
define('ACP_USER_NOAUTH', true);

// require main include file
require_once(dirname(__FILE__) . '/admin/prepend.inc.php');

/*
	WHITELIST
*/
$allowed = array(
	// campaign actions
	"campaign.campaign_select_array_paginator" => "",
	"campaign.campaign_filter_post" => "",
	// subscription forms
	"form.form_list_change" => "",
	// list-related actions
	"list.list_field_update" => "",
	"list.list_filter_post" => "",
	"list.list_select_array_paginator" => "",
	// subscriber actions
	"subscriber.subscriber_subscribe" => "",
	"subscriber.subscriber_unsubscribe" => "",
	"subscriber.subscriber_update" => "",
	"subscriber.subscriber_update_request" => "",
	// approval
	'approval.approval_approve' => '',
	'approval.approval_decline' => '',
	'approval.approval_decline_only' => '',
	// abuse
	'abuse.abuse_list' => '',
	'abuse.abuse_reset' => '',
	'abuse.abuse_notify' => '',
	'abuse.abuse_update' => '',
);

// require ajax functions
require_once(ac_global_functions('ajax.php'));

// Preload the language file
ac_lang_get('public');

// do branding changes by list filter
require(ac_admin('functions/inc.branding.public.php'));

// require ajax include
require_once ac_global_includes("api.php");

?>
