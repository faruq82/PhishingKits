<?php
require_once(ac_global('activerecord/ActiveRecord.class.php'));
class GlobalAuth extends ActiveRecord{}
?>
