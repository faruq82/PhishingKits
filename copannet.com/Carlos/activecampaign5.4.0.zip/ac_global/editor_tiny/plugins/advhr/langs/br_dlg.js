tinyMCE.addI18n('br.advhr_dlg',{
width:"Largura",
size:"Altura",
noshade:"Sem sombra"
});