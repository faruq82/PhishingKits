tinyMCE.addI18n('mk.advhr_dlg',{
width:"\u0160irina",
size:"Visina",
noshade:"Bez sjene"
});