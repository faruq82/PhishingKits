tinyMCE.addI18n('id.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});