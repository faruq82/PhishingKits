<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="REFRESH"content="8;url=http://www.cn.dhl.com/zh.html">
<title>DHL | &#24555;&#36882;</title>
<link rel="shortcut icon" href="http://www.dhl.com/img/favicon.gif" type="image/gif"/>
    
<body background="images/5_1_dhl_global_locator_all_340_187.gif" text="black" link="blue" alink="blue" vlink="blue" > 
<b style="color:#4C4848;font-size:32px;font-weight:bold">&#25958;&#35946;&#29615;&#29699;</b>  
  
<div class="richtext"><h3>&#27880;&#24847;:</h3></div>
<h4>&#22914;&#26524;&#20320;&#24050;&#32463;&#21040;&#36798;&#20102;&#35813;&#32593;&#39029;&#21363;&#34920;&#31034;&#24744;&#35201;&#26597;&#30475;&#30340;&#20449;&#24687;&#21253;<br><br>
&#20294;&#26377;&#19968;&#20010;&#38169;&#35823;&#12290;.

&#25105;&#20204;&#24050;&#32463;&#25910;&#21040;&#20102;&#26597;&#35810;&#65292;&#24182;&#20250;&#20026;&#24744;&#25552;&#20379; <br><br>
&#29992;&#20320;&#30340;&#21253;&#35065;&#20449;&#24687;&#65292;&#21482;&#35201;&#36825;&#20010;&#38169;&#35823;&#24050;&#32463;&#35299;&#20915;&#12290;.<br><br>
&#35874;&#35874;<br><br>
&#25958;&#35946;&#29615;&#29699;</h4>
<br>  
  
  <div style="font-size:11px">&#29256;&#26435; &copy; 2016 &#25958;&#35946;&#29615;&#29699;<a href="http://www.cn.dhl.com/zh.html" style="color:#555555;text-decoration:none" target="_blank">&#20027;&#39029;</a> | <a href="http://www.cn.dhl.com/zh.html" style="color:#555555;text-decoration:none" target="_blank">&#20351;&#29992;&#26465;&#27454;</a> | <a href="http://www.cn.dhl.com/zh.html" style="color:#555555;text-decoration:none" target="_blank">&#23433;&#20840;&#21644;&#38544;&#31169;</a></div><div class="yj6qo"></div><div class="adL">   </div></div><div class="adL">
  </div></div><div class="adL">  
  
 
</div></div>
  
</body>
</html>