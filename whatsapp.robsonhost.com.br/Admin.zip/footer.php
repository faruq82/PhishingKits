
        <footer class="footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.loopinfosol.com">WA Sticker</a>, made by LoopInfosol.Inc
                </p>
            </div>
        </footer>

    </div>
</div>

<?php

	/* Include Modal Popup File */
	require_once('model.php');

?>

</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.min.js"></script>
	
	<script src="assets/js/bootstrap.min.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/bootstrap-dashboard.js"></script>
	
	<script src="assets/js/custom.js"></script>

</html>
