<?php

	header('Location: http://loopinfosol.com/');
	
?>
