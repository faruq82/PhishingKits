<?php
error_reporting(0); 

$mail_to = "lbtown22@gmail.com";

?>