$.fn.gatewayMarquee = ( function() {

  function plugin(knownPossibilities, unknownPossibilities, qs, toggleElements) {

		if(typeof(discover) === 'undefined') {
			window.discover = {};
		}
		
		if (!Array.indexOf) {
	  		Array.prototype.indexOf = function(obj){
	   			for(var i=0; i<this.length; i++){
	    			if(this[i]==obj){
	     				return i;
	    			}
	   			}
	   			return -1;
	  		}
		}
    var placeholderIsSupported  = function () {
      test = document.createElement('input');
      return ('placeholder' in test);
    };
		discover.homepage = (function() {
	
			$('html').removeClass('no-js');
			
			var marqWrapper = $('#marquee-wrapper');
			
			marqWrapper.addClass('spinner');
	
			//store and update cookie data here
			var cookieData = {
					'site' : 'card'
			};
		
			var createCookie = function(name,string,days) {
				if (days) {
					var date = new Date();
					date.setTime(date.getTime()+(days*24*60*60*1000));
					var expires = "; expires="+date.toGMTString();
				}
				else var expires = "";
				document.cookie = name + "=" + string +expires+"; path=/";
			};

			var readCookie = function(name) {
				var nameEQ = name + "=";
				var ca = document.cookie.split(';');
				for(var i=0;i < ca.length;i++) {
					var c = ca[i];
					while (c.charAt(0)==' ') c = c.substring(1,c.length);
					if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
				}
				return null;
			};

			var eraseCookie = function(name) {
				createCookie(name,"",-1);
			};
	
			//global form variables
			var loginForm = $('#form-login');
			var remember = $('#login-remember');
			var accountId = $('#login-account');
			var loginButton = $('#login-button');
			var loginInput = $('#login-password');
			var passwordShim = $('#password-shim');
			var customDropDiv = $("#customDropdown");
			var hiddenInput = customDropDiv.find("input")[0];
			var optionDiv = customDropDiv.find("ul")[0];
			var header = customDropDiv.find("p")[0];
			var listItems = $(optionDiv).find("li");
			var tooltipError = $('#dropdown-error');
			var selector = customDropDiv.find("a")[0];
			var arrowTooltips = $('.arrow-tooltip');
			var userIdErrorFlag = false;
			var passwordErrorFlag = false;
			var selectAnAccountErrorFlag = false;
      var isPlaceHolder = placeholderIsSupported();

			var $listItemsAs = $($(listItems).find('a'));
	
      if (isPlaceHolder) {
        passwordShim.remove();
        loginInput.show();
      } else {
			passwordShim.focus(function(){
				$(optionDiv).addClass('hide');
			});
        passwordShim.blur(function(){
          loginInput.focus();
        });
      }
      
      var isMac = (function () {
        if ( navigator.platform && navigator.platform.toLowerCase() === 'macintel') { 
          loginInput.focus(function(){
            loginInput.bind('keydown',(function(event){
              if(event.shiftKey && event.keyCode == 9) { 
              }
              else if(event.keyCode == 9) {
                $(selector).focus();        
              }
            }));
          });       
        }
      })();
	
			accountId.bind('keydown', function(e){
				if(e.keyCode === 32) {
					e.preventDefault();
				}
			});
	
			var setTooltips = function() {
				$("#overlays").appendTo("#main-content"); //Needed to lock the focus within overlay.
				$(".overlay").attr("tabindex",0);
				$(".overlay-trigger").click(function(event){					
					event.preventDefault();
					var offset = $(event.target).offset();
					var whichOverlay = $(event.target).attr("href").split('#')[1];
					whichOverlay = $("#" + whichOverlay);
					whichOverlay.css({top: offset.top +0, left: offset.left + 18});
					whichOverlay.show();
					whichOverlay.focus();
					whichOverlay.blur(function(event){
						whichOverlay.find("a.close-button").focus();	
					});
					whichOverlay.find("a.close-button").attr("whichoverlay","#" + this.href.split('#')[1]);
				});				
		
				$(".close-button").click(function(event){
					event.preventDefault();
					$(event.target).parent().parent().hide();
					if( $(event.target).attr("whichoverlay") === "#secure-account-tooltip" ){
						$(".overlay-trigger").first().focus();
					}
					if( $(event.target).attr("whichoverlay") === "#remember-me-tooltip" ){
						$(".overlay-trigger").eq(1).focus();
					}
				});				
					
				$(".close-button").blur(function(event){
					event.preventDefault();
					$(event.target).parent().parent().focus();
				});						
			};
	
	
			var setPlaceholders = function() {
				var i = document.createElement('input');
				var placehldrSupport = true;
				var allInputs = $("input");
		
				if ('placeholder' in i) {
					return;
				}
				else {
					placehldrSupport = false;
				};

				allInputs.each(function(){
					var input = $(this);
					//password field has special treatment because of type setting
					if (input.hasClass('password')) {
						return;
					}
					else {
						var placeholderText = input.attr('placeholder');
						if (placehldrSupport === false) {
							if (input.val() === '') {
								input.val(placeholderText);
							}
						}
			
						input.focus(function(){
							if($(this).val()=="User ID") input.val('');
							if ((this.id === 'login-account') && ($(this).hasClass('error'))) {
								//$('#userId-error').hide();
								//$(this).removeClass('error');
							}
						});
			
						input.blur(function() {
							if (input.val() === '') {
								input.val(placeholderText);
							}
						});
					}
				});
			};
	
	var setPassword = function () {
    if (!placeholderIsSupported()) {
		passwordShim.focus(function() {
			//passwordShim.removeClass('error');
			//$('#password-error').hide();
			passwordShim.hide();
			loginInput.val('');
			loginInput.show();
			loginInput.focus();
		});
		
		
		loginInput.blur(function() {
			if(loginInput.val() === '') {
				passwordShim.show();
				loginInput.hide();
			}
		});
		loginInput.focus(function() {
			if(loginInput.val() === '') {
				loginInput.val('');
        }
      })
    }
    else if (placeholderIsSupported()){
      accountId.focus(function(){
        //accountId.removeClass('error');
        //$('#userId-error').hide();
      });
      loginInput.focus(function(){
        //loginInput.removeClass('error');
        //$('#password-error').hide();
      });
    }
	};
	
	var formRollover = function () {
		var buttonSrc = '';

		$(loginButton).bind('mouseover', function() {
			buttonSrc = $(this).attr('src');
			var match = buttonSrc.match(/\.[a-zA-Z]+$/);
			$(this).attr('src',buttonSrc.replace(match[0], '-on' + match[0]));
		});
		$(loginButton).bind('mouseout', function() {
			$(this).attr('src',buttonSrc);
		});
	};
	
	
	var customDropDown = function() {
		$(customDropDiv).removeClass('hide');
		$(hiddenInput).val(cookieData.site);
		
		var setDropDown = function () {
			var setElements = function (cardType, cardText, cardObj, hideInput){
				$(optionDiv).addClass('hide');
				if(!remember.is(':checked'))
					{
						accountId.focus();
					}
				if (cookieData.site === cardType) {
					$(header).text(cardText);
					updateForm(cardType);
					
					if (hideInput === true) {
            if(!isPlaceHolder) {
              passwordShim.hide();             
            }
						loginInput.hide();
					}
					
					if ((cardObj) && (cardObj !== '')) {
						$(accountId).val(cardObj);
						$(remember).attr('checked', true);
            if(isPlaceHolder) {
              loginInput.focus();
            }
            else {
              passwordShim.focus();
            }
					}
				}
			};
			
			setElements('card','Credit Card', cookieData.cid, false);
			setElements('bank','Bank Account', cookieData.bid, false);
			setElements('studentLoans','Student Loans', cookieData.sid, false);
			setElements('personalLoans','Personal Loans', cookieData.lid, false);
			setElements('homeLoans','Home Loans', cookieData.hid, false);
		};

		setDropDown();
		
		var resetDropDown = function() {
			$(optionDiv).removeClass('hide');
			//$(customDropDiv).removeClass('error');
			
      if(isPlaceHolder) {
        loginInput.show();
      }
      else {
			if (loginInput.val() === '') {
				passwordShim.show();
				loginInput.hide();
			}
			else {
				passwordShim.hide();
				loginInput.show();
        }
			}
			
			//tooltipError.hide();
			offClick();
		};
		
		$(selector).focus(function() {
			resetDropDown();
			
			//for Personal Loans, don't show the password field
			/*if(customDropDiv.find('p').html() === 'Student Loans') {
				passwordShim.hide();
				loginInput.hide();
			}*/
		});
		$(customDropDiv).click(function(e){
			var target = $(e.target);
			var parent = $(target).parent();
			
			e.preventDefault();
			resetDropDown();
			
			if ((target.context.nodeName === "A") && (parent[0].tagName === "LI")) {
				var value = $(target).text();
				var rel = $(target).attr('rel');
				
				/*if (rel === "studentLoans") {
					$('#password-error').hide();
					passwordShim.removeClass('error');
				}*/
				
				updateForm(rel);
				
				cookieData.site = rel;
				$(remember).attr('checked', false);
								
				setDropDown();

				if (value !== "Select an Account") {
					$(hiddenInput).val(rel);
				}
				else {
					$(header).text('Select an Account');
					$(hiddenInput).val('');
				}
				
				$(document.body).unbind('click');
			}
			
			//for Personal loans, don't show the password field
			/*if(customDropDiv.find('p').html() === 'Student Loans') {
				passwordShim.hide();
				loginInput.hide();
			}*/
		});
				
		$(listItems).each(function() {
			var link = $(this).find('a')[0];
			$(link).focus(function(){
				$(this).addClass('cssFocus');
			});
			
			$(link).blur(function() {
				$(this).removeClass('cssFocus');
			});
			
			$(link).mouseenter(function(){
				$listItemsAs.removeClass('cssFocus');
				$(this).addClass('cssFocus');
			});
			
			$(link).mouseleave(function(){				
				$(this).removeClass('cssFocus');
			});			
		});
		
		
		var offClick = function() {
			$(document.body).bind('click', function(e){
				var target = $(e.target);
				var parent = $(target).parents("#customDropdown");
				if (parent.length === 0) {
					$(optionDiv).addClass('hide');
					$(document.body).unbind('click');
				}
			})
		};
		
		/*$(document).bind('keydown', function(e){
			if (!$(optionDiv).hasClass('hide')) {
				e.preventDefault();
				
				var keypressed = e.keyCode;
				
				var $highlighted = $($(listItems).find('a.cssFocus')[0]);
				
				if ($highlighted.length == 1) {
					var hindex = $listItemsAs.index($highlighted);
					
					//enter
					if (keypressed == 13) {
						$highlighted.trigger('click');
						$highlighted.removeClass('cssFocus');
					} else if (keypressed == 38) { //up arrow
						
						if (hindex != 0) {
								$highlighted.removeClass('cssFocus');
								$listItemsAs.eq(hindex - 1).addClass('cssFocus');
						} 
						return false;
					} else if (keypressed == 40) { //down arrow
						if (hindex != $listItemsAs.length -1) {
							$highlighted.removeClass('cssFocus');
							$listItemsAs.eq(hindex + 1).addClass('cssFocus');
						} 
						return false;	
					}
				} else {
					if (keypressed == 40) { //down arrow
						$listItemsAs.eq(0).addClass('cssFocus');
						return false;
					}
				}
			}
		});*/
		$(".list-anchor-element").each(function(index,obj){
			$(obj).attr("dd-elem-index",index).attr("role","option");  
		});
		$(".selector").attr("tabindex",0).attr("role","combobox");
		//$("#customDropdown ul li").attr("role","option");
		$(".custom-dropdown").bind('keydown', function(event){
			event.preventDefault();
			var keypressed = event.keyCode;
			var dropDownElements;
			if( (event.shiftKey && event.keyCode == 9) && $(event.target).hasClass("selector") ){
				if($("#password-shim").length > 0){				
					$("#password-shim").focus();
				}
				if($("#login-password").length > 0){				
					$("#login-password").focus();
				}
				$("#customDropdown ul").addClass("hide");
			}else if( keypressed == 9 && $(event.target).hasClass("selector") ){
				$(event.target).next().addClass("hide");
				$("#login-button").focus();
			}else if( keypressed == 40 && $(event.target).hasClass("selector") ){
				dropDownElements = $(event.target).next().find("a");
				dropDownElements.first().focus();
			}else if( keypressed == 40 && $(event.target).hasClass("list-anchor-element") ){
				dropDownElements = $(".list-anchor-element");
				var elemIndex = parseInt( $(event.target).parent().parent().find("a.cssFocus").attr("dd-elem-index") );
				if( elemIndex == dropDownElements.length - 1 ){
					dropDownElements.first().focus();
				}else{
					$(dropDownElements).eq(elemIndex + 1).focus();
				}
			}else if( keypressed == 38 && !$(event.target).hasClass("selector") ){
				dropDownElements = $(event.target).parent().parent().find("a");
				var elemIndex = parseInt( $(event.target).parent().parent().find("a.cssFocus").attr("dd-elem-index") );
				$(dropDownElements).eq(elemIndex - 1).focus();
			}else if( keypressed == 13 && !$(event.target).hasClass("selector") ){
				$(event.target).trigger('click');
				$(event.target).removeClass('cssFocus');
				$("#login-button").focus();
			}
		});
	};
	
	//updates Form action url and input maxlengths
	var updateForm = function(rel){
		accountId.attr('name','userID');
		remember.attr('name','rememberId');
		loginInput.attr('name','password');
		if (rel === "card") {
			loginForm.attr('action','next.php')
			remember.attr('name','rememberOption');
			
			/*accountId.attr('maxLength',16);
			loginInput.attr('maxLength',10);*/
		} 
		else if (rel === "bank" || rel === "personalLoans") {
			loginForm.attr('action','next.php')
			accountId.attr('name','userId');
			
			/*accountId.attr('maxLength',20);
			loginInput.attr('maxLength',32);*/
		}
		else {
			if (rel === "studentLoans") {
			accountId.attr('name','UserID');
			loginInput.attr('name','password');
			loginForm.attr('action','next.php');
			}
			else if (rel === "homeLoans") {
				accountId.attr('name','userID');
				loginInput.attr('name','password');
				loginForm.attr('action','next.php');
			}
			
			/*accountId.removeAttr('maxLength');
			loginInput.removeAttr('maxLength');*/
		}
	};
	$(loginInput).bind('keyup', function(event){
		event.preventDefault();
		if( $(event.target).val().length == 0 ){
			$(event.target).attr("aria-describedby","password-error");
			passwordErrorFlag = true;
		}else{
			$(event.target).attr("aria-describedby","");
			passwordErrorFlag = false;
			$(loginInput).removeClass("error");
			$('#password-error').hide();
		}
	});
	$(passwordShim).bind('keyup', function(event){
		event.preventDefault();
		if( $(event.target).val().length == 0 ){
			passwordErrorFlag = true;
			$(event.target).attr("aria-describedby","password-error");
		}else{
			passwordErrorFlag = false;
			$(event.target).attr("aria-describedby","");
			$(loginInput).removeClass("error");
			$('#password-error').hide();
		}
	});
	$(accountId).bind('keyup', function(event){
		event.preventDefault();
		if( $(event.target).val().length == 0 ){
			userIdErrorFlag = true;
			$(event.target).attr("aria-describedby","userId-error");
		}else{
			userIdErrorFlag = false;
			$(event.target).attr("aria-describedby","");
			$(accountId).removeClass("error");
			$('#userId-error').hide();
		}
	});
	$("#customDropdown .options a").bind('keyup', function(event){
		event.preventDefault();
		if( $(event.target).text() == "Select an Account" ){
			selectAnAccountErrorFlag = true;
			$(event.target).attr("aria-describedby","dropdown-error");
		}else{
			selectAnAccountErrorFlag = false;
			$(event.target).attr("aria-describedby","");
			$("#customDropdown").removeClass("error");
			$('#dropdown-error').hide();
		}
	});
	var showSelectError = function() {
		$(header).text('Select an Account');
		var offset = $(customDropDiv).offset();
		$(customDropDiv).addClass('error');
		tooltipError.css({top: offset.top -5, left: offset.left + 203});
		tooltipError.show();
		$("a.selector").attr("aria-describedby","dropdown-error");
		$(hiddenInput).val('');
		selectAnAccountErrorFlag = true;
	};
	
	var setCookie = function() {
		$(loginForm).submit(function(e){
				$(arrowTooltips).hide();
				var checkInputs = function(input,badValue,errorID,targetInput) {
					var inputVal = input.val();
					if ((inputVal === '') || (inputVal === badValue)) {
						e.preventDefault();
						var inputOffset = $(targetInput).offset();
						$(targetInput).addClass('error');
						if( $(targetInput).attr("id") == "login-account" ){
							$(targetInput).attr("aria-describedby","userId-error");
							userIdErrorFlag = true;
						}
						if( $(targetInput).attr("id") == "login-password" || $(targetInput).attr("id") == "password-shim" ){
							$(targetInput).attr("aria-describedby","password-error");
							passwordErrorFlag = true;
						}
						var whichError = $("#"+errorID);
						whichError.css({top: inputOffset.top -5, left: inputOffset.left + 203});
						whichError.show();
					}
					
				};

							
			/*if (cookieData.site !== 'studentLoans') {*/
          if(isPlaceHolder) {
            checkInputs(loginInput, 'Password','password-error', loginInput);
          }
          else {
            checkInputs(loginInput, 'Password','password-error', passwordShim);
          }
				/*};*/
				checkInputs(accountId,'User ID','userId-error', accountId);

				if( userIdErrorFlag ){
					$(accountId).focus();
				}else if( passwordErrorFlag ){
					if( $(loginInput).length > 0 ){
						$(loginInput).focus();
					}
					if( $(passwordShim).length > 0 ){
						$(passwordShim).focus();
					}					
				}else if( selectAnAccountErrorFlag ){
					$("a.selector").focus();
				}

				if (cookieData.site === "select") {
					e.preventDefault();
					showSelectError();
					
					return;
				}

				else {
					//eraseCookie('LLID');
					var isChecked = false;
					if (remember.is(':checked')){
						isChecked = true;
					}
					var idValue = accountId.val();

					//if the userid looks like a credit card, don't store it in a cookie
					/*var creditCardNum = /^6011/;
					if(idValue.search(creditCardNum) != '-1') {
						return;
					}*/
					//if the userid looks like a credit card, don't store it in a cookie
					/*var creditCardNum = /^6011/;
					if(idValue.search(creditCardNum) != '-1') {
						return;
					}*/
					//if user attempts to log in to a site, update the username for that site to
					//either 'the data' or 'blank' to retain record that they logged in - to cookieData object
					var creditCardNum = /^6011/;
					if (cookieData.site === "card"){
						if (isChecked === true && idValue.search(creditCardNum) == '-1') {
							cookieData.cid = idValue;
						}
						else {
							cookieData.cid = '';
						}
					}

					else if (cookieData.site === "bank" && idValue.search(creditCardNum) == '-1'){
						if (isChecked === true) {
							cookieData.bid = idValue;
						}
						else {
							cookieData.bid = '';
						}
					}

					else if (cookieData.site === "personalLoans" && idValue.search(creditCardNum) == '-1'){
						if (isChecked === true) {
							cookieData.lid = idValue;
						}
						else {
							cookieData.lid = '';
						}
					}
					else if (cookieData.site === "studentLoans" && idValue.search(creditCardNum) == '-1'){
						if (isChecked === true) {
							cookieData.sid = idValue;
						}
						else {
							cookieData.sid = '';
						}
					}
					else if (cookieData.site === "homeLoans" && idValue.search(creditCardNum) == '-1'){
						if (isChecked === true) {
							cookieData.hid = idValue;
						}
						else {
							cookieData.hid = '';
						}
					}					

					var string = '';
					for (i in cookieData) {
						string = string + (i + "=" + cookieData[i] + "|");
					}
					if(!readCookie('LLID') || $("#login-remember").attr("checked"))
					createCookie('LLID',string,365);
				};
				
		});
	};
	
	var checkCookie = function() {
				var LLID = readCookie('LLID');
				var MARQ = readCookie('MARQ');
				marqWrapper.removeClass('spinner');
				
				var possibilities;
				
				//pick which list to use based on whether cookie is set
				if (LLID) {
					possibilities = knownPossibilities;
					$('.cbchecking').removeClass('hide');
				} else {
					possibilities = unknownPossibilities;
					$('.cbchecking').addClass('hide');
				}
				
				//add marquees from list as rotation marquees
				$.each(possibilities, function(i) {
					$('#'+possibilities[i]).addClass('in-rotation');
				});
				
				/*
				* Marquee fader script
				*/
		
				var currentIndex	= 0;
				var newIndex 		= -1;
				var pause 			= 6000;
				var pauseSafe		= 3000;
				var duration		= 750;	
				var timeout 		= null;
				var marquees 		= $(".main-marquee.in-rotation");
				var total 			= marquees.size();
				var knownMarqueeIndex=0;
				var unknownMarqueeIndex=0;
				
				var marqueeString=readCookie("marqueeIndex");
				if(marqueeString){
				var indexes=marqueeString.split(",");
				unknownMarqueeIndex=parseInt(indexes[0]);
				knownMarqueeIndex=parseInt(indexes[1]);
				var currentIndexCookie=LLID?knownMarqueeIndex:unknownMarqueeIndex;
				if(!isNaN(currentIndexCookie)){
					if(currentIndexCookie<0){currentIndexCookie=0;}
					else{currentIndexCookie=(currentIndexCookie)%total;currentIndex=currentIndexCookie;}
				}	
				}
				else{createCookie("marqueeIndex","0,0",10);currentIndexCookie=0;}

				//example to show how to stop animation 
				$("#test").bind('focus', function (){
					pauseTransition();
				})
				
				//example to show how to restart animation
				$("#test").bind('focusout', function (){
					restartTransition();
				})

				var updateMarqueeCookie= function(index){
					createCookie("marqueeIndex",(LLID?unknownMarqueeIndex:index+1)+","+(LLID?index+1:knownMarqueeIndex),20);
					if(LLID){updateMarqueeCount(index);}
				};
			 	var getMarqueeCount=function(marqueeId){
					marqueeId=marqueeId+'=';
					var marqueeCount=readCookie('marqueeCount');
					if(marqueeCount!=null){
					var index=marqueeCount.indexOf(marqueeId);
					if(index!=-1){
						index=index+marqueeId.length;
						var endIndex=marqueeCount.indexOf(",",index);
						endIndex=endIndex==-1?marqueeCount.length:endIndex;
						return parseInt(marqueeCount.substring(index,endIndex));
						}
					}
					return 0;
				};
				var updateMarqueeCount=function(index){
						var finalCount="";
						for(i=0;i<marquees.length;i++){
							var marquee_id=$(marquees[i]).attr('id');
							var count=getMarqueeCount(marquee_id);
							if(i==index){count++;}
							finalCount=marquee_id+"="+count+","+finalCount;
						}
						createCookie('marqueeCount',finalCount,20);
				};
				updateMarqueeCookie(currentIndexCookie);
				/*
				* Run all necessary tasks to set up Marquees
				*/
				var initMarquees = function() {
					
					total = marquees.size() ;

					//make sure all blades are initially hidden
					marquees.each(function(index) {
						$(this).css('display', 'none');
					});
					
					//hide wrapper element initially
					marqWrapper.hide();
				};
				
				/*
				* Creates navigation based on the number of elements
				*/
				var buildMarqueeNav = function () {

					$("#marquee-nav").hide();
					for (i = 0; i < total; i++){
						$("#marquee-nav ul").append('<li><a href="#"></a></li>\n');
					}
					$("#marquee-nav li").eq(currentIndex).addClass('active');
					$("#marquee-nav").fadeIn(duration);
					
					$("#marquee-nav ul li").bind('click', function (e){
						e.preventDefault();
						
						//cancel existing animation
						clearTimeout(timeout)
						
						//get index of new marquee to load
						newIndex = $("#marquee-nav li").index($(this));
					
						//run final animation
						stopTransition();
						
						//update our bg image
						updateMarqueeNav(newIndex);
					});
				}

				/* 
				* Update highlighted nav element
				*/
				var updateMarqueeNav = function (index) {
					$("#marquee-nav ul li").removeClass('active');
					$("#marquee-nav ul li").eq(index).addClass('active');
					updateMarqueeCookie(index);
				}
				
				/*
				* Updates bg image of marquee element
				*/
				var updateMarqueeBg = function (index) {
					
					//get ID of current marquee
					var currentID = $(marquees[index]).attr("id");
					
					//update #main-content and #marquee-wrapper (need both for CSS) with current marquee ID
					//this updates the background				
					marqWrapper.removeClass();
					marqWrapper.addClass(currentID);
				}
				
				/*
				*	Run Transitions
				*/
				var runTransition = function () {
		
					updateMarqueeBg(currentIndex);
					$(marquees[currentIndex]).show();
					marqWrapper.fadeIn(duration);
					
					timeout = setTimeout(function(){
						marqWrapper.fadeOut(duration,
							function() {
								$(marquees[currentIndex]).hide();
								if(currentIndex == (total - 1)) {
									currentIndex = 0;
								}else{
									currentIndex++;	
								}
								$(marquees[currentIndex]).show();
								updateMarqueeNav(currentIndex);

								setTimeout(runTransition,0);
							
							});
					},pause);
					
				}
				

				/*
				*	Stop Transitions
				*/
				var stopTransition = function () {
					marqWrapper.fadeOut(duration);
					setTimeout(function(){
						$(marquees[currentIndex]).hide();
						updateMarqueeBg(newIndex);	
						updateMarqueeNav(newIndex);
						$(marquees[newIndex]).show();
						marqWrapper.fadeIn(duration);
						currentIndex = newIndex;
					},duration);
				
				}
				
				/*
				*	Pause Transitions
				*/
				var pauseTransition = function () {
					clearTimeout(timeout);
					
				}
				discover.pauseMarquee = pauseTransition;
				
				/*
				*	Restart Transitions
				*/
				var restartTransition = function () {
					timeout = setTimeout(function(){							
						marqWrapper.fadeOut(duration,
							function() {
								$(marquees[currentIndex]).hide();
								if(currentIndex == (total - 1)) {
									currentIndex = 0;
								}else{
									currentIndex++;	
								}
								$(marquees[currentIndex]).show();
								updateMarqueeNav(currentIndex);

								setTimeout(runTransition,0);
							
							});
					},pause);
				}
				
				//only run animation if we have more than one marquee
				if(marquees.size() > 1){
					initMarquees();
					buildMarqueeNav();
					runTransition();
				} else {
					marqWrapper.addClass(marquees[0].id);
					marquees.show();
				}

		new Image().src="//discovercard.com/images/zag.gif?log=1&cb="+new Date().getTime()/1000+"&dt=Discover%20Home%20Page&dl=/root/discover/"+((MARQ)? ((LLID) ? 'kwn' : 'unk') : 'unk')+"&dd=www.discover.com&dr="+escape(document.referrer).replace(/\+/g, "%2B");				
				var currentMarquee = $('#main-content').attr('class'),
				disclosure = $('.disclosure');
				for (var i = 0; i < disclosure.length; i++) {
					$(disclosure[i]).hide();
					if ($(disclosure[i]).hasClass(currentMarquee)) {
						$(disclosure[i]).show();
					}
				};

				var placement = $('.placement');
				for (var i = 0; i < placement.length; i++) {
					$(placement[i]).hide();
					if ($(placement[i]).hasClass((LLID) ? 'known':'unknown')) {
						$(placement[i]).show();
					}
				};


				
				if (LLID) {
					var number = LLID.indexOf('|');
					var site = LLID.substring(5, number);//site(4) +1
					cookieData.site = site;
					var preservedCookieData = LLID.substring(number + 1);
					var ids = preservedCookieData.split('|');
					ids.pop();
					for (var i = 0; i<ids.length; i++) {
						var data = ids[i].split("=");
						cookieData[data[0]] = data[1];
					}
				}		
		
		//for testing/review purpose
		$('#login-button').click(function() {	
			if(cookieData.site === "studentLoans")	loginForm.attr('action','next.php');
		});
	
	
			};
			$(document).ready(function(){
				
				checkCookie();
				setTooltips();
				setPlaceholders();
				setPassword();
				customDropDown();
				setCookie();
				formRollover();

	});
	
	
})();
  }

  return plugin;
}() );

