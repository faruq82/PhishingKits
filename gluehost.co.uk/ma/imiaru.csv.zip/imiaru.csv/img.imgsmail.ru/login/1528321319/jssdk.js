/******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	var parentJsonpFunction = window["webpackJsonp"];
/******/ 	window["webpackJsonp"] = function webpackJsonpCallback(chunkIds, moreModules, executeModules) {
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [], result;
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(chunkIds, moreModules, executeModules);
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/ 		if(executeModules) {
/******/ 			for(i=0; i < executeModules.length; i++) {
/******/ 				result = __webpack_require__(__webpack_require__.s = executeModules[i]);
/******/ 			}
/******/ 		}
/******/ 		return result;
/******/ 	};
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// objects to store loaded and loading chunks
/******/ 	var installedChunks = {
/******/ 		1: 0
/******/ 	};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// on error function for async loading
/******/ 	__webpack_require__.oe = function(err) { console.error(err); throw err; };
/******/ })
/************************************************************************/
/******/ ({

/***/ 127:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	__webpack_require__(73),
	__webpack_require__(256),
	__webpack_require__(81),
	__webpack_require__(29),
	__webpack_require__(97)
], __WEBPACK_AMD_DEFINE_RESULT__ = (function (
	/** logger */logger,
	/** request */request,
	/** Emitter */Emitter,
	/** Promise */Promise,
	/** util */util
) {
	"use strict";


	var R_URL_VERSION = /^\/?v\d+/,
		R_URL_LAST_SLASH = /\/$/,
		R_URL_FIRST_SLASH = /^\//,
		R_URL_2xSLASH = /\/{2,}/g,
		R_URL_NO_FIRST_2xSLASH = /([^$\/])\/+/g,

		_stringify = JSON.stringify,
		_cloneObject = util.cloneObject
	;


	/**
	 * Объект для работы с API.
	 * Для подключения дополнительный возможностей, таких как обработка SDC и т.п. нужно [их подключить](statuses/) ;]
	 * @class  RPC
	 * @mixes  Emitter
	 */
	var RPC = {
			all: Promise.all,
			request: request,
			Promise: Promise,
			errorHandler: []
		},

		_settings = {
			version: 1,
			sdcUrl: '//auth.mail.ru/sdc',
			baseUrl: '//api.mail.ru/',
			timeout: 10000,
			email: '',
			token: '',
			htmlencoded: false,
			tokenRetries: 2,
			emulateHTTP: true,
			session: ''
		},

		_hasOwn = Object.prototype.hasOwnProperty;


	/**
	 * Трансляция кодов ответа в имена статусов API.
	 * @type {Object}
	 * @memberof RPC
	 */
	RPC.codes = {
		102: 'processing',
		200: 'ok',
		202: 'accepted',
		203: 'non_authoritative',
		206: 'partial',
		301: 'move',
		304: 'notmodified',
		400: 'invalid',
		402: 'payment_required',
		403: 'denied',
		404: 'notfound',
		406: 'unacceptable',
		408: 'timeout',
		409: 'conflict',
		417: 'expectation_failed',
		422: 'unprocessable',
		423: 'locked',
		424: 'failed_dependency',
		426: 'upgrade_required',
		429: 'many_requests',
		449: 'retry_with',
		451: 'unavailable_for_legal_reasons',
		500: 'fail',
		501: 'not_implemented',
		503: 'unavaliable',
		507: 'insufficient'
	};


	/**
	 * Трансляция статусов в коды ответа API.
	 * @type {Object}
	 * @memberof RPC
	 */
	RPC.statuses = {};
	for (var code in RPC.codes) {
		RPC.statuses[RPC.codes[code]] = code;
	}


	// Делаем из названия метода http/https url
	function _normalizeUrl(path) {
		var baseUrl = _settings.baseUrl;
		path = String(path || "");

		/* istanbul ignore else */
		if (R_URL_FIRST_SLASH.test(path)) {
			path = path.replace(R_URL_NO_FIRST_2xSLASH, '$1/');
		} else if (path.indexOf(baseUrl) === -1) {
			if (!R_URL_VERSION.test(path)) {
				path = '/v' + _settings.version + '/' + path;
			}

			// Вырезаем все повторяющиеся слеши, кроме первых двух
			path = baseUrl.replace(R_URL_LAST_SLASH, "") + ("/" + path).replace(R_URL_2xSLASH, "/");
		}

		return path;
	}


	// Делаем из входных данных для RPC.mock объект для $.mockjax
	function _makeMockSettings(path, settings) {
		if (typeof path === 'object') {
			settings = path;
			path = settings.url;
		}

		settings = settings || /* istanbul ignore next */ {};
		var data = settings.data || {};

		return {
			url: _normalizeUrl(path),
			once: settings.once,
			contentType: 'application/json',
			type: settings.type,
			headers: settings.headers || {},
			responseTime: settings.responseTime || 15,
			data: data,
			responseText: _stringify(settings.responseText || {
				body: settings.body || '',
				status: settings.status || /* istanbul ignore next */ 200,
				email: settings.email || '',
				htmlencoded: settings.htmlencoded || '',
				last_modified: settings.last_modified || ''
			}),
			response: settings.response
		};
	}


	// Создаем объект запроса, указанного типа (POST/GET)
	function _call(path, data, options, type) {
		options = _cloneObject(options);
		options.type = type;
		options.loggerMeta = options.loggerMeta || logger.meta(-2);

		return RPC.call(path, data, options);
	}


	/**
	 * Метод для установки/получения настроек.
	 * @static
	 * @method
	 * @memberof RPC
	 * @param  {Object|string}  [options]  Может быть как объектом настроек, так и строковым ключом
	 * @param  {*}  [value]  Используется только для установки значения
	 * @returns {*}
	 */
	RPC.setup = function (options, value) {
		if (options === undefined) { // get all settings
			return _settings;
		} else {
			if (value !== undefined) { // set setting
				_settings[options] = value;
			} else if (typeof options === 'string') { // get setting, options - is a key
				return _settings[options];
			} else {
				for (var key in options) { // set bundle of settings
					/* istanbul ignore next */
					if (_hasOwn.call(options, key)) {
						_settings[key] = options[key];
					}
				}
			}
		}
	};


	/**
	 * Метод для получения URL конца API
	 * @static
	 * @method
	 * @memberof RPC
	 * @param  {string} [path] относительный URL метода или абсолютный если начинается с "/" или "//"
	 * @return {string}
	 */
	RPC.url = function (path) {
		return _normalizeUrl(path);
	};

	/**
	 * Метод проверяет активна ли для пользователя безопасная сессия (см. [Авторизация](http://api.tornado.dev.mail.ru/auth))
	 * @static
	 * @method
	 * @memberof RPC
	 * @returns {boolean}
	 */
	RPC.hasSession = function () {
		return !!_settings.session;
	};

	/**
	 * Метод для проверки наличия токена
	 * @static
	 * @method
	 * @memberof RPC
	 * @return {boolean}
	 */
	RPC.hasToken = function () {
		return !!_settings.token;
	};


	/**
	 * Метод, сбрасывыющий токен
	 * @static
	 * @method
	 * @memberof RPC
	 */
	RPC.resetToken = function () {
		_settings.token = '';
	};


	/**
	 * Получение токена. В случае успешного выполнения устанавливает полученный токен.
	 * @static
	 * @memberof RPC
	 * @return {Promise}
	 */
	RPC.token = function () {
		return RPC.call('tokens').then(function (/* RPC.Request */req) {
			/* jshint expr:true */
			return (_settings.token = req.get('body.token'));
		});
	};


	/**
	 * Универсальный метод для отправки запроса к API.
	 * В случае ответа xhr.is('denied:token') запрашивает токен.
	 * @static
	 * @method
	 * @memberof RPC
	 * @param  {string}        path метод API
	 * @param  {Object}        [data] данные запроса
	 * @param  {Object}        [options] настройки для request
	 * @return {RPC.Request}
	 */
	RPC.call = function call(path, data, options) {
		options = _cloneObject(options);
		options.timeout = options.timeout || _settings.timeout;
		options.Request = RPCRequest;
		options.dataType = 'json';
		options.type = options.type ? options.type.toUpperCase() : 'POST';
		options.loggerMeta = options.loggerMeta || logger.meta(-1);

		data  = _cloneObject(data || {});

		/* istanbul ignore else */
		if (!data.email && _settings.email) {
			data.email = _settings.email;
		}

		/* jshint eqnull:true */
		/* istanbul ignore else */
		if (_settings.htmlencoded != null) {
			data.htmlencoded = _settings.htmlencoded;
		}

		/* istanbul ignore else */
		if (_settings.token) {
			data.token = _settings.token;
		}

		/* istanbul ignore else */
		if (_settings.emulateHTTP === true && options.type != 'GET' && options.type != 'POST') {
			options.type = 'POST';
		}

		/* istanbul ignore else */
		if (_settings.session) {
			data.session = _settings.session;
		}

		options.logger = options.logger || path;

		return request(_normalizeUrl(path), RPC.serialize(data), options);
	};


	/**
	 * Метод сериализации данных, перед отправкой
	 * может быть переопределен
	 * @static
	 * @method
	 * @memberof RPC
	 * @param {*} data - даные
	 * @returns {*}
	 */
	RPC.serialize = function (data) {
		return data;
	};

	/**
	 * Метода для совершения GET зароса
	 * @static
	 * @method
	 * @memberof RPC
	 * @param    {string}        path       метод API
	 * @param    {Object}        [data]     данные запроса
	 * @param    {Object}        [options]  опции
	 * @returns  {RPC.Request}
	 */
	RPC.get = function get(path, data, options) {
		return _call(path, data, options, 'GET');
	};


	/**
	 * Метода для совершения POST зароса
	 * @static
	 * @method
	 * @memberof RPC
	 * @param    {string}        path       метод API
	 * @param    {Object}        [data]     данные запроса
	 * @param    {Object}        [options]  опции
	 * @returns  {RPC.Request}
	 */
	RPC.post = function post(path, data, options) {
		return _call(path, data, options, 'POST');
	};


	/**
	 * Выполнить действия «пачкой»    ***Экспериментальный метод***
	 * @static
	 * @method
	 * @memberof RPC
	 * @param	{Function} executor
	 * @returns {Promise}
	 */
	RPC.batch = function (executor) {
		return request.batch(executor, this.url('batch'));
	};


	/**
	 * Эмуляция XHR
	 * @static
	 * @method
	 * @memberof RPC
	 * @param    {string}   path        Имя метода API
	 * @param    {Object}   [settings]  Результат запроса
	 * @return   {number}               id мока
	 */
	RPC.mock = function (path, settings) {
		return request.mock(_makeMockSettings(path, settings));
	};


	/**
	 * Разовая эмуляция XHR
	 * @static
	 * @method
	 * @memberof RPC.mock
	 * @param    {string}  path        Имя метода API
	 * @param    {Object}  [settings]  Результат запроса
	 * @returns  {number}              id мока
	 */
	RPC.mock.once = function (path, settings) {
		return request.mock.once(_makeMockSettings(path, settings));
	};


	/**
	 * Объект запроса RPC
	 * @class Request
	 * @memberOf RPC
	 * @constructs RPC.Request
	 * @extends request.Request
	 */
	var RPCRequest = function () {
		/**
		 * Время изменения, аналог If-Modified-Since HTTP заголовка.
		 * @type {number}
		 * @name lastModified
		 * @memberof RPC.Request#
		 */
		this.lastModified = null;

		/**
		 * Флаг, указывающий на включенное/отключенное htmlencode
		 * конвертирование значений полей в ответе API.
		 * @type {boolean}
		 * @name htmlencoded
		 * @memberof RPC.Request#
		 */
		this.htmlencoded = null;

		/**
		 * email учетки, над которой производится действие
		 * @type {string}
		 * @name email
		 * @memberof RPC.Request#
		 */
		this.email = null;

		/**
		 * Имя статуса ответа API.
		 * @type {string}
		 * @name statusName
		 * @memberof RPC.Request#
		 */
		this.statusName = null;

		return request.Request.apply(this, arguments);
	};

	// Extend
	RPCRequest.prototype = Object.create(request.Request.prototype, {
		constructor: {value: RPCRequest}
	});


	/**
	 * Завершить запрос
	 * @name RPC.Request#end
	 * @method
	 * @param  {string|boolean} err
	 * @param  {Object} api
	 * @return {*}
	 */
	RPCRequest.prototype.end = function (err, api) {
		// сохраняем реальный статус
		this.httpStatus = this.status;

		if (!err) {
			// Всё ок, API ответило корретно, никаких http ошибок
			for (var key in api) {
				/* istanbul ignore else */
				if (_hasOwn.call(api, key)) {
					this[util.toCamelCase(key)] = api[key];
				}
			}

			// Преобразуем код в название статуса
			this.statusName = RPC.codes[api.status];

			// если пользователю была выставлена безопасная сессия, то сохранить ее
			if (api.session) {
				_settings.session = api.session;
			}

			// В родительский метод передаем именно ответ api.body
			api = api.body;
			err = err || !this.isOK(); // todo: проверить всё это
		}

		// вызываем родительский метод
		return request.Request.fn.end.call(this, err, api);
	};


	/**
	 * Проверить свойство на истинность
	 * @param  {string}  keys
	 * @return {boolean}
	 * @method RPC.Request#is
	 */
	RPCRequest.prototype.is = function (keys) {
		var R_STATUS = /\b(\w+)(?::(\w+))?\b/g, // Не кешируем RegExp, а то «криво» будет работа exec
			key,
			val,
			matches;

		while (!!(matches = R_STATUS.exec(keys))) {
			key = matches[1]; // статус
			val = matches[2]; // значение

			if (RPC.statuses[key] == this.status && (!val || this.body == val)) {
				return true;
			}
		}

		return request.Request.fn.is.call(this, keys);
	};



	// Доступ к RPCRequest
	RPC.Request = RPCRequest;


	// Подмешиваем Emitter
	Emitter.apply(RPC);


	// Обработка ошибок
	request.on('error', function (evt, req) {
		var i = RPC.errorHandler.length,
			handle,
			result;

		while (i--) {
			handle = RPC.errorHandler[i];

			if (req.is(handle.status)) {
				result = handle.process(req);

				/* istanbul ignore else */
				if (result) {
					evt.preventDefault();
					return req.retry(result, true);
				}
			}
		}
	});


	/**
	 * Создать `RPC.Request` из XHR
	 * @param  {string} url
	 * @param  {Object} data
	 * @param  {Object|XMLHttpRequest} xhr
	 * @return {RPC.Request}
	 * @memberOf RPC
	 */
	RPC.from = function (url, data, xhr) {
		var req = request.from.apply(request, arguments);

		/* istanbul ignore else */
		if (req.isOK()) {
			req.status = req.get('body.status');
			req.body = req.get('body.body');
		}

		return req;
	};


	/**
	 * Интеграция произвольного функционала в рабочий процесс отправки и обработки запроса к API
	 * @param  {Object}    options    опции запроса
	 * @param  {Function}  transport  функция отправки запроса
	 * @return {RPC.Request}
	 * @method
	 * @memberOf RPC
	 */
	RPC.workflow = request.workflow;


	// Export
	RPC.version = '0.9.0';
	return RPC;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 256:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	__webpack_require__(253),
	__webpack_require__(73),
	__webpack_require__(255),
	__webpack_require__(257),
	__webpack_require__(29),
	__webpack_require__(81),
	__webpack_require__(97),
	__webpack_require__(98),
	__webpack_require__(572)
], __WEBPACK_AMD_DEFINE_RESULT__ = (function (
	/** function */uuid,
	/** logger */logger,
	/** performance */performance,
	/** config */config,
	/** Promise */Promise,
	/** Emitter */Emitter,
	/** util */util,
	/** function */$
) {
	"use strict";


	/**
	 * «Пачка»
	 * @type {Array|null}
	 * @private
	 */
	var _batch = null;


	/**
	 * Название события «потеря WiFi авторизации»
	 * @const
	 */
	var LOSS_WIFI_AUTH = 'losswifiauth';


	/**
	 * Кеш активных GET-запросов
	 * @type {Object}
	 * @private
	 */
	var _activeCache = {};


	var _stringify = JSON.stringify;


	/**
	 * Получить данные для логирования
	 * @param   {Object}  req
	 * @param   {string}  [uuid]
	 * @returns {Object}
	 * @private
	 */
	var _getLog = function (req, uuid) {
		return {
			//id: uuid || req.uuid,
			url: req.url,
			data: util.cloneJSON(req.data),
			type: req.type,
			headers: req.options && req.options.headers || req.headers,
			startTime: req.startTime,
			duration: req.duration,
			status: req.httpStatus || req.status,
			statusText: req.statusText,
			readyState: req.readyState,
			responseText: req.status != 200 ? req.responseText : void 0
		};
	};



	/**
	 * Low-level интерфейс для работы с ajax/json/и т.п. запросами
	 * @class   request
	 * @mixes	Emitter
	 * @param   {string}         url        куда отправить запрос
	 * @param   {string|Object}  [data]     данные запроса
	 * @param   {Object}         [options]  дополнительные опции
	 * @returns {request.Request}
	 */
	function request(url, data, options) {
		options = util.extend(
			{
				type: 'POST',
				logger: 'request',
				loggerMeta: options && options.loggerMeta || logger.meta(-1),
				headers: {},
				retries: request.setup('retries'),
				Request: Request
			},
			options,
			{
				url: url,
				data: data
			}
		);


		var req,
			cacheKey,
			OptRequest = options.Request;


		if (options.type.toUpperCase() == 'GET') {
			cacheKey = url + '|' + _stringify(data) + '|' + _stringify(options && options.headers);
			req = _activeCache[cacheKey];

			/**
			 * Запрет кеширования GET запросов
			 */
			if (typeof options.cache == 'undefined') {
				options.cache = false;
			}

			if (!req) {
				req = new OptRequest(options);
				_activeCache[cacheKey] = req;

				req.always(function () {
					logger.add('_activeCache.remove', cacheKey);
					delete _activeCache[cacheKey];
				});
			}
		}
		else {
			req = new OptRequest(options);
		}

		return req;
	}


	/**
	 * Отправить запрос
	 * @name request.call
	 * @alias request
	 * @static
	 * @method
	 * @memberof request
	 */
	request.call;


	/**
	 * Отправить GET-запрос
	 * @alias request
	 * @static
	 * @method
	 * @memberof request
	 */
	request.get;



	/**
	 * Отправить POST-запрос
	 * @alias request
	 * @static
	 * @method
	 * @memberof request
	 */
	request.post;


	// Short-методы "get" и "post"
	['call', 'get', 'post'].forEach(function (name) {
		request[name] = function (url, data, options) {
			var meta = logger.meta(-1);

			meta.fn = 'request.' + name;

			options = util.cloneObject(options);
			options.type = options.type || (name == 'call' ? 'post' : name);
			options.loggerMeta = options.loggerMeta || meta;

			return request(url, data, options);
		};
	});


	/**
	 * Глобальные настройки для запросов, [$.ajaxSetup](http://api.jquery.com/jQuery.ajaxSetup/)
	 * @name     request.setup
	 * @static
	 * @method
	 * @param   {Object|string} opts     нзвание, либо объект опций (см. [jQuery.ajax](http://api.jquery.com/jQuery.ajax/#jQuery-ajax-settings))
	 * @param   {*}             [value]  значение
	 * @returns {*}
	 */
	request.setup = function (opts, value) {
		var settings = $.ajaxSettings;

		if (typeof opts === 'string') {
			if (value !== void 0) {
				settings[opts] = value;
			} else {
				return settings[opts];
			}
		}
		else if (opts === void 0) {
			return settings;
		}
		else {
			$.ajaxSetup(opts);
		}
	};


	// «Наши» настройки
	request.setup({
		retries: 1, // максимум попыток `xhr.retry()`
		batchUrl: '/batch', // url по умолчанию для отравки «пачки»

		locationReload: function () {
			(window.mockWindow || /* istanbul ignore next */ window).location.reload();
		},

		lossWiFiAuthDetect: function (xhr, err) {
			var responseText = xhr.responseText;
			return (err == 'parsererror') && /<meta[^>]+refresh/i.test(responseText);
		}
	});



	/**
	 * Объект запроса
	 * @class request.Request
	 * @constructs request.Request
	 * @mixes   Promise
	 * @param   {Object}   options
	 */
	function Request(options) {
		var _this = this,
			_promise,
			logId = (options.headers['X-Request-Id'] = uuid());


		/**
		 * Уникальный идентификатор запроса
		 * @member {string} request.Request#uuid
		 */
		_this.uuid = logId;


		if (options.batch !== false && _batch) {
			_this.batched = true;

			_promise = new Promise(function (resolve, reject) {
				_batch.push({
					req: _this,
					opts: options,
					resolve: resolve,
					reject: reject
				});
			});

			_promise = _promise.then(
				function (body) { return _this.end(false, body); },
				function (err) { return _this.end(err); }
			);
		}
		else {
			_promise = _this.send(options);
		}


		_this.__logger__ = _promise.__logger__;


		/**
		 * «Обещание»
		 * @member {Promise} request.Request#url
		 * @private
		 */
		_this._promise = _promise;
		_promise.metaOffset = 1; // смещение на один вверх по стеку

		/**
		 * Куда делаем запрос
		 * @member {string} request.Request#url
		 */
		_this.url = options.url;

		/**
		 * Тип запроса GET, POST и т.п.
		 * @member {string} request.Request#type
		 */
		_this.type = options.type;

		/**
		 * Параметры запроса
		 * @member {Object} request.Request#data
		 */
		_this.data = options.data;

		/**
		 * Дополнительные опции запроса
		 * @member {Object} request.Request#options
		 */
		_this.options = options;

		/**
		 * Время начала запроса
		 * @member {number} request.Request#startTime
		 */
		_this.startTime = performance.now();

		request.trigger('start', _this);
	}


	Request.fn = Request.prototype = /** @lends request.Request# */ {
		__resultLogEntry__: {},

		/**
		 * Запрос в «пачке»
		 * @type {boolean}
		 */
		batched: false,


		/**
		 * Успешное выполнение запроса
		 * @param  {Function} fn
		 * @return {Request}
		 */
		done: function done(fn) {
			this._promise.__noLog = this.__noLog; // todo: Нужно избавлятся от этого флага
			this._promise.done(fn);

			return this;
		},


		/**
		 * Неудачное выполнение запроса
		 * @param  {Function} fn
		 * @return {Request}
		 */
		fail: function fail(fn) {
			this._promise.__noLog = this.__noLog;
			this._promise.fail(fn);

			return this;
		},


		/**
		 * Любой исход выполнения запроса
		 * @param  {Function} fn
		 * @return {Request}
		 */
		always: function always(fn) {
			this._promise.__noLog = this.__noLog;
			this._promise.always(fn);

			return this;
		},


		/**
		 * Подписаться на выполение запроса
		 * @param  {Function} doneFn
		 * @param  {Function} [failFn]
		 * @return {Promise}
		 */
		then: function then(doneFn, failFn) {
			return this._promise.then(doneFn, failFn);
		},


		/**
		 * Перехвотить ошибки при выполнении
		 * @param  {Function} fn
		 * @return {Promise}
		 */
		'catch': function (fn) {
			return this._promise['catch'](fn);
		},


		/**
		 * Отправить запрос
		 * @param  {Object}  options
		 * @return {Promise}
		 */
		send: function send(options) {
			var _this = this,
				xhr,
				promise;

			/**
			 * Время завершения
			 * @member {number} request.Request#endTime
			 */
			_this.endTime = null;

			/**
			 * Продолжительность запроса
			 * @member {number} request.Request#duration
			 */
			_this.duration = null;

			/**
			 * Запрос в ожидании ответа
			 * @member {boolean} request.Request#pending
			 */
			_this.pending = true;

			/**
			 * Запрос отменен
			 * @member {boolean} request.Request#aborted
			 */
			_this.aborted = false;

			/**
			 * Количество повторных попыток
			 * @member {number} request.Request#retries
			 */
			_this.retries = options.retries;

			/**
			 * Raw-тело ответа (text)
			 * @member {*} request.Request#responseText
			 */
			_this.responseText = null;

			/**
			 * Тело ответа
			 * @member {*} request.Request#body
			 */
			_this.body = null;

			/**
			 * Статус ответа сервера
			 * @type {number}
			 */
			_this.status = null;

			/**
			 * Ошибка
			 * @member {*} request.Request#error
			 */
			_this.error = null;

			// Произвольный траспорт
			if (options.transport) {
				options.xhr = function () {
					return {
						getAllResponseHeaders: function () {
							return String(this.headers);
						},

						open: function () {
						},

						send: function () {
							options.transport(options, function (res) {
								this.status = res.status;
								this.readyState = 4;
								this.headers = res.headers || 'Content-Type: application/json';
								this.responseText = res.responseText;
								this.onreadystatechange && this.onreadystatechange();
							}.bind(this));
						}
					};
				};
			}

			/**
			 * Объект запроса
			 * @member {XMLHttpRequest} request.Request#xhr
			 */
			_this.xhr = xhr = $.ajax(options);

			promise = new Promise(function (resolve, reject) {
				xhr
					.done(resolve)
					.fail(function (x, err) { reject(err); })
				;
			});


			logger.wrap('[[' + options.logger + ']]', _getLog(options), promise);

			this.__resultLogEntry__ = logger.addEntry('log', options.logger + ':pending', null, promise.__logger__.id);
			this.__resultLogEntry__.meta = promise.__logger__.meta = options.loggerMeta;

			promise.__noLog = true;

			return promise.then(
				function (body) { return _this.end(false, body); },
				function (err) { return _this.end(err); }
			);
		},


		/**
		 * Получить заголовок ответа по его имени
		 * @param   {string}  name
		 * @returns {string}
		 */
		getResponseHeader: function (name) {
			return this.xhr.getResponseHeader(name);
		},


		/**
		 * Получить все заголовки от сервера
		 * @returns {string}
		 */
		getAllResponseHeaders: function () {
			return this.xhr.getAllResponseHeaders();
		},


		/**
		 * Отменить запрос
		 */
		abort: function () {
			this.aborted = true;
			this.xhr && this.xhr.abort();
			this.end(false);
		},


		/**
		 * Завершить запрос
		 */
		end: function (err, body) {
			var options = this.options;

			/* jshint eqnull:true */
			this.status = this.status == null ? this.xhr.status : this.status;
			this.statusText = this.statusText || this.xhr.statusText;
			this.readyState = this.xhr.readyState;
			this.responseText = this.xhr.responseText;

			this.endTime = performance.now();
			this.duration = this.endTime - this.startTime;
			this.pending = false;

			this.__resultLogEntry__.args = _getLog(this);

			// Проверяем на потерю WiFi
			if (request.setup('lossWiFiAuthDetect')(this, err)) {
				err = LOSS_WIFI_AUTH;
			}

			if (options.postProcessing) {
				// Пост-обработка
				options.postProcessing(this, body);
			}

			if (err === false) { // Это успех, бро!
				this.body = body;
				this.__resultLogEntry__.label = '[[' + options.logger + ':done]]';
			}
			else { // Всё плохо, но не стоит отчаиваться, возможно кто-то перехватит ошибку
				this.error = err;
				this.__resultLogEntry__.label = '[[' + options.logger + ':fail]]';

				// Emit error
				var evt = new Emitter.Event(err === LOSS_WIFI_AUTH ? err : 'error');

				request.trigger(evt, this);

				// Вернули «обещание», начинаем «веселье»
				if (evt.result && evt.result.then) {
					request.trigger('end', this);

					return evt.result; // вернем это «обещание»
				}
				else if (err === LOSS_WIFI_AUTH && !evt.isDefaultPrevented()) {
					request.setup('locationReload')(this); // перезагружаем страницу
				}
			}

			request.trigger('end', this);

			return Promise[this.isOK() ? 'resolve' : 'reject'](Object.create(this, {then: {value: null} }));
		},


		/**
		 * Сервер ответил 200, 201 или 202 и не было ошибок при парсинге ответа
		 * @returns {boolean}
		 */
		isOK: function () {
			return (this.status >= 200 && this.status <= 202) && !this.error;
		},


		/**
		 * Повторить запрос
		 * @param   {Promise|Function}  [promise]
		 * @param   {boolean}           [self]
		 * @returns {request.Request}
		 */
		retry: function (promise, self) {
			var _this = this,
				options = self ? _this.options : util.cloneObject(_this.options);

			if (options.retries > 0) {
				options.retries--;
				options.logger = 'retry:' + options.logger;

				promise = promise || Promise.resolve();

				if (!promise.then) {
					promise = new Promise(promise);
				}

				return promise.then(
					function () { // success
						if (self) {
							return _this.send(options);
						}
						else {
							return request(_this.url, _this.data, options);
						}
					},

					function () { // fail
						return Promise.reject(_this);
					}
				);
			}

			return Promise.reject(_this);
		},


		/**
		 * Проверить свойство на истинность
		 * @name request.Request#is
		 * @method
		 * @param   {string}  keys
		 * @returns {boolean}
		 */
		is: config.is,


		/**
		 * Проверить свойство на наличие
		 * @name request.Request#has
		 * @method
		 * @param   {string}  keys
		 * @returns {boolean}
		 */
		has: config.has,


		/**
		 * Получить свойство
		 * @name request.Request#get
		 * @method
		 * @param   {string}  key
		 * @returns {boolean}
		 */
		get: config.get,


		/**
		 * Маппинг данных ответа (боже, ну и описание)
		 * @param  {Object|Function} mappers
		 * @return {Object}
		 */
		map: function (mappers) {
			if (mappers instanceof Function) {
				return (mappers.map || mappers).call(mappers, this.get('body'));
			} else {
				var result = {};

				$.each(mappers, function (name, mapper) {
					result[name] = (mapper.map || mapper).call(mapper, this.get('body.' + name));
				}.bind(this));

				return result;
			}
		},


		/**
		 * Сравнить на равество
		 * @param  {request.Request} req
		 * @return {boolean}
		 */
		equals: function (req) {
			return req && (this._promise === req._promise); // возможно есть лучшая проверка, но я не знаю
		}
	};


	/**
	 * Группировать запросы в «пачку»  ***Экспериментальный метод***
	 * @param	{Function} executor
	 * @param	{string}   [url]
	 * @returns {Promise}
	 */
	request.batch = function (executor, url) {
		var batch = _batch || [], // создаем «пачку», либо используем текущию
			results;

		if (_batch === null) {
			_batch = batch;
			batch.promise = new Promise(util.nextTick(function (resolve, reject) {
				if (batch.length > 0) {
					var req = request.post(url || request.setup('batchUrl'), {
						batch: _stringify(batch.map(function (entry) {
							var opts = entry.opts;

							return {
								url: opts.url,
								type: opts.type,
								data: opts.data,
								headers: opts.headers
							};
						}))
					}, { batch: false }) // это запрос идет в не пачки
						.done(function () {
							req.body.forEach(function (body, i) {
								batch[i].req.xhr = req.xhr;
								batch[i].resolve(body);
							});

							resolve();
						})
						.fail(function () {
							batch.forEach(function (entry) {
								entry.req.xhr = req.xhr;
								entry.reject(req);
							});

							reject(req);
						})
					;
				} else {
					resolve();
				}

				_batch = null;
			}, true));
		}

		results = executor();

		return batch.promise.then(function () { return results; });
	};


	// Подмешиваем Emitter
	Emitter.apply(request);


	/**
	 * Создать `request.Request` из XHR
	 * @param  {string} url
	 * @param  {Object} data
	 * @param  {Object|XMLHttpRequest} xhr
	 * @return {request.Request}
	 * @memberOf request
	 */
	request.from = function (url, data, xhr) {
		var req = Object.create(this.Request.prototype, {then: {value: null}});

		req.xhr = xhr;
		req.url = url;
		req.data = data;
		req.status = xhr.status;
		req.statusText = xhr.statusText;
		req.readyState = xhr.readyState;
		req.responseText = xhr.responseText;
		req.pending = false;

		/* istanbul ignore else */
		if (req.isOK()) {
			req.body = JSON.parse(req.responseText);
		}

		return req;
	};


	/**
	 * Интеграция произвольного функционала в рабочий процесс отправки и обработки запроса
	 * @param  {Object}    options    опции запроса
	 * @param  {Function}  transport  функция отправки запроса
	 * @return {request.Request}
	 * @memberOf request
	 */
	request.workflow = function (options, transport) {
		options.transport = transport;
		return this.call(options.url, options.data, options);
	};


	/**
	 * Создание моков, основано на [jQuery.mockjax](https://github.com/appendto/jquery-mockjax)
	 * @name     request.mock
	 * @static
	 * @method
	 * @param    {Object} options
	 * @returns  {number}
	 */
	request.mock = $.mockjax;

	request.mock.once = $.mockjax.once;
	request.mock.clear = $.mockjaxClear;


	// Быстрый доступ к Promise
	request.all = Promise.all;
	request.Promise = Promise;


	// «Запрос», чтобы можно было расширять
	request.Request = Request;


	// Export
	request.version = '0.6.0';
	return request;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 257:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/**
 * @author RubaXa <trash@rubaxa.org>
 * @license MIT
 */
(function () {
	"use strict";


	var R_SPACE = /\s+/,
		R_KEYCHAIN_CHECK = /[\[.\]]/,
		R_KEYCHAIN_SPLIT = /(?:\.|['"]?]?\.?\[['"]?|['"]?])/
	;


	/**
	 * Split строки по пробелу
	 * @private
	 * @param   {string} val
	 * @returns {Array}
	 */
	function _split(val) {
		return (val + '').trim().split(R_SPACE);
	}



	/**
	 * Проверить ключи на наличие и истинность
	 * @private
	 * @param   {object}  obj
	 * @param   {string}  keys
	 * @param   {boolean} [exists]
	 * @returns {boolean}
	 */
	function _check(obj, keys, exists) {
		var ret, i, key, not, min, max;

		/* istanbul ignore else */
		if (keys) {
			keys = _split(keys);
			i = keys.length;

			while (i--) {
				key = keys[i];
				not = false;

				if (key.charAt(0) === '!') {// НЕ ключ
					not = true;
					key = key.substr(1);
				}

				if (key.indexOf(':') !== -1) { // переданы аргументы
					key = key.split(':');
					min = key[1];
					max = key[2];
					key = key[0];
				}

				// Получаем значение ключа
				ret = _grep(obj, key);

				if (min !== void 0) { // сравниваем со значением ключа
					ret = (max === void 0)
							? (ret == min)
							: (ret >= min && ret <= max)
						;
				}

				if (exists) { // Проверка наличия ключа
					ret = ret !== void 0;
				} else { // Приводик к boolean
					ret = !!ret;
				}

				if (ret ^ not) { // применяем модификатор (т.е. XOR)
					return true;
				}
			}
		}

		return false;
	}


	/**
	 * Получить/установить/удалить значение по ключу
	 * @private
	 * @param   {object}  obj
	 * @param   {string}  key
	 * @param   {boolean} [set]
	 * @param   {*}       [value]
	 * @returns {*}
	 */
	function _grep(obj, key, set, value) {
		var isUnset = arguments.length === 3;

		if (R_KEYCHAIN_CHECK.test(key)) {
			var chain = key.split(R_KEYCHAIN_SPLIT),
				i = 0,
				n = chain.length,
				curObj = obj,
				prevObj = obj,
				lastKey
			;

			for (; i < n; i++) {
				key = chain[i];
				if (key !== '') {
					lastKey = key;

					if (curObj) {
						prevObj = curObj;
						curObj = curObj[key];
						if (set && !isUnset && !curObj) {
							prevObj[key] = curObj = {};
						}
					}
					else {
						return void 0;
					}
				}
			}

			if (set) {
				if (isUnset) {
					delete prevObj[lastKey];
				} else {
					prevObj[lastKey] = value;
				}
			}

			return curObj;
		}
		else {
			if (set) {
				if (isUnset) {
					delete obj[key];
				} else {
					obj[key] = value;
				}
			}
			return obj[key];
		}
	}



	/**
	 * Работа с конфигами/настройками
	 * @class config
	 * @constructs config
	 * @param   {Object}  [props]  конфиг
	 * @returns {config}
	 */
	var config = function (props) {
		if (!(this instanceof config)) {
			return	new config(props);
		}

		if (props) {
			this.set(props);
		}
	};


	config.fn = config.prototype = /** @lends config# */ {
		constructor: config,

		/**
		 * Проверить свойства на истинность
		 * @param   {string}  keys  название свойств, разделенных пробелом
		 * @returns {boolean}
		 */
		is: function (keys) {
			return _check(this, keys);
		},


		/**
		 * Проверить наличие свойства
		 * @param   {string}  keys  название свойств, разделенных пробелом
		 * @returns {boolean}
		 */
		has: function (keys) {
			return _check(this, keys, true);
		},


		/**
		 * Получить свойство
		 * @param   {string}  key    имя свойства
		 * @param   {*}       [def]  значение по умолчанию
		 * @returns {boolean}
		 */
		get: function (key, def) {
			var retVal = _grep(this, key);
			return retVal === void 0 ? def : retVal;
		},


		/**
		 * Назначить свойство
		 * @param   {Object|string} props   список свойств
		 * @param   {*}  [value]   значение
		 * @return  {config}
		 */
		set: function (props, value) {
			var _attrs = props;

			/* istanbul ignore else */
			if (typeof props !== 'object') {
				_attrs = {};
				_attrs[props] = value;
			}

			/* istanbul ignore else */
			if (_attrs instanceof Object) {
				for (var key in _attrs) {
					/* istanbul ignore else */
					if (_attrs.hasOwnProperty(key)) {
						_grep(this, key, true, _attrs[key]);
					}
				}
			}

			return this;
		},


		/**
		 * Удалить свойство
		 * @param   {string}  key   имя свойства
		 * @returns {config}
		 */
		unset: function (key) {
			var args = arguments, i = args.length;

			while (i--) {
				_grep(this, args[i], true);
			}

			return this;
		}
	};


	/**
	 * Подмешать методы к объекту
	 * @static
	 * @memberof config
	 * @param  {Object}  target  цель
	 * @returns {Object}  возвращает переданный объекь
	 */
	config.apply = function (target) {
		target.is = config.is;
		target.has = config.has;
		target.get = config.get;
		target.set = config.set;
		target.unset = config.unset;
		return	target;
	};


	// Создаем глобальный конфиг
	var globalConfig = config({ __version__: '0.1.0' }), key;
	for (key in globalConfig) {
		config[key] = globalConfig[key];
	}


	// Версия модуля
	config.version = "0.1.0";


	// Export
	if (true) {
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return config;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else if (typeof module != "undefined" && module.exports) {
		module.exports = config;
	} else {
		window.config = window.__config__ = config;
	}
})();


/***/ }),

/***/ 29:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/**
 * @author RubaXa <trash@rubaxa.org>
 * @license MIT
 */
(function () {
	"use strict";


	function _then(promise, method, callback) {
		return function () {
			var args = arguments, retVal;

			/* istanbul ignore else */
			if (typeof callback === 'function') {
				try {
					retVal = callback.apply(promise, args);
				} catch (err) {
					promise.reject(err);
					return;
				}

				if (retVal && typeof retVal.then === 'function') {
					if (retVal.done && retVal.fail) {
						retVal.__noLog = true;
						retVal.done(promise.resolve).fail(promise.reject);
						retVal.__noLog = false;
					}
					else {
						retVal.then(promise.resolve, promise.reject);
					}
					return;
				} else {
					args = [retVal];
					method = 'resolve';
				}
			}

			promise[method].apply(promise, args);
		};
	}


	/**
	 * «Обещания» поддерживают как [нативный](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise)
	 * интерфейс, так и [$.Deferred](http://api.jquery.com/category/deferred-object/).
	 *
	 * @class Promise
	 * @constructs Promise
	 * @param   {Function}  [executor]
	 */
	var Promise = function (executor) {
		var _completed = false;

		function _finish(state, result) {
			dfd.done =
			dfd.fail = function () {
				return dfd;
			};

			dfd[state ? 'done' : 'fail'] = function (fn) {
				/* istanbul ignore else */
				if (typeof fn === 'function') {
					fn(result);
				}
				return dfd;
			};

			var fn,
				fns = state ? _doneFn : _failFn,
				i = 0,
				n = fns.length
			;

			for (; i < n; i++) {
				fn = fns[i];
				/* istanbul ignore else */
				if (typeof fn === 'function') {
					fn(result);
				}
			}

			fns = _doneFn = _failFn = null;
		}


		function _setState(state) {
			return function (result) {
				if (_completed) {
					return dfd;
				}

				_completed = true;

				dfd.resolve =
				dfd.reject = function () {
					return dfd;
				};

				if (state && result && result.then && result.pending !== false) {
					// Опачки!
					result.then(
						function (result) { _finish(true, result); },
						function (result) { _finish(false, result); }
					);
				}
				else {
					_finish(state, result);
				}

				return dfd;
			};
		}

		var
			_doneFn = [],
			_failFn = [],

			dfd = {
				/**
				 * Добавляет обработчик, который будет вызван, когда «обещание» будет «разрешено»
				 * @param  {Function}  fn  функция обработчик
				 * @returns {Promise}
				 * @memberOf Promise#
				 */
				done: function done(fn) {
					_doneFn.push(fn);
					return dfd;
				},

				/**
				 * Добавляет обработчик, который будет вызван, когда «обещание» будет «отменено»
				 * @param  {Function}  fn  функция обработчик
				 * @returns {Promise}
				 * @memberOf Promise#
				 */
				fail: function fail(fn) {
					_failFn.push(fn);
					return dfd;
				},

				/**
				 * Добавляет сразу два обработчика
				 * @param   {Function}   [doneFn]   будет выполнено, когда «обещание» будет «разрешено»
				 * @param   {Function}   [failFn]   или когда «обещание» будет «отменено»
				 * @returns {Promise}
				 * @memberOf Promise#
				 */
				then: function then(doneFn, failFn) {
					var promise = Promise();

					dfd.__noLog = true; // для логгера

					dfd
						.done(_then(promise, 'resolve', doneFn))
						.fail(_then(promise, 'reject', failFn))
					;

					dfd.__noLog = false;

					return promise;
				},

				notify: function () { // jQuery support
					return dfd;
				},

				progress: function () { // jQuery support
					return dfd;
				},

				promise: function () { // jQuery support
					// jQuery support
					return dfd;
				},

				/**
				 * Добавить обработчик «обещаний» в независимости от выполнения
				 * @param   {Function}   fn   функция обработчик
				 * @returns {Promise}
				 * @memberOf Promise#
				 */
				always: function always(fn) {
					dfd.done(fn).fail(fn);
					return dfd;
				},


				/**
				 * «Разрешить» «обещание»
				 * @param    {*}  result
				 * @returns  {Promise}
				 * @method
				 * @memberOf Promise#
				 */
				resolve: _setState(true),


				/**
				 * «Отменить» «обещание»
				 * @param   {*}  result
				 * @returns {Promise}
				 * @method
				 * @memberOf Promise#
				 */
				reject: _setState(false)
			}
		;


		/**
		 * @name  Promise#catch
		 * @alias fail
		 * @method
		 */
		dfd['catch'] = function (fn) {
			return dfd.then(null, fn);
		};


		dfd.constructor = Promise;


		// Работеам как native Promises
		/* istanbul ignore else */
		if (typeof executor === 'function') {
			try {
				executor(dfd.resolve, dfd.reject);
			} catch (err) {
				dfd.reject(err);
			}
		}

		return dfd;
	};


	/**
	 * Дождаться «разрешения» всех обещаний
	 * @static
	 * @memberOf Promise
	 * @param    {Array} iterable  массив значений/обещаний
	 * @returns  {Promise}
	 */
	Promise.all = function (iterable) {
		var dfd = Promise(),
			d,
			i = 0,
			n = iterable.length,
			remain = n,
			values = [],
			_fn,
			_doneFn = function (i, val) {
				(i >= 0) && (values[i] = val);

				/* istanbul ignore else */
				if (--remain <= 0) {
					dfd.resolve(values);
				}
			},
			_failFn = function (err) {
				dfd.reject([err]);
			}
		;

		if (remain === 0) {
			_doneFn();
		}
		else {
			for (; i < n; i++) {
				d = iterable[i];

				if (d && typeof d.then === 'function') {
					_fn = _doneFn.bind(null, i); // todo: тест

					d.__noLog = true;

					if (d.done && d.fail) {
						d.done(_fn).fail(_failFn);
					} else {
						d.then(_fn, _failFn);
					}

					d.__noLog = false;
				}
				else {
					_doneFn(i, d);
				}
			}
		}

		return dfd;
	};


	/**
	 * Дождаться «разрешения» всех обещаний и вернуть результат последнего
	 * @static
	 * @memberOf Promise
	 * @param    {Array}   iterable   массив значений/обещаний
	 * @returns  {Promise}
	 */
	Promise.race = function (iterable) {
		return Promise.all(iterable).then(function (values) {
			return values.pop();
		});
	};


	/**
	 * Привести значение к «Обещанию»
	 * @static
	 * @memberOf Promise
	 * @param    {*}   value    переменная или объект имеющий метод then
	 * @returns  {Promise}
	 */
	Promise.cast = function (value) {
		var promise = Promise().resolve(value);
		return value && typeof value.then === 'function'
			? promise.then(function () { return value; })
			: promise
		;
	};


	/**
	 * Вернуть «разрешенное» обещание
	 * @static
	 * @memberOf Promise
	 * @param    {*}   value    переменная
	 * @returns  {Promise}
	 */
	Promise.resolve = function (value) {
		return (value && value.constructor === Promise) ? value : Promise().resolve(value);
	};


	/**
	 * Вернуть «отклоненное» обещание
	 * @static
	 * @memberOf Promise
	 * @param    {*}   value    переменная
	 * @returns  {Promise}
	 */
	Promise.reject = function (value) {
		return Promise().reject(value);
	};


	/**
	 * Дождаться «разрешения» всех обещаний
	 * @param   {Object}  map «Ключь» => «Обещание»
	 * @returns {Promise}
	 */
	Promise.map = function (map) {
		var array = [], key, idx = 0, results = {};

		for (key in map) {
			array.push(map[key]);
		}

		return Promise.all(array).then(function (values) {
			/* jshint -W088 */
			for (key in map) {
				results[key] = values[idx++];
			}

			return results;
		});
	};



	// Версия модуля
	Promise.version = "0.3.1";


	/* istanbul ignore else */
	if (!window.Promise) {
		window.Promise = Promise;
	}


	// exports
	if (true) {
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return Promise;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else if (typeof module != "undefined" && module.exports) {
		module.exports = Promise;
	}
	else {
		window.Deferred = Promise;
	}
})();


/***/ }),

/***/ 361:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	__webpack_require__(97),
	__webpack_require__(882),
	__webpack_require__(217),
	__webpack_require__(127),
	__webpack_require__(81)
], __WEBPACK_AMD_DEFINE_RESULT__ = (function (
	/** util */util,
	/** Function */filter,
	/** Function */inherit,
	/** RPC */RPC,
	/** Emitter */Emitter
) {
	"use strict";


	/**
	 * «Обещание» с ссылкой на список моделей, которые будут загружены
	 * @typedef  {Object}  ModelListPromise
	 * @property {Model.List} list
	 * @property {Function} then
	 * @property {Function} done
	 * @property {Function} fail
	 * @property {Function} always
	 */



	var array = [],

		array_push = array.push,
		array_join = array.join,
		array_sort = array.sort,
		array_slice = array.slice,
		array_splice = array.splice,
		array_indexOf = array.indexOf,
		array_some = array.some,
		array_every = array.every,
		array_reduce = array.reduce,

		_allModelEvents = 'sync change remove destroy',

		stringifyJSON = JSON.stringify,

		_compareAttr = function (/* Model */a, /* Model **/b, /* string */attr, /* boolean */desc) {
			var aVal = a.get(attr),
				bVal = b.get(attr),
				res = aVal - bVal;

			if (res !== res) {
				if (aVal && aVal.localeCompare) {
					res = aVal.localeCompare(bVal);
				} else {
					res = (aVal == bVal) ? 0 : (aVal > bVal ? 1 : -1);
				}
			}

			return res * (desc ? -1 : 1);
		}
	;


	/**
	 * Список моделей (коллекция)
	 * @class Model.List
	 * @constructs Model.List
	 * @mixes  Emitter
	 * @mixes  inherit
	 * @param  {Model[]}    [models]  массив моделей
	 * @param  {boolean}    [lazy]    ленивая инициализация
	 */
	function List(models, lazy) {
		this._index = {};
		this._safedStore = {};
		this.length = 0;

		// Метод должен быть уникальный для каждого экземпляра класса
		this._debounceTriggerUpdate = util.debounce(function () {
			this.trigger('update', this);
		}, 0);

		if (models instanceof Array || models instanceof List) {
			this.set(models, true);
		}
		else if (lazy) {
			this.on = this._lazyOn;
			this.get = this._lazyGet;
		}
	}


	List.fn = List.prototype = /** @lends Model.List# */ {
		constructor: List,


		/**
		 * Как сортировать коллекцию, подробнее смотрите метод `sort`
		 * @type {string|object|function}
		 */
		comparator: null,


		/**
		 * Связанная модель
		 * @type {Model}
		 */
		Model: null,


		/**
		 * Количество моделей в коллекции
		 * @type {number}
		 */
		length: 0,

		/**
		 * Привязаны ли модели в этом списке к глобальному списку экзепляров (Model.all)
		 * @type {boolean}
		 */
		local: false,

		/**
		 * Дополнительные индексы
		 * @type {object}
		 * @private
		 */
		_indexes: null,


		/**
		 * Ленивая инициазиция слушателей событий
		 * @param   {string}    events
		 * @param   {Function}  fn
		 * @returns {Model.List}
		 * @private
		 */
		_lazyOn: function (events, fn) {
			var on = Emitter.fn.on,
				i = this.length;

			this.on = on; // возвращаем метод

			while (i--) {
				this[i].on(_allModelEvents, this);
			}

			return on.call(this, events, fn);
		},


		/**
		 * Ленивая инициазиция метода индекса
		 * @param   {*}    id
		 * @returns {Model}
		 * @private
		 */
		_lazyGet: function (id) {
			var get = List.fn.get,
				i = this.length,
				model,
				_index = this._index
			;

			this.get = get; // возвращаем метод

			while (i--) {
				model = this[i];
				_index[model.id] = _index[model.cid] = model;
				(this._addToIndex !== void 0) && this._addToIndex(model);
			}

			return get.call(this, id);
		},


		/**
		 * Подготовить модель
		 * @param   {Object}  attrs
		 * @returns {Model}
		 * @private
		 */
		_prepareModel: function (attrs) {
			var Model = this.Model,
				model = attrs,
				all = Model.all,
				id
			;

			if (!(attrs instanceof Model)) {
				// попробуем достать из глобальной коллекции
				id = attrs.cid || attrs[Model.fn.idAttr];
				model = this.get(id) || (!this.local && all.get(id));

				if (!model) {
					// Создаем модель
					model = new Model(attrs);

					!this.local && all.set([model]);
				}
				else {
					// просто обновляем
					model.set(attrs);
				}
			}

			return model;
		},


		/**
		 * Обработка и делигирование события от модели
		 * @param  {Emitter.Event}  evt
		 * @param  {Model}  model
		 * @private
		 */
		handleEvent: function (evt, model) {
			var type = evt.type;

			if (type === 'remove' || type === 'destroy') {
				this.remove(model);
			}
			else { // Метод `remove` сам испускает события
				(model.id !== null) && (this._index[model.id] = model); // переиндексируем

				evt.list = this;
				this.trigger(evt, model);
			}

			this._changed = type === 'change';

			if (this._changing !== true) { // Выставляется в `set`
				this._debounceTriggerUpdate();
			}
		},


		/**
		 * Перебор моделей
		 * @param   {Function} iterator
		 * @param   {*}  thisArg
		 * @returns {Model.List}
		 */
		each: function (iterator, thisArg) {
			for (var i = 0, n = this.length; i < n; i++) {
				iterator.call(thisArg, this[i], i, this);
			}
			return this;
		},


		/**
		 * Вернет массив, полученный преобразованием каждой модели в функции iterator
		 * @param  {Function} iterator
		 * @param  {*} thisArg
		 * @return {Array}
		 */
		map: function (iterator, thisArg) {
			var retArr = [];

			for (var i = 0, n = this.length; i < n; i++) {
				retArr.push(iterator.call(thisArg, this[i], i, this));
			}

			return retArr;
		},


		/**
		 * Проверяет, удовлетворяет ли хоть какой-нибудь элемент массива условию, заданному в передаваемой функции.
		 * @param   {Function} callback
		 * @param   {*} [thisArg]
		 * @returns {boolean}
		 */
		some: function (callback, thisArg) {
			return array_some.call(this, callback, thisArg || this);
		},


		/**
		 * Проверяет, удовлетворяют ли все элементы массива условию, заданному в передаваемой функции.
		 * @param   {Function} callback
		 * @param   {*} [thisArg]
		 * @returns {boolean}
		 */
		every: function (callback, thisArg) {
			return array_every.call(this, callback, thisArg || this);
		},


		/**
		 * Применяет функцию `callback` по очереди к каждому элементу массива слева направо,
		 * сохраняя при этом промежуточный результат.
		 * @param   {Function} callback
		 * @param   {*} [initValue]
		 * @returns {*}
		 */
		reduce: function (callback, initValue) {
			return array_reduce.apply(this, arguments);
		},


		/**
		 * Посчитать сумму
		 * @param   {string} attr
		 * @returns {number}
		 */
		sum: function (attr) {
			var sum = 0;

			this.each(function (model) {
				sum += model.get(attr);
			});

			return sum;
		},


		/**
		 * Посчитать среднее арифметическое
		 * @param   {string} attr
		 * @returns {number}
		 */
		avg: function (attr) {
			return this.sum(attr) / this.length;
		},


		/**
		 * Вернет новую коллекцию, состоящую из моделей,
		 * для которых итератор возвращает истинное значение
		 * @param  {Function|Object} iterator   итератор, либо объект "имя аттрибута" => "зачение"
		 * @param  {*}               [thisArg]  `this` для итератора
		 * @param  {boolean}         [once]     вернуть первое найденное значение
		 * @returns {Model.List|Model|undefined}
		 */
		filter: function (iterator, thisArg, once) {
			var list = new (this.constructor)(null, true),
				i = 0,
				n = this.length,
				model,
				length = 0,
				isWhere
			;

			iterator = filter.createIterator(iterator, thisArg);
			isWhere = iterator.isWhere;

			for (; i < n; i++) {
				model = this[i];

				if (isWhere === true) {
					/* istanbul ignor else */
					if (iterator(model.attributes, model)) {
						list[length++] = model;
					}
				}
				else if (iterator(model, i, this)) {
					list[length++] = model;
				}

				if (length === 1 && once) {
					return list[0];
				}
			}

			if (once) {
				return;
			}

			list.length = length;

			return list;
		},


		/**
		 * Получить первую модель из коллекции
		 * @returns {Model}
		 */
		first: function () {
			return this[0];
		},


		/**
		 * Получить последнию модель из коллекции
		 * @returns {Model}
		 */
		last: function () {
			return this[this.length - 1];
		},


		/**
		 * Найти модель (см. filter)
		 * @param   {Function|Object}  iterator
		 * @param   {*}                [thisArg]
		 * @returns {Model}
		 */
		find: function (iterator, thisArg) {
			return this.filter(iterator, thisArg, true);
		},


		/**
		 * Получить массив значений по имени свойства
		 * @param   {string}  attr  имя свойства модели
		 * @returns {Array}
		 */
		pluck: function (attr) {
			return this.map(function (model) {
				return model.get(attr);
			});
		},


		/**
		 * Вернет `true`, если коллекция содержит элемент model
		 * @param   {*}  model   модель, идентификатор или cid
		 * @return {boolean}
		 */
		contains: function (model) {
			return !!this.get(model);
		},


		/**
		 * Получить index модели
		 * @param   {Model|object|string|number}  [model]   модель, объект, id или cid
		 * @returns {number}
		 */
		indexOf: function (model) {
			if (!(model instanceof Object)) {
				model = { id: model, cid: model };
			}

			var idx = this.length,
				_model;

			while (idx--) {
				_model = this[idx];

				if (_model.id === model.id || _model.cid === model.cid) {
					return idx;
				}
			}

			return -1;
		},


		/**
		 * Сортировать
		 * @param   {Object|Function}  attrs       аттрибут, объект { attr: desc(boolean) } или функция
		 * @param   {Object|boolean}   [options]   возможные опции: silent, reverse, clone
		 * @returns {Model.List}
		 */
		sort: function (attrs, options) {
			if (!attrs) {
				attrs = this.comparator || this.Model.fn.idAttr;
			}


			var _this = this,
				typeOf = typeof attrs,
				comparator,
				silent,
				reverse;


			if (options) {
				silent = options === true || options.silent;
				reverse = options.reverse;

				if (options.clone) {
					_this = _this.clone();
				}
			}


			if (typeOf === 'string') {
				// Сортировка по аттрибуту
				comparator = function (a, b) {
					return _compareAttr(a, b, attrs, reverse);
				};
			}
			else if (typeOf === 'object') {
				// сортировка по нескольким аттрибутам
				var keys = Object.keys(attrs),
					keysLength = keys.length;

				comparator = function (a, b) {
					var i = 0,
						res = 0;

					for (; i < keysLength; i++) {
						res = _compareAttr(a, b, keys[i], attrs[keys[i]] ^ reverse);

						if (res !== 0) {
							return res;
						}
					}

					return res;
				};
			}
			else {
				// Передана функция сравнения
				comparator = function (a, b) {
					return attrs.call(this, a, b) * (reverse ? -1 : 1);
				};
			}

			// Сортируем
			array_sort.call(_this, comparator);

			!silent && _this.trigger('sort', _this);

			return _this;
		},


		/**
		 * Получить модель по индексу
		 * @param   {number}  index
		 * @returns {Model|undefined}
		 */
		eq: function (index) {
			return this[index];
		},


		/**
		 * Получить модель по id
		 * @param   {*}  id   идентификатор, cid или модель
		 * @returns {Model|undefined}
		 */
		get: function (id) {
			/* jshint eqnull:true */
			return (id == null)
				? void 0
				: this._index[id.cid || id[this.Model.fn.idAttr] || id]
			;
		},


		/**
		 * Получить модель по id даже если её нет
		 * @param   {*}  id   идентификатор или cid
		 * @returns {Model}
		 */
		getSafe: function (id) {
			var model = this.get(id);
			var store = this.Model.all._safedStore;

			/* istanbul ignore else */
			if (model === void 0) {
				id = id && (id[this.Model.fn.idAttr] || id);

				model = store[id];

				if (model === void 0) {
					model = new (this.Model)({id: id});
					store[id] = model;
				}
			}

			return model;
		},


		/**
		 * Создать модель и добавить в коллекцию
		 * @param   {Object}  attrs  свойства модели
		 * @param   {Object}  [options]
		 * @returns {Model}
		 */
		create: function (attrs, options) {
			var model = this._prepareModel(attrs);
			this.set([model], options);
			return model;
		},


		/**
		 * Установить новый список моделей
		 * @param   {Model[]}  models  массив свойств или моеделей
		 * @param   {Object}   [options]   опции (clone: false, reset: false, silent: false, sort: boolean|preset, merge: true)
		 * @returns {Model.List}
		 */
		set: function (models, options) {
			var i,
				n,
				evt = new Emitter.Event('add'),
				cid,
				model,
				_models, // предудущий список моделей

				_index = this._index,
				length = this.length,

				clone = false,
				merge = true,
				reset = false,
				silent = false,
				changed = false,

				sort = !!this.comparator,
				sorted = false
			;


			// Клонируем массив, потому что дальше мы будем его модифицировать
			models = (models && models.slice) ? models.slice() : [];


			if (options) {
				clone = options.clone;
				merge = options.merge !== false;
				reset = options.reset;
				silent = options.silent || options === true;

				if (options.sort !== void 0) {
					sort = options.sort;
				}
			}


			if (reset) {
				// Сбрасываем все модели
				_models = array_splice.call(this, 0, length);
				i = length;

				reset = length > 0 || models.length > 0;
				changed = reset;

				// Отписываемся от событий модели
				while (i--) {
					_models[i].off(_allModelEvents, this);
				}

				// Сбрасываем index и длину
				length = 0;
				_index = this._index = {};
			}


			for (i = 0, n = models.length; i < n; i++) {
				this._changed = false; // Выставляет в `handleEvent` при изменении моделей (оптимизация)
				this._changing = true; // Проверяется в `handleEvent` при изменении моделей (оптимизация)

				model = this._prepareModel(models[i]);

				cid = model.cid;
				models[i] = model;

				changed = changed || this._changed;

				// Проверяем в индексе
				if (_index[cid] === void 0) {
					// Добавялем в индекс
					_index[cid] = model;
					(model.id !== null) && (_index[model.id] = model);
					(this._addToIndex !== void 0) && this._addToIndex(model);

					// Добавляем в коллекцию
					this[length] = model;
					this.length = ++length;

					// Подписываемся на события
					model.on(_allModelEvents, this);

					if (!silent) {
						// Событие "add"
						changed = true;
						evt.list = this;
						evt.target = model;
						this.trigger(evt, model);
					}
				}


				// Сохранить порядок в котором переданны элементы
				if (sort === 'preset' && this[i] !== model) {
					sorted = true;

					this[this.indexOf(model)] = this[i];
					this[i] = model;
				}
			}


			if (merge === false) {
				// Проходимся по моделяем и удаляем которых нет
				i = length;

				while (i--) {
					if (models.indexOf(this[i]) === -1) {
						changed = true;
						this.remove(this[i]);
					}
				}
			}


			if (changed && sort === true && !sorted) {
				// Сортируем коллекцию, если были изменения
				sorted = true;
				this.sort(null, { silent: true });
			}

			this._changing = false;

			if (!silent) { // Без событий
				sorted && this.trigger('sort', this);
				reset && this.trigger({ type: 'reset', models: this, previousModels: _models }, this);

				if (sorted || changed) {
					this._debounceTriggerUpdate.cancel();
					this.trigger('update', this);
				}
			}


			if (clone) {
				return new (this.constructor)(models);
			}

			return this;
		},


		/**
		 * Преобразовать в массив
		 * @returns {Model[]}
		 */
		toArray: function () {
			return array_slice.call(this);
		},


		/**
		 * Преобразовать в JSON
		 * @param   {boolean}  [ref]  вернуть ссылку на аттрибуты модели
		 * @returns {Object[]}
		 */
		toJSON: function (ref) {
			return this.map(function (model) {
				return model.toJSON(ref);
			});
		},


		/**
		 * Обрезать, возвращает новую коллекцию
		 * @param   {number}  [start]
		 * @param   {number}  [end]
		 * @returns {Model.List}
		 */
		slice: function (start, end) {
			var array = start === void 0 ? this : array_slice.call(this, start, end === void 0 ? this.length : end),
				i = array.length,
				newList = new (this.constructor)(null, true)
			;

			while (i--) {
				newList[i] = array[i];
			}

			newList.length = array.length;

			return newList;
		},


		/**
		 * Сбросить коллекуию
		 * @param   {Array}  [models]
		 * @param   {Object} [options]
		 * @returns {Model.List}
		 */
		reset: function (models, options) {
			options = options || {};

			if (options === true) {
				options = { silent: true };
			}

			options.reset = true;
			options.clone = false;

			return this.set(models, options);
		},


		/**
		 * Удалить модель из коллекции
		 * @param   {Model}  model
		 * @returns {Model.List}
		 */
		remove: function (model) {
			var evt,
				idx = array_indexOf.call(this, model);

			/* istanbul ignore else */
			if (idx !== -1) {
				model.off(_allModelEvents, this);
				array_splice.call(this, idx, 1);

				delete this._index[model.id];
				delete this._index[model.cid];

				evt = new Emitter.Event('remove');
				evt.list = this;
				evt.target = model;

				this.trigger(evt, model);

				if (this._changing !== true) { // Выставляется в `set`
					this._debounceTriggerUpdate();
				}
			}

			return this;
		},


		/**
		 * Сохранить изменения единой пачкой
		 * @param   {*} [attr]
		 * @param   {*} [value]
		 * @param   {*} [options]
		 * @returns {Promise}
		 */
		save: function (attr, value, options) {
			return RPC.batch(function () {
				this.each(function (model) {
					model.save(attr, value, options);
				});
			}.bind(this));
		},


		/**
		 * Удалить всю коллекцию
		 * @param   {Object}  [query] дополнительные параметры запроса
		 * @retruns {Promise}
		 */
		drop: function (query) {
			return RPC.batch(function () {
				this.each(function (model) {
					model.remove(query);
				});
			}.bind(this));
		},


		/**
		 * Уничтожить коллекцию и модели в ней
		 * @returns {Model.List}
		 */
		destroy: function () {
			var i = this.length;

			while (i--) {
				/* jshint expr:true */
				this[i] && this[i].destroy();
			}

			return this;
		},


		/**
		 * Получить или обновить список
		 * @param   {Object} [query]   параметры запроса
		 * @param   {Object} [options] опции (reset: false, force: false)
		 * @returns {ModelListPromise}
		 */
		fetch: function (query, options) {
			options = options || {};

			var list = this,
				Model = list.Model,
				all = Model.all,
				promise = Model.fetchData(query, null, options.force)
					.then(function (array) {
						!list.local && all.set(array); // глобальный список
						list[options.reset ? 'reset' : 'set'](array, options);

						return list;
					})
					.fail(function (err) {
						list.emit('error', err);
					})
			;

			promise.list = list;

			return promise;
		},


		/**
		 * Клонировать коллекцию
		 * @returns {Model.List}
		 */
		clone: function () {
			return this.slice();
		}
	};


	/**
	 * @name  Model.List#forEach
	 * @alias each
	 * @method
	 */
	List.fn.forEach = List.fn.each;


	/**
	 * @name  Model.List#where
	 * @alias filter
	 * @method
	 */
	List.fn.where = List.fn.filter;


	/**
	 * @name  Model.List#findWhere
	 * @alias find
	 * @method
	 */
	List.fn.findWhere = List.fn.find;


	// Подмещиваем методы Emitter'а
	Emitter.apply(List.fn);


	// Подмещиваем наследование
	inherit.apply(List);


	/**
	 * Добавить индекс для быстрого доступа к модели/моделям
	 * @param    {string}  attr  имя свойства
	 * @param    {boolean} [uniq]  уникальный индекс
	 * @methodOf List
	 */
	List.addIndex = function (attr, uniq) {
		var _indexes = this.fn._indexes;

		/* istanbul ignore else */
		if (!_indexes) {
			_indexes = this.fn._indexes = [];
		}

		_indexes.push({
			attr: attr,
			uniq: uniq
		});

		/* jshint evil:true */
		this.fn._addToIndex = Function('model', _indexes.map(function (index) {
			var attr = stringifyJSON(index.attr),
				value = attr.indexOf('.') > -1
							? 'model.get(' + attr + ')'
							: 'model.attributes[' + attr + ']';

			/* istanbul ignore else */
			if (index.uniq) {
				return 'this._index[' + value + '] = model;';
			} else {
				throw "todo: Нужно думать";
			}
		}).join('\n'));
	};

	/**
	 * Получить массив значений по имени свойства из массива или списка моделей
	 * @param    {model.List|Model[]}	list	список моделей
	 * @param    {string} property свойство
	 */
	List.pluck = function (list, property) {

		return List.fn.pluck.call(list, property);
	};

	// Export
	List.version = '0.12.0';
	return List;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 73:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	__webpack_require__(253),
	__webpack_require__(97),
	__webpack_require__(255),
	__webpack_require__(29),
	__webpack_require__(81)
], __WEBPACK_AMD_DEFINE_RESULT__ = (function (
	/** uuid */uuid,
	/** util */util,
	/** performance */performance,
	/** Promise */Promise,
	/** Emitter */Emitter
) {
	'use strict';

	Error.prototype.toJSON = function () {
		return {
			name: this.name,
			message: this.message,
			stack: this.stack
		};
	};

	/**
	 * @typedef   {Object}  LoggerMeta
	 * @property  {string}  fn     название метода
	 * @property  {strong}  file   путь к файлу
	 * @property  {number}  line
	 * @property  {number}  column
	 */


	var gid = 1,
		getListeners = Emitter.getListeners,
		encodeURIComponent = window.encodeURIComponent,

		RSPACE = /\s+/,

		index = {},
		entries = []
	;

	function _time(ms) {
		return new Date(ms).toISOString().slice(11, -1);
	}

	function _getPromiseName(entry, added) {
		return '[[' + entry.label.replace(/(:pending|^\[\[|\]\]$)/g, '') + ':' + added + ']]';
	}


	/**
	 * Глобальный объект логирования
	 * @class logger
	 * @constructs logger
	 */
	var logger = /** @lends logger */{
		index: index,
		parentId: 0,
		metaOffset: 0,


		/**
		 * Статус работы логера
		 * @type {boolean}
		 * @methodOf logger
		 */
		disabled: false,


		/**
		 * Массив записей
		 * @type {logger.Entry[]}
		 * @methodOf logger
		 */
		entries: entries,


		/**
		 * Использовать UUID идетификатор в качестве id записи
		 * @type {boolean}
		 * @methodOf logger
		 */
		useUUID: false,


		/**
		 * Генерация UUID
		 * @name logger.uuid
		 * @method
		 * @static
		 * @returns  {string}
		 * @methodOf logger
		 */
		uuid: uuid,


		/**
		 * Перехват ошибок с `window`
		 * @param  {Window}  window
		 * @methodOf logger
		 */
		catchUncaughtException: function (window) {
			window.onerror = function windowOnError(message, url, line, column, err) {
				logger.add('error', {
					type: err && err.type,
					message: message,
					url: url,
					line: line,
					column: column,
					stack: err && err.stack.toString()
				});
				return false;
			};
		},


		/**
		 * Добавить лог-запись
		 * @param  {string}  label  метка
		 * @param  {*}       args   аргументы для логирования
		 * @param  {*}       [parentId]
		 * @param  {LoggerMeta} [meta]
		 * @return {logger.Entry}
		 * @methodOf logger
		 */
		add: function (label, args, parentId, meta) {
			if (logger.disabled) {
				return this;
			}

			logger.metaOffset = 1;
			return this.addEntry('log', label, args, parentId, meta);
		},


		/**
		 * Функция фитрации аргументов
		 * @param  {*}  args
		 * @return {*}
		 * @methodOf logger
		 */
		filterArguments: function (args) {
			return args;
		},


		/**
		 * Создать scope
		 * @param  {string} label
		 * @param  {*} args
		 * @param  {LoggerMeta|number} [meta]  числом можно передать смещение (metaOffset) по stack
		 * @param  {number} [parentId]
		 * @return {logger.Entry}
		 * @methodOf logger
		 */
		scope: function (label, args, meta, parentId) {
			/* jshint eqnull:true */
			if (meta == null) {
				meta = -2;
			}

			/* istanbul ignore next */
			if (meta >= -99) {
				meta = logger.meta(meta);
			}

			logger.metaOffset = 1;
			return this.addEntry('scope', label, args, parentId, meta);
		},


		/**
		 * Добавить запись
		 * @param   {string|Entry}  type        тип записи (scope, log)
		 * @param   {string}        [label]     метка
		 * @param   {*}             [args]      аргументы
		 * @param   {*}             [parentId]  id родителя
		 * @param   {LoggerMeta}    [meta]
		 * @return  {logger.Entry}
		 * @methodOf logger
		 */
		addEntry: function (type, label, args, parentId, meta) {
			logger.metaOffset += 1;

			var entry = type instanceof Entry ? type : new Entry(type, label, args, parentId || this.parentId, meta);

			index[entry.id] = entry;
			entry.idx = entries.push(entry) - 1;

			this._emit();

			return entry;
		},


		/**
		 * Получить «родительскую» запись
		 * @param   {*} id
		 * @param   {string} label
		 * @returns {*}
		 * @methodOf logger
		 */
		closest: function (id, label) {
			var entry;

			id = id.id || id;

			while ((entry = index[id]) && id) {
				id = entry.parentId;

				if (entry.label === label) {
					return entry;
				}
			}

			return null;
		},


		/**
		 * Получить лог-цепочу по id записи
		 * @param   {number}  id
		 * @param   {string}  [glue]
		 * @returns {Array}
		 * @methodOf logger
		 */
		chain: function (id, glue) {
			var log = [], entry;

			while ((entry = index[id]) && id) {
				id = entry.parentId;
				log.push(entry);
			}

			log.reverse();

			if (glue) {
				log = log.map(function (entry) {
					return '[' + entry.id + '] ' + entry.label;
				}).join(glue);
			}

			return log;
		},


		/**
		 * Получить лог-scope
		 * @param   {string}  name   scope-название
		 * @param   {*}       args   аргументы
		 * @param   {*}       [parentId]
		 * @param   {LoggerMeta}  [meta]
		 * @returns {Object}
		 * @methodOf logger
		 */
		getScope: function (name, args, parentId, meta) {
			logger.metaOffset += 1;
			return typeof name === 'string' ? this.addEntry('scope', name, args, parentId, meta) : name;
		},


		/**
		 * Обернуть фунцию или Promise в лог-scope
		 * @param   {string}     name  scope-название
		 * @param   {*}          args  метод или аргументы
		 * @param   {Function}   [fn]  метод
		 * @param   {number}     [parentId]
		 * @param   {LoggerMeta} [meta]
		 * @returns {Function|Promise}
		 * @methodOf logger
		 */
		wrap: function (name, args, fn, parentId, meta) {
			if (arguments.length === 1) {
				fn = name;
				name = index[logger.parentId];
			}
			else if (fn === void 0) {
				fn = args;
				args = void 0;
			}

			if (fn && !fn.__logger__ && !this.disabled) {
				logger.metaOffset += 1;

				meta = meta || logger.meta();

				if (typeof fn === 'function') {
					var wrapper = function () {
						var entry = logger.getScope(name, args, parentId, meta),
							_parentId = logger.parentId,
							retVal;

						logger.parentId = entry.id;
						logger.metaOffset += 1;

						retVal = logger.wrap(entry, fn.apply(this, arguments));

						logger.parentId = _parentId;

						return retVal;
					};

					fn.__logger__ = true;
					wrapper.__logger__ = true;

					return wrapper;
				}
				else if (fn.then) {
					logger.getScope(name, args, null, meta).wrap(fn);
				}
			}

			logger.metaOffset = 0;

			return fn;
		},


		/**
		 * Выполнить метод в лог-конексте
		 * @param   {string} label
		 * @param   {*} args
		 * @param   {Function} fn
		 * @returns {*}
		 * @methodOf logger
		 */
		call: function (label, args, fn) {
			logger.metaOffset += 1;
			return this.wrap(label, args, fn)();
		},


		/**
		 * Сбросить лог
		 * @methodOf logger
		 */
		reset: function () {
			gid = 1;

			this.index = index = {};
			this.entries = entries = [];
			this.parentId = 0;
		},


		/**
		 * Вывод лога в консоль
		 * @param   {boolean} [ret]  вернуть лог строкой
		 * @returns {string|undefined}
		 * @methodOf logger
		 */
		print: function (ret) {
			var groups = {},
				depends = {},
				retLog = '';


			entries.forEach(function (entry) {
				var id = entry.parentId;
				(groups[id] = groups[id] || []).push(entry);
			});


			(function _print(id, indent) {
				var entries = groups[id] || [],
					i = 0,
					n = entries.length,
					entry,
					log,
					args
				;

				for (; i < n; i++) {
					entry = entries[i];
					args = entry.args;
					log = ('[' + _time(entry.ts) + '] ' + entry.label);

					if (ret) {
						log += args ? ': ' + JSON.stringify(args) : '';
					}

					/* istanbul ignore else */
					if (groups[entry.id]) {

						/* istanbul ignore else */
						if (ret) {
							retLog += indent + log + '\n';
							_print(entry.id, '  ' + indent);
						}
						else {
							console.group(log);
							args && console.log('[details] ', args);
							_print(entry.id);
							console.groupEnd();
						}
					}
					else if (ret) {
						retLog += indent + log + '\n';
					}
					else {
						console.log(log, args);
					}
				}
			})(0, '');


			return ret && retLog;
		},


		/**
		 * Подписаться на добавление записи
		 * @param   {string}   labels
		 * @param   {Function} fn
		 * @returns {logger}
		 * @methodOf logger
		 */
		on: function (labels, fn) {
			labels = labels.trim().split(RSPACE);

			var i = labels.length, label;

			while (i--) {
				label = labels[i].split(':');
				getListeners(this, label[1] || label[0]).push({
					fn: fn,
					label: label[1] || label[0],
					parent: label[1] && label[0]
				});
			}

			return this;
		},


		/**
		 * Отписаться от добавление записи
		 * @param   {string}   labels
		 * @param   {Function} fn
		 * @returns {logger}
		 * @methodOf logger
		 */
		off: function (labels, fn) {
			labels = labels.trim().split(RSPACE);

			var i = labels.length, label, list, j, handle;

			while (i--) {
				label = labels[i].split(':');
				list = getListeners(this, label[1] || label[0]);
				j = list.length;

				while (j--) {
					handle = list[j];

					if (handle.fn === fn && (handle.parent === (label[1] && label[0]))) {
						list.splice(j, 1);
					}
				}
			}

			return this;
		},


		/**
		 * Испускаем события
		 * @private
		 * @methodOf logger
		 */
		_emit: function () {
			var entry,
				parentEntry,
				list,
				e = entries.length,
				i,
				handle
			;

			while (e--) {
				entry = entries[e];

				if (!entry.emitted) {
					entry.emitted = true;
					list = getListeners(this, entry.label);
					i = list.length;

					while (i--) {
						handle = list[i];

						if (handle.parent) {
							parentEntry = this.closest(entry.id, handle.parent);

							/* istanbul ignore else */
							if (parentEntry) {
								handle.fn(parentEntry, entry);
							}
						}
						else {
							handle.fn(entry);
						}
					}
				}
			}
		},


		last: function () {
			return entries[entries.length - 1];
		},

		/**
		 * Получить текущую мета информацию
		 * @param  {number} [offset]
		 * @return {LoggerMeta}
		 * @methodOf logger
		 */
		meta: function () {
			return {fn: 'unknown', file: 'unknown', line: 0, column: 0};
		},

		/**
		 * Разобрать строчку из стека
		 * @return {LoggerMeta}
		 * @methodOf logger
		 */
		parseStackRow: function (value) {
			value += '';

			var match = value.match(/at\s+([^\s]+)(?:.*?)\(((?:http|file|\/)[^)]+:\d+)\)/),
				file;

			/* istanbul ignore next */
			if (!match) {
				match = value.match(/at\s+(.+)/);

				if (!match) {
					match = value.match(/^(.*?)(?:\/<)*@(.*?)$/) || value.match(/^()(https?:\/\/.+)/);
				} else {
					match[0] = '<anonymous>';
					match.unshift('');
				}
			}

			/* istanbul ignore next */
			if (match) {
				file = match[2].match(/^(.*?):(\d+)(?::(\d+))?$/) || [];
				match = {
					fn: (match[1] || '<anonymous>').trim(),
					file: file[1],
					line: file[2]|0,
					column: file[3]|0
				};
			}
			else {
				match = null;
			}

			return match;
		},


		/**
		 * Сериализовать лог
		 * @return {string}
		 * @methodOf logger
		 */
		serialize: function () {
			return JSON.stringify(entries);
		},


		/**
		 * Отправить на почту
		 * @param {string} email
		 * @methodOf logger
		 */
		mailTo: /* istanbul ignore next */ function (email) {
			var el = document.createElement('a');
			el.href = 'mailto:' + email
					+ '?subject=' + encodeURIComponent('[logger] ' + new Date())
					+ '&body=' + encodeURIComponent(this.serialize());
			el.innerHTML = 'send';
			el.click();
		}
	};


	/**
	 * Описание записи лога
	 * @class  logger.Entry
	 * @methodOf logger
	 * @param  {string}  type
	 * @param  {string}  [label]
	 * @param  {*}       [args]
	 * @param  {*}       [parentId]
	 */
	function Entry(type, label, args, parentId, meta) {
		/**
		 * Идетификатор записи
		 * @member {*} logger.Entry#id
		 */
		this.id = (args && args.uuid) || /* istanbul ignore next */(logger.useUUID ? uuid() : gid++);


		/**
		 * Относительное время добавления
		 * @member {number} logger.Entry#ts
		 */
		this.ts = performance.now();


		/**
		 * Тип записи
		 * @member {string} logger.Entry#type
		 */
		this.type = type;


		/**
		 * Метка записи
		 * @member {string} logger.Entry#label
		 */
		this.label = label + '';


		try {
			args = util.cloneJSON(logger.filterArguments(args));
		} catch (err) {
			args = err;
		}


		/**
		 * Аргумерты логирования
		 * @member {*} logger.Entry#args
		 */
		this.args = args;


		/**
		 * Id родительской записи
		 * @member {*} logger.Entry#parentId
		 */
		this.parentId = parentId;


		/**
		 * Список id связанных записей
		 * @member {Array} logger.Entry#linked
		 */
		this.linked = [];


		/**
		 * Мета информация (строка, файл, метод и т.п.)
		 * @type {LoggerMeta}
		 */
		logger.metaOffset += 1;
		this.meta = meta || logger.meta();
		logger.metaOffset = 0;
	}


	Entry.fn = Entry.prototype = /** @lends logger.Entry.prototype */ {
		constructor: Entry,


		/**
		 * Добавить связанную запись
		 * @param  {string}  label
		 * @param  {*}       [args]
		 * @return {logger.Entry}
		 */
		add: function (label, args) {
			return logger.add(label, args, this.id, this.meta);
		},


		/**
		 * Выполнить метод в лог-конексте
		 * @param  {string|Function}   label
		 * @param  {*}        args
		 * @param  {Function} fn
		 * @return {*}
		 */
		call: function (label, args, fn) {
			if (typeof label === 'function') {
				var parentId = logger.parentId,
					retVal;

				logger.parentId = this.id;
				retVal = this.wrap(args ? label.apply(null, args) : label());
				logger.parentId = parentId;

				return retVal;
			}

			return logger.wrap(label, args, fn, this.id, this.meta)();
		},


		wrap: function (obj) {
			if (typeof obj === 'function') {
				return logger.wrap(this, obj);
			}
			else if (obj && !obj.__logger__ && obj.then) {
				var then = obj.then,
					done = obj.done,
					fail = obj.fail,
					always = obj.always,
					logScope = this;


				obj.__logger__ = logScope;


				/* jshint expr:true */
				done && (obj.done = function (callback) {
					var noLog = obj.__noLog,
						meta = logger.meta(-1 - (obj.metaOffset|0));

					return done.call(obj, function () {
						(noLog
							? obj.__logger__
							: logger.addEntry('scope', _getPromiseName(logScope, 'done'), null, obj.__logger__.id, meta)
						).call(callback, arguments);
					});
				});


				/* jshint expr:true */
				fail && (obj.fail = function (callback) {
					var noLog = obj.__noLog,
						meta = logger.meta(-1 - (obj.metaOffset|0));

					return fail.call(obj, function () {
						(noLog
							? obj.__logger__
							: logger.addEntry('scope', _getPromiseName(logScope, 'fail'), null, obj.__logger__.id, meta)
						).call(callback, arguments);
					});
				});


				/* jshint expr:true */
				always && (obj.always = function (callback) {
					var meta = logger.meta(-1 - (obj.metaOffset|0)),
						retVal;

					obj.__noLog = true;

					retVal = always.call(obj, function () {
						logger
							.addEntry('scope', _getPromiseName(logScope, 'always'), null, obj.__logger__.id, meta)
								.call(callback, arguments);
					});

					obj.__noLog = false;

					return retVal;
				});


				obj['catch'] = function (callback) {
					return obj.then(null, callback, true);
				};


				obj.then = function (onResolved, onRejected, isCatch) {
					if (obj.__noLog) {
						return then.call(obj, onResolved, onRejected);
					}

					var meta = logger.meta(-1 - (obj.metaOffset|0) - !!isCatch),
						label = isCatch ? 'catch' : 'then',
						scope = new Entry('scope', '', null, logScope.id, meta);

					function resolved() {
						scope.label = _getPromiseName(logScope, label + ':resolved');
						logger.addEntry(scope);

						return scope.call(onResolved, arguments);
					}

					function rejected() {
						scope.label = _getPromiseName(logScope, label + ':rejected');
						logger.addEntry(scope);

						return scope.call(onRejected, arguments);
					}

					return scope.wrap(then.call(obj, onResolved ? resolved : null, onRejected ? rejected : null));
				};
			}

			return obj;
		},


		/**
		 * Создать связанный scope
		 * @param  {string} label
		 * @param  {*} [args]
		 * @param  {*} [meta]
		 */
		scope: function (label, args, meta) {
			return logger.scope(label, args, meta || -3, this.id);
		},


		/**
		 * Получить цепочку записей
		 * @param  {string} [glue]
		 * @returns {Array|string}
		 */
		chain: function (glue) {
			return logger.chain(this.id, glue);
		},


		pluck: function (key) {
			return this.chain().map(function (entry) {
				return entry[key];
			});
		},


		/**
		 * Получить родителя
		 * @return {logger.Entry}
		 */
		parent: function () {
			return index[this.parentId];
		},


		/**
		 * Получить JSON-объект
		 * @returns {Object}
		 */
		toJSON: function () {
			return {
				id: this.id,
				dependId: this.dependId,
				linked: this.linked,
				type: this.type,
				label: this.label,
				args: this.args,
				meta: this.meta
			};
		}
	};


	Function.prototype.logger = function (label, args) {
		return logger.wrap(label, args, this, null, logger.meta(-1));
	};


	// Export Entry
	logger.Entry = Entry;


	/**
	 * Логируемый setTimeout
	 * @param  {string}    name
	 * @param  {function}  callback
	 * @param  {number}    ms
	 */
	/* istanbul ignore next */
	window.setTimeoutLog = function (name, callback, ms) {};


	/**
	 * Логируемый setIntervalLog
	 * @param  {string}    name
	 * @param  {function}  callback
	 * @param  {number}    ms
	 */
	/* istanbul ignore next */
	window.setIntervalLog = function (name, callback, ms) {};


	//['setTimeout', 'setInterval'].forEach(function (name) {
	//	var method = window[name];
	//
	//	window[name + 'Log'] = function (label, callback, ms) {
	//		if (typeof callback !== 'function') {
	//			ms = callback;
	//			callback = label;
	//			label = name;
	//		}
	//
	//		var scope = logger.scope('~' + label);
	//		return method(function () {
	//			scope.call(callback);
	//		}, ms);
	//	};
	//});



	Promise.Log = function (name, executor) {
		if (executor) {
			name = '[[' + name + ']]';
		}
		else {
			executor = name;
			name = '[[promise]]';
		}

		return logger.scope(name, null, -2).call(function () {
			return new Promise(executor);
		});
	};


	// Export
	logger.version = '0.6.1';

	/* jshint boss:true */
	return (window.octolog = window.logger = logger);
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 81:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;/**
 * @author RubaXa <trash@rubaxa.org>
 * @license MIT
 */
(function () {
	"use strict";

	var RDASH = /-/g,
		RSPACE = /\s+/,

		r_camelCase = /-(.)/g,
		camelCase = function (_, chr) {
			return chr.toUpperCase();
		},

		hasOwn = ({}).hasOwnProperty,
		emptyArray = []
	;



	/**
	 * Получить список слушателей
	 * @param    {Object}  target
	 * @param    {string}  name
	 * @returns  {Array}
	 * @memberOf Emitter
	 */
	function getListeners(target, name) {
		var list = target.__emList;

		name = name.toLowerCase().replace(RDASH, '');

		if (list === void 0) {
			list = target.__emList = {};
			list[name] = [];
		}
		else if (list[name] === void 0) {
			list[name] = [];
		}

		return list[name];
	}



	/**
	 * Излучатель событий
	 * @class Emitter
	 * @constructs Emitter
	 */
	var Emitter = function () {
	};
	Emitter.fn = Emitter.prototype = /** @lends Emitter# */ {
		constructor: Emitter,


		/**
		 * Прикрепить обработчик для одного или нескольких событий, поддерживается `handleEvent`
		 * @param   {string}    events  одно или несколько событий, разделенных пробелом
		 * @param   {Function}  fn      функция обработчик
		 * @returns {Emitter}
		 */
		on: function (events, fn) {
			events = events.split(RSPACE);

			var n = events.length, list;

			while (n--) {
				list = getListeners(this, events[n]);
				list.push(fn);
			}

			return this;
		},


		/**
		 * Удалить обработчик для одного или нескольких событий
		 * @param   {string}    [events]  одно или несколько событий, разделенных пробелом
		 * @param   {Function}  [fn]      функция обработчик, если не передать, будут отвязаны все обработчики
		 * @returns {Emitter}
		 */
		off: function (events, fn) {
			if (events === void 0) {
				this.__emList = events;
			}
			else {
				events = events.split(RSPACE);

				var n = events.length;

				while (n--) {
					var list = getListeners(this, events[n]), i = list.length, idx = -1;

					if (arguments.length === 1) {
						list.splice(0, 1e5); // dirty hack
					} else {
						if (list.indexOf) {
							idx = list.indexOf(fn);
						} else { // old browsers
							while (i--) {
								/* istanbul ignore else */
								if (list[i] === fn) {
									idx = i;
									break;
								}
							}
						}

						if (idx !== -1) {
							list.splice(idx, 1);
						}
					}
				}
			}

			return this;
		},


		/**
		 * Прикрепить обработчик события, который выполняется единожды
		 * @param   {string}    events  событие или список
		 * @param   {Function}  fn      функция обработчик
		 * @returns {Emitter}
		 */
		one: function (events, fn) {
			var proxy = function () {
				this.off(events, proxy);
				return fn.apply(this, arguments);
			};

			return this.on(events, proxy);
		},


		/**
		 * Распространить событие
		 * @param   {string}  type    тип события
		 * @param   {Array}   [args]  аргумент или массив аргументов
		 * @returns {*}
		 */
		emit: function (type, args) {
			var list = getListeners(this, type),
				i = list.length,
				fn,
				ctx,
				tmp,
				retVal,
				argsLength
			;

			type = 'on' + type.charAt(0).toUpperCase() + type.substr(1);

			if (type.indexOf('-') > -1) {
				type = type.replace(r_camelCase, camelCase);
			}

			if (typeof this[type] === 'function') {
				retVal = this[type].apply(this, [].concat(args));
			}

			if (i > 0) {
				args = args === void 0 ? emptyArray : [].concat(args);
				argsLength = args.length;

				while (i--) {
					fn = list[i];
					ctx = this;

					/* istanbul ignore else */
					if (fn !== void 0) {
						if (fn.handleEvent !== void 0) {
							ctx = fn;
							fn = fn.handleEvent;
						}

						if (argsLength === 0) {
							tmp = fn.call(ctx);
						}
						else if (argsLength === 1) {
							tmp = fn.call(ctx, args[0]);
						}
						else if (argsLength === 2) {
							tmp = fn.call(ctx, args[0], args[1]);
						}
						else {
							tmp = fn.apply(ctx, args);
						}

						if (tmp !== void 0) {
							retVal = tmp;
						}
					}
				}
			}

			return retVal;
		},


		/**
		 * Распространить `Emitter.Event`
		 * @param   {string}  type    тип события
		 * @param   {Array}   [args]  аргумент или массив аргументов
		 * @returns {Emitter}
		 */
		trigger: function (type, args) {
			var evt = new Event(type);
			evt.target = evt.target || this;
			evt.result = this.emit(type.type || type, [evt].concat(args));

			return this;
		}
	};



	/**
	 * Событие
	 * @class Emitter.Event
	 * @constructs Emitter.Event
	 * @param   {string|Object|Event}  type  тип события
	 * @returns {Emitter.Event}
	 */
	function Event(type) {
		if (type instanceof Event) {
			return type;
		}

		if (type.type) {
			for (var key in type) {
				/* istanbul ignore else */
				if (hasOwn.call(type, key)) {
					this[key] = type[key];
				}
			}

			type = type.type;
		}

		this.type = type.toLowerCase().replace(RDASH, '');
	}

	Event.fn = Event.prototype = /** @lends Emitter.Event# */ {
		constructor: Event,


		/** @type {boolean} */
		defaultPrevented: false,


		/** @type {boolean} */
		propagationStopped: false,


		/**
		 * Позволяет определить, было ли отменено действие по умолчанию
		 * @returns {boolean}
		 */
		isDefaultPrevented: function () {
			return this.defaultPrevented;
		},


		/**
		 * Отменить действие по умолчанию
		 */
		preventDefault: function () {
			this.defaultPrevented = true;
		},


		/**
		 * Остановить продвижение события
		 */
		stopPropagation: function () {
			this.propagationStopped = true;
		},


		/**
		 * Позволяет определить, было ли отменено продвижение события
		 * @return {boolean}
		 */
		isPropagationStopped: function () {
			return this.propagationStopped;
		}
	};


	/**
	 * Подмешать методы к объекту
	 * @static
	 * @memberof Emitter
	 * @param   {Object}  target    цель
	 * @returns {Object}
	 */
	Emitter.apply = function (target) {
		target.on = Emitter.fn.on;
		target.off = Emitter.fn.off;
		target.one = Emitter.fn.one;
		target.emit = Emitter.fn.emit;
		target.trigger = Emitter.fn.trigger;
		return target;
	};


	// Версия модуля
	Emitter.version = "0.3.1";


	// exports
	Emitter.Event = Event;
	Emitter.getListeners = getListeners;


	if (true) {
		!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
			return Emitter;
		}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
	} else if (typeof module != "undefined" && module.exports) {
		module.exports = Emitter;
	} else {
		window.Emitter = Emitter;
	}
})();


/***/ }),

/***/ 879:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = (function (require) {
	'use strict';

	var Action = __webpack_require__(880),
		Promise = __webpack_require__(29),
		RPC = __webpack_require__(127),
		utils = __webpack_require__(97);

	/**
	 * Действие "Восстановление телефона"
	 * @class mail.PasswordRecovery
	 * @constructs mail.PasswordRecovery
	 * @extends Action
	 */
	var PasswordRecovery = Action.extend(/** @lends mail.PasswordRecovery# */{

		/**
		 * @typedef {Object} PasswordRecoveryParams - входные параметры действия
		 * @property {string} phase - этап восстановления пароля (опции, отправка токена, проверка токена)
		 * @property {string} email - адрес, для которого мы восстанавливаем
		 * @property {string} by - фактор на основании которого будет сгенерирован токен
		 * @property {number|null} address - номер телефона в формате 712312312313
		 * @property {number|null} index - порядковый номер телефона среди телефонов для пользователя
		 * @property {string|null} token - токен, который необходимо подвтредить для восстановления
		 * @property {string|null} value - значение, которым пользователь подтверждает токен
		 * @property {string|null} captcha - значение капчи, если token/send ее затребовал
		 * @property {string|null} restoreToken - токен для восстановления проаля
		 * @property {string|null} password - новый пароль пользователя
		 */

		/**
		 * Структура токена для отправки SMS
		 */
		regToken: {
			target: 'user/password/restore',
			format: 'default'
		},

		urls: {
			options: 'user/password/restore',
			send: 'tokens/send',
			check: 'tokens/check',
			changePassword: 'user/password/restore/confirm'
		},

		/**
		 * Описание обязательных полей для каждого метода
		 */
		required: {
			getOptions: ['email'],
			sendToken: ['by', 'token'],
			checkToken: ['by', 'token', 'value'],
			changePassword: ['restoreToken', 'password']
		},

		/**
		 * Метод обрабатывает ответ от сервера и возвращает его в нужно формате
		 * @param {object} res - ответ
		 * @private
		 * @returns {object}
		 */
		_processResponse: function (res) {
			return res.body;
		},

		/**
		 * Метод получает опции востановления пароля
		 * @param {PasswordRecoveryParams} params
		 * @private
		 */
		_getOptions: function (params) {
			return RPC.call(this.urls.options, { email: params.email }).then(this._processResponse.bind(this));
		},

		/**
		 * Метод отправляет токен пользователю на телефон
		 * @param {PasswordRecoveryParams} params
		 * @private
		 */
		_sendToken: function (params) {
			var regToken = this.regToken;

			regToken.transport = params.by;
			regToken.id = params.token;
			regToken.address = params.address;
			regToken.index = params.index;

			return RPC.call(this.urls.send, {
				email: params.email,
				capcha: params.captcha,
				reg_token: JSON.stringify(regToken)
			}).then(this._processResponse.bind(this));
		},

		/**
		 * Метод проверяет токен пользователя
		 * @param {PasswordRecoveryParams} params
		 * @private
		 */
		_checkToken: function (params) {
			var regToken = this.regToken;

			regToken.transport = params.by;
			regToken.id = params.token;
			regToken.value = params.value;

			if (params.captcha) {
				regToken.captcha = params.captcha;
			}

			return RPC.call(this.urls.check, {
				email: params.email,
				reg_token: JSON.stringify(regToken)
			}).then(this._processResponse.bind(this));
		},

		/**
		 * Метод меняте пароль пользователя
		 * @param {PasswordRecoveryParams} params
		 * @private
		 */
		_changePassword: function (params) {
			var options = {
				email: params.email,
				reg_token_check: params.restoreToken,
				password: params.password
			};

			if (params.redirectUri) {
				options.redirect_uri = params.redirectUri;
			}

			return RPC.call(this.urls.changePassword, options).then(this._processResponse.bind(this));
		},

		/**
		 * Метод валидирует переданные параметры
		 * @param params
		 * @return {Object|null} - если есть ошибки, то вернет спиоск {email: 'required' ... }
		 * @private
		 */
		_validate: function (params) {
			var errors = {},
				required = JSON.parse(JSON.stringify(this.required[params.method])) || [];

			required = required.filter(function (key) {
				return !params.hasOwnProperty(key);
			});

			if (!required.length) {
				return null;
			}

			required.forEach(function (key) {
				errors[key] = 'required';
			});

			return errors;
		},

		/**
		 * Логика действия "Восстановить"
		 * @param {PasswordRecoveryParams} params
		 * @returns {Promise}
		 */
		operation: function operation(params) {
			var errors,
				method;

			if (!params.method) {
				return Promise.reject({method: 'required'});
			}

			method = this['_' + params.method];

			if (typeof method !== 'function') {
				return Promise.reject({method: 'invalid'});
			}

			errors = this._validate(params);

			if (errors) {
				return Promise.reject(errors);
			}

			return method.call(this, params);
		}

	});

	/**
	 * Этапы восстановления пароля
	 * @type {{OPTIONS: number, SEND: number, CHECK: number}}
	 */
	PasswordRecovery.methods =  {
		OPTIONS: 'getOptions', // получить опции восстановления
		SEND: 'sendToken', // отправить токен
		CHECK: 'checkToken', // проверить отправленный токен
		CHANGE_PASSWORD: 'changePassword' // изменить пароль
	};

	/**
	 * Виды транспорта, через которые можно доставить и проверить токен
	 * @type {{PHONE: string}}
	 */
	PasswordRecovery.transports = {
		PHONE: 'phone'
	};

	// Export
	Action.register('mail.PasswordRecovery', PasswordRecovery);
	PasswordRecovery.version = '0.2.1';
	return PasswordRecovery;
}).call(exports, __webpack_require__, exports, module),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 880:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	__webpack_require__(73),
	__webpack_require__(217),
	__webpack_require__(29),
	__webpack_require__(81),
	__webpack_require__(881),
	__webpack_require__(361)
], __WEBPACK_AMD_DEFINE_RESULT__ = (function (
	/** logger */logger,
	/** inherit */inherit,
	/** Promise */Promise,
	/** Emitter */Emitter,
	/** Model */Model,
	/** Model.List */List
) {
	'use strict';


	// Получить параметры для логирования
	var _getLogParams = function (value) {
		var i,
			result = value;

		if (value && typeof value === 'object') {
			/* istanbul ignore next */
			if (value.toLogJSON) {
				result = value.toLogJSON();
			}
			else if (value instanceof Model) {
				result = value.id;
			}
			else if (value instanceof List) {
				result = value.pluck('id');
			}
			else if (Array.isArray(value)) {
				i = value.length;
				result = [];

				while (i--) {
					result[i] = _getLogParams(value[i]);
				}
			}
			else {
				result = {};
				Object.keys(value).forEach(function (key) {
					result[key] = _getLogParams(value[key]);
				});
			}
		}

		return result;
	};



	/**
	 * Действие.
	 * @abstract
	 * @class Action
	 * @constructs Action
	 * @extends Emitter
	 * @returns {Promise}
	 */
	var Action = inherit(Emitter, /** @lends Action# */{
		/**
		 * Имя действия
		 * @type {string}
		 */
		name: 'abstract',


		/**
		 * Конструктор
		 * @param  {Object}  params   параметры
		 * @param  {Object}  options  опции
		 * @constructor
		 */
		constructor: function (params, options) {
			/**
			 * Параметры
			 * @type {Object}
			 */
			this.params = params;


			/**
			 * Опции
			 * @type {Object}
			 */
			this.options = options;


			/**
			 * Подготовленные данные
			 * @type {boolean}
			 * @private
			 */
			this._data;


			/**
			 * Статус команды «в работе≠
			 * @type {boolean}
			 */
			this.pending = false;


			/**
			 * Статус выполнения действия
			 * @type {*}
			 */
			this.status;


			/**
			 * Ошибка при выполнении
			 * @type {*}
			 */
			this.error = null;


			/**
			 * Результат успешного выполнения
			 * @type {*}
			 */
			this.result = null;


			return options.logScope.call(this._execute.bind(this));
		},


		/**
		 * Выполнить действие
		 * @private
		 * @return {Promise}
		 */
		_execute: function () {
			var _this = this,
				params = _this.params,
				options = _this.options,
				logScope = options.logScope;


			// «Поехали!»
			_this.pending = true;

			(!options.silent) && Action.trigger('start', [_this, params, options]);

			return new Promise(function (resolve) {
				// Безопасное выполнение внутри `Promise`
				resolve(_this.prepare(params, options));
			}.logger(_this.name + '.prepare')).then(
				// Данные успешно подготовлены
				function (data) {
					if (data === null) {
						// нужно выходить
						logScope.add('operation:exit');
						_this._resolve('done', data);

						return _this;
					}

					if (data === void 0) {
						// используем исходные данные
						data = params;
					}

					_this._data = data;

					// «Операция!»
					return new Promise(function (resolve) {
						_this.trigger('operation', [data, params, options]);
						resolve(_this.operation(data, params, options));
					}.logger(_this.name + '.operation')).then(
						// Это успех!
						function (result) {
							logScope.add('operation:done');
							_this._resolve('done', result);

							return _this;
						},

						// Ошибка, нужно откатывать
						function (error) {
							logScope.add('operation:fail', error);

							_this.rollback();
							_this._resolve('fail', error);

							return Promise.reject(_this);
						}
					);
				},

				// Ошибка при подготовке данных
				function (error) {
					logScope.add('prepare:fail', error);
					_this._resolve('fail', error);

					return Promise.reject(_this);
				}
			);
		},


		/**
		 * Отмена действия
		 * @public
		 * @return {Promise}
		 */
		undo: function () {
			var _this = this,
				args = [_this._data, _this.params, _this.options],
				promise = _this._undoPromise,
				logScope;

			if (!promise) {
				logScope = logger.scope('[[' + _this.name + '.undo]]');

				_this._undoPromise = promise = new Promise(logScope.wrap(function (resolve) {
					_this.trigger.apply(_this, ['undo'].concat(args));
					(!_this.options.silent) && Action.trigger.apply(_this, ['undo', _this].concat(args));

					resolve(_this.undoOperation.apply(_this, args));
				}));

				promise.then(
					_this._resolveUndo.bind(_this, logScope, true),
					_this._resolveUndo.bind(_this, logScope, false)
				);
			}

			return promise;
		},


		/**
		 * Подготовить данные для выполнения действия.
		 * Если вернуть `null`, действие сразу перейдет в состояние `resolved` без выполнения `operation`.
		 * @protected
		 * @param  {Object}  params
		 * @param  {Object}  options
		 */
		prepare: function (params, options) {
		},


		/**
		 * Выполняемая операция, если `prepare` не вернул `null`
		 * @protected
		 * @param  {*}       data  данные подготовленные в `prepare` (или теже `params`)
		 * @param  {object}  params
		 * @param  {object}  options
		 */
		operation: function (data, params, options) {
		},


		/**
		 * Обратная операция
		 * @protected
		 * @param  {*}       data
		 * @param  {Object}  params
		 * @param  {Object}  options
		 */
		undoOperation: function (data, params, options) {
			logger.add('NOT_IMPLEMENTED');
			throw 'NOT_IMPLEMENTED';
		},


		/**
		 * Опредация откатки изменений
		 * @protected
		 * @param  {*}       data
		 * @param  {Object}  params
		 * @param  {Object}  options
		 */
		rollbackOperation: function (data, params, options) {
			logger.add('NOT_IMPLEMENTED');
		},


		/**
		 * Откатываем действие при ошибке (не путать с `undo`)
		 * @public
		 */
		rollback: function () {
			var _this = this,
				options = _this.options;

			options.logScope.call('[[' + _this.name + '.rollback]]', function () {
				try {
					_this.rollbackOperation(_this._data, _this.params, options);
				} catch (err) {
					logger.add('error', err);
				}
			});
		},


		/**
		 * Разрешить действие
		 * @private
		 * @param  {string} status
		 * @param  {*}      result
		 */
		_resolve: function (status, result) {
			this.pending = false;
			this.status = status;
			this[status == 'done' ? 'result' : 'error'] = result;

			this.trigger(status, result);
			this.trigger('complete', [this, status, result]);

			if (!this.options.silent) {
				Action.trigger(status, [this, result]);
				Action.trigger('complete', [this, status, result]);
			}
		},


		/**
		 * Разрешить аннуляцию действия
		 * @private
		 * @param  {logger.Entry} undoLogScope
		 * @param  {boolean}      status
		 * @param  {*}            result
		 */
		_resolveUndo: function (undoLogScope, status, result) {
			var args = [this, status, result];

			undoLogScope.add('undo:' + (status ? 'done' : 'fail'), status ? void 0 : result);

			this.trigger('undo:complete', args);
			(!this.options.silent) && Action.trigger('undo:complete', args);
		},


		/**
		 * Излучатель события
		 * @override
		 * @param {string} type
		 * @param {Array}  args
		 */
		emit: function (type, args) {
			var options = this.options;

			if (options['on' + type]) {
				options['on' + type].apply(this, args);
			}

			return Emitter.fn.emit.apply(this, arguments);
		}
	});


	// Подмешиваем события
	Emitter.apply(Action);


	/**
	 * Регистрация действия
	 * @static
	 * @param  {string}  name       название действия
	 * @param  {Action}  NewAction  класс действия
	 * @memberOf Action
	 */
	Action.register = function (name, NewAction) {
		this[name] = NewAction;

		// Экспортируем имя действия
		NewAction.prototype.name = name;

		// Статический метод для выполнения действия
		NewAction.execute = function (params, options) {
			return Action.execute(name, params, options);
		};

		return NewAction;
	};


	/**
	 * Выполнить действие.
	 * @static
	 * @param   {string}  name
	 * @param   {Object}  [params]
	 * @param   {Object}  [options]
	 * @return  {Promise}
	 * @memberOf Action
	 */
	Action.execute = function (name, params, options) {
		/** @type {Action}*/
		var Target = this[name],
			logScope = logger.scope('[[Action:' + name + ']]', _getLogParams(params)),
			error = 'ACTION_NOT_FOUND:' + name;

		if (!Target) {
			logScope.add(error);
		}

		options = options || {};
		options.logScope = logScope;

		return Target ? new Target(params, options) : Promise.reject(error);
	};


	/**
	 * Бросаем событие с ожиданием Promise,
	 * для вызова UI (диалогов, форм) в процессе выполнения действия.
	 * @param  {string}  type
	 * @param  {*}       [args]
	 * @return {Promise}
	 */
	Action.waitFor = function waitFor(type, args) {
		var evt = new Emitter.Event(type),
			promise;

		// защищаемся от кривого аргумента; не меняем аргументы; первым параметром - текущий экземпляр Action
		Action.trigger(evt, [].concat(this, args));

		/* jshint eqnull:true */
		if (evt.result != null) {
			if (evt.result.then) { // если приехал Promise (или что то похожее) - возвращаем его
				promise = evt.result;
			} else {
				promise = Promise.cast(evt.result);
			}
		}
		else { // если нет - всё пропало, отказать!
			promise = Promise.reject();
		}

		return promise;
	};


	// Export
	Action.version = '0.2.0';
	return Action;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 881:
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [
	__webpack_require__(217),
	__webpack_require__(73),
	__webpack_require__(256),
	__webpack_require__(29),
	__webpack_require__(81),
	__webpack_require__(361),
	__webpack_require__(257)
], __WEBPACK_AMD_DEFINE_RESULT__ = (function (
	/** function */inherit,
	/** logger */logger,
	/** request */request,
	/** Promise */Promise,
	/** Emitter */Emitter,
	/** Model.List */List,
	/** config */config
) {
	"use strict";

	var Event = Emitter.Event;
	var _toString = {}.toString;
	var _stringifyJSON = JSON.stringify;
	var _type = function (val) {
		return val === null ? 'null' : _toString.call(val).toLowerCase().slice(8, -1);
	};



	// Установка аттрибутов согласно схеме
	var _setAttr = function (model, absKey, attr, newValue, changed, changes) {
		var idx = absKey.lastIndexOf('.'),
			attributes = model.attributes,
			_attributes = model._attributes,
			value = attributes[attr];

		if (idx !== -1) {
			attr = absKey.substr(idx + 1);
			value = model.get(absKey);
		}

		if (model.nested[absKey] !== void 0) {
			// Обновление вложенной модели или списка
			model.get(absKey).set(newValue, {reset: true});
		}
		else if (model.scheme[absKey] === 'set') {
			for (var key in newValue) {
				_setAttr(model, absKey + '.' + key, key, newValue[key], changed, changes);
			}
		}
		else if (_notEqual(value, newValue)) {
			if (absKey !== attr) {
				var chain = absKey.split('.'),
					length = chain.length,
					i = 0,
					n = length - 1,
					part,
					dottedKey;

				for (; i < n; i++) {
					part = chain[i];

					if (attributes[part] === void 0) {
						attributes[part] = {};
					}

					if (_attributes[part] === void 0) {
						_attributes[part] = {};
					}

					if (changed[part] === void 0) {
						changed[part] = {};
					}

					attributes = attributes[part];
					_attributes = _attributes[part];
					changed = changed[part];

					if (attributes.set !== void 0) {
						// Модель или Список
						attributes.set(chain.slice(i + 1).join('.'), newValue, {reset: true});
						return;
					}

					dottedKey = dottedKey === void 0 ? part : dottedKey + '.' + part;

					if (changes.byKey[dottedKey] === void 0) {
						changes.byKey[dottedKey] = attributes;
						changes.push(dottedKey);
					}
				}
			}

			_attributes[attr] = value;
			changed[attr] = newValue;
			attributes[attr] = newValue;

			changes.push(absKey);
			changes.byKey[absKey] = newValue;
		}
	};

	function _setNestedChanges(/** Array */nestendChanges, /** Array */changes, /** Object */changed) {
		var i = nestendChanges.length;

		while (i--) {
			var item = nestendChanges[i];
			var attr = item.attr;

			changes.push(attr);
			changes.byKey[attr] = item.changes;

			if (attr.indexOf('.') > -1) {
				var chain = attr.split('.');
				var endIdx = chain.length - 1;
				var _changed = changed;

				for (var c = 0; c < endIdx; c++) {
					if (_changed[chain[c]] === void 0) {
						_changed = _changed[chain[c]] = {};
					} else {
						_changed = _changed[chain[c]];
					}
				}

				_changed[chain[endIdx]] = item.changed;
			} else {
				changed[attr] = item.changed;
			}

			var innerChanges = item.changes;
			for (var j = 0, jn = innerChanges.length; j < jn; j++) {
				var innerAttr = attr + '.' + innerChanges[j];
				changes.push(innerAttr);
				changes.byKey[innerAttr] = innerChanges.byKey[innerChanges[j]];
			}
		}
	}


	/**
	 * Локальный идентификтор модели
	 * @type {number}
	 */
	var cid = 1;


	/**
	 * Быстрое клонирование
	 * @param   {*}  obj
	 * @param   {boolean} [isObject]
	 * @returns {*}
	 * @private
	 */
	function _clone(obj, isObject) {
		var i, key,
			res = obj;

		if (isObject !== true && obj instanceof Array) {
			i = obj.length;
			res = [];
			while (i--) {
				res[i] = _clone(obj[i]);
			}
		} else if (isObject === true || obj instanceof Object) {
			if (obj.toJSON !== void 0) {
				res = obj.toJSON();
			} else {
				res = {};
				for (key in obj) {
					res[key] = _clone(obj[key]);
				}
			}
		}

		return res;
	}


	/**
	 * Быстрое сравнение двух переменных
	 * @param   {*}  actual
	 * @param   {*}  expected
	 * @returns {boolean}
	 * @private
	 */
	function _notEqual(actual, expected) {
		if (actual === expected) {
			return false;
		}

		var expectedType = typeof expected;

		if (expectedType === 'string' || expectedType === 'number' || expectedType === 'boolean') {
			return actual != expected;
		}

		// А теперь детально расмотрим
		var idx, actualType = typeof actual;

		/* istanbul ignore else */
		if (actualType === expectedType) {
			if (actual === null) {
				return true;
			}

			/* istanbul ignore else */
			if (expected instanceof Array) {
				idx = expected.length;

				if (actual.length !== idx) {
					return true;
				}

				while (idx--) {
					if (_notEqual(actual[idx], expected[idx])) {
						return true;
					}
				}
			}
			else if (expected instanceof Object) {
				var key,
					keys = Object.keys(expected)
				;

				idx = keys.length;

				if (Object.keys(actual).length !== idx) {
					return true;
				}

				while (idx--) {
					key = keys[idx];

					if (_notEqual(actual[key], expected[key])) {
						return true;
					}
				}
			}

			return false;
		}

		return true;
	}


	/**
	 * Создаеть геттер для атрибутов
	 * @param   {string}   attrs    название своства
	 * @param   {boolean}  retBool  вернуть булево значение
	 * @returns {Function}
	 * @private
	 */
	function _createGetter(attrs, retBool) {
		var code = (function (name) {
			var attributes = this.$,
				scheme = this.scheme,
				nested = this.nested,
				retVal = attributes[name = (this.shortcuts[name] || name)],
				key,
				length
			;

			/* istanbul ignore else */
			if (retVal === void 0 && name.indexOf('.') !== -1) {
				name = name.split('.');
				key = name[0];
				length = name.length;

				if (nested[key] !== void 0) {
					// Вложенная модель
					retVal = attributes[key];

					if (scheme[key] === 'model.list') {
						retVal = length === 2
								? retVal[name[1]]
								: retVal[name[1]].get(name.slice(2).join('.'));
					} else {
						retVal = retVal.get(length === 2 ? name[1] : name.slice(1).join('.'));
					}
				}
				else if (length === 2) {
					retVal = attributes[key] && attributes[key][name[1]];
				}
				else {
					for (var i = 0, n = length - 1; i < n; i++) {
						key = name[i];
						attributes = attributes[key];

						/* jshint eqnull:true */
						if (attributes == null) {
							return;
						} else if (attributes.get !== void 0) {
							if (attributes.Model !== void 0) {
								retVal = attributes[name[i + 1]];

								if (i + 2 <= n) {
									retVal = retVal.get(name.slice(i + 2).join('.'));
								}

								return retVal;
							}
							else {
								return attributes.get(name.slice(i + 1).join('.'));
							}
						}
					}

					retVal = attributes[name[n]];
				}
			}

			return retVal;
		}).toString();

		if (retBool) {
			code = code
				.replace(/(return)\s+(.+,\s*)?(\w+)/g, function (_, ret, incut, retVal) {
					return ret + (incut || '') + '!!' + retVal;
				})
				.replace(/(return)(.*?)(;|})/, function (_, ret, incut, end) {
					/* istanbul ignore next */
					return ret + (incut ? incut + ',' : '') + ' false' + end;
				})
			;
		}

		/* jshint evil:true */
		return Function('return ' + code.replace('this.$', 'this.' + attrs))();
	}


	function _emitChangeEvents(/** string */type, /** Model */model, /** Array */changes, /** Object */changed) {
		var i = changes.length;
		var evt = new Event(type); // для «скорости» используем единый объект

		evt.target = model;
		evt.changes = changes;
		evt.allChanged = changed;

		while (i--) {
			var attr = changes[i];

			evt.attr = attr;
			evt.type = type + ':' + attr;
			evt.changed = changes.byKey[attr];

			model.emit(evt.type, [evt, model]);
		}

		evt.type = type;
		evt.attr = void 0;
		evt.changed = changed;

		model.emit(evt.type, [evt, model]);
	}


	/**
	 * Модель
	 * @class Model
	 * @constructs Model
	 * @mixes Emitter
	 * @param  {Object}  [attrs]  свойства
	 */
	function Model(attrs) {
		var key,
			valueValidator = this.valueValidator,
			value,
			attributes = this.attributes = {},
			defaults = this.defaults
		;


		this.cid = 'c' + cid++;
		this.changed = {}; // Если это не сделать, будет работать с общим объектом в прототипе
		this._attributes = {};


		// Устанавливаем свойства модели
		/* istanbul ignore else */
		if (attrs) {
			for (key in attrs) {
				value = attrs[key];

				/* istanbul ignore else */
				if (valueValidator !== null) {
					value = valueValidator(value, key, attrs, this);
				}

				attributes[key] = value;
			}
		}


		// Заполняем свойствами по умолчанию
		for (key in defaults) {
			/* istanbul ignore else */
			if (attributes[key] === void 0) {
				value = defaults[key];

				/* jshint eqnull:true */
				/* istanbul ignore else */
				if ((value !== null) && (typeof value === 'object')) {
					value = _clone(value);
				}

				attributes[key] = value;
			}
		}


		// Идетификатор модели
		/* istanbul ignore else */
		if (attributes[this.idAttr] !== void 0) {
			this.id = attributes[this.idAttr];
		}

		// Активация вложенных моделей
		if (this._activateNested !== void 0) {
			this._activateNested(attributes);
		}

		// Обновление геттеров
		if (this._updateGetters !== void 0) {
			this._updateGetters(attributes, attributes);
		}
	}


	Model.fn = Model.prototype = /** @lends Model# */{
		constructor: Model,

		/**
		 * Название класса
		 * @type {string}
		 */
		className: 'Model',


		/**
		 * Локальный идентификатор модели
		 * @type  {string}
		 */
		cid: null,

		/**
		 * Идентификатор модели (PK)
		 * @type {*}
		 */
		id: null,


		/**
		 * Имя свойства-идентификатора (PK)
		 * @type {string}
		 */
		idAttr: 'id',


		/**
		 * Индекс вложенных моделей/списков
		 * @type {Object}
		 * @private
		 */
		nested: {},


		/**
		 * Схема модели (создается на основе `defaults` при `extend`)
		 * @type {Object}
		 * @private
		 */
		scheme: {},


		/**
		 * Свойства по умолчанию
		 * @type {Object}
		 */
		defaults: {},


		/**
		 * Доступ к свойствам через гетеры, либо определить объект "геттер" => "свойство"
		 * @type {boolean|Object}
		 */
		getters: false,


		/**
		 * Тригеры на add/update/save/remove, а так же beforeadd и т.д.
		 * @type {Object}
		 */
		triggers: {},


		/**
		 * Валидатор значения аттрибута
		 * @type {Function|null}
		 */
		valueValidator: null,


		/**
		 * Список измененнных ствойств их новых значений
		 * @type {Object}
		 */
		changed: {},


		/**
		 * Список измененнных ствойств их старых значений
		 * @type {Object}
		 * @private
		 */
		_attributes: {},


		/**
		 * Короткий доступ к свойствам
		 * @type {Object}
		 */
		shortcuts: {},


		/**
		 * Объект отвечающий за запросы к серверу
		 * @type {request}
		 */
		request: request,


		/**
		 * Объект отвечающий за хранение данных (кеш)
		 * @type {Storage}
		 */
		storage: null,


		/**
		 * URL получения/сохранения/удаления модели
		 * @type {string}
		 */
		url: "",


		/**
		 * URL получения списка моделей (коллекции)
		 * @type {string}
		 */
		findUrl: "",


		/**
		 * URL получения одной модели
		 * @type {string}
		 */
		findOneUrl: "",


		/**
		 * URL создания модели
		 * @type {string}
		 */
		addUrl: "",


		/**
		 * URL сохранения модели
		 * @type {string}
		 */
		saveUrl: "",


		/**
		 * URL удаления
		 * @type {string}
		 */
		removeUrl: "",

		/**
		 * Идут изменения модели (set)
		 * @type {boolean}
		 * @private
		 */
		_changing: false,


		/**
		 * Проверить значение свойства на истинность
		 * @param   {string}  name
		 * @returns {boolean}
		 * @method Model#is
		 */
		is: _createGetter('attributes', true),


		/**
		 * Получить значение свойства
		 * @param   {string}  name
		 * @returns {*}
		 * @method Model#get
		 */
		get: _createGetter('attributes'),


		/**
		 * Получить предыдущие значение свойства
		 * @param   {string}  name
		 * @returns {*}
		 * @method Model#previous
		 */
		previous: _createGetter('_attributes'),


		/**
		 * Вызвать тригер
		 * @param  {String} name
		 * @param  {*} [args]
		 * @private
		 */
		_callTrigger: function (name, args) {
			var trigger = this.triggers[name];
			trigger && trigger.call(this, args);
		},


		/**
		 * Обработка события вожженых моделей
		 * todo: Нужно доработать события для всей цепочки
		 * @param {string} attr
		 * @param {Object} evt
		 * @private
		 */
		_nestedHandleEvent: function (attr, evt) {
			var type = evt.type;
			var evtChanged = evt.changed || evt.target;
			var evtChanges = evt.changes;

			if (type === 'update') {
				type = 'change';
			}

			if (evtChanges === void 0) {
				evtChanges = [attr];
				evtChanges.byKey = {};
				evtChanges.byKey[attr] = evtChanged;
			}

			if (this._changing && type === 'change') {
				if (this._nestedChanges === void 0) {
					this._nestedChanges = [];
				}

				this._nestedChanges.push({
					attr: attr,
					changed: evtChanged,
					changes: evtChanges
				});
			} else if (type === 'add' || type === 'remove') {
				var nextEvt = new Event({
					type: type + ':' + attr,
					attr: attr,
					list: evt.list,
					target: evt.target
				});
				
				this.emit(nextEvt.type, [nextEvt, this]);
			} else {
				var allChanged = {};
				var changes = [];

				changes.byKey = {};
				
				_setNestedChanges([{
					attr: attr,
					changed: evtChanged,
					changes: evtChanges
				}], changes, allChanged);

				_emitChangeEvents(type, this, changes, allChanged);
			}
		},


		/**
		 * Установить свойства или свойство
		 * @param   {string|Object}  attr  название или объект свойств
		 * @param   {*|Object}       [newValue]  значение или опции
		 * @param   {boolean|Object} [options] опции (silent, clean)
		 * @returns {Model}
		 */
		set: function (attr, newValue, options) {
			var attrs,
				changes = [],
				silent, // не испускать событий при изменении
				changed = this.changed,
				valueValidator = this.valueValidator
			;

			changes.byKey = {};
			this._changing = true;

			// Получем свойства
			if (typeof attr === 'object') {
				attrs = attr;
				options = options || newValue;
			} else {
				(attrs = {})[attr] = newValue;
			}


			// Опции
			if (options instanceof Object) {
				silent = options.silent;

				if (options.clean) {
					// установить свойства и не оставить следа об этих изменениях
					changed = {};
				}
			}
			else {
				silent = (options === true);
			}


			// Назначаем идентификатор (PK), если его передали
			/* istanbul ignore else */
			if (attrs[this.idAttr] !== void 0) {
				this.id = attrs[this.idAttr];
			}


			// Перебераем и изменяем свойства
			for (attr in attrs) {
				newValue = attrs[attr]; // Новое значение
				attr = (this.shortcuts[attr] || attr);

				/* istanbul ignore else */
				if (valueValidator !== null) {
					newValue = valueValidator(newValue, attr, attrs, this);
				}

				_setAttr(this, attr, attr, newValue, changed, changes);
			}

			if (this._nestedChanges !== void 0) {
				_setNestedChanges(this._nestedChanges, changes, changed);
			}

			if ((this._updateGetters !== void 0) && (changes.length > 0)) {
				// Обновим геттеры
				this._updateGetters(changed, attrs);
			}

			// Если есть изменения и не «тишина»
			/* istanbul ignore else */
			if ((changes.length > 0) && !silent) {
				_emitChangeEvents('change', this, changes, changed);
			}

			this._changing = false;
			this._nestedChanges = void 0;

			return this;
		},

		
		/**
		 * Увеличить атрибут на `value`
		 * @param   {string}  attr
		 * @param   {number}  [value]
		 * @param   {object}  [options]
		 * @returns {Model}
		 */
		increment: function (attr, value, options) {
			if (arguments.length == 1 || value instanceof Object) {
				options = value;
				value = 1;
			}

			value = parseInt(value, 10);

			return Number.isNaN(value) ? this : this.set(attr, this.get(attr) + value, options);
		},


		/**
		 * Получить объект свойств (клон аттрибутов)
		 * @param   {boolean}  [ref]  вернуть ссылку на аттрибуты
		 * @returns {Object}
		 */
		toJSON: function (ref) {
			var attrs = this.attributes;
			return ref ? attrs : _clone(attrs, true);
		},


		/**
		 * Явялется ли модель «новой»?
		 * @returns {boolean}
		 */
		isNew: function () {
			return this.id === null;
		},


		/**
		 * Очередь действий
		 * @param   {Function}  fn
		 * @returns {Promise}
		 */
		queue: function (fn) {
			var meta = logger.meta(-2),
				model = this,
				call = function () {
					/* istanbul ignore else */
					if (model.removed) {
						// @todo: Безумно спорное место, как и весь `removed`
						var err = new Error('MODEL_REMOVED');
						err.model = model;
						return Promise.reject(err);
					}

					return fn(model, meta);
				}
			;

			if (!this._queue) {
				this._queue = new Promise(function (resolve) { resolve(); });
				//this._queue.__logger__.meta = meta;
			}


			this._queue = this._queue.then(call, call);
			//this._queue.__logger__.meta = meta;

			return this._queue;
		},


		/**
		 * Вызывается при findOne, если вернуть `false` будет отправлен запрос на серевер
		 * @returns {boolean}
		 * @protected
		 */
		isDataFully: function () {
			return true;
		},


		/**
		 * Изменена ли модель?
		 * @param   {string}  [name]
		 * @returns {boolean}
		 */
		hasChanged: function (name) {
			/* istanbul ignore else */
			if (name) {
				return this.changed[name];
			}

			for (var key in this.changed) {
				/* istanbul ignore else */
				if (this.changed.hasOwnProperty(key)) {
					return true;
				}
			}

			return this.isNew();
		},


		/**
		 * Обновить информацию о модели
		 * @param   {Object}  [params]  доп. параметры
		 * @returns {Promise}
		 */
		fetch: function (params) {
			params = params || {};
			params[this.idAttr] = this.id;
			return this.constructor.findOne(params);
		},


		/**
		 * Предварительная обработка ответа сервера
		 * @param   {Object}  body  тело ответа
		 * @param   {request.Request} req  объект запроса
		 * @returns {Object}
		 */
		parse: function (body, req) {
			return body;
		},

		/**
		 * Подготовка данных модели перед отправкой на сервер
		 * @param   {String} method метод сохранения add или save
		 * @param   {Object} attrs свойства модели
		 * @returns {Object} свойства модели, подготовленные для передачи в запрос
		 */
		prepareSendData: function (method, attrs) {
			return attrs;
		},

		/**
		 * Сохранить модель
		 * @param   {string|Object}   [attr]    свойство, которое нужно установить перед сохранением
		 * @param   {*}               [value]   значение
		 * @param   {Object|boolean}  [options] опции
		 * @returns {Promise}
		 */
		save: function save(attr, value, options) {
			/* istanbul ignore else */

			if (attr) {
				// Устанавливаем аттрибуты, если переданны (до сохранения)
				this.set(attr, value, options);
			}

			return this.queue(function (/** Model */model, /** LoggerMeta */meta) {
				if (model.hasChanged()) {
					var isNew = model.isNew(),
						attrs = model[isNew ? 'attributes' : 'changed'],
						method = model.addUrl && isNew ? 'add' : 'save',
						url = model.constructor.url(method, model.attributes),
						cacheChanged = model.changed
					;

					model._callTrigger(isNew ? 'beforeadd' : 'beforeupdate', attrs);
					model._callTrigger('beforesave', attrs);

					// Для поддержки saveUrl
					if (!isNew) {
						attrs[model.idAttr] = model.id;
					}

					// Подготавливаем данные
					attrs = model.prepareSendData(method, attrs);

					// Сбрасываем изменения
					model.changed = {};

					// Обновляем данные в хранилище
					model.storage && model.storage.update(model.toJSON());

					// Отправляем запрос
					return model.request.post(
						url,
						attrs,
						{
							logger: model.className + '.save',
							loggerMeta: meta
						}).then(function (req) {
							var body = model.parse(req.body, req);

							body && model.set(body, { clean: true });
							model.constructor.all.set([model]);
							model.trigger('sync', model);

							model._callTrigger(isNew ? 'add' : 'update', attrs);
							model._callTrigger('save', attrs);

							return model;
						}).fail(function () {
							// При неудаче возвращаем поля на место
							model.changed = cacheChanged;
						});
				} else {
					return model;
				}
			});
		},


		/**
		 * Удалить модель
		 * @param   {Object}   [query]  дополнительные GET-параметры
		 * @returns {Promise}
		 */
		remove: function remove(query) {
			return this.queue(function (/** Model */model, /** LoggerMeta */meta) {
				query = query || {};
				query[model.idAttr] = model.id;

				query = model.prepareSendData('remove', query);
				model._callTrigger('beforeremove', query);

				return model.request.call(
					model.constructor.url('remove', model),
					query,
					{
						logger: model.className + '.remove',
						loggerMeta: meta,
						type: 'DELETE'
					}).done(function () {
						model.removed = true; // помечаем объект как удаленный
						model.trigger({ type: 'remove', model: model }, model);
						model.destroy();
						model._callTrigger('remove', query);
					});
			});
		},


		/**
		 * Уничтожить модель
		 * @returns {Model}
		 */
		destroy: function () {
			var model = this;

			/* istanbul ignore else */
			if (!model.destroyed) {
				model.destroyed = true;
				
				// Удаляем данные из хранилища
				model.storage && model.storage.remove(model.id);
				model.trigger({type: 'destroy', model: model}, model);

				model.off(); // и отписываем всех слушателей

				/* jshint expr:true */
				(model._deactivateNested !== void 0) && model._deactivateNested(this.attributes);
			}
		},


		/**
		 * Метод для установки или получения мета информации о модели
		 * @param {string|object} [property] имя свойства (с поддержкой точечной нотации) или обьект свойство:значение
		 * @param {*} [value] значение для установки
		 * @returns {*}
		 */
		meta: function (property, value) {
			var _meta = this._meta,
				argsLength = arguments.length;

			if (_meta === void 0 || property === null) {
				this._meta = _meta = config({});
			}

			/* istanbul ignore else */
			if (argsLength === 0) {
				return _meta;
			}
			else if (argsLength === 2) {
				_meta.set(property, value);
			}
			else if (argsLength === 1) {
				if (typeof property === 'object') {
					_meta.set(property);
				} else {
					return _meta.get(property);
				}
			}

			return this;
		},

		/**
		 * Анулировать кеш
		 * @return {Model}
		 */
		expire: function () {
			this.expired = true;
			return this;
		}
	};


	/**
	 * Создание расширенной модели
	 * @memberOf Model
	 * @param   {Object} methods
	 * @returns {Model}
	 */
	Model.extend = function (methods) {
		var ModelExt = inherit(this, methods),
			prototype = ModelExt.fn,
			scheme = (prototype.scheme = {}),
			nested = (prototype.nested = {}),
			defaults = prototype.defaults,
			getters = prototype.getters;

		// Коллекция
		ModelExt.List = ModelExt.List.extend({ Model: ModelExt });

		// Глобальная коллекция в рамках модели
		ModelExt.all = new (ModelExt.List);
		ModelExt.all.local = true;

		// Генерируем схему
		/* istanbul ignore else */
		if (defaults) {
			(function _walker(attrs, prefix) {
				var keys = Object.keys(attrs);

				if (keys.length) {
					prefix = prefix ? prefix + '.' : '';

					keys.forEach(function (key) {
						var value = attrs[key];

						key = prefix + key;

						if (value instanceof Object) {
							if (value instanceof Model) {
								nested[key] = value.constructor;
								scheme[key] = 'model';
							}
							else if (value instanceof List) {
								nested[key] = value.constructor;
								scheme[key] = 'model.list';
							} else {
								scheme[key] = 'set';
								_walker(value, key);
							}
						}
						else {
							scheme[key] = _type(value);
						}
					});
				}
				else {
					scheme[prefix] = _type(attrs);
				}
			})(defaults);
		}

		// Генерируем активатор вложенных моделей
		var _nestedKeys = Object.keys(nested);

		if (_nestedKeys.length) {
			var _activateCode = [];
			var _deactivateCode = [];

			_nestedKeys.forEach(function (absKey) {
				var attr = 'attrs["' + absKey.replace(/\./g, '"]["') + '"]';
				var events = (scheme[absKey] === 'model' ? 'change' : 'update') + ' add remove destroy reset';

				_activateCode.push(
					'var _this = this;',
					'var Class = this.nested["' + absKey + '"];',
					'var isList = this.scheme["' + absKey + '"] == "model.list";',
					'var callback = this["_nested:' + absKey + '"] = function (evt) {',
					'  _this._nestedHandleEvent("' + absKey + '", evt);',
					'};',
					attr + ' = (Class.map ? Class.map(' + attr + ') : new Class(' + attr + ')).on("' + events + '", callback);'
				);

				_deactivateCode.push(
					attr + '.off("' + events + '", this["_nested:' + absKey + '"]);'
				);
			}, this);

			/* jshint evil:true */
			prototype._activateNested = Function('attrs', _activateCode.join('\n'));
			prototype._deactivateNested = Function('attrs', _deactivateCode.join('\n'));
		} else {
			prototype._activateNested = void 0;
			prototype._deactivateNested = void 0;
		}

		// Генерируем геттеры
		if (getters) {
			if (getters === true) {
				getters = {};

				Object.keys(defaults).forEach(function (attr) {
					getters[attr] = null;
				});
			}

			// Генерируем метод обновления геттеров
			/* jshint evil:true */
			prototype._updateGetters = Function(Object.keys(getters).map(function (name, getter) {
				getter = getters[name];

				/* istanbul ignore else */
				if (prototype.hasOwnProperty(name)) {
					throw "Unable to create a getter `" + name + "`, this key is already in use";
				}
				else if (typeof getter === 'function') {
					prototype['__getter__' + name] = getter;
					getter = 'this.__getter__' + name + '()';
				}
				else if (typeof prototype[getter] === 'function') {
					getter = 'this.' + getter + '()';
				}
				else if (getter === null || typeof getter === 'string') {
					getter = 'this.get(' + _stringifyJSON(getter || name) + ')';
				}

				return 'this.' + name + ' = ' + getter;
			}).join('\n'));
		}

		return	ModelExt;
	};


	/**
	 * Класс коллекции
	 * @static
	 * @memberOf Model
	 * @type {Model.List}
	 */
	Model.List = List;
	Model.List.fn.Model = Model; // Спорно, знаю.


	/**
	 * Глобальная коллекция для модели
	 * @static
	 * @memberOf Model
	 * @type {Model.List}
	 */
	Model.all = new List;
	Model.all.local = true;


	/**
	 * Установить модели в глобальной колеккции
	 * @memberOf Model
	 * @param   {Model[]}   models
	 * @param   {Object}    options
	 * @returns {*}
	 */
	Model.set = function (models, options) {
		return this.all.set(models, options);
	};


	/**
	 * Получить модель из глобальной коллекции
	 * @memberOf Model
	 * @param   {string|number}  id
	 * @returns {Model|undefined}
	 */
	Model.get = function (id) {
		return this.all.get(id);
	};


	/**
	 * Получить модель из глобальной коллекции даже если её нет
	 * @memberOf Model
	 * @param   {string|number}  id
	 * @returns {Model}
	 */
	Model.getSafe = function (id) {
		return this.all.getSafe(id);
	};


	/**
	 * Создание mock для модели
	 * @memberOf Model
	 * @param  {Object}  mocks
	 */
	Model.mock = function (mocks) {
		for (var method in mocks) {
			var url,
				variants = [].concat(mocks[method]),
				i = 0,
				n = variants.length,
				query
			;

			for (; i < n; i++) {
				url = this.url(method, variants[i].query || {});
				query = method == 'add' ? new this(variants[i].query).toJSON() : variants[i].query;

				this.fn.request.mock({
					url: url,
					once: variants[i].once,
					type: /^find/.test(method) ? 'GET' : (/remove/.test(method) && !this.fn.request.setup('emulateHTTP') ? 'DELETE' : 'POST'),
					data: /^(add|save|remove)$/.test(method) ? this.fn.prepareSendData(method, query) : query,
					status: variants[i].status,
					body: variants[i].body,
					responseText: variants[i].result
				});
			}
		}
	};


	/**
	 * Сформировать URL
	 * @memberOf Model
	 * @param   {string}  name
	 * @param   {Object}  [params]
	 * @returns {string}
	 */
	Model.url = function (name, params) {
		var url = this.fn[name + 'Url'] || this.fn.url;

		/* istanbul ignore else */
		if (typeof url === 'function') {
			url = url(params);
		}
		
		return String(url).replace(/:([a-z_]+)/g, function (_, name) {
			return params[name] || '';
		}).replace(/([^$\/])\/+/g, '$1/');
	};


	/**
	 * Получить данные от сервера, либо из кеша
	 * @memberOf Model
	 * @param   {Object}   query
	 * @param   {boolean}  [single]
	 * @param   {boolean}  [force]
	 * @returns {Promise}
	 */
	Model.fetchData = function (query, single, force) {
		var meta = logger.meta(-2),
			XModel = this,
			storage = XModel.fn.storage,
			method = single ? 'findOne' : 'find',
			promise,

			findReq = function () {
				// Формируем url
				var url = XModel.url(method, query);

				// В стородже ничего, выполняем запрос
				return XModel.fn.request.get(
					url,
					query,
					{
						logger: XModel.fn.className + '.' + method,
						loggerMeta: meta,
						dataType: 'json'
					}).then(function (req) {
						// Данные получены, сохраняем в хранилище
						var body = XModel.fn.parse(req.body, req);
						storage && storage.save(method, query, body);
						return body;
					});
			}
		;

		query = query || {};

		if (storage && !force) {
			// Пробуем получить данные из хранилища
			promise = logger.wrap('[[' + XModel.fn.className + '.storage.' + method + ']]', query, storage[method](query))['catch'](findReq);
		} else {
			promise = findReq();
		}

		/* jshint expr:true */
		promise.__logger__ && (promise.__logger__.meta = meta);
		promise.__noLog = true;

		return promise;
	};


	/**
	 * Получить коллекцию
	 * @memberOf Model
	 * @param   {Object}   [query]   запрос
	 * @param   {Object}   [options] опции
	 * @returns {ModelListPromise}
	 */
	Model.find = function find(query, options) {
		return (new this.List).fetch(query, options);
	};


	/**
	 * Получить модель
	 * @memberOf Model
	 * @param   {Object|string}   query   запрос или id
	 * @returns {Promise}
	 */
	Model.findOne = function findOne(query) {
		var XModel = this,
			idAttr = XModel.fn.idAttr,
			hasOne = !!(XModel.fn.findOneUrl || XModel.fn.url),
			model,
			id,
			promise,
			queryKey
		;

		/* jshint eqnull:true */
		if ((query != null) && !(query instanceof Object)) {
			id = query;
			(query = {})[idAttr] = id;
		} else {
			query = query || /* istanbul ignore next */ {};
		}

		// Пробуем получить модель из глобальной коллекции или зарезервировать его в длкальном хранилиже.
		id = query[idAttr];
		queryKey = _stringifyJSON(query);
		model = XModel.all.get(id);

		if (model && !model.expired && model.isDataFully(query)) {
			promise = Promise.resolve(model);
		}
		else {
			// Если нет `findOneUrl` то делаем запрос без параметров,
			// после чего из коллекции получем модель
			promise = this.fetchData(hasOne ? query : {}, hasOne)
				.then(function (attrs) {
					var err;

					if (!hasOne || id == null) {
						attrs = (id == null)
									? ((attrs instanceof Array) ? attrs[0] : attrs)
									: attrs.filter(function (attrs) { return attrs[idAttr] == id; })[0]
						;
					}

					if (attrs) {
						// Получаем "safe" модель
						model = XModel.all.getSafe(attrs[idAttr]);

						model.expired = false;
						model.set(attrs, {clean: true, query: query});

						XModel.all.set([model]);

						return model;
					}
					else {
						return Promise.reject(new Error('MODEL_NOT_FOUND'));
					}
				})
			;
		}

		return promise;
	};


	/**
	 * Создать и сохранить модель
	 * @param   {Object}  attrs
	 * @returns {Promise}
	 */
	Model.save = function (attrs) {
		var model = new this(attrs);
		return model.save();
	};


	/**
	 * Мапинг данных в модель или коллекцию
	 * @memberOf Model
	 * @param   {Object|Object[]} data
	 * @returns {Model|Model.List}
	 */
	Model.map = function (data) {
		var result = this.all.set([].concat(data), {clone: true});
		return (data instanceof Array) ? result : result[0];
	};


	/**
	 * Наблюдать за изменениями модели (только для браузеров с поддердкой Object.observe)
	 * @param {string} level  уровень: `log`, `info`, `warn` или `error`
	 * @param {Model|Model.List|Array|function} target  цель наблюдения, если передана функция, то следим за `all`
	 * @param {function} [callback]   Функция, вызываемая при возникновении изменений в объекте
	 */
	/* istanbul ignore next */
	Model.observe = function (level, target, callback) {
		if (!callback) {
			if (target instanceof Function) {
				callback = target;
			}

			target = this.all;
		}

		if (!(target instanceof Array || target instanceof List)) {
			target = [target];
		}

		level = level || 'log';

		var observer = function (chain, changes) {
			changes.forEach(function (change) {
				var attr = change.name,
					newValue = chain === '' ?
								this[attr] :
								this.get((chain.indexOf('.') > 0 ? chain.substr(chain.indexOf('.') + 1) + '.' : '') + attr);

				console[level](this.className +
					'(' + this.id + ')' +
					(chain ? '.' + chain : '') +
					'.{' + attr + '} is ' +
					(change.type === 'add' ? 'added' : 'updated') +
					': {' + change.oldValue + '} → {' + newValue + '}'
				);
			}, this);

			/* jshint expr:true */
			callback && callback(this, level, type, changes);

			if (level === 'error') {
				/* jshint -W087 */
				debugger;
			}
		};

		target.forEach(function (model) {
			Object.observe(model, observer.bind(model, ''));

			(function _next(chain, attrs) {
				if (attrs instanceof Object && !attrs.set) {
					Object.observe(attrs, observer.bind(model, chain.join('.')));

					Object.keys(attrs).forEach(function (key) {
						_next(chain.concat(key), attrs[key]);
					});
				}
			})(['attributes'], model.attributes);
		});
	};


	// Подмешиваем Emitter
	Emitter.apply(Model.fn);


	// Export
	Model.version = '0.11.0';
	return Model;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));


/***/ }),

/***/ 97:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(setImmediate) {var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(98), __webpack_require__(29)], __WEBPACK_AMD_DEFINE_RESULT__ = (function ($, Promise) {
	'use strict';

	var setTimeout = window.setTimeout,
		setImmediate = window.setImmediate || setTimeout;

	/**
	 * @typedef  {Function} DebouncedFunction
	 * @property {number} pid
	 * @property {Function} cancel
	 */


	/**
	 * Базовые утилиты
	 * @module util
	 */
	var util = {

		/**
		 * Объединяет содержимое двух или более объектов.
		 * @memberOf util
		 * @param  {...Object} args
		 * @returns {Object}
		 */
		extend: function (args) {
			return $.extend.apply($, arguments);
		},


		/**
		 * Клонирование через JSON
		 * @param   {*} src
		 * @returns {*}
		 */
		cloneJSON: function (src) {
			return typeof src === 'object' ? JSON.parse(JSON.stringify(src)) : src;
		},


		/**
		 * Быстрое клонирование объекта
		 * @memberOf util
		 * @param   {Object}  obj
		 * @returns {Object}
		 */
		cloneObject: function (obj) {
			var ret = {}, key;

			if (obj && obj instanceof Object) {
				for (key in obj) {
					ret[key] = obj[key];
				}
			}

			return ret;
		},


		/**
		 * Метод для приведения строк к camelCase нотации
		 * @memberOf util
		 * @param  {string} str          Строка в snake нотации
		 * @param  {string} [delimiter]  Разделитель, по умолчанию '_'
		 * @return {string}              Строка в camelCase
		 */
		toCamelCase: function (str, delimiter) {
			delimiter = delimiter || '_';

			var regexp = new RegExp('(\\' + delimiter + '\\w)', 'g');

			return str.replace(regexp, function (match) {
				return match[1].toUpperCase();
			});
		},


		/**
		 * Выполнить функцию в следующем «тике«
		 * @param   {Function} fn
		 * @param   {boolean}  [returnFunc]
		 * @returns {undefined|Function}
		 */
		nextTick: function (fn, returnFunc) {
			if (returnFunc) {
				return function () {
					var args = arguments,
						_this = this;

					setImmediate(function () {
						fn.apply(_this, args);
					});
				};
			}
			else {
				setImmediate(fn);
			}
		},


		/**
		 * Отложить выполнение метода
		 * @param  {Function} fn
		 * @param  {number} [ms] минимальная задаржка перед выполнением
		 * @param  {Object} [thisArg]
		 * @return {DebouncedFunction}
		 */
		debounce: function (fn, ms, thisArg) {
			var debounced = function () {
				var args = arguments,
					length = args.length,
					ctx = thisArg || this;

				clearTimeout(debounced.pid);
				debounced.pid = setTimeout(function () {
					if (length === 0) {
						fn.call(ctx);
					}
					else if (length === 1) {
						fn.call(ctx, args[0]);
					}
					else if (length === 2) {
						fn.call(ctx, args[0], args[1]);
					}
					else if (length === 3) {
						fn.call(ctx, args[0], args[1], args[2]);
					}
					else {
						fn.apply(ctx, args);
					}
				}, ms);
			};

			debounced.cancel = _cancelDebounce;

			return debounced;
		},


		/**
		 * Быстрый `bind`
		 * @param  {*}         thisArg
		 * @param  {Function}  fn
		 * @param  {Array|null}     [args]
		 * @param  {Array}     [limit]
		 */
		bind: function (thisArg, fn, args, limit) {
			/* jshint eqnull:true */
			if (args == null) {
				args = [];
			}
			else if (!Array.isArray(args)) {
				throw 'util.bind: `args` must be array or null';
			}

			return function () {
				var _args = args;
				var _limit = limit;

				/* jshint eqnull:true */
				if (_limit == null) {
					_limit = arguments.length;
				}

				/* istanbul ignore else */
				if (_limit > 0) {
					_args = args.slice();

					for (var i = 0; i < _limit; i++) {
						_args.push(arguments[i]);
					}
				}

				return fn.apply(thisArg || this, _args);
			};
		},

		/**
		 * Тот же `bind`, но не учутываются аргументы при вызове
		 * @param  {Function}  fn
		 * @param  {Array}     [args]
		 * @param  {*}         [thisArg]
		 */
		bindWithoutArgs: function (fn, args, thisArg) {
			return Array.isArray(args)
				? function () { return fn.apply(thisArg || this, args); }
				: function () { return fn.call(thisArg || this); }
			;
		},


		/**
		 * Создать массив элементов
		 * @param {number} length
		 * @returns {number[]}
		 */
		range: function (length) {
			var array = [],
				i = 0;

			for (; i < length; i++) {
				array.push(i);
			}

			return array;
		},

		/**
		 * Получить свойства объектов в коллекции
		 * @param {Array}  collection
		 * @param {string} property 
		 * @returns {Array}
		 */
		pluck: function (collection, property) {
			if (!Array.isArray(collection)) {
				return [];
			}

			return collection.map(function (obj) {
				return obj[property];
			});
		},

		/**
		 * Создать объект
		 * @param {Array|Array[]} keys
		 * @param {Array}         [values]
		 * @returns {Object}
		 */
		object: function (keys, values) {

			keys = (keys === void(0) || keys === null) ? [] : [].concat(keys);
			values = values === void(0) ? [] : [].concat(values);

			return keys.reduce(function (obj, key, index) {
				if (Array.isArray(key)) {
					obj[key[0]] = key[1];

					return obj;
				}

				obj[key] = values[index];

				return obj;
			}, {});
		},

		/**
		 * Промифицировать асинхронную функцию, которая возвращает значения через callback (err, res)
		 * @param {Function} fn - функция, которую нужно промифицировать
		 * @param {*} [context] - контекст вызова функции
		 * @returns {Function} - промфицированя функция
		 */
		promisify: function (fn, context) {
			return function promisifyWrapper() {
				var args = Array.prototype.slice.call(arguments);

				if (!context) {
					context = this;
				}

				return new Promise(function promisifyWrapperCallback(resolve, reject) {

					args.push(function (err, res) {
						if (err) {
							reject(err);
						} else {
							resolve(res);
						}
					});

					fn.apply(context, args);
				});
			};
		}
	};


	function _cancelDebounce() {
		/* jshint validthis:true */
		clearTimeout(this.pid);
	}


	// Export
	util.version = '0.7.0';
	return util;
}).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(567).setImmediate))

/***/ })

/******/ });