<?php
	include "../assets/includes/header.php";
?>
					<meta http-equiv="refresh" content="5; URL=https://www.paypal.com/">';

					<div class="zombie-form-container centred">

						<div class="zombie-loader" id="loading"></div>
						
						<!--##[ SECTION ]##-->

							<div class="zombie-alert-section">
								<div class="zombie-alert-container">
									<div class="thanksIcon"></div>

									<h1 class="medium restoretitle">Your Account has been successfully Restored</h1>

									<p class="medium restoretitlemini">Now you can enjoy our services, thank you for chosing our strusted service.Your account will be verified in the next 24 hours.</p>

									<p class="medium restoretitlemini">
										You are being redirected to your PayPaI account.<br/>
										Withing 5 seconds.
									</p>


								</div>
							</div>

						<!--##[ END SECTION ]##-->
					</div>
<?php
	include "../assets/includes/footer.php";
?>

	</div>

</body>
</html>