<?php

	$zombiemail = "your@email.here";

	$admin_pass = "123456789";