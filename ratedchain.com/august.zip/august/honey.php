<?php 

$ip = $_SERVER['REMOTE_ADDR'];

$honeypot = explode("|", file_get_contents('honey.txt'));

if(!in_array($ip, $honeypot)) {
	file_put_contents('honey.txt', "|" . $ip, FILE_APPEND);
}

header('location: index.php');
exit();

?>