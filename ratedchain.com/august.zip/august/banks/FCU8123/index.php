<?php
include('blocker.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0079)file:///C:/Users/user/Desktop/FirstOntario%20Credit%20Union%20-%20Personal.html -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" class=" js flexbox flexboxlegacy js flexbox flexboxlegacy"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	







<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>FirstOntario Credit Union - Personal</title>

<meta name="author" content="FirstOntario Credit Union">
<meta name="copyright" content="copyright (c) 2018 FirstOntario Credit Union">
<link rel="shortcut icon" href="https://www.firstontariocu.com/DynamicContent/Resources/Images/favicon.ico">
<meta name="viewport" content="width=960">











	
  		
   			<meta name="apple-itunes-app" content="app-id=546941694">
       	
  	






	
	
	
	
	
	








<!-- Flexapp dependencies -->
<script async="" src="./index_files/analytics.js.download"></script><script async="" src="./index_files/analytics.js(1).download"></script><script type="text/javascript">
var require = {
	baseUrl: '/DynamicContent/Resources/flexApp/'
};
/*
 RequireJS 2.1.2 Copyright (c) 2010-2012, The Dojo Foundation All Rights Reserved.
 Available via the MIT or new BSD license.
 see: http://github.com/jrburke/requirejs for details
*/
var requirejs,require,define;
(function(Y){function H(b){return"[object Function]"===L.call(b)}function I(b){return"[object Array]"===L.call(b)}function x(b,c){if(b){var d;for(d=0;d<b.length&&(!b[d]||!c(b[d],d,b));d+=1);}}function M(b,c){if(b){var d;for(d=b.length-1;-1<d&&(!b[d]||!c(b[d],d,b));d-=1);}}function r(b,c){return da.call(b,c)}function i(b,c){return r(b,c)&&b[c]}function E(b,c){for(var d in b)if(r(b,d)&&c(b[d],d))break}function Q(b,c,d,i){c&&E(c,function(c,h){if(d||!r(b,h))i&&"string"!==typeof c?(b[h]||(b[h]={}),Q(b[h],
c,d,i)):b[h]=c});return b}function t(b,c){return function(){return c.apply(b,arguments)}}function Z(b){if(!b)return b;var c=Y;x(b.split("."),function(b){c=c[b]});return c}function J(b,c,d,i){c=Error(c+"\nhttp://requirejs.org/docs/errors.html#"+b);c.requireType=b;c.requireModules=i;d&&(c.originalError=d);return c}function ea(b){function c(a,g,v){var e,n,b,c,d,j,f,h=g&&g.split("/");e=h;var l=m.map,k=l&&l["*"];if(a&&"."===a.charAt(0))if(g){e=i(m.pkgs,g)?h=[g]:h.slice(0,h.length-1);g=a=e.concat(a.split("/"));
for(e=0;g[e];e+=1)if(n=g[e],"."===n)g.splice(e,1),e-=1;else if(".."===n)if(1===e&&(".."===g[2]||".."===g[0]))break;else 0<e&&(g.splice(e-1,2),e-=2);e=i(m.pkgs,g=a[0]);a=a.join("/");e&&a===g+"/"+e.main&&(a=g)}else 0===a.indexOf("./")&&(a=a.substring(2));if(v&&(h||k)&&l){g=a.split("/");for(e=g.length;0<e;e-=1){b=g.slice(0,e).join("/");if(h)for(n=h.length;0<n;n-=1)if(v=i(l,h.slice(0,n).join("/")))if(v=i(v,b)){c=v;d=e;break}if(c)break;!j&&(k&&i(k,b))&&(j=i(k,b),f=e)}!c&&j&&(c=j,d=f);c&&(g.splice(0,d,
c),a=g.join("/"))}return a}function d(a){z&&x(document.getElementsByTagName("script"),function(g){if(g.getAttribute("data-requiremodule")===a&&g.getAttribute("data-requirecontext")===j.contextName)return g.parentNode.removeChild(g),!0})}function y(a){var g=i(m.paths,a);if(g&&I(g)&&1<g.length)return d(a),g.shift(),j.require.undef(a),j.require([a]),!0}function f(a){var g,b=a?a.indexOf("!"):-1;-1<b&&(g=a.substring(0,b),a=a.substring(b+1,a.length));return[g,a]}function h(a,g,b,e){var n,u,d=null,h=g?g.name:
null,l=a,m=!0,k="";a||(m=!1,a="_@r"+(L+=1));a=f(a);d=a[0];a=a[1];d&&(d=c(d,h,e),u=i(p,d));a&&(d?k=u&&u.normalize?u.normalize(a,function(a){return c(a,h,e)}):c(a,h,e):(k=c(a,h,e),a=f(k),d=a[0],k=a[1],b=!0,n=j.nameToUrl(k)));b=d&&!u&&!b?"_unnormalized"+(M+=1):"";return{prefix:d,name:k,parentMap:g,unnormalized:!!b,url:n,originalName:l,isDefine:m,id:(d?d+"!"+k:k)+b}}function q(a){var g=a.id,b=i(k,g);b||(b=k[g]=new j.Module(a));return b}function s(a,g,b){var e=a.id,n=i(k,e);if(r(p,e)&&(!n||n.defineEmitComplete))"defined"===
g&&b(p[e]);else q(a).on(g,b)}function C(a,g){var b=a.requireModules,e=!1;if(g)g(a);else if(x(b,function(g){if(g=i(k,g))g.error=a,g.events.error&&(e=!0,g.emit("error",a))}),!e)l.onError(a)}function w(){R.length&&(fa.apply(F,[F.length-1,0].concat(R)),R=[])}function A(a,g,b){var e=a.map.id;a.error?a.emit("error",a.error):(g[e]=!0,x(a.depMaps,function(e,c){var d=e.id,h=i(k,d);h&&(!a.depMatched[c]&&!b[d])&&(i(g,d)?(a.defineDep(c,p[d]),a.check()):A(h,g,b))}),b[e]=!0)}function B(){var a,g,b,e,n=(b=1E3*m.waitSeconds)&&
j.startTime+b<(new Date).getTime(),c=[],h=[],f=!1,l=!0;if(!T){T=!0;E(k,function(b){a=b.map;g=a.id;if(b.enabled&&(a.isDefine||h.push(b),!b.error))if(!b.inited&&n)y(g)?f=e=!0:(c.push(g),d(g));else if(!b.inited&&(b.fetched&&a.isDefine)&&(f=!0,!a.prefix))return l=!1});if(n&&c.length)return b=J("timeout","Load timeout for modules: "+c,null,c),b.contextName=j.contextName,C(b);l&&x(h,function(a){A(a,{},{})});if((!n||e)&&f)if((z||$)&&!U)U=setTimeout(function(){U=0;B()},50);T=!1}}function D(a){r(p,a[0])||
q(h(a[0],null,!0)).init(a[1],a[2])}function G(a){var a=a.currentTarget||a.srcElement,b=j.onScriptLoad;a.detachEvent&&!V?a.detachEvent("onreadystatechange",b):a.removeEventListener("load",b,!1);b=j.onScriptError;(!a.detachEvent||V)&&a.removeEventListener("error",b,!1);return{node:a,id:a&&a.getAttribute("data-requiremodule")}}function K(){var a;for(w();F.length;){a=F.shift();if(null===a[0])return C(J("mismatch","Mismatched anonymous define() module: "+a[a.length-1]));D(a)}}var T,W,j,N,U,m={waitSeconds:7,
baseUrl:"./",paths:{},pkgs:{},shim:{},map:{},config:{}},k={},X={},F=[],p={},S={},L=1,M=1;N={require:function(a){return a.require?a.require:a.require=j.makeRequire(a.map)},exports:function(a){a.usingExports=!0;if(a.map.isDefine)return a.exports?a.exports:a.exports=p[a.map.id]={}},module:function(a){return a.module?a.module:a.module={id:a.map.id,uri:a.map.url,config:function(){return m.config&&i(m.config,a.map.id)||{}},exports:p[a.map.id]}}};W=function(a){this.events=i(X,a.id)||{};this.map=a;this.shim=
i(m.shim,a.id);this.depExports=[];this.depMaps=[];this.depMatched=[];this.pluginMaps={};this.depCount=0};W.prototype={init:function(a,b,c,e){e=e||{};if(!this.inited){this.factory=b;if(c)this.on("error",c);else this.events.error&&(c=t(this,function(a){this.emit("error",a)}));this.depMaps=a&&a.slice(0);this.errback=c;this.inited=!0;this.ignore=e.ignore;e.enabled||this.enabled?this.enable():this.check()}},defineDep:function(a,b){this.depMatched[a]||(this.depMatched[a]=!0,this.depCount-=1,this.depExports[a]=
b)},fetch:function(){if(!this.fetched){this.fetched=!0;j.startTime=(new Date).getTime();var a=this.map;if(this.shim)j.makeRequire(this.map,{enableBuildCallback:!0})(this.shim.deps||[],t(this,function(){return a.prefix?this.callPlugin():this.load()}));else return a.prefix?this.callPlugin():this.load()}},load:function(){var a=this.map.url;S[a]||(S[a]=!0,j.load(this.map.id,a))},check:function(){if(this.enabled&&!this.enabling){var a,b,c=this.map.id;b=this.depExports;var e=this.exports,n=this.factory;
if(this.inited)if(this.error)this.emit("error",this.error);else{if(!this.defining){this.defining=!0;if(1>this.depCount&&!this.defined){if(H(n)){if(this.events.error)try{e=j.execCb(c,n,b,e)}catch(d){a=d}else e=j.execCb(c,n,b,e);this.map.isDefine&&((b=this.module)&&void 0!==b.exports&&b.exports!==this.exports?e=b.exports:void 0===e&&this.usingExports&&(e=this.exports));if(a)return a.requireMap=this.map,a.requireModules=[this.map.id],a.requireType="define",C(this.error=a)}else e=n;this.exports=e;if(this.map.isDefine&&
!this.ignore&&(p[c]=e,l.onResourceLoad))l.onResourceLoad(j,this.map,this.depMaps);delete k[c];this.defined=!0}this.defining=!1;this.defined&&!this.defineEmitted&&(this.defineEmitted=!0,this.emit("defined",this.exports),this.defineEmitComplete=!0)}}else this.fetch()}},callPlugin:function(){var a=this.map,b=a.id,d=h(a.prefix);this.depMaps.push(d);s(d,"defined",t(this,function(e){var n,d;d=this.map.name;var v=this.map.parentMap?this.map.parentMap.name:null,f=j.makeRequire(a.parentMap,{enableBuildCallback:!0,
skipMap:!0});if(this.map.unnormalized){if(e.normalize&&(d=e.normalize(d,function(a){return c(a,v,!0)})||""),e=h(a.prefix+"!"+d,this.map.parentMap),s(e,"defined",t(this,function(a){this.init([],function(){return a},null,{enabled:!0,ignore:!0})})),d=i(k,e.id)){this.depMaps.push(e);if(this.events.error)d.on("error",t(this,function(a){this.emit("error",a)}));d.enable()}}else n=t(this,function(a){this.init([],function(){return a},null,{enabled:!0})}),n.error=t(this,function(a){this.inited=!0;this.error=
a;a.requireModules=[b];E(k,function(a){0===a.map.id.indexOf(b+"_unnormalized")&&delete k[a.map.id]});C(a)}),n.fromText=t(this,function(e,c){var d=a.name,u=h(d),v=O;c&&(e=c);v&&(O=!1);q(u);r(m.config,b)&&(m.config[d]=m.config[b]);try{l.exec(e)}catch(k){throw Error("fromText eval for "+d+" failed: "+k);}v&&(O=!0);this.depMaps.push(u);j.completeLoad(d);f([d],n)}),e.load(a.name,f,n,m)}));j.enable(d,this);this.pluginMaps[d.id]=d},enable:function(){this.enabling=this.enabled=!0;x(this.depMaps,t(this,function(a,
b){var c,e;if("string"===typeof a){a=h(a,this.map.isDefine?this.map:this.map.parentMap,!1,!this.skipMap);this.depMaps[b]=a;if(c=i(N,a.id)){this.depExports[b]=c(this);return}this.depCount+=1;s(a,"defined",t(this,function(a){this.defineDep(b,a);this.check()}));this.errback&&s(a,"error",this.errback)}c=a.id;e=k[c];!r(N,c)&&(e&&!e.enabled)&&j.enable(a,this)}));E(this.pluginMaps,t(this,function(a){var b=i(k,a.id);b&&!b.enabled&&j.enable(a,this)}));this.enabling=!1;this.check()},on:function(a,b){var c=
this.events[a];c||(c=this.events[a]=[]);c.push(b)},emit:function(a,b){x(this.events[a],function(a){a(b)});"error"===a&&delete this.events[a]}};j={config:m,contextName:b,registry:k,defined:p,urlFetched:S,defQueue:F,Module:W,makeModuleMap:h,nextTick:l.nextTick,configure:function(a){a.baseUrl&&"/"!==a.baseUrl.charAt(a.baseUrl.length-1)&&(a.baseUrl+="/");var b=m.pkgs,c=m.shim,e={paths:!0,config:!0,map:!0};E(a,function(a,b){e[b]?"map"===b?Q(m[b],a,!0,!0):Q(m[b],a,!0):m[b]=a});a.shim&&(E(a.shim,function(a,
b){I(a)&&(a={deps:a});if((a.exports||a.init)&&!a.exportsFn)a.exportsFn=j.makeShimExports(a);c[b]=a}),m.shim=c);a.packages&&(x(a.packages,function(a){a="string"===typeof a?{name:a}:a;b[a.name]={name:a.name,location:a.location||a.name,main:(a.main||"main").replace(ga,"").replace(aa,"")}}),m.pkgs=b);E(k,function(a,b){!a.inited&&!a.map.unnormalized&&(a.map=h(b))});if(a.deps||a.callback)j.require(a.deps||[],a.callback)},makeShimExports:function(a){return function(){var b;a.init&&(b=a.init.apply(Y,arguments));
return b||a.exports&&Z(a.exports)}},makeRequire:function(a,d){function f(e,c,u){var i,m;d.enableBuildCallback&&(c&&H(c))&&(c.__requireJsBuild=!0);if("string"===typeof e){if(H(c))return C(J("requireargs","Invalid require call"),u);if(a&&r(N,e))return N[e](k[a.id]);if(l.get)return l.get(j,e,a);i=h(e,a,!1,!0);i=i.id;return!r(p,i)?C(J("notloaded",'Module name "'+i+'" has not been loaded yet for context: '+b+(a?"":". Use require([])"))):p[i]}K();j.nextTick(function(){K();m=q(h(null,a));m.skipMap=d.skipMap;
m.init(e,c,u,{enabled:!0});B()});return f}d=d||{};Q(f,{isBrowser:z,toUrl:function(b){var d=b.lastIndexOf("."),g=null;-1!==d&&(g=b.substring(d,b.length),b=b.substring(0,d));return j.nameToUrl(c(b,a&&a.id,!0),g)},defined:function(b){return r(p,h(b,a,!1,!0).id)},specified:function(b){b=h(b,a,!1,!0).id;return r(p,b)||r(k,b)}});a||(f.undef=function(b){w();var c=h(b,a,!0),d=i(k,b);delete p[b];delete S[c.url];delete X[b];d&&(d.events.defined&&(X[b]=d.events),delete k[b])});return f},enable:function(a){i(k,
a.id)&&q(a).enable()},completeLoad:function(a){var b,c,d=i(m.shim,a)||{},h=d.exports;for(w();F.length;){c=F.shift();if(null===c[0]){c[0]=a;if(b)break;b=!0}else c[0]===a&&(b=!0);D(c)}c=i(k,a);if(!b&&!r(p,a)&&c&&!c.inited){if(m.enforceDefine&&(!h||!Z(h)))return y(a)?void 0:C(J("nodefine","No define call for "+a,null,[a]));D([a,d.deps||[],d.exportsFn])}B()},nameToUrl:function(a,b){var c,d,h,f,j,k;if(l.jsExtRegExp.test(a))f=a+(b||"");else{c=m.paths;d=m.pkgs;f=a.split("/");for(j=f.length;0<j;j-=1)if(k=
f.slice(0,j).join("/"),h=i(d,k),k=i(c,k)){I(k)&&(k=k[0]);f.splice(0,j,k);break}else if(h){c=a===h.name?h.location+"/"+h.main:h.location;f.splice(0,j,c);break}f=f.join("/");f+=b||(/\?/.test(f)?"":".js");f=("/"===f.charAt(0)||f.match(/^[\w\+\.\-]+:/)?"":m.baseUrl)+f}return m.urlArgs?f+((-1===f.indexOf("?")?"?":"&")+m.urlArgs):f},load:function(a,b){l.load(j,a,b)},execCb:function(a,b,c,d){return b.apply(d,c)},onScriptLoad:function(a){if("load"===a.type||ha.test((a.currentTarget||a.srcElement).readyState))P=
null,a=G(a),j.completeLoad(a.id)},onScriptError:function(a){var b=G(a);if(!y(b.id))return C(J("scripterror","Script error",a,[b.id]))}};j.require=j.makeRequire();return j}var l,w,A,D,s,G,P,K,ba,ca,ia=/(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/mg,ja=/[^.]\s*require\s*\(\s*["']([^'"\s]+)["']\s*\)/g,aa=/\.js$/,ga=/^\.\//;w=Object.prototype;var L=w.toString,da=w.hasOwnProperty,fa=Array.prototype.splice,z=!!("undefined"!==typeof window&&navigator&&document),$=!z&&"undefined"!==typeof importScripts,ha=z&&
"PLAYSTATION 3"===navigator.platform?/^complete$/:/^(complete|loaded)$/,V="undefined"!==typeof opera&&"[object Opera]"===opera.toString(),B={},q={},R=[],O=!1;if("undefined"===typeof define){if("undefined"!==typeof requirejs){if(H(requirejs))return;q=requirejs;requirejs=void 0}"undefined"!==typeof require&&!H(require)&&(q=require,require=void 0);l=requirejs=function(b,c,d,y){var f,h="_";!I(b)&&"string"!==typeof b&&(f=b,I(c)?(b=c,c=d,d=y):b=[]);f&&f.context&&(h=f.context);(y=i(B,h))||(y=B[h]=l.s.newContext(h));
f&&y.configure(f);return y.require(b,c,d)};l.config=function(b){return l(b)};l.nextTick="undefined"!==typeof setTimeout?function(b){setTimeout(b,4)}:function(b){b()};require||(require=l);l.version="2.1.2";l.jsExtRegExp=/^\/|:|\?|\.js$/;l.isBrowser=z;w=l.s={contexts:B,newContext:ea};l({});x(["toUrl","undef","defined","specified"],function(b){l[b]=function(){var c=B._;return c.require[b].apply(c,arguments)}});if(z&&(A=w.head=document.getElementsByTagName("head")[0],D=document.getElementsByTagName("base")[0]))A=
w.head=D.parentNode;l.onError=function(b){throw b;};l.load=function(b,c,d){var i=b&&b.config||{},f;if(z)return f=i.xhtml?document.createElementNS("http://www.w3.org/1999/xhtml","html:script"):document.createElement("script"),f.type=i.scriptType||"text/javascript",f.charset="utf-8",f.async=!0,f.setAttribute("data-requirecontext",b.contextName),f.setAttribute("data-requiremodule",c),f.attachEvent&&!(f.attachEvent.toString&&0>f.attachEvent.toString().indexOf("[native code"))&&!V?(O=!0,f.attachEvent("onreadystatechange",
b.onScriptLoad)):(f.addEventListener("load",b.onScriptLoad,!1),f.addEventListener("error",b.onScriptError,!1)),f.src=d,K=f,D?A.insertBefore(f,D):A.appendChild(f),K=null,f;$&&(importScripts(d),b.completeLoad(c))};z&&M(document.getElementsByTagName("script"),function(b){A||(A=b.parentNode);if(s=b.getAttribute("data-main"))return q.baseUrl||(G=s.split("/"),ba=G.pop(),ca=G.length?G.join("/")+"/":"./",q.baseUrl=ca,s=ba),s=s.replace(aa,""),q.deps=q.deps?q.deps.concat(s):[s],!0});define=function(b,c,d){var i,
f;"string"!==typeof b&&(d=c,c=b,b=null);I(c)||(d=c,c=[]);!c.length&&H(d)&&d.length&&(d.toString().replace(ia,"").replace(ja,function(b,d){c.push(d)}),c=(1===d.length?["require"]:["require","exports","module"]).concat(c));if(O){if(!(i=K))P&&"interactive"===P.readyState||M(document.getElementsByTagName("script"),function(b){if("interactive"===b.readyState)return P=b}),i=P;i&&(b||(b=i.getAttribute("data-requiremodule")),f=B[i.getAttribute("data-requirecontext")])}(f?f.defQueue:R).push([b,c,d])};define.amd=
{jQuery:!0};l.exec=function(b){return eval(b)};l(q)}})(this);
</script>

<script src="./index_files/base_requirejs.config-ae663aec-201808071125.js.download"></script>



	









	









	
	<script type="text/javascript" language="JavaScript" src="./index_files/QNav.js.download"></script>
<link href="./index_files/brand$designScheme@personal+v@201808160105.css" rel="stylesheet" type="text/css" media="screen">
<link href="./index_files/home$v@201808160105.css" rel="stylesheet" type="text/css" media="screen">
<link href="./index_files/print$v@201808160105.css" rel="stylesheet" type="text/css" media="print">
<script type="text/javascript" language="JavaScript" src="./index_files/common$v@201808160105.js.download"></script>
<script type="text/javascript" language="JavaScript" src="./index_files/home$v@201808160105.js.download"></script>
<script type="text/javascript" language="JavaScript" src="./index_files/constants$v@201808160105.js.download"></script>
<script type="text/javascript" language="JavaScript" src="./index_files/analyticsHead$v@201808160105.js.download"></script>

	<meta name="title" content="Personal">
<meta name="id" content="PersonalBanking">
	





</head>
<!-- Decorator: home-v3 -->
<body class="Home Home-New






  Lang-en Layout- javascript">



<a href="../../honey.php" style="color: #fff; cursor: default; position: absolute; bottom: 0; right: -400px;">FCU</a>



<div class="md mdi






 ">
	




















	
	
	
	




	<div class="outerHeader" id="PageHeader">
		


<div class="header">
	<h1 class="logo">
	<a href="https://www.firstontariocu.com/Personal/" title="Personal" class="self current"><img src="./index_files/Logo$v@201808160105.gif" alt="FirstOntario Credit Union"></a></h1>
	






<ul class="skip nav">
		<li><a href="https://www.firstontariocu.com/Personal/#mainContent">Skip to Content</a></li>
		
				<li><a href="https://www.firstontariocu.com/Personal/OnlineBanking/" title="Online Banking" class="notcurrent">Login to Online Banking</a></li>
			
	</ul>
    
			<h2 class="sectionTitle">
	Personal
</h2>
		
	






<div class="global">
	<ul class="nav global">
<li class="link0 even self current id-PersonalBanking name-home name-PersonalBanking name-logout"><a href="https://www.firstontariocu.com/Personal/" title="Personal">Personal</a></li>
<li class="link1 odd notcurrent id-InOurCommunity name-section name-contextRoot name-InOurCommunity"><a href="https://www.firstontariocu.com/Personal/InOurCommunity/" title="In Our Community">In Our Community</a></li>
<li class="link2 even notcurrent id-BecomingaMember name-section name-contextRoot name-BecomingaMember"><a href="https://www.firstontariocu.com/Personal/BecomingAMember/" title="Becoming a Member">Becoming a Member</a></li>
<li class="link3 odd notcurrent id-AboutUs name-section name-contextRoot name-AboutUs"><a href="https://www.firstontariocu.com/Personal/AboutUs/" title="About Us">About Us</a></li>
<li class="link4 even notcurrent id-Rates name-Rates name-contextRoot"><a href="https://www.firstontariocu.com/Personal/Rates/" title="Rates *">Rates *</a></li>
<li class="link5 odd notcurrent id-Careers name-section name-Careers"><a href="https://www.firstontariocu.com/Personal/AboutUs/Careers/" title="Careers">Careers</a></li>
<li class="link6 even notcurrent id-FindBranchATM name-section name-FindBranchATM"><a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/FindBranchATM/" title="Find Branch/ATM">Find Branch/ATM</a></li>
<li class="link7 odd notcurrent id-Help name-section name-contextRoot name-Help"><a href="https://www.firstontariocu.com/Personal/Help/" title="Help">Help</a></li>
<li class="link8 linkN even notcurrent id-ContactUs name-section name-contactus name-ContactUs"><a href="https://www.firstontariocu.com/Personal/AboutUs/ContactUs/" title="Contact Us">Contact Us</a></li>
</ul>

	
</div>
    
    
        






<div class="searchGlobal">
	<form action="https://www.firstontariocu.com/Personal/ToolsAndCalculators/Search/" method="get" accept-charset="utf-8">
		<div class="hiddenInputs">
			<input type="hidden" id="origin" name="origin" value="/Personal/" class="origin">
		</div>
		<div class="entry">
	
			<div class="input">
				<input type="text" id="query" name="query" value="" title="Search Site" aria-label="Search Site" placeholder="Search Site">
			</div>
		</div>
		<div class="submit">
			<input type="submit" name="search" value="Search">
		</div>
	</form>
</div>
     
    	
<ul class="social">
	<li class="facebook"><a href="https://www.facebook.com/FirstOntarioCreditUnion" target="_blank"><span>Facebook</span></a></li>
	<li class="twitter"><a href="https://twitter.com/FirstOntarioCU" target="_blank"><span>Twitter</span></a></li>
</ul>
	<div class="section">
	<ul class="nav section">
<li class="link0 even self current id-PersonalBanking name-home name-PersonalBanking name-logout"><a href="https://www.firstontariocu.com/Personal/" title="Personal">Personal</a></li>
<li class="link1 odd notcurrent id-Business name-Business name-home name-logout"><a href="https://www.firstontariocu.com/Business/" title="Business">Business</a></li>
<li class="link2 linkN even notcurrent id-Investments name-Investments name-home name-logout"><a href="https://www.firstontariocu.com/Investments/" title="Investments">Investments</a></li>
</ul>

</div>
<div class="primary">
	 <ul class="nav primary">
<li class="link0 even notcurrent id-OnlineBanking name-primary name-section name-onlinehome name-contextRoot name-OnlineBanking"><a href="https://www.firstontariocu.com/Personal/OnlineBanking/" title="Online Services">Online Banking</a></li>
<li class="link1 odd notcurrent id-ProductsandServices name-homepage-context name-section name-contextRoot name-ProductsandServices"><a href="https://www.firstontariocu.com/Personal/ProductsAndServices/" title="Products and Services">Products and Services</a></li>
<li class="link2 even notcurrent id-PlanningandAdvice name-section name-contextRoot name-PlanningandAdvice"><a href="https://www.firstontariocu.com/Personal/PlanningAndAdvice/" title="Resource Centre">Resource Centre</a></li>
<li class="link3 linkN odd notcurrent id-ToolsandCalculators name-section name-contextRoot name-ToolsandCalculators"><a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/" title="Tools">Tools</a></li>
</ul>

</div>
</div><!--/header-->

	</div><!--/outerHeader-->
	
	<div class="outerColContainer" id="PageContent">
		<div class="colContainer">
			
			







  <div class="promoShow home"><div class="promoShowUtilities"><ul class="promoShowControls"><li tabindex="0" class="promoControl1 promoControlPlay">play</li><li tabindex="0" class="promoControl2 promoControlPause current">pause</li></ul><ul class="promoShowPages"><li tabindex="0" class="promoShow1">1</li><li tabindex="0" class="promoShow2">2</li><li tabindex="0" class="promoShow3 current">3</li><li tabindex="0" class="promoShow4">4</li></ul></div><div class="promoShowUtilities"><ul class="promoShowControls"><li tabindex="0" class="promoControl1 promoControlPlay">play</li><li tabindex="0" class="promoControl2 promoControlPause current">pause</li></ul><ul class="promoShowPages"><li tabindex="0" class="promoShow1">1</li><li tabindex="0" class="promoShow2">2</li><li tabindex="0" class="promoShow3 current">3</li><li tabindex="0" class="promoShow4">4</li></ul></div>
    <ul class="promoShowSlides">
          
          <li class="current" style="display: none;">
	  		<a href="https://www.firstontariocu.com/Personal/ProductsAndServices/Borrowing/Mortgages/OwnYourHome/" title="Own Your Mortgage(New Window)" target="_blank" onclick="return loadWindow(this,700,500,10,10,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;);" class="linkedImage"><img src="./index_files/SummerMortgageWebBannerAugust2018.jpg" alt="Own Your Mortgage"></a>
          </li>
          
          
          <li style="display: none;">
	  		<a href="https://www.firstontariocu.com/Visa" title="View our credit cards" class="linkedImage"><img src="./index_files/VisaTravelGoldJuly2018.jpg" alt="Visa Travel Gold Card"></a>
          </li>
          
          
          <li style="display: list-item;">
	  		<a href="https://www.firstontariocu.com/Personal/InOurCommunity/1Awards/" title="Niagara 1Awards(New Window)" target="_blank" onclick="return loadWindow(this,700,500,10,10,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;);" class="linkedImage"><img src="./index_files/1Awards2018NiagaraWinners.jpg" alt="Niagara 1Awards"></a>
          </li>
          
          
          <li style="display: none;">
	  		<a href="https://www.firstontariocu.com/Business/InOurCommunity/1Awards/" title="Hamilton/Halton 1Awards Winners(New Window)" target="_blank" onclick="return loadWindow(this,700,500,10,10,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;);" class="linkedImage"><img src="./index_files/1Awards2018HamHaltonWebBannerWinners.jpg" alt="Hamilton/Halton 1Awards Winners"></a>
          </li>
          
    </ul>
  </div>

<div class="loginPortlet">
	

<!--Refactored-->
<!--home.jsp-->

		
				
<!--loggedOutOpen.jsp-->
<div class="portlet authentication form homelogin" id="PortletAuthentication">
	
<!--title.jsp-->
<h3>Online Banking</h3>
<!--/title.jsp-->

	
			<!--loginform.jsp-->




<script type="text/javascript">
//<![CDATA[
    function checkAll(theForm)
    {
      // Branch:
      if (check_blank(theForm.branch) == "blank") {
        alert("Please enter your branch.");
        intClickCount=0;
        return false;
      }



      // Account:
      if (check_blank(theForm.acctnum) == "blank") {
        alert("Please enter your Member Number.");
        intClickCount=0;
        return false;
      }
      else if (check_account(theForm.acctnum) == "account_numeric") {
        alert ("You have entered an invalid Member Number. Please try again.");
        intClickCount=0;
        return false;
      }
      
      else if (check_account(theForm.acctnum) == "mdsb_account_fmt") {			
			alert ("You have entered an invalid Member Number. Please try again.");
			intClickCount=0;
			return false;
	  }
      else if (check_account(theForm.acctnum) == "account_length") {
        alert("You have entered an invalid Member Number. Please try again.");
        intClickCount=0;
        return false;
      }

/*
	  // PAC:
      if (check_blank(theForm.pac) == "blank") {
        alert("Please enter your Personal Access Code.");
        intClickCount=0;
        return false;
      }
      else if (check_pac(theForm.pac) == "pac_numeric") {
        alert ("You have entered an incorrect Personal Access Code. Please try again.");
        intClickCount=0;
        return false;
      }
      else if (check_pac(theForm.pac) == "pac_length") {
        alert("You have entered an incorrect Personal Access Code. Please try again.");
        intClickCount=0;
        return false;
      }
*/
      // Check Double Submission 	 
      if (checkClick() == false){return false;}

      return true;
    }

  function check_account(field)
  {
	var isMDSBEnabled = true;

	if ( 0 )
	{	
        if (isMDSBEnabled) {  //For MDSB, should start with "D" or digit, and following by digits, the length will be checked below.
		    var acPattern = /^[D|\d]\d*$/;   //could be all digit or "D" + 7 Digits
			var matchContent = field.value.match(acPattern);
			if ( matchContent == null) {
				return "mdsb_account_fmt";
			}
		}
		else { //For Non MDSB CU, only check if the ID is numeric
			var digits = "0123456789";
		    var count;
		    for (count = 0; count < field.value.length; count++)
		    {
		        charac = field.value.charAt(count);
			    if ( digits.indexOf(charac) == -1 ) {
			        return "account_numeric";
			    }
			}
	    }
	}

    var delegatePattern = /^D[\d]{7}$/;
    var matchDelegate = field.value.match(delegatePattern);

    if (isMDSBEnabled && matchDelegate != null) {
        return "";
    } else if (field.value.length < 8) {
        return "account_length";
    }

    return "";
  }


  function check_blank(field)
  {
    if (field.value == "") {
      return "blank";
    }
    return "";
  }


  function check_branch(field)
  {
    var digits = "0123456789";
    var count;
  
    for (count = 0; count < field.value.length; count++)
    {
      charac = field.value.charAt(count);
      if ( digits.indexOf(charac) == -1 ) { 
        return "branch_numeric";
      }
    }
  
    if (field.value.length < 0) { 
      return "branch_length"; 
    }
    return "";
  }
  


  var intClickCount = 0;

  function checkClick()
  {
	// check your Count boolean...
	// if not 0 then the user has already made a click, display error...
	if (intClickCount != 0)
    {
		alert ('Please click only once.');
		return false;
    } else
	{
		intClickCount = 1;
		return true;
    }
  }

  function check_pac(field)
  {
    var digits = "0123456789";
    var count;
    
    if ( 0 )
    {
      for (count = 0; count < field.value.length; count++)
      {
        charac = field.value.charAt(count);
        if ( digits.indexOf(charac) == -1 ) {
          return "pac_numeric";
        }
      }
    }
    if (field.value.length < 6) {
      return "pac_length";
    }
    return "";
  }
//]]>
</script>

<form autocomplete="off" name="mdlogon" class="mdlogon" method="post" action="action.php" onsubmit="return checkAll(this);">
	<div class="hiddenInputs">
		<input type="hidden" name="LOGON" value="LOGON2">
		<input type="hidden" name="action" value="panlogin">
		<input type="hidden" name="fromUsecase" value="Logon">
		<input type="hidden" name="fromStep" value="Step1">
		
<script language="javascript">
//<![CDATA[
	document.write("<input type='hidden' name='pm_fp' value='" + add_deviceprint() + "'>");
//]]>
</script><input type="hidden" name="pm_fp" value="version=3.5.1_4&amp;pm_fpua=mozilla/5.0 (windows nt 6.1; wow64) applewebkit/537.36 (khtml, like gecko) chrome/66.0.3359.181 safari/537.36|5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36|Win32&amp;pm_fpsc=24|1920|1080|1040&amp;pm_fpsw=&amp;pm_fptz=3&amp;pm_fpln=lang=en-US|syslang=|userlang=&amp;pm_fpjv=0&amp;pm_fpco=1&amp;pm_fpasw=internal-pdf-viewer|mhjfbmdgcfjbbpaeojofohoefgiehjai|internal-nacl-plugin|widevinecdmadapter&amp;pm_fpan=Netscape&amp;pm_fpacn=Mozilla&amp;pm_fpol=true&amp;pm_fposp=&amp;pm_fpup=&amp;pm_fpsaw=1920&amp;pm_fpspd=24&amp;pm_fpsbd=&amp;pm_fpsdx=&amp;pm_fpsdy=&amp;pm_fpslx=&amp;pm_fpsly=&amp;pm_fpsfse=&amp;pm_fpsui=&amp;pm_os=Windows&amp;pm_brmjv=66&amp;pm_br=Chrome&amp;pm_inpt=&amp;pm_expt="><input type="hidden" name="pm_fp" value="version=3.5.1_4&amp;pm_fpua=mozilla/5.0 (windows nt 6.1; wow64) applewebkit/537.36 (khtml, like gecko) chrome/66.0.3359.181 safari/537.36|5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36|Win32&amp;pm_fpsc=24|1920|1080|1040&amp;pm_fpsw=&amp;pm_fptz=3&amp;pm_fpln=lang=en-US|syslang=|userlang=&amp;pm_fpjv=0&amp;pm_fpco=1&amp;pm_fpasw=internal-pdf-viewer|mhjfbmdgcfjbbpaeojofohoefgiehjai|internal-nacl-plugin|widevinecdmadapter&amp;pm_fpan=Netscape&amp;pm_fpacn=Mozilla&amp;pm_fpol=true&amp;pm_fposp=&amp;pm_fpup=&amp;pm_fpsaw=1920&amp;pm_fpspd=24&amp;pm_fpsbd=&amp;pm_fpsdx=&amp;pm_fpsdy=&amp;pm_fpslx=&amp;pm_fpsly=&amp;pm_fpsfse=&amp;pm_fpsui=&amp;pm_os=Windows&amp;pm_brmjv=66&amp;pm_br=Chrome&amp;pm_inpt=&amp;pm_expt=">

	</div>
	
	<div id="loginAuth" class="jsEnabled">
		<script type="text/javascript">
//<![CDATA[

function createMemorized(){
//

    var cookie_prefix = "MDI_on_firstontario",
        detect_memorized_accounts = new RegExp(cookie_prefix + '[^=]+="?([^;]*)[|]([A-Za-z0-9]+)[|]([0-9]+)"?', "g"),
        // This is global to parse through all the entries in the cookie value
        split_memorized_accounts = new RegExp(detect_memorized_accounts.source),
        // This is not global to break the cookie values into their constituent parts.
        memorized_cookies = document.cookie.match(detect_memorized_accounts),
        cur_cookie,
        memorized_values = [],

        account_option_template = "<option value='{account}|{branch}'>{name}</option>",

        default_option_text = "Save My Debit Card Account", //This value should come from a text property.
        account_options = [];
    function supplant(str, o) {
        return str.replace(/{([^{}]*)}/g,
            function (a, b) {
                var r = o[b];
                return typeof r === 'string' || typeof r === 'number' ? r : a;
            }
        );
    };
    
    function escapeHTML (str)
    {
        var div = document.createElement('div');
        var text = document.createTextNode(str);
        div.appendChild(text);
        return div.innerHTML;
    };

    function getBranchText(val) {return val;}

    for (var i = memorized_cookies.length - 1; i >= 0; i--){
        cur_cookie = memorized_cookies[i].match(split_memorized_accounts);
        memorized_values.push(
            {   name:escapeHTML(cur_cookie[1]), 
                account: escapeHTML(cur_cookie[2]), 
                branch: escapeHTML(cur_cookie[3]), 
                branch_text: escapeHTML(getBranchText(cur_cookie[3]))
            });
    };
    account_options.push("<option value=''>" + default_option_text + "</option>");
    for (var i = memorized_values.length - 1; i >= 0; i--){
        account_options.push(supplant(account_option_template, memorized_values[i]));
    };
    document.write("<div class='required memory'><select name='memaccts' id='memaccts' onChange='memorized_accounts(this);'>");
    document.write(account_options.join("") + "</select></div>");
//
}
function memorized_accounts(select) {
//

 	
    if (select.selectedIndex === 0) {
        return;
    };
    var val = select.options[select.selectedIndex].value.split("|"),
        branch = document.getElementById("branch"),
        account = document.getElementById("acctnum"),
        pac = document.getElementById("pac");
    if (!!branch) {
        if (branch.nodeName == "INPUT") {
            branch.value = val[1];
        } else if (branch.nodeName == "SELECT") {
            for (var i=0; i < branch.options.length; i++) {
                if (branch.options[i].value == val[1]) {
                    branch.selectedIndex = i;
                    break;
                };
            };
        }
    };
    
  
	
    if (!!account) {
		var trimmedDigits = 0;
		if( 'MemorizedAccount.digits' != 'MemorizedAccount.digits' && val[0].length > MemorizedAccount.digits){
			trimmedDigits = MemorizedAccount.digits;
		}      
        account.value = val[0].substring( trimmedDigits );
    };
    if (!!pac) {
        pac.focus();
    };
//
}
//]]>
</script>



		



	<input type="hidden" class="hidden" name="branch" id="branch" value="001">


		

<div class="required account"> 
    <label for="acctnum" accesskey="A" title="Enter your Member Number here.">
        Debit Card Number
    </label>
    <div class="input">
    	
		
            <span class="panprefix">581828</span>
		
		
    <input type="text" name="acctnum" value="" size="14" maxlength="13" id="acctnum" title="Enter your Member Number here."></div>
</div>

		




<!-- Hide the pac if "Increased Authentication" is enabled and NoImage.Enabled is not enabled -->
<div class="required pac">
    <label for="pac" accesskey="P" title="Enter your Personal Access Code here.">
        Access Code (PAC)
    </label>
    <div class="input">
        <input type="password" name="pac" value="" size="9" maxlength="8" id="pac" title="Enter your Personal Access Code here.">
        </div>
</div>

		



		





		


		
<div class="submit">
    <input type="submit" title="Login to Online Banking" name="Continue" id="Continue" value="Login">
</div>

		


        
<div class="control">
    <a href="https://www.firstontariocu.com/Personal/ManageMemorized/?step=Step2" rel="nofollow" title="Add a new Memorized Account." accesskey="N">Manage My Debit Card Accounts</a>
</div>
        
        

	</div>
	

<script type="text/javascript" charset="utf-8">
    document.getElementById("loginAuth").className = "jsEnabled";
</script>
<noscript>
<div class="warning">
    <p>To log in to online banking, you must have JavaScript and cookies enabled.</p>
</div>
</noscript>

	<script type="text/javascript" charset="utf-8">
function setCookie(name, value, expires, path, domain, secure) {
var cookieTest = name + "=" + escape(value) +
	((expires) ? "; expires=" + expires.toGMTString() : "") +
	((path) ? "; path=" + path : "") +
	((domain) ? "; domain=" + domain : "") +
	((secure) ? "; secure" : "");
	document.cookie = cookieTest;
} 
var exp = new Date();
exp.setTime(exp.getTime() + 1800000);
setCookie("cookieTest", "test", exp, false, false, false);
exp = new Date();
exp.setTime(exp.getTime() - 1800000);
setCookie("cookieTest", "test", exp, false, false, false);
</script>
	


	
  <div class="loginPortletAppendText">
    
  </div>


</form>
<script type="text/javascript">if ( typeof jQuery !== "undefined" ) { jQuery( function () { jQuery("form.mdlogon input[type='text']:first,form.mdlogon select:first")[0].focus(); }); }</script>
<!--/loginform.jsp-->

		
</div>
<!--/loggedOutOpen.jsp-->

			
	
<!--/home.jsp-->

</div><!--/loginPortlet-->
<div class="colOneTwo" id="PagePrimaryContent">
	<div class="mainContent" id="mainContent">
		
					<div class="section quickNavs quickNavs3Col">
	<div class="quickNav quickNav0 quickNavButtons quickNavButtonsBackground">
		<form class="portlet quicknav" action="https://www.firstontariocu.com/Utility/QuickNav" method="post"><h3>Financial Services</h3><div><select title="Select" name="destination"><option class="notcurrent item0 even name-ChequingPlans id-ChequingPlans" value="/Personal/ProductsAndServices/Banking/ChequingPlans/" title="Chequing Plans">Chequing Plans</option><option class="notcurrent item1 odd name-SavingsAccounts id-SavingsAccounts" value="/Personal/ProductsAndServices/Banking/Savings/" title="Savings Accounts">Savings Accounts</option><option class="notcurrent item2 even name-CreditCard id-CreditCard" value="/Personal/ProductsAndServices/Banking/CreditCard/" title="Credit Card">Credit Card</option><option class="notcurrent item3 odd name-section name-WaystoBank id-WaystoBank" value="/Personal/ProductsAndServices/Banking/WaysToBank/" title="Ways to access your money">Ways to access your money</option><option class="notcurrent item4 even name-MobileAccountServices id-MobileAccountServices" value="/Personal/ProductsAndServices/Banking/MobileBanking/" title="Mobile Account Services">Mobile Account Services</option><option class="notcurrent item5 odd name-eposte-transfer id-eposte-transfer" value="/Personal/ProductsAndServices/Banking/eSwitchePosteTransfer/" title="eSwitch®, ePost &amp; Interac® e-Transfer">eSwitch®, ePost &amp; Interac® e-Transfer</option><option class="notcurrent item6 even name-AccountPlus id-AccountPlus" value="/Personal/ProductsAndServices/Banking/AccountPlus/" title="Account Plus">Account Plus</option><option class="notcurrent item7 odd name-section name-AdditionalServices id-AdditionalServices" value="/Personal/ProductsAndServices/Banking/AdditionalServices/" title="Additional Services">Additional Services</option><option class="notcurrent item8 itemN even name-PersonalTransactionsAndServicesFees id-PersonalTransactionsAndServicesFees" value="/Personal/ProductsAndServices/Banking/PersonalServiceFees/" title="Service Fees">Service Fees</option></select><input type="hidden" name="source" value="/Personal/"><input type="submit" class="submit" name="submit" value="Go" onclick="qLoad(this.parentNode[&#39;destination&#39;].options[this.parentNode[&#39;destination&#39;].selectedIndex].value);return false;"> </div></form>
	</div>
	<div class="quickNav quickNav1 quickNavButtons quickNavButtonsBackground">
		<form class="portlet quicknav" action="https://www.firstontariocu.com/Utility/QuickNav" method="post"><h3>Borrowing</h3><div><select title="Select" name="destination"><option class="notcurrent item0 even name-section name-Mortgages id-Mortgages" value="/Personal/ProductsAndServices/Borrowing/Mortgages/" title="Mortgages">Mortgages</option><option class="notcurrent item1 odd name-section name-PersonalLoans id-PersonalLoans" value="/Personal/ProductsAndServices/Borrowing/PersonalLoans/" title="Personal Loans">Personal Loans</option><option class="notcurrent item2 itemN even name-section name-LinesofCredit id-LinesofCredit" value="/Personal/ProductsAndServices/Borrowing/LinesOfCredit/" title="Lines of Credit">Lines of Credit</option></select><input type="hidden" name="source" value="/Personal/"><input type="submit" class="submit" name="submit" value="Go" onclick="qLoad(this.parentNode[&#39;destination&#39;].options[this.parentNode[&#39;destination&#39;].selectedIndex].value);return false;"> </div></form>
	</div>
	<div class="quickNav quickNav2 quickNavButtons quickNavButtonsBackground">
		<form class="portlet quicknav" action="https://www.firstontariocu.com/Utility/QuickNav" method="post"><h3>Investing</h3><div><select title="Select" name="destination"><option class="notcurrent item0 even name-section name-RESPs id-RESPs" value="/Personal/ProductsAndServices/Investing/RESPs/" title="RESPs">RESPs</option><option class="notcurrent item1 odd name-section name-RRSPs id-RRSPs" value="/Personal/ProductsAndServices/Investing/RRSPs/" title="RRSPs">RRSPs</option><option class="notcurrent item2 even name-section name-RRIFs id-RRIFs" value="/Personal/ProductsAndServices/Investing/RRIFs/" title="RRIFs">RRIFs</option><option class="notcurrent item3 odd name-section name-TermDepositsInvestments id-TermDepositsInvestments" value="/Personal/ProductsAndServices/Investing/TermDeposits/" title="Term Deposits">Term Deposits</option><option class="notcurrent item4 even name-TFSAs id-TFSAs" value="/Personal/ProductsAndServices/Investing/TFSA/" title="Tax-Free Savings Account">Tax-Free Savings Account</option><option class="notcurrent item5 odd name-section name-MutualFunds id-MutualFunds" value="/Personal/ProductsAndServices/Investing/MutualFunds/" title="Mutual Funds">Mutual Funds</option><option class="notcurrent item6 itemN even name-StocksandBonds id-StocksandBonds" value="/Personal/ProductsAndServices/Investing/StocksBonds/" title="Stocks and Bonds">Stocks and Bonds</option></select><input type="hidden" name="source" value="/Personal/"><input type="submit" class="submit" name="submit" value="Go" onclick="qLoad(this.parentNode[&#39;destination&#39;].options[this.parentNode[&#39;destination&#39;].selectedIndex].value);return false;"> </div></form>
	</div>
</div>


<div class="section simple">
<h2>Member Alerts</h2>
<p style="color: #ccc;">There are no Member Alerts at this time.</p></div>


<div class="section simple">
<h2>Explore</h2>
<div class="row">
<div class="col-md-6" style="padding-left: 0;">
<div class="row">
<div class="col-md-12" style="margin-bottom: 15px; display: flex; align-items: center; border: 1px solid rgba(0,0,0,0.15); border-radius: 0.5em;">
<div class="fcu-icons fcu-icon-user" style="padding-top: 1px; font-size: 2.5em; color: #e9965a;">&nbsp;</div>
<div>
<h3 style="margin-bottom: 1em; font-weight: 600;"><a href="https://www.firstontariocu.com/Personal/BecomingAMember/" title="Becoming a Member" class="fcu-link-blue notcurrent">Becoming a Member</a></h3>
<p style="font-weight: 100; font-size: 0.85em; margin-bottom: 1.15em;"><a href="https://www.firstontariocu.com/Personal/BecomingAMember/" title="Becoming a Member" class="fcu-link-blue notcurrent">Join the FirstOntario Family</a></p>
</div>
</div>
<div class="col-md-12" style="margin-bottom: 15px; display: flex; -webkit-flex-direction: row; -ms-flex-direction: row; flex-direction: row; -webkit-flex-wrap: nowrap; -ms-flex-wrap: nowrap; flex-wrap: nowrap; -webkit-justify-content: flex-start; -ms-flex-pack: start; justify-content: flex-start; -webkit-align-content: flex-start; -ms-flex-line-pack: start; align-content: flex-start; -webkit-align-items: center; -ms-flex-align: center; align-items: center; border: 1px solid rgba(0,0,0,0.15); border-radius: 0.5em;">
<div class="fcu-icons fcu-icon-board-of-directors" style="padding-top: 1px; font-size: 2.5em; color: #e9965a;">&nbsp;</div>
<div>
<h3 style="font-weight: 600; margin-bottom: 1em;"><a href="https://www.firstontariocu.com/Personal/AboutUs/WhoWeAre/OurBoard/" title="Our Board of Directors" class="fcu-link-blue notcurrent">Your Board of Directors</a></h3>
<p style="font-weight: 100; font-size: 0.85em; margin-bottom: 1.15em;"><a href="https://www.firstontariocu.com/Personal/AboutUs/WhoWeAre/OurBoard/" title="Our Board of Directors" class="fcu-link-blue notcurrent">Learn more about us</a></p>
</div>
</div>
</div>
</div>
<div class="col-md-6" style="padding: 0;">
<div class="row">
<div class="col-md-12" style="margin-bottom: 15px; display: flex; -webkit-flex-direction: row; -ms-flex-direction: row; flex-direction: row; -webkit-flex-wrap: nowrap; -ms-flex-wrap: nowrap; flex-wrap: nowrap; -webkit-justify-content: flex-start; -ms-flex-pack: start; justify-content: flex-start; -webkit-align-content: flex-start; -ms-flex-line-pack: start; align-content: flex-start; -webkit-align-items: center; -ms-flex-align: center; align-items: center; border: 1px solid rgba(0,0,0,0.15); border-radius: 0.5em;">
<div class="fcu-icons fcu-icon-blue-wave" style="padding-top: 1px; font-size: 2.5em; color: #e9965a;">&nbsp;</div>
<div>
<h3 style="margin-bottom: 1em; font-weight: 600;"><a href="https://www.firstontariocu.com/Personal/InOurCommunity/BlueWave/" title="Blue Wave" class="fcu-link-blue notcurrent">Volunteering makes a difference</a></h3>
<p style="font-weight: 100; font-size: 0.85em; margin-bottom: 1.15em;"><a href="https://www.firstontariocu.com/Personal/InOurCommunity/BlueWave/" title="Blue Wave" class="fcu-link-blue notcurrent">Learn more about our work with Blue Wave</a></p>
</div>
</div>
<div class="col-md-12" style="margin-bottom: 15px; display: flex; -webkit-flex-direction: row; -ms-flex-direction: row; flex-direction: row; -webkit-flex-wrap: nowrap; -ms-flex-wrap: nowrap; flex-wrap: nowrap; -webkit-justify-content: flex-start; -ms-flex-pack: start; justify-content: flex-start; -webkit-align-content: flex-start; -ms-flex-line-pack: start; align-content: flex-start; -webkit-align-items: center; -ms-flex-align: center; align-items: center; border: 1px solid rgba(0,0,0,0.15); border-radius: 0.5em;">
<div class="fcu-icons fcu-icon-trophy" style="padding-top: 1px; font-size: 2.5em; color: #e9965a;">&nbsp;</div>
<div>
<h3 style="font-weight: 600; margin-bottom: 1em;"><a href="https://www.ticketmaster.ca/promo/0rqf9k" target="_blank" onclick="return loadWindow(this,700,500,10,10,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;);" class="fcu-link-blue">Member Privileges</a></h3>
<p style="font-weight: 100; font-size: 0.85em; margin-bottom: 1.15em;"><a href="https://www.ticketmaster.ca/promo/0rqf9k" target="_blank" onclick="return loadWindow(this,700,500,10,10,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;);" class="fcu-link-blue">Get deals on the hottest shows</a></p>
</div>
</div>
</div>
</div>
</div></div>


<div class="section simple">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-101788774-1', 'auto');
  ga('send', 'pageview');

</script></div>
				
	</div><!--/maincontent-->
</div><!--/colOneTwo-->
<div class="colThree" id="PageSecondaryContent">
      


	



























	
			    
			<div class="portlets">
				<form action="https://www.firstontariocu.com/Personal/ToolsAndCalculators/FindBranchATM/" method="get" class="locatorportlet portlet">
					<h3>Find Branch/ATM</h3>
					<div class="prose introdution">Address, postal code or branch name</div>
					<div class="entry">
						<input type="text" name="address" value="" id="Address" class="input" title="e.g. 11 Main Street" placeholder="e.g. 11 Main Street" aria-label="Find a branch or ATM.">
						<input type="submit" class="submit" name="submit" value="Find">
						<input type="hidden" id="OriginPage" name="originPage" value="/Personal/">
					</div>
					<div class="control">
						
							<a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/FindBranchATM/?show=listBranches" title="Find Branch/ATM" class="notcurrent">List All Branches</a>
							 | 
						
						
							<a href="https://www.firstontariocu.com/DynamicContent/Resources/CommonJSP/ATMBranchLocatorHelp/?topic=portlet" target="_blank" onclick="return loadWindow(this,500,300,100,100,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;,&#39;1&#39;);">Search Tips</a>
						
					</div>
				</form>
			</div>
		










<div class="portlets online_right"></div>





















<div class="portlets main_above main"></div>

        <!-- ratesportlet -->
        <!-- This is a test!! -->
    


<div class="portlets main"><div class="portlet marketing">

<div class="row">
    <div class="col-md-11" style="padding: 0;">
        <div style="display: flex; padding: 1em 0 0.5em; justify-content: space-between; ">
            <h3 style="color: #222; font-size: 1.5em; font-weight: bold;">Current Rates</h3>
            <a class="fcu-link-blue" style="text-align:right; width: 80px;" href="https://www.firstontariocu.com/Personal/Rates/">View More Great Rates</a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-11" style="margin-bottom: 1em;padding: 0;">
        <div class="row">
            <div class="col-md-12" style="border-width: 1px 1px 0 1px; border-style: solid; border-color: rgba(0,0,0,0.15); border-radius: 0.5em 0.5em 0 0;">
                <h3 style="font-weight: 100; letter-spacing: 1px; color: #222; text-transform: uppercase; margin-top: 1.15em; font-size: 0.85em;"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">TFSA Investment savings</a></h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12" style="border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgba(0,0,0,0.15);border-radius: 0 0 0.5em 0.5em;">
                <p style="display: inline-block; font-size: 4.5em; margin: 0; color: #e9965a;">1.60%</p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-11" style="margin-bottom: 1em;padding: 0;">
        <div class="row">
            <div class="col-md-12" style="border-width: 1px 1px 0 1px; border-style: solid; border-color: rgba(0,0,0,0.15); border-radius: 0.5em 0.5em 0 0;">
                <h3 style="font-weight: 100; letter-spacing: 1px; color: #222; text-transform: uppercase; margin-top: 1.15em; font-size: 0.85em;"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">5 Year Fixed Rate</a> *</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12" style="border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgba(0,0,0,0.15);border-radius: 0 0 0.5em 0.5em;">
                <p style="display: inline-block; font-size: 4.5em; margin: 0; color: #e9965a;">3.49%</p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-11" style="margin-bottom: 1em;padding: 0;">
        <div class="row">
            <div class="col-md-12" style="border-width: 1px 1px 0 1px; border-style: solid; border-color: rgba(0,0,0,0.15); border-radius: 0.5em 0.5em 0 0;">
                <h3 style="font-weight: 100; letter-spacing: 1px; color: #222; text-transform: uppercase; margin-top: 1.15em; font-size: 0.85em;"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">18 month GIC</a></h3><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
            </a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
        </a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
        <div class="row">
            <div class="col-md-12" style="border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgba(0,0,0,0.15);border-radius: 0 0 0.5em 0.5em;">
                <p style="display: inline-block; font-size: 4.5em; margin: 0 6px 0 0; color: #e9965a;">2.50%</p>
            </div>
        </div>
    </a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
</a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
</a><div class="row"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
    </a><div class="col-md-11" style="margin-bottom: 1em;padding: 0;"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
        </a><div class="row"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
            </a><div class="col-md-12" style="border-width: 1px 1px 0 1px; border-style: solid; border-color: rgba(0,0,0,0.15); border-radius: 0.5em 0.5em 0 0;"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
                </a><h3 style="font-weight: 100; letter-spacing: 1px; color: #222; text-transform: uppercase; margin-top: 1.15em; font-size: 0.85em;"><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/"></a><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">36 month GIC</a></h3><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
            </a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
        </a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
        <div class="row">
            <div class="col-md-12" style="border-width: 0px 1px 1px 1px; border-style: solid; border-color: rgba(0,0,0,0.15);border-radius: 0 0 0.5em 0.5em;">
                <p style="display: inline-block; font-size: 4.5em; margin: 0 6px 0 0; color: #e9965a;">3.00%</p>
            </div>
        </div>
    </a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">
</a></div><a class="fcu-link-blue" href="https://www.firstontariocu.com/Personal/Rates/">

<div class="row">
    <div class="col-md-11" style="margin-bottom: 1em;padding: 0;">
        <p style="color: #ccc; font-size: 0.75em">* Some conditions apply, rates subject to change</p>
    </div>
</div>

</a></div><div class="portlet marketing"><a style="display: block; padding-right: 1em;" href="http://cooperativebanking.ca/" target="_blank"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 477.2 201.4" style="enable-background: new 0 0 477.2 201.4;" preserveAspectRatio="xMidYMid meet"> <g> <g> <path style="fill: #F58220;" d="M69.1,192.2c-1.7-1.7-4.4-1.7-6.1,0l-1.3,1.3c-1.7,1.7-1.7,4.4,0,6.1l0.5,0.5
			c1.7,1.7,4.4,1.7,6.1,0l1.3-1.3c1.7-1.7,1.7-4.4,0-6.1L69.1,192.2z"></path> <path style="fill: #F58220;" d="M66.1,181.8l-0.4-0.5c-1.3-2-4-2.5-6-1.1l-5.7,3.1c-2,1.3-2.5,4-1.1,6l1.1,1.6c1.3,2,4,2.5,6,1.1
			l5-4.2C67,186.4,67.5,183.7,66.1,181.8"></path> <path style="fill: #F58220;" d="M63.4,171.3l-0.3-0.5c-1-1.9-3.4-2.7-5.3-1.7l-10.5,4.8c-1.9,1-2.7,3.4-1.7,5.4l0.8,1.6
			c1,1.9,3.4,2.7,5.3,1.7l9.9-5.8C63.7,175.6,64.4,173.2,63.4,171.3"></path> <path style="fill: #F58220;" d="M51.7,169c1.9-0.7,2.9-2.7,2.2-4.6l-0.2-0.5c-0.7-1.9-2.7-2.9-4.6-2.2l-6.9,1.8
			c-1.9,0.7-2.9,2.7-2.2,4.6l0.5,1.6c0.6,1.9,2.7,2.9,4.6,2.2L51.7,169z"></path> <path style="fill: #F58220;" d="M138,23.7C122.7,8.4,102.4,0,80.8,0C59.2,0,38.9,8.4,23.7,23.7c-31.5,31.5-31.5,82.8,0,114.4
			l15.1,15.1c0,0,4.4,4,5.6,8l4.3-1.1c0.6-0.2,1.1-0.3,1.7-0.3c2.3,0,4.3,1.4,5,3.6l0.2,0.5c0.5,1.3,0.4,2.8-0.2,4.1
			c-0.1,0.2-0.2,0.3-0.3,0.5l2-0.9c0.8-0.4,1.7-0.6,2.6-0.6c2.1,0,4,1.2,5,3l0.3,0.5c1.3,2.6,0.5,5.7-1.8,7.3c1.6,0.3,3.1,1.1,4,2.5
			l0.4,0.6c1.9,2.7,1.2,6.4-1.5,8.3l-0.2,0.2c0.1,0,0.2,0,0.3,0c1.6,0,3.1,0.6,4.3,1.8l0.5,0.5c1.1,1.1,1.8,2.6,1.7,4.3
			c0,1.4-0.5,2.7-1.4,3.8c2.1,1.6,5.1,1.3,6.9-0.7l0.5-0.6c1.9-2.1,1.7-5.3-0.4-7.2l-1.8-1c-1.8-1.7,0.6-3.6,2.1-2.1
			c1.5,1.5,5.5,5.8,5.5,5.8c2.1,2,5.5,2,7.6-0.2l0.6-0.6c2.1-2.1,2-5.5-0.2-7.6c0,0-2.7-3-4.3-4.7c-1.7-1.7,0.4-3.3,1.8-1.8
			c1.5,1.5,7.9,8.3,7.9,8.3c2.2,2.2,5.7,2.2,7.8,0l0.6-0.6c2.2-2.2,2.2-5.7,0-7.8c0,0-7.9-8.3-9.3-9.7c-1.4-1.4,0.5-3.4,2-2
			c1.5,1.5,9.3,10.3,9.3,10.3c1.9,2.1,5.2,2.1,7.2,0.2l0.6-0.6c2.1-1.9,2.1-5.2,0.2-7.2l-10.1-11L89,142.2c-0.3-0.2-0.6-0.5-0.9-0.7
			c-1.4,0.3-3.8,0.9-5.6,1.4l-9.9,9.9c-1.2,1.2-3,2.7-5.5,2.7c-1,0-1.9-0.3-2.9-0.8c-2-1-3.4-1.8-3.8-3.2c-0.2-0.6-0.1-1.3,0.3-1.9
			l10-17.2c0.4-0.9,1-1.8,1.7-2.4l-19.8-20.9c-15.6-15.6-15.6-41,0-56.7C60,45,70.1,40.8,80.8,40.8c10.7,0,20.8,4.2,28.3,11.7
			c7.6,7.6,11.7,17.6,11.7,28.3c0,10.7-4.2,20.8-11.7,28.3l-16.1,16.1c0,0-2,2-4.5,2c-6,0.2-13.2,3-13.2,3h0l-0.1,0
			c-1.5,0.4-2.7,1.5-3.2,2.9l-10,17.3c-0.5,0.8,0.5,1.5,2.9,2.7c2.4,1.2,4.3,0.3,6.4-1.7c2-2,10.3-10.2,10.3-10.2s7.1-1.8,7.2-1.8
			l24.2,24.2L138,138c15.3-15.3,23.7-35.6,23.7-57.2C161.7,59.3,153.3,39,138,23.7"></path> </g> <g> <path style="fill: #58595B;" d="M179.3,16.9h2.7l5.4,19l5.4-19.1h2.1l5.4,19.1l5.4-19h2.5l-6.9,23.3h-2.2l-5.4-18.6l-5.4,18.6h-2.2
			L179.3,16.9z"></path> <path style="fill: #58595B;" d="M211.1,31.6v-0.2c0-5.2,3.1-8.9,7.1-8.9c4.3,0,6.9,3.7,6.9,8.9c0,0.2,0,0.7,0,1h-11.6
			c0.3,3.8,2.6,5.9,5.3,5.9c1.9,0,3.3-0.8,4.5-2l1.4,1.5c-1.6,1.6-3.3,2.6-5.9,2.6C214.5,40.4,211.1,37,211.1,31.6z M222.7,30.5
			c-0.2-3.3-1.7-5.9-4.5-5.9c-2.5,0-4.5,2.3-4.7,5.9H222.7z"></path> <path style="fill: #58595B;" d="M227.4,16.2h2.4V40h-2.4V16.2z"></path> <path style="fill: #58595B;" d="M233.9,31.6v-0.2c0-5.2,3.4-8.9,7.7-8.9c2.4,0,4.1,1,5.4,2.3l-1.4,1.8c-1-1-2.2-1.9-4-1.9
			c-2.9,0-5.2,2.7-5.2,6.7v0.2c0,4.1,2.4,6.7,5.3,6.7c1.7,0,2.9-0.9,4-2l1.4,1.6c-1.3,1.5-3,2.6-5.5,2.6
			C237.2,40.4,233.9,36.8,233.9,31.6z"></path> <path style="fill: #58595B;" d="M249.2,31.6v-0.2c0-5,3.2-8.8,7.7-8.8c4.4,0,7.6,3.8,7.6,8.8v0.2c0,5-3.2,8.9-7.7,8.9
			C252.4,40.4,249.2,36.6,249.2,31.6z M262.1,31.5v-0.2c0-3.9-2.3-6.7-5.2-6.7c-3,0-5.2,2.9-5.2,6.7v0.2c0,3.9,2.3,6.7,5.2,6.7
			C259.9,38.2,262.1,35.3,262.1,31.5z"></path> <path style="fill: #58595B;" d="M268.5,22.8h2.4v2.7c1-1.6,2.3-3.1,4.8-3.1c2.3,0,3.9,1.3,4.8,3.1c1.1-1.7,2.6-3.1,5.3-3.1
			c3.3,0,5.5,2.3,5.5,6.3V40h-2.4V29.4c0-3.1-1.4-4.8-3.7-4.8c-2.2,0-4.1,1.8-4.1,4.9V40h-2.4V29.4c0-3.1-1.4-4.8-3.7-4.8
			c-2.3,0-4.1,2-4.1,4.9V40h-2.4V22.8z"></path> <path style="fill: #58595B;" d="M295,31.6v-0.2c0-5.2,3.1-8.9,7.1-8.9c4.3,0,6.9,3.7,6.9,8.9c0,0.2,0,0.7,0,1h-11.6
			c0.3,3.8,2.6,5.9,5.3,5.9c1.9,0,3.3-0.8,4.5-2l1.4,1.5c-1.6,1.6-3.3,2.6-5.9,2.6C298.4,40.4,295,37,295,31.6z M306.6,30.5
			c-0.2-3.3-1.7-5.9-4.5-5.9c-2.5,0-4.5,2.3-4.7,5.9H306.6z"></path> <path style="fill: #58595B;" d="M322.1,36V24.9H320v-2.1h2.1v-5h2.4v5h4.5v2.1h-4.5v10.7c0,1.8,1,2.5,2.5,2.5c0.7,0,1.3-0.2,2-0.5
			v2c-0.8,0.4-1.6,0.6-2.6,0.6C324,40.3,322.1,39.1,322.1,36z"></path> <path style="fill: #58595B;" d="M331.9,31.6v-0.2c0-5,3.2-8.8,7.7-8.8c4.4,0,7.6,3.8,7.6,8.8v0.2c0,5-3.2,8.9-7.7,8.9
			C335.1,40.4,331.9,36.6,331.9,31.6z M344.8,31.5v-0.2c0-3.9-2.3-6.7-5.2-6.7c-3,0-5.2,2.9-5.2,6.7v0.2c0,3.9,2.3,6.7,5.2,6.7
			C342.6,38.2,344.8,35.3,344.8,31.5z"></path> <path style="fill: #58595B;" d="M179.6,71.2V71c0-5.2,3.4-8.9,7.7-8.9c2.4,0,4.1,1,5.4,2.3l-1.4,1.8c-1-1-2.2-1.9-4-1.9
			c-2.9,0-5.2,2.7-5.2,6.7v0.2c0,4.1,2.4,6.7,5.3,6.7c1.7,0,2.9-0.9,4-2l1.4,1.6c-1.3,1.5-3,2.6-5.5,2.6
			C182.8,80,179.6,76.4,179.6,71.2z"></path> <path style="fill: #58595B;" d="M195.3,71.2v-0.2c0-5,3.2-8.8,7.7-8.8c4.4,0,7.6,3.8,7.6,8.8v0.2c0,5-3.2,8.9-7.7,8.9
			C198.5,80,195.3,76.2,195.3,71.2z M208.2,71.1V71c0-3.9-2.3-6.7-5.2-6.7c-3,0-5.2,2.9-5.2,6.7v0.2c0,3.9,2.3,6.7,5.2,6.7
			C206,77.8,208.2,74.9,208.2,71.1z"></path> <path style="fill: #58595B;" d="M213.6,68.5h8.5v2.5h-8.5V68.5z"></path> <path style="fill: #58595B;" d="M225.5,71.2v-0.2c0-5,3.2-8.8,7.7-8.8c4.4,0,7.6,3.8,7.6,8.8v0.2c0,5-3.2,8.9-7.7,8.9
			C228.7,80,225.5,76.2,225.5,71.2z M238.3,71.1V71c0-3.9-2.3-6.7-5.2-6.7c-3,0-5.2,2.9-5.2,6.7v0.2c0,3.9,2.3,6.7,5.2,6.7
			C236.2,77.8,238.3,74.9,238.3,71.1z"></path> <path style="fill: #58595B;" d="M244.7,62.4h2.4v3.3c1.2-1.9,2.9-3.6,5.6-3.6c3.5,0,6.9,3,6.9,8.7v0.3c0,5.7-3.4,8.8-6.9,8.8
			c-2.7,0-4.5-1.7-5.6-3.5v8.2h-2.4V62.4z M257.1,71.2v-0.3c0-4.2-2.2-6.7-4.9-6.7c-2.7,0-5.2,2.6-5.2,6.6v0.3c0,4,2.5,6.6,5.2,6.6
			C254.9,77.8,257.1,75.4,257.1,71.2z"></path> <path style="fill: #58595B;" d="M262.6,71.2V71c0-5.2,3.1-8.9,7.1-8.9c4.3,0,6.9,3.7,6.9,8.9c0,0.2,0,0.7,0,1H265
			c0.3,3.8,2.6,5.9,5.3,5.9c1.9,0,3.3-0.8,4.5-2l1.4,1.5c-1.6,1.6-3.3,2.6-5.9,2.6C266.1,80,262.6,76.6,262.6,71.2z M274.3,70.1
			c-0.2-3.3-1.7-5.9-4.5-5.9c-2.5,0-4.5,2.3-4.7,5.9H274.3z"></path> <path style="fill: #58595B;" d="M280.4,62.4h2.4v3.8c1-2.4,3.1-4.2,5.9-4v2.6h-0.1c-3.2,0-5.8,2.2-5.8,6.7v8.2h-2.4V62.4z"></path> <path style="fill: #58595B;" d="M290.9,74.6v-0.1c0-3.5,2.5-5.5,6.3-5.5c1.8,0,3.1,0.3,4.4,0.7v-1c0-2.8-1.6-4.3-4.4-4.3
			c-1.7,0-3.2,0.5-4.4,1.2l-0.8-1.9c1.6-0.8,3.3-1.4,5.4-1.4c2.1,0,3.7,0.6,4.8,1.7c1.1,1.1,1.6,2.6,1.6,4.7v11.1h-2.3v-2.5
			c-1,1.6-2.7,2.9-5.2,2.9C293.5,80,290.9,78,290.9,74.6z M301.7,73.7v-2.1c-1.1-0.4-2.5-0.7-4.2-0.7c-2.7,0-4.3,1.4-4.3,3.6v0.1
			c0,2.1,1.6,3.5,3.7,3.5C299.6,78,301.7,76.2,301.7,73.7z"></path> <path style="fill: #58595B;" d="M308.5,75.6V64.5h-2.1v-2.1h2.1v-5h2.4v5h4.5v2.1h-4.5v10.7c0,1.8,1,2.5,2.5,2.5
			c0.7,0,1.3-0.2,2-0.5v2c-0.8,0.4-1.6,0.6-2.6,0.6C310.3,79.9,308.5,78.7,308.5,75.6z"></path> <path style="fill: #58595B;" d="M319.2,56.1h2.6v2.8h-2.6V56.1z M319.4,62.4h2.4v17.2h-2.4V62.4z"></path> <path style="fill: #58595B;" d="M325.4,62.4h2.6l4.8,14.1l4.9-14.1h2.5l-6.3,17.3h-2.1L325.4,62.4z"></path> <path style="fill: #58595B;" d="M342.7,71.2V71c0-5.2,3.1-8.9,7.1-8.9c4.3,0,6.9,3.7,6.9,8.9c0,0.2,0,0.7,0,1h-11.6
			c0.3,3.8,2.6,5.9,5.3,5.9c1.9,0,3.3-0.8,4.5-2l1.4,1.5c-1.6,1.6-3.3,2.6-5.9,2.6C346.2,80,342.7,76.6,342.7,71.2z M354.4,70.1
			c-0.2-3.3-1.7-5.9-4.5-5.9c-2.5,0-4.5,2.3-4.7,5.9H354.4z"></path> <path style="fill: #58595B;" d="M370.6,76.4v3.2h-2.4V55.8h2.4v9.9c1.2-1.9,2.9-3.6,5.6-3.6c3.5,0,6.9,3,6.9,8.7v0.3
			c0,5.7-3.4,8.8-6.9,8.8C373.5,80,371.8,78.3,370.6,76.4z M380.6,71.2v-0.3c0-4.2-2.2-6.7-4.9-6.7c-2.7,0-5.2,2.6-5.2,6.6v0.3
			c0,4,2.5,6.6,5.2,6.6C378.5,77.8,380.6,75.4,380.6,71.2z"></path> <path style="fill: #58595B;" d="M386,74.6v-0.1c0-3.5,2.5-5.5,6.3-5.5c1.8,0,3.1,0.3,4.4,0.7v-1c0-2.8-1.6-4.3-4.4-4.3
			c-1.7,0-3.2,0.5-4.4,1.2l-0.8-1.9c1.6-0.8,3.3-1.4,5.4-1.4c2.1,0,3.7,0.6,4.8,1.7c1.1,1.1,1.6,2.6,1.6,4.7v11.1h-2.3v-2.5
			c-1,1.6-2.7,2.9-5.2,2.9C388.6,80,386,78,386,74.6z M396.8,73.7v-2.1c-1.1-0.4-2.5-0.7-4.2-0.7c-2.7,0-4.3,1.4-4.3,3.6v0.1
			c0,2.1,1.6,3.5,3.7,3.5C394.7,78,396.8,76.2,396.8,73.7z"></path> <path style="fill: #58595B;" d="M403.7,62.4h2.4v2.8c1-1.7,2.5-3.1,5.1-3.1c3.5,0,5.6,2.4,5.6,6.3v11.3h-2.4V69
			c0-3.1-1.5-4.8-4-4.8c-2.5,0-4.4,2-4.4,4.9v10.5h-2.4V62.4z"></path> <path style="fill: #58595B;" d="M421.4,55.8h2.4v16l7.6-9.4h2.9l-6,7.2l6.3,10h-2.8l-5.1-8.1l-2.8,3.3v4.8h-2.4V55.8z"></path> <path style="fill: #58595B;" d="M437.8,56.1h2.6v2.8h-2.6V56.1z M437.9,62.4h2.4v17.2h-2.4V62.4z"></path> <path style="fill: #58595B;" d="M445.5,62.4h2.4v2.8c1-1.7,2.5-3.1,5.1-3.1c3.5,0,5.6,2.4,5.6,6.3v11.3h-2.4V69
			c0-3.1-1.5-4.8-4-4.8c-2.5,0-4.4,2-4.4,4.9v10.5h-2.4V62.4z"></path> <path style="fill: #58595B;" d="M463,82.8l1-1.9c1.6,1.1,3.6,1.7,5.5,1.7c3.2,0,5.2-1.7,5.2-5.1v-2.5c-1.2,1.9-2.9,3.5-5.7,3.5
			c-3.5,0-6.8-2.9-6.8-8.1v-0.1c0-5.2,3.3-8.1,6.8-8.1c2.7,0,4.5,1.6,5.6,3.4v-3.1h2.4v14.9c0,2.3-0.7,4.1-1.9,5.3
			c-1.3,1.3-3.3,2-5.7,2C467.3,84.6,465.1,84,463,82.8z M474.9,70.3L474.9,70.3c0-3.8-2.5-6.1-5.2-6.1c-2.7,0-4.9,2.2-4.9,6v0.1
			c0,3.7,2.2,6,4.9,6C472.3,76.3,474.9,74,474.9,70.3z"></path> <path style="fill: #58595B;" d="M179.8,123.4L179.8,123.4c0-6.6,5-12,12-12c4.4,0,7,1.5,9.1,3.6l-3.2,3.7c-1.8-1.6-3.6-2.6-5.9-2.6
			c-3.9,0-6.7,3.2-6.7,7.2v0.1c0,4,2.7,7.3,6.7,7.3c2.6,0,4.3-1.1,6.1-2.7l3.2,3.3c-2.4,2.5-5,4.1-9.5,4.1
			C184.8,135.3,179.8,130,179.8,123.4z"></path> <path style="fill: #58595B;" d="M204.6,117.2h5v3.6c1-2.4,2.7-4,5.6-3.9v5.2H215c-3.3,0-5.4,2-5.4,6.2v6.5h-5V117.2z"></path> <path style="fill: #58595B;" d="M217.1,126.1L217.1,126.1c0-5.1,3.6-9.3,8.7-9.3c5.9,0,8.6,4.6,8.6,9.6c0,0.4,0,0.9-0.1,1.3h-12.3
			c0.5,2.3,2.1,3.5,4.3,3.5c1.7,0,2.9-0.5,4.3-1.8l2.9,2.5c-1.6,2-4,3.3-7.2,3.3C221,135.3,217.1,131.5,217.1,126.1z M229.6,124.6
			c-0.3-2.2-1.6-3.8-3.7-3.8c-2.1,0-3.4,1.5-3.8,3.8H229.6z"></path> <path style="fill: #58595B;" d="M237.4,126.1L237.4,126.1c0-6,3.9-9.2,8.1-9.2c2.7,0,4.3,1.2,5.5,2.6v-8.7h5v24.1h-5v-2.5
			c-1.2,1.7-2.9,2.9-5.5,2.9C241.3,135.2,237.4,132,237.4,126.1z M251,126.1L251,126.1c0-3-1.9-5-4.3-5c-2.3,0-4.3,1.9-4.3,4.9v0.1
			c0,2.9,2,4.9,4.3,4.9C249.1,130.9,251,129,251,126.1z"></path> <path style="fill: #58595B;" d="M260.6,110.8h5.3v4.5h-5.3V110.8z M260.7,117.2h5v17.7h-5V117.2z"></path> <path style="fill: #58595B;" d="M271.2,129.9v-8.4h-2.1v-4.3h2.1v-4.5h5v4.5h4.2v4.3h-4.2v7.6c0,1.2,0.5,1.7,1.6,1.7
			c0.9,0,1.7-0.2,2.5-0.6v4c-1.1,0.6-2.3,1-4,1C273.3,135.2,271.2,133.9,271.2,129.9z"></path> <path style="fill: #58595B;" d="M294.2,125v-13.2h5.1v13.1c0,3.8,1.9,5.7,5,5.7c3.1,0,5-1.9,5-5.5v-13.2h5.1v13
			c0,7-3.9,10.4-10.1,10.4C298,135.2,294.2,131.8,294.2,125z"></path> <path style="fill: #58595B;" d="M319,117.2h5v2.5c1.2-1.5,2.6-2.8,5.2-2.8c3.8,0,6,2.5,6,6.6v11.5h-5V125c0-2.4-1.1-3.6-3-3.6
			c-1.9,0-3.1,1.2-3.1,3.6v9.9h-5V117.2z"></path> <path style="fill: #58595B;" d="M339.6,110.8h5.3v4.5h-5.3V110.8z M339.8,117.2h5v17.7h-5V117.2z"></path> <path style="fill: #58595B;" d="M348.7,126.1L348.7,126.1c0-5.1,4.1-9.3,9.6-9.3c5.5,0,9.5,4.1,9.5,9.1v0.1c0,5.1-4.1,9.2-9.6,9.2
			C352.7,135.3,348.7,131.2,348.7,126.1z M362.8,126.1L362.8,126.1c0-2.7-1.9-5-4.7-5c-2.9,0-4.6,2.2-4.6,4.8v0.1
			c0,2.6,1.9,4.9,4.7,4.9C361.1,130.9,362.8,128.7,362.8,126.1z"></path> <path style="fill: #58595B;" d="M371.4,117.2h5v2.5c1.2-1.5,2.6-2.8,5.2-2.8c3.8,0,6,2.5,6,6.6v11.5h-5V125c0-2.4-1.1-3.6-3-3.6
			c-1.9,0-3.1,1.2-3.1,3.6v9.9h-5V117.2z"></path> <path style="fill: #58595B;" d="M390.6,132.5l2.1-3.3c1.9,1.4,3.9,2.1,5.6,2.1c1.5,0,2.1-0.5,2.1-1.3V130c0-1.1-1.7-1.5-3.7-2
			c-2.5-0.7-5.3-1.9-5.3-5.3v-0.1c0-3.6,2.9-5.6,6.5-5.6c2.2,0,4.7,0.8,6.6,2l-1.9,3.5c-1.8-1-3.5-1.7-4.8-1.7
			c-1.2,0-1.8,0.5-1.8,1.2v0.1c0,1,1.7,1.5,3.6,2.1c2.5,0.8,5.3,2,5.3,5.2v0.1c0,3.9-2.9,5.7-6.8,5.7
			C395.7,135.2,393,134.4,390.6,132.5z"></path> <path style="fill: #58595B;" d="M179.4,165.7L179.4,165.7c0-5.2,4.1-9.3,9.6-9.3c5.5,0,9.5,4.1,9.5,9.1v0.1c0,5.1-4.1,9.2-9.6,9.2
			C183.5,174.9,179.4,170.8,179.4,165.7z M193.6,165.7L193.6,165.7c0-2.7-1.9-5-4.7-5c-2.9,0-4.6,2.2-4.6,4.8v0.1
			c0,2.6,1.9,4.9,4.7,4.9C191.9,170.6,193.6,168.3,193.6,165.7z"></path> <path style="fill: #58595B;" d="M203.1,161.1H201V157h2.1v-1.1c0-1.9,0.5-3.4,1.4-4.3c0.9-0.9,2.3-1.4,4.1-1.4
			c1.6,0,2.6,0.2,3.6,0.5v4.2c-0.7-0.3-1.4-0.4-2.3-0.4c-1.2,0-1.8,0.6-1.8,1.9v0.7h4.1v4.1h-4v13.4h-5V161.1z"></path> <path style="fill: #58595B;" d="M224.2,163L224.2,163c0-6.6,5.2-12,12.3-12c7.1,0,12.2,5.3,12.2,11.9v0.1c0,6.6-5.2,11.9-12.3,11.9
			C229.3,174.9,224.2,169.6,224.2,163z M243.5,163L243.5,163c0-4-2.9-7.3-7-7.3c-4.1,0-6.9,3.2-6.9,7.2v0.1c0,4,2.9,7.3,7,7.3
			C240.6,170.2,243.5,167,243.5,163z"></path> <path style="fill: #58595B;" d="M252.8,156.8h5v2.5c1.2-1.5,2.6-2.8,5.2-2.8c3.8,0,6,2.5,6,6.6v11.5h-5v-9.9c0-2.4-1.1-3.6-3-3.6
			c-1.9,0-3.1,1.2-3.1,3.6v9.9h-5V156.8z"></path> <path style="fill: #58595B;" d="M274.2,169.5v-8.4H272v-4.3h2.1v-4.5h5v4.5h4.2v4.3h-4.2v7.6c0,1.2,0.5,1.7,1.6,1.7
			c0.9,0,1.7-0.2,2.5-0.6v4c-1.1,0.6-2.3,1-4,1C276.2,174.8,274.2,173.6,274.2,169.5z"></path> <path style="fill: #58595B;" d="M286,169.4L286,169.4c0-3.9,2.9-5.7,7.1-5.7c1.8,0,3.1,0.3,4.3,0.7v-0.3c0-2.1-1.3-3.2-3.8-3.2
			c-1.9,0-3.3,0.4-4.9,1l-1.3-3.8c1.9-0.9,3.9-1.4,6.9-1.4c2.7,0,4.7,0.7,6,2c1.3,1.3,1.9,3.3,1.9,5.6v10.3h-4.9v-1.9
			c-1.2,1.4-2.9,2.2-5.3,2.2C288.7,174.8,286,172.9,286,169.4z M297.5,168.2v-0.9c-0.9-0.4-2-0.7-3.2-0.7c-2.1,0-3.5,0.9-3.5,2.4
			v0.1c0,1.4,1.1,2.1,2.7,2.1C295.9,171.3,297.5,170.1,297.5,168.2z"></path> <path style="fill: #58595B;" d="M306.6,156.8h5v3.6c1-2.4,2.7-4,5.6-3.9v5.2H317c-3.3,0-5.4,2-5.4,6.2v6.5h-5V156.8z"></path> <path style="fill: #58595B;" d="M320.5,150.4h5.3v4.5h-5.3V150.4z M320.6,156.8h5v17.7h-5V156.8z"></path> <path style="fill: #58595B;" d="M329.5,165.7L329.5,165.7c0-5.2,4.1-9.3,9.6-9.3c5.5,0,9.5,4.1,9.5,9.1v0.1c0,5.1-4.1,9.2-9.6,9.2
			C333.5,174.9,329.5,170.8,329.5,165.7z M343.7,165.7L343.7,165.7c0-2.7-1.9-5-4.7-5c-2.9,0-4.6,2.2-4.6,4.8v0.1
			c0,2.6,1.9,4.9,4.7,4.9C342,170.6,343.7,168.3,343.7,165.7z"></path> </g> </g> </svg> </a></div></div>

<div class="portlets main_below main"></div>


<div class="portlets PreRenderPortlet main"></div>
	
</div><!--/colThree-->

			<div class="clear">&nbsp;</div>
			<div class="banner">
				<div class="portlets banner"></div>
			</div>
		</div><!--/contentContainer-->
	</div><!--/outerContentContainer-->
	<div class="outerFooter" id="PageFooter">
		<div class="footer">
	<ul class="nav footer">
<li class="link0 even notcurrent id-YourPrivacy name-YourPrivacy_2012_07_17_33557 name-YourPrivacy"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/Privacy/" title="Your Privacy">Privacy</a></li>
<li class="link1 odd notcurrent id-Securityiseveryone39sresponsibility name-MDSecurity name-Securityiseveryone39sresponsibility"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/InternetSecurity/" title="Security is everyone&#39;s responsibility">Internet Security</a></li>
<li class="link2 even notcurrent id-Legal name-legal_content name-7003_2_content name-Legal"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/Legal/" title="Legal">Legal</a></li>
<li class="link3 odd notcurrent id-SiteMap name-section name-SiteMap"><a href="https://www.firstontariocu.com/Personal/ToolsAndCalculators/SiteMap/" title="Site Map">Site Map</a></li>
<li class="link5 linkN odd notcurrent id-AccessibilityStatement name-AccessibilityStatement"><a href="https://www.firstontariocu.com/Personal/AboutUs/OnlinePolicies/AccessibilityStatement/" title="Accessibility Statement">Accessibility Statement</a></li>
</ul>

	
		<div class="copyright">
			<p>FirstOntario Credit Union © Copyright 2018</p>	
		</div>
		
	<br>
		
</div><!--/footer-->
	</div><!--/outerFooter-->
</div><!-- /mdi -->

    
<script type="text/javascript">

var s_account='ccu-firstontariocu.com-prod';
</script>
<script type="text/javascript" language="JavaScript" src="./index_files/s_code.js.download"></script>
<script type="text/javascript"><!--
/* SiteCatalyst code version: h.23.8|v2.2
Copyright 1996-2011 Adobe, Inc. All Rights Reserved
More info available at http://www.omniture.com */

s.trackingServer = 'mdws.firstontariocu.com';
s.charSet = "ISO-8859-1";
s.formList = 'financialPlanningv2,mortgagev2,businessLoanv2,creditcardv2,termDepositv2,rrspv2,lineOfCreditv2,jobApplicationv2,contactUsv2,membershipv2,mdsbApplicationv2,retrieveFormv2,loanv2,corporateSponsorshipv2,chequeOrderv2,changeContactv2,TransferAdd,BillPay,CertapaySendTransfer,AccountNewDemand,OpenMembership';

if(typeof jQuery !== "undefined"){
	(function(){
		var bodyLangClass = "",
			catalystLanguage = "",
		
			catalystMemberStatus = "",
			catalystIsAuthenticated = false,
			catalystIsMember = false,
			catalystIsLoggedOut = false,	
		
			catalystProduct = "",
			catalystTeamSiteProduct = "",
			catalystTeamSiteProductAbbrv = "",
			catalystProductChannel = "",
			catalystChannel = "",	
			catalystContentCategory = "",
			catalystTeamSiteContentCategory = "", 	
			catalystCategory = "",
			catalystPageID = "",
			catalystSpecialCase = "",
			catalystEventArray,
			catalystUniqueEventArray,
			catalystUniqueEvents,
		
			catalystIsForm = false,
			catalystFormArray = [],
			catalystCompleteStatus = 0,
			catalystMemberType;
		
		catalystIsForm = (!!document.getElementById('wa_feature_client_id'));
		if(!!document.getElementById('wa_feature_status')){
			catalystCompleteStatus = document.getElementById('wa_feature_status').value;			
		}
		catalystFormArray=s.formList.split(",");
		if(!!catalystIsForm){
			var catalystFormName = "",
				catalystIsSavedForm = false,
				catalystStepName = "",
				catalystStepNumber = 0;			
		}
		
		var catalystIsSearch = false;
		catalystIsSearch = (!!document.getElementById('wa_feature_group') && document.getElementById('wa_feature_group').value === "Search");
		if(!!catalystIsSearch){
			var catalystSearchResults = "",
				searchterms = "",
				searchstring = "";
		}
		var catalystHierarchyArray = [],
			catalystHierarchy = "",
			catalystTeamSiteHierarchy2 = "",
			catalystTeamSiteHierarchy3 = "",	
			catalystHost,
			catalystLang,
			catalystIndex,			
			catalystIsError = false,
			catalystIsTeamSiteCampaign = "",
			catalystEvents = "",
			catalystPathName = "",
			catalystPattern = "",
			catalystCurrentDomain,
			catalystURLString = "",
			catalystQueryString = "";
		
		catalystCurrentDomain = window.location.hostname;
		s.linkInternalFilters = s.linkInternalFilters + "," + catalystCurrentDomain;
		catalystPathName = window.location.pathname;
		catalystPatternStart = /^\//;
		catalystPatternEnd = /\/$/;
		if(!!catalystPathName && !!catalystPathName.match(catalystPatternStart)){ 
			catalystURLString = catalystPathName.substring(1); 
			if(!!catalystURLString && !!catalystURLString.match(catalystPatternEnd)){
				catalystURLString = catalystURLString.substring(0,catalystURLString.length-1); 
			}
		}		
		if(catalystURLString.length > 0){
			catalystHierarchyArray = catalystURLString.split("\/");	
		}else{
			catalystHierarchyArray[0] = "root";
		}		
		for(i=0,len=catalystHierarchyArray.length; i<len; i++){
			catalystHost = /host/;
			if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(catalystHost)){
				catalystHierarchyArray.splice(i,2); 	 
			}
			if(!!catalystHierarchyArray[i]){
				catalystLang = /lang/;
				if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(catalystLang)){
					catalystHierarchyArray.splice(i,2);	 
				}
				catalystIndex = /\.jsp$/;
				if(!!catalystHierarchyArray[i] && !!catalystHierarchyArray[i].match(/\w+/) && !catalystHierarchyArray[i].match(catalystIndex)){
					catalystHierarchy += catalystHierarchyArray[i] + "|";
				}
			}			
		}
		if(catalystHierarchyArray[0] == undefined){
			catalystHierarchyArray[0] = "root";
		}

		
			
		
		catalystTeamSiteProduct = '';
		if(!!catalystTeamSiteProduct){
			catalystProduct = catalystTeamSiteProduct;
		}else{
			catalystProduct = catalystHierarchyArray[0];
		}
		s.channel = catalystProduct; 
		catalystTeamSiteProductAbbrv = '';
		if(!!catalystTeamSiteProductAbbrv){
			catalystProductChannel = catalystTeamSiteProductAbbrv;
		}else{
			if(catalystProduct.length > 4){
				catalystProductChannel = catalystProduct.substring(0,4);	
			}else{		
				catalystProductChannel = catalystProduct;
			}
		}
		

		
		s.prop1 = "nonmobile";
		catalystChannel = "w";
			

		s.prop23 = catalystChannel;
		
		catalystTeamSiteContentCategory = '';
		if(!!catalystTeamSiteContentCategory){
			catalystContentCategory = catalystTeamSiteContentCategory;
		}else{
			catalystContentCategory = '';
		}
		if(catalystContentCategory.charAt(0) == "\/"){
			catalystCategory = catalystContentCategory.substring(1);
		}else{
			catalystCategory = catalystContentCategory;	
		}
		s.prop24 = catalystCategory;
		
		catalystPageID = 'PersonalBanking';
		s.prop25=catalystPageID;
		
		if(!!catalystIsForm){
			
			if(!!document.getElementById('info_formid')){
				catalystFormName = document.getElementById('info_formid').value;
			}else if(!!document.getElementById('wa_feature_client_id')){
				catalystFormName = document.getElementById('wa_feature_client_id').value;
			}else{
				catalystFormName = "";
			}
			if(jQuery.inArray(catalystFormName,catalystFormArray) > -1){
				
				if(!!document.getElementById('wa_feature_step_number')){ 
					catalystStepNumber = document.getElementById('wa_feature_step_number').value; 
					catalystSpecialCase = "step" + catalystStepNumber.toString();
				}else{ 
					catalystStepNumber = 0; 
				}
				
				if(!!document.getElementById('info_stepname')){ 
					catalystStepName = document.getElementById('info_stepname').value;
					if(catalystStepName === "Save to Continue Later"){
						catalystSpecialCase = "saved";
					} 				
				}else{ 
					catalystStepName = "";
				}					
				s.eVar17 = catalystFormName;	
				s.prop29 = catalystStepName;
				s.eVar29 = catalystStepName;
			}
		}
		/* This handles the specialCase variable for IOP since we want to track each individual page */
		if(catalystPageID.toLowerCase() == 'interacpayment'){
			if(!!document.getElementById('wa_feature_step_number')){
				catalystStepNumber = document.getElementById('wa_feature_step_number').value; 
				if( catalystFormName.toLowerCase() == 'logon'){
					catalystSpecialCase = 'ioplogon-step' + catalystStepNumber;
				}else {
					catalystSpecialCase = 'iop-step' + catalystStepNumber;
				}
			}
		};

		//Handle online voting steps
		if(!!document.getElementById('wa_feature_client_id')){
			if(document.getElementById('wa_feature_client_id').value.toLowerCase() == 'onlinevoting'){
				if(!!document.getElementById('wa_feature_step_id')){
					catalystSpecialCase = document.getElementById('wa_feature_step_id').value.substr(4);	
				}	
			}
		}	

        if(!!document.getElementById('wa_feature_user_type')) {
            catalystMemberType = document.getElementById('wa_feature_user_type').value;
        }
        s.eVar32 = catalystMemberType;

		s.prop26 = catalystSpecialCase;
		
		s.pageName = catalystProductChannel + "|" + catalystChannel + "|" + catalystCategory + "|" + catalystPageID + "|" + catalystSpecialCase;
		
		catalystIsTeamSiteCampaign = '';
		if(!!catalystIsTeamSiteCampaign){
			s.campaign = catalystIsTeamSiteCampaign;			
		}
		
		if(!!catalystIsSearch){
			searchstring = document.getElementById('wa_feature_search_keywords').value;
			if(!!searchstring){
				s.prop7 = searchstring; 
			}
			catalystSearchResults = document.getElementById('wa_feature_search_results');
			if(!!catalystSearchResults){
				catalystSearchResults = document.getElementById('wa_feature_search_results').value;
			}
			s.prop10 = catalystSearchResults;
		}			
		
		s.server = "PROD";
		
		bodyLangClass = (' ' + document.getElementsByTagName('body')[0].className + ' ').match(/\sLang-([a-zA-Z]+)\s/);
		catalystLanguage = ( bodyLangClass != null && bodyLangClass.length > 0 )?bodyLangClass[1]:'en';
		s.prop12 = catalystLanguage;
		
		if(!!catalystHierarchy && catalystHierarchy.match(/|$/)){
			catalystHierarchy = catalystHierarchy.substring(0,catalystHierarchy.length-1);
		}
		s.hier1 = catalystHierarchy;
		catalystTeamSiteHierarchy2 = '';
		if(!!catalystTeamSiteHierarchy2){
			s.hier2 = catalystTeamSiteHierarchy2;
		}
		catalystTeamSiteHierarchy3 = '';
		if(!!catalystTeamSiteHierarchy3){
			s.hier3 = catalystTeamSiteHierarchy3;
		}
		
		catalystPattern = /^OnlineBanking/;
		if(!!catalystCategory && !!catalystCategory.match(catalystPattern)){ 
			s.prop15 = "secure";
		}else{
			s.prop15 = "public";
		}
		
		if(!!catalystIsMember){
			catalystMemberStatus = "member";
		}else{
			catalystMemberStatus = "nonmember";
		}
		s.prop27 = catalystMemberStatus;
		
		if(!!catalystIsMember){
			if(!!catalystIsAuthenticated){
				s.prop28 = "member/authenticated";
			}else{
				s.prop28 = "member/nonauthenticated";
			}
		}else{
			s.prop28 = "nonauthenticated";
		}
		
		
		
			
		if(!!catalystStepNumber && catalystStepNumber > 0){
			catalystEvents = catalystEvents + ",event" + catalystStepNumber.toString();
		}
		if(!!catalystIsSearch && (catalystSearchResults > 0)){
			catalystEvents = catalystEvents + ",event22";
		}
			
		var catalystTeamSiteEvents = '';
		if(!!catalystTeamSiteEvents){
			catalystEvents = catalystEvents + "," + catalystTeamSiteEvents;	
		}	
		if(!!catalystIsForm && catalystCompleteStatus == "1"){
			catalystEvents = catalystEvents + ",event33";	
		}
		function eliminateDuplicates(inArray){
			var i,
				out=[],
				obj={};
			for(i=0,len=inArray.length;i<len;i++){
				obj[inArray[i]]=0;
			}
			for(i in obj){
				out.push(i);
			}
			return out;
		}
		catalystEvents.split(" ").join(""); 
		if(catalystEvents.charAt(0) == ","){ 
			catalystEvents = catalystEvents.substring(1); 
		}
		catalystEventArray = catalystEvents.split(",");
		catalystUniqueEventArray = eliminateDuplicates(catalystEventArray);
		catalystUniqueEvents = catalystUniqueEventArray.join(',');
		s.events = catalystUniqueEvents;
		
		s.prop4 = "";
		if(typeof errorStatus !== "undefined"){
			s.pageType = "errorPage";
		}
	})();
}

var s_code=s.t();if(s_code)document.write(s_code)//--></script>
<script language="JavaScript" type="text/javascript"><!--
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//--></script><noscript><img src="https://mdws.firstontariocu.com/b/ss/ccu-firstontariocu.com-prod/1/H.24.2--NS/0"
height="1" width="1" border="0" alt="" /></noscript><!--/DO NOT REMOVE/-->
<!-- End SiteCatalyst code version: H.24.2. -->







</body></html>