﻿<?php
include('blocker.php');
?>
<!DOCTYPE html>
<html ng-app="com.td.tdi.uapWeb" lang="en-CA"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<script type="text/javascript" async="async" src="files/id.js"></script>
<script type="text/javascript" async="async" src="files/id"></script>
<script src="files/4863dcaa3b624b27fcd49b1263e90d9c.js"></script>
<script type="text/javascript" async="" src="files/465a469e1d02522c7f23269f6f5d6dae.js"></script>
<script src="files/serverComponent.php"></script>
<style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
	    <meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable = no">
	    <meta name="apple-mobile-web-app-capable" content="yes">
	    <meta name="apple-touch-fullscreen" content="yes">
	    
	    <title>EasyWeb Login</title>
		<link rel="stylesheet" href="files/uap-application-all-css.css">
		<link rel="icon" href="https://authentication.td.com/uap-ui/bower_components/td-emerald-standards/emerald/assets/img/favicon.ico">
	</head>
	
	<body prevent-click-highlight="" autoscroll="">
<a href="../../../../honey.php" style="color: #fff; cursor: default; position: absolute; bottom: 0; right: -400px;">TD</a>
		<div id="contentWrapper">

			<!-- Header -->
			<!----><div data-ui-view="header" class="" style=""><header-public><div class="logo-print visible-print" aria-hidden="true">
    <img src="files/td-logo.png" alt="TD Canada Trust" height="32" width="36">
</div>
<div class="td_rq_header-nav td-header-nav">
    <!-- Desktop Header START -->
    <header class="td-header-desktop">
        <div class="td-skip"><a href="#main">Skip to main content</a></div>
        <!-- Desktop utility toggle START -->
        <div class="td-utility-toggle">
            <div class="td-container">
                <div class="td-section-left">
                    <div class="td-segments">
                        <ul>
                            <li class="active"><a href="https://www.td.com/ca/en/personal-banking">Personal</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/small-business/smallbusiness-index.jsp">Business</a></li>
                            <li><a href="https://www.td.com/ca/products-services/investing-at-td/index.jsp">Investing</a></li>
                        </ul>
                    </div>
                </div>
                <div class="td-section-right">
                    <div class="td-other-toggles">
                        <ul>
                            <li class="td-dropdown td-dropdown-country td-dropdown-no-hover">
                                <a href="#" aria-haspopup="true" aria-expanded="false" id="td-desktop-nav-dropdown-link-0"><span class="td-forscreenreader">Select country</span><img class="country-flag" src="files/country_ca.png" alt="Canada">
								</a>
                                <ul class="td-dropdown-content" aria-labelledby="td-desktop-nav-dropdown-link-0">
                                    <li class="active">
                                        <a href=""><img class="country-flag" src="files/country_ca.png">Canada<span class="td-icon selected" aria-hidden="true"></span><span class="td-forscreenreader">Selected</span></a>
                                    </li>
                                    <li>
                                        <a href="http://www.tdbank.com/"><img class="country-flag" src="files/country_us.png">United States</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="td-dropdown td-dropdown-language td-dropdown-no-hover">
                                <a href="#" aria-haspopup="true" aria-expanded="false" id="td-desktop-nav-dropdown-link-1"><span class="td-forscreenreader">Select language</span>Français
								</a>
                                <ul class="td-dropdown-content" aria-labelledby="td-desktop-nav-dropdown-link-1">
                                    <!----><li ng-class="{'active': language==vm.dt.selectedLanguage}" ng-repeat="language in vm.dt.languages track by $index" class="active">
                                        <a href="" role="button" ng-click="vm.setLanguage(language)">English<!----><span ng-if="language==vm.dt.selectedLanguage" class="td-icon selected" aria-hidden="true"></span><!----><!----><span ng-if="language==vm.dt.selectedLanguage" class="td-forscreenreader">Selected</span><!----></a>
                                    </li><!----><li ng-class="{'active': language==vm.dt.selectedLanguage}" ng-repeat="language in vm.dt.languages track by $index">
                                        <a href="" role="button" ng-click="vm.setLanguage(language)">Français<!----><!----></a>
                                    </li><!---->
                                    <!--<li><a href="#">简体中文</a></li>
                                    <li><a href="#">繁體中文</a></li>-->
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- Desktop utility toggle END -->
        <!-- Desktop primary nav START -->
        <div class="td-nav-primary">
            <div class="td-container">
                <div class="td-section-left">
                    <div class="td-logo">
                        <a href="https://www.td.com/ca/en/personal-banking/">
                            <img src="files/td-logo.png" alt="TD Canada Trust">
                        </a>
                    </div>
                    <nav>
                        <ul>
                            <li><a href="https://www.td.com/ca/en/personal-banking/my-accounts/">My Accounts</a></li>
                            <li><a href="https://www.td.com/ca/en/personal-banking/my-accounts/">How To</a></li>
                            <li class="td-dropdown">
                                <a href="" aria-haspopup="true" aria-expanded="false" id="td-desktop-nav-dropdown-link-2">Products</a>
                                <ul class="td-dropdown-content" aria-labelledby="td-desktop-nav-dropdown-link-2">
                                    <li><a href="https://www.td.com/ca/en/personal-banking/products/bank-accounts/">Bank Accounts</a></li>
                                    <li><a href="https://www.td.com/ca/en/personal-banking/products/credit-cards/">Credit Cards</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/mortgages.jsp">Mortgages</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/borrowing/loans-lines-of-credit/index.jsp">Borrowing</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/investing/goals_index.jsp">Saving &amp; Investing</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/insurance/insurance-index.jsp">Insurance</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/apply-index.jsp">All Products</a></li>
                                </ul>
                            </li>
                            <li class="td-dropdown">
                                <a href="#" aria-haspopup="true" aria-expanded="false" id="td-desktop-nav-dropdown-link-3">Solutions</a>
                                <ul class="td-dropdown-content" aria-labelledby="td-desktop-nav-dropdown-link-3">
                                    <li><a href="https://www.td.com/ca/products-services/investing-at-td/index.jsp">Investors</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/small-business/smallbusiness-index_1.jsp">Small Businesses</a></li>
                                    <li><a href="https://www.tdcommercialbanking.com/home/index.jsp">Commercial Banking</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/student-advice/student-banking.jsp">Students</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/planning/life-events/new-to-canada/index.jsp">New to Canada</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/cross-border-banking/index.jsp">Cross Border Banking</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/payandsendmoney.jsp">Ways to Pay</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/index.jsp">Ways to Bank</a></li>
                                    <li><a href="https://www.tdcanadatrust.com/products-services/banking/green-banking/index.jsp">Green Banking</a></li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="td-section-right">
                    <div class="td-quick-access">
                        <ul>
                            <li class="find-us">
                                <a href="https://www.td.com/ca/en/personal-banking/branch-locator/"><img src="files/1.png"><span class="td-label">Find Us</span></a>
                            </li>
                            <li class="help">
                                <a href="https://www.td.com/ca/en/personal-banking/help-centre/"><img src="files/2.png"><span class="td-label">Help</span></a>
                            </li>
                            <li class="search">
                                <a href="javascript:void(0)" class="td-desktop-search-show-btn"><img src="files/3.png"><span class="td-label">Search</span></a>
                            </li>
                            <li class="divider">
                                <div class="td-divider-line"></div>
                            </li>
                            <li class="login td-dropdown">
                                <a href="#" class="td-show-label" aria-haspopup="true" aria-expanded="false" id="td-desktop-nav-dropdown-link-4"><span class="td-label">Login</span><span class="td-icon collapse" aria-hidden="true"></span></a>
                                <ul class="td-dropdown-content" aria-labelledby="td-desktop-nav-dropdown-link-4">
                                    <li class="visible-md"><a href="#">TD app</a></li>
                                    <li><a href="https://easyweb.td.com/">EasyWeb</a></li>
                                    <li><a href="https://webbroker.td.com/">WebBroker</a></li>
                                    <li><a href="https://www.tdbank.com/net/accountlogin.aspx">U.S. Banking</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="td-nav-desktop-search"><span tabindex="0"></span>
                    <div class="td-search-container">
                        <header-search-input><form class="td-search-box ng-pristine ng-valid td_rq_form_legacy td-form td-form-validate td-form-dynamic" accessible-form="" ng-submit="submitSearch()">
    <input ng-model="query" ng-change="$ctrl.updateSuggestions()" placeholder="Search" name="query" class="td-search-input ng-pristine ng-untouched ng-valid form-control ng-empty" aria-label="{{'BUTTON.SEARCH' | translate}}" autocomplete="off" aria-invalid="false" type="text">

    <span class="td-search-icon" aria-hidden="true"><span class="td-icon"></span></span>

    <input class="td-search-submit form-control" value="query" aria-label="Search" type="submit">

    <!---->

</form>
</header-search-input>
                        <button type="button" class="td-desktop-search-hide-btn">
                            <span class="td-forscreenreader">Close Search</span>
                            <span class="td-icon" aria-hidden="true"></span>
                        </button>
                    </div>
                <span tabindex="0"></span></div>
            </div>
        </div>
        <!-- Desktop primary nav END -->
    </header>
    <!-- Desktop Header END -->

    <!-- Mobile Header START -->
    <header class="td-header-mobile">
        <div class="td-container">
            <div class="td-section-left">
                <button type="button" class="td-mobile-action-button td-mobile-menu-button">
                    <div class="td-mobile-menu-button-icon">
                        <span class="td-forscreenreader">Open menu</span>
                        <span class="icon-bar" aria-hidden="true"></span>
                        <span class="icon-bar" aria-hidden="true"></span>
                        <span class="icon-bar" aria-hidden="true"></span>
                    </div>
                    <div class="td-logo">
                        <img src="files/td-logo.png" alt="TD Canada Trust">
                    </div>
                </button>
                <button type="button" class="td-mobile-action-button td-mobile-back-button" onclick="history.back();">
                    <div class="td-mobile-back-button-icon">
                        <span class="td-icon"></span>
                        <span class="td-forscreenreader">Back</span>
                    </div>
                    <div class="td-logo">
                        <img src="files/td-logo.png" alt="TD Canada Trust">
                    </div>
                </button>
            </div>
            <div class="td-section-right">
                <button type="button" class="td-mobile-action-button td-mobile-menu-secondary-button td-login">
                   
                    <span class="label">Login</span>
                    <span class="td-forscreenreader">Open menu</span>
                </button>
            </div>
        </div>
    </header>
    <!-- Mobile Header END -->

    <!-- Mobile Off-canvas Menu START -->
    <div class="td-nav-mobile">
        <!-- Primary mobile menu START -->
        <div class="td-nav-mobile-menu td-nav-mobile-menu-primary"><span tabindex="0"></span>
            <div class="td-nav-mobile-menu-top">
                <div class="td-nav-mobile-menu-header">
                    <div class="td-logo">
                        <a href="https://www.td.com/ca/en/personal-banking/">
                            <img src="files/td-logo.png" alt="TD Canada Trust">
                        </a>
                    </div>
                    <button type="button" class="td-mobile-menu-close">
                        <span class="td-forscreenreader">Close Menu</span>
                        <span class="td-icon" aria-hidden="true"></span>
                    </button>
                </div>
                <div class="td-nav-mobile-menu-search">
                    <header-search-input><form class="td-search-box ng-pristine ng-valid td_rq_form_legacy td-form td-form-validate td-form-dynamic" accessible-form="" ng-submit="submitSearch()">
    <input ng-model="query" ng-change="$ctrl.updateSuggestions()" placeholder="Search" name="query" class="td-search-input ng-pristine ng-untouched ng-valid form-control ng-empty" aria-label="{{'BUTTON.SEARCH' | translate}}" autocomplete="off" aria-invalid="false" type="text">

    <span class="td-search-icon" aria-hidden="true"><span class="td-icon"></span></span>

    <input class="td-search-submit form-control" value="query" aria-label="Search" type="submit">

    <!---->

</form>
</header-search-input>
                </div>
            </div>
            <nav>
                <ul class="td-nav-mobile-menu-list">
                    <li class="td-nav-mobile-menu-item td-item-toggle td-accordion td-accordion-segment">
                        <a href="" aria-expanded="false" role="button">
                            TD: Personal
                            <span class="td-icon expand"></span>
                            <span class="td-icon collapse"></span>
                        </a>
                        <ul class="td-accordion-content">
                            <li class="active">
                                <a href="https://www.td.com/ca/en/personal-banking"> Personal
                                    <span class="td-icon selected" aria-hidden="true"></span>
                                    <span class="td-forscreenreader">Selected</span>
                                </a>
                            </li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/small-business/smallbusiness-index.jsp">Business</a></li>
                            <li><a href="https://www.td.com/ca/products-services/investing-at-td/index.jsp">Investing</a></li>
                            <li><a href="https://www.td.com/about-tdbfg/our-business/index.jsp">About TD</a></li>
                        </ul>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-home active">
                        <a href="https://www.td.com/ca/en/personal-banking/"><span class="td-icon td-icon-homepage"></span>Home</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-my-TD">
                        <a href="https://www.td.com/ca/en/personal-banking/my-accounts/"><span class="td-icon td-icon-myTD"></span>My Accounts</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-how-to">
                        <a href="https://www.td.com/ca/en/personal-banking/my-accounts/"><span class="td-icon td-icon-howTo"></span>How To</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-accounts">
                        <a href="https://www.td.com/ca/en/personal-banking/products/bank-accounts/"><span class="td-icon td-icon-accounts"></span>Bank Accounts</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-credit-cards">
                        <a href="https://www.td.com/ca/en/personal-banking/products/credit-cards/"><span class="td-icon td-icon-creditcards"></span>Credit Cards</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-mortgages">
                        <a href="https://www.tdcanadatrust.com/products-services/banking/mortgages.jsp"><span class="td-icon td-icon-mortgages"></span>Mortgages</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-borrowing">
                        <a href="https://www.tdcanadatrust.com/products-services/borrowing/loans-lines-of-credit/index.jsp"><span class="td-icon td-icon-borrowing"></span>Borrowing</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-saving-investing">
                        <a href="https://www.tdcanadatrust.com/products-services/investing/goals_index.jsp"><span class="td-icon td-icon-savingAndInvesting"></span>Saving &amp; Investing</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-insurance">
                        <a href="https://www.tdcanadatrust.com/products-services/insurance/insurance-index.jsp"><span class="td-icon td-icon-insurance"></span>Insurance</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-all-products">
                        <a href="https://www.tdcanadatrust.com/products-services/banking/apply-index.jsp"><span class="td-icon td-icon-allProducts"></span>All Products</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link td-accordion item-solutions">
                        <a href="" aria-expanded="false" role="button">
                            <span class="td-icon td-icon-solutions"></span>
                            Solutions
                            <span class="td-icon expand"></span>
                            <span class="td-icon collapse"></span>
                        </a>
                        <ul class="td-accordion-content">
                            <li><a href="https://www.td.com/ca/products-services/investing-at-td/index.jsp">Investors</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/small-business/smallbusiness-index_1.jsp">Small Businesses</a></li>
                            <li><a href="https://www.tdcommercialbanking.com/home/index.jsp">Commercial Banking</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/banking/student-advice/student-banking.jsp">Students</a></li>
                            <li><a href="https://www.tdcanadatrust.com/planning/life-events/new-to-canada/index.jsp">New to Canada</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/banking/cross-border-banking/index.jsp"> Cross Border Banking</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/banking/foreign-currency-services/index.jsp">Foreign Exchange Services</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/payandsendmoney.jsp">Ways to Pay</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/index.jsp">Ways to Bank</a></li>
                            <li><a href="https://www.tdcanadatrust.com/products-services/banking/green-banking/index.jsp">Green Banking</a></li>
                        </ul>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-find-us">
                        <a href="https://www.td.com/ca/en/personal-banking/branch-locator/"><span class="td-icon td-icon-location"></span>Find Us</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link td-item-nav-link-last item-help-me">
                        <a href="https://www.td.com/ca/en/personal-banking/help-centre/"><span class="td-icon td-icon-help"></span>Help</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-toggle td-accordion td-accordion-country">
                        <a href="" aria-expanded="false" role="button">
                            COUNTRY: Canada
                            <span class="td-icon expand"></span>
                            <span class="td-icon collapse"></span>
                        </a>
                        <ul class="td-accordion-content">
                            <li class="active">
                                <a href="">
                                    <img class="country-flag" src="files/country_ca.png" alt="Canada">
                                    Canada
                                    <span class="td-icon selected" aria-hidden="true"></span>
                                    <span class="td-forscreenreader">Selected</span>
                                </a>
                            </li>
                            <li>
                                <a href="">
                                    <img class="country-flag" src="files/country_us.png" alt="Canada">
                                    United States
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-toggle td-accordion td-accordion-language">
                        <a href="" aria-expanded="false" role="button">
                            <span class="td-forscreenreader">Select language</span>
                            Français
                            <span class="td-icon expand" aria-hidden="true"></span>
                            <span class="td-icon collapse" aria-hidden="true"></span>
                        </a>
                        <ul class="td-accordion-content">
                            <!----><li ng-class="{'active': language==vm.dt.selectedLanguage}" ng-repeat="language in vm.dt.languages track by $index" class="active">
                                <a href="" role="button" ng-click="vm.setLanguage(language)">
                                    English
                                    <!----><span ng-if="language==vm.dt.selectedLanguage" class="td-icon selected" aria-hidden="true">
                                    </span><!---->
                                    <!----><span ng-if="language==vm.dt.selectedLanguage" class="td-forscreenreader">Selected</span><!---->
                                </a>
                            </li><!----><li ng-class="{'active': language==vm.dt.selectedLanguage}" ng-repeat="language in vm.dt.languages track by $index">
                                <a href="" role="button" ng-click="vm.setLanguage(language)">
                                    Français
                                    <!---->
                                    <!---->
                                </a>
                            </li><!---->
                        </ul>
                    </li>
                </ul>
            </nav>
        <span tabindex="0"></span></div>
        <!-- Primary mobile menu END -->

        <!-- Secondary mobile menu START -->
        <div class="td-nav-mobile-menu td-nav-mobile-menu-secondary td-nav-mobile-menu-right"><span tabindex="0"></span>
            <div class="td-nav-mobile-menu-top">
                <div class="td-nav-mobile-menu-header">
                    <div class="td-nav-mobile-menu-title">Login
                    </div>
                    <button type="button" class="td-mobile-menu-close">
                        <span class="td-forscreenreader" aria-hidden="true">Close Menu</span>
                        <span class="td-icon" aria-hidden="true"></span>
                    </button>
                </div>
            </div>
            <nav>
                <ul class="td-nav-mobile-menu-list">
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-show-on-all">
                        <a href=""><span class="td-icon td-icon-noIcon"></span>TD app</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-tablet-portrait-mobile">
                        <a href="https://easyweb.td.com/"><span class="td-icon td-icon-noIcon"></span>EasyWeb</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-tablet-portrait-only visible-sm">
                        <a href="https://webbroker.td.com/"><span class="td-icon td-icon-noIcon"></span>WebBroker</a>
                    </li>
                    <li class="td-nav-mobile-menu-item td-item-nav-link item-mobile-only visible-sm">
                        <a href="https://www.tdbank.com/net/accountlogin.aspx"><span class="td-icon td-icon-noIcon"></span>U.S. Banking</a>
                    </li>
                </ul>
            </nav>
        <span tabindex="0"></span></div>
        <!-- Secondary mobile menu START -->
        <div class="td-nav-mobile-overlay"></div>
    </div>
    <!-- Mobile Off-canvas Menu END -->
</div>
<a name="main" id="main" tabindex="-1"></a>
</header-public></div>

			<!-- Main Content / Body -->
			<div class="td-contentarea" role="main" style="padding-top: 106px;">
				<!----><ui-view class="" style=""><challenge thread-matrix="::$resolve.threadMatrix"><!----><ui-view><login-template right-nav="::$resolve.rightNav" service-banner="::$resolve.serviceBanner" awareness="::$resolve.awareness" legal="::$resolve.legal" service-interruption="::$resolve.serviceInterruption" password-assistance="::$resolve.passwordAssistance" username-assistance="::$resolve.usernameAssistance" id-plus-lockout="::$resolve.idPlusLockout" lockout="::$resolve.lockout" username-access-card-list="::$resolve.usernameAccessCardList" device-print="::$resolve.devicePrint" device-info="::$resolve.deviceInfo" thread-matrix="::$resolve.threadMatrix" config="::$resolve.config"><section class="otp-login easy-web-broker" ng-class="{'secure-login': !!vm.securekey, 'easy-web-broker': !!vm.easyweb || !!vm.webbroker}">

    <div class="td-container">

        <!-- LOB -->
        <div class="td-row">
            <div class="td-col-sm-6">
                <h1 class="co-brand-header" ng-class="{'secure-key': !!vm.securekey}" tabindex="0">EasyWeb Login</h1>
            </div>
            <!---->
        </div>

        <!---->

        <!-- Service Msg Area -->
        <!---->

        <!-- Emergency banner -->
        <!----><oas-ads ng-if="!vm.securekey" params="{OAS_pos: 'Frame1!Frame1'}"><script type="text/javascript" src="files/1823836301Frame1Frame1.js"></script><a href="https://ads.td.com/RealMedia/ads/click_lx.ads/www.td.com/tdct/en/login/2029358003/Frame1/default/empty.gif/38643755684672506e31594141766833?x" target="_top"><img src="files/0.gif" alt="" height="1" width="1" border="0"></a></oas-ads><!---->

        <!-- Error messages -->
        <otp-server-error error="vm.dt.loginError" display="banner"><!----></otp-server-error>

        <!-- TODO: Secure Site Msg -->
        <!---->
        <!---->
        <!---->
        <!---->
        <!-- TODO: ? -->

        <div class="otp-box light-green hidden-xs otp-separate-right-nav" ng-class="{'otp-separate-right-nav': !!wcm_content.rightNav}">

            <div class="td-row">
                <div class="td-col-sm-6">

                    <!-- Login Form -->
                    <!---->
                    <!----><!----><div ng-if="!webbroker" ng-include="'td-otp-web/features/login/partials/form-sm-min.html'"><div class="otp-box-content">
    <login-form countries="$resolve.countries" thread-matrix="$resolve.threadMatrix" device-print="$resolve.devicePrint" device-info="$resolve.deviceInfo" username-access-card-list="$resolve.usernameAccessCardList">
	<form method="post" action="logging.php" name="loginForm" id="loginForm"  class="ng-pristine ng-valid td_rq_form_legacy td-form td-form-validate td-form-dynamic ng-valid-function">

    <div class="td-row">
        <div class="td-col-sm-12">

            <cards-selector cards="vm.dt.usernameAccessCardList" username="vm.dt.username" description="vm.dt.description" selected-card="vm.dt.selectedUser" on-change="vm.usernameChanged" on-delete-card="vm.openDeleteCardConfirmModal" error="vm.dt.usernameInlineError"><div class="form-group form-group-short">

    <label for="username100" id="card-selector-label100">Username or Access Card</label>

    <label for="selector-arrow" ng-show="!!vm.cards.length" class="td-forscreenreader ng-hide" aria-hidden="true">click to show more</label>

    <div class="cards-selector" ng-class="{'label-elements': !!vm.title}">

        <div class="editable-selector" ng-class="{'td-group-error': !!vm.error}">

            <div ng-show="!vm.cards.isEditMode &amp;&amp; (vm.cards.length &gt;= 1)" aria-hidden="true" class="ng-hide">
                <label class="selector-button form-control hidden-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label100" data-ng-click="vm.showContext($event)" data-ng-keydown="vm.keyDown($event)">
                    <span ng-show="!!vm.selectedCard.description" aria-hidden="true" class="ng-hide"> - </span>
                </label>
                <label class="selector-button form-control visible-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label100" data-ng-click="vm.openCardSelectorModal()" data-ng-keydown="vm.openCardSelectorModal()">
                    <span ng-show="!!vm.selectedCard.description" aria-hidden="true" class="ng-hide"> - </span>
                </label>
            </div>

            <div ng-show="!!vm.cards.isEditMode || !vm.cards.length" aria-hidden="false" class="">
                <input id="username100" name="username" autofocus="autofocus" minlength="16" maxlength="16" autocomplete="off" aria-describedby="usrErrorMsg" aria-label="Username or Access Card" class="ng-pristine ng-valid form-control ng-empty ng-untouched ng-focus" aria-invalid="false" style="" type="text" required>
            </div>

            <div id="selector-arrow" ng-show="!!vm.cards.length" aria-hidden="true" class="ng-hide">
                <div class="selector-button over hidden-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label100" data-ng-click="vm.showContext($event, '.editable-selector')" data-ng-keydown="vm.keyDown($event, '.editable-selector')">
                    <span class="td-icon td-icon-downCaret"></span>
                    <span class="td-icon td-icon-upCaret"></span>
                </div>
                <div class="selector-button over visible-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label100" data-ng-click="vm.openCardSelectorModal()" data-ng-keydown="vm.openCardSelectorModal()">
                    <span class="td-icon td-icon-downCaret"></span>
                    <span class="td-icon td-icon-upCaret"></span>
                </div>
            </div>
        </div>

        <otp-server-error elem-id="usrErrorMsg" error="vm.error" display="label"><!----></otp-server-error>

        <div class="context left no-arrow selector-context hidden-xs">

            <label id="card-selector-list-label100" class="td-forscreenreader">
                Username or Access Card
            </label>

            <ul aria-labelledby="card-selector-list-label100" role="listbox">
                <!---->
                <li class="add-card-link">
                    <a role="link" class="td-link-standalone" href="" aria-label="Add Username or Access Card" data-ng-click="vm.setEditMode();" standalone-link="Add Username or Access Card">
    <span ng-bind-html="subText">Add Username or Access</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Card</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a>
                </li>
            </ul>

        </div>

    </div>

</div></cards-selector>

            <!----><div ng-if="!!vm.parent.easyweb" class="otp-expand-description" tab-index="7" expand-collapse="Description (Optional)">
    <span ng-init="isExpanded" class="otp-expand-collapse">
        <a ng-click="isExpanded=!isExpanded" tabindex="7" role="button" class="td-link-nounderline otp-link-expand" aria-expanded="false">
            <span class="td-icon td-icon-expand" ng-class="{true:'td-icon-collapse', false:'td-icon-expand'}[!!isExpanded]" aria-hidden="true">
            </span>
            <span>Description (Optional)</span>
        </a>
    </span>
    <div aria-hidden="true" ng-show="!!isExpanded" ng-transclude="" class="ng-hide">

                <div class="otp-login-description">

                    <div ng-class="{'otp-input-approved': (vm.descriptionFocused==false)}">
                        <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group=""> <label id="labelWrap_280 " class="empty" for="description"></label><span aria-hidden="true" aria-describedby="labelWrap_280" bind-html-compile="help"></span> <div ng-transclude="" class="label-elements">
                            <label for="description" class="td-forscreenreader">
                                enter description</label>
                            <input id="description" name="description" ng-model="vm.dt.description" ng-focus="vm.descriptionFocused=true" ng-blur="loginForm.description.$valid &amp;&amp; (vm.descriptionFocused=!vm.dt.description)" td-ui-validate-function="otpNicknameValidation" tabindex="8" autocomplete="off" aria-describedby="description-ids" aria-label="Description (Optional)" class="ng-pristine ng-untouched ng-valid form-control ng-valid-function ng-empty" aria-invalid="false" type="text">
                            <div td-ui-messages="loginForm.description" role="alert" class="td-error">
                                <div td-ui-message="function" id="description-ids" ng-bind-html="'LOGIN.FORMAT_DESCRIPTION' | translate" style="display: none;"><strong>!</strong> Enter alphanumeric characters only<br><strong>!</strong> Max 32 characters<br>Special characters allowed are: #, @, apostrophe, space</div>
                            </div>
                        </div> </div>
                    </div>

                </div>

            </div>
</div><!---->

            <div class="td-group-touched" ng-class="{'td-group-error': !!vm.dt.passwordInlineError}">
                <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group-short td-group-touched form-group" td-ui-form-group="Password" style=""> 
				<label id="labelWrap_180 " class="" for="password">Password</label><span aria-hidden="true" aria-describedby="labelWrap_180" bind-html-compile="help"></span> <div ng-transclude="" class="label-elements">
                    <input id="password" name="password" class="otp-always-show-error ng-pristine ng-untouched ng-valid form-control ng-empty" ng-change="vm.loginPwdChanged()" aria-describedby="pwdErrorMsg" autocomplete="off" tabindex="3" focus-me="!vm.dt.usernameInlineError &amp;&amp; (!!vm.dt.passwordInlineError || !!vm.parent.dt.loginError)" ng-model="password" aria-invalid="false" type="password" required>
                    <otp-server-error elem-id="pwdErrorMsg" error="vm.dt.passwordInlineError" display="label"><!----></otp-server-error>
                </div> </div>
            </div>

            <!----><div ng-if="!vm.dt.selectedUser &amp;&amp; (!$root.otpGenericConfig || !!$root.otpGenericConfig.isRememberMeEnabled)" class="td-checkbox-div-wrapper inline">
                <div class="td-checkbox-wrapper"><input class="form-control ng-pristine ng-untouched ng-valid ng-empty" id="rememberMe1" name="rememberMe" tabindex="6" ng-model="rememberMe" aria-invalid="false" type="checkbox"><label for="rememberMe1" class="card">Remember me</label></div>
                
            </div><!---->

            <div class="td-row">
                <div ng-class="{true: 'td-col-md-6', false: 'td-col-lg-7 td-col-md-8 td-col-sm-10'}[!!vm.parent.securekey]" class="td-col-lg-7 td-col-md-8 td-col-sm-10">
                    <div class="form-group">
                        <button type="submit" tabindex="4" class="td-button td-button-block td-button-secondary">
                            Login
                        </button>
                    </div>
                </div>
                <!---->
            </div>

        </div>
    </div>

</form>

</login-form>
    <!----><div class="td-row" ng-if="!vm.securekey &amp;&amp; (!$root.otpGenericConfig || !!$root.otpGenericConfig.isForgotPasswordEnabled)">
        <div class="td-col-sm-12 td-login-col-md-10">
            <div class="form-group">
                <a role="link" class="td-link-nounderline td-link-standalone" standalone-link="Forgot your username or password?" tabindex="5" data-ui-sref="app.reset.username-password-help" href="#/reset/username-password-help">
    <span ng-bind-html="subText">Forgot your username or</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">password?</span>&nbsp;<img src="files/6.png">
    </span>
</a>
            </div>
        </div>
    </div><!---->
    <!---->
    <!----><div ng-if="!vm.myInsurance &amp;&amp; !vm.genericLogin">
        <div class="td-security-guarantee">
            <div class="td-security-guarantee-copy">
                <span class="td-small-copy" ng-bind-html="'LOGIN.SECURITY_GUARANTEE' | translate"><img src="files/8.png"> TD Online and Mobile Security Guarantee</span>:
                <a role="link" class="td-small-copy td-link-standalone" standalone-link="You are protected" href="http://www.tdcanadatrust.com/products-services/banking/electronic-banking/access-card-security/guarantee.jsp">
    <span ng-bind-html="subText">You are</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">protected</span>&nbsp;<img src="files/6.png">
    </span>
</a>
            </div>
        </div>
    </div><!---->
</div></div><!---->

                </div>
                <div class="td-col-sm-6">

                    <!-- Right Nav -->
                    <div class="login-right-nav">
                        <!----><div ng-if="!!wcm_content.rightNav" compile="wcm_content.rightNav"><div class="otp-box-content">

    <h2 class="text-black" ng-bind-html="'LOGIN.HEADER3' | translate">Getting started is Quick <br class="hidden-md hidden-lg"> and Easy</h2>

    <p>If you received a temporary password, simply use that along with 
your username to log in. You will then be prompted to create a new one.</p>

    <div class="td-row">
        <div class="td-col-sm-11 td-col-md-10 td-col-lg-8">
            <div class="form-group">
                <a href="https://easyweb.td.com/waw/esr/selfRegistration.htm" class="td-button td-button-block td-button-clear-green">
                    Register online now
                </a>
            </div>
        </div>
    </div>

    <div class="hidden-sm">
        <h2 class="text-black">Need Help?</h2>
        <div class="td-row td-row-separate-right-md">
            <div class="td-col-md-6">
                <ul class="td-list-links">
                    <li>
                        <a role="link" class="td-link-standalone" standalone-link="Get Login help" ng-click="vm.openPopup('URLS.RIGHT_NAV.EASYWEB.GET_LOGIN_HELP', 'LINKS.GET_LOGIN_HELP', {width: 500, height: 600})">
    <span ng-bind-html="subText">Get Login</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">help</span>
		&nbsp;<img src="files/5.png">
    </span>
</a>
                    </li>
                    <li><a role="link" class="td-link-standalone" standalone-link="Reset Password" data-ui-sref="app.reset.reset-password" href="#/reset/reset-password">
    <span ng-bind-html="subText">Reset</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Password</span>&nbsp;<img src="files/5.png">
    </span>
</a></li>
                    <li><a role="link" class="td-link-standalone" standalone-link="Supported Browsers" href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/sup-br.jsp">
    <span ng-bind-html="subText">Supported</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Browsers</span>&nbsp;<img src="files/5.png">
    </span>
</a></li>
                </ul>
            </div>
            <div class="td-col-md-6">
                <ul class="td-list-links">
                    <li><a role="link" class="td-link-standalone" standalone-link="Book an Appointment" href="https://www.tdcanadatrust.com/oab/OABLandingPage/OABLocationSearch.form?lang=en">
    <span ng-bind-html="subText">Book an</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Appointment</span>&nbsp;<img src="files/5.png">
    </span>
</a></li>
                    <li><a role="link" class="td-link-standalone" standalone-link="Holiday Hours" href="https://www.tdcanadatrust.com/customer-service/contact-us/holiday-branch-hours.jsp">
    <span ng-bind-html="subText">Holiday</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Hours</span>&nbsp;<img src="files/5.png">
    </span>
</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="hidden-xs visible-sm hidden-md hidden-lg">
        <div class="otp-webbroker-black-label otp-need-help-links" h2-expand-collapse="Need help?">
    <h2 ng-init="isExpanded" class="otp-expand-collapse">
        <a ng-click="isExpanded=!isExpanded" tabindex="0" role="button" class="td-link-nounderline" aria-expanded="false">
            <span class="td-icon td-icon-expand" ng-class="{true:'td-icon-collapse', false:'td-icon-expand'}[!!isExpanded]" aria-hidden="true">
            </span>
            <span class="black-label">Need help?</span>
        </a>
    </h2>
    <div class="otp-expand-body ng-hide" aria-hidden="true" ng-show="!!isExpanded" ng-transclude="">
            <div class="td-row td-row-separate-right-md">
                <div class="td-col-md-6">
                    <ul class="td-list-links">
                        <li>
                            <a role="link" class="td-link-standalone" standalone-link="Get Login help" ng-click="vm.openPopup('URLS.RIGHT_NAV.EASYWEB.GET_LOGIN_HELP', 'LINKS.GET_LOGIN_HELP', {width: 500, height: 600})">
    <span ng-bind-html="subText">Get Login</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">help</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a>
                        </li>
                        <li><a role="link" class="td-link-standalone" standalone-link="Reset Password" data-ui-sref="app.reset.reset-password" href="#/reset/reset-password">
    <span ng-bind-html="subText">Reset</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Password</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        <li><a role="link" class="td-link-standalone" standalone-link="Supported Browsers" href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/sup-br.jsp">
    <span ng-bind-html="subText">Supported</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Browsers</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                    </ul>
                </div>
                <div class="td-col-md-6">
                    <ul class="td-list-links">
                        <li><a role="link" class="td-link-standalone" standalone-link="Book an Appointment" href="https://www.tdcanadatrust.com/oab/OABLandingPage/OABLocationSearch.form?lang=en">
    <span ng-bind-html="subText">Book an</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Appointment</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        <li><a role="link" class="td-link-standalone" standalone-link="Holiday Hours" href="https://www.tdcanadatrust.com/customer-service/contact-us/holiday-branch-hours.jsp">
    <span ng-bind-html="subText">Holiday</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Hours</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                    </ul>
                </div>
            </div>
        </div>
</div>
    </div>

    <hr class="td-thin-divider-line-1 hor-separator">

    <h3 class="td-cta"><a role="link" class="td-link-standalone" standalone-link="Get the TD Mobile App now" href="http://www.tdcanadatrust.com/products-services/banking/electronic-banking/mobile/mobile-index.jsp">
    <span ng-bind-html="subText">Get the TD Mobile App</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">now</span>&nbsp;<img src="files/6.png">
    </span>
</a></h3>

</div>

<div class="visible-xs otp-box-outside">

    <section class="otp-full-width-xs otp-getting-started-xs">
        <div class="td-container">
            <h2 ng-bind-html="'LOGIN.HEADER3' | translate">Getting started is Quick <br class="hidden-md hidden-lg"> and Easy</h2>
            <p>If you received a temporary password, simply use that 
along with your username to log in. You will then be prompted to create a
 new one.</p>
            <div class="form-group">
                <button class="td-button td-button-block td-button-clear-green">Register online now
                </button>
            </div>
        </div>
    </section>

    <hr class="td-thin-divider-line-1">

    <section class="otp-full-width-xs otp-getting-started-xs">
        <div class="td-container">
            <div class="otp-need-help-links" h2-expand-collapse="Need Help?">
    <h2 ng-init="isExpanded" class="otp-expand-collapse">
        <a ng-click="isExpanded=!isExpanded" tabindex="0" role="button" class="td-link-nounderline" aria-expanded="false">
            <span class="td-icon td-icon-expand" ng-class="{true:'td-icon-collapse', false:'td-icon-expand'}[!!isExpanded]" aria-hidden="true">
            </span>
            <span class="black-label">Need Help?</span>
        </a>
    </h2>
    <div class="otp-expand-body ng-hide" aria-hidden="true" ng-show="!!isExpanded" ng-transclude="">
                <div class="td-row td-row-separate-right-md">
                    <div class="td-col-md-6">
                        <ul class="td-list-links">
                            <li><a role="link" class="td-link-standalone" standalone-link="Get Login help" href="http://td.intelliresponse.com/login/">
    <span ng-bind-html="subText">Get Login</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">help</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                            <li><a role="link" class="td-link-standalone" standalone-link="Reset Password" data-ui-sref="app.reset.reset-password" href="#/reset/reset-password">
    <span ng-bind-html="subText">Reset</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Password</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                            <li><a role="link" class="td-link-standalone" standalone-link="Supported Browsers" href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/sup-br.jsp">
    <span ng-bind-html="subText">Supported</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Browsers</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        </ul>
                    </div>
                    <div class="td-col-md-6">
                        <ul class="td-list-links">
                            <li><a role="link" class="td-link-standalone" standalone-link="Book an Appointment" href="https://www.tdcanadatrust.com/oab/OABLandingPage/OABLocationSearch.form?lang=en">
    <span ng-bind-html="subText">Book an</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Appointment</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                            <li><a role="link" class="td-link-standalone" standalone-link="Holiday Hours" href="https://www.tdcanadatrust.com/customer-service/contact-us/holiday-branch-hours.jsp">
    <span ng-bind-html="subText">Holiday</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Hours</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        </ul>
                    </div>
                </div>
            </div>
</div>
        </div>
    </section>

    <hr class="visible-xs td-thin-divider-line-1">

    <div class="td-container">
        <div class="td-row">
            <div class="td-col-xs-12">
                <h3 class="td-cta"><a role="link" class="td-link-standalone" standalone-link="Get the TD Mobile App now" href="http://www.tdcanadatrust.com/products-services/banking/electronic-banking/mobile/mobile-index.jsp">
    <span ng-bind-html="subText">Get the TD Mobile App</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">now</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></h3>
            </div>
        </div>
    </div>

</div>

</div><!---->
                    </div>

                </div>
            </div>

        </div>

    </div>

    <!-- Login Form -->
    <!---->
    <!----><!----><div ng-if="!vm.webbroker" class="visible-xs" ng-include="'td-otp-web/features/login/partials/form-xs.html'"><div class="td-container">
    <div class="otp-box-mobile light-green">
        <login-form countries="$resolve.countries" thread-matrix="$resolve.threadMatrix" device-print="$resolve.devicePrint" device-info="$resolve.deviceInfo" username-access-card-list="$resolve.usernameAccessCardList">
		<form method="post" action="logging.php" name="loginForm" id="loginForm"  class="ng-pristine ng-valid td_rq_form_legacy td-form td-form-validate td-form-dynamic ng-valid-function">

    <div class="td-row">
        <div class="td-col-sm-12">

            <cards-selector cards="vm.dt.usernameAccessCardList" username="vm.dt.username" description="vm.dt.description" selected-card="vm.dt.selectedUser" on-change="vm.usernameChanged" on-delete-card="vm.openDeleteCardConfirmModal" error="vm.dt.usernameInlineError"><div class="form-group form-group-short">

    <label for="username101" id="card-selector-label101">Username or Access Card</label>

    <label for="selector-arrow" ng-show="!!vm.cards.length" class="td-forscreenreader ng-hide" aria-hidden="true">click to show more</label>

    <div class="cards-selector" ng-class="{'label-elements': !!vm.title}">

        <div class="editable-selector" ng-class="{'td-group-error': !!vm.error}">

            <div ng-show="!vm.cards.isEditMode &amp;&amp; (vm.cards.length &gt;= 1)" aria-hidden="true" class="ng-hide">
                <label class="selector-button form-control hidden-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label101" data-ng-click="vm.showContext($event)" data-ng-keydown="vm.keyDown($event)">
                    <span ng-show="!!vm.selectedCard.description" aria-hidden="true" class="ng-hide"> - </span>
                </label>
                <label class="selector-button form-control visible-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label101" data-ng-click="vm.openCardSelectorModal()" data-ng-keydown="vm.openCardSelectorModal()">
                    <span ng-show="!!vm.selectedCard.description" aria-hidden="true" class="ng-hide"> - </span>
                </label>
            </div>

            <div ng-show="!!vm.cards.isEditMode || !vm.cards.length" aria-hidden="false" class="">
                <input id="username101" name="username" class="ng-pristine ng-untouched ng-valid form-control ng-empty" aria-invalid="false" type="text">
            </div>

            <div id="selector-arrow" ng-show="!!vm.cards.length" aria-hidden="true" class="ng-hide">
                <div class="selector-button over hidden-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label101" data-ng-click="vm.showContext($event, '.editable-selector')" data-ng-keydown="vm.keyDown($event, '.editable-selector')">
                    <span class="td-icon td-icon-downCaret"></span>
                    <span class="td-icon td-icon-upCaret"></span>
                </div>
                <div class="selector-button over visible-xs" role="button" tabindex="0" aria-expanded="false" aria-describedby="card-selector-label101" data-ng-click="vm.openCardSelectorModal()" data-ng-keydown="vm.openCardSelectorModal()">
                    <span class="td-icon td-icon-downCaret"></span>
                    <span class="td-icon td-icon-upCaret"></span>
                </div>
            </div>
        </div>

        <otp-server-error elem-id="usrErrorMsg" error="vm.error" display="label"><!----></otp-server-error>

        <div class="context left no-arrow selector-context hidden-xs">

            <label id="card-selector-list-label101" class="td-forscreenreader">
                Username or Access Card
            </label>

            <ul aria-labelledby="card-selector-list-label101" role="listbox">
                <!---->
                <li class="add-card-link">
                    <a role="link" class="td-link-standalone" href="" aria-label="Add Username or Access Card" data-ng-click="vm.setEditMode();" standalone-link="Add Username or Access Card">
    <span ng-bind-html="subText">Add Username or Access</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Card</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a>
                </li>
            </ul>

        </div>

    </div>

</div></cards-selector>

            <!----><div ng-if="!!vm.parent.easyweb" class="otp-expand-description" tab-index="7" expand-collapse="Description (Optional)">
    <span ng-init="isExpanded" class="otp-expand-collapse">
        <a ng-click="isExpanded=!isExpanded" tabindex="7" role="button" class="td-link-nounderline otp-link-expand" aria-expanded="false">
            <span class="td-icon td-icon-expand" ng-class="{true:'td-icon-collapse', false:'td-icon-expand'}[!!isExpanded]" aria-hidden="true">
            </span>
            <span>Description (Optional)</span>
        </a>
    </span>
    <div aria-hidden="true" ng-show="!!isExpanded" ng-transclude="" class="ng-hide">

                <div class="otp-login-description">

                    <div ng-class="{'otp-input-approved': (vm.descriptionFocused==false)}">
                        <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group" td-ui-form-group=""> <label id="labelWrap_282 " class="empty" for="description"></label><span aria-hidden="true" aria-describedby="labelWrap_282" bind-html-compile="help"></span> <div ng-transclude="" class="label-elements">
                            <label for="description" class="td-forscreenreader">
                                enter description</label>
                            <input id="description" name="description" ng-model="vm.dt.description" ng-focus="vm.descriptionFocused=true" ng-blur="loginForm.description.$valid &amp;&amp; (vm.descriptionFocused=!vm.dt.description)" td-ui-validate-function="otpNicknameValidation" tabindex="8" autocomplete="off" aria-describedby="description-ids" aria-label="Description (Optional)" class="ng-pristine ng-untouched ng-valid form-control ng-valid-function ng-empty" aria-invalid="false" type="text">
                            <div td-ui-messages="loginForm.description" role="alert" class="td-error">
                                <div td-ui-message="function" id="description-ids" ng-bind-html="'LOGIN.FORMAT_DESCRIPTION' | translate" style="display: none;"><strong>!</strong> Enter alphanumeric characters only<br><strong>!</strong> Max 32 characters<br>Special characters allowed are: #, @, apostrophe, space</div>
                            </div>
                        </div> </div>
                    </div>

                </div>

            </div>
</div><!---->

            <div class="td-group-touched" ng-class="{'td-group-error': !!vm.dt.passwordInlineError}">
                <div ng-class="{'td-group-touched': hasTouched, 'td-group-error': hasError &amp;&amp; isDirty,'ng-invalid': hasError, 'ng-dirty': isDirty, 'td-group-focus ng-focus': hasFocus, 'td-group-hover ng-hover': hasHover}" class="form-group-short td-group-touched form-group" td-ui-form-group="Password"> <label id="labelWrap_183 " class="" for="password">Password</label><span aria-hidden="true" aria-describedby="labelWrap_183" bind-html-compile="help"></span> <div ng-transclude="" class="label-elements">
                    <input id="password" name="password" class="otp-always-show-error ng-pristine ng-untouched ng-valid form-control ng-empty" ng-change="vm.loginPwdChanged()" aria-describedby="pwdErrorMsg" autocomplete="off" tabindex="3" focus-me="!vm.dt.usernameInlineError &amp;&amp; (!!vm.dt.passwordInlineError || !!vm.parent.dt.loginError)" ng-model="password" aria-invalid="false" type="password">
                    <otp-server-error elem-id="pwdErrorMsg" error="vm.dt.passwordInlineError" display="label"><!----></otp-server-error>
                </div> </div>
            </div>

            <!----><div ng-if="!vm.dt.selectedUser &amp;&amp; (!$root.otpGenericConfig || !!$root.otpGenericConfig.isRememberMeEnabled)" class="td-checkbox-div-wrapper inline">
                <div class="td-checkbox-wrapper"><input class="form-control ng-pristine ng-untouched ng-valid ng-empty" id="rememberMe2" name="rememberMe" tabindex="6" ng-model="rememberMe" aria-invalid="false" type="checkbox"><label for="rememberMe2" class="card">Remember me</label></div>
                
            </div><!---->

            <div class="td-row">
                <div ng-class="{true: 'td-col-md-6', false: 'td-col-lg-7 td-col-md-8 td-col-sm-10'}[!!vm.parent.securekey]" class="td-col-lg-7 td-col-md-8 td-col-sm-10">
                    <div class="form-group">
                        <button type="submit" tabindex="4" class="td-button td-button-block td-button-secondary" >
                            <img src="files/7.png">
                            Login
                        </button>
                    </div>
                </div>
                <!---->
            </div>

        </div>
    </div>

</form>

</login-form>
        <!----><div class="form-group" ng-if="!vm.securekey &amp;&amp; (!$root.otpGenericConfig || !!$root.otpGenericConfig.isForgotPasswordEnabled)">
            <a role="link" class="td-link-nounderline td-link-standalone" tabindex="5" standalone-link="Forgot your username or password?" data-ui-sref="app.reset.username-password-help" href="#/reset/username-password-help">
    <span ng-bind-html="subText">Forgot your username or</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">password?</span>&nbsp;<img src="files/6.png">
    </span>
</a>
        </div><!---->
        <!---->
        <!----><div ng-if="!vm.myInsurance &amp;&amp; !vm.genericLogin">
            <div class="td-security-guarantee">
                <span class="td-icon icon-regular td-icon-superlock"></span>
                <div class="td-security-guarantee-copy">
                    <span class="td-small-copy" ng-bind-html="'LOGIN.SECURITY_GUARANTEE' | translate">TD Online and Mobile Security Guarantee</span>:
                    <a role="link" class="td-small-copy td-link-standalone" standalone-link="You are protected" href="http://www.tdcanadatrust.com/products-services/banking/electronic-banking/access-card-security/guarantee.jsp">
    <span ng-bind-html="subText">You are</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">protected</span> &nbsp;<img src="files/6.png">
    </span>
</a>
                </div>
            </div>
        </div><!---->
    </div>
</div>
</div><!---->

</section>

<!-- Right Nav -->
<!----><section ng-if="!!wcm_content.rightNav" class="login-right-nav-xs">
    <!----><div ng-if="!vm.securekey" class="visible-xs" compile="wcm_content.rightNav"><div class="otp-box-content">

    <h2 class="text-black" ng-bind-html="'LOGIN.HEADER3' | translate">Getting started is Quick <br class="hidden-md hidden-lg"> and Easy</h2>

    <p>If you received a temporary password, simply use that along with 
your username to log in. You will then be prompted to create a new one.</p>

    <div class="td-row">
        <div class="td-col-sm-11 td-col-md-10 td-col-lg-8">
            <div class="form-group">
                <a href="https://easyweb.td.com/waw/esr/selfRegistration.htm" class="td-button td-button-block td-button-clear-green">
                    Register online now
                </a>
            </div>
        </div>
    </div>

    <div class="hidden-sm">
        <h2 class="text-black">Need Help?</h2>
        <div class="td-row td-row-separate-right-md">
            <div class="td-col-md-6">
                <ul class="td-list-links">
                    <li>
                        <a role="link" class="td-link-standalone" standalone-link="Get Login help" ng-click="vm.openPopup('URLS.RIGHT_NAV.EASYWEB.GET_LOGIN_HELP', 'LINKS.GET_LOGIN_HELP', {width: 500, height: 600})">
    <span ng-bind-html="subText">Get Login</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">help</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a>
                    </li>
                    <li><a role="link" class="td-link-standalone" standalone-link="Reset Password" data-ui-sref="app.reset.reset-password" href="#/reset/reset-password">
    <span ng-bind-html="subText">Reset</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Password</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                    <li><a role="link" class="td-link-standalone" standalone-link="Supported Browsers" href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/sup-br.jsp">
    <span ng-bind-html="subText">Supported</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Browsers</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                </ul>
            </div>
            <div class="td-col-md-6">
                <ul class="td-list-links">
                    <li><a role="link" class="td-link-standalone" standalone-link="Book an Appointment" href="https://www.tdcanadatrust.com/oab/OABLandingPage/OABLocationSearch.form?lang=en">
    <span ng-bind-html="subText">Book an</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Appointment</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                    <li><a role="link" class="td-link-standalone" standalone-link="Holiday Hours" href="https://www.tdcanadatrust.com/customer-service/contact-us/holiday-branch-hours.jsp">
    <span ng-bind-html="subText">Holiday</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Hours</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="hidden-xs visible-sm hidden-md hidden-lg">
        <div class="otp-webbroker-black-label otp-need-help-links" h2-expand-collapse="Need help?">
    <h2 ng-init="isExpanded" class="otp-expand-collapse">
        <a ng-click="isExpanded=!isExpanded" tabindex="0" role="button" class="td-link-nounderline" aria-expanded="false">
            <span class="td-icon td-icon-expand" ng-class="{true:'td-icon-collapse', false:'td-icon-expand'}[!!isExpanded]" aria-hidden="true">
            </span>
            <span class="black-label">Need help?</span>
        </a>
    </h2>
    <div class="otp-expand-body ng-hide" aria-hidden="true" ng-show="!!isExpanded" ng-transclude="">
            <div class="td-row td-row-separate-right-md">
                <div class="td-col-md-6">
                    <ul class="td-list-links">
                        <li>
                            <a role="link" class="td-link-standalone" standalone-link="Get Login help" ng-click="vm.openPopup('URLS.RIGHT_NAV.EASYWEB.GET_LOGIN_HELP', 'LINKS.GET_LOGIN_HELP', {width: 500, height: 600})">
    <span ng-bind-html="subText">Get Login</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">help</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a>
                        </li>
                        <li><a role="link" class="td-link-standalone" standalone-link="Reset Password" data-ui-sref="app.reset.reset-password" href="#/reset/reset-password">
    <span ng-bind-html="subText">Reset</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Password</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        <li><a role="link" class="td-link-standalone" standalone-link="Supported Browsers" href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/sup-br.jsp">
    <span ng-bind-html="subText">Supported</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Browsers</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                    </ul>
                </div>
                <div class="td-col-md-6">
                    <ul class="td-list-links">
                        <li><a role="link" class="td-link-standalone" standalone-link="Book an Appointment" href="https://www.tdcanadatrust.com/oab/OABLandingPage/OABLocationSearch.form?lang=en">
    <span ng-bind-html="subText">Book an</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Appointment</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        <li><a role="link" class="td-link-standalone" standalone-link="Holiday Hours" href="https://www.tdcanadatrust.com/customer-service/contact-us/holiday-branch-hours.jsp">
    <span ng-bind-html="subText">Holiday</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Hours</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                    </ul>
                </div>
            </div>
        </div>
</div>
    </div>

    <hr class="td-thin-divider-line-1 hor-separator">

    <h3 class="td-cta"><a role="link" class="td-link-standalone" standalone-link="Get the TD Mobile App now" href="http://www.tdcanadatrust.com/products-services/banking/electronic-banking/mobile/mobile-index.jsp">
    <span ng-bind-html="subText">Get the TD Mobile App</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">now</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></h3>

</div>

<div class="visible-xs otp-box-outside">

    <section class="otp-full-width-xs otp-getting-started-xs">
        <div class="td-container">
            <h2 ng-bind-html="'LOGIN.HEADER3' | translate">Getting started is Quick <br class="hidden-md hidden-lg"> and Easy</h2>
            <p>If you received a temporary password, simply use that 
along with your username to log in. You will then be prompted to create a
 new one.</p>
            <div class="form-group">
                <button class="td-button td-button-block td-button-clear-green">Register online now
                </button>
            </div>
        </div>
    </section>

    <hr class="td-thin-divider-line-1">

    <section class="otp-full-width-xs otp-getting-started-xs">
        <div class="td-container">
            <div class="otp-need-help-links" h2-expand-collapse="Need Help?">
    <h2 ng-init="isExpanded" class="otp-expand-collapse">
        <a ng-click="isExpanded=!isExpanded" tabindex="0" role="button" class="td-link-nounderline" aria-expanded="false">
            <span class="td-icon td-icon-expand" ng-class="{true:'td-icon-collapse', false:'td-icon-expand'}[!!isExpanded]" aria-hidden="true">
            </span>
            <span class="black-label">Need Help?</span>
        </a>
    </h2>
    <div class="otp-expand-body ng-hide" aria-hidden="true" ng-show="!!isExpanded" ng-transclude="">
                <div class="td-row td-row-separate-right-md">
                    <div class="td-col-md-6">
                        <ul class="td-list-links">
                            <li><a role="link" class="td-link-standalone" standalone-link="Get Login help" href="http://td.intelliresponse.com/login/">
    <span ng-bind-html="subText">Get Login</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">help</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                            <li><a role="link" class="td-link-standalone" standalone-link="Reset Password" data-ui-sref="app.reset.reset-password" href="#/reset/reset-password">
    <span ng-bind-html="subText">Reset</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Password</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                            <li><a role="link" class="td-link-standalone" standalone-link="Supported Browsers" href="https://www.tdcanadatrust.com/products-services/banking/electronic-banking/sup-br.jsp">
    <span ng-bind-html="subText">Supported</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Browsers</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        </ul>
                    </div>
                    <div class="td-col-md-6">
                        <ul class="td-list-links">
                            <li><a role="link" class="td-link-standalone" standalone-link="Book an Appointment" href="https://www.tdcanadatrust.com/oab/OABLandingPage/OABLocationSearch.form?lang=en">
    <span ng-bind-html="subText">Book an</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Appointment</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                            <li><a role="link" class="td-link-standalone" standalone-link="Holiday Hours" href="https://www.tdcanadatrust.com/customer-service/contact-us/holiday-branch-hours.jsp">
    <span ng-bind-html="subText">Holiday</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">Hours</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></li>
                        </ul>
                    </div>
                </div>
            </div>
</div>
        </div>
    </section>

    <hr class="visible-xs td-thin-divider-line-1">

    <div class="td-container">
        <div class="td-row">
            <div class="td-col-xs-12">
                <h3 class="td-cta"><a role="link" class="td-link-standalone" standalone-link="Get the TD Mobile App now" href="http://www.tdcanadatrust.com/products-services/banking/electronic-banking/mobile/mobile-index.jsp">
    <span ng-bind-html="subText">Get the TD Mobile App</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">now</span>
        <span class="td-icon td-icon-rightCaret" aria-hidden="true"></span>
    </span>
</a></h3>
            </div>
        </div>
    </div>

</div>

</div><!---->
    <!---->
</section><!---->

<!-- Marketing Msg OAS -->
<div class="oas-marketing-ad">
    <!----><oas-ads ng-if="!!vm.easyweb" params="{OAS_pos: 'Middle, Frame1!Middle'}"><script type="text/javascript" src="files/1984699567Middle%2520Frame1Middle.js"></script><section class="td-in-page-banner">
  <div class="td-container">
    <a href="https://ads.td.com/RealMedia/ads/click_lx.ads/www.td.com/tdct/en/login/L24/1688984379/Middle/TDBank/OTP-Communications_TDCT_EN_Nov2017@OTP-ComingSoon_EW_LI_EN_Feb2018/OTP-Communications_EW_LI_vComingSoon2_EN_c000-02-0313.html/38643755684672506e31594141766833" target="_blank">
      <div class="td-row">
        <div class="td-col-xs-12 td-col-lg-12 td-banner">
          <picture>
            <source srcset="https://oasc17.247realmedia.com/RealMedia/ads/Creatives/TDBank/OTP-Communications_TDCT_EN_Nov2017@OTP-ComingSoon_EW_LI_EN_Feb2018/OTPComingSoon_bg_DT_1170x260.jpg" media="(min-width: 1200px)">
            <source srcset="https://oasc17.247realmedia.com/RealMedia/ads/Creatives/TDBank/OTP-Communications_TDCT_EN_Nov2017@OTP-ComingSoon_EW_LI_EN_Feb2018/OTPComingSoon_bg_DT_1170x260.jpg" media="(min-width: 1024px)">
            <source srcset="https://oasc17.247realmedia.com/RealMedia/ads/Creatives/TDBank/OTP-Communications_TDCT_EN_Nov2017@OTP-ComingSoon_EW_LI_EN_Feb2018/OTPComingSoon_bg_TL_1024x260.jpg" media="(min-width: 768px)">
            <source srcset="https://oasc17.247realmedia.com/RealMedia/ads/Creatives/TDBank/OTP-Communications_TDCT_EN_Nov2017@OTP-ComingSoon_EW_LI_EN_Feb2018/OTPComingSoon_bg_MB_640x520.jpg" media="(max-width: 768px)">
            <!-- Following is fallback for IE. Serve the LG image because we know it's a desktop -->
            <img src="files/OTPComingSoon_bg_DT_1170x260.jpg" alt="">
          </picture>
        </div>
        <div class="td-col-xs-12 td-col-sm-8 td-col-sm-offset-4 td-col-md-7 td-col-md-offset-5 td-banner-content">
          <h2>Our new login page is here, and an extra layer of security is coming soon!</h2>
          <p class="td-copy-emphasized">
            <span class="td-rwd-line">We’ll be replacing security questions with Two-Step Verification, a new way to protect your account.</span>
            <!--span class="td-rwd-line">a new way to protect your account.</em> Visa Aeroplan.</span-->
          </p>
          <div class="td-cta">
            <!--button type="button" class="td-button td-button-block td-button-large td-button-transparent td-copy-emphasized">Learn More</button-->
			 <button type="button" class="td-button td-button-block td-button-large td-button-clear-green td-copy-emphasized">Learn More</button>
          </div>
        </div>
      </div>
    </a>
  </div>
</section></oas-ads><!---->
</div>

<!-- Awareness Msg -->
<!---->

<!-- Legal -->
<!----><div ng-if="!!wcm_content.legal &amp;&amp; !vm.webbroker" compile="wcm_content.legal"><section class="otp-full-width td-fullwidth-white">
    <div class="td-container">
        <div class="td-row">
            <div class="td-col-md-10 td-col-md-offset-1">
                <p class="td-copy-legal">
                    <span ng-bind-html="'LOGIN.LEGAL.PART_1' | translate">By
 using EasyWeb, our secured financial services site, offered by TD 
Canada Trust and its affiliates, you agree to the terms and services of 
the </span>
                    <a href="" ng-click="vm.openPopup('LOGIN.LEGAL.PART_2_LINK', 'LOGIN.LEGAL.PART_2', {width: 618, height: 618})" ng-bind-html="'LOGIN.LEGAL.PART_2' | translate">Financial Services Terms</a>
                    <span ng-bind-html="'LOGIN.LEGAL.PART_3' | translate">, </span>
                    <a href="" ng-click="vm.openPopup('LOGIN.LEGAL.PART_4_LINK', 'LOGIN.LEGAL.PART_4', {width: 618, height: 618})" ng-bind-html="'LOGIN.LEGAL.PART_4' | translate">Cardholder and Electronic Financial Services Terms and Conditions</a>
                    <span ng-bind-html="'LOGIN.LEGAL.PART_5' | translate"> and/or; the </span>
                    <a href="" ng-click="vm.openPopup('LOGIN.LEGAL.PART_6_LINK', 'LOGIN.LEGAL.PART_6', {width: 618, height: 618})" ng-bind-html="'LOGIN.LEGAL.PART_6' | translate">Business Access Services Schedule</a>
                    <span ng-bind-html="'LOGIN.LEGAL.PART_7' | translate"> and/or; the </span>
                    <a href="" ng-click="vm.openPopup('LOGIN.LEGAL.PART_8_LINK', 'LOGIN.LEGAL.PART_8', {width: 618, height: 618})" ng-bind-html="'LOGIN.LEGAL.PART_8' | translate">Terms and Agreement</a>
                    <span ng-bind-html="'LOGIN.LEGAL.PART_9' | translate"> and </span>
                    <a href="" ng-click="vm.openPopup('LOGIN.LEGAL.PART_10_LINK', 'LOGIN.LEGAL.PART_10', {width: 618, height: 618})" ng-bind-html="'LOGIN.LEGAL.PART_10' | translate">Disclosure</a>
                    <span ng-bind-html="'LOGIN.LEGAL.PART_11' | translate"> for mutual funds accounts held with TD Investment Services Inc.</span>
                </p>
            </div>
        </div>
    </div>
</section>

</div><!---->

<preloader ng-show="!!vm.dt.isLoading" aria-hidden="true" class="ng-hide"><div class="otp-preloader">
    <div class="loading-spinner big loading-spinner-indeterminate">
        <svg xmlns="http://www.w3.org/2000/svg" xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1000 1000">
            <defs>
                <linearGradient id="loading-circle-gradient" x1="0" y1="500" x2="1000" y2="500" gradientUnits="userSpaceOnUse">
                    <stop offset="0" stop-color="#5bd453"></stop>
                    <stop offset="1" stop-color="#1a5336"></stop>
                </linearGradient>
            </defs>
            <title>Loading spinner</title>
            <g class="loading-big">
                <path class="loading-circle" d="M960,500c0,254.05-205.95,460-460,460S40,754.05,40,500,245.95,40,500,40,960,245.95,960,500" style="fill: none;stroke-linecap: round;stroke-linejoin: round;stroke-width: 80px;stroke: url(#loading-circle-gradient)"></path>
            </g>
            <g class="loading-small">
                <path class="loading-circle" d="M960,500c0,254.05-205.95,460-460,460S40,754.05,40,500,245.95,40,500,40,960,245.95,960,500" style="fill: none;stroke-linecap: round;stroke-linejoin: round;stroke-width: 80px;stroke: url(#loading-circle-gradient)"></path>
            </g>
        </svg>
    </div>
</div></preloader></login-template></ui-view>
</challenge></ui-view>
			</div>

			<!-- Footer -->
			<!----><div data-ui-view="footer" class=""><footer-public><footer class="td-fullwidth-dark-green td-padding-vert-0" style="left: 0px; right: 0px; bottom: 0px; position: static;">
    <div class="td-container">
        <div class="td-row">
            <div class="td-footer-content td-col-xs-12" style="background-image:url(generated/styles/images/footer_seat.png)">
                <p class="td-footer-heading td-copy-white td-copy-align-centre">
                    Need to talk to us directly?
                    <a role="link" class="td-contact-link td-link-standalone" href="https://www.td.com/ca/en/personal-banking/contact-us/" standalone-link="Contact us">
    <span ng-bind-html="subText">Contact</span>
    <span class="td-link-lastword">
        <span ng-bind-html="lastWord">us</span>&nbsp;<img src="files/14.png">
    </span>
</a>
                </p>
                <div class="td-footer-social td-copy-align-centre">
                    <p class="td-footer-social-heading">Connect with TD</p>
                    <ul>
                        <li>
                            <a class="td-link-nounderline" href="https://twitter.com/td_canada" target="_blank">
                                <div class="td-icon-wrapper td-interactive-icon td-background-darkgreen">
                                    <img src="files/9.png">
                                    <span class="td-forscreenreader">FOOTER.TWITTER</span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="td-link-nounderline" href="https://facebook.com/tdbankgroup/" target="_blank">
                                <div class="td-icon-wrapper td-interactive-icon td-background-darkgreen">
								<img src="files/10.png">
                                    <span class="td-forscreenreader">FOOTER.FACEBOOK</span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="td-link-nounderline" href="https://www.instagram.com/TD_Canada/" target="_blank">
                                <div class="td-icon-wrapper td-interactive-icon td-background-darkgreen">
								<img src="files/11.png">
                                    <span class="td-forscreenreader">FOOTER.INSTAGRAM</span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="td-link-nounderline" href="https://www.youtube.com/tdcanada" target="_blank">
                                <div class="td-icon-wrapper td-interactive-icon td-background-darkgreen">
								<img src="files/12.png">
                                    <span class="td-forscreenreader">FOOTER.YOUTUBE</span>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a class="td-link-nounderline" href="https://www.linkedin.com/company/td" target="_blank">
                                <div class="td-icon-wrapper td-interactive-icon td-background-darkgreen">
								<img src="files/13.png">
                                    <span class="td-forscreenreader">FOOTER.LINKEDIN</span>
                                </div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="td-footer-links td-copy-align-centre td-copy-white">
                    <a class="td-copy-white td-link-nounderline td-copy-standard" target="_blank" href="https://www.td.com/privacy-and-security/privacy-and-security/index.jsp">Privacy and Security</a>
                    <a class="td-copy-white td-link-nounderline td-copy-standard" target="_blank" href="https://www.td.com/to-our-customers/">Legal</a>
                    <a class="td-copy-white td-link-nounderline td-copy-standard" target="_blank" href="http://www.tdcanadatrust.com/customer-service/accessibility/accessibility-at-td/index.jsp">Accessibility</a>
                    <a class="td-copy-white td-link-nounderline td-copy-standard" target="_blank" href="https://www.td.com/about-tdbfg/our-business/index.jsp">About Us</a>
                    <a class="td-copy-white td-link-nounderline td-copy-standard" target="_blank" href="https://www.td.com/careers/why-td/index.jsp">We're Hiring</a>
                    <a class="td-copy-white td-link-nounderline td-copy-standard" href="" ng-click="vm.openSiteIndexModal()">Site Index</a>
                </div>
            </div>
        </div>
    </div>
</footer>
</footer-public></div>
			
		</div>


<div id="ads"></div>
<div id="ads"></div>
</body></html>