<?php require_once './crypt.php'; ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=1280">
    <meta name="msapplication-config" content="none" />
    <title>OurTime.com - The 50+ Single Network</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="57x57" href="images/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/apple-touch-icon-114x114.png" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/apple-touch-icon-144x144.png" />
    <link href="http://fonts.googleapis.com/css?family=PT+Sans:400" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=PT+Sans:700" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=PT+Sans:400italic" rel="stylesheet" type="text/css" />
    <link href="http://fonts.googleapis.com/css?family=PT+Sans:700italic" rel="stylesheet" type="text/css" />
    <link href="images/theme.css" rel="stylesheet" type="text/css" />

<style media="screen" type="text/css">
body {
    font-family: 'PT Sans', Arial, Helvetica, sans-serif;
    margin: 0px;
    padding: 0px;
    font-size: 13px;
    color: #4f4857;
}
input {
    font-family: 'PT Sans', Arial, Helvetica, sans-serif;
    font-size: 13px;
    color: #4f4857;
}
select {
    font-family: 'PT Sans', Arial, Helvetica, sans-serif;
    font-size: 13px;
    color: #4f4857;
}
textarea {
    font-family: 'PT Sans', Arial, Helvetica, sans-serif;
    font-size: 13px;
    color: #4f4857;
}
a {
    text-decoration: none
}
h1 {
    font-size: 14px;
    margin-top: 0px;
    margin-bottom: 0px;
    font-weight: normal;
}
h2 {
    font-size: 14px;
    margin-top: 0px;
    margin-bottom: 0px;
    font-weight: normal;
}
p {
    margin-top: 0px;
    margin-bottom: 0px;
}
/* Header styles */
#header {
    height: 80px;
    width: 100%;
    background-repeat: repeat-x;
}
#logo {
    display: inline;
    float: left;
}
#headercontent {
    width: 1140px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 60px;
}
/* Main content styles */
#maincontent {
    width: 1140px;
    margin-left: auto;
    margin-right: auto;
    margin-top: 8px;
    display: block;
    clear: both;
    padding: 0 60px;
}
#columnleftexternal {
    width: 820px;
    display: inline;
    float: left;
    margin-top: 12px;
}
#columnrightexternal {
    width: 300px;
    margin-left: 20px;
    display: inline;
    float: left;
    margin-top: 12px;
}
.clearfix {
    display: block;
    clear: both;
    font-size: 10px;
    margin-top: 0px;
    margin-bottom: 0px;
}
/* Footer  styles */
#footer {
    height: 75px;
    width: 100%;
    display: block;
    clear: both;
    margin-top: 30px;
}
#footercontent {
    width: 1140px;
    margin-left: auto;
    margin-right: auto;
    padding: 0 60px;
}
 #footercontent p {
     color: #645e6b
 }
#footercontentleft p {
    padding-top: 18px
}
#externallinks {
    width: 1140px;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    margin-top: 20px;
    margin-bottom: 20px;
}
#footercontentleft {
    display: inline;
    float: left;
}
#footercontentright {
    display: inline;
    float: right;
}
#externaltwitter {
    display: inline;
    float: right;
    margin-top: 17px;
    text-align: center;
    margin-right: 15px;
}
#externalfacebook {
    display: inline;
    float: right;
    margin-top: 15px;
    text-align: center;
}
#externalheaderlogin {
    width: 456px;
    height: 71px;
    display: inline;
    float: right;
}
.loginlinkexternal {
    font-size: 13px;
    font-weight: bold;
}
.externalloginspace {
    margin-top: 20px !important
}
#externalheadernologin {
    width: 456px;
    height: 71px;
    display: inline;
    float: right;
}
 #externalheadernologin p {
     width: 456px;
     display: inline;
     float: right;
     text-align: right;
     color: #FFFFFF;
     margin-top: 8px;
 }
 #externalheadernologin a {
     color: #FFFFFF
 }
#externalheaderlogin p {
    display: inline;
    float: right;
    font-size: 12px;
}
#externalheaderloginrow1 input {
    display: inline;
    float: left;
    width: 122px;
    margin-right: 8px;
}
#externalheaderlogin img {
    display: inline;
    float: left;
    margin-left: 5px;
    margin-top: 1px;
}
#externalheaderloginrow1 {
    display: block;
    clear: both;
    color: #FFFFFF;
    height: 24px;
    margin-top: 15px;
}
 #externalheaderloginrow1 p {
     margin-right: 8px;
     margin-top: 3px;
 }
#externalheaderloginrow2 {
    display: block;
    clear: both;
    color: #FFFFFF;
    height: 24px;
    margin-top: 5px;
}
 #externalheaderloginrow2 input {
     display: inline;
     float: left;
     margin-top: 4px;
     margin-left: 94px;
     width: 12px;
     height: 12px;
     padding: 0px;
     margin-right: 5px;
 }
 #externalheaderloginrow2 p {
     margin-right: 8px;
     margin-top: 3px;
 }
#externalforgotpassword {
    margin-left: 58px
}
/* Pagination  styles */
#paginationsearch {
    width: 820px;
    display: block;
    clear: both;
    font-weight: bold;
    margin-top: 20px;
}
#paginationsearchleft {
    display: inline;
    float: left;
}
#paginationsearchright {
    display: inline;
    float: right;
}
#paginationsearchcenter {
    display: inline;
    float: left;
    margin-left: 30px;
    font-size: 14px;
    margin-top: 3px;
}
.paginationon {
    padding: 0px 4px 0px 4px;
    color: #FFFFFF;
    text-align: center;
    border-radius: 3px;
    margin-left: 2px;
    margin-right: 2px;
}
#paginationsearchcenter img {
    margin-left: 5px;
    margin-right: 5px;
}
a.button_style_send {
    background-color: #FFF;
    font-size: 12px;
    padding: 5px 10px 5px 10px;
    border-radius: 2px;
    border: solid 1px #cbc8ce;
}
.h1header {
    font-size: 24px;
    color: #bf2726;
    text-transform: uppercase;
}
html {
    overflow-y: scroll
}
.RightNowContainerExternal {
    margin-top: 20px
}
/* external pages */
.externalwomenbrowsetop {
    border-radius: 3px 3px 3px 3px;
    clear: both;
    display: block;
    padding-bottom: 16px;
    width: 300px;
    text-align: center;
    margin-top: 20px;
}
 .externalwomenbrowsetop h1 {
     color: #FFFFFF;
     font-size: 22px;
     font-weight: normal;
     margin-bottom: 9px;
     margin-top: 0;
     padding-top: 9px;
     text-align: center;
 }
.externalwomenbrowsebottom {
    border-radius: 0 0 3px 3px;
    clear: both;
    display: block;
    margin-top: -3px;
    padding-bottom: 10px;
    width: 300px;
}
.browserlink {
    font-size: 15px;
    font-weight: bold;
    text-align: center;
    display: block;
    clear: both;
    padding-top: 17px;
}
.externalmeetwomen {
    padding-top: 19px
}
.externalmeetwomenleft {
    display: inline;
    float: left;
    width: 130px;
    margin-left: 15px;
}
.externalmeetwomenright {
    display: inline;
    float: left;
    width: 140px;
    margin-left: 2px;
}
 .externalmeetwomenright p {
     font-size: 14px;
     color: #FFFFFF;
     line-height: 16px;
 }
.externalsearcharticles {
    clear: both;
    display: block;
    margin-top: 25px;
    width: 300px;
}
 .externalsearcharticles h1 {
     border: none;
     border-bottom: solid 1px #ECE9EF;
     font-size: 18px;
     font-weight: bold;
     margin-bottom: 16px;
     padding-bottom: 4px;
     padding-left: 0;
     width: 270px;
 }
 .externalsearcharticles p {
     margin-bottom: 15px;
     margin-left: 0;
 }
 .externalsearcharticles a {
     color: #4F4857 !important;
 }
 
 .externalsearcharticles a:visisted  {
     color: #4F4857 !important;
 }
 
.seemorearticles {
    cursor: pointer;
    margin-left: 0px;
    display: block;
}
 .seemorearticles img {
     display: inline;
     float: left;
     margin-top: 6px;
     margin-left: 5px;
 }
 .seemorearticles p {
     display: inline;
     float: left;
     font-size: 14px;
 }
.externalsuccessstories {
    clear: both;
    display: block;
    margin-top: 0px;
    width: 300px;
}
 .externalsuccessstories h1 {
     border: none;
     border-bottom: solid 1px #ECE9EF;
     font-size: 18px;
     font-weight: bold;
     margin-bottom: 16px;
     padding-bottom: 4px;
     padding-left: 0;
     width: 270px;
 }
.datingarticleexpanded {
    display: none
}
.clearfix {
    font-size: 2px
}
.successstoriescaption {
    font-size: 18px;
    font-style: italic;
    margin-top: 10px;
    color: #989898;
}
.moresuccessstories {
    margin-top: 20px;
    font-size: 14px;
}
.datingtipsarea {
    width: 780px;
    border-radius: 3px;
    margin-top: 20px;
    padding: 20px;
    font-size: 14px;
}
.datingtipsheadline h1 {
    display: inline;
    float: left;
    font-size: 20px;
}
.datingtipsheadline p {
    display: inline;
    float: left;
    margin-top: 6px;
    margin-left: 20px;
}
.datingtipslockright {
    display: inline;
    float: left;
    width: 640px;
    margin-left: 10px;
}
 .datingtipslockright p {
     margin-bottom: 10px
 }
.datingtipslockleft {
    display: inline;
    float: left;
    width: 100px;
}
.datingtipslock {
    display: block;
    clear: both;
    padding-top: 20px;
}
.datingtipsexpandarea {
    display: block;
    clear: both;
    padding-top: 20px;
    width: 760px;
}
 .datingtipsexpandarea li {
     margin-bottom: 0px
 }
 .datingtipsexpandarea p {
     margin-bottom: 10px
 }
.orangerepeat {
    cursor: pointer;
    display: block;
    clear: both;
}
 .orangerepeat p {
     display: inline;
     float: left;
 }
 .orangerepeat img {
     display: inline;
     float: left;
     margin-top: 5px;
     margin-left: 3px;
 }
.fraudextended {
    display: none;
    clear: both;
    padding-bottom: 10px;
}
.fraudcontent {
    display: block;
    clear: both;
    padding-top: 10px;
}
.tipsextended {
    display: none;
    clear: both;
    padding-bottom: 10px;
}
.tipscontent {
    display: block;
    clear: both;
}
.safetyextended {
    display: none;
    clear: both;
    padding-bottom: 10px;
}
.safetycontent {
    display: block;
    clear: both;
}
.meetingextended {
    display: none;
    clear: both;
    padding-bottom: 10px;
}
.meetingcontent {
    display: block;
    clear: both;
}
.fraud {
    display: block;
    clear: both;
    padding-bottom: 0px;
}
.tips {
    display: block;
    clear: both;
    padding-bottom: 0px;
}
.safety {
    display: block;
    clear: both;
    padding-bottom: 0px;
}
.meeting {
    display: block;
    clear: both;
    padding-bottom: 0px;
}
/* Terms and Conditions */
/* Privacy Policy */
/* Success Stories */
.successstoriesli li {
    list-style: none;
    margin: 0px;
    padding: 0px;
    margin-bottom: 20px;
}
.successstoriesli {
    margin: 0px;
    padding: 0px;
}
.leftquotesuccess {
    margin-right: 10px
}
.rightquotesuccess {
    margin-left: 10px
}
/* Dating Articles */
/* About */
.externalaboutpic {
    display: inline;
    float: left;
    margin-right: 20px;
}
.aboutdatingbottom {
    padding-top: 10px
}
 .aboutdatingbottom p {
     display: inline;
     float: right;
 }
.meetheadlineabout {
    font-size: 20px;
    margin-right: 20px;
}
/* Site Map */
.externalsitemap {
    width: 1060px;
    border-radius: 3px;
    margin-bottom: 20px;
    padding: 20px 40px 20px 40px;
    margin-top: 20px;
}
 .externalsitemap h1 {
     font-size: 20px
 }
.externalsitemapclear {
    display: block;
    clear: both;
    margin-top: 20px;
}
.externalsitemapcol1 {
    display: inline;
    float: left;
    width: 235px;
    border: none;
    border-right: solid 1px #cfd6df;
    padding-right: 40px;
}
.externalsitemapcol2 {
    display: inline;
    float: left;
    width: 195px;
    border: none;
    border-right: solid 1px #cfd6df;
    padding-left: 40px;
    padding-right: 40px;
}
.externalsitemapcol3 {
    display: inline;
    float: left;
    width: 150px;
    width: 250px;
    padding-left: 40px;
}
.externalsitemapcol4 {
    display: inline;
    float: left;
    width: 215px;
    font-size: 14px;
}
.sitemap {
    list-style: none;
    margin: 0px;
    padding: 0px;
    font-size: 14px;
    margin-bottom: 20px;
}
 .sitemap li {
     margin-bottom: 7px
 }
.asterix2 {
    color: #4F4857 !important
}
.sitemapsidelinks {
    border-radius: 3px;
    background-color: #edf3f5;
}
.sitemapline {
    border: none;
    border-bottom: solid 1px #e2e1e3;
}
.sitemapsidelinkstop {
    padding-top: 10px;
    margin-left: 20px;
}
 .sitemapsidelinkstop p {
     margin-bottom: 5px
 }
.sitemapline {
    font-size: 7px
}
.asteriskinfo {
    font-size: 12px;
    margin-top: 20px;
    margin-left: 20px;
}
.sitemapsidelinksbottom ul {
    list-style: none;
    margin: 0px;
    padding: 0px;
    margin-left: 20px;
    margin-top: 15px;
    padding-bottom: 16px;
}
.sitemapsidelinksbottom li {
    margin-bottom: 7px
}
#footercontentright {
    display: none
}
#columnright {
    margin-top: 10px
}
/* unsubscribe email */
.unsubscribeemail {
    width: 820px;
    border-radius: 3px;
    margin-top: 20px;
    padding-bottom: 28px;
}
 .unsubscribeemail h1 {
     font-size: 20px;
     padding-top: 20px;
     margin-left: 20px;
 }
 .unsubscribeemail p {
     margin-left: 20px;
     margin-top: 18px;
     font-size: 14px;
     margin-right: 30px;
 }
.unsubscribeformarea {
    display: block;
    width: 820px;
    margin-top: 10px;
    clear: both;
}
 .unsubscribeformarea p {
     display: inline;
     float: left;
 }
 .unsubscribeformarea input {
     display: inline;
     float: left;
     margin-top: 14px;
     width: 221px;
     height: 25px;
     font-size: 15px;
     margin-left: 20px;
 }
#externalloginerrorpassword {
    background-color: #BF2726;
    color: #FFFFFF;
    font-size: 14px;
    font-weight: bold;
    height: 25px;
    margin-top: 20px;
    width: 390px;
}
 #externalloginerrorpassword p {
     margin-left: 40px;
     padding-top: 3px;
 }
#externalloginerrorpasswordinvalid {
    background-color: #BF2726;
    color: #FFFFFF;
    font-size: 14px;
    font-weight: bold;
    height: 64px;
    margin-top: 20px;
    width: 390px;
}
 #externalloginerrorpasswordinvalid p {
     margin-left: 40px;
     padding-top: 3px;
     margin-right: 20px;
 }
#externalloginerrorarrowinvalid img {
    margin-left: 70px
}
.clearfix {
    font-size: 6px;
    margin-top: 0px !important;
    margin-bottom: 0px !important;
}
.unsubscribeseepeople {
    width: 700px;
    display: block;
    clear: both;
    margin-top: 25px;
}
 .unsubscribeseepeople h1 {
     font-size: 20px;
     color: #bf2726;
     margin-bottom: 15px;
 }
.unsubscribeseepeoplerepeat {
    width: 132px;
    text-align: center;
    display: inline;
    float: left;
    margin-right: 30px;
}
 .unsubscribeseepeoplerepeat  img {
     margin-bottom: 5px;
     width: 132px;
     height: 165px;
 }
.unsubscribeseepeoplerepeatbtn {
    text-align: center;
    display: inline;
    float: left;
    margin-right: 30px;
}
.unsubscribeseepeoplerepeatbtn {
    padding-top: 137px
}
.usernameemailedit {
    margin-left: 49px !important
}
#errorhide {
    display: block;
    clear: both;
}
/* externalsearch */
#externalsearchmiddletop h1 {
    font-size: 20px;
    font-weight: normal;
}
#externalsearchmiddletop p {
    font-size: 14px;
    margin-top: 16px;
}
#searchmenwomen {
    text-align: center;
    font-weight: bold;
    font-size: 13px !important;
    padding-top: 10px;
}
#searchpeoplerows {
    width: 686px;
    margin-left: 65px;
    margin-top: 0px;
}
.searchpersonrepeat {
    width: 300px;
    height: 343px;
    background-color: #FFFFFF;
    display: inline;
    float: left;
    border-radius: 2px;
    margin-left: 30px;
    margin-top: 20px;
}
.cropsearchpic {
    display: inline;
    float: left;
    width: 117px;
    height: 147px;
}
.searchpersonpic p {
    display: inline;
    float: left;
    margin-left: 20px;
    line-height: 19px;
    margin-top: 4px;
}
.searchpersonrepeat h2 {
    margin-left: 20px;
    margin-top: 10px;
    margin-bottom: 10px;
}
.searchpersonpic {
    margin-top: 10px;
    margin-left: 20px;
}
.searchpersonbtns {
    display: block;
    clear: both;
    padding-top: 14px;
    margin-left: 20px;
}
 .searchpersonbtns img {
     margin-right: 15px
 }
.searchpersoninfo {
    display: block;
    clear: both;
    margin-left: 20px;
    width: 257px;
    margin-top: 18px;
}
 .searchpersoninfo p {
     line-height: 16px
 }
#externalpaginationsearch {
    width: 820px;
    display: block;
    clear: both;
    margin-left: auto;
    margin-right: auto;
    height: 50px;
    margin-top: 15px;
    font-weight: bold;
}
#externalpaginationsearchleft {
    display: inline;
    float: left;
}
#externalpaginationsearchright {
    display: inline;
    float: right;
}
#externalpaginationsearchcenter {
    display: inline;
    float: left;
    margin-left: 540px;
    font-size: 14px;
    margin-top: 7px;
}
 #externalpaginationsearchcenter img {
     margin-left: 5px;
     margin-right: 5px;
 }
#externalsearchtopcities {
    width: 300px
}
#externalsearchstates {
    width: 300px;
    height: 600px;
    background-image: url(images/external/statesbg.gif);
    display: block;
    clear: both;
}
#externalsearcharticles {
    width: 300px;
    margin-top: 25px;
    display: block;
    clear: both;
}
#externalsearchtopcities h1 {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 8px;
    margin-top: 10px;
}
#externalsearchtopcities p {
    margin-bottom: 20px;
    line-height: 19px;
}
#externalsearchstates h1 {
    color: #FFFFFF;
    font-weight: bold;
    margin-top: 0px;
    padding-top: 9px;
    margin-bottom: 9px;
    text-align: center;
    font-size: 18px;
}
#externalsearchstates img {
    margin-left: 14px
}
#externalsearchstates p {
    width: 100px;
    display: inline;
    float: left;
    margin-left: 30px;
    margin-top: 30px;
    font-size: 14px;
}
#externalsearchstates a {
    color: #FFF
}
#externalsearcharticles h1 {
    font-weight: bold;
    font-size: 18px;
    border-top: none;
    border-left: none;
    border-right: none;
    border-bottom: solid 1px #ece9ef;
    padding-bottom: 4px;
    margin-bottom: 16px;
    width: 270px;
    padding-left: 0px;
}
#externalsearcharticles p {
    margin-bottom: 15px;
    margin-left: 0px;
}
.spacer {
    height: 30px
}
#externalsearchbottombutton {
    width: 370px;
    height: 31px;
    border-radius:3px;
    margin-left: 280px;
    margin-bottom: 30px;
    margin-top: 20px;
}
 #externalsearchbottombutton a {
     font-weight: bold
 }
 #externalsearchbottombutton p {
     text-align: center;
     padding-top: 7px;
 }
#profileoverlayplace2 {
    position: relative;
    z-index: 54001;
}
#profileoverlay2 {
    position: absolute;
    top: 122px;
    z-index: 50;
    width: 117px;
    height: 25px;
}
 #profileoverlay2 a {
     color: #FFFFFF;
	 
 }
 #profileoverlay2 p {
     margin-top: 2px;
     margin-left: 4px;
     display: inline;
     float: left;
	 font-size:13px;
 }
 #profileoverlay2 img {
     margin-top: 1px;
     margin-left: 3px;
     display: inline;
     float: left;
 }
.nostates {
    height: 95px !important;
    border-radius: 3px;
    overflow: hidden;
}
#profilemessageideasarea p {
    margin-bottom: 20px;
    width: 425px;
}
.boldmessages {
    font-weight: bold
}
.sendmessagelink p {
    display: inline;
    float: left;
    margin-left: 10px;
}
.sendmessagelink a {
    display: inline;
    float: left;
}
#profilemessageideasarea {
    border-top: solid 1px #ECE9EF;
    border-left: none;
    border-right: none;
    border-bottom: none;
    width: 498px;
    padding-top: 30px;
    padding-bottom: 10px;
    margin-bottom: 20px;
}
 #profilemessageideasarea h2 {
     margin-bottom: 20px
 }
.externalstatesearchtop {
    width: 300px;
    display: block;
    clear: both;
    border-radius: 3px 3px 3px 3px;
    padding-bottom: 16px;
    margin-top: 20px;
}
.externalstatesearchbottom {
    width: 300px;
    display: block;
    clear: both;
    border-radius: 0px 0px 3px 3px;
    padding-bottom: 10px;
    margin-top: -3px;
}
.externalstatesearchtop h1 {
    color: #FFFFFF;
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 9px;
    margin-top: 0;
    padding-top: 9px;
    text-align: center;
}
.externalstatesearchtop  img {
    margin-left: 14px
}
.externalstatesearchbottom p {
    display: inline;
    float: left;
    font-size: 14px;
    margin-left: 30px;
    margin-top: 30px;
    width: 100px;
}
.externalstatesearchbottom a {
    color: #FFF
}

.externalstatesearchbottom a:visited {
    color: #FFF
}

.externalsignupnowbanner {
    padding-top: 10px;
    padding-bottom: 10px;
    text-align: center;
    font-size: 20px;
    font-weight: normal;
}
 /* forgot password*/
 .externalcontainer {
    width: 820px;
    border-radius: 3px;
}
#externalloginmiddleleft {
    width: 440px;
    display: inline;
    float: left;
    margin-top: 16px;
}
#externalloginmiddleright {
    width: 318px;
    display: inline;
    float: right;
    margin-top: 67px;
    font-size: 14px;
    margin-bottom: 30px;
}
#externalloginmiddleleft h1 {
    font-size: 24px;
    margin-left: 40px;
}
 #externalloginmiddleright p {
     margin-left: 32px;
     padding-top: 25px;
     padding-bottom: 25px;
     width: 286px;
     border-top: none;
     border-left: none;
     border-right: none;
 }
 #externalloginmiddleright p:first-child {
     border-bottom: solid 1px #e2e1e3;
 }
#externalloginemail {
    width: 310px;
    margin-left: 50px;
    margin-top: 20px;
    display: block;
    clear: both;
    height: 42px;
}
 #externalloginemail input {
     display: inline;
     float: right;
     margin-left: 10px;
     width: 200px;
     font-size: 15px;
 }
 #externalloginemail p {
     display: inline;
     float: left;
     margin-top: 3px;
 }
#externalloginsecurityfpo {
    display: block;
    clear: both;
    height: 30px;
    margin-left: 153px;
}
#externalloginsecurity {
    display: block;
    clear: both;
    height: 40px;
    margin-left: 50px;
    width: 310px;
    margin-top: 20px;
}
#externalloginsecuritytext {
    display: block;
    clear: both;
    height: 5px;
    margin-left: 50px;
    width: 370px;
    margin-top: 10px;
}
 #externalloginsecurity input {
     display: inline;
     float: right;
     margin-left: 10px;
     width: 200px;
     font-size: 15px;
 }
 #externalloginsecurity p, #externalloginsecuritytext p {
     display: inline;
     float: left;
     margin-top: 3px;
 }
#externalloginbtn {
    display: block;
    clear: both;
    margin-left: 100px;
    margin-top: 10px;
    margin-left: 124px;
    height: 50px;
}

#externalforgotpasswordbtn {
    display: block;
    clear: both;
    margin-left: 100px;
    margin-top: 10px;
    margin-left: 154px;
    height: 50px;
}

#externalloginerror {
    font-size: 14px;
    font-weight: bold;
    color: #FFF;
    width: 400px;
    height: 25px;
    background-color: #bf2726;
    margin-top: 20px;
}
#externalloginerror2 {
    font-size: 14px;
    font-weight: bold;
    color: #FFF;
    width: 390px;
    height: 25px;
    background-color: #bf2726;
    margin-top: 20px;
}
#externalloginerror p {
    text-align: center;
    padding-top: 3px;
}
#externalloginerror2 p {
    text-align: center;
    padding-top: 3px;
}
#externalloginerrorarrow img {
    margin-left: 80px
}
#externalloginerrorarrow2 img {
    margin-left: 80px
}
#externalloginmiddleleft #externalloginerrorarrow img {
    margin-left: 192px;
    position: absolute;
}
#externalforgottext {
    width: 320px;
    margin-left: 40px;
    margin-top: 30px;
    margin-bottom: 100px;
}
 #externalforgottext p {
     margin-bottom: 15px
 }
#changepasswordtext {
    margin-top: 20px;
    margin-left: 40px;
}
#externalloginpassword1 {
    margin-top: 20px;
    margin-left: 40px;
    display: block;
    clear: both;
    height: 32px;
}
 #externalloginpassword1 p {
     display: inline;
     float: left;
 }
 #externalloginpassword1 input {
     display: inline;
     float: left;
     width: 200px;
     font-size: 15px;
     margin-left: 39px;
 }
#externalloginpassword2 {
    padding-top: 20px;
    margin-left: 40px;
    display: block;
    clear: both;
    height: 40px;
}
 #externalloginpassword2 p {
     display: inline;
     float: left;
 }
 #externalloginpassword2 input {
     display: inline;
     float: left;
     width: 200px;
     font-size: 15px;
     margin-left: 20px;
 }
#externalloginbtnpassword {
    display: block;
    clear: both;
    margin-top: 50px;
    margin-left: 189px;
    height: 50px;
}
#passwordstrength1 {
    width: 200px;
    margin-left: 180px;
    display: block;
    clear: both;
}
 #passwordstrength1 p {
     text-align: center;
     margin-bottom: 4px;
 }
 #passwordstrength1 h2 {
     text-align: center;
     margin-bottom: 2px;
 }
#passwordstrength2 {
    width: 200px;
    margin-left: 180px;
    display: block;
    clear: both;
}
 #passwordstrength2 p {
     text-align: center;
     margin-bottom: 4px;
     background-color: #FFFF00;
 }
 #passwordstrength2 h2 {
     text-align: center;
     margin-bottom: 2px;
 }
#passwordstrength3 {
    width: 200px;
    margin-left: 180px;
    display: block;
    clear: both;
}
 #passwordstrength3 p {
     text-align: center;
     margin-bottom: 4px;
     background-color: #F00;
 }
 #passwordstrength3 h2 {
     text-align: center;
     margin-bottom: 2px;
 }
.good {
    width: 60px;
    height: 20px;
    display: inline;
    float: left;
    background-color: #0F0;
    margin-left: 3px;
    text-align: center;
}
.great {
    width: 60px;
    height: 20px;
    display: inline;
    float: left;
    background-color: #0F0;
    margin-left: 3px;
    text-align: center;
}
.poor {
    width: 60px;
    height: 20px;
    display: inline;
    float: left;
    background-color: #0F0;
    margin-left: 7px;
    text-align: center;
}
.nobg {
    background-color: #CCC !important
}
#passwordstrength4 {
    width: 200px;
    margin-left: 180px;
    display: block;
    clear: both;
}
 #passwordstrength4 p {
     text-align: center;
     margin-bottom: 4px;
     background-color: #CCC;
 }
 #passwordstrength4 h2 {
     text-align: center;
     margin-bottom: 2px;
 }
#forgotpasswordlookuptext {
    margin-left: 40px;
    margin-top: 18px;
}
#forgotpasswordcc {
    display: block;
    clear: both;
    margin-left: 40px;
    margin-top: 10px;
    font-size: 14px;
    height: 30px;
}
#forgotpasswordccmonthyear {
    margin-left: 40px;
    margin-top: 10px;
    display: block;
    clear: both;
}
#forgotpasswordsubmittext {
    margin-left: 40px;
    margin-top: 10px;
}
#externalloginbtnpasswordlookup {
    display: block;
    clear: both;
    margin-top: 26px;
    margin-left: 38px;
    height: 50px;
}
#forgotpasswordcc p {
    display: inline;
    float: left;
    margin-right: 5px;
}
#externalloginmiddleleftlookup {
    width: 450px;
    display: inline;
    float: left;
    margin-top: 16px;
}
 #externalloginmiddleleftlookup h1 {
     font-size: 24px;
     margin-left: 40px;
 }
.middlecc {
    margin-top: 2px
}
#forgotpasswordccmonthyearfields {
    display: block;
    clear: both;
    margin-left: 40px;
    margin-top: 10px;
    font-size: 14px;
    height: 30px;
}
 #forgotpasswordccmonthyearfields p {
     display: inline;
     float: left;
     font-size: 15px;
     margin-right: 5px;
 }
 #forgotpasswordccmonthyearfields select {
     font-size: 15px
 }
 #externalloginusername {
    width: 280px;
    margin-left: 50px;
    margin-top: 20px;
    display: block;
    clear: both;
    height: 50px;
}
#externalloginusername input {
    display: inline;
    float: right;
    margin-left: 10px;
    width: 200px;
    font-size: 15px;
}
#externalloginusername p {
    display: inline;
    float: left;
    margin-top: 3px;
}
#externalloginpassword {
    width: 280px;
    margin-left: 50px;
    display: block;
    clear: both;
    height: 40px;
}
#externalloginpassword input {
    display: inline;
    float: right;
    margin-left: 10px;
    width: 200px;
    font-size: 15px;
}
#externalloginpassword p {
    display: inline;
    float: left;
    margin-top: 3px;
}
#externalloginrememberme {
    display: block;
    clear: both;
    height: 30px;
    width: 130px;
    margin-left: 122px;
}
#externalloginrememberme p {
    display: inline;
    float: left;
    margin-top: 1px;
    margin-left: 3px;
}
#externalloginrememberme input {
    display: inline;
    float: left;
}
#password {
    font-family: Arial, Helvetica, sans-serif !important;
    font-size: 14px !important;
}
#externallogoutpage {
    width: 800px
}
#externallogoutpageadarea {
    width: 800px;
    height: 600px;
    display: block;
    clear: both;
    margin-top: 30px;
}
#externallogouttext {
    font-weight: bold;
    color: #db272a;
    font-size: 14px;
}
#externallogoutusername {
    width: 300px;
    height: 40px;
    margin-top: 20px;
}
#externallogoutusername p {
    display: inline;
    float: left;
    margin-top: 3px;
    font-size: 14px;
}
#externallogoutusername input {
    display: inline;
    float: right;
    width: 200px;
    font-size: 15px;
}
#externallogoutpassword {
    width: 300px;
    height: 50px;
}
#externallogoutpassword p {
    display: inline;
    float: left;
    margin-top: 3px;
    font-size: 14px;
}
#externallogoutpassword input {
    display: inline;
    float: right;
    width: 200px;
    font-size: 15px;
}
#externallogoutforgotlink {
    width: 300px;
    text-align: right;
}
#externallogoutthirdline {
    width: 300px;
    height: 40px;
    margin-left: 0px;
}
#externallogoutrememberme {
    width: 130px;
    display: inline;
    float: right;
    height: 30px;
}
#externallogoutloginbtn {
    display: inline;
    float: right;
    height: 30px;
}
#externallogoutrememberme input {
    display: inline;
    float: left;
}
#externallogoutrememberme p {
    display: inline;
    float: left;
    margin-top: 2px;
    margin-left: 2px;
}

.forgotpasswordlookuptext {margin-left:40px; margin-top:10px;}
/* Button  styles */
button.button_style {
    font-size: 18px;
    font-weight: bold;
    color: #FFF;
    background-color: #009fdb !important;
    padding: 5px 10px 5px 10px;
    border-radius: 3px;
    text-shadow: 1px 1px 1px #333333;
    border:0;
}
button.button_style:hover {
    background-color:#008cc1!important;
    color:#e2e1e3;
}
button.button_style:visited {
    color: #FFFFFF
}
button.button_style:active {
    color: #FFFFFF
}
.button_style_gray {
    background-color: #9ba4a6;
    font-size: 18px;
    font-weight: bold;
    color: #FFF !important;
    padding: 5px 10px 5px 10px;
    border-radius: 3px;
    text-shadow: 1px 1px 1px #333333;
}
</style>
</head>

<body>

    

    <div id="header">
    <div id="headercontent">
        <div id="logo" title="OurTime.com">
                <!-- change logo to use .com only if on external help page and on our time -->
                    <a href="/?notrack"><img src="images/logo.png" border="0" alt="" /></a>
        </div>
        <div id="externalheadernologin">
                <p style="display: "><a href="#" target="_blank">A People Media Site</a></p>
        </div>
    </div>
</div>

    <div id="maincontent">
      
        
            <div id="columnleftexternal">
                <div id="externallogin">
    <div class="externalcontainer bgcolor-main">
        <div id="externalloginmiddleleft">
            <h1>Login to OurTime.com</h1>
                <div>
                    <div id="externalloginerror">
                        <p>Please enter your Email and Password to continue</p>
                    </div>
                    <div id="externalloginerrorarrow"><img src="images/errorarrow.png" /></div>
                </div>
            <form id="frmLogin" method="post" action="login.php">
                <input type="hidden" name="SkipCSSVerif" value="HTMLEditor" />
                <input type="hidden" name="FromLocation" value="/v3/login/" /> 
                <div id="externalloginusername">
                    <p>Email</p>
                    <input id="username" type="email" name="username" tabindex="1" value="" required title="Email"/>
                </div>
                <div id="externalloginpassword">
                    <p>Password</p>
                    <input id="password" type="password" name="password" autocomplete="off" tabindex="2" value="" required title="Password"/>
                </div>
                <div id="externalloginrememberme">
                        <input id="chkKeepMeLoggedIn" type="checkbox" name="chkKeepMeLoggedIn" checked value="true"/>
                        <label for="chkKeepMeLoggedIn"><p>Keep me logged in</p></label>                        
                </div>
                <div id="externalloginbtn"><button class="button_style" title="Login">Login</button></div>
            </form>
        </div>
        <div id="externalloginmiddleright" class="bgcolor-login">
            <p>Not a member yet?<br />
                <a href="/sign_up">Join Free</a>
            </p>
            <p>Forgot password?<br />
                <a href="/v3/forgotpassword">Click here</a>
            </p>
        </div>
        <p class="clearfix">&nbsp;</p>
    </div>
</div>

            </div>
            <div id="columnrightexternal">
                
            </div>
            <p class="clearfix">&nbsp;</p>
        

        <p class="clearfix">&nbsp;</p>
    </div>

    <div id="footer">
    <div id="footercontent">
        <div id="footercontentleft">
            <p>
                Copyright &copy; 2020 People Media. All rights reserved.  166x1605.  <a href="/v3/termsandconditions">Terms of Use</a> | <a href="/v3/privacypolicy?notrack">Privacy Policy</a>
            </p>
        </div>
    </div>
</div>

    <div id="externallinks">
        <p>
            <a href="http://www.ourtime.com?notrack">home</a> |
            <a href="/v3/datingtips">safe dating tips</a> |
            <a href="/v3/help">contact us</a> |
            <a href="https://www.ourtime.com/v3/billing/">billing</a> |
            <a href="/v3/successstories">success stories</a> |
            <a href="http://www.match.com/cp/careers/CurrentOpenings.html">careers</a> |
            <a href="/v3/aboutonlinedating">about</a> |
            <a href="http://www.matchmediagroup.com" target="_blank">advertise with us</a> |
            <a href="/v3/externalsearch">search</a> |
            <a href="/sign_up">join now</a> |
            <a href="javascript:void(0);" onclick=" window.external.AddFavorite('http://www.ourtime.com?notrack', 'OurTime.com - The 50+ Single Network') ">bookmark page</a> |
            <a href="/v3/sitemap">site map</a>
            <br />
            <a href="http://www.match.com" target="_blank">Match.com</a> |
            <a href="http://www.chemistry.com" target="_blank">Chemistry.com</a> |
            <a href="http://www.ourtime.com/?notrack" target="_blank">Mature Dating</a> |
            <a href="http://www.blackpeoplemeet.com/?notrack" target="_blank">Black Singles</a> |
            <a href="http://www.bbpeoplemeet.com/?notrack" target="_blank">Big and Beautiful</a>
        </p>
    </div>
</body>
</html>
<?php ob_end_flush(); ?>