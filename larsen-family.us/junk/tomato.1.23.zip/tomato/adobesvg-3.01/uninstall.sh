#!/bin/sh
# Adobe SVG Viewer 3.01 uninstall script
rm -rf '/root/.adobesvg'
rm -f '/usr/lib/mozilla/plugins/libNPSVG3.so'
rm -f /usr/local/adobesvg
rm -rf /usr/local/adobesvg-3.01
