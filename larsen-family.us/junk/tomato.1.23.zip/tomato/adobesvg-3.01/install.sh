#!/bin/sh

installPlugin()
{
    echo -n "Installing in $1..."
    rm -f "$1"/libNPSVG*.so
    if cp `pwd`/libNPSVG3.so "$1" ; then
	found=1
	echo rm -f \'$1/libNPSVG3.so\' >> $uninstall
	echo OK
    else
        echo Failed
    fi
}

cd `echo $0 | sed 's%[^/]*$%.%'`

found=0
local=0
force=0
uninstall=`pwd`/uninstall.sh

case "$1" in
    -l|--local)
	local=1
	mkdir -p "$HOME/.adobesvg"
	mkdir -p "$HOME/.mozilla/plugins"
	shift
	;;
esac

if [ "$local" = "1" ] ; then
    echo "Making local installation"
    echo "Adobe SVG Viewer installation folder is "`pwd`
    rm -f "$HOME/.adobesvg/lib"
    ln -s `pwd` "$HOME/.adobesvg/lib"
    echo '#!/bin/sh' > $uninstall
    echo '# Adobe SVG Viewer 3.01 uninstall script (local install)' >> $uninstall
    echo rm -rf \'$HOME/.adobesvg\' >> $uninstall
    installPlugin "$HOME/.mozilla/plugins"
else

    case "$1" in
	-f|--force)
	    force=1
	    uninstall="$HOME/uninstall.sh"
	    shift
	    ;;
    esac

    if [ "$USER" != "root" -a "$force" != "1" ] ; then
	USER=root
	export USER
	echo "Changing user to root"
	exec su -- root -c "./install.sh $*"
    fi

    echo '#!/bin/sh' > $uninstall
    echo '# Adobe SVG Viewer 3.01 uninstall script' >> $uninstall
    echo rm -rf \'$HOME/.adobesvg\' >> $uninstall

    echo "Searching for Mozilla..."
    for mp in /usr/lib/mozilla*/plugins /usr/local/mozilla*/plugins /usr/mozilla*/plugins /opt/mozilla*/plugins "$@"
    do
	if [ -d "$mp" ] ; then
	    installPlugin "$mp"
	fi
    done

    if [ $found = "0" ] ; then
	echo "Mozilla installation not found"
    else
	rm -rf /usr/local/adobesvg
	echo "rm -f /usr/local/adobesvg" >> $uninstall
	if [ `pwd` = /usr/local/adobesvg-3.01 ] ; then
	    echo "Linking /usr/local/adobesvg-3.01 to /usr/local/adobesvg"
	    ln -s /usr/local/adobesvg-3.01 /usr/local/adobesvg
	else
	    if [ "$force" = "1" ] ; then
		echo "Installation folder is "`pwd`
		echo "Linking "'pwd'" to /usr/local/adobesvg"
		ln -s `pwd` /usr/local/adobesvg
	    else
		echo "Copying files to /usr/local/adobesvg-3.01"
		rm -rf /usr/local/adobesvg-3.01
		echo rm -rf "/usr/local/adobesvg-3.01" >> $uninstall
		mkdir -p /usr/local/adobesvg-3.01
		cp * /usr/local/adobesvg-3.01
		chmod 755 /usr/local/adobesvg-3.01
		chmod 444 /usr/local/adobesvg-3.01/*
		chmod 555 /usr/local/adobesvg-3.01/*.so /usr/local/adobesvg-3.01/*.sh
		echo "Linking /usr/local/adobesvg-3.01 to /usr/local/adobesvg"
		ln -s /usr/local/adobesvg-3.01 /usr/local/adobesvg
	    fi
	fi
    fi
fi
chmod 755 "$uninstall"
echo "Written uninstall script $uninstall"

