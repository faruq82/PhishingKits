________________________________________________________________ 

DiskPie, Version 2.1
Copyright (c) 2001 Ziff Davis Media, Inc.
Written by Neil J. Rubenking
First Published in PC Magazine, US Edition, December 11 2001, v20n21
http://www.pcmag.com/utilities/
________________________________________________________________ 

PLATFORMS:
Windows 95/98/Me/NT4/2000/XP

DESCRIPTION:
Hard disks keep getting bigger and bigger, but somehow we still run out of space. MP3s and other media files are immensely popular-and simply immense. Programs are bigger, and data files are bigger. Windows Explorer isn't much help. It will tell you the size of all selected files in a folder, but nothing about the files in that folder's subfolders. Enter DiskPie, a utility to identify the biggest consumers of disk space. Pie charts let you see at a glance which folders and file types are taking up the most space. The charts are highly customizable, and can be printed. An Explorer view lets you navigate to the folder you want to chart, and as a bonus displays the number of bytes in and below the selected folder. DiskPie also can display and print a report of the largest files in the selected folder. Armed with the information that DiskPie provides, you can decide how best to allocate the space on your disk.

REVISION HISTORY:
Changes in Version 2.0:
- Requires 32-bit windows (Version 1 was designed for Windows 3.1).
- Improved the user interface.
- Added long filename support.
- Added network drive support.
- Added support for drives larger than 2GB.

Changes in Version 2.1:
- On a few systems, the INI filename would become corrupted (the sixth character would be changed to a non-printing character), making it impossible for the program to save settings. This has been fixed.

- The program would sometimes report an access violation at shutdown. This was caused by the program's attempt to record the size and position of the Detail window when that window had never been displayed. This has been fixed.

- On very slow systems with very high video resolution, the rotation of the pie during processing took more time than was allotted. This has been fixed.

THANKS TO OUR BETA TESTERS:
Bob Abrahams
Paul Boucher
Alec Burgess
Herbert Bushong
Dennis Cummins
Charles Dial
Michael Dugan
Robert Eisenbach
Josh Fitzgerald
Ken Holt
Bruno Sonnino
Greg Wolking

INSTALLATION:
To install DiskPie, run the supplied installation program SETUP.EXE. To uninstall the program, use the Add/Remove Programs applet in the Windows Control Panel. For details on program operation, refer to the program's online help file.

FILE LIST:
Setup.exe     - DiskPie installation program
readme.txt    - the file you are reading
license.txt   - PC Magazine Utilities license agreement
dpie_src.zip  - DiskPie source code (for programmers)

SUPPORT:
Help for PC Magazine's free utilities can be obtained in our online discussion area on the World Wide Web (http://discuss.pcmag.com/pcmag). You may find an answer to your question simply by reading the posted messages. The authors of current utilities generally visit this forum daily. If the author is not available and the forum sysops can't answer your question, the Utilities column editor, who also checks the forum each day, will contact the author for you.

LICENSE INFORMATION:
PC Magazine programs are copyrighted and cannot be distributed, whether modified or unmodified. Use is subject to the terms and conditions of the license agreement distributed with the programs.

----

Neil J. Rubenking, the author of DiskPie, is the Contributing Technical Editor to PC Magazine. Sheryl Canter is the editor of the Utilities column and a Contributing Editor of PC Magazine.

