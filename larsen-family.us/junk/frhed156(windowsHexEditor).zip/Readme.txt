-----------------------------------------------------------------------
What is frhed?

Welcome to the "Free Hex Editor", abbreviated with "frhed". Frhed is a
free binary file editor for 32-Bit Windows platforms, like Windows 95,
Windows 98 and Windows NT.

Features include:
- Native 32 bit Windows application: long filenames supported,
  editable file size limited only by available system memory.
- small program size (ca. 100K), loads fast.
- Cut, copy & paste binary values. Syntax for describing byte,
  word, longword, float and double binary values in text form
  to use with find and paste functions.
- Directly enter hex values or text in main window (overwrite or insert).
- Compare files.
- Search for any combination of text and binary values.
- Bit manipulation.
- Export as hexdump to file or clipboard.
- Automatically adjust bytes displayed per hexdump line to
  window width, or set bytes per line manually.
- Choose font size, character set (ANSI or OEM), colors
  of text and background.
- Intel or Motorola binary format.
- Can be used as "Send to"-Target.
- Set bookmarks to easily access offsets in the file.
- Load files partially.
- Load files by dragging them into the window.
- Apply binary templates for structured information.
- Source code is included. (Written with Microsoft
  Visual C++ 4.0. Does not use MFC, only Win32 API
  calls and C library calls, uses C++ classes).
- No registration fee required!

-----------------------------------------------------------------------
Installing frhed:

Extract the contents of the Zip-file to a directory. Nothing else is
required, you can start frhed by creating a shortcut to frhed.exe
in the start menu or putting the shortcut in the "Send to"-folder
and then sending files to it.
If you don't need the source code, delete the directory "Source".

-----------------------------------------------------------------------
Disclaimer

Frhed is supplied on an as-is basis. The author offers no warranty of
its fitness for any purpose whatsoever, and accepts no liability
whatsoever for any loss or damage incurred by its use. Frhed is not
a supported product. The author accepts no commitment or liability
to address any problems that may be encountered in using it; however,
frhed is continually being developed and improved, so he is always
interested to hear about any bugs or deficiencies.

-----------------------------------------------------------------------
Using And Distributing frhed

Frhed may be freely used for any purpose. You may use it privately or
in the course of your work; there is no fee, and no registration is
required. You may distribute it to anyone, and you may place it on
any archive or bulletin board system. You may not charge anyone for
it other than a reasonable fee to cover your distribution costs.
Normally, you should distribute frhed in the form as supplied by
the author; however, you may repackage it to suit the conventions
and needs of an archive or bulletin board system. Frhed may be
distributed as part of any commercial product without a prior
licence agreement, although no extra cost should be charged
for inclusion of frhed. Frhed may be reviewed for any publication,
whether in hard copy or electronic form, without the author's
prior permission.

-----------------------------------------------------------------------
Contacting the Author

If you have comments or suggestions please send eMail to:
  rkibria@hrz1.hrz.tu-darmstadt.de

-----------------------------------------------------------------------
Personal homepage

You can also find frhed (including the newest beta version) on my personal homepage:
http://www.kibria.de
