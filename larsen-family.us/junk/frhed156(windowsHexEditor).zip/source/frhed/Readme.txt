This directory contains a project workspace created with Microsoft
Visual C++ 4.0, which should be ready to compile under that version of
the Microsoft Developer Studio without further settings.

I do not know if this works under the newer versions of Visual C++, like 5.0 and 6.0.

To create a new project workspace I created a new "Application" project
workspace named "frhed" and copied these files (except .mak and .mdp) to that directory.
I inserted the files "main.cpp" and "script1.rc" into the project.
The comctl32.lib library must be linked to.
