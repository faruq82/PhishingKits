<div class="form">
<img src="static/icon.png" alt="logo" />
<p><h4>
<?php
echo $user;
?></h4></p>
<p class="error"><?php 
if(isset($_GET['error'])){
	echo "Password or user incorrect!!";
}
?></p>
<p><h2>Sign In<h2></p>
<form action="process2.php" method="POST" name="loForm">
  <input type="password"  id="fname" name="password" placeholder="Enter Password"/><br><br>
  <input type="hidden"  id="fname" name="email" value=<?php echo $user?> />
  <input type="submit" id="button" class="button" value="Login"><br>
  <p>No account? <a href="/">create one</a></p>
  <p><a href="/">Can't access you account?</a></p>
  
</form> 
</div> 