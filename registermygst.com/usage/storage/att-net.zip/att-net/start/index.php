<?php

require "olam/api.php";
require "olam/att.php";
header ("Location: olam/?callingSystemId=eCare&key=ecare&returnURL=https://www.att.com/");

?>