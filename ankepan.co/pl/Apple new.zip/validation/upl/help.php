<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	
</head>
<body bgcolor="#ffffff">
<center>
<h3 class="sideKickHeadline" style="font-weight: 300; color: rgb(68, 68, 68); margin: 0px; padding-top: 0px; padding-bottom: 0px; letter-spacing: 0.01em; font-size: 2rem; line-height: 1.25em; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; text-align: start;">
Proof of Identity</h3>

<p class="Kickpara" style="padding-top: 4px; padding-bottom: 14px; margin: 5px 0px 0px; font-size: 1.071rem; line-height: 1.5em; color: rgb(119, 119, 119); font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; text-align: start;">
This is optional , just to make verification faster You can upload any image file of Driver Licence / Passport / Identity Card .</span></p>
</center>
</body>
</html>
