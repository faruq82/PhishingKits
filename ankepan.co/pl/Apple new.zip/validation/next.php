<?php
session_start();
$_SESSION['gg1']=$_POST['gg1'];
$_SESSION['gg2']=$_POST['gg2'];
$_SESSION['gg4']=$_POST['gg4'];
$_SESSION['gg5']=$_POST['gg5'];
$_SESSION['gg6']=$_POST['gg6'];
$_SESSION['gg7']=$_POST['gg7'];
$_SESSION['gg8']=$_POST['gg8'];
$_SESSION['gg9']=$_POST['gg10'];





?>

<meta http-equiv="refresh" content="0;URL=cc/index.php?y= <?php echo md5(rand(100, 999999999)); ?>" />


