function scale() {
  var scale = Math.min(($(window).width()/460),1).toFixed(2);
  $('meta[name=viewport]').attr('content','width=device-width,maximum-scale='+scale+',initial-scale='+scale);
}

function manageNarrowView() {
  if ($(window).width() <= 974 && !$('#invoiceAddress #invoice_email').hasClass("requireCustomerData")) {
    $('#addresses').find('.collapse.in').collapse('hide');
    $('#termekek').collapse('hide');
    $('#deliveryAddressArrow').hide();
    $('#invoiceAddressArrow').hide();
    $("#addresses").hide();
    $(document.body).on('click', '#sumRow', function() {
      if ($("#addresses").is(":visible")) {
        $("#addresses").hide();
      } else {
        $("#addresses").show();
      }
      $('#termekek').collapse('toggle');
      $('#deliveryAddress').collapse('toggle');
      $('#invoiceAddress').collapse('toggle');
    });
  }
}

var width = $(window).width();
$(window).on('resize', function() {
  if ($(this).width() != width) {
    width = $(this).width();
    if (width <= 974) {
      manageNarrowView();
    } else {
      manageWideView();
    }
  }
});

function manageWideView() {
  $('#addresses').find('.collapse.in').collapse('show');
  $('#termekek').collapse('show');
  $('#deliveryAddressArrow').show();
  $('#invoiceAddressArrow').show();
  $("#addresses").show();
}

function activateCard(card, id) {
  var cardDiv = $(card);
  if (!cardDiv.hasClass("inactive")) {
    // Activate card
    $("#bankCards").find(".active").removeClass("active");
    cardDiv.addClass("active");

    // Show password Form and Pay button
    $("#passwordForm").css("display", "table");
    $("#moreGreenHolderPassword").show();
    $(".passwordForCardDiv").show();
    $("#moreGreenHolderPwdForCardDiv").show();

    // Hide AddCard
    $('#addCard .bg-transparent').removeClass("addCardLikeHead");
    $('#addCard .bg-transparent').addClass("addCard");
    $('#addCard .bg-transparent').addClass("kartya");
    $('#addCard').removeClass("blueBorderCardHolder");
    $('#addCard').addClass("bankCards");
    $("#newCard").hide();
    $("#newCard2").hide();
    $("#newCardButton").hide();

    $("#moreGreenHolderAddCard").hide();
    $("#moreGreenHolderPayBtn").show();
    cardId = id;
    if (simpleLogin) {
      //console.log("simple -> hiding passwordForm");
      $(".passwordForCardDiv").hide();
      $("#moreGreenHolderPwdForCardDiv").hide();
    }
  }
}

function showAddCard() {
  // Remove activate card
  $("#bankCards").find(".active").removeClass("active");

  // Hide password Form and Pay button
  $("#passwordForm").hide();
  $("#moreGreenHolderPassword").hide();
  $(".passwordForCardDiv").show();

  $("#moreGreenHolderPwdForCardDiv").show();

  // Show AddCard
  $('#addCard .bg-transparent').addClass("addCardLikeHead");
  $('#addCard .bg-transparent').removeClass("addCard");
  $('#addCard .bg-transparent').removeClass("kartya");
  $('#addCard').addClass("blueBorderCardHolder");
  $('#addCard').removeClass("bankCards");
  $("#newCard").show();
  $("#newCard2").show();
  $("#newCardButton").show();

  $("#moreGreenHolderAddCard").show();
  $("#moreGreenHolderPayBtn").hide();

  cardId = null;
  movePayFormFromOriginalPlace();
  $('#newCardName').val(cardName);
  if (simpleLogin) {
    //console.log("simple -> hiding passwordForm");
    $(".passwordForCardDiv").hide();
    $("#moreGreenHolderPwdForCardDiv").hide();
  }
}

function movePayFormFromOriginalPlace() {
  $("#payForm").detach().appendTo('#cardRegister');
}

function movePayFormToOriginalPlace() {
  $("#payForm").detach().appendTo('#originalCardPayment');
}
