(function(G,M){function F(){var Q=N.elements;
return"string"==typeof Q?Q.split(" "):Q
}function J(R){var Q=E[R[D]];
Q||(Q={},K++,R[D]=K,E[K]=Q);
return Q
}function C(R,Q,S){Q||(Q=M);
if(L){return Q.createElement(R)
}S||(S=J(Q));
Q=S.cache[R]?S.cache[R].cloneNode():A.test(R)?(S.cache[R]=S.createElem(R)).cloneNode():S.createElem(R);
return Q.canHaveChildren&&!P.test(R)?S.frag.appendChild(Q):Q
}function O(R,Q){if(!Q.cache){Q.cache={},Q.createElem=R.createElement,Q.createFrag=R.createDocumentFragment,Q.frag=Q.createFrag()
}R.createElement=function(S){return !N.shivMethods?Q.createElem(S):C(S,R,Q)
};
R.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+F().join().replace(/\w+/g,function(S){Q.createElem(S);
Q.frag.createElement(S);
return'c("'+S+'")'
})+");return n}")(N,Q.frag)
}function B(R){R||(R=M);
var Q=J(R);
if(N.shivCSS&&!I&&!Q.hasCSS){var T,S=R;
T=S.createElement("p");
S=S.getElementsByTagName("head")[0]||S.documentElement;
T.innerHTML="x<style>article,aside,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}</style>";
T=S.insertBefore(T.lastChild,S.firstChild);
Q.hasCSS=!!T
}L||O(R,Q);
return R
}var H=G.html5||{},P=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,A=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,I,D="_html5shiv",K=0,E={},L;
(function(){try{var R=M.createElement("a");
R.innerHTML="<xyz></xyz>";
I="hidden" in R;
var Q;
if(!(Q=1==R.childNodes.length)){M.createElement("a");
var T=M.createDocumentFragment();
Q="undefined"==typeof T.cloneNode||"undefined"==typeof T.createDocumentFragment||"undefined"==typeof T.createElement
}L=Q
}catch(S){L=I=!0
}})();
var N={elements:H.elements||"abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup main mark meter nav output progress section summary time video",version:"3.6.2pre",shivCSS:!1!==H.shivCSS,supportsUnknownElements:L,shivMethods:!1!==H.shivMethods,type:"default",shivDocument:B,createElement:C,createDocumentFragment:function(R,Q){R||(R=M);
if(L){return R.createDocumentFragment()
}for(var Q=Q||J(R),V=Q.frag.cloneNode(),U=0,T=F(),S=T.length;
U<S;
U++){V.createElement(T[U])
}return V
}};
G.html5=N;
B(M)
})(this,document);
window.innerShiv=function(){function B(H,G,F){return/^(?:area|br|col|embed|hr|img|input|link|meta|param)$/i.test(F)?H:G+"></"+F+">"
}var E,D=document,A,C="abbr article aside audio canvas datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video".split(" ");
return function(J,H){if(!E&&(E=D.createElement("div"),E.innerHTML="<nav></nav>",A=E.childNodes.length!==1)){for(var F=D.createDocumentFragment(),I=C.length;
I--;
){F.createElement(C[I])
}F.appendChild(E)
}J=J.replace(/^\s\s*/,"").replace(/\s\s*$/,"").replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,"").replace(/(<([\w:]+)[^>]*?)\/>/g,B);
E.innerHTML=(F=J.match(/^<(tbody|tr|td|col|colgroup|thead|tfoot)/i))?"<table>"+J+"</table>":J;
F=F?E.getElementsByTagName(F[1])[0].parentNode:E;
if(H===!1){return F.childNodes
}for(var I=D.createDocumentFragment(),G=F.childNodes.length;
G--;
){I.appendChild(F.firstChild)
}return I
}
}();
window.Modernizr=function(AX,AW,AV){function U(A){AO.cssText=A
}function T(B,A){return U(AK.join(B+";")+(A||""))
}function S(B,A){return typeof B===A
}function R(B,A){return !!~(""+B).indexOf(A)
}function Q(B,A){for(var D in B){var C=B[D];
if(!R(C,"-")&&AO[C]!==AV){return A=="pfx"?C:!0
}}return !1
}function P(B,A,E){for(var D in B){var C=A[B[D]];
if(C!==AV){return E===!1?B[D]:S(C,"function")?C.bind(E||A):C
}}return !1
}function O(B,A,E){var D=B.charAt(0).toUpperCase()+B.slice(1),C=(B+" "+AI.join(D+" ")+D).split(" ");
return S(A,"string")||S(A,"undefined")?Q(C,A):(C=(B+" "+AH.join(D+" ")+D).split(" "),P(C,A,E))
}function N(){AT.input=function(C){for(var B=0,A=C.length;
B<A;
B++){AD[C[B]]=C[B] in AN
}return AD.list&&(AD.list=!!AW.createElement("datalist")&&!!AX.HTMLDataListElement),AD
}("autocomplete autofocus list placeholder max min multiple pattern required step".split(" ")),AT.inputtypes=function(A){for(var F=0,E,D,C,B=A.length;
F<B;
F++){AN.setAttribute("type",D=A[F]),E=AN.type!=="text",E&&(AN.value=AM,AN.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(D)&&AN.style.WebkitAppearance!==AV?(AR.appendChild(AN),C=AW.defaultView,E=C.getComputedStyle&&C.getComputedStyle(AN,null).WebkitAppearance!=="textfield"&&AN.offsetHeight!==0,AR.removeChild(AN)):/^(search|tel)$/.test(D)||(/^(url|email)$/.test(D)?E=AN.checkValidity&&AN.checkValidity()===!1:E=AN.value!=AM)),AE[A[F]]=!!E
}return AE
}("search tel url email datetime date month week time datetime-local number range color".split(" "))
}var AU="2.6.2",AT={},AS=!0,AR=AW.documentElement,AQ="modernizr",AP=AW.createElement(AQ),AO=AP.style,AN=AW.createElement("input"),AM=":)",AL={}.toString,AK=" -webkit- -moz- -o- -ms- ".split(" "),AJ="Webkit Moz O ms",AI=AJ.split(" "),AH=AJ.toLowerCase().split(" "),AG={svg:"http://www.w3.org/2000/svg"},AF={},AE={},AD={},AC=[],AB=AC.slice,AA,Z=function(K,J,I,H){var G,F,E,D,C=AW.createElement("div"),B=AW.body,A=B||AW.createElement("body");
if(parseInt(I,10)){while(I--){E=AW.createElement("div"),E.id=H?H[I]:AQ+(I+1),C.appendChild(E)
}}return G=["&#173;",'<style id="s',AQ,'">',K,"</style>"].join(""),C.id=AQ,(B?C:A).innerHTML+=G,A.appendChild(C),B||(A.style.background="",A.style.overflow="hidden",D=AR.style.overflow,AR.style.overflow="hidden",AR.appendChild(A)),F=J(C,K),B?C.parentNode.removeChild(C):(A.parentNode.removeChild(A),AR.style.overflow=D),!!F
},Y=function(A){var C=AX.matchMedia||AX.msMatchMedia;
if(C){return C(A).matches
}var B;
return Z("@media "+A+" { #"+AQ+" { position: absolute; } }",function(D){B=(AX.getComputedStyle?getComputedStyle(D,null):D.currentStyle)["position"]=="absolute"
}),B
},X=function(){function B(E,D){D=D||AW.createElement(A[E]||"div"),E="on"+E;
var C=E in D;
return C||(D.setAttribute||(D=AW.createElement("div")),D.setAttribute&&D.removeAttribute&&(D.setAttribute(E,""),C=S(D[E],"function"),S(D[E],"undefined")||(D[E]=AV),D.removeAttribute(E))),D=null,C
}var A={select:"input",change:"input",submit:"form",reset:"form",error:"img",load:"img",abort:"img"};
return B
}(),W={}.hasOwnProperty,V;
!S(W,"undefined")&&!S(W.call,"undefined")?V=function(B,A){return W.call(B,A)
}:V=function(B,A){return A in B&&S(B.constructor.prototype[A],"undefined")
},Function.prototype.bind||(Function.prototype.bind=function(A){var D=this;
if(typeof D!="function"){throw new TypeError
}var C=AB.call(arguments,1),B=function(){if(this instanceof B){var E=function(){};
E.prototype=D.prototype;
var G=new E,F=D.apply(G,C.concat(AB.call(arguments)));
return Object(F)===F?F:G
}return D.apply(A,C.concat(AB.call(arguments)))
};
return B
}),AF.flexbox=function(){return O("flexWrap")
},AF.flexboxlegacy=function(){return O("boxDirection")
},AF.canvas=function(){var A=AW.createElement("canvas");
return !!A.getContext&&!!A.getContext("2d")
},AF.canvastext=function(){return !!AT.canvas&&!!S(AW.createElement("canvas").getContext("2d").fillText,"function")
},AF.webgl=function(){return !!AX.WebGLRenderingContext
},AF.touch=function(){var A;
return"ontouchstart" in AX||AX.DocumentTouch&&AW instanceof DocumentTouch?A=!0:Z(["@media (",AK.join("touch-enabled),("),AQ,")","{#modernizr{top:9px;position:absolute}}"].join(""),function(B){A=B.offsetTop===9
}),A
},AF.geolocation=function(){return"geolocation" in navigator
},AF.postmessage=function(){return !!AX.postMessage
},AF.websqldatabase=function(){return !!AX.openDatabase
},AF.indexedDB=function(){return !!O("indexedDB",AX)
},AF.hashchange=function(){return X("hashchange",AX)&&(AW.documentMode===AV||AW.documentMode>7)
},AF.history=function(){return !!AX.history&&!!history.pushState
},AF.draganddrop=function(){var A=AW.createElement("div");
return"draggable" in A||"ondragstart" in A&&"ondrop" in A
},AF.websockets=function(){return"WebSocket" in AX||"MozWebSocket" in AX
},AF.rgba=function(){return U("background-color:rgba(150,255,150,.5)"),R(AO.backgroundColor,"rgba")
},AF.hsla=function(){return U("background-color:hsla(120,40%,100%,.5)"),R(AO.backgroundColor,"rgba")||R(AO.backgroundColor,"hsla")
},AF.multiplebgs=function(){return U("background:url(https://),url(https://),red url(https://)"),/(url\s*\(.*?){3}/.test(AO.background)
},AF.backgroundsize=function(){return O("backgroundSize")
},AF.borderimage=function(){return O("borderImage")
},AF.borderradius=function(){return O("borderRadius")
},AF.boxshadow=function(){return O("boxShadow")
},AF.textshadow=function(){return AW.createElement("div").style.textShadow===""
},AF.opacity=function(){return T("opacity:.55"),/^0.55$/.test(AO.opacity)
},AF.cssanimations=function(){return O("animationName")
},AF.csscolumns=function(){return O("columnCount")
},AF.cssgradients=function(){var B="background-image:",A="gradient(linear,left top,right bottom,from(#9f9),to(white));",C="linear-gradient(left top,#9f9, white);";
return U((B+"-webkit- ".split(" ").join(A+B)+AK.join(C+B)).slice(0,-B.length)),R(AO.backgroundImage,"gradient")
},AF.cssreflections=function(){return O("boxReflect")
},AF.csstransforms=function(){return !!O("transform")
},AF.csstransforms3d=function(){var A=!!O("perspective");
return A&&"webkitPerspective" in AR.style&&Z("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",function(B,C){A=B.offsetLeft===9&&B.offsetHeight===3
}),A
},AF.csstransitions=function(){return O("transition")
},AF.fontface=function(){var A;
return Z('@font-face {font-family:"font";src:url("https://")}',function(F,E){var D=AW.getElementById("smodernizr"),C=D.sheet||D.styleSheet,B=C?C.cssRules&&C.cssRules[0]?C.cssRules[0].cssText:C.cssText||"":"";
A=/src/i.test(B)&&B.indexOf(E.split(" ")[0])===0
}),A
},AF.generatedcontent=function(){var A;
return Z(["#",AQ,"{font:0/0 a}#",AQ,':after{content:"',AM,'";visibility:hidden;font:3px/1 a}'].join(""),function(B){A=B.offsetHeight>=3
}),A
},AF.video=function(){var A=AW.createElement("video"),C=!1;
try{if(C=!!A.canPlayType){C=new Boolean(C),C.ogg=A.canPlayType('video/ogg; codecs="theora"').replace(/^no$/,""),C.h264=A.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/,""),C.webm=A.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/,"")
}}catch(B){}return C
},AF.audio=function(){var A=AW.createElement("audio"),C=!1;
try{if(C=!!A.canPlayType){C=new Boolean(C),C.ogg=A.canPlayType('audio/ogg; codecs="vorbis"').replace(/^no$/,""),C.mp3=A.canPlayType("audio/mpeg;").replace(/^no$/,""),C.wav=A.canPlayType('audio/wav; codecs="1"').replace(/^no$/,""),C.m4a=(A.canPlayType("audio/x-m4a;")||A.canPlayType("audio/aac;")).replace(/^no$/,"")
}}catch(B){}return C
},AF.localstorage=function(){try{return localStorage.setItem(AQ,AQ),localStorage.removeItem(AQ),!0
}catch(A){return !1
}},AF.sessionstorage=function(){try{return sessionStorage.setItem(AQ,AQ),sessionStorage.removeItem(AQ),!0
}catch(A){return !1
}},AF.webworkers=function(){return !!AX.Worker
},AF.applicationcache=function(){return !!AX.applicationCache
},AF.svg=function(){return !!AW.createElementNS&&!!AW.createElementNS(AG.svg,"svg").createSVGRect
},AF.inlinesvg=function(){var A=AW.createElement("div");
return A.innerHTML="<svg/>",(A.firstChild&&A.firstChild.namespaceURI)==AG.svg
},AF.smil=function(){return !!AW.createElementNS&&/SVGAnimate/.test(AL.call(AW.createElementNS(AG.svg,"animate")))
},AF.svgclippaths=function(){return !!AW.createElementNS&&/SVGClipPath/.test(AL.call(AW.createElementNS(AG.svg,"clipPath")))
};
for(var M in AF){V(AF,M)&&(AA=M.toLowerCase(),AT[AA]=AF[M](),AC.push((AT[AA]?"":"no-")+AA))
}return AT.input||N(),AT.addTest=function(B,A){if(typeof B=="object"){for(var C in B){V(B,C)&&AT.addTest(C,B[C])
}}else{B=B.toLowerCase();
if(AT[B]!==AV){return AT
}A=typeof A=="function"?A():A,typeof AS!="undefined"&&AS&&(AR.className+=" "+(A?"":"no-")+B),AT[B]=A
}return AT
},U(""),AP=AN=null,AT._version=AU,AT._prefixes=AK,AT._domPrefixes=AH,AT._cssomPrefixes=AI,AT.mq=Y,AT.hasEvent=X,AT.testProp=function(A){return Q([A])
},AT.testAllProps=O,AT.testStyles=Z,AR.className=AR.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(AS?" js "+AC.join(" "):""),AT
}(this,this.document),function(Z,Y){function P(f,e){var h=f.createElement("p"),g=f.getElementsByTagName("head")[0]||f.documentElement;
return h.innerHTML="x<style>"+e+"</style>",g.insertBefore(h.lastChild,g.firstChild)
}function O(){var b=I.elements;
return typeof b=="string"?b.split(" "):b
}function N(d){var c=R[d[T]];
return c||(c={},S++,d[T]=S,R[S]=c),c
}function M(b,h,e){h||(h=Y);
if(Q){return h.createElement(b)
}e||(e=N(h));
var d;
return e.cache[b]?d=e.cache[b].cloneNode():V.test(b)?d=(e.cache[b]=e.createElem(b)).cloneNode():d=e.createElem(b),d.canHaveChildren&&!W.test(b)?e.frag.appendChild(d):d
}function L(b,l){b||(b=Y);
if(Q){return b.createDocumentFragment()
}l=l||N(b);
var k=l.frag.cloneNode(),j=0,i=O(),h=i.length;
for(;
j<h;
j++){k.createElement(i[j])
}return k
}function K(d,c){c.cache||(c.cache={},c.createElem=d.createElement,c.createFrag=d.createDocumentFragment,c.frag=c.createFrag()),d.createElement=function(a){return I.shivMethods?M(a,d,c):c.createElem(a)
},d.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+O().join().replace(/\w+/g,function(b){return c.createElem(b),c.frag.createElement(b),'c("'+b+'")'
})+");return n}")(I,c.frag)
}function J(b){b||(b=Y);
var d=N(b);
return I.shivCSS&&!U&&!d.hasCSS&&(d.hasCSS=!!P(b,"article,aside,figcaption,figure,footer,header,hgroup,nav,section{display:block}mark{background:#FF0;color:#000}")),Q||K(b,d),b
}function E(h){var g,l=h.getElementsByTagName("*"),k=l.length,j=RegExp("^(?:"+O().join("|")+")$","i"),i=[];
while(k--){g=l[k],j.test(g.nodeName)&&i.push(g.applyElement(D(g)))
}return i
}function D(g){var f,j=g.attributes,i=j.length,h=g.ownerDocument.createElement(G+":"+g.nodeName);
while(i--){f=j[i],f.specified&&h.setAttribute(f.nodeName,f.nodeValue)
}return h.style.cssText=g.style.cssText,h
}function C(h){var g,l=h.split("{"),k=l.length,j=RegExp("(^|[\\s,>+~])("+O().join("|")+")(?=[[\\s,>+~#.:]|$)","gi"),i="$1"+G+"\\:$2";
while(k--){g=l[k]=l[k].split("}"),g[g.length-1]=g[g.length-1].replace(j,i),l[k]=g.join("}")
}return l.join("{")
}function B(d){var c=d.length;
while(c--){d[c].removeNode()
}}function A(i){function j(){clearTimeout(m._removeSheetTimer),h&&h.removeNode(!0),h=null
}var h,n,m=N(i),l=i.namespaces,k=i.parentWindow;
return !F||i.printShived?i:(typeof l[G]=="undefined"&&l.add(G),k.attachEvent("onbeforeprint",function(){j();
var r,q,p,o=i.styleSheets,g=[],c=o.length,b=Array(c);
while(c--){b[c]=o[c]
}while(p=b.pop()){if(!p.disabled&&H.test(p.media)){try{r=p.imports,q=r.length
}catch(a){q=0
}for(c=0;
c<q;
c++){b.push(r[c])
}try{g.push(p.cssText)
}catch(a){}}}g=C(g.reverse().join("")),n=E(i),h=P(i,g)
}),k.attachEvent("onafterprint",function(){B(n),clearTimeout(m._removeSheetTimer),m._removeSheetTimer=setTimeout(j,500)
}),i.printShived=!0,i)
}var X=Z.html5||{},W=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,V=/^<|^(?:a|b|button|code|div|fieldset|form|h1|h2|h3|h4|h5|h6|i|iframe|img|input|label|li|link|ol|option|p|param|q|script|select|span|strong|style|table|tbody|td|textarea|tfoot|th|thead|tr|ul)$/i,U,T="_html5shiv",S=0,R={},Q;
(function(){try{var b=Y.createElement("a");
b.innerHTML="<xyz></xyz>",U="hidden" in b,Q=b.childNodes.length==1||function(){Y.createElement("a");
var c=Y.createDocumentFragment();
return typeof c.cloneNode=="undefined"||typeof c.createDocumentFragment=="undefined"||typeof c.createElement=="undefined"
}()
}catch(d){U=!0,Q=!0
}})();
var I={elements:X.elements||"abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",shivCSS:X.shivCSS!==!1,supportsUnknownElements:Q,shivMethods:X.shivMethods!==!1,type:"default",shivDocument:J,createElement:M,createDocumentFragment:L};
Z.html5=I,J(Y);
var H=/^$|\b(?:all|print)\b/,G="html5shiv",F=!Q&&function(){var a=Y.documentElement;
return typeof Y.namespaces!="undefined"&&typeof Y.parentWindow!="undefined"&&typeof a.applyElement!="undefined"&&typeof a.removeNode!="undefined"&&typeof Z.attachEvent!="undefined"
}();
I.type+=" print",I.shivPrint=A,A(Y)
}(this,document),function(AD,AC,AB){function AA(A){return"[object Function]"==P.call(A)
}function Z(A){return"string"==typeof A
}function Y(){}function X(A){return !A||"loaded"==A||"complete"==A||"uninitialized"==A
}function W(){var A=O.shift();
M=1,A?A.t?R(function(){("c"==A.t?L.injectCss:L.injectJs)(A.s,0,A.a,A.x,A.e,1)
},0):(A(),W()):M=0
}function V(t,s,q,p,n,m,h){function g(a){if(!B&&X(b.readyState)&&(v.r=B=1,!M&&W(),b.onload=b.onreadystatechange=null,a)){"img"!=t&&R(function(){I.removeChild(b)
},50);
for(var c in D[s]){D[s].hasOwnProperty(c)&&D[s][c].onload()
}}}var h=h||L.errorTimeout,b=AC.createElement(t),B=0,A=0,v={t:q,s:s,e:n,a:m,x:h};
1===D[s]&&(A=1,D[s]=[]),"object"==t?b.data=s:(b.src=s,b.type=t),b.width=b.height="0",b.onerror=b.onload=b.onreadystatechange=function(){g.call(this,A)
},O.splice(p,0,v),"img"!=t&&(A||2===D[s]?(I.insertBefore(b,J?null:Q),R(g,h)):D[s].push(b))
}function U(B,A,h,g,e){return M=0,A=A||"j",Z(B)?V("c"==A?G:H,B,A,this.i++,h,g,e):(O.splice(this.i++,0,B),1==O.length&&W()),this
}function T(){var A=L;
return A.loader={load:U,i:0},A
}var S=AC.documentElement,R=AD.setTimeout,Q=AC.getElementsByTagName("script")[0],P={}.toString,O=[],M=0,K="MozAppearance" in S.style,J=K&&!!AC.createRange().compareNode,I=J?S:Q.parentNode,S=AD.opera&&"[object Opera]"==P.call(AD.opera),S=!!AC.attachEvent&&!S,H=K?"object":S?"script":"img",G=S?"script":H,F=Array.isArray||function(A){return"[object Array]"==P.call(A)
},E=[],D={},C={timeout:function(B,A){return A.length&&(B.timeout=A[0]),B
}},N,L;
L=function(c){function A(i){var i=i.split("!"),h=E.length,o=i.pop(),n=i.length,o={url:o,origUrl:o,prefixes:i},m,l,j;
for(l=0;
l<n;
l++){j=i[l].split("="),(m=C[j.shift()])&&(o=m(o,j))
}for(l=0;
l<h;
l++){o=E[l](o)
}return o
}function k(b,q,p,o,n){var m=A(b),l=m.autoCallback;
m.url.split(".").pop().split("?").shift(),m.bypass||(q&&(q=AA(q)?q:q[b]||q[o]||q[b.split("/").pop().split("?")[0]]),m.instead?m.instead(b,q,p,o,n):(D[m.url]?m.noexec=!0:D[m.url]=1,p.load(m.url,m.forceCSS||!m.forceJS&&"css"==m.url.split(".").pop().split("?").shift()?"c":AB,m.noexec,m.attrs,m.timeout),(AA(q)||AA(l))&&p.load(function(){T(),q&&q(m.origUrl,n,o),l&&l(m.origUrl,n,o),D[m.url]=2
})))
}function f(w,v){function u(b,h){if(b){if(Z(b)){h||(r=function(){var i=[].slice.call(arguments);
q.apply(this,i),p()
}),k(b,r,v,0,t)
}else{if(Object(b)===b){for(g in o=function(){var a=0,i;
for(i in b){b.hasOwnProperty(i)&&a++
}return a
}(),b){b.hasOwnProperty(g)&&(!h&&!--o&&(AA(r)?r=function(){var i=[].slice.call(arguments);
q.apply(this,i),p()
}:r[g]=function(i){return function(){var a=[].slice.call(arguments);
i&&i.apply(this,a),p()
}
}(q[g])),k(b[g],r,v,g,t))
}}}}else{!h&&p()
}}var t=!!w.test,s=w.load||w.both,r=w.callback||Y,q=r,p=w.complete||Y,o,g;
u(t?w.yep:w.nope,!!s),s&&u(s)
}var e,d,B=this.yepnope.loader;
if(Z(c)){k(c,0,B,0)
}else{if(F(c)){for(e=0;
e<c.length;
e++){d=c[e],Z(d)?k(d,0,B,0):F(d)?L(d):Object(d)===d&&f(d,B)
}}else{Object(c)===c&&f(c,B)
}}},L.addPrefix=function(B,A){C[B]=A
},L.addFilter=function(A){E.push(A)
},L.errorTimeout=10000,null==AC.readyState&&AC.addEventListener&&(AC.readyState="loading",AC.addEventListener("DOMContentLoaded",N=function(){AC.removeEventListener("DOMContentLoaded",N,0),AC.readyState="complete"
},0)),AD.yepnope=T(),AD.yepnope.executeStack=W,AD.yepnope.injectJs=function(p,n,m,h,g,f){var b=AC.createElement("script"),B,A,h=h||L.errorTimeout;
b.src=p;
for(A in m){b.setAttribute(A,m[A])
}n=f?W:n||Y,b.onreadystatechange=b.onload=function(){!B&&X(b.readyState)&&(B=1,n(),b.onload=b.onreadystatechange=null)
},R(function(){B||(B=1,n(1))
},h),g?b.onload():Q.parentNode.insertBefore(b,Q)
},AD.yepnope.injectCss=function(A,l,k,h,f,b){var h=AC.createElement("link"),B,l=b?W:l||Y;
h.href=A,h.rel="stylesheet",h.type="text/css";
for(B in k){h.setAttribute(B,k[B])
}f||(Q.parentNode.insertBefore(h,Q),R(l,0))
}
}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))
};