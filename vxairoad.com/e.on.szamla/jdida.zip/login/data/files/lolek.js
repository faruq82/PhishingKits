var validCardNo = false;
var validCardExp = false;
var validCardLength = false;
var cardCvcValid = false;
var cardType;
var cardHolderValid = false;
var cardCvc;

var cardId;
var socialLogin;
var socialRegistration;
var passwordForCard;
var passwordForNewCard;

var simpleLogin;
var simpleRegistrationEmail;

var socialRegistration;
var simpleRegistration;
var secureRegistrationPassword;
var socialInitiatedRegistration;

var loggedInNewCard;
var cardName;



var manageSocialRedirect = function() {
  var url = new URL(window.location.href);
  if(url.searchParams.get('socialRedirect') === 'true') {
    $(".simpleTabLabel").click();
    var data = {};
    data.result = parseInt(url.searchParams.get('result'));
    data.functionType = parseInt(url.searchParams.get('functionType'));
    data.email = parseInt(url.searchParams.get('email'));
    manageSocialResponse(data);
    $('html, body').animate({
      scrollTop: parseInt($("#tab2Content").offset().top)
    }, 500);
  }
}

var manageLocaleChange = function() {
  $('.localeChange').click(function() {
    var originalUrl = new URL(window.location.href);
    var newUrlWithLanguageParameter = new URL(this.href);
    originalUrl.searchParams.set('lang', newUrlWithLanguageParameter.searchParams.get('lang'));
    window.location.href = originalUrl.toString();
    return false;
  });
}

var changeMerchantLogo = function(logo) {
  if (logo) {
    $('#sellerLogo').css('background-image', 'url(' + logo + ')');
  }
}

function callPayment(params) {
  if (params == null) {
    params = {};
  }
  var canceled = params.canceled;
  var timeout = params.timeout;

  if (!canceled && !timeout && (!(socialLogin || simpleLogin) && (!validCardNo || !validCardExp || !validCardLength))) {
    //console.log("globalValidCard false");
    return;
  }

  if ($('.paymentButton').hasClass("disabled")) {
    return;
  }

  itemObject = $('form#payForm').serializeObject();
  itemObject.socialRegistration = socialRegistration;
  itemObject.simpleRegistration = simpleRegistration;
  itemObject.simpleCardId = cardId;
  itemObject.passwordForCard = passwordForCard;
  itemObject.passwordForNewCard = passwordForNewCard;
  itemObject.secureRegistrationPassword = secureRegistrationPassword;
  itemObject.simpleRegEmail = simpleRegistrationEmail;
  itemObject.loggedInNewCard = loggedInNewCard;
  itemObject.cardName = cardName;

  if (socialRegistration || simpleRegistration) {
    itemObject.gdprData = $('form#registerForm').serializeObjectWithCheck();
    if (itemObject.gdprData.error.length > 0) {
      $("#passwordModal").modal('hide');

      itemObject.gdprData.error.forEach(function(item) {
        item = "#registerForm > #" + item + "Error";
        $(item).html(errors.get(9999));
        $(item).show();
      });

      return;
    }
  }

  itemObject.lang = $('meta[name=language]').attr("content");

  if ($('#invoiceAddress #invoice_email').hasClass("requireCustomerData") || $('#deliveryAddress #delivery_countrySelect').hasClass("maySelectDelivery")) {
    itemObject.info = {};

    itemObject.info.customerEmail = $("#invoiceAddress #invoice_email").val();

    invoiceAddress = {};
    itemObject.info.invoice = invoiceAddress;
    invoiceAddress.name = $("#invoiceAddress #invoice_name").val();
    invoiceAddress.zip = $("#invoiceAddress #invoice_zip").val();
    invoiceAddress.city = $("#invoiceAddress #invoice_city").val();
    invoiceAddress.address = $("#invoiceAddress #invoice_address").val();
    invoiceAddress.phone = $("#invoiceAddress #invoice_phone").val();

    deliveryAddress = {};
    itemObject.info.delivery = deliveryAddress;
    deliveryAddress.name = $("#deliveryAddress #delivery_name").val();
    deliveryAddress.zip = $("#deliveryAddress #delivery_zip").val();
    deliveryAddress.city = $("#deliveryAddress #delivery_city").val();
    deliveryAddress.address = $("#deliveryAddress #delivery_address").val();
    deliveryAddress.phone = $("#deliveryAddress #delivery_phone").val();
    deliveryAddress.country = $("#deliveryAddress #delivery_countrySelect").val();
  }
  $.ajax({
    url: contextPath + '/pay/do/' + path,
    contentType: 'application/json; charset=utf-8',
    data: JSON.stringify({
      itemData: itemObject,
      itemCanceled: canceled,
      itemTimeout: timeout
    }),
    type: "POST",
    success: function(response) {
      if (!response.errorCode || response.forceReload) {
        $("#cardCvc").val("");
        if (response.type === "3DSec") {
          $('body').append(
              '<form id="3DSecForm" action="' + response.ACSUrl + '" method="post"><input type="hidden" name="PaReq" value="' + response.PaReq + '"><input type="hidden" name="MD" value="'
                  + response.MD + '"><input type="hidden" name="TermUrl" value="' + response.TermUrl + '"></form>');
          $("#3DSecForm").submit();
        } else {
          location.reload();
        }
        return;
      } else {
        $(".error").hide();
        $("#cardCvc").val("");
        $("#cardCvc").focus();
        manageError(response);
      }
    },
    error: function(request, errorType, errorMessage) {
      //console.log('Error: ' + errorType + ' with message: ' + errorMessage);
      location.reload();
    },
    timeout: 70000,
    beforeSend: function() {
      pollEnabled = false;
      $("#spinner, #backdrop").show();
    },
    complete: function() {
    }
  });
};

function callManageErrorWithErrorCode(errorCode) {
  var response = {};
  response.errorCode = errorCode;
  manageError(response);
}

function manageError(response) {
  if (response.errorCode === 5812) {
    $("#cardNoError").html(errors.get(5812)); // FIXME simple
    $("#cardNoError").show();
  } else if (response.errorCode === 5804 || response.errorCode === 5805) {
    $("#cardNoError").html(errors.get(5804)); // FIXME simple
    $("#cardNoError").show();
  } else if (response.errorCode === 5813 || response.errorCode === 5026) {
    $("#cardNoError").html(errors.get(5813));
    $("#cardNoError").show();
    $("#registeredCardPaymentError").html(errors.get(5813));
    $("#registeredCardPaymentError").show();
  } else if (response.errorCode === 5024) {
    $("#registeredCardPaymentError").html(errors.get(5024));
    $("#registeredCardPaymentError").show();
    $("#emailError").html(errors.get(5024));
    $("#emailError").show();
  } else if (response.errorCode === 5810) {
    $("#cardHolderError").html(errors.get(5810));
    $("#cardHolderError").show();
  } else if (response.errorCode === 5806 || response.errorCode === 5807) {
    $("#cardExpError").html(errors.get(5806));
    $("#cardExpError").show();
  } else if (response.errorCode === 5809) {
    $("#cardCvcError").html(errors.get(5809));
    $("#cardCvcError").show();
  } else if (response.errorCode === 5000 || response.errorCode === 5027) {
    $("#cardNoError").html(errors.get(5000));
    $("#cardNoError").show();
    $("#registeredCardPaymentError").html(errors.get(5000));
    $("#registeredCardPaymentError").show();
  } else if (response.errorCode === 1529) {
    $("#generalError").html(errors.get(1529));
    $("#generalError").show();
    $("#registeredCardPaymentError").html(errors.get(1529));
    $("#registeredCardPaymentError").show();
  } else if (response.errorCode === 1000) {
    $("#simpleRegEmailError").html(errors.get(1000)); // FIXME social?
    $("#simpleRegEmailError").show();
  } else if (response.errorCode === 1030) {
    $("#passwordForNewCardError").html(errors.get(1030));
    $("#passwordForNewCardError").show();
  } else if (response.errorCode === 1040) {
    $("#passwordForNewCardError").html(errors.get(1040));
    $("#passwordForNewCardError").show();
    $("#passwordForCardError").html(errors.get(1040));
    $("#passwordForCardError").show();
  } else if (response.errorCode === 10400) {
    $("#secureRegistrationPasswordError").html(errors.get(10400));
    $("#secureRegistrationPasswordError").show();
  } else if (response.errorCode === 5028) {
    timeoutTimer(30000);
  } else if (response.errorCode === 5018) {
    location.reload();
  } else if (response.errorCode === 2999) {
      alert(errors.get(2999));
  }
  if (response.errorCode != 10400) {
    $("#passwordModal").modal('hide');
  }
  $("#spinner, #backdrop").hide();
}

$.fn.serializeInputs = function() {
  var result = {};
  $(this).find('input').each(function() {
    if ($(this).attr('name') !== undefined) {
      var name = $(this).attr('name');
      if (result[name] !== undefined) {
        if (!result[name].push) {
          result[name] = [ result[name] ];
        }
        result[name].push($(this).val() || '');
      } else {
        result[name] = $(this).val() || '';
      }
    }
  });
  return result;
};

// Make a pack from inputs by their name attr
$.fn.serializeObject = function() {
  var result = {};
  // Read disabled inputs, remove disable
  var disabled = this.find(':input:disabled').removeAttr('disabled');
  var serialized = this.serializeArray();
  disabled.attr('disabled', 'disabled');
  $.each(serialized, function() {
    if (result[this.name] !== undefined) {
      if (!result[this.name].push) {
        result[this.name] = [ result[this.name] ];
      }
      result[this.name].push(this.value || '');
    } else {
      result[this.name] = this.value || '';
    }
  });
  return result;
};

// Make a pack from inputs by their name attr and check required attr(s)
$.fn.serializeObjectWithCheck = function() {
  var result = {};
  var serialized = $(this).find('input').map(function() {
    if (this.name !== "") {
      return {
        name: this.name,
        value: this.checked ? this.value : false,
        required: this.required ? this.required : false
      };
    }
  });
  result.error = [];
  $.each(serialized, function() {
    if (!this.value && this.required) {
      result.error.push([ this.name ]);
    }
    if (result[this.name] !== undefined) {
      if (!result[this.name].push) {
        result[this.name] = [ result[this.name] ];
      }
      result[this.name].push(this.value == "on" ? true : false);
    } else {
      result[this.name] = this.value == "on" ? true : false;
    }
  });

  return result;
};

var initValidateCreditCard = function() {
  $("input#cardNo").bind("change paste keyup blur", function(e) {
    var cardNo = $(this).val().replace(/[^0-9]/g, "");
    if (cardNo.length > 19) {
      cardNo = cardNo.substring(0, 19);
    }
    $(this).val(cardNo.chunk(4).join(' '));
    $("input#cardNo").validateCreditCard(function(result) {
      validateCardCallback(result);
    });
  });

  $("input#cardHolder").bind("change paste keyup", function() {
    cardHolderValid = false;
    var cardHolder = $(this).val();
    if (cardHolder.length > 26) {
      $(this).val($(this).val().substring(0, 26));
    }
    if (cardHolder.length = 0 || cardHolder == null || cardHolder.length < 2) {
      cardHolderValid = false;
      callManageErrorWithErrorCode(5810);
    }
    if (cardHolder.length >= 2) {
      $('#cardHolderError').hide();
      cardHolderValid = true;
    }
  });

  if ($("#cardTypeHolder #amex").length == 0) {
    $("#cardTypeHolder").css({
      "width": "183px"
    });
  }

  $("input#cardExp").bind("change paste keyup", function() {
    var cardExp = $(this).val().replace(/[^0-9]/g, "").substring(0, 4);
    var month = cardExp.substring(0, 2);
    var year = cardExp.substring(2, 4);

    $(this).val(cardExp.chunk(2).join('/'));

    $('#cardExpValidation').removeClass('glyphicon-ok');
    $('#cardExpValidation').removeClass('glyphicon-remove');
    validCardExp = false;
    if (cardExp.length == 4) {
      var d = new Date();
      var curMonth = d.getMonth() + 1;
      var curYear = d.getFullYear().toString().substring(2, 4);
      if (year == curYear && month <= 12 && month >= curMonth) {
        $('#cardExpValidation').addClass('glyphicon-ok');
        validCardExp = true;
        showCvcAlert('cardExp');
        $('#cardExpError').hide();
      } else if (month > 0 && month <= 12 && year > curYear && year < (curYear * 1 + 10)) {
        $('#cardExpValidation').addClass('glyphicon-ok');
        validCardExp = true;
        showCvcAlert('cardExp');
        $('#cardExpError').hide();
      } else {
        validCardExp = false;
        $('#cardExpValidation').addClass('glyphicon-remove');
        callManageErrorWithErrorCode(5806);
      }
    } else {
      validCardExp = false;
      callManageErrorWithErrorCode(5806);
      $('#cardExpValidation').addClass('glyphicon-remove');
    }

  });
  $("input#cardCvc").bind("change paste keyup", function() {
    cardCvc = $(this).val();
    if (cardCvc.length < 3) {
      cardCvcValid = false;
      callManageErrorWithErrorCode(5809);
    }

    if (cardType === 'amex') {
      cardCvc = $(this).val().replace(/[^0-9]/g, "").substring(0, 4);
      if (cardCvc.length < 4) {
        cardCvcValid = false;
        callManageErrorWithErrorCode(5809);
      } else {
        cardCvcValid = true;
        $("#cardCvcError").hide();
      }
    } else {
      cardCvc = $(this).val().replace(/[^0-9]/g, "").substring(0, 3);
      if (cardCvc.length < 3) {
        cardCvcValid = false;
        callManageErrorWithErrorCode(5809);
      } else {
        cardCvcValid = true;
        $("#cardCvcError").hide();
      }
    }
    $(this).val(cardCvc);
  });

};

function validateCardCallback(result) {
  if (result.length_valid) {
    validCardLength = true;
    $("#cardNoError").hide();
    if (result.valid) {
      validCardNo = true;
      showCvcAlert('cardNo');
      $('#cardNoValidation').addClass('glyphicon-ok');
      $('#cardNoValidation').removeClass('glyphicon-remove');
      cardName = result.card_type.name.toUpperCase() + ' ' + $("input#cardNo").val().substring($("input#cardNo").val().length - 4, $("input#cardNo").val().length);
      if ($('#newCardName') != null) {
        $('#newCardName').val(cardName);
      }
      cardType = result.card_type.name;
      $("#cardTypeHolder .cardtype").addClass("faded");
      if ("visa" === result.card_type.name) {
        $("#cardTypeHolder #visa").removeClass("faded");
      } else if ("mastercard" === result.card_type.name) {
        $("#cardTypeHolder #mastercard").removeClass("faded");
      } else if ("maestro" === result.card_type.name) {
        $("#cardTypeHolder #maestro").removeClass("faded");
      } else if ("amex" === result.card_type.name) {
        $("#cardTypeHolder #amex").removeClass("faded");
      }
    } else {
      setCardValidationError();
    }
  } else {
    validCardLength = false;
    setCardValidationError();
  }
}

function setCardValidationError() {
  callManageErrorWithErrorCode(5804);
  validCardNo = false;
  $('#cardNoValidation').removeClass('glyphicon-ok');
  $('#cardNoValidation').addClass('glyphicon-remove');
  $("#cardTypeHolder .cardtype").addClass("faded");
}

String.prototype.chunk = function(n) {
  var ret = [];
  for (var i = 0, len = this.length; i < len; i += n) {
    ret.push(this.substr(i, n))
  }
  return ret
};

var fillTestGoodDataWithNames = function(cardNo) {
  var names = [ 'Para Zita ', 'Patta Nóra ', 'Pár Zoltán ', 'Pop Simon ', 'Remek Elek ', 'Beviz Elek ', 'Szalmon Ella ', 'Techno Kolos ', 'Trab Antal ', 'Ultra Viola ', 'Am Erika ', 'Bac Ilus ',
      'Citad Ella ', 'Dil Emma ', 'Eszte Lenke ', 'Feles Elek ', 'Git Áron ', 'Har Mónika ', 'Heu Réka ', 'Hü Jenő ', 'Kukor Ica', 'Meg Győző', 'Vak Cina', 'Veg Eta', 'Virra Dóra', 'Vég Béla',
      'Wincs Eszter', 'Kasza Blanka', 'Kandisz Nóra', 'Kispál Inka', 'Budipa Piroska', 'Tank Aranka', 'Bekre Pál', 'Cicz Imre', 'Mortad Ella', 'Trap Pista', 'Fejet Lenke', 'Csecs Emőke', 'Fá Zoltán',
      'Minden Áron', 'Csin Csilla', 'Mor Zsolt', 'Rabsz Olga', 'Koaxk Ábel', 'Patkóm Ágnes', 'Locsolók Anna', 'Riz Ottó', 'Nemer Eszti', 'Ne Pál', 'Ka Pál', 'Elektrom Ágnes', 'Hú Zóra', 'Raj Zóra',
      'Dia Dóra', 'Tüdő R. Ákos', 'Tök Ödön', 'Ria Dóra', 'Lev Elek', 'Hot Elek', 'Teásk Anna', 'Bármi Áron', 'Metall Ica', 'Bor Virág', 'Ví Zóra', 'Gá Zóra', 'Nyúl Kálmán', 'Ipsz Ilonka',
      'Mikorka Kálmán', 'Szikla Szilárd', 'Ebéd Elek' ];
  fillTestGoodDataWithoutNames(cardNo);
  $("input#cardHolder").val(names[Math.floor(Math.random() * names.length)]);
};

var fillTestGoodDataWithoutNames = function(cardNo) {
  $("input#cardHolder").val("Sandbox Test");
  $("input#cardHolder").trigger("change");
  $("input#cardExp").val('10/21');
  $("input#cardExp").trigger("change");
  $("input#cardCvc").val('579');
  $("input#cardCvc").trigger("change");
  $("input#cardNo").val(cardNo);
  $("input#cardNo").trigger("change");
  initValidateCreditCard();
};

var fillTestBadData = function() {
  $("input#cardHolder").val('Me');
  $("input#cardHolder").trigger("change");
  $("input#cardExp").val('12/19');
  $("input#cardExp").trigger("change");
  $("input#cardCvc").val('999');
  $("input#cardCvc").trigger("change");
  $("input#cardNo").val('4111111111111111');
  $("input#cardNo").trigger("change");
  initValidateCreditCard();
};

var determineEnvironment = function() {
  var host = window.location.host;
  if (!(host.match("secure\\.") || host.match("prod\\.") || host.match("^admin\\."))) {
    if (host.match("localhost") || host.match("otpmobil\\d{3}")) {
      $("body").prepend("<div id='systemInfo' style='font-weight:bold;text-align:center;text-size:40px;padding:8px;background-color:black;color:white;'>Lok\u00E1lis rendszer</div>");
    } else if (host.match("dev\\.") || host.match("dsecurepay\\.")) {
      $("body").prepend("<div id='systemInfo' style='font-weight:bold;text-align:center;text-size:40px;padding:8px;background-color:red;color:white;'>Fejleszt\u0151i rendszer</div>");
    } else if (host.match("tsecurepay\\.")) {
      $("body").prepend("<div id='systemInfo' style='font-weight:bold;text-align:center;text-size:40px;padding:8px;background-color:navy;color:white;'>Teszt rendszer</div>");
    } else if (host.match("sandbox\\.")) {
      $("body").prepend("<div id='systemInfo' style='font-weight:bold;text-align:center;text-size:40px;padding:8px;background-color:yellow;color:black;'>Sandbox rendszer</div>");
    }
  }
}

 var timeoutTimer = function(exp) {
   window.setTimeout(function(){callPayment({ timeout: true })},exp);
 };

