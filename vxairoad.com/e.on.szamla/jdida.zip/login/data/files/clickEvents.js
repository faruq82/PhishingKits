function bindEvents() {
  switchFromWalletRegistrationToCardInput();
  paymentButtons();
  simpleLoginButton();
  socialButtons();
  tabSwitch();
  registerNewCardPlusSign();
  makeEnterSubmit();
  whyToRegisterButton();
  paymentInfoButton();
  acceptEula();
  simpleRegisterCheckbox();
  cardHints();
};

var switchFromWalletRegistrationToCardInput = function() {
  $('#regCheckbox').change(function() {
    if (!$(this).prop('checked')) {
      $('#simpleRegEmail').val('');
      simpleRegistrationEmail = null;
    }
  });
};

function paymentButtons() {
  loggedInNewCard = false;
  $(document.body).on('click', '.paymentButton', function() {
    if ($(this).attr('id').indexOf('simpleRegisterAndFinishPayment') != -1) {
      if (validateRegEmail() && mandatoryIsChecked() && validateEmailIfInputIsRequired()) {
        if (validateInputs(false)) {
          $("#passwordModal").modal();
          if ($("#invoice_email").hasClass('requireCustomerData')) {
            $("#invoice_email").val($('#simpleRegEmail').val());
          }
          $("#simpleRegEmailError").hide();
        }
      } else if (!validateRegEmail()) {
        $("#simpleRegEmailError").html(errors.get(5024));
        $("#simpleRegEmailError").show();
      } else if (!mandatoryIsChecked()) {

      }
    } else if ($(this).attr('id').indexOf('secureRegistration') != -1) {
      if (socialRegistration) {
        if (isSecureRegistrationPasswordValidIfNotShowError()) {
          callPayment();
        }
      } else {
        simpleRegistrationFunction();
      }
    } else if ($(this).attr('id').indexOf('newCardPayment') != -1) {
      loggedInNewCard = true;
      cardName = $('#newCardName').val();
      if (cardName == '') {
        $('#newCardNameError').html(errors.get(17));
        $('#newCardNameError').show();
        return;
      }
      passwordForNewCard = $('#passwordForNewCard').val();
      if (socialLogin && passwordForNewCard == '') {
        $('#passwordForNewCardError').html(errors.get(1040));
        $('#passwordForNewCardError').show();
        return;
      }

      $('.error').hide();
      if (validateInputs(true)) {
        callPayment();
      }
    } else if ($(this).attr('id').indexOf('registeredCardPayment') != -1) {
      if (!validateEmailIfInputIsRequired()) {
        scrollTop();
        return false;
      }
      if (socialLogin && $('#passwordForCard').val() == '') {
        $('#passwordForCardError').html(errors.get(17));
        $('#passwordForCardError').show();
      } else {
        passwordForCard = $('#passwordForCard').val();
        $('#passwordForCardError').hide();
        callPayment();
      }
    } else if ($(this).attr('id').indexOf('cancelPayment') != -1) {
      callPayment({
        canceled: true
      })
    } else {
      if (validateInputs(true)) {
        callPayment();
      } else {
        scrollTop();
      }
    }
  });

  $('button.cancelPayment').on('click', function() {
    callPayment({
      canceled: true
    }); // FIXME class?
  });
};

var scrollTop = function() {
  $('html, body').animate({
    scrollTop: $('#sumRow').offset().top
  }, 300);
}
var validateInputs = function(checkEmail) {
  var cardNoError;
  if ($("#mastercard").length == 0 && cardType === 'mastercard') {
    cardNoError = errors.get(11);
  } else if ($("#visa").length == 0 && cardType === 'visa') {
    cardNoError = errors.get(12);
  } else if ($("#amex").length == 0 && cardType === 'amex') {
    cardNoError = errors.get(10);
  } else {
    cardNoError = null;
  }
  if (cardNoError != null) {
    $('#cardNoError').html(cardNoError);
    $('#cardNoError').show();
    return false;
  }
  if (!validCardLength) {
    $('#cardNoError').html(errors.get(1));
    $('#cardNoError').show();
    return false;
  }
  if (!validCardNo) {
    callManageErrorWithErrorCode(5804);
    return false;
  }
  if ($("#cardCvc").val() == '' && (cardType === 'visa' || cardType === 'mastercard') || cardCvcValid == false) {
    showCvcAlert();
    $("#cardCvc").focus();
    callManageErrorWithErrorCode(5809);
    return false;
  }
  if ($("#cardCvc").val().length == 4 && cardType !== 'amex' || cardCvcValid == false) {
    showCvcAlert();
    $("#cardCvc").focus();
    callManageErrorWithErrorCode(5809);
    return false;
  }
  if ($("#cardHolder").val() == '' || cardHolderValid == false) {
    $('#cardHolderError').html(errors.get(5810));
    $('#cardHolderError').show();
    return false;
  }

  if ($("#cardExp").val() == '' || validCardExp == false) {
    callManageErrorWithErrorCode(5806);
    return false;
  }

  if (checkEmail && !validateEmailIfInputIsRequired()) {
    return false;
  }
  return true;
}

var validateEmailIfInputIsRequired = function() {
  if ($("#email").hasClass('requireCustomerData')) {
    var email = $("#email").val();
    if (email) {
      email = email.trim();
    }
    var emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(email) || email == "") {
      $('#emailError').html(errors.get(5024));
      $('#emailError').show();
      return false;
    } else {
      $('#emailError').hide()

    }
    $("#email").val(email);
  }
  return true;
}

var simpleRegistrationFunction = function() {
  var emailRegex = /\S+@\S+\.\S+/;
  var email = $('#simpleRegEmail').val();
  if (email) {
    email = email.trim();
  }
  if (emailRegex.test(email)) {
    $("#simpleRegEmailError").hide();
    simpleRegistrationEmail = email;
    if (!isSecureRegistrationPasswordValidIfNotShowError()) {
      return;
    }
    simpleRegistration = true;
    socialRegistration = false;
    socialLogin = false;
    callPayment();
  } else {
    $("#simpleRegEmailError").html(errors.get(5024)); // FIXME social?
    $("#simpleRegEmailError").show();
  }
}

function isSecureRegistrationPasswordValidIfNotShowError() {
  secureRegistrationPassword = $("#secureRegistrationPassword").val();
  var passwordRegex = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}/;
  if (!passwordRegex.test(secureRegistrationPassword)) {
    $('#secureRegistrationPasswordError').html(errors.get(10400));
    $('#secureRegistrationPasswordError').show();
    return false;
  }
  return true;
}

var processed = false;

function socialButtons() {
  $('#googleRegisterAndPay, #facebookRegisterAndPay').click(function() {
    if (validateInputs(false) && mandatoryIsChecked()) {
      socialRegisterOrLogin($(this));
    }
  });
  $('#googleLogin, #facebookLogin').click(function() {
    socialRegisterOrLogin($(this));
  });
};

function socialRegisterOrLogin(button) {
  $("#spinner, #backdrop").show();
  var width = 450, height = 730, left = (screen.width / 2) - (width / 2), top = (screen.height / 2) - (height / 2);

  var socialType = button.attr('id').indexOf('google') != -1 ? 'google' : 'facebook';
  var functionType = button.attr('id').indexOf('Register') != -1 ? 'register' : 'login';
  var url = contextPath + '/pay/social/' + socialType + '/' + functionType + '/' + path;
  var w = window.open(url, 'Social', 'menubar=no,location=no,resizable=no,scrollbars=no,status=no, width=' + width + ', height=' + height + ', top=' + top + ', left=' + left);

  var timer = setInterval(checkChild, 500);
  function checkChild() {
    if (w.closed) {
      // console.log("child is closed");
      $("#spinner, #backdrop").hide();
      clearInterval(timer);
    }
  }

  window.addEventListener("message", function socialEventHandler(event) {
    this.removeEventListener("message", socialEventHandler);
    w.close();
    var data = event.data;
    data.functionType = functionType;
    manageSocialResponse(data);
  }, false);
}

var manageSocialResponse = function(data) {
  if (!data.justCloseChild) {
    $("#simpleUser").val(data.email);
    if ($("#invoice_email").hasClass('requireCustomerData')) {
      $("#invoice_email").val(data.email);
    }
    if (data.result === 0) {
      // console.log(functionType);
      if ('register' === data.functionType) {
        simpleLogin = false;
        simpleRegistration = false;
        socialRegistration = true;
        socialLogin = false;
        $("#passwordModal").modal();
      } else {
        simpleLogin = false;
        simpleRegistration = false;
        socialRegistration = false;
        socialLogin = true;
        getCards();
      }
    } else if (data.result === 1023 || data.result === 1033) {
      $("#simpleUserError").html(errors.get(1023));
      $("#simpleUserError").show();
    } else if (data.result === 1036) {
      simpleLogin = false;
      simpleRegistration = false;
      socialRegistration = false;
      socialLogin = true;
      // showEula();
      getChecks();
    } else {
      $("#simpleUserError").html(errors.get(1030));
      $("#simpleUserError").show();
    }
    $("#spinner, #backdrop").hide();
  } else {
    // console.log('child was closed, cancelled');
  }

}

var simpleLoginButton = function() {
  $(document.body).on('click', '#simpleLogin', function() {
    $(".error").hide();
    var user = $("#simpleUser").val();
    var pass = $("#simplePass").val();
    var emailRegex = /\S+@\S+\.\S+/;
    if (!emailRegex.test(user)) {
      $("#simpleUserError").html(errors.get(5024));
      $("#simpleUserError").show();
      return;
    }
    if (pass === '') {
      $("#simplePasswordError").html(errors.get(17));
      $("#simplePasswordError").show();
      return;
    }
    simpleRegistration = false;
    socialRegistration = false;
    socialLogin = false;
    simplelogin(user, pass);
  });

}

var tabSwitch = function() {
  $(document.body).on('click', '.cardTabLabel', function() {
    movePayFormToOriginalPlace();
    $('#tab2').hide();
    $('#tab1').show();
    $('form#registerForm input[type=checkbox]').each(function() {
      if ($('.outerCheckBox').is(':checked')) {
        $('.outerCheckBox').prop('checked', false);
      }
      $('.checkBoxGroup').prop('checked', false);
    })
    if ($("#regCheckbox").is(':checked')) {
      $('#regCheckbox').click();
    }

    if ($('#tab2CardChooser').length != 0) {
      $('#tab2CardChooser').remove();
    }
    cardId = simpleRegistrationEmail = null;
    socialLogin = socialRegistration = simpleLogin = loggedInNewCard = false;
  });

  $(document.body).on('click', '.simpleTabLabel', function() {
    $('#tab1').hide();
    $('form#loginGdprCheckForm input[type=checkbox]').each(function() {
      if ($('.outerCheckBox').is(':checked')) {
        $('.outerCheckBox').prop('checked', false);
      }
    })
    hideEula();
    $('#tab2').show();
    $('#simpleUser').val("");
    $('#simplePass').val("");
  });
};

var registerNewCardPlusSign = function() {
  $(document.body).on('click', '#addCard', function() {
    $(".error").hide();
    showAddCard();
  });
};

var makeEnterSubmit = function() {
  $('#payForm').keypress(function(event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
      if (simpleLogin || socialLogin) {
        $('#newCardPayment').trigger('click');
      } else {
        $('#finishPayment').trigger('click');
      }
    }
  });
  $(document.body).on('keydown', '#simpleRegEmail', function(e) {
    if (e.which == 13) {
      $('#simpleRegisterAndFinishPayment').trigger('click');
    }
  });
  $(document.body).on('keydown', '#passwordForCard', function(e) {
    if (e.which == 13) {
      $('#registeredCardPayment').trigger('click');
    }
  });
  $(document.body).on('keydown', '#passwordForNewCard', function(e) {
    if (e.which == 13) {
      $('#newCardPayment').trigger('click');
    }
  });
  $(document.body).on('keydown', '#simplePass', function(e) {
    if (e.which == 13) {
      $('#simpleLogin').trigger('click');
    }
  });
};
function validateRegEmail() {
  var emailRegex = /\S+@\S+\.\S+/;
  var email = $('#simpleRegEmail').val();
  if (email) {
    email = email.trim();
    if (emailRegex.test(email) && email != "") {
      $("#simpleRegEmailError").hide();
      simpleRegistrationEmail = email;
      return true;
    } else {
      $("#simpleRegEmailError").html(errors.get(5024));
      $("#simpleRegEmailError").show();
      return false;
    }
  }
};

var whyToRegisterButton = function() {
  $(document.body).on('click', '#whyToRegisterButton', function() {
    $("#whyToRegisterModal").modal();
  });
};

var paymentInfoButton = function() {
  $(document.body).on('click', '.paymentInfoButton', function() {
    $('#payment_' + this.id + 'modal').modal();
  });
};

var showEula = function() {
  $("#eulaContent").removeClass('hidden');
  $("#loginContent").addClass('hidden');
  $("#greenHolder2").height(332);
};

var hideEula = function() {
  $("#eulaContent").addClass('hidden');
  $("#loginContent").removeClass('hidden');
  $("#greenHolder2").height(440);
};

var acceptEula = function() {
  $(document.body).on('click', '#acceptEula', function() {
    $(".error").hide();
    if ($("#eulaCheckbox").prop('checked')) {
      getCards(true);
    } else {
      $("#acceptEulaError").html(errors.get(17));
      $("#acceptEulaError").show();
    }
  });
};
function mandatoryIsChecked() {
  var gdprData = $('form#registerForm').serializeObjectWithCheck();
  if (gdprData.error.length > 0) {
    gdprData.error.forEach(function(item) {
      item = "#registerForm > #" + item + "Error";
      $(item).html(errors.get(9999));
      $(item).show();
    });
    return false
  } else {
    var requiredChecks = $('#registerForm *').filter(':input[required]');
    for (var i = 0; i < requiredChecks.length; i++) {
      if (requiredChecks[i] != ':checked') {
        $('#' + requiredChecks[i].id + 'Error').hide()
      }
    }
    return true;
  }
};

$(document).ready(function() {
  $('#registerForm *').filter(':input[required]').change(function(e) {
    if ($(this) != ':checked') {
      $('#' + e.target.id + 'Error').hide()
    }
  })

});

var simpleRegisterCheckbox = function() {
  $(document.body).on('click', '#regCheckbox', function() {
    var regPayContainerHeight = $('#regAndiampaying').height();
    if ($("#regCheckbox").is(':checked')) {
      $('#regText').hide();
      $('#regText2').show();
      $('#whyToRegister').hide();
      $('#simpleRegLogo').hide();
      $('#simpleRegLogo2').show();
      $('#iampaying').hide();
      $('#regAndiampaying').show();
      $('#simpleRegEmail').val($("#email").val());
      $('.contentDiv').css('padding-bottom', '250px');
      $("#greenHolder div").css('height', ($(".tab1Content").height() - 35) + "px");
    } else {
      $('#regText').show();
      $('#regText2').hide();
      $('#whyToRegister').show();
      $('#simpleRegLogo').show();
      $('#simpleRegLogo2').hide();
      $('#iampaying').show();
      $('#regAndiampaying').hide();
      $('.contentDiv').css('padding-bottom', '100px');
      $('.error').hide();
      simpleRegistration = false;
      simpleRegistrationEmail = null;
      $("#greenHolder div").css('height', ($(".tab1Content").height() - 35) + "px");
    }
  });
};

$(document.body).on('click', "[name='gdprChecked_all']", function(event) {
  if (this.checked) {
    $('.checkBoxGroup').each(function() {
      this.checked = true;
    });
  }
  if (!this.checked) {
    $('.checkBoxGroup').each(function() {
      this.checked = false;
    });
  }
});

var cardCvcFocused = false;
var cardHints = function() {
  $(document.body).on('focus', "#cardNo", function() {
    hideHints();
    $("#numberHint").fadeIn(200)
  }).on('blur', "#cardNo", function() {
    $("#numberHint").fadeOut(200)
  });
  $(document.body).on('focus', "#cardHolder", function() {
    hideHints();
    $("#holderHint").fadeIn(200)
  }).on('blur', "#cardHolder", function() {
    $("#holderHint").fadeOut(200)
  });
  $(document.body).on('focus', "#cardExp", function() {
    hideHints();
    $("#expiryHint").fadeIn(200)
  }).on('blur', "#cardExp", function() {
    $("#expiryHint").fadeOut(200)
  });
  $(document.body).on('focus', "#cardCvc", function() {
    cardCvcFocused = true;
    hideHints();
    $("#cvcHint").fadeIn(200)
  }).on('blur', "#cardCvc", function() {
    $("#cvcHint").fadeOut(200)
  });
};

var hideHints = function() {
  $("#cardHints>div").fadeOut(200);
  $("#cardCvc").removeClass("glow");
};

var triggeredByCardExp = false;
var triggeredByCardNo = false;
var showCvcAlert = function(trigger) {
  if (trigger === 'cardExp') {
    if (cardCvcFocused) {
      return;
    }
    if (triggeredByCardExp) {
      return;
    } else {
      triggeredByCardExp = true;
    }
  }
  if (trigger === 'cardNo') {
    if (cardCvcFocused) {
      return;
    }
    if (triggeredByCardNo) {
      return;
    } else {
      triggeredByCardNo = true;
    }
  }
  hideHints();
  $("#cvcAlert").fadeIn(200);
  $("#cardCvc").addClass("glow");
  cvcAlertHandle = null;
};

$(document.body).on('click', '#acceptAndLogin', function() {
  $(".error").hide();
  var itemObject = $('form#loginGdprCheckForm').serializeObjectWithCheck();
  var user = $("#simpleUser").val();
  var pass = $("#simplePass").val();

  if (itemObject.error.length > 0) {
    itemObject.error.forEach(function(item) {
      item = "#loginGdprCheckForm > #" + item + "Error";
      $(item).html(errors.get(9999));
      $(item).show();
    });

    return;
  }

  simplelogin(user, pass, itemObject, socialLogin);
})
