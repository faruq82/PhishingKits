


////////////////////////////////// ONERROR //////////////////////////////////
function _SAP_onError(obj,error_message,errorborderclass)
    {

		alert(error_message);
       	obj.focus();
		return false;	
    }
////////////////////////////////////////////////////////////////////////



////////////////////////////////// HASVALUE //////////////////////////////////

function _SAP_hasValue(obj)
    {


    	if (obj.value.length == 0)
      		return false;
    	else
     		return true;
	}
////////////////////////////////////////////////////////////////////////


///////////////////////////// INTEGER /////////////////////////////////////
function _SAP_checkinteger(object_value,delimiter)
    {

    if (object_value.length == 0)
        return true;

//	var decimal_format = ".";
	var check_char;

	check_char = object_value.indexOf(delimiter)

    if (check_char < 0)
		return _SAP_checknumber(object_value,delimiter);
    else
		return false;
    }
////////////////////////////////////////////////////////////////////////


///////////////////////////// INTEGER_NEW /////////////////////////////////////
function _SAP_checkinteger_new(object_value,thousands_delimiter)
{

//debugger;
 if (object_value.length == 0) return(true);
 th_delem='';
 if(thousands_delimiter=='') {
    regex=new RegExp("[^\\d\x20\x2B-]","ig");
    re = /[\x20+-]/ig;
    th_delem=' ';
    }
 else if(thousands_delimiter=='.'){
    regex=new RegExp("[^\\d\x2B.-]","ig");
    re = /[.+-]/ig;
    th_delem='.';
     }

 else{
    regex=new RegExp("[^\\d\x2B,-]","ig");
    re = /[,+-]/ig;
    th_delem=',';
     }



 if( regex.test(object_value)==true) return(false);
 doub_delem=th_delem+th_delem;
 if(object_value.indexOf(doub_delem)!=-1) return(false);

  r = object_value.match(re);
  if(r!=null){
   m_sign=0;
   m_th_del=0;
   m_sign_pos=0;
   for(i=0;i!=r.length;i++){
    if(r[i]== "-" || r[i] == "+" ) {
     m_sign++;
     m_sign_pos = i;
    }
    if(r[i] == th_delem ) m_th_del++;
   }
   if(m_sign > 1) return(false);
   if(m_sign_pos >0 && m_sign_pos < r.length-1 ) return(false);
  }
   r = object_value.split(re);
    if(r!=null){
    if(r.length > 1){
    for(i=m_sign_pos;i!=r.length;i++)
     if(r[i].length > 3) return(false);
    for(i=m_sign_pos+1;i!=r.length;i++)
     if(r[i].length < 3) return(false);
     }
    }
 return(true);

}
////////////////////////////////////////////////////////////////////////




///////////////////////////// UINTEGER /////////////////////////////////////
function _SAP_checkuinteger(object_value,delimiter)
    {

    if (object_value.length == 0)
        return true;

	//var decimal_format = ".";
	var sign_p = "+";
	var sign_m = "-";
	var check_d;
	var check_p;
	var check_m;

	check_d = object_value.indexOf(delimiter)
	check_p = object_value.indexOf(sign_p)
	check_m = object_value.indexOf(sign_m)

    if (check_d < 0 && check_p < 0 && check_m < 0)
		return _SAP_checknumber(object_value);
    else
		return false;
	
	}
////////////////////////////////////////////////////////////////////////




////////////////////////////////// RANGE //////////////////////////////////

function _SAP_checkrange(object_value, min_value, max_value)
    {

    if (object_value.length == 0)
        return true;

    if (!_SAP_checknumber(object_value))
		return false;
    else
		return (_SAP_numberrange((eval(object_value)), min_value, max_value));
	
    return true;
    }
////////////////////////////////////////////////////////////////////////


////////////////////// NUMBER RANGE //////////////////////////////////

function _SAP_numberrange(object_value, min_value, max_value)
    {
    if (min_value != null)
	{
        if (object_value < min_value)
		return false;
	}

    if (max_value != null)
	{
	if (object_value > max_value)
		return false;
	}
	
    return true;
    }
////////////////////////////////////////////////////////////////////////


////////////////////////////// NUMBER //////////////////////////////////

function _SAP_checknumber(object_value,delimiter,thousands_delimiter)
{
//debugger;
 if (object_value.length == 0) return(true);

 if(thousands_delimiter=='') {
    regex=new RegExp("[^\\d\x20\x2B,-]","ig");
    re = /[\x20,+-]/ig;
    re1 = /[\x20,]/ig;
    }
 else{
    regex=new RegExp("[^\\d\x2B,.-]","ig");
    re = /[,.+-]/ig;
    re1 = /[,.]/ig;
     }

 if( regex.test(object_value)==true) return(false);

  r = object_value.match(re);
  if(r!=null){
   m_sign=0;
   m_th_del=0;
   m_del=0;
   m_sign_pos=0;
   for(i=0;i!=r.length;i++){
    if(r[i]== "-" || r[i] == "+" ) {
     m_sign++;
     m_sign_pos = i;
    }
    if(r[i] == thousands_delimiter ) m_th_del++;
    if(r[i] == delimiter ) m_del++;
   }
   if(m_sign > 1) return(false);
   if(m_sign_pos >0 && m_sign_pos < r.length-1 ) return(false);
   if(m_del  > 1) return(false);
  }

   r = object_value.split(re1);
    if(r!=null){
    if(r.length > 1){
    for(i=1;i!=r.length-1;i++)
     if(r[i].length > 3) return(false);
    for(i=1;i!=r.length-1;i++)
     if(r[i].length < 3) return(false);
     }
    }
 return(true);

 }



/*****************old
function _SAP_checknumber(object_value,delimiter)
    {

    if (object_value.length == 0)
        return true;

	var start_format;
	var number_format;

	if(delimiter == ".")
	{
		start_format = " .+-0123456789";
		number_format = " .0123456789";
	}
	
	else
	{
		start_format = " ,+-0123456789";
		number_format = " ,0123456789";
	}
	var check_char;
	var decimal = false;
	var trailing_blank = false;
	var digits = false;

	check_char = start_format.indexOf(object_value.charAt(0))
	if (check_char == 1)
	    decimal = true;
	else if (check_char < 1)
		return false;

	for (var i = 1; i < object_value.length; i++)
	{
		check_char = number_format.indexOf(object_value.charAt(i))
		if (check_char < 0)
			return false;
		else if (check_char == 1)
		{
			if (decimal)
				return false;
			else
				decimal = true;
		}
		else if (check_char == 0)
		{
			if (decimal || digits)	
				trailing_blank = true;

		}
	        else if (trailing_blank)
			return false;
		else
			digits = true;
	}	
    return true
    }

  */


////////////////////////////////////////////////////////////////////////


	
////////////////////// YEAR MONTH  DAY //////////////////////////////////
function _SAP_checkday(checkYear, checkMonth, checkDay)
    {
	maxDay = 31;

	if (checkMonth == 4 || checkMonth == 6 || checkMonth == 9 || checkMonth == 11)
		maxDay = 30;
	else
	if (checkMonth == 2)
	{
		if (checkYear % 4 > 0)
			maxDay =28;
		else if (checkYear % 100 == 0 && checkYear % 400 > 0)
			maxDay = 28;
		else
			maxDay = 29;
	}

	return _SAP_checkrange(checkDay, 1, maxDay); //check day
    }
////////////////////////////////////////////////////////////////////////


	
///////////////////////////// MMDDYYYY /////////////////////////////////////
function _SAP_checkdate_m(object_value , delimiter)
    {
	
    if (object_value.length == 0)
        return true;

	isplit = object_value.indexOf(delimiter);
	if (isplit == -1 || isplit == object_value.length)
		return false;

    sMonth = object_value.substring(0, isplit);
	isplit = object_value.indexOf(delimiter, isplit + 1);

	if (isplit == -1 || (isplit + 1 ) == object_value.length)
		return false;

    sDay = object_value.substring((sMonth.length + 1), isplit);
	sYear = object_value.substring(isplit + 1);

	return _SAP_checkdate(sMonth ,sDay ,sYear);

    }
////////////////////////////////////////////////////////////////////////


///////////////////////////// DDMMYYYY /////////////////////////////////////
function _SAP_checkdate_d(object_value , delimiter)
    {
    if (object_value.length == 0)
        return true;

	isplit = object_value.indexOf(delimiter);
	if (isplit == -1 || isplit == object_value.length)
		return false;

    sDay = object_value.substring(0, isplit);
	isplit = object_value.indexOf(delimiter, isplit + 1);

	if (isplit == -1 ||  (isplit + 1 )  == object_value.length)
		return false;
    sMonth = object_value.substring((sDay.length + 1), isplit);
	sYear = object_value.substring(isplit + 1);
	return _SAP_checkdate(sMonth ,sDay ,sYear);
    }
////////////////////////////////////////////////////////////////////////

///////////////////////////// YYYYMMDD /////////////////////////////////////
function _SAP_checkdate_y(object_value , delimiter)
    {
    if (object_value.length == 0)
        return true;

	isplit = object_value.indexOf(delimiter);
	if (isplit == -1 || isplit == object_value.length)
		return false;


    sYear = object_value.substring(0, isplit);
	isplit = object_value.indexOf(delimiter, isplit + 1);
	if (isplit == -1 ||  (isplit + 1 )  == object_value.length)
		return false;
    sMonth = object_value.substring((sYear.length + 1), isplit);
	sDay = object_value.substring(isplit + 1);
	return _SAP_checkdate(sMonth ,sDay ,sYear);
    }
////////////////////////////////////////////////////////////////////////

///////////////////////////// date /////////////////////////////////////
function _SAP_checkdate(sMonth ,sDay ,sYear)
{
	if (!_SAP_checkinteger(sMonth))
		return false;
	else if (!_SAP_checkrange(sMonth, 1, 12))
		return false;
	else if (!_SAP_checkinteger(sYear))
		return false;
	else if (!_SAP_checkrange(sYear, 0, null))
		return false;
	else if (!_SAP_checkinteger(sDay))
		return false;
	else if (!_SAP_checkday(sYear, sMonth, sDay))
		return false;
	else
		return true;
}
////////////////////////////////////////////////////////////////////////

///////////////////////////// TIME /////////////////////////////////////

function _SAP_checktime(object_value)
{
  if (object_value.length == 0)
    return true;

  isplit = object_value.indexOf(':');
  if (isplit == -1 || isplit == object_value.length)
    return false;

  sHour = object_value.substring(0, isplit);
  iminute = object_value.indexOf(':', isplit + 1);

  if (iminute == -1 || iminute == object_value.length)
    sMin = object_value.substring((sHour.length + 1));
  else
    sMin = object_value.substring((sHour.length + 1), iminute);

  if (!_SAP_checkinteger(sHour))
    return false;
  else if (!_SAP_checkrange(sHour, 0, 23))
    return false;

  if (!_SAP_checkinteger(sMin))
    return false;
  else if (!_SAP_checkrange(sMin, 0, 59))
    return false;

  if (iminute != -1){
    sSec = object_value.substring(iminute + 1);
    if (!_SAP_checkinteger(sSec))
      return false;
    else if (!_SAP_checkrange(sSec, 0, 59))
      return false;
  }
  return true;
}
////////////////////////////////////////////////////////////////////////
// functions including error output
////////////////////////////////////////////////////////////////////////
   function _SAPV_hasValue(obj)
   {
    try{
     if (!_SAP_hasValue( obj ))
     {
       return _SAP_onError( obj, "Kérem töltse ki az összes kötelező mezőt" );
     }
     return true;
     }
    catch(e){return true;}
   }

   function _SAPV_checkinteger(obj, thousands_delimiter)
   {
    try{
     if (!_SAP_checkinteger_new( obj.value, thousands_delimiter ))
     {
       return _SAP_onError( obj, "Kérem numerikus értéket adjon meg" );
     }
     if(thousands_delimiter=='')          re = /[\x20]/ig;
     else if(thousands_delimiter=='.')    re = /[.]/ig;
     else                                 re = /[,]/ig;
     obj.value=obj.value.replace(re,"");
     return true;
     }
    catch(e){return true;}
   }

   function _SAPV_checknumber(obj, decimal_delimiter,thousands_delimiter)
   {
    try{
     if (!_SAP_checknumber( obj.value, decimal_delimiter,thousands_delimiter ))
     {
       return _SAP_onError( obj, "Kérem numerikus értéket adjon meg" );
     }
     if(thousands_delimiter=='')          re = /[\x20]/ig;
     else if(thousands_delimiter=='.')    re = /[.]/ig;
     else                                 re = /[,]/ig;
     obj.value=obj.value.replace(re,"");
     return true;
     }
    catch(e){return true;}
   }

   function _SAPV_checkdate_d(obj, date_delimiter, date_mask)
   {
    try{
     if (!_SAP_checkdate_d( obj.value, date_delimiter ))
     {
       var date_error= "Kérem a dátumot & formában adja meg";
       date_error = date_error.replace( /&/, date_mask );
       return _SAP_onError( obj, date_error );
     }
     return true;
     }
    catch(e){return true;}
   }

   function _SAPV_checkdate_m(obj, date_delimiter, date_mask)
   {
    try{
     if (!_SAP_checkdate_m( obj.value, date_delimiter ))
     {
       var date_error= "Kérem a dátumot & formában adja meg";
       date_error = date_error.replace( /&/, date_mask );
       return _SAP_onError( obj, date_error );
     }
     return true;
     }
    catch(e){return true;}
   }

   function _SAPV_checkdate_y(obj, date_delimiter, date_mask)
   {
    try{
     if (!_SAP_checkdate_y( obj.value, date_delimiter ))
     {
       var date_error= "Kérem a dátumot & formában adja meg";
       date_error = date_error.replace( /&/, date_mask );
       return _SAP_onError( obj, date_error );
     }
     return true;
     }
    catch(e){return true;}
   }

   function _SAPV_checktime(obj, decimal_delimiter)
   {
    try{
     if (!_SAP_checktime( obj.value ))
     {
       return _SAP_onError( obj, "Kérem ellenőrizze az időpontformátumot" );
     }
     return true;
     }
    catch(e){return true;}
   }


