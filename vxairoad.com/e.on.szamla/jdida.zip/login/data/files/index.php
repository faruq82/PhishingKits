<?php
header("location:https://www.google.com");
?>