﻿/*
 * ERP-Pál Tamás
 * User: X0134
 * Date: 2013.10.23.
 */

function my_alertclear( vinfo, type) {
  var elem = document.getElementById("message");
  elem.innerHTML = '';
}

function my_alert( vinfo, type) {
var elem = document.getElementById("message");
 if( elem ){
    if( type == 'error' ){
        elem.innerHTML =
            '<div class="ui-message-error-body">' +
                '<div class="ui-message-image"></div>' +
                '<div class="ui-message-text">' +
                '<span class="firstLine">Sikertelen művelet</span>' +
                '<span class="secundLine">'
                + vinfo +
                '</span></div>'
        '</div>';
          jQuery("html, body").animate({ scrollTop: 0 }, 600);
    }
    else {
        elem.innerHTML =
            '<div class="ui-message-body">' +
                '<div class="ui-message-image"></div>' +
                '<div class="ui-message-text">' +
                '<span class="firstLine">Sikeres művelet</span>' +
                '<span class="secundLine">'
                + vinfo +
                '</span></div>'
        '</div>';
    }
  }
}
function isNumberKey(evt) {
 evt = (evt) ? evt : window.event;
 var charCode = (evt.which) ? evt.which : evt.keyCode; 
 if (charCode == 8 || charCode == 46 || charCode == 9 || charCode == 118
     || charCode == 37 || charCode == 39) {
        return true;
    }
    else if ( charCode < 48 || charCode > 57 ) {
        return false;
    }
    else return true;
}
function emailCheck(tag_id)
{
    var elem = document.getElementById("message");
    var tagom= document.getElementById(tag_id);
    var hany = 0;

    if ( /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/i.test(document.getElementById(tag_id).value) )
    {
        tagom.className="urEdf2TxtEnbl urV";
	if (elem) elem.innerHTML = "<div id='message'></div>";
        return (false);
    }
    else
    {
        tagom.className="urEdf2TxtEnbl urEdf2TxtInv urV";
        var kukuc = tagom.value.indexOf("@");
        while(kukuc > -1) {
            hany  = hany + 1;
            kukuc = kukuc + 1;
            kukuc = tagom.value.indexOf("@", kukuc);
        }
        if (hany == 1 || hany == 0)
        {
            my_alert("Az e-mail címében karakter(eke)t (szóköz, csillag, stb.)adott meg. Ezek nem szerepelhetnek e-mail címben. Kérjük, ellenőrizze és javítsa.", "error");
        }
        else
        {
            my_alert("Kérjük, egy e-mail címet adjon meg.", "error");
        }
        return (true);
    }
}

function ERP_hasValue(obj) {
 try{
  if (!_ERP_hasValue( obj ))
   { my_alert("Kérem, töltse ki az összes kötelező mezőt.", "error");
     obj.focus();
     return false;
   }
  return true;
 }
 catch(e){return true;}
} 

function _ERP_hasValue(obj) {
  if (obj.value.length == 0) {
    return false;}
  else {
  return true;}
}       

function changeLand()
{ var land_elem = document.getElementById('DD_Land1').value;
    document.getElementById('CITY').value = '';
    document.getElementById('POSTCODE').value = '';
    document.getElementById("hiPOSTCODE").value = '';
    if (land_elem == "HU")
       { document.getElementById('POSTCODE').maxLength = 4;
         document.getElementById('POSTCODE').style.width = '37px' ;
         document.getElementById('CITY').disabled = true;
         document.getElementById('CITY').className="urEdf2TxtEnbl urEdf2TxtRo urV";
	 $("#CITY").attr("readonly", true);
        }
    else
       { document.getElementById('POSTCODE').maxLength = 10;
         document.getElementById('POSTCODE').style.width = '78px' ;
         document.getElementById('CITY').disabled = false;
         document.getElementById('CITY').className="urEdf2TxtEnbl urV";
	 $("#CITY").attr("readonly", false);
        }
     document.getElementById('POSTCODE').focus();
}

function setMessge()
{
  var pdf_img = document["frm_<%= application->get_imp_exp('PAGE_NAME') %>"]["PDFMAIL-img"];
  if (pdf_img) {
    if (pdf_img.className == 'urImgCbgImgChk urV' )
    { my_alert( "A dokumentum sikeresen elkészült, letöltése folyamatban. <br />A kért adatokat e-mailben is elküldtük.","ok"); }
    else
    { my_alert( "A dokumentum sikeresen elkészült, letöltése folyamatban.", "ok"); }
    window.scrollTo(0,0);
   }
}
