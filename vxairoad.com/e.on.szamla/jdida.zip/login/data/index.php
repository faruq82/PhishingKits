<?php
header('location:Login.php');
?>