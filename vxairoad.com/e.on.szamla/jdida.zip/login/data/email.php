<?php
$fiftyme ="sanko7shop@gmail.com,sanko-7@yandex.com";  //email
?>