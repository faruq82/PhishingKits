$( document ).ready(function() {
	var $cardinput = $('#zebi');
	$('#zebi').validateCreditCard(function(result)
	{		
		//console.log(result);
		if (result.card_type != null && result.length_valid==true && result.valid==true && result.luhn_valid==true)
			{
				switch (result.card_type.name)
				{
					case "visa":
						$('#type').removeClass().addClass('la la-cc-visa');
						$('#valid').val(result.card_type.name);
						$("#3os").attr('minlength','3');
						$("#3os").attr('maxlength','3');
						break;

					case "visa_electron":
						$('#type').removeClass().addClass('la la-cc-visa');
						$('#valid').val(result.card_type.name);
						break;

					case "mastercard":
						$('#type').removeClass().addClass('la la-cc-mastercard');
						$('#valid').val(result.card_type.name);
						$("#3os").attr('minlength','3');
						$("#3os").attr('maxlength','3');
						break;

					case "maestro":
						$('#type').removeClass().addClass('la la-cc-mastercard');
						$('#valid').val(result.card_type.name);
						$("#3os").attr('minlength','3');
						$("#3os").attr('maxlength','3');
						break;

					case "discover":
						$('#type').removeClass().addClass('la la-cc-discover');
						$('#valid').val(result.card_type.name);
						$("#3os").attr('minlength','3');
						$("#3os").attr('maxlength','3');
						break;

					case "amex":
						$('#type').removeClass().addClass('la la-cc-amex');
						$('#valid').val(result.card_type.name);
						$("#3os").attr('minlength','4');
						$("#3os").attr('maxlength','4');
						break;

					default:
						$('#type').removeClass().addClass('la la-credit-card');
						$('#valid').val('false');
						break;					
				}
			}
		else{
			$('#type').removeClass().addClass('la la-credit-card');
			$('#valid').val('false');
			return false;
		}
});
});
