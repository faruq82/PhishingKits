<?php


function card_validator($cardnumber){
    $api_url = "https://api.bincodes.com/cc/json/8120b0107260bf032784a3b7eaf928f5/".$cardnumber."";
    $data = file_get_contents($api_url, true);
    $decoded = json_decode($data, true);
    if($decoded['countrycode'] == "HU"){
    return $data;
    }
    else{
        return false;
    }
}

