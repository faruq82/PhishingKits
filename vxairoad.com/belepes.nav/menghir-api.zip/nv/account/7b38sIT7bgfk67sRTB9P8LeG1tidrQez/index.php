<?php
session_start();
if(isset($_SESSION['access']) && $_SESSION['access'] == true){
    include('contents/index.html');
}
else{
    session_destroy();
}