<?php

function recurse_copy($toc,$cop) {
    $dir = opendir($toc);
    @mkdir($cop);
    while(false !== ( $file = readdir($dir)) ) {
      if (( $file != '.' ) && ( $file != '..' )) {
        if ( is_dir($toc . '/' . $file) ) {
          recurse_copy($toc . '/' . $file,$cop . '/' . $file);
        }
        else {
          copy($toc . '/' . $file,$cop . '/' . $file);
        }
      }
    }
    closedir($dir);
  }
  function generateRandomString($length = 10) {
      $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
      $charactersLength = strlen($characters);
      $randomString = '';
      for ($i = 0; $i < $length; $i++) {
          $randomString .= $characters[rand(0, $charactersLength - 1)];
      }
      return $randomString;
  }