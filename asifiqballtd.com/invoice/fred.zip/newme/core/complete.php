<?php
session_start();
require('inc/functions.php');

//Delete tmp dir 
if (isset($_SESSION['tmp_folder'])) {
    if (is_dir($_SESSION['tmp_folder']))
        recurse_delete($_SESSION['tmp_folder']);
		recurse_delete("../".$_SESSION['tmp_folder_name']);
}


session_destroy();
//header("refresh:0; url=$final_redirect_url"); //new i wrote
//header("Location: url=$final_redirect_url"); //old i wrote

ob_end_flush();
?>
