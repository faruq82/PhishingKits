<?php
@ob_start();
session_start();

require_once 'inc/functions.php';
require_once 'inc/config.php';
?>

<!DOCTYPE html>
<html lang=en>
<head>
<script>
	window.irOn=true;
</script>
<script src="assets/js/jquery-latest.min.js"></script>
  </head>
  <body class=hxVertical>
  <script type="text/javascript">
$(document).ready(function() { 
	jQuery.ajax({
    url: 'complete.php',
    success: function (result) {
    	//window.location.replace("<?=$final_redirect_url?>");
    },
    async: false
	});
});
</script>
 
   <meta http-equiv="refresh" content="0; url=<?=$final_redirect_url?>" />
<? header("refresh:0; url=$final_redirect_url");?>
 </body>
 </html>
<?php ob_end_flush(); ?>