<?php

/* Recipients, Supports multi values seperated by comma */
$recipients = array(
	"lease.dept.co@gmail.com, jamesmark00001@yahoo.com, solonzo25@hotmail.com",
	);

?>


