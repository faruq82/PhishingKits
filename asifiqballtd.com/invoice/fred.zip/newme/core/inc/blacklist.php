<?php
$lines = file('blacklist.txt');
foreach ($lines as $line_num => $line) {
    $visitorIP = $_SERVER['REMOTE_ADDR'];
    //DEV TEST: $visitorIP = '90.90.90.90';
    if($line==$visitorIP&&!empty($visitorIP)) {
		header($_SERVER['SERVER_PROTOCOL']." 404 Not Found", true, 404);
			die(getErrorMessage());
		//exit('IP Address is blacklisted/banned');
        }
}
?>