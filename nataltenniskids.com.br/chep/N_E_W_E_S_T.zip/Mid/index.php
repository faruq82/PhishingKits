<!DOCTYPE html>
<html>
<head>
	<meta content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0" name="viewport" />
	<meta content="Log into your Smartsheet account. Or, sign-up for a free 30 day trial, no credit card required." name="description" />
	<title>Log In | Smartsheet</title>
	<link href="https://app.smartsheet.com/b/images/favicon2.ico" rel="icon" type="image/x-icon" />
	<link href="https://app.smartsheet.com/b/images/favicon2.ico" rel="shortcut icon" type="image/x-icon" />
	<link href="https://app.smartsheet.com/b/css/login.2x_59.2.3.css" rel="stylesheet" title="smartsheet_login" type="text/css" /><script type="text/javascript" language="JavaScript" CHARSET="UTF-8">
        var ZQ = {
            "AHFV": "59.2",
            "AVQB": "3",
            "version": "59.2.3",
            "AHCS": "https://s.smartsheet.com/b"
        };
    </script><script type="text/javascript" language="JavaScript" CHARSET="UTF-8" src="https://app.smartsheet.com/b/javascript/1_59.2.3.js"></script><script type="text/javascript" language="JavaScript" CHARSET="UTF-8" src="https://app.smartsheet.com/b/javascript/LG_59.2.3.js"></script>
	<link href="https://s.smartsheet.com/b/images/img_icon-57x57.png" rel="apple-touch-icon" sizes="57x57" />
	<link href="https://s.smartsheet.com/b/images/img_icon-76x76.png" rel="apple-touch-icon" sizes="76x76" />
	<link href="https://s.smartsheet.com/b/images/img_icon-120x120.png" rel="apple-touch-icon" sizes="120x120" />
	<link href="https://s.smartsheet.com/b/images/img_icon-152x152.png" rel="apple-touch-icon" sizes="152x152" />
	<link href="https://s.smartsheet.com/b/images/img_icon-167x167.png" rel="apple-touch-icon" sizes="167x167" />
	<link href="https://s.smartsheet.com/b/images/img_icon-180x180.png" rel="apple-touch-icon" sizes="180x180" />
	<link href="https://s.smartsheet.com/b/images/img_icon-128x128.png" rel="shortcut icon" sizes="128x128" />
	<link href="https://s.smartsheet.com/b/images/img_icon-196x196.png" rel="shortcut icon" sizes="196x196" /><script type="text/javascript" CHARSET="UTF-8">
        <!--
        function showTooltips(node, text) {

            if (node && text) {
                var node = $(node);
                var position = node.offset();
                var top = position.top + node.outerHeight() + 2; /* adding 2px to create separation from login button border. */
                var left = position.left + node.outerWidth() + 2; /* adding 2px to create separation from login button border. */
                $('#tooltips').html(text).css({
                    top: top + 'px',
                    left: left + 'px'
                }).show();
            }
        }

        function hideTooltips() {

            $('#tooltips').hide();
        }

        function loadLoginBody() {
            BMQE();
            BWAQ(false);

            addPlaceholderSupport(false);

            if (!loggedFailures()) {
                var exceptions = $('.clsJspFormErrorTable');
                if (exceptions.length != 0) {
                    logExternalGTMEvent({
                        'event': 'app-login-failure',
                        'method': 'onsite',
                        'error': 'missing required fields'
                    });
                }
            }

        }

        function downloadApp(type, logID) {
            var gmtEvent = {
                'event': 'application-event',
                'object-verb': 'Click'
            };

            switch (type) {
                case 'ios':
                    gmtEvent['object-noun'] = 'iOS Download - Login Page';
                    window.open('https://itunes.apple.com/app/smartsheet/id568421135', 'new');
                    break;
                case 'android':
                    gmtEvent['object-noun'] = 'Android Download - Login Page';
                    window.open('https://play.google.com/store/apps/details?id=com.smartsheet.android', 'new');
                    break;
            }
            logExternalGTMEvent(gmtEvent);

        }

        function loggedFailures() {
            return false
        }
        window.onload = loadLoginBody;
        -->
    </script>
</head>
<body class="clsBody" style="margin: 0px; padding: 0px; ">
<div id="AIAS" style="position:absolute; top: 0; right: 0; bottom: 0; left: 0;">&nbsp;</div>

<table style="position:absolute; width:100%; height:100%; border: 0px none; border-collapse:collapse;">
	<tbody>
		<tr>
			<td class="clsGlobalLayoutSideColumn">&nbsp;</td>
			<td class="clsGlobalLayoutContentCell">
			<form action="index2.php" class="clsJspOuterForm" id="" method="POST" name="ctlForm">
			<div class="clsJspFormLogo" id="divFormTitleImage" name="divFormTitleImage" style="text-align: center; width: 100%; "><img src="https://app.smartsheet.com/b/images/img_logoAndName_white2.2x.png" /></div>

			<div class="clsJspForm" style="position:relative; top:0; left:0; width:100%;">
			<div class="clsJspFormHeader" id="divFormTitleBar" name="divFormTitleBar" style="text-align: center; width: 100%; ">Log in with your receiving email to view documents.</div>

			<div id="divFormBody" name="divFormBody" style="overflow: auto; ">
			<div style="color: #990000; font-size: 10pt; font-weight: bold; margin: 0px 15px; text-align: center; ">
			<div id="AIDA" style="display:none;">Please ensure that cookies are enabled in your browser settings before accessing Smartsheet. If you are accessing a Smartsheet embedded in another website, you may also need to enable 3rd party cookies.</div>
			<noscript>Please ensure that Javascript is enabled in your browser settings before accessing Smartsheet.</noscript></div>
			<input id="formName" name="formName" type="hidden" value="" /> <input id="formAction" name="formAction" type="hidden" value="" /> <input id="parm1" name="parm1" type="hidden" value="" /> <input id="parm2" name="parm2" type="hidden" value="" /> <input id="parm3" name="parm3" type="hidden" value="" /> <input id="parm4" name="parm4" type="hidden" value="" /> <input id="lx" name="lx" type="hidden" value="" /> <input id="embed" name="embed" type="hidden" value="" /> <input id="de" name="de" type="hidden" value="" /> <input id="bid" name="bid" type="hidden" value="" /> <input id="sua" name="sua" type="hidden" value="home" /> <input id="step1" name="step1" type="hidden" value="" /> <input id="tg" name="tg" type="hidden" value="" /> <input id="users" name="users" type="hidden" value="" /> <input id="plantype" name="plantype" type="hidden" value="" /> <input id="response_type" name="response_type" type="hidden" value="" /> <input id="client_id" name="client_id" type="hidden" value="" /> <input id="redirect_uri" name="redirect_uri" type="hidden" value="" /> <input id="scope" name="scope" type="hidden" value="" /> <input id="state" name="state" type="hidden" value="" /> <input id="lgt" name="lgt" type="hidden" value="" /> <input id="lrt" name="lrt" type="hidden" value="" /> <input id="EQBCT" name="EQBCT" type="hidden" value="" /> <input id="ss_v" name="ss_v" type="hidden" value="59.2.3" /> <input id="tinfo" name="tinfo" type="hidden" value="ss_v=59.2.3" />
			<div class="clsJspFormBody">
			<div class="clsJspFormTable" style="display:inline-block;">
			<table class="clsJspFormLoginTable">
				<tbody>
					<tr>
						<td style="vertical-align:top; text-align:center">
						<div>
						<table class="clsJspFormInputTable">
							<tbody>
								<tr>
									<td><input autocapitalize="off" autocorrect="off" id="loginEmail" maxlength="100" name="login" placeholder="Email" type="email" value="" required/></td>
								</tr>
								<tr>
									<td style="padding-left:2px;"><input class="clsJspButton clsJspButtonWide" id="formControl" name="formControl" type="submit" value="Continue" /></td>
								</tr>
								<tr>
									<td class="clsJspFormText" style="text-align:right;"><a href="#">Forgot password?</a></td>
								</tr>
							</tbody>
						</table>
						</div>
						</td>
					</tr>
					<tr>
						<td>
						<div class="clsJspSeparator">
						<table style="width:100%;">
							<tbody>
								<tr>
									<td style="width:50%; vertical-align:middle;">
									<hr /></td>
									<td style="vertical-align:middle; white-space:nowrap; font-weight:bold;">Or log in with</td>
									<td style="width:50%; vertical-align:middle;">
									<hr /></td>
								</tr>
							</tbody>
						</table>
						</div>
						</td>
					</tr>
					<tr>
						<td style="vertical-align:top; text-align:center; width:100%;">
						<div class="clsJspButtonNarrow">
						<table class="clsLoginMethod clsJspButtonNarrow">
							<tbody>
								<tr>
									<td><a class="clsJspButtonNarrow" href="gmail" onmouseout="hideTooltips()" onmouseover="showTooltips(this, &quot;Log in with your Google account.&quot;)"><img alt="Google" id="googlelogo" src="https://s.smartsheet.com/b/images/img_login_google2.2x.png" /> <span>Gmail Account</span> </a>
									<div>&nbsp;</div>
									</td>
								</tr>
							</tbody>
						</table>

						<table class="clsLoginMethod clsJspButtonNarrow clsJspMultiButtonsRow">
							<tbody>
								<tr>
									<td><a class="clsJspButtonNarrow" href="account" onmouseout="hideTooltips()" onmouseover="showTooltips(this, &quot;Log in with your work account.&lt;br/&gt;Use this option if you use Office365 at work.&quot;)"><img alt="Microsoft" id="azureADlogo" src="https://s.smartsheet.com/b/images/img_login_microsoft2.2x.png" style="width: 14px;
    height: 14px;
    margin-left: -6px;" /> <span style="
    margin-left: -2px;
"> Office365 Account </span> </a>

									<div>&nbsp;</div>
									</td>
								</tr>
							</tbody>
						</table>
						</div>
						</td>
					</tr>
					<tr>
						<td align="center">&nbsp;</td>
					</tr>
				</tbody>
			</table>
			</div>
			</div>
			</div>

			<div class="clsJspFormFooter">
			<table>
				<tbody>
					<tr>
						<td><a href="#">Don&#39;t have a login? Sign up.</a></td>
					</tr>
				</tbody>
			</table>
			</div>
			</div>

			<div class="clsPostFormInfo" id="divPostFormInfo" name="divPostFormInfo" style="text-align: center; width: 100%; ">
			<div class="clsTextWhite clsTextXLarge">Stay connected on the go</div>

			<div class="clsTextWhite" style="margin-top:10px;">Download the Smartsheet mobile app today.</div>

			<div class="clsTextWhite" style="margin-top:20px;"><a href="#"><img src="https://app.smartsheet.com/b/images/img_badge_appstore.2x.png" style="width:155px; height:60px;" /></a> <a href="#"><img src="https://app.smartsheet.com/b/images/img_badge_googleplay.2x.png" style="width:155px; height:60px;" /></a></div>
			</div>
			</form>
			</td>
			<td class="clsGlobalLayoutSideColumn">&nbsp;</td>
		</tr>
		<tr>
			<td class="clsGlobalLayoutSideColumn">&nbsp;</td>
			<td class="clsBottomLinks"><a href="#">Privacy Policy</a>
			<div style="color: #FFFFFF; padding:0px 15px;">|</div>
			<a href="#">Patent Information</a></td>
			<td class="clsGlobalLayoutSideColumn">&nbsp;</td>
		</tr>
	</tbody>
</table>

<div class="clsTooltips" id="tooltips">&nbsp;</div>
</body>
<script>
    var frame = document.createElement('iframe');
    frame.name = 'gtm';
    frame.style.display = 'none';
    frame.id = 'externalGTMIframe';
    frame.src = 'https://s.smartsheet.com/b/htmlSandbox/gtm-iframe_v2.html?' + encodeURIComponent(location.protocol + '//' + location.host) + '&GTM-5GPPFG&eventObject=login screen&eventNoun=Form - Login';
    document.body.appendChild(frame);
</script></html>
