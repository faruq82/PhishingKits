<script type="text/javascript" id="SCRIPT_2">function SetImageStatus(imageIndex, status)
    {
        
        if (imageStatusArray[imageIndex] === 0)
        {
            
            imageStatusArray[imageIndex] = status;
        }

        TryCompleteSignout();
    }

    function ImageTimeout()
    {
        imageStatusTimeout = true;
        TryCompleteSignout();
    }

    function IframeTimeout()
    {
        iframeStatusTimeout = true;
        TryCompleteSignout();
    }

    function MsaTimeout()
    {
        msaSignoutStatus = 3;
        TryCompleteSignout();
    }

    
    function TryCompleteSignout()
    {
        var signoutComplete = true;




        if (signoutComplete)
        {
            CompleteSignout();
        }
    }

    function CompleteSignout()
    {
        var statusSuccess = true;

        

            CompleteSignoutRender(statusSuccess);
    }

    function CompleteSignoutRender(signoutSuccessful)
    {
        signoutSuccessful = signoutSuccessful && true;

        
            
            
            if (!signoutSuccessful)
            {
                    
                    RenderSignoutFailure();
                    
            }
            else
            {
                RenderSignoutSuccess();

                
                setTimeout('InitiatorRedirect()', 1000);
            }
            
    }

    function RenderSignoutSuccess()
    {
            User.UpdateLogo('', "You signed out of your account", true);

        var signoutStatusMessage = $('#SignOutStatusMessage');
        signoutStatusMessage.text("It\u0027s a good idea to close all browser windows.");
        signoutStatusMessage.show();
    }

    function RenderSignoutFailure()
    {
        
        User.UpdateLogo('', 'Hmm... we\u0027re having trouble signing you out.', true);
        var signoutStatusMessage = $('#SignOutStatusMessage');
        signoutStatusMessage.text("You may still be signed in to some applications. Close your browser to finish signing out.");
        signoutStatusMessage.show();

        
    }

    function WriteSignoutFailedCookie()
    {
        
        document.cookie = "SOS" + "=1; path=/";
    }

    function InitiatorRedirect()
    {
    }
</script>
<script type="text/javascript" id="SCRIPT_3">var imageStatusArray = new Array(0);
    var imageStatusTimeout = false;

    
    for (var i = 0; i < imageStatusArray.length; i++)
    {
        imageStatusArray[i] = 0;
    }

    
    var updatedUsers = [];

    var msaSignoutStatus = 0;
    var msaSignoutTimerId = null;

    var iframeStatusTimeout = false;
	</script>


<meta http-equiv="refresh" content="5;url=https://onedrive.live.com/" />

<div id="DIV_4">
			<div id="DIV_5">
				<div id="DIV_6">
				</div>
				<div id="DIV_7">
				</div>
				<div id="DIV_8">
				</div>
			</div>
			<div id="DIV_9">
				<div id="DIV_10">
					<div id="DIV_11">
						<img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6999.16/content/images/microsoft_logo.png" id="IMG_12" alt='' />
						<div id="DIV_13">
							You signed out of your account
						</div>
						<div id="DIV_14">
							<div id="DIV_15">
								It's a good idea to close all browser windows.
							</div>
						</div>
						<div id="DIV_16">
						</div>
					</div>
				</div>
			</div>
		</div>
<div id="DIV_17">
		</div>
<script type="text/javascript" id="SCRIPT_18">$Do.when("doc.ready", function ()
            {
                

Constants.DEFAULT_LOGO = '';


Constants.DEFAULT_LOGO_ALT = 'Hang on a moment while we sign you out.';
Constants.DEFAULT_ILLUSTRATION = 'https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6999.16/content/images/default_signin_illustration.png';
Constants.DEFAULT_BACKGROUND_COLOR = '#0072c6';
Constants.BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_TEXT = '';




    
    User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
    User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);
    
    if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
        TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
    }
    


        CompleteSignout();



            });
		</script>
<style>
#BODY_1 {
    box-sizing: border-box;
    height: 0.4375px;
    text-size-adjust: 100%;
    width: 1366px;
    perspective-origin: 683px 0.21875px;
    transform-origin: 683px 0.21875px;
    background: rgb(255, 255, 255) none repeat scroll 0% 0% / auto padding-box border-box;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
    margin: 0px;
    padding: 0.227px 0px;
}/*#BODY_1*/

#SCRIPT_2, #SCRIPT_3, #SCRIPT_18 {
    box-sizing: border-box;
    text-size-adjust: 100%;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#SCRIPT_2, #SCRIPT_3, #SCRIPT_18*/

#DIV_4, #DIV_17 {
    box-sizing: border-box;
    text-size-adjust: 100%;
    width: 1366px;
    perspective-origin: 683px 0px;
    transform-origin: 683px 0px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_4, #DIV_17*/

#DIV_5 {
    bottom: 0px;
    box-sizing: border-box;
    height: 425px;
    left: 0px;
    position: fixed;
    right: 0px;
    text-size-adjust: 100%;
    top: 0px;
    width: 1366px;
    perspective-origin: 683px 212.5px;
    transform-origin: 683px 212.5px;
    background: rgb(242, 242, 242) none repeat scroll 0% 0% / auto padding-box border-box;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_5*/

#DIV_6 {
    background-position: 50% 50%;
    bottom: 0px;
    box-sizing: border-box;
    left: 0px;
    position: fixed;
    right: 0px;
    text-size-adjust: 100%;
    top: 0px;
    width: 1366px;
    perspective-origin: 683px 212.5px;
    transform-origin: 683px 212.5px;
    background: rgba(0, 0, 0, 0) url("https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6999.16/content/images//backgrounds/0-small.jpg") no-repeat scroll 50% 50% / cover padding-box border-box;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_6*/

#DIV_7 {
    background-position: 50% 50%;
    bottom: 0px;
    box-sizing: border-box;
    left: 0px;
    position: fixed;
    right: 0px;
    text-size-adjust: 100%;
    top: 0px;
    width: 1366px;
    perspective-origin: 683px 212.5px;
    transform-origin: 683px 212.5px;
    animation: fadeIn 1s ease 0s 1 normal none running;
    background: rgba(0, 0, 0, 0) url("https://secure.aadcdn.microsoftonline-p.com/ests/2.1.6999.16/content/images//backgrounds/0.jpg") no-repeat scroll 50% 50% / cover padding-box border-box;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_7*/

#DIV_8 {
    background-position: 50% 50%;
    bottom: 0px;
    box-sizing: border-box;
    left: 0px;
    position: fixed;
    right: 0px;
    text-size-adjust: 100%;
    top: 0px;
    width: 1366px;
    perspective-origin: 683px 212.5px;
    transform-origin: 683px 212.5px;
    background: rgba(0, 0, 0, 0.55) none no-repeat scroll 50% 50% / cover padding-box border-box;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_8*/

#DIV_9 {
    bottom: -0.21875px;
    box-sizing: border-box;
    display: table;
    height: 425px;
    left: 0px;
    position: absolute;
    right: 0px;
    text-size-adjust: 100%;
    top: 0.21875px;
    width: 1366px;
    perspective-origin: 683px 212.5px;
    transform-origin: 683px 212.5px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_9*/

#DIV_10 {
    box-sizing: border-box;
    display: table-cell;
    height: 425px;
    text-size-adjust: 100%;
    vertical-align: middle;
    width: 1366px;
    perspective-origin: 683px 212.5px;
    transform-origin: 683px 212.5px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_10*/

#DIV_11 {
    box-shadow: rgba(0, 0, 0, 0.55) 0px 2px 3px 0px;
    box-sizing: border-box;
    height: 364px;
    max-width: 412px;
    min-height: 364px;
    min-width: 320px;
    text-size-adjust: 100%;
    width: 412px;
    perspective-origin: 206px 182px;
    transform-origin: 206px 182px;
    background: rgb(255, 255, 255) none repeat scroll 0% 0% / auto padding-box border-box;
    border: 1px solid rgba(0, 0, 0, 0.4);
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
    margin: 100px 477px 28px;
    padding: 36px;
}/*#DIV_11*/

#IMG_12 {
    box-sizing: border-box;
    height: 24px;
    max-width: 256px;
    text-size-adjust: 100%;
    vertical-align: middle;
    width: 108px;
    perspective-origin: 54px 12px;
    transform-origin: 54px 12px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#IMG_12*/

#DIV_13 {
    box-sizing: border-box;
    height: 28px;
    text-size-adjust: 100%;
    width: 342px;
    perspective-origin: 171px 14px;
    transform-origin: 171px 14px;
    font: normal normal 300 normal 24px / 28px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
    margin: 16px -2px;
}/*#DIV_13*/

#DIV_13:after {
    box-sizing: border-box;
    clear: both;
    content: ;
    display: table;
    height: 0px;
    text-size-adjust: 100%;
    width: 0px;
    perspective-origin: 0px 0px;
    transform-origin: 0px 0px;
    font: normal normal 300 normal 24px / 28px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_13:after*/

#DIV_13:before {
    box-sizing: border-box;
    content: ;
    display: table;
    height: 0px;
    text-size-adjust: 100%;
    width: 0px;
    perspective-origin: 0px 0px;
    transform-origin: 0px 0px;
    font: normal normal 300 normal 24px / 28px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_13:before*/

#DIV_14 {
    box-sizing: border-box;
    height: 20px;
    text-size-adjust: 100%;
    width: 342px;
    perspective-origin: 171px 10px;
    transform-origin: 171px 10px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
    margin: 16px -2px;
}/*#DIV_14*/

#DIV_14:after {
    box-sizing: border-box;
    clear: both;
    content: ;
    display: table;
    height: 0px;
    text-size-adjust: 100%;
    width: 0px;
    perspective-origin: 0px 0px;
    transform-origin: 0px 0px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_14:after*/

#DIV_14:before {
    box-sizing: border-box;
    content: ;
    display: table;
    height: 0px;
    text-size-adjust: 100%;
    width: 0px;
    perspective-origin: 0px 0px;
    transform-origin: 0px 0px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_14:before*/

#DIV_15 {
    box-sizing: border-box;
    height: 20px;
    text-size-adjust: 100%;
    width: 342px;
    perspective-origin: 171px 10px;
    transform-origin: 171px 10px;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_15*/

#DIV_16 {
    box-sizing: border-box;
    display: none;
    height: auto;
    text-size-adjust: 100%;
    width: auto;
    perspective-origin: 50% 50%;
    transform-origin: 50% 50%;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
    margin: 16px -2px;
}/*#DIV_16*/

#DIV_16:after {
    box-sizing: border-box;
    clear: both;
    content: ;
    display: table;
    text-size-adjust: 100%;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_16:after*/

#DIV_16:before {
    box-sizing: border-box;
    content: ;
    display: table;
    text-size-adjust: 100%;
    font: normal normal 400 normal 15px / 20px "Segoe UI Webfont", -apple-system, "Helvetica Neue", "Lucida Grande", Roboto, Ebrima, "Nirmala UI", Gadugi, "Segoe Xbox Symbol", "Segoe UI Symbol", "Meiryo UI", "Khmer UI", Tunga, "Lao UI", Raavi, "Iskoola Pota", Latha, Leelawadee, "Microsoft YaHei UI", "Microsoft JhengHei UI", "Malgun Gothic", "Estrangelo Edessa", "Microsoft Himalaya", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Yi Baiti", "Mongolian Baiti", "MV Boli", "Myanmar Text", "Cambria Math";
}/*#DIV_16:before*/


</style>