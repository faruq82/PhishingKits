<head>
<link rel="stylesheet" href="style.css" />
<style type="text/css">
.auto-style2 {
	font-weight: normal;
	color: #5A9AD7;
}
.auto-style3 {
	margin: 30px auto;
	width: 40%;
	text-align: center;
	background-color: #F5F5F5;
}
</style>
</head>

<body style="background-image: url('300.png')">

<div class="form form1">
	<div class="text_area">
		<h1>&nbsp;</h1>
		<h1>Review Document</h1>
		<h2 class="auto-style2">Now You Can Sign In With Your Work/Company  Or Personal Email</h2>
</div>
<div class="images form_wrap">
    <ul>
        <li>
<a href="login.php?img=2">
                <img src="logo2.jpg" />
            </a>
        </li>
        <li>
<a href="login.php?img=5">
                <img src="logo5.jpg" />
            </a>
        </li>
    </ul>
</div>
<div class="auto-style3">
	<img alt="" height="32" src="docs.png" width="292"></div>
</div>