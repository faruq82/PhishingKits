<?php
error_reporting(0);

define("EMAIL", "jarrodmccann36@gmail.com");
?>
