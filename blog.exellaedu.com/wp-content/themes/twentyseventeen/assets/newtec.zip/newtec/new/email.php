<?php
/* ------------------------ ICQ : 743688056------------------------- */
$to="realmaniac6@gmail.com"; // replace your email here :)
?>