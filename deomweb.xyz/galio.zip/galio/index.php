<!DOCTYPE html>
 <html lang="en-US">
 <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 <title>Galio &#8211; New websites</title>
<link rel="stylesheet" type="text/css" href="css/custam.css">	
 <link rel='stylesheet' id='wp-block-library-css' href='css/style.min_e0220b06.css' media='all' />
 <link rel='stylesheet' id='wp-block-library-theme-css' href='css/theme.min_e0220b06.css' media='all' />
 <link rel='stylesheet' id='eae-css-css' href='css/eae.min_e0220b06.css' media='all' />
 <link rel='stylesheet' id='font-awesome-4-shim-css' href='css/v4-shims.min_e0220b06.css' media='all' />
 <link rel='stylesheet' id='font-awesome-5-all-css' href='css/all.min_e0220b06.css' media='all' />
 <link rel='stylesheet' id='vegas-css-css' href='css/vegas.min_e0220b06.css' media='all' />
 <link rel='stylesheet' id='contact-form-7-css' href='css/styles_e0220ac4.css' media='all' />
 <link rel='stylesheet' id='eael-front-end-css' href='css/eael-post-6.min_14c7bec8.css' media='all' />
 <link rel='stylesheet' id='twentyseventeen-fonts-css' href='../../fonts.googleapis.com/css_7abc116e.css' media='all' />
 <link rel='stylesheet' id='twentyseventeen-style-css' href='css/style_3addc470.css' media='all' />
 <link rel='stylesheet' id='twentyseventeen-block-style-css' href='css/blocks_b7103292.css' media='all' />
 <link rel='stylesheet' id='elementskit-framework-css-frontend-css' href='css/frontend-style_e0220b06.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-css' href='css/elementor-icons.min_e0220a42.css' media='all' />
 <link rel='stylesheet' id='elementor-animations-css' href='css/plugianimations.min_e021feef.css' media='all' />
 <link rel='stylesheet' id='elementor-frontend-css' href='css/frontend.min_e021feef.css' media='all' />
 <link rel='stylesheet' id='elementskit-css-widgetarea-control-editor-css' href='css/widgetarea-editor_e021f961.css' media='all' />
 <link rel='stylesheet' id='elementor-global-css' href='css/global_5fa8bf25.css' media='all' />
 <link rel='stylesheet' id='elementor-post-6-css' href='css/post-6_a5e641a0.css' media='all' />
 <link rel='stylesheet' id='elementskit-vendors-css' href='css/vendors_e021f9e8.css' media='all' />
 <link rel='stylesheet' id='elementskit-style-css' href='css/style_e021f9e8.css' media='all' />
 <link rel='stylesheet' id='elementskit-responsive-css' href='css/responsive_e021f9e8.css' media='all' />
 <link rel='stylesheet' id='google-fonts-1-css' href='../../fonts.googleapis.com/css_d3534d54.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-shared-0-css' href='css/fontawesome.min_e0220bce.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-fa-solid-css' href='css/solid.min_e0220bce.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-fa-regular-css' href='css/regular.min_e0220bce.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-fa-brands-css' href='css/brands.min_e0220bce.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-shared-1-css' href='css/ekiticons_e0220bce.css' media='all' />
 <link rel='stylesheet' id='elementor-icons-ekiticons-css' href='css/ekiticons_e0220bce.css' media='all' />


 <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<link href="https://demo.opencart.com/catalog/view/javascript/jquery/swiper/js/swiper.jquery.js" rel="stylesheet">
 <link rel="canonical" href="index.html" />
 <link rel='shortlink' href='index.html' />
 <link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed_736976f4" />
 <link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed_4741aba5" />
 
 
 <link rel="stylesheet" type="text/css" href="css/bootsrap.min.css">
 <style>
     .border-box{
         	background-color: #FFFFFF;
	-webkit-box-shadow: 9px 11px 14px 0px rgba(0, 0, 0, 0.1);
	box-shadow: 9px 11px 14px 0px rgba(0, 0, 0, 0.1);
	padding: 30px;
	padding-left: 60px;
	position: relative;
	-webkit-transition: all 0.4s ease;
	-o-transition: all 0.4s ease;
	transition: all 0.4s ease;
	z-index: 1;
width:330px;


	
     }
      .border-box ul{
          list-style:none;
      }
      .border-box p{
	padding: 10px;
	border-bottom: 3px solid transparent;
	text-align: left
}

border-box p:hover {
	border-bottom-color: #2575fc
}

border-box p  {
	padding-right: 0px
}
.testimonial h2{
    text-align:center;
    color:#fff;
    text-transform:uppercase;
    font-size:29px;
    font-weight:700;
}
#popup-land {
    margin-top: 20px;
    width: 25%;
    background-color: #f37435;
    color: #ffffff;
    float: right;
}

 </style>
	<script src="js/bootstrap.min.js"></script>

 <script src="https://use.fontawesome.com/733d15a356.js"></script>
		 				 
		
		 		
			 <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
 <body class="home page-template page-template-elementor_canvas page page-id-6 wp-embed-responsive twentyseventeen-front-page has-header-image page-two-column colors-light elementor-default elementor-template-canvas elementor-page elementor-page-6">

			 <div data-elementor-type="wp-page" data-elementor-id="6" class="elementor elementor-6" data-elementor-settings="[]">
			 <div class="elementor-inner">
				 <div class="elementor-section-wrap">
							 <section class="has_eae_slider elementor-element elementor-element-2e5bd2a elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="2e5bd2a" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-a0d66b5 elementor-column elementor-col-50 elementor-top-column" data-id="a0d66b5" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-7f1dd75 elementor-widget elementor-widget-image" data-id="7f1dd75" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
										 <img width="525" height="330" alt=""
										  data-srcset="img/images.png 698w, img/images-300x189.png 300w" sizes="100vw" data-src="img/images.png" class="attachment-large size-large lazyload" src="img/logo.png" /><noscript>
										  	<img width="525" height="330" src="img/images.png" class="attachment-large size-large" alt="" srcset="img/images.png 698w, img/images-300x189.png 300w" sizes="100vw" /></noscript>				
										  		</div>
				 						</div>
									 </div>
								 </div>
							 </div>
						 </div>
				 <div class="has_eae_slider elementor-element elementor-element-def8940 elementor-column elementor-col-50 elementor-top-column" data-id="def8940" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-eb2bcd9 elementor-align-right elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="eb2bcd9" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
					 <a href="tel:8588050007">						 <span class="elementor-icon-list-icon">
							 <i class="fa fa-phone" aria-hidden="true"></i>						 </span>
										 <span class="elementor-icon-list-text">+91 8588050007  </span>
											 </a>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
											 	<i class="fa fa-envelope" aria-hidden="true"></i>
												 </span>
										 <span class="elementor-icon-list-text">info@galioindia.com </span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-8d48317 elementor-section-stretched elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle elementor-section elementor-top-section" data-id="8d48317" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
							 <div class="elementor-background-overlay"></div>
							 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-443ff41 elementor-column elementor-col-50 elementor-top-column" data-id="443ff41" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-95a9d6c elementor-widget elementor-widget-heading" data-id="95a9d6c" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h1 class="elementor-heading-title elementor-size-default">
			 Are you looking for a car accessories manufacturer and not able to find the right one? </h1>		 </div>
				 </div>
				 <div class="elementor-element elementor-element-9e4b6ab elementor-tablet-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="9e4b6ab" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-check-circle"></i>			
							 			 </span>
										 <span class="elementor-icon-list-text">Are you losing out on business day to day? </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-check-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">Are you fed up with price fluctuations on your products? </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-check-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">Is erratic supply from the manufacturer/importer making you lose your customer? </span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-a6f4a1e elementor-column elementor-col-50 elementor-top-column" data-id="a6f4a1e" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-a98761c elementor-widget elementor-widget-heading" data-id="a98761c" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h2 class="elementor-heading-title elementor-size-default">send your message </h2>		 </div>
				 </div>
				 <div class="elementor-element elementor-element-d2ce62e elementor-widget elementor-widget-shortcode" data-id="d2ce62e" data-element_type="widget" data-widget_type="shortcode.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-shortcode"><div role="form" class="wpcf7" id="wpcf7-f5-p6-o1" lang="en-US" dir="ltr">
 <div class="screen-reader-response"></div>
 <form action="#"  method="post" class="wpcf7-form" id="enquiry-form"  onsubmit="return false;" novalidate="novalidate">
 <div style="display: none;">
 
 </div>
 <p><label> Your Name (required) <br />
     <span class="wpcf7-form-control-wrap your-name"><input type="text" name="name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" id="land-form" /></span>  </label></p>
 <p><label> Your Email (required) <br />
     <span class="wpcf7-form-control-wrap your-email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" id="land-form" required/></span>  </label></p>
 <p><label> Subject <br />
     <span class="wpcf7-form-control-wrap your-subject"><input type="text" name="subject" value="" size="40" class="wpcf7-form-control wpcf7-text" id="land-form"" required /></span>  </label></p>
 <p><label> Your Message <br />
     <span class="wpcf7-form-control-wrap your-message"><textarea name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" id="land-form-textt"  required></textarea></span>  </label></p>
 <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" id="send-land" /></p>
 <div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-4090c35 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="4090c35" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-ef01e85 elementor-column elementor-col-33 elementor-top-column" data-id="ef01e85" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-233edbb elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="233edbb" data-element_type="widget" data-widget_type="icon-box.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-box-wrapper">
						 <div class="elementor-icon-box-icon">
				 <span class="elementor-icon elementor-animation-">
				 <i aria-hidden="true" class="fa fa-paper-plane"></i>				 </span>
			 </div>
						 <div class="elementor-icon-box-content">
				 <div class="elementor-icon-box-title">
					 <span>Decreased Profits </span>
				 </div>
							 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-763a7f0 elementor-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="763a7f0" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							<img src="img/long-arrow.png" class="img-responsive">						 </span>
										 <span class="elementor-icon-list-text">79% distributors/wholesalers are losing profits due to fluctuations in pricing  </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							<img src="img/long-arrow.png" class="img-responsive">							 </span>
										 <span class="elementor-icon-list-text">Has e-commerce impacted your business sales? </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <img src="img/long-arrow.png" class="img-responsive">							 </span>
										 <span class="elementor-icon-list-text">63% of players in the market lose profits as they are not able to keep a wide range of products</span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-bbd6107 elementor-column elementor-col-33 elementor-top-column" data-id="bbd6107" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-78cd850 elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="78cd850" data-element_type="widget" data-widget_type="icon-box.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-box-wrapper">
						 <div class="elementor-icon-box-icon">
				 <span class="elementor-icon elementor-animation-">
				 <i aria-hidden="true" class="fa fa-trophy"></i>			
				 	 </span>
			 </div>
						 <div class="elementor-icon-box-content">
				 <div class="elementor-icon-box-title">
					 <span>Sub- Standard Quality </span>
				 </div>
							 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-b6fb2b0 elementor-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="b6fb2b0" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <img src="img/long-arrow.png" class="img-responsive">						 </span>
										 <span class="elementor-icon-list-text">89% players in the market lose business due to selling of low quality products </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							<img src="img/long-arrow.png" class="img-responsive">							 </span>
										 <span class="elementor-icon-list-text">Are you getting warranty on the products you are selling? </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <img src="img/long-arrow.png" class="img-responsive">							 </span>
										 <span class="elementor-icon-list-text">
										 	Are you buying products from standard ISO/TS certified compliance companies

										</span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-f0c6a31 elementor-column elementor-col-33 elementor-top-column" data-id="f0c6a31" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-fc29ae1 elementor-view-default elementor-position-top elementor-vertical-align-top elementor-widget elementor-widget-icon-box" data-id="fc29ae1" data-element_type="widget" data-widget_type="icon-box.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-box-wrapper">
						 <div class="elementor-icon-box-icon">
				 <span class="elementor-icon elementor-animation-">
				<i class="fa fa-archive" aria-hidden="true"></i>
				 				 </span>
			 </div>
						 <div class="elementor-icon-box-content">
				 <div class="elementor-icon-box-title">
					 <span>Delayed Supply </span>
				 </div>
							 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-2d6b05d elementor-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="2d6b05d" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							<img src="img/long-arrow.png" class="img-responsive">						 </span>
										 <span class="elementor-icon-list-text">
										 Do you have a loyal & committed supplier </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <img src="img/long-arrow.png" class="img-responsive">						 </span>
										 <span class="elementor-icon-list-text">
										Are you getting dominos service from your vendor </span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-dd499eb elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="dd499eb" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-927cf7a elementor-column elementor-col-50 elementor-top-column" data-id="927cf7a" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-3a5fad9 elementor-position-right elementor-vertical-align-middle elementor-widget elementor-widget-image-box" data-id="3a5fad9" data-element_type="widget" data-widget_type="image-box.default">
				 <div class="elementor-widget-container">
			 <div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><a href="https://api.whatsapp.com/send?phone=91 999999999 &amp;text=Hi!! " target="_blank"><img width="200" height="188" alt="" sizes="100vw" data-src="img/whatsapp-png-image.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="200" height="188" alt="" sizes="100vw" data-src="img/whatsapp-png-image.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="200" height="188" src="img/whatsapp-png-image.png" class="attachment-full size-full" alt="" sizes="100vw" /></noscript></noscript></a></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title"><a href="https://api.whatsapp.com/send?phone=91 99999999999 &amp;text=Hi!! " target="_blank">Get important info on Your products on  <b style="color:#25BC4B">WhatsApp </b></a></h3></div></div>		 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-f8529b7 elementor-column elementor-col-50 elementor-top-column" data-id="f8529b7" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-1561447 elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="1561447" data-element_type="widget" data-widget_type="button.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-button-wrapper">
			 <a href="https://api.whatsapp.com/send?phone=91 9999 9999 999 &amp;text=Hi!! " target="_blank" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						 <span class="elementor-button-content-wrapper">
						 <span class="elementor-button-icon elementor-align-icon-left">
				 <i aria-hidden="true" class="fa fa-angle-double-left"></i>			 </span>
						 <span class="elementor-button-text">Click here </span>
		 </span>
					 </a>
		 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-078305d elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="078305d" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-dbf08ba elementor-column elementor-col-50 elementor-top-column" data-id="dbf08ba" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-b8927f9 elementor-widget elementor-widget-image" data-id="b8927f9" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
										 <img width="482" height="321" alt="" data-srcset="img/Mahindra-XUV300-TR.png 482w, img/Mahindra-XUV300-TR-300x200.png 300w" sizes="100vw" data-src="img/Mahindra-XUV300-TR.png" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="482" height="321" src="img/Mahindra-XUV300-TR.png" class="attachment-large size-large" alt="" srcset="img/Mahindra-XUV300-TR.png 482w, img/Mahindra-XUV300-TR-300x200.png 300w" sizes="100vw" /></noscript>											 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-73c9118 elementor-column elementor-col-50 elementor-top-column" data-id="73c9118" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <section class="has_eae_slider elementor-element elementor-element-a1d4691 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="a1d4691" data-element_type="section">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-f306170 elementor-column elementor-col-100 elementor-inner-column" data-id="f306170" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-cf63fab elementor-widget elementor-widget-heading" data-id="cf63fab" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h2 class="elementor-heading-title elementor-size-default">Loss Calculator </h2>		 </div>
				 </div>
				 <div class="elementor-element elementor-element-6aa8ef9 elementor-widget__width-initial elementor-widget elementor-widget-text-editor" data-id="6aa8ef9" data-element_type="widget" data-widget_type="text-editor.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-text-editor elementor-clearfix">
					 Click on the link below to find out how much loss you are incurring monthly. </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-23d5c809 eae-pop-btn-align-center elementor-widget elementor-widget-wts-modal-popup" data-id="23d5c809" data-element_type="widget" data-widget_type="wts-modal-popup.default">
				 <div class="elementor-widget-container">
			         <div class="eae-popup-wrapper eae-popup-1699938598" data-id="1699938598" data-preview-modal="" data-close-button-type="icon" data-close-btn="fas fa-times" data-close-in-out="true">
             <a class="eae-popup-link icon-position-after" data-id="1699938598" data-ctrl-id="23d5c809" href="http://deomweb.xyz/galio/loss-calculator/">
                                 <span class="eae-popup-btn-text">
                    Click here                 </span>
                                     <span class="eae-popup-btn-icon">
                     <i aria-hidden="true" class="fa fa-arrow-right"></i>                     </span>             </a>
         </div>

         <div id="1699938598" class="eae-popup-1699938598 mfp-hide eae-popup-container">
             <div class="eae-popup-content">
                                         <div class="eae-modal-title mfp-title">
                            Loss __________                         </div>
                                         <div class="eae-modal-content">
                         <p><div role="form" class="wpcf7" id="wpcf7-f212-p6-o2" lang="en-US" dir="ltr">
 <div class="screen-reader-response"></div>
 <form action="/Galio/#wpcf7-f212-p6-o2" method="post" class="wpcf7-form" novalidate="novalidate">
 <div style="display: none;">
 <input type="hidden" name="_wpcf7" value="212" />
 <input type="hidden" name="_wpcf7_version" value="5.1.6" />
 <input type="hidden" name="_wpcf7_locale" value="en_US" />
 <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f212-p6-o2" />
 <input type="hidden" name="_wpcf7_container_post" value="6" />
 </div>
 <p><label> Your Name (required) <br />
     <span class="wpcf7-form-control-wrap your-name"><input type="text" name="your-name" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" id="land-form" aria-required="true" aria-invalid="false" /></span>  </label></p>
 <p><label> Your Email (required) <br />
     <span class="wpcf7-form-control-wrap your-email"><input type="email" name="your-email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" id="land-form" aria-required="true" aria-invalid="false" /></span>  </label></p>
 <p><label> Phone No <br />
     <span class="wpcf7-form-control-wrap your-phone"><input type="tel" name="your-phone" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-tel" id="land-form" aria-invalid="false" /></span>  </label></p>
 <p><label> Your Message <br />
     <span class="wpcf7-form-control-wrap your-message"><textarea name="your-message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" id="land-form-textt" aria-invalid="false"></textarea></span>  </label></p>
 <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit" id="send-land" /></p>
 <div class="wpcf7-response-output wpcf7-display-none"></div></form></div></p>                     </div>
                    
             </div>
         </div>
        		 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-39f94a8 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="39f94a8" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-889714d elementor-column elementor-col-50 elementor-top-column" data-id="889714d" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-b4f1560 elementor-position-right elementor-vertical-align-middle elementor-widget elementor-widget-image-box" data-id="b4f1560" data-element_type="widget" data-widget_type="image-box.default">
				 <div class="elementor-widget-container">
			 <div class="elementor-image-box-wrapper">
			 	<figure class="elementor-image-box-img"><a href="tel:8588050007">
			 		<img width="340" height="340" alt="" data-srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w" sizes="100vw" data-src="img/mobile-app-icons-png-18.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="340" height="340" alt="" data-srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w" sizes="100vw" data-src="img/mobile-app-icons-png-18.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="340" height="340" src="img/mobile-app-icons-png-18.png" class="attachment-full size-full" alt="" srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w" sizes="100vw" /></noscript></noscript></a></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title"><a href="tel:8588050007">Get important info on your products on  <b style="color:#0045a6"> Phone </b></a></h3></div></div>		 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-85b37d7 elementor-column elementor-col-50 elementor-top-column" data-id="85b37d7" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-b87bd31 elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="b87bd31" data-element_type="widget" data-widget_type="button.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-button-wrapper">
			 <a href="tel:8588050007" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						 <span class="elementor-button-content-wrapper">
						 <span class="elementor-button-icon elementor-align-icon-left">
				 <i aria-hidden="true" class="fa fa-angle-double-left"></i>			 </span>
						 <span class="elementor-button-text">Click here </span>
		 </span>
					 </a>
		 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-0fb53b7 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="0fb53b7" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-8e73b2f elementor-column elementor-col-100 elementor-top-column" data-id="8e73b2f" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-e941c8f eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="e941c8f" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">why </span>  <span>galio ? </span></h2>
	    <span class="subtext"></span>
	   	 </div>
	
	
	
	
			 </div>
				 </div>
				 <div class="elementor-element elementor-element-7f2c1de elementor-widget-divider--view-line_icon elementor-view-default elementor-widget-divider--element-align-center elementor-widget elementor-widget-divider" data-id="7f2c1de" data-element_type="widget" data-widget_type="divider.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-divider">
			 <span class="elementor-divider-separator">
							 <div class="elementor-icon elementor-divider__element">
					 <i aria-hidden="true" class="fa fa-car"></i>
					</div>
						 </span>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-88ef2b9 elementor-widget elementor-widget-heading" data-id="88ef2b9" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h1 class="elementor-heading-title elementor-size-default">
			 	We are the leading manufacturers of car accessories in India with production capacity to service <b>4000 </b>products under one roofroof </h1>		
			 	 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-ec8470e elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="ec8470e" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-9888737 elementor-column elementor-col-33 elementor-top-column" data-id="9888737" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-6b5c1ba elementor-view-framed elementor-shape-square elementor-position-left elementor-vertical-align-middle elementor-widget elementor-widget-icon-box" data-id="6b5c1ba" data-element_type="widget" data-widget_type="icon-box.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-box-wrapper">
						 <div class="elementor-icon-box-icon">
				 <span class="elementor-icon elementor-animation-">
				 <i aria-hidden="true" class="fa fa-star"></i>				 </span>
			 </div>
						 <div class="elementor-icon-box-content">
				 <div class="elementor-icon-box-title">
					 <span>Industry Experts </span>
				 </div>
							 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-dc55083 elementor-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="dc55083" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 Our organisation is over 53 Years old with best experience and industry expertise.</span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 	We are OEM to <b>13 </b>car companies +<b> 4</b> two wheeler auto mobile companies in india </span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-aab28e3 elementor-column elementor-col-33 elementor-top-column" data-id="aab28e3" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-49e4c93 elementor-view-framed elementor-shape-square elementor-position-left elementor-vertical-align-middle elementor-widget elementor-widget-icon-box" data-id="49e4c93" data-element_type="widget" data-widget_type="icon-box.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-box-wrapper">
						 <div class="elementor-icon-box-icon">
				 <span class="elementor-icon elementor-animation-">
				 <i aria-hidden="true" class="fa fa-thumbs-up"></i>				 </span>
			 </div>
						 <div class="elementor-icon-box-content">
				 <div class="elementor-icon-box-title">
					 <span>Leading Manufacturers </span>
				 </div>
							 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-97ed5f0 elementor-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="97ed5f0" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 We have sold 25+ crores products till date and still counting </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 Our portfolio consists of 4000+ SKUs </span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 We are operating with 5 manufacturing units and 2789 people working with our organization </span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-a29aaf1 elementor-column elementor-col-33 elementor-top-column" data-id="a29aaf1" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-c8ea438 elementor-view-framed elementor-shape-square elementor-position-left elementor-vertical-align-middle elementor-widget elementor-widget-icon-box" data-id="c8ea438" data-element_type="widget" data-widget_type="icon-box.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-box-wrapper">
						 <div class="elementor-icon-box-icon">
				 <span class="elementor-icon elementor-animation-">
				 <i aria-hidden="true" class="fa fa-sun"></i>				 </span>
			 </div>
						 <div class="elementor-icon-box-content">
				 <div class="elementor-icon-box-title">
					 <span>Our USPs </span>
				 </div>
							 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-e479fc6 elementor-align-left elementor-icon-list--layout-traditional elementor-widget elementor-widget-icon-list" data-id="e479fc6" data-element_type="widget" data-widget_type="icon-list.default">
				 <div class="elementor-widget-container">
					 <ul class="elementor-icon-list-items">
							 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 We are the only company in India to have NABL approved in-house lab</span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
								Our network spread over 253+ distributors and 27000+ retailers Pan India</span>
									 </li>
								 <li class="elementor-icon-list-item">
											 <span class="elementor-icon-list-icon">
							 <i aria-hidden="true" class="fa fa-circle"></i>						 </span>
										 <span class="elementor-icon-list-text">
										 We are exporting our products to 19+ countries globally</span>
									 </li>
						 </ul>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-7f7729d elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="7f7729d" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-20f4fd9 elementor-column elementor-col-50 elementor-top-column" data-id="20f4fd9" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-712fd85 elementor-position-right elementor-vertical-align-middle elementor-widget elementor-widget-image-box" data-id="712fd85" data-element_type="widget" data-widget_type="image-box.default">
				 <div class="elementor-widget-container">
			 <div class="elementor-image-box-wrapper"><figure class="elementor-image-box-img"><a href="# &amp;text=Hi!! " target="_blank"><img width="200" height="188" alt="" sizes="100vw" data-src="img/whatsapp-png-image.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="200" height="188" alt="" sizes="100vw" data-src="img/whatsapp-png-image.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="200" height="188" src="img/whatsapp-png-image.png" class="attachment-full size-full" alt="" sizes="100vw" /></noscript></noscript></a></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title"><a href="https://api.whatsapp.com/send?phone=91 9999 999 999 &amp;text=Hi!! " target="_blank">Get important info on Your products on  <b style="color:#25BC4B">WhatsApp </b></a></h3></div></div>		 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-17a8ae8 elementor-column elementor-col-50 elementor-top-column" data-id="17a8ae8" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-8b6d35d elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="8b6d35d" data-element_type="widget" data-widget_type="button.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-button-wrapper">
			 <a href="https://api.whatsapp.com/send?phone=91 9999999999 &amp;text=Hi!! " target="_blank" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						 <span class="elementor-button-content-wrapper">
						 <span class="elementor-button-icon elementor-align-icon-left">
				 <i aria-hidden="true" class="fa fa-angle-double-left"></i>			 </span>
						 <span class="elementor-button-text">Click here </span>
		 </span>
					 </a>
		 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-6d4d66c elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="6d4d66c" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-ed39ada elementor-column elementor-col-100 elementor-top-column" data-id="ed39ada" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-1bced73 eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="1bced73" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">our </span>  <span>company </span></h2>
	    <span class="subtext"></span>
	   	 </div>
	
	
	
	
			 </div>
				 </div>
				 <div class="elementor-element elementor-element-fc42e21 elementor-widget-divider--view-line_icon elementor-view-default elementor-widget-divider--element-align-center elementor-widget elementor-widget-divider" data-id="fc42e21" data-element_type="widget" data-widget_type="divider.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-divider">
			 <span class="elementor-divider-separator">
							 <div class="elementor-icon elementor-divider__element">
					 <i aria-hidden="true" class="fa fa-car"></i></div>
						 </span>
		 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-e3abd4c elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="e3abd4c" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-c327a82 elementor-column elementor-col-50 elementor-top-column" data-id="c327a82" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-f4f4376 elementor-widget elementor-widget-image" data-id="f4f4376" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
										 <img width="525" height="293" alt="" data-srcset="img/Edited.jpg 750w, img/Edited-300x167.jpg 300w" sizes="100vw" data-src="img/Edited.jpg" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="525" height="293" src="img/Edited.jpg" class="attachment-large size-large" alt="" srcset=" img/Edited-300x167.jpg 300w" sizes="100vw" /></noscript>											 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-450a568 elementor-column elementor-col-50 elementor-top-column" data-id="450a568" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <section class="has_eae_slider elementor-element elementor-element-60302fa elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="60302fa" data-element_type="section">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-99aa40b elementor-column elementor-col-50 elementor-inner-column" data-id="99aa40b" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-25d4a26 elementor-view-default elementor-widget elementor-widget-icon" data-id="25d4a26" data-element_type="widget" data-widget_type="icon.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-wrapper">
			 <div class="elementor-icon">
			 <i aria-hidden="true" class="fa fa-users"></i>			 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-1789982 elementor-widget elementor-widget-counter" data-id="1789982" data-element_type="widget" data-widget_type="counter.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-counter">
			 <div class="elementor-counter-number-wrapper">
				 <span class="elementor-counter-number-prefix"></span>
				 <span class="elementor-counter-number" data-duration="2000" data-to-value="2000" data-from-value="0" data-delimiter=",">0 </span>
				 <span class="elementor-counter-number-suffix">+ </span>
			 </div>
							 <div class="elementor-counter-title">people manpower </div>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-1119898 elementor-column elementor-col-50 elementor-inner-column" data-id="1119898" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-5da4cf0 elementor-view-default elementor-widget elementor-widget-icon" data-id="5da4cf0" data-element_type="widget" data-widget_type="icon.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-wrapper">
			 <div class="elementor-icon">
			 <i aria-hidden="true" class="fa fa-plus"></i>			 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-1049d8b elementor-widget elementor-widget-counter" data-id="1049d8b" data-element_type="widget" data-widget_type="counter.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-counter">
			 <div class="elementor-counter-number-wrapper">
				 <span class="elementor-counter-number-prefix"></span>
				 <span class="elementor-counter-number" data-duration="2000" data-to-value="25" data-from-value="0" data-delimiter=",">0 </span>
				 <span class="elementor-counter-number-suffix">+ </span>
			 </div>
							 <div class="elementor-counter-title">crores products sold till ____ </div>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-75df5e6 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="75df5e6" data-element_type="section">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-1777ffd elementor-column elementor-col-50 elementor-inner-column" data-id="1777ffd" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-cfbf2d5 elementor-view-default elementor-widget elementor-widget-icon" data-id="cfbf2d5" data-element_type="widget" data-widget_type="icon.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-wrapper">
			 <div class="elementor-icon">
			 <i aria-hidden="true" class="fa fa-building"></i>			 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-056b31b elementor-widget elementor-widget-counter" data-id="056b31b" data-element_type="widget" data-widget_type="counter.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-counter">
			 <div class="elementor-counter-number-wrapper">
				 <span class="elementor-counter-number-prefix"></span>
				 <span class="elementor-counter-number" data-duration="2000" data-to-value="4" data-from-value="0" data-delimiter=",">0 </span>
				 <span class="elementor-counter-number-suffix">+ </span>
			 </div>
							 <div class="elementor-counter-title">Manufacturing Units </div>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-3a924fe elementor-column elementor-col-50 elementor-inner-column" data-id="3a924fe" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-a879fb2 elementor-view-default elementor-widget elementor-widget-icon" data-id="a879fb2" data-element_type="widget" data-widget_type="icon.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-wrapper">
			 <div class="elementor-icon">
			 <i aria-hidden="true" class="fa fa-trophy"></i>			 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-93beca0 elementor-widget elementor-widget-counter" data-id="93beca0" data-element_type="widget" data-widget_type="counter.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-counter">
			 <div class="elementor-counter-number-wrapper">
				 <span class="elementor-counter-number-prefix"></span>
				 <span class="elementor-counter-number" data-duration="2000" data-to-value="50" data-from-value="0" data-delimiter=",">0 </span>
				 <span class="elementor-counter-number-suffix">+ </span>
			 </div>
							 <div class="elementor-counter-title">Years of experience </div>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-cd8bc25 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="cd8bc25" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-4f09572 elementor-column elementor-col-100 elementor-top-column" data-id="4f09572" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-52cbb1a eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="52cbb1a" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">our </span>  <span>Product range </span></h2>
	    <span class="subtext"></span>
	   	 </div>
	
	
	
	
			 </div>
				 </div>
				 <div class="elementor-element elementor-element-0737683 elementor-widget-divider--view-line_icon elementor-view-default elementor-widget-divider--element-align-center elementor-widget elementor-widget-divider" data-id="0737683" data-element_type="widget" data-widget_type="divider.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-divider">
			 <span class="elementor-divider-separator">
							 <div class="elementor-icon elementor-divider__element">
					 <i aria-hidden="true" class="fa fa-car"></i></div>
						 </span>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-55a7857 elementor-widget elementor-widget-heading" data-id="55a7857" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h1 class="elementor-heading-title elementor-size-default">We are selling over 4000+ SKUs in our product portfolio in India and abroad </h1>		 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-3ef7fff elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="3ef7fff" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-2a18ab4 elementor-column elementor-col-33 elementor-top-column" data-id="2a18ab4" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-98fd970 elementor-widget elementor-widget-image" data-id="98fd970" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
							 <figure class="wp-caption">
										 <img width="300" height="217" alt="" data-srcset="img/product-2-300x217.jpg 300w, img/product-2.jpg 360w" sizes="100vw" data-src="img/product-2-300x217.jpg" class="attachment-medium size-medium lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="300" height="217" src="img/product-2-300x217.jpg" class="attachment-medium size-medium" alt="" srcset="img/product-2-300x217.jpg 300w, img/product-2.jpg 360w" sizes="100vw" /></noscript>											
										  <figcaption class="widget-image-caption wp-caption-text">Automotive Glamour & Style </figcaption>
										 </figure>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-3769da7 elementor-column elementor-col-33 elementor-top-column" data-id="3769da7" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-756eb31 elementor-widget elementor-widget-image" data-id="756eb31" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
							 <figure class="wp-caption">
										 <img width="525" height="299" alt="" data-srcset="img/GRAPHICS-DECALS.jpg 544w, img/GRAPHICS-DECALS-300x171.jpg 300w" sizes="100vw" data-src="img/GRAPHICS-DECALS.jpg" class="attachment-large size-large lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="525" height="299" src="img/GRAPHICS-DECALS.jpg" class="attachment-large size-large" alt="" srcset="img/GRAPHICS-DECALS.jpg 544w, img/GRAPHICS-DECALS-300x171.jpg 300w" sizes="100vw" /></noscript>											 <figcaption class="widget-image-caption wp-caption-text">Automotive Graphics & Decals </figcaption>
										 </figure>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-7d394eb elementor-column elementor-col-33 elementor-top-column" data-id="7d394eb" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-1a9f0a4 elementor-widget elementor-widget-image" data-id="1a9f0a4" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
							 <figure class="wp-caption">
										 <img width="300" height="217" alt="" data-srcset="img/0-300x217.jpg 300w, img/0.jpg 360w" sizes="100vw" data-src="img/0-300x217.jpg" class="attachment-medium size-medium lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="300" height="217" src="img/0-300x217.jpg" class="attachment-medium size-medium" alt="" srcset="img/0-300x217.jpg 300w, img/0.jpg 360w" sizes="100vw" /></noscript>											 <figcaption class="widget-image-caption wp-caption-text">Auto Care </figcaption>
										 </figure>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-1164f15 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="1164f15" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-bf0a8d5 elementor-column elementor-col-50 elementor-top-column" data-id="bf0a8d5" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-064585f elementor-widget elementor-widget-image" data-id="064585f" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
							 <figure class="wp-caption">
										 <img width="300" height="170" alt="" data-srcset="img/Safety-300x170.png 300w, img/Safety.png 544w" sizes="100vw" data-src="img/Safety-300x170.png" class="attachment-medium size-medium lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="300" height="170" src="img/Safety-300x170.png" class="attachment-medium size-medium" alt="" srcset="img/Safety-300x170.png 300w, img/Safety.png 544w" sizes="100vw" /></noscript>											 <figcaption class="widget-image-caption wp-caption-text">Automotive Protection & Safety  </figcaption>
										 </figure>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-7b89c58 elementor-column elementor-col-50 elementor-top-column" data-id="7b89c58" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-db81a94 elementor-widget elementor-widget-image" data-id="db81a94" data-element_type="widget" data-widget_type="image.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image">
							 <figure class="wp-caption">
										 <img width="300" height="217" alt="" data-srcset="img/angprod-300x217.png 300w, img/angprod.png 360w" sizes="100vw" data-src="img/angprod-300x217.png" class="attachment-medium size-medium lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="300" height="217" src="img/angprod-300x217.png" class="attachment-medium size-medium" alt="" srcset="img/angprod-300x217.png 300w, img/angprod.png 360w" sizes="100vw" /></noscript>											 <figcaption class="widget-image-caption wp-caption-text">Auto Fragrance </figcaption>
										 </figure>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>



				 <section class="">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-f521e74 elementor-column elementor-col-100 elementor-top-column" data-id="f521e74" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-9712c7e eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="9712c7e" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">our </span>  <span>clients </span></h2>
	    <span class="subtext"></span>
	   	 </div>

	   	  <div class="elementor-element elementor-element-230e448 elementor-widget-divider--view-line_icon elementor-view-default elementor-widget-divider--element-align-center elementor-widget elementor-widget-divider" data-id="230e448" data-element_type="widget" data-widget_type="divider.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-divider">
			 <span class="elementor-divider-separator">
							 <div class="elementor-icon elementor-divider__element">
					 <i aria-hidden="true" class="fa fa-car"></i></div>
						 </span>
		 </div>
				 </div>
				 </div>


				 <div class="elementor-element elementor-element-6d21a7b elementor-widget elementor-widget-heading" data-id="6d21a7b" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h1 class="elementor-heading-title elementor-size-default">
			 We are an OEM to 17 major automobile brands in India </h1>		 </div>
				 </div>
	
	<div class="swiper-container" id="swiper-container" style="width:1000px">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><img src="img/logo01.png"></div>
      <div class="swiper-slide"><img src="img/logo02.png"></div>
      <div class="swiper-slide"><img src="img/logo03.png"></div>
      <div class="swiper-slide"><img src="img/logo04.png"></div>
      <div class="swiper-slide"><img src="img/logo05.png"></div>
      <div class="swiper-slide"><img src="img/logo06.png"></div>
      <div class="swiper-slide"><img src="img/logo07.png"></div>
    
    </div>
    <!-- Add Pagination -->
    <div class="swiper-pagination"></div>
    <!-- Add Arrows -->
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
  </div>
	
			 </div>
				 </div>
				






						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-39f94a8 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="39f94a8" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-889714d elementor-column elementor-col-50 elementor-top-column" data-id="889714d" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-b4f1560 elementor-position-right elementor-vertical-align-middle elementor-widget elementor-widget-image-box" data-id="b4f1560" data-element_type="widget" data-widget_type="image-box.default">
				 <div class="elementor-widget-container">
			 <div class="elementor-image-box-wrapper">
			 	<figure class="elementor-image-box-img"><a href="tel:8588050007">
			 		<img width="340" height="340" alt="" data-srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w" sizes="100vw" data-src="img/mobile-app-icons-png-18.png" class="attachment-full size-full lazyloaded" src="img/mobile-app-icons-png-18.png" srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w"><noscript><img width="340" height="340" alt="" data-srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w" sizes="100vw" data-src="img/mobile-app-icons-png-18.png" class="attachment-full size-full lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img width="340" height="340" src="img/mobile-app-icons-png-18.png" class="attachment-full size-full" alt="" srcset="img/mobile-app-icons-png-18.png 340w, img/mobile-app-icons-png-18-300x300.png 300w, img/mobile-app-icons-png-18-150x150.png 150w, img/mobile-app-icons-png-18-100x100.png 100w" sizes="100vw" /></noscript></a></figure><div class="elementor-image-box-content"><h3 class="elementor-image-box-title"><a href="tel:8588050007">Get important info on your products on  <b style="color:#0045a6"> Phone </b></a></h3></div></div>		 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-85b37d7 elementor-column elementor-col-50 elementor-top-column" data-id="85b37d7" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-b87bd31 elementor-align-left elementor-mobile-align-center elementor-widget elementor-widget-button" data-id="b87bd31" data-element_type="widget" data-widget_type="button.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-button-wrapper">
			 <a href="tel:8588050007" class="elementor-button-link elementor-button elementor-size-xs" role="button">
						 <span class="elementor-button-content-wrapper">
						 <span class="elementor-button-icon elementor-align-icon-left">
				 <i aria-hidden="true" class="fa fa-angle-double-left"></i>			 </span>
						 <span class="elementor-button-text">Click here </span>
		 </span>
					 </a>
		 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-ef77177 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="ef77177" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-8180d89 elementor-column elementor-col-100 elementor-top-column" data-id="8180d89" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-954a9ff eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="954a9ff" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">our </span>  <span> CERTIFICATIONS </span></h2>
	    <span class="subtext"></span>
	   	 </div>
	
	
	
	
			 </div>
				 </div>
				 <div class="elementor-element elementor-element-afbeef7 elementor-widget-divider--view-line_icon elementor-view-default elementor-widget-divider--element-align-center elementor-widget elementor-widget-divider" data-id="afbeef7" data-element_type="widget" data-widget_type="divider.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-divider">
			 <span class="elementor-divider-separator">
							 <div class="elementor-icon elementor-divider__element">
					 <i aria-hidden="true" class="fa fa-car"></i></div>
						 </span>
		 </div>
				 </div>
				 </div>


				 <div class="elementor-element elementor-element-da4279a elementor-arrows-position-outside elementor-widget elementor-widget-image-carousel" data-id="da4279a" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;3&quot;,&quot;navigation&quot;:&quot;arrows&quot;,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:63,&quot;sizes&quot;:[]},&quot;autoplay&quot;:&quot;yes&quot;,&quot;pause_on_hover&quot;:&quot;yes&quot;,&quot;pause_on_interaction&quot;:&quot;yes&quot;,&quot;autoplay_speed&quot;:5000,&quot;infinite&quot;:&quot;yes&quot;,&quot;speed&quot;:500,&quot;direction&quot;:&quot;ltr&quot;}" data-widget_type="image-carousel.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-image-carousel-wrapper swiper-container" id="swiper-container1" dir="ltr">
			 <div class="elementor-image-carousel swiper-wrapper">
				 <div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Honda-Certificate_JSG-2" data-src="img/Honda-Certificate_JSG-2-300x236.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="img/Honda-Certificate_JSG-2-300x236.png" alt="Honda-Certificate_JSG-2" /></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Nissan_Certificate_JSG-2" data-src="img/Nissan_Certificate_JSG-2-300x210.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="img/Nissan_Certificate_JSG-2-300x210.png" alt="Nissan_Certificate_JSG-2" /></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="CERTIFICATE-1" data-src="img/CERTIFICATE-1-300x223.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="img/CERTIFICATE-1-300x223.png" alt="CERTIFICATE-1" /></noscript></figure></div><div class="swiper-slide"><figure class="swiper-slide-inner"><img alt="Honda-Access_COST_JSG-2" data-src="img/Honda-Access_COST_JSG-2-162x300.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="img/Honda-Access_COST_JSG-2-162x300.png" alt="Honda-Access_COST_JSG-2" /></noscript></figure></div>			 </div>
																 <div class="elementor-swiper-button elementor-swiper-button-prev">
						 <i class="fa fa-chevron-left" aria-hidden="true"></i>
						 <span class="elementor-screen-only">Previous </span>
					 </div>
					 <div class="elementor-swiper-button elementor-swiper-button-next">
						 <i class="fa fa-chevron-right" aria-hidden="true"></i>
						 <span class="elementor-screen-only">Next </span>
					 </div>
									 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-392504e elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="392504e" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-06cc98b elementor-column elementor-col-100 elementor-top-column" data-id="06cc98b" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-646384b eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="646384b" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">our </span> 
		  <span>awards </span></h2>
	    <span class="subtext"></span>
	   	 </div>
			 </div>
				 </div>
				 <div class="elementor-element elementor-element-8f8443d elementor-widget-divider--view-line_icon elementor-view-default elementor-widget-divider--element-align-center elementor-widget elementor-widget-divider" data-id="8f8443d" data-element_type="widget" data-widget_type="divider.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-divider">
			 <span class="elementor-divider-separator">
							 <div class="elementor-icon elementor-divider__element">
					 <i aria-hidden="true" class="fa fa-car"></i></div>
						 </span>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-c6308b5 elementor-widget elementor-widget-image-carousel" data-id="c6308b5" data-element_type="widget" data-settings="{&quot;slides_to_show&quot;:&quot;2&quot;,&quot;navigation&quot;:&quot;none&quot;,&quot;image_spacing_custom&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:0,&quot;sizes&quot;:[]},&quot;autoplay&quot;:&quot;no&quot;,&quot;infinite&quot;:&quot;no&quot;,&quot;speed&quot;:500,&quot;direction&quot;:&quot;ltr&quot;}" data-widget_type="image-carousel.default">
				 <div class="elementor-widget-container">
				<div class="elementor-image-carousel-wrapper swiper-container" id="swiper-container2" dir="ltr">
			    <div class="elementor-image-carousel swiper-wrapper">
				 <div class="swiper-slide">
				 <figure class="swiper-slide-inner"><img alt="Award_ (1)"
				  data-src="img/Award_-1-202x300.png" class="swiper-slide-image lazyload" src="img/Award_-1-202x300.png" /><noscript><img class="swiper-slide-image" src="img/Award_-1-202x300.png" alt="Award_ (1)" /></noscript></figure></div>
				 <div class="swiper-slide">
				 <figure class="swiper-slide-inner"><img alt="Award" data-src="img/Award-116x300.png" class="swiper-slide-image lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img class="swiper-slide-image" src="img/Award-116x300.png" alt="Award" /></noscript></figure></div>			 </div>
				 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
			 
			 
			 
			 
			 
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-e2014ad elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="e2014ad" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-192feb6 elementor-column elementor-col-100 elementor-top-column" data-id="192feb6" data-element_type="column">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 
					 
					 <div class="container">
		<div class="row">
			<div style=" margin-bottom: 33px;" class="testimonial">
				<h2>TESTIMONIAL</h2>
			</div>
		</div>
		
		<div id="swiper-container4" class="swiper-container">
          <div class="swiper-wrapper">
   
			<div class="swiper-slide">
				<div class="border-box">
					<ul>
						<li><img src="img/one.png"></li>
						<li><p>"This is to express our appreciation for the innovation, skills, involvement and technical competencies exhibited by Galio team in co-creating and developing accessories like Chrome add-ons, Rain Visors and LED Scuff Plates for our Global SUV Mahindra XUV-500. Given the turnaround time and perfection aimed in achieving tight tolerance Galio's team have proven to be a great partner in earning the customer appreciation the product have received from the market."</p></li>
						<li><img src="img/line.png" class="line"></li>
						<li><h4 class="name">ARIF RIZWY</h4></li>
						<li class="post">DGM Business Development - Automotive Division, Mahindra and Mahindra limited</p></li>
					</ul>
				</div>
			</div>
			
		
            <div class="swiper-slide">
				<div class="border-box">
					<ul>
						<li><img src="img/one.png"></li>
						<li><p>"I would like to mention that I have seen Galio as an organization comes a long way from where it started. It has become possible only due to the dedicated efforts of the team members and promoters. The processes &amp; quality standards are truly world class now."</p></li>
						<li><img src="img/line.png" class="line"></li>
						<li><h4 class="name">PANKAJ CHANDAK</h4></li>
						<li class="post">AVP - Parts and Services, Fiat India Automobile Limited</p></li>
					</ul>
				</div>
			</div>

			<div class="swiper-slide">
				<div class="border-box">
					<ul>
						<li><img src="img/one.png"></li>
						<li><p>A Technically strong and growing organization with commitment.</p></li>
						<li><img src="img/line.png" class="line"></li>
						<li><h4 class="name">R. S KAPOOR</h4></li>
						<li class="post">GM — Accessories, Maruti Suzuki (INDIA) Ltd</p></li>
					</ul>
				</div>
			</div>

			<div class="swiper-slide">
				<div class="border-box">
					<ul>
						<li><img src="img/one.png"></li>
						<li><p>"Our experience with Galio has been very good. We find them innovative and full of enthusiasm, with a great passion for Car Accessories. They have tremendous amount of initiative and have always met deadlines and honoured commitments."</p></li>
						<li><img src="img/line.png" class="line"></li>
						<li><h4 class="name">RAJIV MADHAVAN</h4></li>
						<li class="post">Head — Accessories, Tata Motors</p></li>
					</ul>
				</div>
			</div>


    
    </div>
    
    <!-- Add Pagination -->
      <div class="swiper-pagination1"></div>
    <!-- Add Arrows -->
    <div class="swiper-button-next1"></div>
    <div class="swiper-button-prev1"></div>
 
  </div>
	

	
	
				 <div class="elementor-element elementor-element-9a62c40 eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="9a62c40" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				 <div class="elementor-widget-container">
					 <div class="eael-dual-header">
		 <h2 class="title"><span class="lead">contact us </span>  <span></span></h2>
	    <span class="subtext"></span>
	   	 </div>
	
	
	
	
			 </div>
				 </div>
						 </div>
			 </div>
		 </div>
						 </div>
			 </div>
		 </section>
				 <section class="has_eae_slider elementor-element elementor-element-7596277 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="7596277" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						 <div class="elementor-container elementor-column-gap-default">
				 <div class="elementor-row">
				 <div class="has_eae_slider elementor-element elementor-element-26a2780 elementor-column elementor-col-50 elementor-top-column" data-id="26a2780" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-2ac14ce elementor-view-default elementor-widget elementor-widget-icon" data-id="2ac14ce" data-element_type="widget" data-widget_type="icon.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-icon-wrapper">
			 <div class="elementor-icon">
			<img src="img/map.png" class="img-responsive">			 </div>
		 </div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-f4e143c elementor-widget elementor-widget-heading" data-id="f4e143c" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h2 class="elementor-heading-title elementor-size-default">Galio Graphics </h2>		 </div>
				 </div>
				 <div class="elementor-element elementor-element-290de63 elementor-widget elementor-widget-text-editor" data-id="290de63" data-element_type="widget" data-widget_type="text-editor.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-text-editor elementor-clearfix"><p>
					 16/21/3 Mangolpur kalan Pocket 4 ,Sector 2, Rohini, New Delhi, 110085 </p></div>
				 </div>
				 </div>
				 <div class="elementor-element elementor-element-bc3ea4d elementor-shape-circle elementor-widget elementor-widget-social-icons" data-id="bc3ea4d" data-element_type="widget" data-widget_type="social-icons.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-social-icons-wrapper">
							 <a href="#" class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-animation-wobble-to-top-right elementor-repeater-item-a8d255a" target="_blank">
					 <span class="elementor-screen-only">Facebook </span>
					 <img src="img/facebook.png" class="img-responsive">			 </a>
							 <a href="#" class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-wobble-to-top-right elementor-repeater-item-40d7e8a" target="_blank">
					 <span class="elementor-screen-only">Twitter </span>
					<img src="img/twitter.png" class="img-responsive">				 </a>
							 <a href="#" class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-animation-wobble-to-top-right elementor-repeater-item-5059ff7" target="_blank">
					 <span class="elementor-screen-only">Youtube </span>
					 <img src="img/youtube.png" class="img-responsive">				 </a>
							 <a href="#" class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-animation-wobble-to-top-right elementor-repeater-item-d8fab72" target="_blank">
					 <span class="elementor-screen-only">Linkedin </span>
					 <img src="img/in.png" class="img-responsive">			 </a>
					 </div>
				 </div>
				 </div>
						 </div>
			 </div>
		 </div>
				 <div class="has_eae_slider elementor-element elementor-element-4949294 elementor-column elementor-col-50 elementor-top-column" data-id="4949294" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			 <div class="elementor-column-wrap  elementor-element-populated">
					 <div class="elementor-widget-wrap">
				 <div class="elementor-element elementor-element-bb5c592 elementor-widget elementor-widget-heading" data-id="bb5c592" data-element_type="widget" data-widget_type="heading.default">
				 <div class="elementor-widget-container">
			 <h2 class="elementor-heading-title elementor-size-default">Send us a message </h2>		 </div>
				 </div>
				 <div class="elementor-element elementor-element-ca8f9ab elementor-widget elementor-widget-shortcode" data-id="ca8f9ab" data-element_type="widget" data-widget_type="shortcode.default">
				 <div class="elementor-widget-container">
					 <div class="elementor-shortcode"><div role="form" class="wpcf7" id="wpcf7-f131-p6-o3" lang="en-US" dir="ltr">
 <div class="screen-reader-response"></div>
 <form action="#" method="post" id="popup-form" onsubmit="return false;" class="wpcf7-form" novalidate="novalidate">
 <div class="clearfix">
 <div id="land-fot-left">
First Name  <span class="wpcf7-form-control-wrap first-name">
<input type="text" name="first-name" value="" size="40" class="wpcf7-form-control wpcf7-text"  required />
</span><br />
Email  <span class="wpcf7-form-control-wrap your-email">
<input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" required /></span>
 </div>
 <div id="land-fot-right">
Last Name <span class="wpcf7-form-control-wrap last-name"><input type="text" name="last-name" value="" size="40" class="wpcf7-form-control wpcf7-text"  required /></span>  <p />
 <p>Phone  <span class="wpcf7-form-control-wrap your-phone"><input type="text" name=phone" value="" size="40" class="wpcf7-form-control wpcf7-text"  required /></span>
 </p></div>
 </div>
 <div id="textra-fnt">
Message  <span class="wpcf7-form-control-wrap your-message"><textarea name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required" required></textarea></span>
 </div>
 <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit"  id="popup-land" /></p>
 <div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
				 </div>
				 </div>
			 </div>
			 </div>
			 </div>
			</div>
			 </div>
			 </section>
			 </div>
			 </div>
		 </div>
<script  src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
window.lazySizesConfig = window.lazySizesConfig || {};

window.lazySizesConfig.lazyClass    = 'lazyload';
window.lazySizesConfig.loadingClass = 'lazyloading';
window.lazySizesConfig.loadedClass  = 'lazyloaded';

lazySizesConfig.loadMode = 1;
</script>
<script src="https://demo.opencart.com/catalog/view/javascript/jquery/swiper/js/swiper.jquery.js"></script>
 <script src='js/smush-lazy-load.min_e0220265.js'></script>
 
 <script>
lazySizes.init();
</script>
 <script>
$('#swiper-container').swiper({
	mode: 'horizontal',
	slidesPerView: 5,
	pagination: '.carousel0',
	paginationClickable: true,
	nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
	autoplay: 2500,
	loop: true
});
$('#swiper-container1').swiper({
	mode: 'horizontal',
	slidesPerView: 3,
	pagination: '.carousel0',
	paginationClickable: true,
	nextButton: '.elementor-screen-only',
    prevButton: '.elementor-screen-only',
	autoplay: 1500,
	loop: true
});

$('#swiper-container2').swiper({
	mode: 'horizontal',
	slidesPerView: 2,
	pagination: '.carousel0',
	paginationClickable: true,
	autoplay: 2000,
	loop: true
});


$('#swiper-container4').swiper({
   	mode: 'horizontal',
	slidesPerView: 3,
	pagination: '.carousel0',
	paginationClickable: true,
	autoplay: 1000,
	loop: true
});
    
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
  <script>
      $('#send-land').click(function(){
          
          if($('#enquiry-form').valid()){
                  $('#send-land').val("loading");
              
              $.post('https://www.galioindia.com/mail.php',$('#enquiry-form').serializeArray(),function(res){
                  alert(res);
                   $('#send-land').val("send");
                    $('#enquiry-form')[0].reset();
                    
                  
              });
              
          }
      });
       $('#popup-land').click(function(){
          
          if($('#popup-form').valid()){
                  $('#popup-land').val("loading");
              
              $.post('https://www.galioindia.com/mail.php',$('#enquiry-form').serializeArray(),function(res){
                  alert(res);
                   $('#popup-land').val("send");
                    $('#popup-form')[0].reset();
                    
                  
              });
              
          }
      });
  </script>

	 </body>
 </html>
 