<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from www.digifuels.com/Galio/loss-calculator/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 28 Feb 2020 17:26:22 GMT -->
<!-- Added by HTTrack --><!-- /Added by HTTrack -->
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
		<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>
<title>Loss Calculator &#8211; Galio</title>
<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link href='https://fonts.gstatic.com/' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="Galio &raquo; Feed" href="http://www.digifuels.com/Galio/feed/" />
<link rel="alternate" type="application/rss+xml" title="Galio &raquo; Comments Feed" href="http://www.digifuels.com/Galio/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.digifuels.com\/Galio\/clc3\/js\/wp-emoji-release.min.js?ver=5.3.2"}};
			!function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='clc3/css/dist/block-library/style.min9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='clc3/css/dist/block-library/theme.min9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='eae-css-css'  href='clc2/plugins/addon-elements-for-elementor-page-builder/assets/css/eae.min9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css'  href='clc2/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css'  href='clc2/plugins/elementor/assets/lib/font-awesome/css/all.min9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='vegas-css-css'  href='clc2/plugins/addon-elements-for-elementor-page-builder/assets/lib/vegas/vegas.min9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='clc2/plugins/contact-form-7/includes/css/stylesb62d.css?ver=5.1.6' media='all' />
<link rel='stylesheet' id='eael-front-end-css'  href='clc2/uploads/essential-addons-elementor/eael-post-214.min7e5c.css?ver=1582910782' media='all' />
<link rel='stylesheet' id='twentyseventeen-fonts-css'  href='https://fonts.googleapis.com/css?family=Libre+Franklin%3A300%2C300i%2C400%2C400i%2C600%2C600i%2C800%2C800i&amp;subset=latin%2Clatin-ext&amp;display=fallback' media='all' />
<link rel='stylesheet' id='twentyseventeen-style-css'  href='clc2/themes/twentyseventeen/style8d89.css?ver=20190507' media='all' />
<link rel='stylesheet' id='twentyseventeen-block-style-css'  href='clc2/themes/twentyseventeen/assets/css/blocksfbfa.css?ver=20190105' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='twentyseventeen-ie8-css'  href='http://www.digifuels.com/Galio/clc2/themes/twentyseventeen/assets/css/ie8.css?ver=20161202' media='all' />
<![endif]-->
<link rel='stylesheet' id='elementskit-framework-css-frontend-css'  href='clc2/plugins/elementskit-lite/libs/framework/assets/css/frontend-style9dff.css?ver=5.3.2' media='all' />
<link rel='stylesheet' id='cf-front-css'  href='clc2/plugins/caldera-forms/assets/build/css/caldera-forms-front.min10f0.css?ver=1.8.6' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='clc2/plugins/elementor/assets/lib/eicons/css/elementor-icons.mindeba.css?ver=5.5.0' media='all' />
<link rel='stylesheet' id='elementor-animations-css'  href='clc2/plugins/elementor/assets/lib/animations/animations.min42e1.css?ver=2.8.5' media='all' />
<link rel='stylesheet' id='elementor-frontend-css'  href='clc2/plugins/elementor/assets/css/frontend.min42e1.css?ver=2.8.5' media='all' />
<link rel='stylesheet' id='elementskit-css-widgetarea-control-editor-css'  href='clc2/plugins/elementskit-lite/modules/controls/assets/css/widgetarea-editor8a54.css?ver=1.0.0' media='all' />
<link rel='stylesheet' id='elementor-global-css'  href='clc2/uploads/elementor/css/globalb29e.css?ver=1580714214' media='all' />
<link rel='stylesheet' id='elementor-post-214-css'  href='clc2/uploads/elementor/css/post-2144ed0.css?ver=1582781904' media='all' />
<link rel='stylesheet' id='elementskit-vendors-css'  href='clc2/plugins/elementskit-lite/widgets/init/assets/css/vendors370e.css?ver=1.4.3' media='all' />
<link rel='stylesheet' id='elementskit-style-css'  href='clc2/plugins/elementskit-lite/widgets/init/assets/css/style370e.css?ver=1.4.3' media='all' />
<link rel='stylesheet' id='elementskit-responsive-css'  href='clc2/plugins/elementskit-lite/widgets/init/assets/css/responsive370e.css?ver=1.4.3' media='all' />
<link rel='stylesheet' id='google-fonts-1-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic%7CRoboto+Slab%3A100%2C100italic%2C200%2C200italic%2C300%2C300italic%2C400%2C400italic%2C500%2C500italic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2C900%2C900italic&amp;ver=5.3.2' media='all' />
<link rel='stylesheet' id='elementor-icons-shared-0-css'  href='clc2/plugins/elementor/assets/lib/font-awesome/css/fontawesome.minad76.css?ver=5.9.0' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-solid-css'  href='clc2/plugins/elementor/assets/lib/font-awesome/css/solid.minad76.css?ver=5.9.0' media='all' />
<link rel='stylesheet' id='elementor-icons-fa-brands-css'  href='clc2/plugins/elementor/assets/lib/font-awesome/css/brands.minad76.css?ver=5.9.0' media='all' />
<script src='clc3/js/jquery/jquery4a5f.js?ver=1.12.4-wp'></script>
<script src='clc3/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script src='clc2/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min9dff.js?ver=5.3.2'></script>
<script src="https://use.fontawesome.com/733d15a356.js"></script>

				<style>
			.no-js img.lazyload { display: none; }
			figure.wp-block-image img.lazyloading { min-width: 150px; }
							.lazyload, .lazyloading { opacity: 0; }
				.lazyloaded {
					opacity: 1;
					transition: opacity 400ms;
					transition-delay: 0ms;
				}
					</style>
		<style>.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>		<style id="wp-custom-css">
			/* form */
#land-form {
    height: 32px;
    background: #efefef;
}

#land-form-textt {
    height: 100px;
    background: #efefef;
}

#send-land {
    background: #f37435;
	width: 100%;}

label {
    color: #f1eded;
    display: block;
    font-weight: 600;
	font-size: 15px;
    
}


/* form */
input#fld_3679030_1 {
    display: none;
}
h4.top-space {
    margin-top:37px;
}
input#fld_3679030_2 {
    display: none;
}
.margin {
    margin-bottom: 22px;
    margin-top: 11px;
}
.dealer-margin {
    margin: 0px 0 14px 0px;
}
@media screen and (min-width: 30em){
h4 {
    font-size: 15px!important;
   
	}}
/*--- 2 Column Form Styles Start ---*/

#land-fot-left {
       width: 48%;
    float: left;
    color: #373435;
    font-weight: 600;
    font-size: 15px;
    margin-right: 25px;
    
}
#land-fot-form {
	margin: 0;
height: 32px;
background: #e8e8e8;}
 
#land-fot-right {
   width: 50%;
    float: left;
	    color: #373435;
    font-weight: 600;
    font-size: 15px
}
#land-fot-form-texter{    margin: 0;
    width: 100%;
    height: 120px;
    background: #e8e8e8;}

#textra-fnt{
    color: #373435;
    font-weight: 600;
    font-size: 15px;
}
#land-fot-send {
        margin-top: 20px;
    width: 25%;
    background-color: #f37435;
    color: #ffffff;
    float: right;}
 
.clearfix:after {
    content:"\0020";
    display:block;
    height:0;
    clear:both;
    visibility:hidden;
    overflow:hidden;
    margin-bottom:10px;
}
 
.clearfix {
    display:flex;
}

.custmoth {
    width: 100%;
    height: 34px;
    padding: 6px 12px;
    background-color: #fff;
    border: 1px solid #ccc;
	    color: #555;
    font-size: 14px;
}
input#fld_8415793_1:disabled {
  background: #dddddd;
}

input#fld_3617938_1 {
    display: none;
}
input#fld_6948440_1 {
    display: none;
}
input#fld_8967165_2 {
    display: none;
}
input#fld_5320349_2 {
    display: none;
}
/*--- 2 Column Form Styles End ---*/

/* mobile */

@media screen and (max-width: 30em) {
  div#CF5e2e915c30876_1-row-1 {
    display: flex;
}
	div#CF5e2fe1af6c7ef_2-row-1 {
    display: flex;
}
	h4 {
    font-size: 13px;
}
	.margin {
    margin: 0;
	}
	.caldera-grid .form-control {
  
		height: 20px;}
	div#fld_7244656_2-wrap {
    margin-bottom: 25px;
}
div#fld_2276710_2-wrap {
    margin-bottom: 40px;
}
div#fld_3451674_2-wrap {
    margin-bottom: 37px;
}
div#fld_1736763_2-wrap {
    margin-bottom: 25px;
}
div#fld_2589489_2-wrap {
    margin-bottom: 40px;
}
div#fld_6935725_2-wrap {
    margin-bottom: 37px;
}
	div#fld_8415793_2-wrap {
    margin-bottom: 25px;
}
	div#fld_8266223_2-wrap {
    margin-bottom: 25px;
}
	h4.total-line {
    margin: 36px 0;
}
	.custmoth {
        height: 20px;
		padding: 0 12px;}
}
h4.top-space {
    margin-top: 15px;
}
/* mobile */

.elementskit-client_logo {
    display: none!important;
}

#popup-land {
    margin-top: 20px;
    width: 25%;
    background-color: #f37435;
    color: #ffffff;
    float: right;
}
		</style>
			<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" /></head>
<body class="page-template page-template-elementor_canvas page page-id-214 wp-embed-responsive has-header-image page-two-column colors-light elementor-default elementor-template-canvas elementor-page elementor-page-214">
			<div data-elementor-type="wp-page" data-elementor-id="214" class="elementor elementor-214" data-elementor-settings="[]">
			<div class="elementor-inner">
				<div class="elementor-section-wrap">
							<section class="has_eae_slider elementor-element elementor-element-f606e6e elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="f606e6e" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-60a21d2 elementor-column elementor-col-50 elementor-top-column" data-id="60a21d2" 
				data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-bcb46a5 elementor-widget elementor-widget-image" data-id="bcb46a5" 
				data-element_type="widget" data-widget_type="image.default">
				<div class="elementor-widget-container">
					<div class="elementor-image">
										<img width="525" height="330"   sizes="100vw" src="calc1/images/images.png" />											</div>
				</div>
				</div>
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-a6ffbef elementor-column elementor-col-50 elementor-top-column"
				data-id="a6ffbef" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-2836386 elementor-align-right elementor-icon-list--layout-traditional elementor-widget
				elementor-widget-icon-list" data-id="2836386" data-element_type="widget" data-widget_type="icon-list.default">
				<div class="elementor-widget-container">
					<ul class="elementor-icon-list-items">
							<li class="elementor-icon-list-item" >
					<a href="tel:+91 8588050007 ">						<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fa fa-phone"></i>						</span>
										<span class="elementor-icon-list-text">+91 8588050007 </span>
											</a>
									</li>
								<li class="elementor-icon-list-item" >
											<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fa fa-envelope"></i>						</span>
										<span class="elementor-icon-list-text">info@galioindia.com</span>
									</li>
						</ul>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section class="has_eae_slider elementor-element elementor-element-6bd30e0 elementor-section-stretched elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle elementor-section elementor-top-section" data-id="6bd30e0" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-9396ed6 elementor-column elementor-col-33 elementor-top-column" data-id="9396ed6" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-c0ef606 eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="c0ef606" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				<div class="elementor-widget-container">
					<div class="eael-dual-header">
		<h2 class="title"><span class="lead">Distributor</span> <span> Model</span></h2>
	   <span class="subtext"></span>
	   	</div>
	
	
	
	
			</div>
				</div>
				<section class="has_eae_slider elementor-element elementor-element-b8de90e elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="b8de90e" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-7b2f289 elementor-column elementor-col-33 elementor-inner-column" data-id="7b2f289" data-element_type="column">
			<div class="elementor-column-wrap">
					<div class="elementor-widget-wrap">
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-1ca30e2 elementor-column elementor-col-33 elementor-inner-column" data-id="1ca30e2" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-5b06303 elementor-widget elementor-widget-heading" data-id="5b06303" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Galio</h2>		</div>
				</div>
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-7d173e6 elementor-column elementor-col-33 elementor-inner-column" data-id="7d173e6" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-108494f elementor-widget elementor-widget-heading" data-id="108494f" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Other Brands</h2>		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section class="has_eae_slider elementor-element elementor-element-6c6c32f elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="6c6c32f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-a890880 elementor-column elementor-col-100 elementor-inner-column" data-id="a890880" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-de23da3 elementor-widget elementor-widget-shortcode" data-id="de23da3" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode"><div class="caldera-grid" id="caldera_form_1" data-cf-ver="1.8.6" data-cf-form-id="CF5e2e915c30876"><div id="caldera_notices_1" data-spinner="http://www.digifuels.com/Galio/clc1/images/spinner.gif"></div><form data-instance="1" class="CF5e2e915c30876 caldera_forms_form cfajax-trigger" method="POST" enctype="multipart/form-data" id="CF5e2e915c30876_1" data-form-id="CF5e2e915c30876" aria-label="Distributor Galio" data-target="#caldera_notices_1" data-template="#cfajax_CF5e2e915c30876-tmpl" data-cfajax="CF5e2e915c30876" data-load-element="_parent" data-load-class="cf_processing" data-post-disable="0" data-action="cf_process_ajax_submit" data-request="http://www.digifuels.com/Galio/cf-api/CF5e2e915c30876" data-hiderows="true">
<input type="hidden" id="_cf_verify_CF5e2e915c30876" name="_cf_verify" value="af8351c118"  data-nonce-time="1582910783" /><input type="hidden" name="_wp_http_referer" value="/Galio/loss-calculator/" /><div id="cf2-CF5e2e915c30876_1"></div><input type="hidden" name="_cf_frm_id" value="CF5e2e915c30876">
<input type="hidden" name="_cf_frm_ct" value="1">
<input type="hidden" name="cfajax" value="CF5e2e915c30876">
<input type="hidden" name="_cf_cr_pst" value="214">
<div class="hide" style="display:none; overflow:hidden;height:0;width:0;">
<label>Phone</label><input type="text" name="phone" value="" autocomplete="off">
</div><div id="CF5e2e915c30876_1-row-1"  class="row  single"><div  class="col-sm-6  first_col"><div class="margin"><h4>No of retailers handled monthly</h4>
</div><div class="margin"><h4>Average sales done with retailers<br />
</h4>
</div><div class="margin"><h4>Total Sales<br />
</h4>
</div><div class="margin"><h4>Average profit on sales (Discount on product Vs. Sales price) %<br />
</h4>
</div><div class="margin"><h4>Profit Earned<br />
</h4>
</div><div class="margin"><h4>Profit / Loss monthly<br />
</h4>
</div></div><div  class="col-sm-3 "><div data-field-wrapper="fld_7244656" class="form-group" id="fld_7244656_1-wrap">
	<label id="fld_7244656Label" for="fld_7244656_1" class="control-label screen-reader-text sr-only">5</label>
	<div class="">
		<input placeholder="5"   type="number" data-field="fld_7244656" class=" form-control" id="fld_7244656_1" name="fld_7244656" value="5" data-type="number" data-parsley-type="number"   aria-labelledby="fld_7244656Label" >			</div>
</div>
<div data-field-wrapper="fld_2276710" class="form-group" id="fld_2276710_1-wrap">
	<label id="fld_2276710Label" for="fld_2276710_1" class="control-label screen-reader-text sr-only">15000</label>
	<div class="">
		<input placeholder="15000"   type="number" data-field="fld_2276710" class=" form-control" id="fld_2276710_1" name="fld_2276710" value="15000" data-type="number" data-parsley-type="number"   aria-labelledby="fld_2276710Label" >			</div>
</div>
<div data-field-wrapper="fld_3451674" class="form-group" id="fld_3451674_1-wrap">
	<label id="fld_3451674Label" for="fld_3451674_1" class="control-label screen-reader-text sr-only">to</label>
	<div class="">
		<h4 aria-labelledby="fld_3451674Label" class="total-line">			<span id="fld_3451674_1" data-calc-display="fld_3451674_1-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_3451674" value="0" data-field="fld_3451674_1" data-calc-field="fld_3451674" data-type="calculation" id="fld_3451674_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8415793" class="form-group" id="fld_8415793_1-wrap">
	<label id="fld_8415793Label" for="fld_8415793_1" class="control-label screen-reader-text sr-only">10</label>
	<div class="">
		<div aria-labelledby="fld_8415793Label" class="custmoth">			<span id="fld_8415793_1" data-calc-display="fld_8415793_1-value"></span></div>
				<input type="hidden" type="hidden" name="fld_8415793" value="0" data-field="fld_8415793_1" data-calc-field="fld_8415793" data-type="calculation" id="fld_8415793_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_7620420" class="form-group" id="fld_7620420_1-wrap">
	<label id="fld_7620420Label" for="fld_7620420_1" class="control-label screen-reader-text sr-only">proj</label>
	<div class="">
		<h4 aria-labelledby="fld_7620420Label" class="top-space">			<span id="fld_7620420_1" data-calc-display="fld_7620420_1-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_7620420" value="0" data-field="fld_7620420_1" data-calc-field="fld_7620420" data-type="calculation" id="fld_7620420_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_3617938" class="form-group" id="fld_3617938_1-wrap">
	<label id="fld_3617938Label" for="fld_3617938_1" class="control-label screen-reader-text sr-only">20</label>
	<div class="">
		<input placeholder="20"   type="number" data-field="fld_3617938" class=" form-control" id="fld_3617938_1" name="fld_3617938" value="20" data-type="number" data-parsley-type="number"   aria-labelledby="fld_3617938Label" >			</div>
</div>
</div><div  class="col-sm-3  last_col"><div data-field-wrapper="fld_1736763" class="form-group" id="fld_1736763_1-wrap">
	<label id="fld_1736763Label" for="fld_1736763_1" class="control-label screen-reader-text sr-only">5-cpy</label>
	<div class="">
		<div aria-labelledby="fld_1736763Label" class="custmoth">			<span id="fld_1736763_1" data-calc-display="fld_1736763_1-value"></span></div>
				<input type="hidden" type="hidden" name="fld_1736763" value="0" data-field="fld_1736763_1" data-calc-field="fld_1736763" data-type="calculation" id="fld_1736763_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_2739966" class="form-group" id="fld_2739966_1-wrap">
	<label id="fld_2739966Label" for="fld_2739966_1" class="control-label screen-reader-text sr-only">15000_cpy</label>
	<div class="">
		<div aria-labelledby="fld_2739966Label" class="custmoth">			<span id="fld_2739966_1" data-calc-display="fld_2739966_1-value"></span></div>
				<input type="hidden" type="hidden" name="fld_2739966" value="0" data-field="fld_2739966_1" data-calc-field="fld_2739966" data-type="calculation" id="fld_2739966_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_6935725" class="form-group" id="fld_6935725_1-wrap">
	<label id="fld_6935725Label" for="fld_6935725_1" class="control-label screen-reader-text sr-only">to-cpy</label>
	<div class="">
		<h4 aria-labelledby="fld_6935725Label" class="total-line">			<span id="fld_6935725_1" data-calc-display="fld_6935725_1-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_6935725" value="0" data-field="fld_6935725_1" data-calc-field="fld_6935725" data-type="calculation" id="fld_6935725_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8266223" class="form-group custmoth" id="fld_8266223_1-wrap">
	<label id="fld_8266223Label" for="fld_8266223_1" class="control-label screen-reader-text sr-only">5%-cpy</label>
	<div class="">
		<div aria-labelledby="fld_8266223Label" class="">			<span id="fld_8266223_1" data-calc-display="fld_8266223_1-value"></span></div>
				<input type="hidden" type="hidden" name="fld_8266223" value="0" data-field="fld_8266223_1" data-calc-field="fld_8266223" data-type="calculation" id="fld_8266223_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_3679030" class="form-group" id="fld_3679030_1-wrap">
	<label id="fld_3679030Label" for="fld_3679030_1" class="control-label screen-reader-text sr-only">100%</label>
	<div class="">
		<input placeholder="100%"   type="number" data-field="fld_3679030" class=" form-control" id="fld_3679030_1" name="fld_3679030" value="100" data-type="number" data-parsley-type="number"   aria-labelledby="fld_3679030Label" >			</div>
</div>
<div data-field-wrapper="fld_5465779" class="form-group" id="fld_5465779_1-wrap">
	<label id="fld_5465779Label" for="fld_5465779_1" class="control-label screen-reader-text sr-only">proj</label>
	<div class="">
		<h4 aria-labelledby="fld_5465779Label" class="top-space">			<span id="fld_5465779_1" data-calc-display="fld_5465779_1-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_5465779" value="0" data-field="fld_5465779_1" data-calc-field="fld_5465779" data-type="calculation" id="fld_5465779_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8389721" class="form-group" id="fld_8389721_1-wrap">
	<label id="fld_8389721Label" for="fld_8389721_1" class="control-label screen-reader-text sr-only">profit</label>
	<div class="">
		<h4 aria-labelledby="fld_8389721Label" class="">			<span id="fld_8389721_1" data-calc-display="fld_8389721_1-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_8389721" value="0" data-field="fld_8389721_1" data-calc-field="fld_8389721" data-type="calculation" id="fld_8389721_1-value"  >
			</div>
</div>
<div data-field-wrapper="fld_6948440" class="form-group" id="fld_6948440_1-wrap">
	<label id="fld_6948440Label" for="fld_6948440_1" class="control-label screen-reader-text sr-only">7%-cpy</label>
	<div class="">
		<input placeholder="7%-cpy"   type="number" data-field="fld_6948440" class=" form-control" id="fld_6948440_1" name="fld_6948440" value="7" data-type="number" data-parsley-type="number"   aria-labelledby="fld_6948440Label" >			</div>
</div>
</div></div></form>
</div>
</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-0634ec9 elementor-column elementor-col-33 elementor-top-column" data-id="0634ec9" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-046619c elementor-widget elementor-widget-spacer" data-id="046619c" data-element_type="widget" data-widget_type="spacer.default">
				<div class="elementor-widget-container">
					<div class="elementor-spacer">
			<div class="elementor-spacer-inner"></div>
		</div>
				</div>
				</div>
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-87a34ca elementor-column elementor-col-33 elementor-top-column" data-id="87a34ca" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-43d1994 eael-dual-header-content-align-center elementor-widget elementor-widget-eael-dual-color-header" data-id="43d1994" data-element_type="widget" data-widget_type="eael-dual-color-header.default">
				<div class="elementor-widget-container">
					<div class="eael-dual-header">
		<h2 class="title"><span class="lead">Dealer</span> <span> Model	</span></h2>
	   <span class="subtext"></span>
	   	</div>
	
	
	
	
			</div>
				</div>
				<section class="has_eae_slider elementor-element elementor-element-eca9cd9 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="eca9cd9" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-d19450c elementor-column elementor-col-33 elementor-inner-column" data-id="d19450c" data-element_type="column">
			<div class="elementor-column-wrap">
					<div class="elementor-widget-wrap">
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-8a3d036 elementor-column elementor-col-33 elementor-inner-column" data-id="8a3d036" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-401a583 elementor-widget elementor-widget-heading" data-id="401a583" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Galio</h2>		</div>
				</div>
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-445e051 elementor-column elementor-col-33 elementor-inner-column" data-id="445e051" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-5f7f04b elementor-widget elementor-widget-heading" data-id="5f7f04b" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Other Brands</h2>		</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<div class="elementor-element elementor-element-bf7acec elementor-widget elementor-widget-shortcode" data-id="bf7acec" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode"><div class="caldera-grid" id="caldera_form_2" data-cf-ver="1.8.6" data-cf-form-id="CF5e2fe1af6c7ef"><div id="caldera_notices_2" data-spinner="clc1/images/spinner.gif"></div><form data-instance="2" class="CF5e2fe1af6c7ef caldera_forms_form cfajax-trigger" method="POST" enctype="multipart/form-data" id="CF5e2fe1af6c7ef_2" data-form-id="CF5e2fe1af6c7ef" aria-label="Dealer galio" data-target="#caldera_notices_2" data-template="#cfajax_CF5e2fe1af6c7ef-tmpl" data-cfajax="CF5e2fe1af6c7ef" data-load-element="_parent" data-load-class="cf_processing" data-post-disable="0" data-action="cf_process_ajax_submit" data-request="http://www.digifuels.com/Galio/cf-api/CF5e2fe1af6c7ef" data-hiderows="true">
<input type="hidden" id="_cf_verify_CF5e2fe1af6c7ef" name="_cf_verify" value="7c9392fd90"  data-nonce-time="1582910783" /><input type="hidden" name="_wp_http_referer" value="/Galio/loss-calculator/" /><div id="cf2-CF5e2fe1af6c7ef_2"></div><input type="hidden" name="_cf_frm_id" value="CF5e2fe1af6c7ef">
<input type="hidden" name="_cf_frm_ct" value="2">
<input type="hidden" name="cfajax" value="CF5e2fe1af6c7ef">
<input type="hidden" name="_cf_cr_pst" value="214">
<div class="hide" style="display:none; overflow:hidden;height:0;width:0;">
<label>Email</label><input type="text" name="email" value="" autocomplete="off">
</div><div id="CF5e2fe1af6c7ef_2-row-1"  class="row  single"><div  class="col-sm-6  first_col"><div class="dealer-margin"><h4>No of cars handled every monthly<br />
</h4>
</div><div class="dealer-margin"><h4>Average work on cars (Galio equiavalent range)</p>
</h4>
</div><div class="dealer-margin"><h4>Total Sales<br />
</h4>
</div><div class="dealer-margin"><h4>Average profit on range (Discount offered on MRP)<br />
 %<br />
</h4>
</div><div class="dealer-margin"><h4>Profit Earned<br />
</h4>
</div><div class="dealer-margin"><h4>Profit / Loss monthly<br />
</h4>
</div></div><div  class="col-sm-3 "><div data-field-wrapper="fld_7244656" class="form-group" id="fld_7244656_2-wrap">
	<label id="fld_7244656Label" for="fld_7244656_2" class="control-label screen-reader-text sr-only">2</label>
	<div class="">
		<input placeholder="2"   type="number" data-field="fld_7244656" class=" form-control" id="fld_7244656_2" name="fld_7244656" value="2" data-type="number" data-parsley-type="number"   aria-labelledby="fld_7244656Label" >			</div>
</div>
<div data-field-wrapper="fld_2276710" class="form-group" id="fld_2276710_2-wrap">
	<label id="fld_2276710Label" for="fld_2276710_2" class="control-label screen-reader-text sr-only">8000</label>
	<div class="">
		<input placeholder="8000"   type="number" data-field="fld_2276710" class=" form-control" id="fld_2276710_2" name="fld_2276710" value="8000" data-type="number" data-parsley-type="number"   aria-labelledby="fld_2276710Label" >			</div>
</div>
<div data-field-wrapper="fld_3451674" class="form-group" id="fld_3451674_2-wrap">
	<label id="fld_3451674Label" for="fld_3451674_2" class="control-label screen-reader-text sr-only">to</label>
	<div class="">
		<h4 aria-labelledby="fld_3451674Label" class="total-line">			<span id="fld_3451674_2" data-calc-display="fld_3451674_2-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_3451674" value="0" data-field="fld_3451674_2" data-calc-field="fld_3451674" data-type="calculation" id="fld_3451674_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8415793" class="form-group" id="fld_8415793_2-wrap">
	<label id="fld_8415793Label" for="fld_8415793_2" class="control-label screen-reader-text sr-only">25%</label>
	<div class="">
		<div aria-labelledby="fld_8415793Label" class="custmoth">			<span id="fld_8415793_2" data-calc-display="fld_8415793_2-value"></span></div>
				<input type="hidden" type="hidden" name="fld_8415793" value="0" data-field="fld_8415793_2" data-calc-field="fld_8415793" data-type="calculation" id="fld_8415793_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_7620420" class="form-group" id="fld_7620420_2-wrap">
	<label id="fld_7620420Label" for="fld_7620420_2" class="control-label screen-reader-text sr-only">Profit Earned</label>
	<div class="">
		<h4 aria-labelledby="fld_7620420Label" class="top-space">			<span id="fld_7620420_2" data-calc-display="fld_7620420_2-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_7620420" value="0" data-field="fld_7620420_2" data-calc-field="fld_7620420" data-type="calculation" id="fld_7620420_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8967165" class="form-group" id="fld_8967165_2-wrap">
	<label id="fld_8967165Label" for="fld_8967165_2" class="control-label screen-reader-text sr-only">40%</label>
	<div class="">
		<input placeholder="40%"   type="number" data-field="fld_8967165" class=" form-control" id="fld_8967165_2" name="fld_8967165" value="40" data-type="number" data-parsley-type="number"   aria-labelledby="fld_8967165Label" >			</div>
</div>
</div><div  class="col-sm-3  last_col"><div data-field-wrapper="fld_1736763" class="form-group" id="fld_1736763_2-wrap">
	<label id="fld_1736763Label" for="fld_1736763_2" class="control-label screen-reader-text sr-only">2-oth</label>
	<div class="">
		<div aria-labelledby="fld_1736763Label" class="custmoth">			<span id="fld_1736763_2" data-calc-display="fld_1736763_2-value"></span></div>
				<input type="hidden" type="hidden" name="fld_1736763" value="0" data-field="fld_1736763_2" data-calc-field="fld_1736763" data-type="calculation" id="fld_1736763_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_2589489" class="form-group" id="fld_2589489_2-wrap">
	<label id="fld_2589489Label" for="fld_2589489_2" class="control-label screen-reader-text sr-only">8000-oth</label>
	<div class="">
		<div aria-labelledby="fld_2589489Label" class="custmoth">			<span id="fld_2589489_2" data-calc-display="fld_2589489_2-value"></span></div>
				<input type="hidden" type="hidden" name="fld_2589489" value="0" data-field="fld_2589489_2" data-calc-field="fld_2589489" data-type="calculation" id="fld_2589489_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_6935725" class="form-group" id="fld_6935725_2-wrap">
	<label id="fld_6935725Label" for="fld_6935725_2" class="control-label screen-reader-text sr-only">Total Sales -oth</label>
	<div class="">
		<h4 aria-labelledby="fld_6935725Label" class="total-line">			<span id="fld_6935725_2" data-calc-display="fld_6935725_2-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_6935725" value="0" data-field="fld_6935725_2" data-calc-field="fld_6935725" data-type="calculation" id="fld_6935725_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8266223" class="form-group" id="fld_8266223_2-wrap">
	<label id="fld_8266223Label" for="fld_8266223_2" class="control-label screen-reader-text sr-only">10%-oth</label>
	<div class="">
		<div aria-labelledby="fld_8266223Label" class="custmoth">			<span id="fld_8266223_2" data-calc-display="fld_8266223_2-value"></span></div>
				<input type="hidden" type="hidden" name="fld_8266223" value="0" data-field="fld_8266223_2" data-calc-field="fld_8266223" data-type="calculation" id="fld_8266223_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_3679030" class="form-group" id="fld_3679030_2-wrap">
	<label id="fld_3679030Label" for="fld_3679030_2" class="control-label screen-reader-text sr-only">100%</label>
	<div class="">
		<input placeholder="100%"   type="number" data-field="fld_3679030" class=" form-control" id="fld_3679030_2" name="fld_3679030" value="100" data-type="number" data-parsley-type="number"   aria-labelledby="fld_3679030Label" >			</div>
</div>
<div data-field-wrapper="fld_5465779" class="form-group" id="fld_5465779_2-wrap">
	<label id="fld_5465779Label" for="fld_5465779_2" class="control-label screen-reader-text sr-only">Profit Earned-oth</label>
	<div class="">
		<h4 aria-labelledby="fld_5465779Label" class="top-space">			<span id="fld_5465779_2" data-calc-display="fld_5465779_2-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_5465779" value="0" data-field="fld_5465779_2" data-calc-field="fld_5465779" data-type="calculation" id="fld_5465779_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_8389721" class="form-group" id="fld_8389721_2-wrap">
	<label id="fld_8389721Label" for="fld_8389721_2" class="control-label screen-reader-text sr-only">Profit / Loss-oth</label>
	<div class="">
		<h4 aria-labelledby="fld_8389721Label" class="">			<span id="fld_8389721_2" data-calc-display="fld_8389721_2-value"></span></h4>
				<input type="hidden" type="hidden" name="fld_8389721" value="0" data-field="fld_8389721_2" data-calc-field="fld_8389721" data-type="calculation" id="fld_8389721_2-value"  >
			</div>
</div>
<div data-field-wrapper="fld_5320349" class="form-group" id="fld_5320349_2-wrap">
	<label id="fld_5320349Label" for="fld_5320349_2" class="control-label screen-reader-text sr-only">20%-oth-demo</label>
	<div class="">
		<input placeholder="20%-oth-demo"   type="number" data-field="fld_5320349" class=" form-control" id="fld_5320349_2" name="fld_5320349" value="20" data-type="number" data-parsley-type="number"   aria-labelledby="fld_5320349Label" >			</div>
</div>
</div></div></form>
</div>
</div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
				<section class="has_eae_slider elementor-element elementor-element-f2a56b1 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="f2a56b1" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-1333c3c elementor-column elementor-col-100 elementor-top-column" data-id="1333c3c" data-element_type="column">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<section class="has_eae_slider elementor-element elementor-element-b9e4d47 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-inner-section" data-id="b9e4d47" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
				<div class="elementor-row">
				<div class="has_eae_slider elementor-element elementor-element-2af7d04 elementor-column elementor-col-50 elementor-inner-column" data-id="2af7d04" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-fd0e663 elementor-view-default elementor-widget elementor-widget-icon" data-id="fd0e663" data-element_type="widget" data-widget_type="icon.default">
				<div class="elementor-widget-container">
					<div class="elementor-icon-wrapper">
			<div class="elementor-icon">
			<img src="calc1/images/map.png">			</div>
		</div>
				</div>
				</div>
				<div class="elementor-element elementor-element-db9d1e1 elementor-widget elementor-widget-heading" data-id="db9d1e1" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Galio Graphics</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-579e002 elementor-widget elementor-widget-text-editor" data-id="579e002" data-element_type="widget" data-widget_type="text-editor.default">
				<div class="elementor-widget-container">
					<div class="elementor-text-editor elementor-clearfix"><p>16/21/3 Mangolpur kalan Pocket 4 ,Sector 2, Rohini, New Delhi, 110085</p></div>
				</div>
				</div>
				<div class="elementor-element elementor-element-f728527 elementor-shape-circle elementor-widget elementor-widget-social-icons" data-id="f728527" data-element_type="widget" data-widget_type="social-icons.default">
				<div class="elementor-widget-container">
					<div class="elementor-social-icons-wrapper">
							<a href="https://www.facebook.com/Galiographicsco" class="elementor-icon elementor-social-icon elementor-social-icon-facebook elementor-animation-wobble-to-top-right elementor-repeater-item-a8d255a" target="_blank">
					<span class="elementor-screen-only">Facebook</span>
					<img src="calc1/images/facebook.png">				</a>
							<a href="https://twitter.com/galio_graphics" class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-animation-wobble-to-top-right elementor-repeater-item-40d7e8a" target="_blank">
					<span class="elementor-screen-only">Twitter</span>
					<img src="calc1/images/twitter.png">				</a>
							<a href="https://www.youtube.com/channel/UClYp7VrU26K-__s2k-f1P5Q" class="elementor-icon elementor-social-icon elementor-social-icon-youtube elementor-animation-wobble-to-top-right elementor-repeater-item-5059ff7" target="_blank">
					<span class="elementor-screen-only">Youtube</span>
					<img src="calc1/images/youtube.png">				</a>
							<a href="https://www.linkedin.com/company/galio-india/" class="elementor-icon elementor-social-icon elementor-social-icon-linkedin elementor-animation-wobble-to-top-right elementor-repeater-item-d8fab72" target="_blank">
					<span class="elementor-screen-only">Linkedin</span>
				<img src="calc1/images/in.png">			</a>
					</div>
				</div>
				</div>
						</div>
			</div>
		</div>
				<div class="has_eae_slider elementor-element elementor-element-75c856f elementor-column elementor-col-50 elementor-inner-column" data-id="75c856f" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-column-wrap  elementor-element-populated">
					<div class="elementor-widget-wrap">
				<div class="elementor-element elementor-element-a3ed0b7 elementor-widget elementor-widget-heading" data-id="a3ed0b7" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h2 class="elementor-heading-title elementor-size-default">Send us a message</h2>		</div>
				</div>
				<div class="elementor-element elementor-element-4eb1a73 elementor-widget elementor-widget-shortcode" data-id="4eb1a73" data-element_type="widget" data-widget_type="shortcode.default">
				<div class="elementor-widget-container">
					<div class="elementor-shortcode"><div role="form" class="wpcf7" id="wpcf7-f131-p214-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="#" method="post" id="popup-form" onsubmit="return false;" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="131" />
<input type="hidden" name="_wpcf7_version" value="5.1.6" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f131-p214-o1" />
<input type="hidden" name="_wpcf7_container_post" value="214" />
</div>
<div class="clearfix">
<div id="land-fot-left">
First Name  <span class="wpcf7-form-control-wrap first-name">
<input type="text" name="first-name" value="" size="40" class="wpcf7-form-control wpcf7-text"  required />
</span><br />
Email  <span class="wpcf7-form-control-wrap your-email">
<input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" required /></span>
 </div>
 <div id="land-fot-right">
Last Name <span class="wpcf7-form-control-wrap last-name"><input type="text" name="last-name" value="" size="40" class="wpcf7-form-control wpcf7-text"  required /></span>  <p />
 <p>Phone  <span class="wpcf7-form-control-wrap your-phone"><input type="text" name=phone" value="" size="40" class="wpcf7-form-control wpcf7-text"  required /></span>
 </p></div>
 </div>
 <div id="textra-fnt">
Message  <span class="wpcf7-form-control-wrap your-message"><textarea name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required" required></textarea></span>
 </div>
 <p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit"  id="popup-land" /></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div></div>
				</div>
				</div>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
						</div>
			</div>
		</section>
						</div>
			</div>
		</div>
		<link rel='stylesheet' id='cf-render-css'  href='clc2/plugins/caldera-forms/clients/render/build/style.min82a7.css?h=1051794361&amp;ver=1.8.6' media='all' />

	</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>

$('#fld_1736763_1-value').val($('#fld_7244656_1').val());
$('#fld_1736763_1').text($('#fld_7244656_1').val());
$('#fld_2739966_1-value').val($('#fld_2276710_1').val());
$('#fld_2739966_1').text($('#fld_2276710_1').val());
$('#fld_3451674_1').text($('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_6935725_1').text($('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_8415793_1').text(20);
$('#fld_8415793').val(20);
$('#fld_8266223_1').text(7);
$('#fld_8266223').val(7);
$('#fld_7620420_1').text(20*$('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_7620420').val(20*$('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_5465779_1').text(7*$('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_5465779').val(7*$('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_8389721_1').text($('#fld_7620420_1').text()-$('#fld_5465779_1').text());
$('#fld_8389721').val($('#fld_7620420_1').text()-$('#fld_5465779_1').text());
$(document).ready(function(){
  $(":input").bind('keyup mouseup', function () {
   
   $('#fld_1736763_1-value').val($('#fld_7244656_1').val());
$('#fld_1736763_1').text($('#fld_7244656_1').val());
$('#fld_2739966_1-value').val($('#fld_2276710_1').val());
$('#fld_2739966_1').text($('#fld_2276710_1').val());
$('#fld_3451674_1').text($('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_6935725_1').text($('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_7620420_1').text(20*$('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_7620420').val(20*$('#fld_7244656_1').val()*$('#fld_2276710_1').val());
$('#fld_5465779_1').text(7*$('#fld_6935725_1').text());
$('#fld_8389721_1').text($('#fld_7620420_1').text()-$('#fld_5465779_1').text());
$('#fld_8389721').val($('#fld_7620420_1').text()-$('#fld_5465779_1').text());
  });
});
</script>
<!-- Dealer Calculator -->
<script>

$('#fld_1736763_2-value').val($('#fld_7244656_2').val());
$('#fld_1736763_2').text($('#fld_7244656_2').val());
$('#fld_2589489_2-value').val($('#fld_2276710_2').val());
$('#fld_2589489_2').text($('#fld_2276710_2').val());
$('#fld_3451674_2').text($('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_6935725_2').text($('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_8415793_2').text(20);
$('#fld_8415793').val(20);
$('#fld_8266223_2').text(7);
$('#fld_8266223').val(7);
$('#fld_7620420_2').text(20*$('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_7620420').val(20*$('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_5465779_2').text(7*$('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_5465779').val(7*$('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_8389721_2').text($('#fld_7620420_2').text()-$('#fld_5465779_2').text());
$('#fld_8389721').val($('#fld_7620420_2').text()-$('#fld_5465779_2').text());
$(document).ready(function(){
  $(":input").bind('keyup mouseup', function () {
   
   $('#fld_2736763_2-value').val($('#fld_7244656_2').val());
$('#fld_2736763_2').text($('#fld_7244656_2').val());
$('#fld_2739966_2-value').val($('#fld_2276710_2').val());
$('#fld_2739966_2').text($('#fld_2276710_2').val());
$('#fld_3451674_2').text($('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_6935725_2').text($('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_7620420_2').text(20*$('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_7620420').val(20*$('#fld_7244656_2').val()*$('#fld_2276710_2').val());
$('#fld_5465779_2').text(7*$('#fld_6935725_2').text());
$('#fld_8389721_2').text($('#fld_7620420_2').text()-$('#fld_5465779_2').text());
$('#fld_8389721').val($('#fld_7620420_2').text()-$('#fld_5465779_2').text());
  });
});
</script>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
  <script>
     
       $('#popup-land').click(function(){
          
          if($('#popup-form').valid()){
                  $('#popup-land').val("loading");
              
              $.post('https://www.galioindia.com/mail.php',$('#enquiry-form').serializeArray(),function(res){
                  alert(res);
                   $('#popup-land').val("send");
                    $('#popup-form')[0].reset();
                    
                  
              });
              
          }
      });
  </script>

</html>
