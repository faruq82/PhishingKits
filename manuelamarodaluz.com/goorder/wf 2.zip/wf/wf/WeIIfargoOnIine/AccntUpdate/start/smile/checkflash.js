document.writeln("<script language='VBScript' type='text/vbscript'>");
document.writeln("<!-- // Visual basic helper required to detect Flash Player ActiveX control version information -->");
document.writeln(" Function VBGetSwfVer(i) ");
document.writeln(" on error resume next ");
document.writeln(" Dim swControl, swVersion ");
document.writeln(" swVersion = 0 ");
document.writeln(' set swControl = CreateObject("ShockwaveFlash.ShockwaveFlash." + CStr(i)) ');
document.writeln(" if (IsObject(swControl)) then ");
document.writeln(' swVersion = swControl.GetVariable("$version")  ');
document.writeln(" end if  ");
document.writeln(" VBGetSwfVer = swVersion  ");
document.writeln(" End Function  ");
document.writeln("<\/script> ");
var jsVersion=1;
var isIE=(navigator.appVersion.indexOf("MSIE")!=-1)?true:false;
var isWin=(navigator.appVersion.toLowerCase().indexOf("win")!=-1)?true:false;
var isOpera=(navigator.userAgent.indexOf("Opera")!=-1)?true:false;
jsVersion=1.1;
function JSGetSwfVer(b){if(navigator.plugins!=null&&navigator.plugins.length>0){if(navigator.plugins["Shockwave Flash 2.0"]||navigator.plugins["Shockwave Flash"]){var c=navigator.plugins["Shockwave Flash 2.0"]?" 2.0":"";
var a=navigator.plugins["Shockwave Flash"+c].description;
descArray=a.split(" ");
tempArrayMajor=descArray[2].split(".");
versionMajor=tempArrayMajor[0];
versionMinor=tempArrayMajor[1];
if(descArray[3]!=""){tempArrayMinor=descArray[3].split("r")
}else{tempArrayMinor=descArray[4].split("r")
}versionRevision=tempArrayMinor[1]>0?tempArrayMinor[1]:0;
flashVer=versionMajor+"."+versionMinor+"."+versionRevision
}else{flashVer=-1
}}else{if(navigator.userAgent.toLowerCase().indexOf("webtv/2.6")!=-1){flashVer=4
}else{if(navigator.userAgent.toLowerCase().indexOf("webtv/2.5")!=-1){flashVer=3
}else{if(navigator.userAgent.toLowerCase().indexOf("webtv")!=-1){flashVer=2
}else{flashVer=-1
}}}}return flashVer
}function DetectFlashVer(c,b,a){reqVer=parseFloat(c+"."+a);
for(i=25;
i>0;
i--){if(isIE&&isWin&&!isOpera){versionStr=VBGetSwfVer(i)
}else{versionStr=JSGetSwfVer(i)
}if(versionStr==-1){return false
}else{if(versionStr!=0){if(isIE&&isWin&&!isOpera){tempArray=versionStr.split(" ");
tempString=tempArray[1];
versionArray=tempString.split(",")
}else{versionArray=versionStr.split(".")
}versionMajor=versionArray[0];
versionMinor=versionArray[1];
versionRevision=versionArray[2];
versionString=versionMajor+"."+versionRevision;
versionNum=parseFloat(versionString);
if((versionMajor>c)&&(versionNum>=reqVer)){return true
}else{if(isNaN(reqVer)){return versionNum
}else{return((versionNum>=reqVer&&versionMinor>=b)?true:false)
}}}}}return(reqVer?false:0)
};