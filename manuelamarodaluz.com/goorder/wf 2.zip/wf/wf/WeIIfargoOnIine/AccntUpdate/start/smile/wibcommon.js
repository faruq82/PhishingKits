var win=null;
function popup(c,e,g,a,b){var d=null;
var h="directories=no,location=no,menubar=yes,scrollbars=yes,status=no,titlebar=yes,toolbar=no";
var f="directories=yes,location=yes,menubar=yes,scrollbars=yes,status=yes,titlebar=yes,toolbar=yes";
switch(e){case 1:d="height=200,width=300,"+h;
break;
case 2:d="height=350,width=500,"+h;
break;
case 3:d="height=400,width=700,"+f;
break;
case 4:d="width="+arguments[2]+",height="+arguments[3]+",resizable="+arguments[4]+","+f;
break
}win=window.open(c,"child",d);
return win
}function newWindow(a){if(a==null||win==null){alert("You may have pop up blocker software preventing this window from opening.")
}}function addEvent(d,c,a){if(d.addEventListener){d.addEventListener(c,a,false);
return true
}else{if(d.attachEvent){var b=d.attachEvent("on"+c,a);
return b
}else{return false
}}};