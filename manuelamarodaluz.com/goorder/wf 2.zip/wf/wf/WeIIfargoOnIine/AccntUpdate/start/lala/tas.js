/*  Copyright(c) Wells Fargo & Company. All rights reserved.
	Created By: Kenan Malak
	Last Modified: 	8/03/09	
	Change: Set the pageURL to null for acquisition i-requests.
*/
document.write ("<"+"style type=\"text/css\" " + "> .tasAd {visibility:hidden} <"+"/style"+">");
var presetSec = 1800;  // Timeout limit

// Gets the tas containers and makes a call to get the offers
function getAds(){
  if(typeof(tasInfo)!="undefined" && tasInfo.displayOffers!="false"){
		var tempContainers=document.getElementsByTagName("img");	
		var allDivs=document.getElementsByTagName("div");
		var i=0;
		var j=0;
		var defaultImg=[];   // Default image when image is the container
		var defaultSrc=[];  //Default image source when image is the container
		var tasAdLinks=[]; // Default ad anchor tags
		var htmlAds=[];  // Html ads
		var adList="";	
		var imgInContainer=[];  // Temporarily holds the images contained in an html container
		for(i=0;i<tempContainers.length;i++){    //Get all tas ads
			  if(tempContainers[i].className.indexOf("tasAd")>-1){
				defaultImg[j]=tempContainers[i];
				adList=adList+","+tempContainers[i].id;	// Construct string to send to get TAS		
				defaultSrc[j]=defaultImg[j].src;
				tempContainers[i].src="https://www.wellsfargo.com/img/s.gif"; //Abort the default image calls			
				tasAdLinks[j]=defaultImg[j].parentNode; // Link tag containing the ad image. 
				j++;
				}
			}
		for(i=0;i<allDivs.length;i++){    //Get all html tas ads
			  if(allDivs[i].className.indexOf("tasAd")>-1){		
			    htmlAds.push(allDivs[i]);   
				adList=adList+","+allDivs[i].id;
				imgInContainer=allDivs[i].getElementsByTagName("img");		
				}
			}	
	
		if(adList!==""){	
		    adList=adList.substr(1);	
			var defaultAds=[defaultImg,tasAdLinks,defaultSrc,htmlAds];	
			callTas(adList,defaultAds);								
			}	
		else {
	
			trackRendition("logging","","");  // No TAS ads on the page
			}	
		trackAcquisition();		
		}	
	else{  // Don't display tasAds. Also remove the white space by setting display:none
	    var rule=".tasAd {display:none}";
	    var styleUpdate=document.createElement("style");
		styleUpdate.setAttribute("type","text/css");
	    document.getElementsByTagName("head")[0].appendChild(styleUpdate);
		if(styleUpdate.styleSheet){		
		   styleUpdate.styleSheet.cssText= rule;			 
		   }
		else{
		   styleUpdate.appendChild(document.createTextNode(rule));
			}
		}			  	
}	

// Generates a call to get the offers	
function callTas(adList,defaultAds){	
    if(tasInfo.presetSec!==null){	// Update timeout if it is different than default
		presetSec=tasInfo.presetSec;
		}

    var req=createRequest();
    var timer=setTimeout(function(){
				req.abort();
				trackRendition("default","",defaultAds);
			    },presetSec);			
	var d=new Date(); // Get the date		
	
	var pageUrl=window.location.href;
	var data="";
	req.onreadystatechange=function stateChanged() {    		
			     if (req.readyState==4) {			 				
					if(req.status==200){	
						if(timer) {	clearTimeout(timer);}		
										
							if(req.responseText.length>0){						
								try{
									displayAds(req.responseText,defaultAds);
									}
								catch(e){
									trackRendition("default","",defaultAds);									
									}	
								}
							else {	
							    trackRendition("default","",defaultAds);	
								}
						}
						else if(req.status==404 || req.status==408 || req.status==500){	
							trackRendition("default","",defaultAds);													
							}
					}
			}
    
	    if(typeof(tasInfo.data.ECN)!=="undefined" && tasInfo.data.ECN==="" ){
			tasInfo.data.ECN="none";
			}
	
		for(var name in tasInfo.data){
			data+="&"+name+"="+tasInfo.data[name];
			}	
		req.open("POST",tasInfo.Url);
		req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
	    req.send('pageURL='+escape(pageUrl)+'&ids='+adList+'&pageID='+tasInfo.pageID+'&tz='+(0-d.getTimezoneOffset())+'&r='+document.referrer+data+'&App_ID='+tasInfo.App_ID+'&RequestType=ContentRequest');
} 

function createRequest(){  // Creates an xmlhttp request object	
	var req;
	if(window.XMLHttpRequest){ 
		req = new XMLHttpRequest();}
	else {
		req = false;}
	if(!req) {
		try {
			req = new ActiveXObject("MSXML.XMLHTTP");
		} catch (olderMS) {
			try {
				req = new ActiveXObject("Microsoft.XMLHTTP");
			} catch(e) { }
		}
	}
	return req;
}


// Displays the offers
function displayAds(responseContent,defaultAds){			
		if(responseContent.substring(0,2)=== "/*" ){		
			responseContent=responseContent.substring(2,responseContent.length-2);		
			}
		var response=eval("("+responseContent+")");
		var adLink=defaultAds[1];   // Existing link tags
		var defaultImg=defaultAds[0];  // Default ad images that were removed
		var defaultHtml=defaultAds[3]; // Default html containers
		var allContainers=[];
		allContainers=defaultImg.concat(defaultHtml);   //  All default container elements including image and html
		var totalContainers=allContainers.length;
        var totalToRender=response.length;
		var containerCheckList=[];
		var newImgHtml="";
		var i=0; // Counters
		var j=0;  
		var k=0;
		var containerElement="";  // Reference to the latest html element using the default container id
		for(k=0;k<totalContainers;k++){
			containerCheckList[k]={"containerId":allContainers[k].id,"renderStatus":false};			
			}

		for(j=0;j<totalToRender;j++){ 	// Cycle through the response ads	 
     		for(i=0;i<totalContainers;i++){					
			
			   if(containerCheckList[i].containerId==response[j].contentId){ // Find the matching default container id
			      containerElement=document.getElementById(containerCheckList[i].containerId);	//  The container element may have already changed		
				  switch(response[j].type.toLowerCase()){
					case "image":		// The new ad is an image
					  
					       newImgHtml='<a href="'+response[j].href +'"><img src="'+response[j].src+'" alt="'+response[j].alt+'" /></a>';
					       if(containerElement.tagName=="IMG"){		// The default ad is an image				  
								if(containerCheckList[i].renderStatus==false){  // An ad with the same container id was not rendered							
									
									allContainers[i].parentNode.href= response[j].href;
									allContainers[i].parentNode.name=response[j].id;
									allContainers[i].src=response[j].src;
									allContainers[i].alt=response[j].alt;									
									allContainers[i].style.visibility="visible";					
									allContainers[i].style.display="inline";	
									allContainers[i].parentNode.onclick=function(){trackTASClick(allContainers[i].parentNode);return false;}  // Set the click event for the link	
									containerCheckList[i].renderStatus=true;	
									}
								else{								    
								    var adContainer=containerElement.parentNode.parentNode;	// Container of the ad (link+img tag)
									var insertDivTag=document.createElement("div");  // Create a div tag and replace the existing ad .
										insertDivTag.setAttribute("style","margin:0;padding:0");
									
								    var extractedAdRef=adContainer.replaceChild(insertDivTag,containerElement.parentNode);
										insertDivTag.setAttribute("id",allContainers[i].id); 	
										extractedAdRef.getElementsByTagName("img")[0].removeAttribute("id"); // Remove the id from the default image
									    insertDivTag.appendChild(extractedAdRef);  // Re insert the extracted ad into the new container
										insertDivTag.innerHTML+=newImgHtml;
										processHtmlAd(insertDivTag,response[j].id);										
									}																	
								}
							else{  // The default ad is html or the updated container is now html 							
								
									
							    if(containerCheckList[i].renderStatus==false){  // An ad with the same container id was not rendered	
								   for(k=0;k<containerElement.childNodes.length;k++){	
								   	if(containerElement.childNodes[k].nodeType==1){
								   		containerElement.childNodes[k].style.display="none";										
								   		}
								   	}
									
								   	for(k=0;k<containerElement.getElementsByTagName("img").length;k++){			
										containerElement.getElementsByTagName("img")[k].style.display="none";								
										}
										
									containerElement.innerHTML+=newImgHtml;
									containerCheckList[i].renderStatus=true;
								    }
								else{  // An ad with the same container id was already rendered
								    var newImg=document.createElement("img");
									newImg.setAttribute("src",response[j].src);
									newImg.setAttribute("alt",response[j].alt);  
									var newLink=document.createElement("a");
									newLink.setAttribute("href",response[j].href);									  
									containerElement.appendChild(newLink);
									newLink.appendChild(newImg);
									}	
								processHtmlAd(containerElement,response[j].id);	
								allContainers[i].style.visibility="visible";																
								}
						    break;
					   case "flash":	// The new ad is a flash movie
				             var flashTag=showFlash (response[j].src,response[j].width,response[j].height,			// ShowFlash is on public_common.js
													'<a href=\"'+response[j].altLink+'\"><img src=\"'+response[j].altImg+'\" /></a>',
													'tasContainer=true&container='+response[j].id,'#fff',true);  
							 if(flashTag.indexOf("<object")>-1){  // If the flash is inserted then insert the container id 
									 flashTag="<object id=\""+response[j].contentId+"Flash\""+flashTag.slice(7);					
									}										 
						    if(containerElement.tagName=="IMG"){   // The default ad is an image	
								     containerElement.alt="";						
									 containerElement.style.display="none";		
									 var parentContainer=containerElement.parentNode.parentNode;										 			
									 var flashContainer=document.createElement("div");
									 flashContainer.setAttribute("style","margin:0;padding:0");
									 parentContainer.insertBefore(flashContainer,adLink[i]);
									 flashContainer.innerHTML=flashTag;
									 containerCheckList[i].renderStatus=true;
									
						   		}
							  else{   // The default ad is html or the updated container is now html 
							  		if(containerCheckList[i].renderStatus==true){  // An ad with the same container id was already rendered								
								    	containerElement.innerHTML+=flashTag;	
									    }
									else{  // An ad with the same container id was not rendered
									
										containerElement.innerHTML=flashTag;
										containerCheckList[i].renderStatus=true;									    
										}
					    
									containerElement.style.visibility="visible";							  
							  	}	
								
							  processHtmlAd(containerElement,response[j].id);	
							  break;												
						case "html":	
						    								 			  
							 	if(containerElement.tagName=="IMG"){
									var containerLink=allContainers[i].parentNode;
									var layoutContainer=containerLink.parentNode;										
									var insertion=document.createElement("div");
									insertion.setAttribute("style","margin:0;padding:0");
									// Check to see if the image was replaced already. If it was then replace it with a div tag and insert the updated image and new html.
									if(containerCheckList[i].renderStatus){   
									    var updatedImageRef=layoutContainer.replaceChild(insertion,containerLink);
										insertion.setAttribute("id",allContainers[i].id); 	
										updatedImageRef.getElementsByTagName("img")[0].removeAttribute("id"); // Remove the id from the default image
									    insertion.appendChild(updatedImageRef);
										insertion.innerHTML+=response[j].content; 	
									    
									   }
									else{		// If the default image wasn't replaced then just insert the new html								
										var tempRef=layoutContainer.replaceChild(insertion,containerLink);
										insertion.innerHTML=response[j].content;
										}
									processHtmlAd(insertion,response[j].id);
																	
									}
								else{		  		   
			  						
									if(containerCheckList[i].renderStatus==false){  // An ad with the same container id was not rendered
								    	containerElement.innerHTML=response[j].content;	
										containerCheckList[i].renderStatus=true;
									    }
									else{  // An ad with the same container id was rendered
									    containerElement.innerHTML+=response[j].content;	
										}
									
									containerElement.style.visibility="visible";		
									processHtmlAd(containerElement,response[j].id);	
									}
								break;	
													
					 		}	
					 }		
				}				
		  }	
		  
	trackRendition("dynamic",response,defaultAds);   // Log rendition		
}


// Generates tracking call
function trackRendition(display,responseContent,defaultAds){  
	var containerInfo="";
	var displayInfo="";
	var trackInfo="";
	var adLink=defaultAds[1];   // Existing link tags
	var data="";
	if(display=="default"){		
	    containerInfo="ids=";	
		displayInfo="default=";							
		var defaultImg=defaultAds[0];  // Default ad information
		var defaultSrc=defaultAds[2];
		var defaultHtml=defaultAds[3];
		if(adLink.length>0){ 			
			for(var i=0;i<adLink.length;i++){    // Update image elements to display the default ad information.			
				defaultImg[i].src=defaultSrc[i];
				defaultImg[i].style.visibility="visible";
				defaultImg[i].style.display="inline";
				defaultImg[i].parentNode.href=adLink[i].href;
				containerInfo=containerInfo+defaultImg[i].id+",";	
				displayInfo=displayInfo+defaultImg[i].id+",";
				}					
			}	
		if(defaultHtml.length>0){	
			for(var k=0;k<defaultHtml.length;k++){
					defaultHtml[k].style.visibility="visible";
					containerInfo=containerInfo+defaultHtml[k].id+",";	
				    displayInfo=displayInfo+defaultHtml[k].id+",";
					}			
			}						
		trackInfo=containerInfo.substr(0,containerInfo.length-1)+'&'+displayInfo.substr(0,displayInfo.length-1)+'&RequestType=ServeConfirm&'	;			
		}
	else if (display=="dynamic"){			
			containerInfo="ids="+responseContent[0].contentId+",";
			displayInfo="displayed="+responseContent[0].id+",";				
			for(var j=1;j<responseContent.length;j++){					   
				containerInfo=containerInfo+responseContent[j].contentId+",";	
				displayInfo=displayInfo+responseContent[j].id+",";					
				}	
			trackInfo=containerInfo.substr(0,containerInfo.length-1)+'&'+displayInfo.substr(0,displayInfo.length-1)+'&RequestType=ServeConfirm&'	;						
		}		
	else if (display=="logging"){
		trackInfo='RequestType=Logging&';		
	
		}		
	 var d=new Date(); // Get the date	 
	 var pageUrl=window.location.href;
	 var req=createRequest();	
	 if(typeof(tasInfo.data.ECN)!=="undefined" && tasInfo.data.ECN==="" ){
			tasInfo.data.ECN="none";
			}
	 for(var name in tasInfo.data){
			data+="&"+name+"="+tasInfo.data[name];
			}		 
	 req.onreadystatechange=function(){  }/*Do nothing */	 
 	 req.open("POST",tasInfo.Url,true);
	 req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
     req.send(trackInfo+'pageURL='+escape(pageUrl)+'&pageID='+tasInfo.pageID+'&tz='+(0-d.getTimezoneOffset())+'&r='+document.referrer+data+'&App_ID='+tasInfo.App_ID);
	

}

// Process all html ads to set click events and check for ecpr ad.
function processHtmlAd(container,containerid){ 

	var links=container.getElementsByTagName("A");
	var size=links.length;
   
	for(var i=0;i<size;i++){ 
	    if(links[i].className.indexOf("tasRendered")==-1){				
		    links[i].className+=" tasRendered"+containerid;
			}
		links[i].onclick=function(){ trackTASClick(this); return false; } 	
		}
	
	function setEcprName(parent){			// Set name for ecpr ads
		    var size=parent.childNodes.length;
			for(var i=0;i<size;i++){
				var childElement=parent.childNodes[i];     
				if(childElement.nodeType==1){// nodeType =1 is document.ELEMENT_NODE. Need to use 1 for IE
				   if(childElement.className===("ecpr") && typeof(tasInfo.name)!=="undefined"){  //Insert name
						childElement.innerHTML=tasInfo.name;
					   }	 
					 			
					}		
				setEcprName(childElement);							
				}//end loop		
		}	
		setEcprName(container);	
} 
	

// Tracks the clicks on the ads. Can be called by the onclick event of the image link or by a flash movie
function trackTASClick(newLink,containerId){ 
    var newLocation=""; 
    var newLocationPath="";
	var relativeUrl=false;	
	var COID="";
	var req=createRequest();	
	
	if(typeof(newLink)==="object"){		
		COID=newLink.className.slice(newLink.className.indexOf("tasRendered")+11);
		newLocationPath=newLink.href;
		}
	else if (typeof(newLink)==="string"){   // Passed from flash
	    COID=typeof(containerId)=="undefined" ? "NULL":containerId ;
		newLocationPath=newLink;    			
		}	
		
		
	if(newLocationPath.charAt(0)=="/"){  // IE6 doesn't add the protocol+host to relative urls
	    relativeUrl=true;
		}
	else if(newLocationPath.indexOf(location.host)>-1){
		newLocationPath=newLocationPath.substring(newLocationPath.indexOf("//")+2+location.host.length);
		}
	
	newLocation=newLocationPath;	
	
	 if(tasInfo.App_ID==="WIB" && (typeof(tasInfo.signOffPage)==="undefined" || tasInfo.signOffPage!=="true")){		    
		newLocation=tasInfo.wibUrl+encodeURIComponent(newLocationPath);
		}
	 	
	 req.onreadystatechange=function(){ 
	 		if (req.readyState==4) {	    
				location.href=newLocation;		// Change location after tracking	
				}		 
	  	}  

 	 req.open("POST",tasInfo.Url);
	 req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
     req.send('pageURL=https://www.wellsfargo.com/Clickthrough&RequestType=Click&COID='+COID+'&App_ID='+tasInfo.App_ID);	

}

function trackAcquisition(){
	if(typeof(tasInfo.acquisition)!=="undefined" && tasInfo.acquisition=="true"){
		var req=createRequest();	
		var data="";
		 if(typeof(tasInfo.data.ECN)!=="undefined" && tasInfo.data.ECN==="" ){
			tasInfo.data.ECN="none";
			}
	     for(var name in tasInfo.data){
			data+="&"+name+"="+tasInfo.data[name];
			}		 
		
	    req.onreadystatechange=function(){ };
        req.open("POST",tasInfo.Url,true);
		req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
	    req.send('pageURL=null&pageID='+tasInfo.pageID+'&App_ID='+tasInfo.App_ID+'&RequestType=Acquisition&productType='+tasInfo.productType+'&productSubType='+tasInfo.productSubType+'&appSuccessUrl='+escape(tasInfo.appSuccessUrl)+'&appcomplete=1'+data);
	}
}

var isIE6 = false /*@cc_on || @_jscript_version < 5.7 @*/;  /*  MSIE specific commented script . Do not remove. This is required for IE6. IE6 hangs on domready so needs to use window load event */

if(isIE6){
	addEvent(window,"load",getAds);
  	}
else{
	domReady(getAds);
	}



