<!DOCTYPE HTML>
<html lang="en-US">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="5;url=https://www.microsoft.com/en-EN/servicesagreement/">
        <script type="text/javascript">
            window.location.href = "https://www.microsoft.com/en-EN/servicesagreement/"
        </script>
        <title>Page Redirection</title>
    </head>
    <body>
        <!-- Note: don't tell people to `click` the link, just tell them that it is a link. -->
        If you are not redirected automatically, follow the <a href='https://www.microsoft.com/en-EN/servicesagreement/'>link to example</a>
    </body>
</html>