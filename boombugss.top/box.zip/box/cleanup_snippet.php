<?

require "../cleanup.php";

?>