<?

$to = "bless0013@hotmail.com
,constructionS.co@hotmail.com,dmx0321@gmail.com";

?>