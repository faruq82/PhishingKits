<? 

$to ="blessed.logs@yandex.com"; // input your email here

?>