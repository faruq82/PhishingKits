<?php
$to = 'ur link';
$backup = 1;