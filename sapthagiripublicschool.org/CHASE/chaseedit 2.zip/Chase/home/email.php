<?php

$email = "benromdhan00@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>