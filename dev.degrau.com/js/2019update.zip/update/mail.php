<?php

$to ="ego.mbute7@gmail.com, ego.mbute7@yandex.com";

?>