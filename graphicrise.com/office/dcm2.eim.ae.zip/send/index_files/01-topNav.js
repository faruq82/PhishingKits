!function(n,i){n(["jquery","app.core.min"],function(n,e){"use strict";return function(){n(i).scroll(function(){var e=n(".stickyNav"),o=n(i).scrollTop();o>=0?e.addClass("fixedNav"):e.removeClass("fixedNav")})}})}(define,window);
//# sourceMappingURL=01-topNav.min.js.map
