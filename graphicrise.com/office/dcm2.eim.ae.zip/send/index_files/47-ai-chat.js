/**
 * v###version###
 */
(function (define, window) {
	define(['jquery', 'app.core.min'], function ($, app) {
		'use strict';

		return function () {
			localStorage.setItem("AIChat", 'No');
			function getTokenID() {
        localStorage.setItem("AIChat", 'No');
				var $location = "https://www.etisalat.ae"
        var currentLang = $('html').attr('lang');
        var getloggedinInformation = {
          "async": true,
          "crossDomain": true,
          "url": $location + "/b2c/getUserInfo.service",
          "method": "POST",
          "headers": {
            "Content-Type": "application/json",
            "cache-control": "no-cache"
          },
          "processData": false,
          "data": "{}"
        }
        $.ajax(getloggedinInformation).done(function (response) {
          var prasedJSON = JSON.parse(response);
          $.get($location + "/b2c/getStatelessTokenLoggedIn.service",
  					function (responseTokn) {
              var loggedInIframe = $location + "/etisalat-va/#/?channel=portalb2c&language=" + currentLang + "&fullName=" + prasedJSON.firstName + prasedJSON.lastName + "&sendemailto=" + prasedJSON.email + "&token=" + responseTokn
								localStorage.setItem("AIChat", 'Yes');
							if($('.aiChatIfreameDiv iframe').length > 0 ) {
								('.aiChatIfreameDiv iframe').remove();
								$(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedInIframe + "'></iframe>");
							}else {
								$(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedInIframe + "'></iframe>");
							}
  					})
        }).fail(function (error) {
          var loggedOutIframe = $location + "/etisalat-va/#/?channel=portalb2c&language=" + currentLang;
					localStorage.setItem("AIChat", 'Yes');
					if($('.aiChatIfreameDiv iframe').length > 0 ) {
						('.aiChatIfreameDiv iframe').remove();
					$(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedOutIframe + "'></iframe>");
				}else {
					$(".aiChatIfreameDiv").append("<iframe style='width: 100%;height: 100%;border: 0px;' src='" + loggedOutIframe + "'></iframe>");
				}
      });

			}

			$(document).ready(function () {
				localStorage.setItem("AIChat", 'No');
				$(document).mouseup(function (e) {
					var container = $(".aiChatIfreameDiv,.show-ai-support");
					if (!container.is(e.target) // if the target of the click isn't the container...
						&&
						container.has(e.target).length === 0) // ... nor a descendant of the container
					{
						$('body').removeAttr('style');
						$('.ai-chat-wrapper').hide(300);
						$('.show-ai-support').show();
						localStorage.setItem("AIChat", 'Yes');
					}
				});


				$(document).on('click','.minAI',function(){
					$('body').removeAttr('style');
					$('.ai-chat-wrapper').hide(300);
					$('.show-ai-support').show();
					localStorage.setItem("AIChat", 'Yes');
				})

				$(".hide-ai-support").click(function () {
					$('.ai-chat-wrapper').hide(300);
					$('.show-ai-support').show();

				});
				$(".show-ai-support").click(function () {
					$('body').css('position','fixed');
					getTokenID();
					$('.ai-chat-wrapper').show(300);
					$('.ai-chat-wrapper').removeClass('hide');
					$('.show-ai-support').hide();
					if (localStorage.getItem("AIChat") == 'No' || localStorage.getItem("AIChat") == null ) {
						localStorage.setItem("AIChat", 'Yes');
					}
				});
			});
		};
	});
}(define, window));
