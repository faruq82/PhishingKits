if (typeof dwr == 'undefined' || dwr.engine == undefined) throw new Error('You must include DWR engine before including this file');

(function() {
if (dwr.engine._getObject("ReadCatalogueAction") == undefined) {
var p;

p = {};
p._path = '/dx_etisalat_ae/dwr';





p.getCaptchaResults = function(p0, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getCaptchaResults', arguments);
};









p.validateB2BUser = function(p0, p1, p2, p3, p4, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'validateB2BUser', arguments);
};









p.validateB2CUser = function(p0, p1, p2, p3, p4, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'validateB2CUser', arguments);
};






p.ValidateB2BOTP = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'ValidateB2BOTP', arguments);
};




p.getCaptcha = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getCaptcha', arguments);
};





p.randomItem = function(p0, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'randomItem', arguments);
};






p.validateOTP = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'validateOTP', arguments);
};





p.resendB2BOTP = function(p0, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'resendB2BOTP', arguments);
};










p.checkAvailable = function(p0, p1, p2, p3, p4, p5, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'checkAvailable', arguments);
};






p.getAccountList = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getAccountList', arguments);
};






p.getModifylink = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getModifylink', arguments);
};






p.getSSOUrl = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getSSOUrl', arguments);
};








p.getJSONFromResponse = function(p0, p1, p2, p3, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getJSONFromResponse', arguments);
};





p.getCartDetails = function(p0, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getCartDetails', arguments);
};




p.logout = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'logout', arguments);
};




p.doPost = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'doPost', arguments);
};




p.doGet = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'doGet', arguments);
};




p.init = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'init', arguments);
};






p.service = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'service', arguments);
};




p.getServletInfo = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getServletInfo', arguments);
};




p.getServletContext = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getServletContext', arguments);
};




p.getServletConfig = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getServletConfig', arguments);
};




p.getServletName = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getServletName', arguments);
};





p.getInitParameter = function(p0, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getInitParameter', arguments);
};




p.getInitParameterNames = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'getInitParameterNames', arguments);
};






p.log = function(p0, p1, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'log', arguments);
};





p.log = function(p0, callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'log', arguments);
};




p.init = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'init', arguments);
};




p.destroy = function(callback) {
return dwr.engine._execute(p._path, 'ReadCatalogueAction', 'destroy', arguments);
};

dwr.engine._setObject("ReadCatalogueAction", p);
}
})();

