!function(t,n){t(["jquery"],function(t){"use strict";return function(){t(n).scroll(function(){t(this).scrollTop()>=500?t("#return-to-top").fadeIn(500):t("#return-to-top").fadeOut(500)}),t("#return-to-top").click(function(){t("body,html").animate({scrollTop:0},500)})}})}(define,window);
//# sourceMappingURL=226-back-to-top.min.js.map
