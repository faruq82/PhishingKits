!function(n,t){n(["jquery","app.core.min"],function(n){"use strict";return function(){n(function(){var t=n(".more-less-button");t.click(function(e){e.preventDefault(),t.toggleClass("active"),n(".show-after").toggleClass("show-now")})})}})}(define,window);
//# sourceMappingURL=14-footer.min.js.map
