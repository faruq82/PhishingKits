! function(e, n) {
    e(["jquery", "app.core.min"], function(e, s) {
        "use strict";
        return function() {
            function s() {
                e(document).find(".container_swip").each(function() {
                    var n = e(this).find(".swiper-slide").length;
                    e(this).addClass("swiper-with-" + n + "-slides");
                    new Swiper(e(this).find(".swiper_menu"), {
                        loop: !1,
                        autoplay: !1,
                        slidesPerView: e(this).find(".swiper-slide").length,
                        simulateTouch: !0,
                        breakpoints: {
                            767: {
                                slidesPerView: "auto",
                                centeredSlides: !0,
                                spaceBetweenSlides: 0
                            },
                            9999: {
                                centeredSlides: !1,
                                slidesPerView: e(this).find(".swiper-slide").length
                            }
                        }
                    });
                    i()
                })
            }

            function i() {
                var n = 0;
                e(document).find(".swiper_menu").each(function() {
                    var s = e(this)[0].swiper;
                    s && (n = (e(this).width() - e(this).width() / 10 * 3 * 3) / 2, s.params.spaceBetween = n, e(this).find(".swiper-wrapper").removeAttr("style"), e(this).find(".swiper-slide").removeAttr("style"), s.update(!0))
                })
            }
            var a = e(n),
                o = e(document),
                t = a.scrollTop(),
                l = e("#main-menu"),
                r = e(".sub_menu_mobile");
            if (l.length > 0) {
                var u = l.offset().top - 1,
                    d = l.offset().top + l.height() / 2;
                a.scroll(function() {
                    var e = a.scrollTop();
                    e + a.height() < o.height() / 2 - 47 && (e < u ? (l.removeClass("main-menu__fixed"), r.removeClass("sub-menu__fixed")) : (l.addClass("main-menu__fixed"), r.addClass("sub-menu__fixed"), e > d && !l.hasClass("menu__collapse") ? (l.removeClass("main-menu__full"), r.removeClass("sub-menu__full"), l.addClass("menu__collapse")) : e <= d && l.hasClass("menu__collapse") && (l.addClass("main-menu__full"), r.addClass("sub-menu__full"), l.removeClass("menu__collapse"))), t = e)
                })
            }
            var c = l.find(".mega-dropdown");
            l.find(".navbar-nav a").hover(function() {
                var n = e(this).data("sub-menu");
                n ? (c.addClass("open"), c.find(".row-sub-menu").hide(), c.find("#" + n).show()) : c.removeClass("open")
            }), l.mouseleave(function() {
                c.removeClass("open")
            });
            var m = !1,
                f = !1;
            e(".mega-dropdown").mouseenter(function() {
                m = !0
            }).mouseleave(function() {
                m = !1
            }), e(".navbar-nav li").mouseenter(function() {
                f = !0
            }).mouseleave(function() {
                f = !1
            }), e(".navbar-nav li").mouseleave(function() {
                setTimeout(function() {
                    m || f || c.removeClass("open")
                }, 200)
            }), e(".hamburger_icon").unbind().click(function() {
                e(this).toggleClass("open"), e(".sub_menu_mobile").toggleClass("visible_menu")
            }), e(document).ready(function() {
			$('.account-link a').click(function(){
              $('.sub-account-menu-wrap').show();
            });

            $(document).mouseup(function(e){
                var container = $(".sub-account-menu-wrap");
                // if the target of the click isn't the container nor a descendant of the container
                if (!container.is(e.target) && container.has(e.target).length === 0)
                {
                    $('.sub-account-menu-wrap').hide();
                }
            });
				
                e(n).width() < 767 ? e("li.swiper-slide").click(function() {
                    e(this).hasClass("sandy-green-b") ? e(".storelocatorMob").show() : e(".storelocatorMob").hide()
                }) : e(".storelocatorMob").hide(), e(".swiper-wrapper .swiper-slide").on("click", function() {
                    var n = e(this),
                        s = n.find(".anchorTag");
                    s[0].click()
                }), s(), e(".container_swip").length && e(n).on("resize", function() {
                    setTimeout(function() {
                        i()
                    }, 500)
                })
            }), e(n).on("load", function() {
                var s = n.location.pathname,
                    i = s.lastIndexOf("/") + 1,
                    a = s.substr(i);
                e(".main-menu-R0 .nav.navbar-nav").find('a[href$="' + a + '"]').parent().addClass("active")
            })
        }
    })
}(define, window);
//# sourceMappingURL=02-main-menu.min.js.map