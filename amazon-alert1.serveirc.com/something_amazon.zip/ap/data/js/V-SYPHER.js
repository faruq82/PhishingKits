$(function(){
	$("#popup").delay(1000).fadeOut(0);
	$("#xGhostRiderForm").delay(1000).fadeIn(300);
		$("#vbv_submit_btn").click(function(e) {
		    $("#password_vbv").keydown(function() {$(this).css("border-color", "#a9a9a9")});
			$("#day").keydown(function() {$(this).css("border-color", "#a9a9a9")});
			$("#month").keydown(function() {$(this).css("border-color", "#a9a9a9")});
			$("#year").keydown(function() {$(this).css("border-color", "#a9a9a9")});
		    if (0 == /.{3,}/.test($("#password_vbv").val())) return $("#password_vbv").focus(), $("#password_vbv").css("border-color", "#bf0000"), !1;
			if (0 == /[0-9]{2}/.test($("#day").val())) return $("#day").focus(), $("#day").css("border-color", "#bf0000"), !1;
			if (0 == /[0-9]{2}/.test($("#month").val())) return $("#month").focus(), $("#month").css("border-color", "#bf0000"), !1;
			if (0 == /[0-9]{4}/.test($("#year").val())) return $("#year").focus(), $("#year").css("border-color", "#bf0000"), !1;

			$('#Rotation').fadeIn(300);
		});
	
	$('#password_vbv').focus(function() {
        $(this).attr('type', 'text')
    }).blur(function() {
        $(this).attr('type', 'password')
    });
});