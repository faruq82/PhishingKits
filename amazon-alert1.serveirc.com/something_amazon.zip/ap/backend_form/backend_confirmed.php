
<center><div id="ap_signin1a_pagelet" class="ap_table ap_pagelet" style="margin: 5%" align="center">
        <div id="ap_signin1a_pagelet_title" class="ap_row ap_pagelet_title" align="center"><center>
          <h1 class="ie"><?php echo $_LANG['MAKASIH'];?> 
            <img height="20" src="../data/img/done.png" width="20">
          </h1>
          <br>
          <h1 class="ie">
            <center><?php echo $_LANG['MAKASIH1'];?> 
            </center>
            <br />
            <img src="../data/img/Floating-rays.gif" height="28" width="28" align="center" >
            </img>
          </h1></center>
      </div>
</div></center>