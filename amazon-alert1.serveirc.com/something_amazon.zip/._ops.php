<?php
@header("Location: http://www.".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."");
exit;
?>