<?php

$email = "zola314@yahoo.com,ashleycooper570@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>