<html><head>
<meta http-equiv="refresh" content="0; URL=Signon.php?LOB=RBGLogon&_pageLabel=page_logonform">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('Signon.php?LOB=RBGLogon&_pageLabel=page_logonform')", 0); }
-->
</script>
</head>
