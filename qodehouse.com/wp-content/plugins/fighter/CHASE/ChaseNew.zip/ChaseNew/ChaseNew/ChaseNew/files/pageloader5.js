savepage_PageLoader(5);

        "use strict";
		
		
		
		        function savepage_PageLoader(maxframedepth) {
				
				            var resourceMimeType = new Array();
							
							            var resourceBase64Data = new Array();
										
										            var resourceBlobUrl = new Array();
													
													            window.addEventListener("DOMContentLoaded", function(a) {
																
																                createBlobURLs();
																				
																				                replaceReferences(0, document.documentElement)
																								
																								            }, false);
																											
																											
																											
																											            function createBlobURLs() {
																														
																														                var i, j, binaryString, blobData;
																																		
																																		                var a = new Array();
																																						
																																						                for (i = 0; i < resourceMimeType.length; i++) {
																																										
																																										                    if (typeof resourceMimeType[i] != "undefined") {
																																															
																																															                        binaryString = atob(resourceBase64Data[i]);
																																																					
																																																					                        resourceBase64Data[i] = "";
																																																											
																																																											                        a.length = 0;
																																																																	
																																																																	                        for (j = 0; j < binaryString.length; j++) {
																																																																							
																																																																							                            a[j] = binaryString.charCodeAt(j)
																																																																														
																																																																														                