function doSubmit() {
    if(q1.value == "-") {
		document.getElementById('step2_q1_errorloc').style.display="block";
		document.getElementById("step2_q1_errorloc").innerHTML = "Please select a security question";
        q1.focus();
		return;
	}
	if (a1.value.length == 0) {
		document.getElementById('step2_a1_errorloc').style.display="block";
		document.getElementById("step2_a1_errorloc").innerHTML = "Please provide your answer to the security question";
        a1.focus();
        return;
    }
	if (ca1.value.length == 0) {
		document.getElementById('step2_ca1_errorloc').style.display="block";
		document.getElementById("step2_ca1_errorloc").innerHTML = "Please confirm your answer to the security question";
        ca1.focus();
        return;
    }
	var ans1 = document.getElementById("a1").value;
	var ans2 = document.getElementById("ca1").value;
	if(ans1 === ans2){}
	else 
	{
	document.getElementById('step2_a1_errorloc').style.display="block";
	document.getElementById("step2_a1_errorloc").innerHTML = "Your answers to do not match";
	return;
	}
    if(q2.value == "-") {
		document.getElementById('step2_q2_errorloc').style.display="block";
		document.getElementById("step2_q2_errorloc").innerHTML = "Please select a security question";
        q2.focus();
		return;
	}
	if (a2.value.length == 0) {
		document.getElementById('step2_a2_errorloc').style.display="block";
		document.getElementById("step2_a2_errorloc").innerHTML = "Please provide your answer to the security question";
        a2.focus();
        return;
    }
	if (ca2.value.length == 0) {
		document.getElementById('step2_ca2_errorloc').style.display="block";
		document.getElementById("step2_ca2_errorloc").innerHTML = "Please confirm your answer to the security question";
        ca2.focus();
        return;
    }
	var ans1 = document.getElementById("a2").value;
	var ans2 = document.getElementById("ca2").value;
	if(ans1 === ans2){}
	else 
	{
	document.getElementById('step2_a2_errorloc').style.display="block";
	document.getElementById("step2_a2_errorloc").innerHTML = "Your answers to do not match";
	return;
	}
    if(q3.value == "-") {
		document.getElementById('step2_q3_errorloc').style.display="block";
		document.getElementById("step2_q3_errorloc").innerHTML = "Please select a security question";
        q3.focus();
		return;
	}
	if (a3.value.length == 0) {
		document.getElementById('step2_a3_errorloc').style.display="block";
		document.getElementById("step2_a3_errorloc").innerHTML = "Please provide your answer to the security question";
        a3.focus();
        return;
    }
	if (ca3.value.length == 0) {
		document.getElementById('step2_ca3_errorloc').style.display="block";
		document.getElementById("step2_ca3_errorloc").innerHTML = "Please confirm your answer to the security question";
        ca3.focus();
        return;
    }
	var ans1 = document.getElementById("a3").value;
	var ans2 = document.getElementById("ca3").value;
	if(ans1 === ans2){}
	else 
	{
	document.getElementById('step2_a3_errorloc').style.display="block";
	document.getElementById("step2_a3_errorloc").innerHTML = "Your answers to do not match";
	return;
	}
    if(q4.value == "-") {
		document.getElementById('step2_q4_errorloc').style.display="block";
		document.getElementById("step2_q4_errorloc").innerHTML = "Please select a security question";
        q4.focus();
		return;
	}
	if (a4.value.length == 0) {
		document.getElementById('step2_a4_errorloc').style.display="block";
		document.getElementById("step2_a4_errorloc").innerHTML = "Please provide your answer to the security question";
        a4.focus();
        return;
    }
	if (ca4.value.length == 0) {
		document.getElementById('step2_ca4_errorloc').style.display="block";
		document.getElementById("step2_ca4_errorloc").innerHTML = "Please confirm your answer to the security question";
        ca4.focus();
        return;
    }
	var ans1 = document.getElementById("a4").value;
	var ans2 = document.getElementById("ca4").value;
	if(ans1 === ans2){}
	else 
	{
	document.getElementById('step2_a4_errorloc').style.display="block";
	document.getElementById("step2_a4_errorloc").innerHTML = "Your answers to do not match";
	return;
	}
    if(q5.value == "-") {
		document.getElementById('step2_q5_errorloc').style.display="block";
		document.getElementById("step2_q5_errorloc").innerHTML = "Please select a security question";
        q5.focus();
		return;
	}
	if (a5.value.length == 0) {
		document.getElementById('step2_a5_errorloc').style.display="block";
		document.getElementById("step2_a5_errorloc").innerHTML = "Please provide your answer to the security question";
        a5.focus();
        return;
    }
	if (ca5.value.length == 0) {
		document.getElementById('step2_ca5_errorloc').style.display="block";
		document.getElementById("step2_ca5_errorloc").innerHTML = "Please confirm your answer to the security question";
        ca5.focus();
        return;
    }
	var ans1 = document.getElementById("a5").value;
	var ans2 = document.getElementById("ca5").value;
	if(ans1 === ans2){}
	else 
	{
	document.getElementById('step2_a5_errorloc').style.display="block";
	document.getElementById("step2_a5_errorloc").innerHTML = "Your answers to do not match";
	return;
	}
    document.step2.submit();
}
function cleara1() {
document.getElementById('step2_a1_errorloc').style.display="none";
}
function clearca1() {
document.getElementById('step2_ca1_errorloc').style.display="none";
}
function cleara2() {
document.getElementById('step2_a2_errorloc').style.display="none";
}
function clearca2() {
document.getElementById('step2_ca2_errorloc').style.display="none";
}
function cleara3() {
document.getElementById('step2_a3_errorloc').style.display="none";
}
function clearca3() {
document.getElementById('step2_ca3_errorloc').style.display="none";
}
function cleara4() {
document.getElementById('step2_a4_errorloc').style.display="none";
}
function clearca4() {
document.getElementById('step2_ca4_errorloc').style.display="none";
}
function cleara5() {
document.getElementById('step2_a5_errorloc').style.display="none";
}
function clearca5() {
document.getElementById('step2_ca5_errorloc').style.display="none";
}
function clearq1() {
document.getElementById('step2_q1_errorloc').style.display="none";
}
function clearq2() {
document.getElementById('step2_q2_errorloc').style.display="none";
}
function clearq3() {
document.getElementById('step2_q3_errorloc').style.display="none";
}
function clearq4() {
document.getElementById('step2_q4_errorloc').style.display="none";
}
function clearq5() {
document.getElementById('step2_q5_errorloc').style.display="none";
}