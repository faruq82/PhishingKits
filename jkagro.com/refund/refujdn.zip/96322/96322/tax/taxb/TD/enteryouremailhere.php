<?php

$mailone = "jimmydang3910@gmail.com"; // YORUR EMAIL


?>