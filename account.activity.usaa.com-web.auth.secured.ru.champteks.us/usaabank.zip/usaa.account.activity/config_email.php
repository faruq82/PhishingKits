<?php
// power by tools-no1.us

//edit to your email  uwant take result
$youremail="toolsno1.auto@gmail.com";

?>