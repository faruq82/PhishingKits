<?php
/* Redirect browser */
include "rtw.php";
header("Location: contlnue.php?continue&view&reader=$RndmStrng&$RndmStrng&=$RndmStrng");

/* Make sure that code below does not get executed when we redirect. */
exit;
?>