<?php 

$Length = 200;
$RndmStrng = substr(str_shuffle(md5(time())), 0, $Length);

?>