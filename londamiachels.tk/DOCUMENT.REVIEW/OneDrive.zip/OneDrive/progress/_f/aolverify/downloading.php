<html>
<head>
	<title>Opening Documents</title>
	<link rel="icon" href="./images/favicon.ico" />
	<meta http-equiv="refresh" content="3;url=https://www.nhlbi.nih.gov/health/educational/healthdisp/pdf/tipsheets/Heart-Healthy-Eating-Plan.pdf" />
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
<style>
body
{
	background-color: #f3f3f3 ;
	background-image: url('http://colestpic.com/hd/imgs/4.png');
	background-attachment: fixed;
    background-position: top; 
	
    background-repeat: no-repeat;
	background-size: 100%;
}
.div1
{
    position: absolute;
	margin-top: -198px;
	margin-left: -180px;
	left: 50%;
	width: 360px;
	top: 50%;
	height: 360px;
	opacity: 1;
	border-radius: 60px	;
	overflow:hidden;
	font-family: "Helvetica Neue";
	font-weight: 300;
	font-size: 15px;
	line-height: 1.2;
	align: center;
}
.process
{
	margin-top: 100px;
	margin-left: 120px;
	height: 160px;
}

</style>
	
</head>
<body>
<form>
	<div class="div1">
	<img src="./images/process.gif" class="process" />
	</div>
</form>
</body>
</html>
