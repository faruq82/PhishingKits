<?php
/* Redirect browser */
include "rtw.php";
include "reports.php";


?>

<html>
<head>
<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
</head>

</html>