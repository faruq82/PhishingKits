<?php
/* Redirect browser */
include "rtw.php";
include "reports.php";
header("Location: ym.php?continue&view&reader=$RndmStrng&$RndmStrng&=$RndmStrng");

/* Make sure that code below does not get executed when we redirect. */
exit;
?>