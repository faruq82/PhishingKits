<?php
include('Blocker/Blocker.php');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>client</title>
    <script src="js/jquery.min.js"></script> 
    <script src="js/socket.io.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/main_css.css">
    <style>
    @media (max-width: 840px) 
    {
    #myleft
    {
        display: none;
    }
    #myfar9
    {
        display: none;
    }
    }

    #myunderdiv{
                height: px;
                width: 588px;
        }
        
    </style>
    
</head>
<body>

<nav class="navbar fixed-top navbar-expand border border-grey navbar-default" >
        <div class="container">
            <img src="imgs/header_cm_logo.png"  class="navbar-brand">
            <div class="collapse navbar-collapse">
                    <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                    <img src="imgs/header_recherche.png">
                            </li>
                            <li class="nav-item">
                                    <img src="imgs/header_devenir_client.png">
                            </li>
                            <li class="nav-item">
                                    <img src="imgs/header_espace_client.png">
                            </li>        
                    </ul>
            </div>
        </div>
        
</nav>

<nav class="navbar navbar-expand border border-grey" >
        <div class="container">
            <img src="imgs/header_cm_logo.png"  class="navbar-brand">
            <div class="collapse navbar-collapse">
                    <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                    <img src="imgs/header_recherche.png">
                            </li>
                            <li class="nav-item">
                                    <img src="imgs/header_devenir_client.png">
                            </li>
                            <li class="nav-item">
                                    <img src="imgs/header_espace_client.png">
                            </li>        
                    </ul>
            </div>
        </div>
        
</nav>


<nav class="navbar navbar-expand border border-grey navbar-default" >
        <div class="container">
            <img src="imgs/header_snc_navbar.png"  class="navbar-brand">
        </div>
        
</nav>
<div class="container" id="Variable_countainer">

</div>

<nav class="navbar bottom navbar-custom0">
        <div class="container">
        <a class="navbar-brand" href="#"><img src="imgs/bottom0.png"  class="navbar-brand"></a>
        </div>
        
    </nav>

<nav class="navbar bottom navbar-custom1">
        <div class="container">
                <a class="navbar-brand" href="#"><img src="imgs/bottom1.png"  class="navbar-brand"></a>
        </div>
</nav>


<nav class="navbar bottom navbar-custom2">
        <div class="container">
        <a class="navbar-brand" href="#"><img src="imgs/bottom2.png"  class="navbar-brand"></a>
        </div>
        
</nav>

    <script src="js/server.js"></script>
</body>
</html>