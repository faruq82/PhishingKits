<?php

$to ="asgkuwait@yandex.ru";

?>