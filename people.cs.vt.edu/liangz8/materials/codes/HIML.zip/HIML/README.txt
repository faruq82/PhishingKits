HIML package Version 1.0 (June, 2016) (Matlab code)

------------------------------------

Copyright (c) 2016 Liang Zhao
George Mason University
lzhao9@gmu.edu

Please cite the following paper in any work that uses this material:

Zhao, Liang, Jieping Ye, Feng Chen, Chang-Tien Lu, and Naren Ramakrishnan. "Hierarchical incomplete multi-source feature learning for spatiotemporal event forecasting." In Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, pp. 2085-2094. ACM, 2016.

@inproceedings{zhao2016hierarchical,
  title={Hierarchical incomplete multi-source feature learning for spatiotemporal event forecasting},
  author={Zhao, Liang and Ye, Jieping and Chen, Feng and Lu, Chang-Tien and Ramakrishnan, Naren},
  booktitle={Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining},
  pages={2085--2094},
  year={2016},
  organization={ACM}
}

Together with this Readme.txt are the codes and data.

---------------
ENVIRONMENT: 
---------------
Matlab 2011-2016 (previous version may also work)


---------------
INSTALLATION: 
---------------
Before running the codes, please first install and add-path the toolbox UNLocBox here: https://lts2.epfl.ch/unlocbox/.


---------------
EXAMPLE RUN:
---------------
To run the code, run the following command lines:
>> load('published_data.mat')
>> example_run


---------------
DATA FORMAT: 
---------------
Please refer to the comments in file 'example_run.m' for the format of the data in published_data.mat



If any problem, please contact Liang Zhao via lzhao9@gmu.edu.