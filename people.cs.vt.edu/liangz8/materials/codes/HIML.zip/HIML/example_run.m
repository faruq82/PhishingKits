function example_run
% Here our data has three levels, city level (denoted by x or X); state
% level (denoted by u or U), and country level (denoted by z or Z)
% tr_chunks and te_chunks: variables that store the missing patterns 
% (defined in Definition 3 in the paper) for training and test setmentioned in the paper.
%          Each contains two fields:    1) time: the duration of the missing patterns
%                                       2) value: "'x', [1,1]" means city level
% tr_X, tr_U, tr_Z, and te_X, te_U, te_Z: training and test inputs for
% city, state, and country levels, each row is a sample while each column
% is a feature.
% tr_Y and te_Y: training and test labels.
% is missing, [1,inf] means current level is not missing.
load published_data;
[inputs_tr,sizes,XUZ_std] = training_data_formulate(tr_X,tr_U,tr_Z,tr_Y,tr_chunks,5); % the weights of positive obseravations are 5 times than those of negative ones
[Ws] = interactive_lasso(inputs_tr,sizes,0.5,0.5,0,1);% choose classification using logisitc loss
inputs_te = test_data_formulate(te_X,te_U,te_Z,te_Y,te_chunks,XUZ_std);
% get prediction performance
[pred_Y,auc] = predict(Ws,inputs_te,1,false);
end