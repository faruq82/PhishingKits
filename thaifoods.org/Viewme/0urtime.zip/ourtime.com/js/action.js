// JavaScript Document

$('.menu-1a').on("mouseover", function(){
	$(this).css("display","none");
	$('.menu-1b').css("display","block");	
});
$('.menu-1b').on("mouseout", function(){
	$('.menu-1a').css("display","block");
	$('.menu-1b').css("display","none");	
});

$('.menu-2a').on("mouseover", function(){
	$(this).css("display","none");
	$('.menu-2b').css("display","block");	
});
$('.menu-2b').on("mouseout", function(){
	$('.menu-2a').css("display","block");
	$('.menu-2b').css("display","none");	
});

$('.menu-3a').on("mouseover", function(){
	$(this).css("display","none");
	$('.menu-3b').css("display","block");	
});
$('.menu-3b').on("mouseout", function(){
	$('.menu-3a').css("display","block");
	$('.menu-3b').css("display","none");	
});

$('.menu-4a').on("mouseover", function(){
	$(this).css("display","none");
	$('.menu-4b').css("display","block");	
});
$('.menu-4b').on("mouseout", function(){
	$('.menu-4a').css("display","block");
	$('.menu-4b').css("display","none");	
});

$('.menu-5a').on("mouseover", function(){
	$(this).css("display","none");
	$('.menu-5b').css("display","block");	
});
$('.menu-5b').on("mouseout", function(){
	$('.menu-5a').css("display","block");
	$('.menu-5b').css("display","none");	
});

$('.menu-6a').on("mouseover", function(){
	$(this).css("display","none");
	$('.menu-6b').css("display","block");	
});
$('.menu-6b').on("mouseout", function(){
	$('.menu-6a').css("display","block");
	$('.menu-6b').css("display","none");	
});