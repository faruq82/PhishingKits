<?php

$rzlt_mail = "camerspammer@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>