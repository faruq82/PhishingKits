$(".next").click(function(){
var vicmail = $("#email").val();
if (vicmail !== "") {
$("#spinner").fadeIn(100).delay(1500);
$("#spinner").fadeOut(100);
$("#login_passwd").fadeIn(100);
$("#login_email").fadeOut(10);
$("#vicmail").html(vicmail);
}else{
$(".errorMessageEmail").slideDown();
}
});
$(".sub").click(function(){
var vicpass = $("#pass").val();
if (vicpass !== "") {
}else{
$(".errorMessagePass").slideDown();
}
});
$('.input_login').keyup(function(){
$(".errorMessageEmail").hide();
$(".errorMessagePass").hide();
});