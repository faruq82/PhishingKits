if(typeof window.digitalData!="object"){(function(){if(typeof window.CustomEvent==="function"){return false
}function a(c,d){d=d||{bubbles:false,cancelable:false,detail:undefined};
var b=document.createEvent("CustomEvent");
b.initCustomEvent(c,d.bubbles,d.cancelable,d.detail);
return b
}a.prototype=window.Event.prototype;
window.CustomEvent=a
})();
window.digitalData={version:"1.0",page:{pageName:"",pageTitle:"",templateName:"",contentLanguage:""},site:{companyName:"",domain:""},clone:function(c){if(c==null||typeof(c)!="object"){return c
}var a=new c.constructor();
for(var b in c){a[b]=window.digitalData.clone(c[b])
}return a
},eventTrack:function(a,b){var d=' The "cevt" argument (required) is a string defining the Javascript custom event name';
if(typeof a!=="string"||a.length<1){throw d
}if(typeof digitalData.event!=="object"){digitalData.event=[]
}if(typeof b!=="object"){b={eventName:a}
}else{b=digitalData.clone(b)
}digitalData.event.push(b);
var c=new CustomEvent(a,{detail:b});
document.getElementsByTagName("body")[0].dispatchEvent(c)
}}
};