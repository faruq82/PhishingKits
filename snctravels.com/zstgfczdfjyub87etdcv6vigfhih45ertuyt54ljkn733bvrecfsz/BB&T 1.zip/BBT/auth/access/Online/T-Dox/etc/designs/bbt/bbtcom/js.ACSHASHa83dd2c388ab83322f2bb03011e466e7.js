/*@preserve BB&T platform, version 1.5.17 */
!function(S){"use strict";function B(e){return(B="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}function _(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}S=S&&S.hasOwnProperty("default")?S.default:S;var i="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};function e(e,t){return e(t={exports:{}},t.exports),t.exports}var t,r,n,o=e(function(e){var t,n;t=i,n=function(){
/*! svg4everybody v2.1.9 | github.com/jonathantneal/svg4everybody */
function E(e,t,n){
// if the target exists
if(n){
// create a document fragment to hold the contents of the target
var i=document.createDocumentFragment(),r=!t.hasAttribute("viewBox")&&n.getAttribute("viewBox");
// conditionally set the viewBox on the svg
r&&t.setAttribute("viewBox",r);
// copy the contents of the clone into the fragment
for(// clone the target
var o=n.cloneNode(!0);o.childNodes.length;)i.appendChild(o.firstChild);
// append the fragment into the svg
e.appendChild(i)}}function h(i){
// listen to changes in the request
i.onreadystatechange=function(){
// if the request is ready
if(4===i.readyState){
// get the cached html document
var n=i._cachedDocument;
// ensure the cached html document based on the xhr response
n||((n=i._cachedDocument=document.implementation.createHTMLDocument("")).body.innerHTML=i.responseText,i._cachedTarget={}),// clear the xhr embeds list and embed each item
i._embeds.splice(0).map(function(e){
// get the cached target
var t=i._cachedTarget[e.id];
// ensure the cached target
t||(t=i._cachedTarget[e.id]=n.getElementById(e.id)),
// embed the target into the svg
E(e.parent,e.svg,t)})}},// test the ready state change immediately
i.onreadystatechange()}function A(e){for(var t=e;"svg"!==t.nodeName.toLowerCase()&&(t=t.parentNode););return t}return function(e){var d,u=Object(e),t=window.top!==window.self;d="polyfill"in u?u.polyfill:/\bTrident\/[567]\b|\bMSIE (?:9|10)\.0\b/.test(navigator.userAgent)||(navigator.userAgent.match(/\bEdge\/12\.(\d+)\b/)||[])[1]<10547||(navigator.userAgent.match(/\bAppleWebKit\/(\d+)\b/)||[])[1]<537||/\bEdge\/.(\d+)\b/.test(navigator.userAgent)&&t;
// create xhr requests object
var f={},_=window.requestAnimationFrame||setTimeout,S=document.getElementsByTagName("use"),p=0;
// conditionally start the interval if the polyfill is active
d&&function e(){
// while the index exists in the live <use> collection
for(// get the cached <use> index
var t=0;t<S.length;){
// get the current <use>
var n=S[t],i=n.parentNode,r=A(i),o=n.getAttribute("xlink:href")||n.getAttribute("href");if(!o&&u.attributeName&&(o=n.getAttribute(u.attributeName)),r&&o){if(d)if(!u.validate||u.validate(o,r,n)){
// remove the <use> element
i.removeChild(n);
// parse the src and get the url and id
var a=o.split("#"),s=a.shift(),l=a.join("#");
// if the link is external
if(s.length){
// get the cached xhr request
var c=f[s];
// ensure the xhr request exists
c||((c=f[s]=new XMLHttpRequest).open("GET",s),c.send(),c._embeds=[]),// add the svg and id as an item to the xhr embeds list
c._embeds.push({parent:i,svg:r,id:l}),// prepare the xhr ready state change event
h(c)}else
// embed the local id into the svg
E(i,r,document.getElementById(l))}else
// increase the index when the previous value was not "valid"
++t,++p}else
// increase the index when the previous value was not "valid"
++t}
// continue the interval
// continue the interval
(!S.length||0<S.length-p)&&_(e,67)}()}},e.exports?// Node. Does not work with strict CommonJS, but
// only CommonJS-like environments that support module.exports,
// like Node.
e.exports=n():t.svg4everybody=n()}),u=function(e){try{return!!e()}catch(e){return!0}},a={}.toString,s=function(e){return a.call(e).slice(8,-1)},l="".split,m=u(function(){
// throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
// eslint-disable-next-line no-prototype-builtins
return!Object("z").propertyIsEnumerable(0)})?function(e){return"String"==s(e)?l.call(e,""):Object(e)}:Object,f=function(e){if(null==e)throw TypeError("Can't call method on "+e);return e},c=function(e){return m(f(e))},d=function(e,t){var n=[][e];return!n||!u(function(){
// eslint-disable-next-line no-useless-call,no-throw-literal
n.call(null,t||function(){throw 1},1)})},p="object",E=function(e){return e&&e.Math==Math&&e},h=
// eslint-disable-next-line no-undef
E(typeof globalThis==p&&globalThis)||E(typeof window==p&&window)||E(typeof self==p&&self)||E(typeof i==p&&i)||
// eslint-disable-next-line no-new-func
Function("return this")(),A=!u(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a}),T={}.propertyIsEnumerable,g=Object.getOwnPropertyDescriptor,C={f:g&&!T.call({1:2},1)?function(e){var t=g(this,e);return!!t&&t.enumerable}:T},L=function(e,t){return{enumerable:!(1&e),configurable:!(2&e),writable:!(4&e),value:t}},O=function(e){return"object"==typeof e?null!==e:"function"==typeof e},R=function(e,t){if(!O(e))return e;var n,i;if(t&&"function"==typeof(n=e.toString)&&!O(i=n.call(e)))return i;if("function"==typeof(n=e.valueOf)&&!O(i=n.call(e)))return i;if(!t&&"function"==typeof(n=e.toString)&&!O(i=n.call(e)))return i;throw TypeError("Can't convert object to primitive value")},v={}.hasOwnProperty,I=function(e,t){return v.call(e,t)},y=h.document,b=O(y)&&O(y.createElement),N=function(e){return b?y.createElement(e):{}},D=!A&&!u(function(){return 7!=Object.defineProperty(N("div"),"a",{get:function(){return 7}}).a}),M=Object.getOwnPropertyDescriptor,P={f:A?M:function(e,t){if(e=c(e),t=R(t,!0),D)try{return M(e,t)}catch(e){/* empty */}if(I(e,t))return L(!C.f.call(e,t),e[t])}},w=function(e){if(!O(e))throw TypeError(String(e)+" is not an object");return e},G=Object.defineProperty,F={f:A?G:function(e,t,n){if(w(e),t=R(t,!0),w(n),D)try{return G(e,t,n)}catch(e){/* empty */}if("get"in n||"set"in n)throw TypeError("Accessors not supported");return"value"in n&&(e[t]=n.value),e}},x=A?function(e,t,n){return F.f(e,t,L(1,n))}:function(e,t,n){return e[t]=n,e},U=function(t,n){try{x(h,t,n)}catch(e){h[t]=n}return n},H=e(function(e){var t="__core-js_shared__",n=h[t]||U(t,{});(e.exports=function(e,t){return n[e]||(n[e]=void 0!==t?t:{})})("versions",[]).push({version:"3.1.2",mode:"global",copyright:"© 2019 Denis Pushkarev (zloirock.ru)"})}),k=H("native-function-to-string",Function.toString),j=h.WeakMap,V="function"==typeof j&&/native code/.test(k.call(j)),W=0,z=Math.random(),X=function(e){return"Symbol(".concat(void 0===e?"":e,")_",(++W+z).toString(36))},Y=H("keys"),K=function(e){return Y[e]||(Y[e]=X(e))},q={},$=h.WeakMap;if(V){var J=new $,Q=J.get,Z=J.has,ee=J.set;t=function(e,t){return ee.call(J,e,t),t},r=function(e){return Q.call(J,e)||{}},n=function(e){return Z.call(J,e)}}else{var te=K("state");q[te]=!0,t=function(e,t){return x(e,te,t),t},r=function(e){return I(e,te)?e[te]:{}},n=function(e){return I(e,te)}}var ne={set:t,get:r,has:n,enforce:function(e){return n(e)?r(e):t(e,{})},getterFor:function(n){return function(e){var t;if(!O(e)||(t=r(e)).type!==n)throw TypeError("Incompatible receiver, "+n+" required");return t}}},ie=e(function(e){var t=ne.get,s=ne.enforce,l=String(k).split("toString");H("inspectSource",function(e){return k.call(e)}),(e.exports=function(e,t,n,i){var r=!!i&&!!i.unsafe,o=!!i&&!!i.enumerable,a=!!i&&!!i.noTargetGet;"function"==typeof n&&("string"!=typeof t||I(n,"name")||x(n,"name",t),s(n).source=l.join("string"==typeof t?t:"")),e!==h?(r?!a&&e[t]&&(o=!0):delete e[t],o?e[t]=n:x(e,t,n)):o?e[t]=n:U(t,n)})(Function.prototype,"toString",function(){return"function"==typeof this&&t(this).source||k.call(this)})}),re=Math.ceil,oe=Math.floor,ae=function(e){return isNaN(e=+e)?0:(0<e?oe:re)(e)},se=Math.min,le=function(e){return 0<e?se(ae(e),9007199254740991):0;// 2 ** 53 - 1 == 9007199254740991
},ce=Math.max,de=Math.min,ue=function(e,t){var n=ae(e);return n<0?ce(n+t,0):de(n,t)},fe=function(s){return function(e,t,n){var i,r=c(e),o=le(r.length),a=ue(n,o);
// Array#includes uses SameValueZero equality algorithm
// eslint-disable-next-line no-self-compare
if(s&&t!=t){for(;a<o;)
// eslint-disable-next-line no-self-compare
if((i=r[a++])!=i)return!0;
// Array#indexOf ignores holes, Array#includes - not
}else for(;a<o;a++)if((s||a in r)&&r[a]===t)return s||a||0;return!s&&-1}},_e=fe(!1),Se=function(e,t){var n,i=c(e),r=0,o=[];for(n in i)!I(q,n)&&I(i,n)&&o.push(n);
// Don't enum bug & hidden keys
for(;t.length>r;)I(i,n=t[r++])&&(~_e(o,n)||o.push(n));return o},pe=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"],Ee=pe.concat("length","prototype"),he={f:Object.getOwnPropertyNames||function(e){return Se(e,Ee)}},Ae={f:Object.getOwnPropertySymbols},me=h.Reflect,Te=me&&me.ownKeys||function(e){var t=he.f(w(e)),n=Ae.f;return n?t.concat(n(e)):t},ge=function(e,t){for(var n=Te(t),i=F.f,r=P.f,o=0;o<n.length;o++){var a=n[o];I(e,a)||i(e,a,r(t,a))}},Ce=/#|\.prototype\./,Le=function(e,t){var n=Re[Oe(e)];return n==Ie||n!=ve&&("function"==typeof t?u(t):!!t)},Oe=Le.normalize=function(e){return String(e).replace(Ce,".").toLowerCase()},Re=Le.data={},ve=Le.NATIVE="N",Ie=Le.POLYFILL="P",ye=Le,be=P.f,Ne=function(e,t){var n,i,r,o,a,s=e.target,l=e.global,c=e.stat;if(n=l?h:c?h[s]||U(s,{}):(h[s]||{}).prototype)for(i in t){
// contained in target
if(o=t[i],r=e.noTargetGet?(a=be(n,i))&&a.value:n[i],!ye(l?i:s+(c?".":"#")+i,e.forced)&&void 0!==r){if(typeof o==typeof r)continue;ge(o,r)}
// add a flag to not completely full polyfills
(e.sham||r&&r.sham)&&x(o,"sham",!0),
// extend global
ie(n,i,o,e)}},De=[].join,Me=m!=Object,Pe=d("join",",");
// `Array.prototype.join` method
// https://tc39.github.io/ecma262/#sec-array.prototype.join
Ne({target:"Array",proto:!0,forced:Me||Pe},{join:function(e){return De.call(c(this),void 0===e?",":e)}});
// `IsArray` abstract operation
// https://tc39.github.io/ecma262/#sec-isarray
var we=Array.isArray||function(e){return"Array"==s(e)},Ge=function(e,t,n){var i=R(t);i in e?F.f(e,i,L(0,n)):e[i]=n},Fe=!!Object.getOwnPropertySymbols&&!u(function(){
// Chrome 38 Symbol has incorrect toString conversion
// eslint-disable-next-line no-undef
return!String(Symbol())}),xe=H("wks"),Be=h.Symbol,Ue=function(e){return xe[e]||(xe[e]=Fe&&Be[e]||(Fe?Be:X)("Symbol."+e))},He=Ue("species"),ke=function(t){return!u(function(){var e=[];return(e.constructor={})[He]=function(){return{foo:1}},1!==e[t](Boolean).foo})},je=Ue("species"),Ve=[].slice,We=Math.max,ze=ke("slice");
// `Array.prototype.slice` method
// https://tc39.github.io/ecma262/#sec-array.prototype.slice
// fallback for not array-like ES3 strings and DOM objects
Ne({target:"Array",proto:!0,forced:!ze},{slice:function(e,t){var n,i,r,o=c(this),a=le(o.length),s=ue(e,a),l=ue(void 0===t?a:t,a);if(we(o)&&(
// cross-realm fallback
"function"!=typeof(n=o.constructor)||n!==Array&&!we(n.prototype)?O(n)&&null===(n=n[je])&&(n=void 0):n=void 0,n===Array||void 0===n))return Ve.call(o,s,l);for(i=new(void 0===n?Array:n)(We(l-s,0)),r=0;s<l;s++,r++)s in o&&Ge(i,r,o[s]);return i.length=r,i}});var Xe=F.f,Ye=Function.prototype,Ke=Ye.toString,qe=/^\s*function ([^ (]*)/;
// Function instances `.name` property
// https://tc39.github.io/ecma262/#sec-function-instances-name
!A||"name"in Ye||Xe(Ye,"name",{configurable:!0,get:function(){try{return Ke.call(this).match(qe)[1]}catch(e){return""}}});var $e,Je,Qe=Object.setPrototypeOf||("__proto__"in{}?function(){var n,i=!1,e={};try{(n=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__").set).call(e,[]),i=e instanceof Array}catch(e){/* empty */}return function(e,t){return function(e,t){if(w(e),!O(t)&&null!==t)throw TypeError("Can't set "+String(t)+" as a prototype")}(e,t),i?n.call(e,t):e.__proto__=t,e}}():void 0),Ze=function(e,t,n){var i,r=t.constructor;return r!==n&&"function"==typeof r&&(i=r.prototype)!==n.prototype&&O(i)&&Qe&&Qe(e,i),e},et=Ue("match"),tt=function(e){var t;return O(e)&&(void 0!==(t=e[et])?!!t:"RegExp"==s(e))},nt=function(){var e=w(this),t="";return e.global&&(t+="g"),e.ignoreCase&&(t+="i"),e.multiline&&(t+="m"),e.unicode&&(t+="u"),e.sticky&&(t+="y"),t},it=h,rt=function(e){return"function"==typeof e?e:void 0},ot=Ue("species"),at=Ue("match"),st=F.f,lt=he.f,ct=h.RegExp,dt=ct.prototype,ut=/a/g,ft=/a/g,_t=new ct(ut)!==ut;
// Works with __proto__ only. Old v8 can't work with null proto objects.
/* eslint-disable no-proto */
// `RegExp` constructor
// https://tc39.github.io/ecma262/#sec-regexp-constructor
if(ye("RegExp",A&&(!_t||u(function(){
// RegExp constructor can alter flags and IsRegExp works correct with @@match
return ft[at]=!1,ct(ut)!=ut||ct(ft)==ft||"/a/i"!=ct(ut,"i")})))){for(var St=function(e,t){var n=this instanceof St,i=tt(e),r=void 0===t;return!n&&i&&e.constructor===St&&r?e:Ze(_t?new ct(i&&!r?e.source:e,t):ct((i=e instanceof St)?e.source:e,i&&r?nt.call(e):t),n?this:dt,St)},pt=function(t){t in St||st(St,t,{configurable:!0,get:function(){return ct[t]},set:function(e){ct[t]=e}})},Et=lt(ct),ht=0;ht<Et.length;)pt(Et[ht++]);(dt.constructor=St).prototype=dt,ie(h,"RegExp",St)}
// https://tc39.github.io/ecma262/#sec-get-regexp-@@species
$e=function(e,t){return arguments.length<2?rt(it[e])||rt(h[e]):it[e]&&it[e][t]||h[e]&&h[e][t]}("RegExp"),Je=F.f,A&&$e&&!$e[ot]&&Je($e,ot,{configurable:!0,get:function(){return this}});var At="toString",mt=/./[At],Tt=RegExp.prototype,gt=u(function(){return"/a/b"!=mt.call({source:"a",flags:"b"})}),Ct=mt.name!=At;
// `RegExp.prototype.toString` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype.tostring
(gt||Ct)&&ie(RegExp.prototype,At,function(){var e=w(this),t=String(e.source),n=e.flags;return"/"+t+"/"+String(void 0===n&&e instanceof RegExp&&!("flags"in Tt)?nt.call(e):n)},{unsafe:!0});
// `ToObject` abstract operation
// https://tc39.github.io/ecma262/#sec-toobject
var Lt,Ot,Rt=function(e){return Object(f(e))},vt=function(e,t,n){var i,r,o=String(f(e)),a=ae(t),s=o.length;return a<0||s<=a?n?"":void 0:(i=o.charCodeAt(a))<55296||56319<i||a+1===s||(r=o.charCodeAt(a+1))<56320||57343<r?n?o.charAt(a):i:n?o.slice(a,a+2):r-56320+(i-55296<<10)+65536},It=function(e,t,n){return t+(n?vt(e,t,!0).length:1)},yt=RegExp.prototype.exec,bt=String.prototype.replace,Nt=yt,Dt=(Lt=/a/,Ot=/b*/g,yt.call(Lt,"a"),yt.call(Ot,"a"),0!==Lt.lastIndex||0!==Ot.lastIndex),Mt=void 0!==/()??/.exec("")[1];
// CONVERT_TO_STRING: true  -> String#at
// CONVERT_TO_STRING: false -> String#codePointAt
(Dt||Mt)&&(Nt=function(e){var t,n,i,r,o=this;return Mt&&(n=new RegExp("^"+o.source+"$(?!\\s)",nt.call(o))),Dt&&(t=o.lastIndex),i=yt.call(o,e),Dt&&i&&(o.lastIndex=o.global?i.index+i[0].length:t),Mt&&i&&1<i.length&&
// Fix browsers whose `exec` methods don't consistently return `undefined`
// for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
bt.call(i[0],n,function(){for(r=1;r<arguments.length-2;r++)void 0===arguments[r]&&(i[r]=void 0)}),i});var Pt=Nt,wt=function(e,t){var n=e.exec;if("function"==typeof n){var i=n.call(e,t);if("object"!=typeof i)throw TypeError("RegExp exec method returned something other than an Object or null");return i}if("RegExp"!==s(e))throw TypeError("RegExp#exec called on incompatible receiver");return Pt.call(e,t)},Gt=Ue("species"),Ft=!u(function(){
// #replace needs built-in support for named groups.
// #match works fine because it just return the exec results, even if it has
// a "grops" property.
var e=/./;return e.exec=function(){var e=[];return e.groups={a:"7"},e},"7"!=="".replace(e,"$<a>")}),xt=!u(function(){var e=/(?:)/,t=e.exec;e.exec=function(){return t.apply(this,arguments)};var n="ab".split(e);return 2!==n.length||"a"!==n[0]||"b"!==n[1]}),Bt=function(n,e,t,i){var r=Ue(n),o=!u(function(){
// String methods call symbol-named RegEp methods
var e={};return e[r]=function(){return 7},7!=""[n](e)}),a=o&&!u(function(){
// Symbol-named RegExp methods call .exec
var e=!1,t=/a/;return t.exec=function(){return e=!0,null},"split"===n&&(
// RegExp[@@split] doesn't call the regex's exec method, but first creates
// a new one. We need to return the patched regex when creating the new one.
t.constructor={},t.constructor[Gt]=function(){return t}),t[r](""),!e});if(!o||!a||"replace"===n&&!Ft||"split"===n&&!xt){var s=/./[r],l=t(r,""[n],function(e,t,n,i,r){return t.exec===Pt?o&&!r?{done:!0,value:s.call(t,n,i)}:{done:!0,value:e.call(n,t,i)}:{done:!1}}),c=l[0],d=l[1];ie(String.prototype,n,c),ie(RegExp.prototype,r,2==e?function(e,t){return d.call(e,this,t)}
// 21.2.5.6 RegExp.prototype[@@match](string)
// 21.2.5.9 RegExp.prototype[@@search](string)
:function(e){return d.call(e,this)}),i&&x(RegExp.prototype[r],"sham",!0)}},Ut=Math.max,Ht=Math.min,kt=Math.floor,jt=/\$([$&'`]|\d\d?|<[^>]*>)/g,Vt=/\$([$&'`]|\d\d?)/g;
// `RegExpExec` abstract operation
// https://tc39.github.io/ecma262/#sec-regexpexec
// @@replace logic
Bt("replace",2,function(r,g,C){return[
// `String.prototype.replace` method
// https://tc39.github.io/ecma262/#sec-string.prototype.replace
function(e,t){var n=f(this),i=null==e?void 0:e[r];return void 0!==i?i.call(e,n,t):g.call(String(n),e,t)},
// `RegExp.prototype[@@replace]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@replace
function(e,t){var n=C(g,e,this,t);if(n.done)return n.value;var i=w(e),r=String(this),o="function"==typeof t;o||(t=String(t));var a=i.global;if(a){var s=i.unicode;i.lastIndex=0}for(var l=[];;){var c=wt(i,r);if(null===c)break;if(l.push(c),!a)break;""===String(c[0])&&(i.lastIndex=It(r,le(i.lastIndex),s))}for(var d,u="",f=0,_=0;_<l.length;_++){c=l[_];
// NOTE: This is equivalent to
//   captures = result.slice(1).map(maybeToString)
// but for some reason `nativeSlice.call(result, 1, result.length)` (called in
// the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
// causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
for(var S=String(c[0]),p=Ut(Ht(ae(c.index),r.length),0),E=[],h=1;h<c.length;h++)E.push(void 0===(d=c[h])?d:String(d));var A=c.groups;if(o){var m=[S].concat(E,p,r);void 0!==A&&m.push(A);var T=String(t.apply(void 0,m))}else T=L(S,r,p,E,A,t);f<=p&&(u+=r.slice(f,p)+T,f=p+S.length)}return u+r.slice(f)}];
// https://tc39.github.io/ecma262/#sec-getsubstitution
function L(o,a,s,l,c,e){var d=s+o.length,u=l.length,t=Vt;return void 0!==c&&(c=Rt(c),t=jt),g.call(e,t,function(e,t){var n;switch(t.charAt(0)){case"$":return"$";case"&":return o;case"`":return a.slice(0,s);case"'":return a.slice(d);case"<":n=c[t.slice(1,-1)];break;default:// \d\d?
var i=+t;if(0===i)return e;if(u<i){var r=kt(i/10);return 0===r?e:r<=u?void 0===l[r-1]?t.charAt(1):l[r-1]+t.charAt(1):e}n=l[i-1]}return void 0===n?"":n})}});var Wt=function(e){if("function"!=typeof e)throw TypeError(String(e)+" is not a function");return e},zt=Ue("species"),Xt=[].push,Yt=Math.min,Kt=4294967295,qt=!u(function(){return!RegExp(Kt,"y")});
// @@split logic
Bt("split",2,function(r,m,T){var g;
// based on es5-shim implementation, need to rework it
return g="c"=="abbc".split(/(b)*/)[1]||4!="test".split(/(?:)/,-1).length||2!="ab".split(/(?:ab)*/).length||4!=".".split(/(.?)(.?)/).length||1<".".split(/()()/).length||"".split(/.?/).length?function(e,t){var n=String(f(this)),i=void 0===t?Kt:t>>>0;if(0===i)return[];if(void 0===e)return[n];
// If `separator` is not a regex, use native split
if(!tt(e))return m.call(n,e,i);for(var r,o,a,s=[],l=(e.ignoreCase?"i":"")+(e.multiline?"m":"")+(e.unicode?"u":"")+(e.sticky?"y":""),c=0,d=new RegExp(e.source,l+"g");(r=Pt.call(d,n))&&!(c<(o=d.lastIndex)&&(s.push(n.slice(c,r.index)),1<r.length&&r.index<n.length&&Xt.apply(s,r.slice(1)),a=r[0].length,c=o,s.length>=i));)d.lastIndex===r.index&&d.lastIndex++;// Avoid an infinite loop
return c===n.length?!a&&d.test("")||s.push(""):s.push(n.slice(c)),s.length>i?s.slice(0,i):s}:"0".split(void 0,0).length?function(e,t){return void 0===e&&0===t?[]:m.call(this,e,t)}:m,[
// `String.prototype.split` method
// https://tc39.github.io/ecma262/#sec-string.prototype.split
function(e,t){var n=f(this),i=null==e?void 0:e[r];return void 0!==i?i.call(e,n,t):g.call(String(n),e,t)},
// `RegExp.prototype[@@split]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@split
//
// NOTE: This cannot be properly polyfilled in engines that don't support
// the 'y' flag.
function(e,t){var n=T(g,e,this,t,g!==m);if(n.done)return n.value;var i,r,o,a=w(e),s=String(this),l=(i=RegExp,void 0===(o=w(a).constructor)||null==(r=w(o)[zt])?i:Wt(r)),c=a.unicode,d=(a.ignoreCase?"i":"")+(a.multiline?"m":"")+(a.unicode?"u":"")+(qt?"y":"g"),u=new l(qt?a:"^(?:"+a.source+")",d),f=void 0===t?Kt:t>>>0;if(0===f)return[];if(0===s.length)return null===wt(u,s)?[s]:[];for(var _=0,S=0,p=[];S<s.length;){u.lastIndex=qt?S:0;var E,h=wt(u,qt?s:s.slice(S));if(null===h||(E=Yt(le(u.lastIndex+(qt?0:S)),s.length))===_)S=It(s,S,c);else{if(p.push(s.slice(_,S)),p.length===f)return p;for(var A=1;A<=h.length-1;A++)if(p.push(h[A]),p.length===f)return p;S=_=E}}return p.push(s.slice(_)),p}]},!qt),function(o,f,_){function S(e,t){return B(e)===t}function p(){return"function"!=typeof f.createElement?f.createElement(arguments[0]):A?f.createElementNS.call(f,"http://www.w3.org/2000/svg",arguments[0]):f.createElement.apply(f,arguments)}function r(e,t,n,i){var r,o,a,s,l,c="modernizr",d=p("div"),u=((l=f.body)||((l=p(A?"svg":"body")).fake=!0),l);if(parseInt(n,10))for(;n--;)(a=p("div")).id=i?i[n]:c+(n+1),d.appendChild(a);return(r=p("style")).type="text/css",r.id="s"+c,(u.fake?u:d).appendChild(r),u.appendChild(d),r.styleSheet?r.styleSheet.cssText=e:r.appendChild(f.createTextNode(e)),d.id=c,u.fake&&(u.style.background="",u.style.overflow="hidden",s=h.style.overflow,h.style.overflow="hidden",h.appendChild(u)),o=t(d,e),u.fake?(u.parentNode.removeChild(u),h.style.overflow=s,h.offsetHeight):d.parentNode.removeChild(d),!!o}function a(e){return e.replace(/([A-Z])/g,function(e,t){return"-"+t.toLowerCase()}).replace(/^ms-/,"-ms-")}function E(e,t){var n=e.length;if("CSS"in o&&"supports"in o.CSS){for(;n--;)if(o.CSS.supports(a(e[n]),t))return!0;return!1}if("CSSSupportsRule"in o){for(var i=[];n--;)i.push("("+a(e[n])+":"+t+")");return r("@supports ("+(i=i.join(" or "))+") { #modernizr { position: absolute; } }",function(e){return"absolute"===function(e,t,n){var i;if("getComputedStyle"in o){i=getComputedStyle.call(o,e,t);var r=o.console;null!==i?n&&(i=i.getPropertyValue(n)):r&&r[r.error?"error":"log"].call(r,"getComputedStyle returning null, its possible modernizr test results are inaccurate")}else i=!t&&e.currentStyle&&e.currentStyle[n];return i}(e,null,"position")})}return _}function s(e,t){return function(){return e.apply(t,arguments)}}function i(e,t,n,i,r){var o=e.charAt(0).toUpperCase()+e.slice(1),a=(e+" "+u.join(o+" ")+o).split(" ");return S(t,"string")||S(t,"undefined")?function(e,t,n,i){function r(){a&&(delete T.style,delete T.modElem)}if(i=!S(i,"undefined")&&i,!S(n,"undefined")){var o=E(e,n);if(!S(o,"undefined"))return o}for(var a,s,l,c,d,u=["modernizr","tspan","samp"];!T.style&&u.length;)a=!0,T.modElem=p(u.shift()),T.style=T.modElem.style;for(l=e.length,s=0;s<l;s++)if(c=e[s],d=T.style[c],!!~(""+c).indexOf("-")&&(c=c.replace(/([a-z])-([a-z])/g,function(e,t,n){return t+n.toUpperCase()}).replace(/^-/,"")),T.style[c]!==_){if(i||S(n,"undefined"))return r(),"pfx"!==t||c;try{T.style[c]=n}catch(e){}if(T.style[c]!==d)return r(),"pfx"!==t||c}return r(),!1}(a,t,i,r):function(e,t,n){var i;for(var r in e)if(e[r]in t)return!1===n?e[r]:S(i=t[e[r]],"function")?s(i,n||t):i;return!1}(a=(e+" "+g.join(o+" ")+o).split(" "),t,n)}function e(e,t,n){return i(e,_,_,t,n)}var l=[],t={_version:"3.7.0",_config:{classPrefix:"",enableClasses:!0,enableJSClass:!0,usePrefixes:!0},_q:[],on:function(e,t){var n=this;setTimeout(function(){t(n[e])},0)},addTest:function(e,t,n){l.push({name:e,fn:t,options:n})},addAsyncTest:function(e){l.push({name:null,fn:e})}},c=function(){};c.prototype=t,c=new c;var d=[],h=f.documentElement,A="svg"===h.nodeName.toLowerCase(),n="Moz O ms Webkit",u=t._config.usePrefixes?n.split(" "):[];t._cssomPrefixes=u;var m={elem:p("modernizr")};c._q.push(function(){delete m.elem});var T={style:m.elem.style};c._q.unshift(function(){delete T.style});var g=t._config.usePrefixes?n.toLowerCase().split(" "):[];t._domPrefixes=g,t.testAllProps=i,t.testAllProps=e,c.addTest("cssgridlegacy",e("grid-columns","10px",!0)),c.addTest("cssgrid",e("grid-template-rows","none",!0)),function(){var e,t,n,i,r,o;for(var a in l)if(l.hasOwnProperty(a)){if(e=[],(t=l[a]).name&&(e.push(t.name.toLowerCase()),t.options&&t.options.aliases&&t.options.aliases.length))for(n=0;n<t.options.aliases.length;n++)e.push(t.options.aliases[n].toLowerCase());for(i=S(t.fn,"function")?t.fn():t.fn,r=0;r<e.length;r++)1===(o=e[r].split(".")).length?c[o[0]]=i:(!c[o[0]]||c[o[0]]instanceof Boolean||(c[o[0]]=new Boolean(c[o[0]])),c[o[0]][o[1]]=i),d.push((i?"":"no-")+o.join("-"))}}(),function(e){var t=h.className,n=c._config.classPrefix||"";if(A&&(t=t.baseVal),c._config.enableJSClass){var i=new RegExp("(^|\\s)"+n+"no-js(\\s|$)");t=t.replace(i,"$1"+n+"js$2")}c._config.enableClasses&&(0<e.length&&(t+=" "+n+e.join(" "+n)),A?h.className.baseVal=t:h.className=t)}(d),delete t.addTest,delete t.addAsyncTest;for(var C=0;C<c._q.length;C++)c._q[C]();o.Modernizr=c}(window,document);var $t=F.f,Jt=Ue("toStringTag"),Qt=function(e,t,n){e&&!I(e=n?e:e.prototype,Jt)&&$t(e,Jt,{configurable:!0,value:t})},Zt={f:Ue},en=F.f,tn=function(e){var t=it.Symbol||(it.Symbol={});I(t,e)||en(t,e,{value:Zt.f(e)})},nn=Object.keys||function(e){return Se(e,pe)},rn=A?Object.defineProperties:function(e,t){w(e);for(var n,i=nn(t),r=i.length,o=0;o<r;)F.f(e,n=i[o++],t[n]);return e},on=h.document,an=on&&on.documentElement,sn=K("IE_PROTO"),ln="prototype",cn=function(){/* empty */},dn=function(){
// Thrash, waste and sodomy: IE GC bug
var e,t=N("iframe"),n=pe.length,i="script";for(t.style.display="none",an.appendChild(t),t.src=String("javascript:"),(e=t.contentWindow.document).open(),e.write("<script>document.F=Object</"+i+">"),e.close(),dn=e.F;n--;)delete dn[ln][pe[n]];return dn()},un=Object.create||function(e,t){var n;return null!==e?(cn[ln]=w(e),n=new cn,cn[ln]=null,
// add "__proto__" for Object.getPrototypeOf polyfill
n[sn]=e):n=dn(),void 0===t?n:rn(n,t)};q[sn]=!0;
// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var fn=he.f,_n={}.toString,Sn="object"==typeof window&&window&&Object.getOwnPropertyNames?Object.getOwnPropertyNames(window):[],pn={f:function(e){return Sn&&"[object Window]"==_n.call(e)?function(e){try{return fn(e)}catch(e){return Sn.slice()}}(e):fn(c(e))}},En=K("hidden"),hn="Symbol",An=ne.set,mn=ne.getterFor(hn),Tn=P.f,gn=F.f,Cn=pn.f,Ln=h.Symbol,On=h.JSON,Rn=On&&On.stringify,vn="prototype",In=Ue("toPrimitive"),yn=C.f,bn=H("symbol-registry"),Nn=H("symbols"),Dn=H("op-symbols"),Mn=H("wks"),Pn=Object[vn],wn=h.QObject,Gn=!wn||!wn[vn]||!wn[vn].findChild,Fn=A&&u(function(){return 7!=un(gn({},"a",{get:function(){return gn(this,"a",{value:7}).a}})).a})?function(e,t,n){var i=Tn(Pn,t);i&&delete Pn[t],gn(e,t,n),i&&e!==Pn&&gn(Pn,t,i)}:gn,xn=function(e,t){var n=Nn[e]=un(Ln[vn]);return An(n,{type:hn,tag:e,description:t}),A||(n.description=t),n},Bn=Fe&&"symbol"==typeof Ln.iterator?function(e){return"symbol"==typeof e}:function(e){return Object(e)instanceof Ln},Un=function(e,t,n){return e===Pn&&Un(Dn,t,n),w(e),t=R(t,!0),w(n),I(Nn,t)?(n.enumerable?(I(e,En)&&e[En][t]&&(e[En][t]=!1),n=un(n,{enumerable:L(0,!1)})):(I(e,En)||gn(e,En,L(1,{})),e[En][t]=!0),Fn(e,t,n)):gn(e,t,n)},Hn=function(e,t){w(e);for(var n,i=function(e){var t=nn(e),n=Ae.f;if(n)for(var i,r=n(e),o=C.f,a=0;r.length>a;)o.call(e,i=r[a++])&&t.push(i);return t}(t=c(t)),r=0,o=i.length;r<o;)Un(e,n=i[r++],t[n]);return e},kn=function(e){var t=yn.call(this,e=R(e,!0));return!(this===Pn&&I(Nn,e)&&!I(Dn,e))&&(!(t||!I(this,e)||!I(Nn,e)||I(this,En)&&this[En][e])||t)},jn=function(e,t){if(e=c(e),t=R(t,!0),e!==Pn||!I(Nn,t)||I(Dn,t)){var n=Tn(e,t);return!n||!I(Nn,t)||I(e,En)&&e[En][t]||(n.enumerable=!0),n}},Vn=function(e){for(var t,n=Cn(c(e)),i=[],r=0;n.length>r;)I(Nn,t=n[r++])||I(q,t)||i.push(t);return i},Wn=function(e){for(var t,n=e===Pn,i=Cn(n?Dn:c(e)),r=[],o=0;i.length>o;)!I(Nn,t=i[o++])||n&&!I(Pn,t)||r.push(Nn[t]);return r};
// `Symbol` constructor
// https://tc39.github.io/ecma262/#sec-symbol-constructor
Fe||(ie((Ln=function(){if(this instanceof Ln)throw TypeError("Symbol is not a constructor");var e=void 0===arguments[0]?void 0:String(arguments[0]),t=X(e),n=function(e){this===Pn&&n.call(Dn,e),I(this,En)&&I(this[En],t)&&(this[En][t]=!1),Fn(this,t,L(1,e))};return A&&Gn&&Fn(Pn,t,{configurable:!0,set:n}),xn(t,e)})[vn],"toString",function(){return mn(this).tag}),C.f=kn,F.f=Un,P.f=jn,he.f=pn.f=Vn,Ae.f=Wn,A&&(
// https://github.com/tc39/proposal-Symbol-description
gn(Ln[vn],"description",{configurable:!0,get:function(){return mn(this).description}}),ie(Pn,"propertyIsEnumerable",kn,{unsafe:!0})),Zt.f=function(e){return xn(Ue(e),e)}),Ne({global:!0,wrap:!0,forced:!Fe,sham:!Fe},{Symbol:Ln});for(var zn=nn(Mn),Xn=0;zn.length>Xn;)tn(zn[Xn++]);Ne({target:hn,stat:!0,forced:!Fe},{
// `Symbol.for` method
// https://tc39.github.io/ecma262/#sec-symbol.for
for:function(e){return I(bn,e+="")?bn[e]:bn[e]=Ln(e)},
// `Symbol.keyFor` method
// https://tc39.github.io/ecma262/#sec-symbol.keyfor
keyFor:function(e){if(!Bn(e))throw TypeError(e+" is not a symbol");for(var t in bn)if(bn[t]===e)return t},useSetter:function(){Gn=!0},useSimple:function(){Gn=!1}}),Ne({target:"Object",stat:!0,forced:!Fe,sham:!A},{
// `Object.create` method
// https://tc39.github.io/ecma262/#sec-object.create
create:function(e,t){return void 0===t?un(e):Hn(un(e),t)},
// `Object.defineProperty` method
// https://tc39.github.io/ecma262/#sec-object.defineproperty
defineProperty:Un,
// `Object.defineProperties` method
// https://tc39.github.io/ecma262/#sec-object.defineproperties
defineProperties:Hn,
// `Object.getOwnPropertyDescriptor` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertydescriptors
getOwnPropertyDescriptor:jn}),Ne({target:"Object",stat:!0,forced:!Fe},{
// `Object.getOwnPropertyNames` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertynames
getOwnPropertyNames:Vn,
// `Object.getOwnPropertySymbols` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertysymbols
getOwnPropertySymbols:Wn}),
// Chrome 38 and 39 `Object.getOwnPropertySymbols` fails on primitives
// https://bugs.chromium.org/p/v8/issues/detail?id=3443
Ne({target:"Object",stat:!0,forced:u(function(){Ae.f(1)})},{getOwnPropertySymbols:function(e){return Ae.f(Rt(e))}}),
// `JSON.stringify` method behavior with symbols
// https://tc39.github.io/ecma262/#sec-json.stringify
On&&Ne({target:"JSON",stat:!0,forced:!Fe||u(function(){var e=Ln();
// MS Edge converts symbol values to JSON as {}
return"[null]"!=Rn([e])||"{}"!=Rn({a:e})||"{}"!=Rn(Object(e))})},{stringify:function(e){for(var t,n,i=[e],r=1;arguments.length>r;)i.push(arguments[r++]);if(n=t=i[1],(O(t)||void 0!==e)&&!Bn(e))// IE8 returns string on undefined
return we(t)||(t=function(e,t){if("function"==typeof n&&(t=n.call(this,e,t)),!Bn(t))return t}),i[1]=t,Rn.apply(On,i)}}),
// `Symbol.prototype[@@toPrimitive]` method
// https://tc39.github.io/ecma262/#sec-symbol.prototype-@@toprimitive
Ln[vn][In]||x(Ln[vn],In,Ln[vn].valueOf),
// `Symbol.prototype[@@toStringTag]` property
// https://tc39.github.io/ecma262/#sec-symbol.prototype-@@tostringtag
Qt(Ln,hn),q[En]=!0;var Yn=F.f,Kn=h.Symbol;if(A&&"function"==typeof Kn&&(!("description"in Kn.prototype)||
// Safari 12 bug
void 0!==Kn().description)){var qn={},$n=function(){var e=arguments.length<1||void 0===arguments[0]?void 0:String(arguments[0]),t=this instanceof $n?new Kn(e):void 0===e?Kn():Kn(e);return""===e&&(qn[t]=!0),t};
// wrap Symbol constructor for correct work with undefined description
ge($n,Kn);var Jn=$n.prototype=Kn.prototype;Jn.constructor=$n;var Qn=Jn.toString,Zn="Symbol(test)"==String(Kn("test")),ei=/^Symbol\((.*)\)[^)]+$/;Yn(Jn,"description",{configurable:!0,get:function(){var e=O(this)?this.valueOf():this,t=Qn.call(e);if(I(qn,e))return"";var n=Zn?t.slice(7,-1):t.replace(ei,"$1");return""===n?void 0:n}}),Ne({global:!0,forced:!0},{Symbol:$n})}
// `Symbol.iterator` well-known symbol
// https://tc39.github.io/ecma262/#sec-symbol.iterator
tn("iterator");var ti=Ue("unscopables"),ni=Array.prototype;
// Array.prototype[@@unscopables]
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
null==ni[ti]&&x(ni,ti,un(null));
// add a key to Array.prototype[@@unscopables]
var ii,ri,oi,ai=function(e){ni[ti][e]=!0},si=!u(function(){function e(){/* empty */}return e.prototype.constructor=null,Object.getPrototypeOf(new e)!==e.prototype}),li=K("IE_PROTO"),ci=Object.prototype,di=si?Object.getPrototypeOf:function(e){return e=Rt(e),I(e,li)?e[li]:"function"==typeof e.constructor&&e instanceof e.constructor?e.constructor.prototype:e instanceof Object?ci:null},ui=Ue("iterator"),fi=!1;[].keys&&(
// Safari 8 has buggy iterators w/o `next`
"next"in(oi=[].keys())?(ri=di(di(oi)))!==Object.prototype&&(ii=ri):fi=!0),null==ii&&(ii={}),
// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
I(ii,ui)||x(ii,ui,function(){return this});var _i={IteratorPrototype:ii,BUGGY_SAFARI_ITERATORS:fi},Si=_i.IteratorPrototype,pi=Ue("iterator"),Ei=_i.IteratorPrototype,hi=_i.BUGGY_SAFARI_ITERATORS,Ai="values",mi="entries",Ti=function(){return this},gi=function(e,t,n,i,r,o,a){var s,l,c;l=i,c=t+" Iterator",(s=n).prototype=un(Si,{next:L(1,l)}),Qt(s,c,!1);var d,u,f,_=function(e){if(e===r&&A)return A;if(!hi&&e in E)return E[e];switch(e){case"keys":case Ai:case mi:return function(){return new n(this,e)}}return function(){return new n(this)}},S=t+" Iterator",p=!1,E=e.prototype,h=E[pi]||E["@@iterator"]||r&&E[r],A=!hi&&h||_(r),m="Array"==t&&E.entries||h;
// export additional methods
if(
// fix native
m&&(d=di(m.call(new e)),Ei!==Object.prototype&&d.next&&(di(d)!==Ei&&(Qe?Qe(d,Ei):"function"!=typeof d[pi]&&x(d,pi,Ti)),
// Set @@toStringTag to native iterators
Qt(d,S,!0))),
// fix Array#{values, @@iterator}.name in V8 / FF
r==Ai&&h&&h.name!==Ai&&(p=!0,A=function(){return h.call(this)}),
// define iterator
E[pi]!==A&&x(E,pi,A),r)if(u={values:_(Ai),keys:o?A:_("keys"),entries:_(mi)},a)for(f in u)!hi&&!p&&f in E||ie(E,f,u[f]);else Ne({target:t,proto:!0,forced:hi||p},u);return u},Ci="Array Iterator",Li=ne.set,Oi=ne.getterFor(Ci),Ri=gi(Array,"Array",function(e,t){Li(this,{type:Ci,target:c(e),// target
index:0,// next index
kind:t});
// `%ArrayIteratorPrototype%.next` method
// https://tc39.github.io/ecma262/#sec-%arrayiteratorprototype%.next
},function(){var e=Oi(this),t=e.target,n=e.kind,i=e.index++;return!t||i>=t.length?{value:e.target=void 0,done:!0}:"keys"==n?{value:i,done:!1}:"values"==n?{value:t[i],done:!1}:{value:[i,t[i]],done:!1}},"values");
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
ai("keys"),ai("values"),ai("entries");
// optional / simple context binding
var vi=Ue("species"),Ii=function(e,t){var n;return we(e)&&(
// cross-realm fallback
"function"!=typeof(n=e.constructor)||n!==Array&&!we(n.prototype)?O(n)&&null===(n=n[vi])&&(n=void 0):n=void 0),new(void 0===n?Array:n)(0===t?0:t)},yi=function(u,e){var f=1==u,_=2==u,S=3==u,p=4==u,E=6==u,h=5==u||E,A=e||Ii;return function(e,t,n){for(var i,r,o=Rt(e),a=m(o),s=function(i,r,e){if(Wt(i),void 0===r)return i;switch(e){case 0:return function(){return i.call(r)};case 1:return function(e){return i.call(r,e)};case 2:return function(e,t){return i.call(r,e,t)};case 3:return function(e,t,n){return i.call(r,e,t,n)}}return function(){return i.apply(r,arguments)}}(t,n,3),l=le(a.length),c=0,d=f?A(e,l):_?A(e,0):void 0;c<l;c++)if((h||c in a)&&(r=s(i=a[c],c,o),u))if(f)d[c]=r;// map
else if(r)switch(u){case 3:return!0;// some
case 5:return i;// find
case 6:return c;// findIndex
case 2:d.push(i);// filter
}else if(p)return!1;// every
return E?-1:S||p?p:d}},bi=yi(1),Ni=ke("map");
// `Array.prototype.map` method
// https://tc39.github.io/ecma262/#sec-array.prototype.map
// with adding support of @@species
Ne({target:"Array",proto:!0,forced:!Ni},{map:function(e/* , thisArg */){return bi(this,e,arguments[1])}});var Di=[].sort,Mi=[1,2,3],Pi=u(function(){Mi.sort(void 0)}),wi=u(function(){Mi.sort(null)}),Gi=d("sort");
// `Array.prototype.sort` method
// https://tc39.github.io/ecma262/#sec-array.prototype.sort
Ne({target:"Array",proto:!0,forced:Pi||!wi||Gi},{sort:function(e){return void 0===e?Di.call(Rt(this)):Di.call(Rt(this),Wt(e))}});var Fi=Ue("toStringTag"),xi="Arguments"==s(function(){return arguments}()),Bi={};
// ES3 wrong here
Bi[Ue("toStringTag")]="z";
// `Object.prototype.toString` method implementation
// https://tc39.github.io/ecma262/#sec-object.prototype.tostring
var Ui="[object z]"!==String(Bi)?function(){return"[object "+(void 0===(e=this)?"Undefined":null===e?"Null":"string"==typeof(n=function(e,t){try{return e[t]}catch(e){/* empty */}}(t=Object(e),Fi))?n:xi?s(t):"Object"==(i=s(t))&&"function"==typeof t.callee?"Arguments":i)+"]";var e,t,n,i}:Bi.toString,Hi=Object.prototype;
// `Object.prototype.toString` method
// https://tc39.github.io/ecma262/#sec-object.prototype.tostring
Ui!==Hi.toString&&ie(Hi,"toString",Ui,{unsafe:!0});var ki="String Iterator",ji=ne.set,Vi=ne.getterFor(ki);
// `String.prototype[@@iterator]` method
// https://tc39.github.io/ecma262/#sec-string.prototype-@@iterator
gi(String,"String",function(e){ji(this,{type:ki,string:String(e),index:0});
// `%StringIteratorPrototype%.next` method
// https://tc39.github.io/ecma262/#sec-%stringiteratorprototype%.next
},function(){var e,t=Vi(this),n=t.string,i=t.index;return i>=n.length?{value:void 0,done:!0}:(e=vt(n,i,!0),t.index+=e.length,{value:e,done:!1})});
// iterable DOM collections
// flag - `iterable` interface - 'entries', 'keys', 'values', 'forEach' methods
var Wi={CSSRuleList:0,CSSStyleDeclaration:0,CSSValueList:0,ClientRectList:0,DOMRectList:0,DOMStringList:0,DOMTokenList:1,DataTransferItemList:0,FileList:0,HTMLAllCollection:0,HTMLCollection:0,HTMLFormElement:0,HTMLSelectElement:0,MediaList:0,MimeTypeArray:0,NamedNodeMap:0,NodeList:1,PaintRequestList:0,Plugin:0,PluginArray:0,SVGLengthList:0,SVGNumberList:0,SVGPathSegList:0,SVGPointList:0,SVGStringList:0,SVGTransformList:0,SourceBufferList:0,StyleSheetList:0,TextTrackCueList:0,TextTrackList:0,TouchList:0},zi=Ue("iterator"),Xi=Ue("toStringTag"),Yi=Ri.values;for(var Ki in Wi){var qi=h[Ki],$i=qi&&qi.prototype;if($i){
// some Chrome versions have non-configurable methods on DOMTokenList
if($i[zi]!==Yi)try{x($i,zi,Yi)}catch(e){$i[zi]=Yi}if($i[Xi]||x($i,Xi,Ki),Wi[Ki])for(var Ji in Ri)
// some Chrome versions have non-configurable methods on DOMTokenList
if($i[Ji]!==Ri[Ji])try{x($i,Ji,Ri[Ji])}catch(e){$i[Ji]=Ri[Ji]}}}var Qi,Zi={init:(Qi={stateToCountyMapping:{},
// builds an object that contains all valid counties by state
buildStateToCountyMapping:function(){Qi.stateToCountyMapping={NC:["Alamance","Alexander","Alleghany","Anson","Ashe","Avery","Beaufort","Bertie","Bladen","Brunswick","Buncombe","Burke","Cabarrus","Caldwell","Camden","Carteret","Caswell","Catawba","Chatham","Cherokee","Chowan","Clay","Cleveland","Columbus","Craven","Cumberland","Currituck","Dare","Davidson","Davie","Duplin","Durham","Edgecombe","Forsyth","Franklin","Gaston","Gates","Graham","Granville","Greene","Guilford","Halifax","Harnett","Haywood","Henderson","Hertford","Hoke","Hyde","Iredell","Jackson","Johnston","Jones","Lee","Lenoir","Lincoln","Macon","Madison","Martin","Mcdowell","Mecklenburg","Mitchell","Montgomery","Moore","Nash","New Hanover","Northampton","Onslow","Orange","Pamlico","Pasquotank","Pender","Perquimans","Person","Pitt","Polk","Randolph","Richmond","Robeson","Rockingham","Rowan","Rutherford","Sampson","Scotland","Stanly","Stokes","Surry","Swain","Transylvania","Tyrrell","Union","Vance","Wake","Warren","Washington","Watauga","Wayne","Wilkes","Wilson","Yadkin","Yancey"],AL:["Autauga","Baldwin","Barbour","Bibb","Blount","Bullock","Butler","Calhoun","Chambers","Cherokee","Chilton","Choctaw","Clarke","Clay","Cleburne","Coffee","Colbert","Conecuh","Coosa","Covington","Crenshaw","Cullman","Dale","Dallas","Dekalb","Elmore","Escambia","Etowah","Fayette","Franklin","Geneva","Greene","Hale","Henry","Houston","Jackson","Jefferson","Lamar","Lauderdale","Lawrence","Lee","Limestone","Lowndes","Macon","Madison","Marengo","Marion","Marshall","Mobile","Monroe","Montgomery","Morgan","Perry","Pickens","Pike","Randolph","Russell","Shelby","St. Clair","Sumter","Talladega","Tallapoosa","Tuscaloosa","Walker","Washington","Wilcox","Winston"],DC:["District Of Columbia"],DE:["Kent","New Castle","Sussex"],FL:["Alachua","Baker","Bay","Bradford","Brevard","Broward","Calhoun","Charlotte","Citrus","Clay","Collier","Columbia","Desoto","Dixie","Duval","Escambia","Flagler","Franklin","Gadsden","Gilchrist","Glades","Gulf","Hamilton","Hardee","Hendry","Hernando","Highlands","Hillsborough","Holmes","Indian River","Jackson","Jefferson","Lafayette","Lake","Lee","Leon","Levy","Liberty","Madison","Manatee","Marion","Martin","Miami-dade","Monroe","Nassau","Okaloosa","Okeechobee","Orange","Osceola","Palm Beach","Pasco","Pinellas","Polk","Putnam","Santa Rosa","Sarasota","Seminole","St. Johns","St. Lucie","Sumter","Suwannee","Taylor","Union","Volusia","Wakulla","Walton","Washington"],GA:["Appling","Atkinson","Bacon","Baker","Baldwin","Banks","Barrow","Bartow","Ben Hill","Berrien","Bibb","Bleckley","Brantley","Brooks","Bryan","Bulloch","Burke","Butts","Calhoun","Camden","Candler","Carroll","Catoosa","Charlton","Chatham","Chattahoochee","Chattooga","Cherokee","Clarke","Clay","Clayton","Clinch","Cobb","Coffee","Colquitt","Columbia","Cook","Coweta","Crawford","Crisp","Dade","Dawson","Decatur","Dekalb","Dodge","Dooly","Dougherty","Douglas","Early","Echols","Effingham","Elbert","Emanuel","Evans","Fannin","Fayette","Floyd","Forsyth","Franklin","Fulton","Gilmer","Glascock","Glynn","Gordon","Grady","Greene","Gwinnett","Habersham","Hall","Hancock","Haralson","Harris","Hart","Heard","Henry","Houston","Irwin","Jackson","Jasper","Jeff Davis","Jefferson","Jenkins","Johnson","Jones","Lamar","Lanier","Laurens","Lee","Liberty","Lincoln","Long","Lowndes","Lumpkin","Macon","Madison","Marion","Mcduffie","Mcintosh","Meriwether","Miller","Mitchell","Monroe","Montgomery","Morgan","Murray","Muscogee","Newton","Oconee","Oglethorpe","Paulding","Peach","Pickens","Pierce","Pike","Polk","Pulaski","Putnam","Quitman","Rabun","Randolph","Richmond","Rockdale","Schley","Screven","Seminole","Spalding","Stephens","Stewart","Sumter","Talbot","Taliaferro","Tattnall","Taylor","Telfair","Terrell","Thomas","Tift","Toombs","Towns","Treutlen","Troup","Turner","Twiggs","Union","Upson","Walker","Walton","Ware","Warren","Washington","Wayne","Webster","Wheeler","White","Whitfield","Wilcox","Wilkes","Wilkinson","Worth"],IN:["Adams","Allen","Bartholomew","Benton","Blackford","Boone","Brown","Carroll","Cass","Clark","Clay","Clinton","Crawford","Daviess","De Kalb","Dearborn","Decatur","Delaware","Dubois","Elkhart","Fayette","Floyd","Fountain","Franklin","Fulton","Gibson","Grant","Greene","Hamilton","Hancock","Harrison","Hendricks","Henry","Howard","Huntington","Jackson","Jasper","Jay","Jefferson","Jennings","Johnson","Knox","Kosciusko","La Porte","Lagrange","Lake","Lawrence","Madison","Marion","Marshall","Martin","Miami","Monroe","Montgomery","Morgan","Newton","Noble","Ohio","Orange","Owen","Parke","Perry","Pike","Porter","Posey","Pulaski","Putnam","Randolph","Ripley","Rush","Scott","Shelby","Spencer","St. Joseph","Starke","Steuben","Sullivan","Switzerland","Tippecanoe","Tipton","Union","Vanderburgh","Vermillion","Vigo","Wabash","Warren","Warrick","Washington","Wayne","Wells","White","Whitley"],KY:["Adair","Allen","Anderson","Ballard","Barren","Bath","Bell","Boone","Bourbon","Boyd","Boyle","Bracken","Breathitt","Breckenridge","Bullitt","Butler","Caldwell","Calloway","Campbell","Carlisle","Carroll","Carter","Casey","Christian","Clark","Clay","Clinton","Crittenden","Cumberland","Daviess","Edmonson","Elliott","Estill","Fayette","Fleming","Floyd","Franklin","Fulton","Gallatin","Garrard","Grant","Graves","Grayson","Green","Greenup","Hancock","Hardin","Harlan","Harrison","Hart","Henderson","Henry","Hickman","Hopkins","Jackson","Jefferson","Jessamine","Johnson","Kenton","Knott","Knox","Larue","Laurel","Lawrence","Lee","Leslie","Letcher","Lewis","Lincoln","Livingston","Logan","Lyon","Madison","Magoffin","Marion","Marshall","Martin","Mason","Mccracken","Mccreary","Mclean","Meade","Menifee","Mercer","Metcalfe","Monroe","Montgomery","Morgan","Muhlenberg","Nelson","Nicholas","Ohio","Oldham","Owen","Owsley","Pendleton","Perry","Pike","Powell","Pulaski","Robertson","Rockcastle","Rowan","Russell","Scott","Shelby","Simpson","Spencer","Taylor","Todd","Trigg","Trimble","Union","Warren","Washington","Wayne","Webster","Whitley","Wolfe","Woodford"],MD:["Allegany","Anne Arundel","Baltimore","Baltimore City","Calvert","Caroline","Carroll","Cecil","Charles","Dorchester","Frederick","Garrett","Harford","Howard","Kent","Montgomery","Prince Georges","Queen Annes","Somerset","St.mary","Talbot","Washington","Wicomico","Worcester"],NJ:["Atlantic","Bergen","Burlington","Camden","Cape May","Cumberland","Essex","Gloucester","Hudson","Hunterdon","Mercer","Middlesex","Monmouth","Morris","Ocean","Passaic","Salem","Somerset","Sussex","Union","Warren"],OH:["Adams","Allen","Ashland","Ashtabula","Athens","Auglaize","Belmont","Brown","Butler","Carroll","Champaign","Clark","Clermont","Clinton","Columbiana","Coshocton","Crawford","Cuyahoga","Darke","Defiance","Delaware","Erie","Fairfield","Fayette","Franklin","Fulton","Gallia","Geauga","Greene","Guernsey","Hamilton","Hancock","Hardin","Harrison","Henry","Highland","Hocking","Holmes","Huron","Jackson","Jefferson","Knox","Lake","Lawrence","Licking","Logan","Lorain","Lucas","Madison","Mahoning","Marion","Medina","Meigs","Mercer","Miami","Monroe","Montgomery","Morgan","Morrow","Muskingum","Noble","Ottawa","Paulding","Perry","Pickaway","Pike","Portage","Preble","Putnam","Richland","Ross","Sandusky","Scioto","Seneca","Shelby","Stark","Summit","Trumbull","Tuscarawas","Union","Van Wert","Vinton","Warren","Washington","Wayne","Williams","Wood","Wyandot"],PA:["Adams","Allegheny","Armstrong","Beaver","Bedford","Berks","Blair","Bradford","Bucks","Butler","Cambria","Cameron","Carbon","Centre","Chester","Clarion","Clearfield","Clinton","Columbia","Crawford","Cumberland","Dauphin","Delaware","Elk","Erie","Fayette","Forest","Franklin","Fulton","Greene","Huntingdon","Indiana","Jefferson","Juniata","Lackawanna","Lancaster","Lawrence","Lebanon","Lehigh","Luzerne","Lycoming","Mckean","Mercer","Mifflin","Monroe","Montgomery","Montour","Northampton","Northumberland","Perry","Philadelphia","Pike","Potter","Schuylkill","Snyder","Somerset","Sullivan","Susquehanna","Tioga","Union","Venango","Warren","Washington","Wayne","Westmoreland","Wyoming","York"],SC:["Abbeville","Aiken","Allendale","Anderson","Bamberg","Barnwell","Beaufort","Berkeley","Calhoun","Charleston","Cherokee","Chester","Chesterfield","Clarendon","Colleton","Darlington","Dillon","Dorchester","Edgefield","Fairfield","Florence","Georgetown","Greenville","Greenwood","Hampton","Horry","Jasper","Kershaw","Lancaster","Laurens","Lee","Lexington","Marion","Marlboro","Mccormick","Newberry","Oconee","Orangeburg","Pickens","Richland","Saluda","Spartanburg","Sumter","Union","Williamsburg","York"],TN:["Anderson","Bedford","Benton","Bledsoe","Blount","Bradley","Campbell","Cannon","Carroll","Carter","Cheatham","Chester","Claiborne","Clay","Cocke","Coffee","Crockett","Cumberland","Davidson","Decatur","Dekalb","Dickson","Dyer","Fayette","Fentress","Franklin","Gibson","Giles","Grainger","Greene","Grundy","Hamblen","Hamilton","Hancock","Hardeman","Hardin","Hawkins","Haywood","Henderson","Henry","Hickman","Houston","Humphreys","Jackson","Jefferson","Johnson","Knox","Lake","Lauderdale","Lawrence","Lewis","Lincoln","Loudon","Macon","Madison","Marion","Marshall","Maury","Mcminn","Mcnairy","Meigs","Monroe","Montgomery","Moore","Morgan","Obion","Overton","Perry","Pickett","Polk","Putnam","Rhea","Roane","Robertson","Rutherford","Scott","Sequatchie","Sevier","Shelby","Smith","Stewart","Sullivan","Sumner","Tipton","Trousdale","Unicoi","Union","Van Buren","Warren","Washington","Wayne","Weakley","White","Williamson","Wilson"],TX:["Anderson","Andrews","Angelina","Aransas","Archer","Armstrong","Atascosa","Austin","Bailey","Bandera","Bastrop","Baylor","Bee","Bell","Bexar","Blanco","Borden","Bosque","Bowie","Brazoria","Brazos","Brewster","Briscoe","Brooks","Brown","Burleson","Burnet","Caldwell","Calhoun","Callahan","Cameron","Camp","Carson","Cass","Castro","Chambers","Cherokee","Childress","Clay","Cochran","Coke","Coleman","Collin","Collingsworth","Colorado","Comal","Comanche","Concho","Cooke","Coryell","Cottle","Crane","Crockett","Crosby","Culberson","Dallam","Dallas","Dawson","Deaf Smith","Delta","Denton","Dewitt","Dickens","Dimmit","Donley","Duval","Eastland","Ector","Edwards","El Paso","Ellis","Erath","Falls","Fannin","Fayette","Fisher","Floyd","Foard","Fort Bend","Franklin","Freestone","Frio","Gaines","Galveston","Garza","Gillespie","Glasscock","Goliad","Gonzales","Gray","Grayson","Gregg","Grimes","Guadalupe","Hale","Hall","Hamilton","Hansford","Hardeman","Hardin","Harris","Harrison","Hartley","Haskell","Hays","Hemphill","Henderson","Hidalgo","Hill","Hockley","Hood","Hopkins","Houston","Howard","Hudspeth","Hunt","Hutchinson","Irion","Jack","Jackson","Jasper","Jeff Davis","Jefferson","Jim Hogg","Jim Wells","Johnson","Jones","Karnes","Kaufman","Kendall","Kenedy","Kent","Kerr","Kimble","King","Kinney","Kleberg","Knox","La Salle","Lamar","Lamb","Lampasas","Lavaca","Lee","Leon","Liberty","Limestone","Lipscomb","Live Oak","Llano","Loving","Lubbock","Lynn","Madison","Marion","Martin","Mason","Matagorda","Maverick","Mcculloch","Mclennan","Mcmullen","Medina","Menard","Midland","Milam","Mills","Mitchell","Montague","Montgomery","Moore","Morris","Motley","Nacogdoches","Navarro","Newton","Nolan","Nueces","Ochiltree","Oldham","Orange","Palo Pinto","Panola","Parker","Parmer","Pecos","Polk","Potter","Presidio","Rains","Randall","Reagan","Real","Red River","Reeves","Refugio","Roberts","Robertson","Rockwall","Runnels","Rusk","Sabine","San Augustine","San Jacinto","San Patricio","San Saba","Schleicher","Scurry","Shackelford","Shelby","Sherman","Smith","Somervell","Starr","Stephens","Sterling","Stonewall","Sutton","Swisher","Tarrant","Taylor","Terrell","Terry","Throckmorton","Titus","Tom Green","Travis","Trinity","Tyler","Upshur","Upton","Uvalde","Val Verde","Van Zandt","Victoria","Walker","Waller","Ward","Washington","Webb","Wharton","Wheeler","Wichita","Wilbarger","Willacy","Williamson","Wilson","Winkler","Wise","Wood","Yoakum","Young","Zapata","Zavala"],VA:["Accomack","Albemarle","Alexandria","Alleghany","Amelia","Amherst","Appomattox","Arlington","Augusta","Bath","Bedford","Bedford City Of","Bland","Botetourt","Bristol","Brunswick","Buchanan","Buckingham","Buena Vista","Campbell","Caroline","Carroll","Charles City","Charlotte","Charlottesville","Chesapeake","Chesterfield","Clarke","Colonial Heights","Covington","Craig","Culpeper","Cumberland","Danville","Dickenson","Dinwiddie","Emporia","Essex","Fairfax","Fairfax City","Fairfax City Of","Falls Church","Fauquier","Floyd","Fluvanna","Franklin","Frederick","Fredericksburg","Galax","Giles","Gloucester","Goochland","Grayson","Greene","Greensville","Halifax","Hampton","Hanover","Harrisonburg","Henrico","Henry","Highland","Hopewell","Isle Of Wight","James City","King And Queen","King George","King William","Lancaster","Lee","Lexington","Loudoun","Louisa","Lunenburg","Lynchburg","Madison","Manassas","Manassas Park","Martinsville","Mathews","Mecklenburg","Middlesex","Montgomery","Nelson","New Kent","Newport News","Norfolk","Northampton","Northumberland","Norton","Nottoway","Orange","Page","Patrick","Petersburg","Pittsylvania","Poquoson","Portsmouth","Powhatan","Prince Edward","Prince George","Prince William","Pulaski","Radford","Rappahannock","Richmond","Richmond City Of","Roanoke","Rockbridge","Rockingham","Russell","Salem","Scott","Shenandoah","Smyth","Southampton","Spotsylvania","Stafford","Staunton","Suffolk","Surry","Sussex","Tazewell","Virginia Beach","Warren","Washington","Waynesboro","Westmoreland","Williamsburg","Winchester","Wise","Wythe","York"],WV:["Barbour","Berkeley","Boone","Braxton","Brooke","Cabell","Calhoun","Clay","Doddridge","Fayette","Gilmer","Grant","Greenbrier","Hampshire","Hancock","Hardy","Harrison","Jackson","Jefferson","Kanawha","Lewis","Lincoln","Logan","Marion","Marshall","Mason","Mcdowell","Mercer","Mineral","Mingo","Monongalia","Monroe","Morgan","Nicholas","Ohio","Pendleton","Pleasants","Pocahontas","Preston","Putnam","Raleigh","Randolph","Ritchie","Roane","Summers","Taylor","Tucker","Tyler","Upshur","Wayne","Webster","Wetzel","Wirt","Wood","Wyoming"]}},
// returns an array of county names in alphabetical order
// parameter - twoLetterStateAbbr: the state's abbreviation as a string, is case insensitive
getCountiesForState:function(e){var t=[],n=e.toUpperCase(),i=!0,r=!1,o=void 0;try{for(var a,s=Qi.stateToCountyMapping[n][Symbol.iterator]();!(i=(a=s.next()).done);i=!0){var l=a.value;t.push(Qi.toTitleCase(l))}}catch(e){r=!0,o=e}finally{try{i||null==s.return||s.return()}finally{if(r)throw o}}return t.sort(),t},toTitleCase:function(e){return e.toLowerCase().split(" ").map(function(e){return e.charAt(0).toUpperCase()+e.slice(1)}).join(" ")},init:function(){Qi.buildStateToCountyMapping()}}).init,getCountiesForState:Qi.getCountiesForState};
/*
   * IE11 does not support custom events. This functionality
   * checks for IE9 - IE11 and creates an adapter for custom events.
   */
/* eslint-disable no-invalid-this */
// Usage
//
// var functionName = debounce( function() {
// All the taxing stuff you do
// }, 250);
//
// window.addEventListener('resize', myEfficientFn);
function er(e,t){var n=2<arguments.length&&void 0!==arguments[2]?arguments[2]:this,i=null,r=null,o=function(){return e.apply(n,r)};return function(){r=arguments,clearTimeout(i),i=setTimeout(o,t)}}var tr=Ue("isConcatSpreadable"),nr=9007199254740991,ir="Maximum allowed index exceeded",rr=!u(function(){var e=[];return e[tr]=!1,e.concat()[0]!==e}),or=ke("concat"),ar=function(e){if(!O(e))return!1;var t=e[tr];return void 0!==t?!!t:we(e)};
// `Array.prototype.concat` method
// https://tc39.github.io/ecma262/#sec-array.prototype.concat
// with adding support of @@isConcatSpreadable and @@species
Ne({target:"Array",proto:!0,forced:!rr||!or},{concat:function(e){// eslint-disable-line no-unused-vars
var t,n,i,r,o,a=Rt(this),s=Ii(a,0),l=0;for(t=-1,i=arguments.length;t<i;t++)if(o=-1===t?a:arguments[t],ar(o)){if(r=le(o.length),nr<l+r)throw TypeError(ir);for(n=0;n<r;n++,l++)n in o&&Ge(s,l,o[n])}else{if(nr<=l)throw TypeError(ir);Ge(s,l++,o)}return s.length=l,s}});var sr=fe(!0);
// `Array.prototype.includes` method
// https://tc39.github.io/ecma262/#sec-array.prototype.includes
Ne({target:"Array",proto:!0},{includes:function(e/* , fromIndex = 0 */){return sr(this,e,1<arguments.length?arguments[1]:void 0)}}),
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
ai("includes");var lr=u(function(){nn(1)});
// `Object.keys` method
// https://tc39.github.io/ecma262/#sec-object.keys
Ne({target:"Object",stat:!0,forced:lr},{keys:function(e){return nn(Rt(e))}});
// helper for String#{startsWith, endsWith, includes}
var cr=Ue("match"),dr="includes",ur=function(t){var n=/./;try{"/./"[t](n)}catch(e){try{return n[cr]=!1,"/./"[t](n)}catch(e){/* empty */}}return!1}(dr);
// `String.prototype.includes` method
// https://tc39.github.io/ecma262/#sec-string.prototype.includes
Ne({target:"String",proto:!0,forced:!ur},{includes:function(e/* , position = 0 */){return!!~function(e,t,n){if(tt(t))throw TypeError("String.prototype."+n+" doesn't accept regex");return String(f(e))}(this,e,dr).indexOf(e,1<arguments.length?arguments[1]:void 0)}});var fr=[].forEach,_r=yi(0),Sr=d("forEach")?function(e/* , thisArg */){return _r(this,e,arguments[1])}:fr;for(var pr in Wi){var Er=h[pr],hr=Er&&Er.prototype;
// some Chrome versions have non-configurable methods on DOMTokenList
if(hr&&hr.forEach!==Sr)try{x(hr,"forEach",Sr)}catch(e){hr.forEach=Sr}}var Ar,mr,Tr={getUrlParameters:(Ar={
// returns an array of parameters } from the url
// if no url is passed in, it uses location.href
getUrlParameters:function(e){var i={},t=e||window.location.href;return t&&t.replace(/[?&]+([^=&]+)=([^&]*)/gi,function(e,t,n){i[t]=n}),i},
// returns the hash } from the url
getUrlHash:function(){return window.location.hash.slice(1)}}).getUrlParameters,getUrlHash:Ar.getUrlHash},gr={appendPageParameters:(mr={PARAMETERS:{GET:"getParameters"},SELECTORS:{DATA_URL:"data-url",HREF:"href",SRC:"src"},VALUES:{ALL:"all"},pageParametersObject:{},pageParametersKeys:[],allPageParametersString:"",appendPageParameters:function(){mr.pageParametersObject=Tr.getUrlParameters(window.location.href),mr.pageParametersKeys=Object.keys(mr.pageParametersObject);// build the string for all parameters
var e=!(mr.allPageParametersString=""),t=!1,n=void 0;try{for(var i,r=mr.pageParametersKeys[Symbol.iterator]();!(e=(i=r.next()).done);e=!0){var o=i.value;mr.allPageParametersString="".concat(mr.allPageParametersString,"&").concat(o,"=").concat(mr.pageParametersObject[o])}}catch(e){t=!0,n=e}finally{try{e||null==r.return||r.return()}finally{if(t)throw n}}mr.allPageParametersString=mr.allPageParametersString.slice(1),// check link elements with href attributes
mr.checkElement("a[".concat(mr.SELECTORS.HREF,"]"),mr.SELECTORS.HREF),// check elements with data-url attributes
mr.checkElement("[".concat(mr.SELECTORS.DATA_URL,"]"),mr.SELECTORS.DATA_URL),// check iframes with src attributes
mr.checkElement("iframe[".concat(mr.SELECTORS.SRC,"]"),mr.SELECTORS.SRC)},checkElement:function(e,n){S(e).each(function(e,t){mr.replaceParameters(t,n)})},replaceParameters:function(e,t){var n=S(e),r=n.attr(t),i=Tr.getUrlParameters(r),o=!1,a=[];// determine which parameters are referenced in the element's url
i[mr.PARAMETERS.GET]&&(o=(a=i[mr.PARAMETERS.GET].split(",")).includes(mr.VALUES.ALL)),a.length&&(
// remove the getParameters parameter
// if it appears as a middle or last parameter
// determine if the url already has a parameter and then add the correct character
(// if it appears as an only parameter
r=(// if it appears as a first parameter
r=(r=r.replace("&".concat(mr.PARAMETERS.GET,"=").concat(i[mr.PARAMETERS.GET]),"")).replace("".concat(mr.PARAMETERS.GET,"=").concat(i[mr.PARAMETERS.GET],"&"),"")).replace("".concat(mr.PARAMETERS.GET,"=").concat(i[mr.PARAMETERS.GET]),"")).indexOf("?")!==r.length-1&&(r="".concat(r,"&")),o?
// append all page parameters
r="".concat(r).concat(mr.allPageParametersString):
// append only the selected page parameters
a.forEach(function(e,t){if(mr.pageParametersObject[e]){var n=0<t?"&":"",i="".concat(e,"=").concat(mr.pageParametersObject[e]);r="".concat(r).concat(n).concat(i)}}),// if no parameters match, remove the ? if it is still on the url
r.indexOf("&")===r.length-1&&(r=r.slice(0,-1)),r.indexOf("?")===r.length-1&&(r=r.slice(0,-1)),// set the attribute value
n.attr(t,r))}}).appendPageParameters},Cr=yi(2),Lr=ke("filter");
// `Array.prototype.filter` method
// https://tc39.github.io/ecma262/#sec-array.prototype.filter
// with adding support of @@species
Ne({target:"Array",proto:!0,forced:!Lr},{filter:function(e/* , thisArg */){return Cr(this,e,arguments[1])}});
// a string of all valid unicode whitespaces
// eslint-disable-next-line max-len
var Or,Rr="\t\n\v\f\r                　\u2028\u2029\ufeff",vr="["+Rr+"]",Ir=RegExp("^"+vr+vr+"*"),yr=RegExp(vr+vr+"*$"),br=function(e,t){return e=String(f(e)),1&t&&(e=e.replace(Ir,"")),2&t&&(e=e.replace(yr,"")),e},Nr=(Or="trim",u(function(){return!!Rr[Or]()||"​᠎"!="​᠎"[Or]()||Rr[Or].name!==Or}));
// `String.prototype.trim` method
// https://tc39.github.io/ecma262/#sec-string.prototype.trim
Ne({target:"String",proto:!0,forced:Nr},{trim:function(){return br(this,3)}});
/*
   * Detects the version of IE
   * A return value of -1 indicates that the browser is not IE
   */
var Dr={getVersionNumber:function(){var e=window.navigator.userAgent,t="-1",n=e.indexOf("MSIE "),i=e.indexOf("Trident/"),r=e.indexOf("Edge/");if(// FOR TESTING - uncomment to check result …
// IE 10
// ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';
// IE 11
// ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';
// Edge 12 (Spartan)
// ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';
// Edge 13
// ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';
0<n&&(
// IE 10 or older
t=parseInt(e.substring(n+5,e.indexOf(".",n)),10)),0<i){
// IE 11
var o=e.indexOf("rv:");t=parseInt(e.substring(o+3,e.indexOf(".",o)),10)}return 0<r&&(
// Edge (IE 12+)
t=parseInt(e.substring(r+5,e.indexOf(".",r)),10)),t}},Mr=yi(5),Pr="find",wr=!0;
// Shouldn't skip holes
Pr in[]&&Array(1)[Pr](function(){wr=!1}),
// `Array.prototype.find` method
// https://tc39.github.io/ecma262/#sec-array.prototype.find
Ne({target:"Array",proto:!0,forced:wr},{find:function(e/* , that = undefined */){return Mr(this,e,1<arguments.length?arguments[1]:void 0)}}),
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
ai(Pr);var Gr,Fr,xr={displayModal:(Gr={CLASSES:{AEM_TEMPLATE:".aem-template"},CLASSES_NO_DOT:{REDIRECT_NOTICE:{MODAL:"redirect-notice",TRIGGER:"collapsible__trigger--redirect-notice",TARGET:"collapsible__target--redirect-notice",TARGET_INNER:"collapsible__target-inner-redirect-notice",SPINNER:"spinner--redirect-notice",CANCEL:"cancel--redirect-notice",BACKDROP:"backdrop--redirect-notice"}},ATTRIBUTES:{LANGUAGE:"lang"},EVENTS:{REDIRECT_NOTICE:"redirectNotice",REDIRECT_NOTICE_GO_TO_PAGE:"goToPage",REDIRECT_NOTICE_CANCEL:"cancel"},TIMEOUTS:{INITIAL_LOAD:"500",TRANSFER:"4500",CANCEL_BUTTON_FOCUS_DELAY:"1000"},stateIndicators:{transferNoticeDisplayed:!1,transferCancelled:!1},createModal:function(e,t,n){
// creates the modal, so that it can be added to the page before the rest of the js initializes
// the modal requires collapse functionality, so it has to be in the dom before collapse initializes
var i=""!==e?"".concat(Gr.ATTRIBUTES.LANGUAGE,'="').concat(e,'"'):"";return S(Gr.CLASSES.AEM_TEMPLATE).before('\n        <div class="js-lx-collapsible '.concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.MODAL," js-").concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.MODAL,'" ').concat(i,'>\n          <button class="lx-button collapsible__trigger js-lx-collapsible__trigger ').concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TRIGGER," js-").concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TRIGGER,' display-none" data-animate-mobile="fade" data-animate-desktop="fade">\n            ').concat(t,'\n          </button>\n\n          <div class="lx-collapsible__target js-lx-collapsible__target ').concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TARGET," js-").concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TARGET,' display-none">\n            <div class="').concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TARGET_INNER," js-").concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TARGET_INNER,'">\n              <div class="spinner spinner--md spinner--background spinner--mp-redirect" aria-hidden="true"></div>\n              <h2>').concat(t,'</h2>\n              <p>\n                <a class="lx-button lx-button--secondary ').concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.CANCEL," js-").concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.CANCEL,'" href="javascript:void(0);">\n                  ').concat(n,'\n                  <span class="lx-screen-reader-only"> - ').concat(t,"</span>\n                </a>\n              </p>\n            </div>\n          </div>\n        </div>\n      ")),S(".js-".concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.MODAL)).first()},displayModal:function(e){if(!Gr.stateIndicators.transferNoticeDisplayed){var t=e.find(".js-".concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.CANCEL));// add an event handler for the cancel button
t.on("click",{$redirectNoticeElement:e},Gr.cancelTransfer),// add a tab trap
S(document).on("keydown",{$redirectNoticeElement:e},Gr.trapTabs),// create an overlay on the page
// display the redirect message and start the countdown
setTimeout(function(){S(Gr.CLASSES.AEM_TEMPLATE).addClass(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.BACKDROP),e.find(".js-".concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TRIGGER)).click(),// delays focusing on the cancel button to give screen readers a chance to load
setTimeout(function(){t.focus()},Gr.TIMEOUTS.CANCEL_BUTTON_FOCUS_DELAY)},Gr.TIMEOUTS.INITIAL_LOAD),// set up the page to transfer unless the user cancels it
setTimeout(function(){
// a custom event to indicate to start the redirect
Gr.createAndDispatchRedirectNoticeEvent(Gr.EVENTS.REDIRECT_NOTICE_GO_TO_PAGE)},Gr.TIMEOUTS.TRANSFER),Gr.stateIndicators.transferNoticeDisplayed=!0}},cancelTransfer:function(e){Gr.stateIndicators.transferNoticeDisplayed&&(
// cancel the transfer
Gr.stateIndicators.transferCancelled=!0,// dismiss the transfer notice
e.data.$redirectNoticeElement.find(".js-".concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.TRIGGER)).click(),// remove the overlay on the page
S(Gr.CLASSES.AEM_TEMPLATE).removeClass(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.BACKDROP),// remove the tab trap
S(document).off("keydown",Gr.trapTabs),Gr.stateIndicators.transferNoticeDisplayed=!1,// a custom event to indicate that the redirect should be cancelled
Gr.createAndDispatchRedirectNoticeEvent(Gr.EVENTS.REDIRECT_NOTICE_CANCEL))},trapTabs:function(e){var t=e.data.$redirectNoticeElement.find(".js-".concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.CANCEL));// if the user presses the tab key in conjunction with the shift key
e.shiftKey&&9===e.which&&(e.preventDefault(),t.focus()),// if the user presses the tab key and NOT in conjunction with the shift key
9!==e.which||e.shiftKey||(e.preventDefault(),t.focus())},createAndDispatchRedirectNoticeEvent:function(e){
// only send go to page events if the notice hasn't been cancelled
if(e!==Gr.EVENTS.REDIRECT_NOTICE_GO_TO_PAGE||!Gr.stateIndicators.transferCancelled){var t=new CustomEvent(Gr.EVENTS.REDIRECT_NOTICE,{detail:{type:e}});S(".js-".concat(Gr.CLASSES_NO_DOT.REDIRECT_NOTICE.MODAL)).first()[0].dispatchEvent(t)}}}).displayModal,createModal:Gr.createModal},Br={setUpLanguageLinks:(Fr={LANGUAGES:{EN:"en",ES:"es",FR:"fr"},MOTIONPOINT:{DO_NOT_TRANSLATE_START:"\x3c!-- mp_trans_disable_start --\x3e",DO_NOT_TRANSLATE_END:"\x3c!-- mp_trans_disable_end --\x3e",REMOVE_START:"\x3c!-- mp_trans_remove_start --\x3e",REMOVE_END:"\x3c!-- mp_trans_remove_end --\x3e",ADD_START:"\x3c!--mp_trans_add ",ADD_END:" --\x3e "},CLASSES:{AEM_TEMPLATE:".aem-template",REDIRECT_NOTICE:".js-redirect-notice"},EVENTS:{REDIRECT_NOTICE:"redirectNotice",REDIRECT_NOTICE_GO_TO_PAGE:"goToPage",REDIRECT_NOTICE_CANCEL:"cancel"},TRANSFER_MESSAGES:{EN:"Redirecting to English",ES:"Redirigiendo a Español",FR:"Redirection vers le français"},CANCEL_BUTTON_TEXT:{EN:"Cancel",ES:"Cancelar",FR:"Annuler"},LINK_TEXT:{ENGLISH_LANGUAGE:"English"},LANGUAGE_ATTRIBUTE:"lang",COOKIE_KEY:"MP_LANG",LANGUAGE_LINK_PARAMETERS:{TARGET_LANGUAGE:"targetLanguage",TARGET_DOMAIN:"targetDomain"},
// FOR TESTING - uncomment this line out and comment the following one
// PAGE_LANGUAGE: 'es',
PAGE_LANGUAGE:S("html").attr("lang"),
// FOR TESTING - uncomment this line out and comment the following one
// PAGE_URL: 'https://sit.cafo.com/nested/test.html',
PAGE_URL:location.href,
// FOR TESTING - uncomment this line out and comment the following one
// PAGE_DOMAIN: 'sit.cafo.com',
PAGE_DOMAIN:location.hostname,
// versions of IE less than 12 will not write cookies or redirect
// because of issues with IE not reading/sending cookies across subdomains
ieVersionNumber:Dr.getVersionNumber(),isOldIE:!1,redirect:{targetHref:null,targetLanguage:null,$noticeElement:null},setUpLanguageLinks:function(){var _=Fr.getCookie(Fr.COOKIE_KEY);0<Fr.ieVersionNumber&&Fr.ieVersionNumber<12&&(Fr.isOldIE=!0),// if there are links on the page with the "mplang" parameter
// then the site is available in another language
S('[href*="'.concat(Fr.LANGUAGE_LINK_PARAMETERS.TARGET_LANGUAGE,'="]')).each(function(e,t){
/* eslint-disable indent */
/* eslint-disable multiline-ternary */
var n=S(t),i=Tr.getUrlParameters(n.attr("href")),r=i[Fr.LANGUAGE_LINK_PARAMETERS.TARGET_LANGUAGE]?decodeURIComponent(i[Fr.LANGUAGE_LINK_PARAMETERS.TARGET_LANGUAGE]):"",o=i[Fr.LANGUAGE_LINK_PARAMETERS.TARGET_DOMAIN]?decodeURIComponent(i[Fr.LANGUAGE_LINK_PARAMETERS.TARGET_DOMAIN]):"",a=t.hostname,s="#"===o,l=!0;// set up the link
if(
/* eslint-enable indent */
/* eslint-enable multiline-ternary */
// ensure that the appropriate url parameters are defined
s&&(r&&o||(l=!1),r===Fr.LANGUAGES.EN||a||(l=!1)),s||r||(l=!1),l)// check if there is a proxy site for the current environment
// MotionPoint often doesn't have site or dev proxy sites
if(
// add the target language to the link for accessibility purposes
r!==Fr.PAGE_LANGUAGE&&n.attr(Fr.LANGUAGE_ATTRIBUTE,r),s)n.attr("href","#");else{// for non-English links, create an English copy of the link
// and mark it up for MotionPoint
if(
// if this is a MotionPoint-hosted proxy site
// replace the language link with the same language as the page with the English equivalent
// this is fallback functionality in case the links do not get translated by MotionPoint
Fr.PAGE_LANGUAGE!==Fr.LANGUAGES.EN&&Fr.PAGE_LANGUAGE===r&&(Fr.changeLinkToEnglishVersion(n,r,o,a),r=Fr.LANGUAGES.EN,o=a),r!==Fr.LANGUAGES.EN){
// copy the link
n.clone().insertAfter(n);var c=S(n.next());Fr.changeLinkToEnglishVersion(c,r,o,a),
/* eslint-disable no-invalid-this */
n.before(Fr.MOTIONPOINT.REMOVE_START),n.after(Fr.MOTIONPOINT.REMOVE_END),c.wrap(function(){return"".concat(Fr.MOTIONPOINT.ADD_START).concat(this.outerHTML).concat(Fr.MOTIONPOINT.ADD_END)})}// determine the target href
var d=Fr.determineTargetHref(o);if(d){
// if appropriate, redirect to the target page based on the cookie
// don't redirect for IE11 or less
if(!Fr.isOldIE&&_!==Fr.PAGE_LANGUAGE&&_===r&&null===Fr.redirect.targetHref){var u="",f="";switch(r){case Fr.LANGUAGES.EN:u=Fr.TRANSFER_MESSAGES.EN,f=Fr.CANCEL_BUTTON_TEXT.EN;break;case Fr.LANGUAGES.ES:u=Fr.TRANSFER_MESSAGES.ES,f=Fr.CANCEL_BUTTON_TEXT.ES;break;case Fr.LANGUAGES.FR:u=Fr.TRANSFER_MESSAGES.FR,f=Fr.CANCEL_BUTTON_TEXT.FR;break;default:u=Fr.TRANSFER_MESSAGES.EN,f=Fr.CANCEL_BUTTON_TEXT.EN}Fr.redirect.targetHref=d,Fr.redirect.targetLanguage=r,Fr.redirect.$noticeElement=xr.createModal(r,u,f)}// add behavior to go to the target site
n.on("click",function(e){e.preventDefault(),Fr.goToTargetSite(r,d)})}}else console.error("The following language-specific link does not contain the correct url parameters: ".concat(n.attr("href")))})},hasRedirectNotice:function(){return null!==Fr.redirect.$noticeElement},displayRedirectNotice:function(){Fr.redirect.$noticeElement&&(
// listen for an event to trigger the redirect or to cancel the redirect
Fr.redirect.$noticeElement.on(Fr.EVENTS.REDIRECT_NOTICE,{targetLanguage:Fr.redirect.targetLanguage,targetHref:Fr.redirect.targetHref},Fr.redirectNoticeEventHandler),// display the modal
xr.displayModal(Fr.redirect.$noticeElement))},redirectNoticeEventHandler:function(e){
// either redirects to a new page or cancels the redirect
// based on an event } from the redirect notice
switch(e.detail.type){case Fr.EVENTS.REDIRECT_NOTICE_GO_TO_PAGE:Fr.goToTargetSite(e.data.targetLanguage,e.data.targetHref);break;case Fr.EVENTS.REDIRECT_NOTICE_CANCEL:Fr.setCookie(Fr.COOKIE_KEY,Fr.PAGE_LANGUAGE),Fr.redirect.targetHref=null,Fr.redirect.targetLanguage=null,Fr.redirect.$noticeElement=null}},getCookie:function(e){var t=new RegExp("".concat(e,"=([^;]+)")).exec(document.cookie);return null!==t?unescape(t[1]):null},setCookie:function(e,t){if(!Fr.isOldIE){var n="";// only removes a subdomain if the domain isn't numeric (e.g. 10.131.64.95)
n=isNaN(Fr.PAGE_DOMAIN.replace(/\./g,""))?Fr.PAGE_DOMAIN.substring(Fr.PAGE_DOMAIN.indexOf(".")):Fr.PAGE_DOMAIN,// FOR TESTING - enable this console statement
// console.log( `${key}=${value}; path=/; domain=${cookieDomainValue}` );
document.cookie="".concat(e,"=").concat(t,"; path=/; domain=").concat(n)}},changeLinkToEnglishVersion:function(e,t,n,i){
/* eslint-disable no-invalid-this */
e.contents().filter(function(){return this.nodeType===Node.TEXT_NODE&&""!==this.nodeValue.trim()}).replaceWith(Fr.LINK_TEXT.ENGLISH_LANGUAGE),
/* eslint-enable no-invalid-this */
e.attr(Fr.LANGUAGE_ATTRIBUTE,Fr.LANGUAGES.EN),e.attr("href",e.attr("href").replace("".concat(Fr.LANGUAGE_LINK_PARAMETERS.TARGET_LANGUAGE,"=").concat(t),"".concat(Fr.LANGUAGE_LINK_PARAMETERS.TARGET_LANGUAGE,"=").concat(Fr.LANGUAGES.EN)).replace("".concat(Fr.LANGUAGE_LINK_PARAMETERS.TARGET_DOMAIN,"=").concat(encodeURIComponent(n)),"".concat(Fr.LANGUAGE_LINK_PARAMETERS.TARGET_DOMAIN,"=").concat(i)).replace("&".concat(Fr.LANGUAGE_LINK_PARAMETERS.ENGLISH_DOMAIN,"=").concat(i),""))},determineTargetHref:function(e){
// uses the browser's built-in url manipulation
var t=document.createElement("a");return t.setAttribute("href",Fr.PAGE_URL),Fr.PAGE_URL.replace(t.hostname,e)},goToTargetSite:function(e,t){Fr.setCookie(Fr.COOKIE_KEY,e),// FOR TESTING - uncomment this line out and comment the following one
// console.log( `targetHref = ${targetHref}` );
location.href=t}}).setUpLanguageLinks,hasRedirectNotice:Fr.hasRedirectNotice,displayRedirectNotice:Fr.displayRedirectNotice};function Ur(t,n){S("html, body").animate({scrollTop:S(t).offset().top},400,function(){var e=void 0===n?-1:n;S(t).attr("tabindex",e),S(t).focus()})}var Hr,kr,jr={init:(Hr={SPEED:400,cacheDom:function(){Hr.$root=S("html, body"),Hr.$selector=S('a[href*="#"]:not([href="#"])')},bindEvents:function(){Hr.$selector.on("click",Hr.scrollToTarget)},scrollToTarget:function(e){try{if(location.pathname.replace(/^\//,"")===this.pathname.replace(/^\//,"")&&location.hostname===this.hostname){
// Prevent default link behavior
e.preventDefault();// Store target object
var t=S(this.hash);// Animate scroll
(t=t.length?t:S("[name="+t.slice(1)+"]")).length&&Hr.$root.animate({scrollTop:t.offset().top},Hr.SPEED,function(){t.focus(),t.is(":focus")||(t.attr("tabindex","-1"),t.focus())})}}catch(e){console.error("Unable to scroll to target: ".concat(this.href))}},addLink:function(e){Hr.$selector.add(e),e.on("click",Hr.scrollToTarget)},init:function(){Hr.cacheDom(),Hr.bindEvents()}}).init,addLink:Hr.addLink},Vr={init:(kr={BOTTOM_RIGHT_FIXED_ITEMS_ID_NO_HASH:"bottom-right-fixed-items",SCROLL_TO_TOP_LOCATION_SELECTOR:".aem-template",SCROLL_TO_TOP_CLASS:".js-lx-button--scroll-to-top",SCROLL_TO_TOP_STARTING_HEIGHT:200,SKIP_NAV_ID:"#main-content",SCROLL_TOP_IS_VISIBLE_CLASS_NO_DOT:"scroll-top-is-visible",
// adds a link that appears when the user has scrolled a little ways down the page
// the link scrolls back up to the skip nav
// the link is only added if the page has a skip nav
addScrollToTop:function(){var e=0<arguments.length&&void 0!==arguments[0]?arguments[0]:"0 0 16 16";S(kr.SKIP_NAV_ID).length&&(S(kr.SCROLL_TO_TOP_LOCATION_SELECTOR).append('\n          <div id="'.concat(kr.BOTTOM_RIGHT_FIXED_ITEMS_ID_NO_HASH,'">\n            <a href="').concat(kr.SKIP_NAV_ID,'" class="lx-button lx-button--tertiary lx-button__icon lx-button--scroll-to-top\n              ').concat(kr.SCROLL_TO_TOP_CLASS.slice(1),'" style="display: none">\n              <span class="lx-screen-reader-only">Scroll to top of page</span>\n              <svg class="lx-icon lx-icon--up-arrow" viewbox="').concat(e,'" aria-hidden="true" focusable="false" id="up-arrow">\n                <path d="M12.41 7.47L8.07 2 3.58 7.61M8.07 2v12"></path>\n              </svg>\n            </a>\n          </div>\n        ')),// adds smooth scroll functionality
jr.addLink(S("".concat(kr.SCROLL_TO_TOP_LOCATION_SELECTOR,' a[href="').concat(kr.SKIP_NAV_ID,'"]'))),// add the listener that displays/hides the link
S(window).on("scroll",er(function(){var e=S(kr.SCROLL_TO_TOP_CLASS);S(window).scrollTop()>=kr.SCROLL_TO_TOP_STARTING_HEIGHT&&!e.is(":visible")&&(e.fadeIn(),S("#".concat(kr.BOTTOM_RIGHT_FIXED_ITEMS_ID_NO_HASH)).addClass(kr.SCROLL_TOP_IS_VISIBLE_CLASS_NO_DOT)),S(window).scrollTop()<kr.SCROLL_TO_TOP_STARTING_HEIGHT&&e.is(":visible")&&(e.fadeOut(),S("#".concat(kr.BOTTOM_RIGHT_FIXED_ITEMS_ID_NO_HASH)).removeClass(kr.SCROLL_TOP_IS_VISIBLE_CLASS_NO_DOT))},100)))},init:function(){kr.addScrollToTop()}}).init},Wr=Object.is||function(e,t){
// eslint-disable-next-line no-self-compare
return e===t?0!==e||1/e==1/t:e!=e&&t!=t};
// @@search logic
Bt("search",1,function(i,a,s){return[
// `String.prototype.search` method
// https://tc39.github.io/ecma262/#sec-string.prototype.search
function(e){var t=f(this),n=null==e?void 0:e[i];return void 0!==n?n.call(e,t):new RegExp(e)[i](String(t))},
// `RegExp.prototype[@@search]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@search
function(e){var t=s(a,e,this);if(t.done)return t.value;var n=w(e),i=String(this),r=n.lastIndex;Wr(r,0)||(n.lastIndex=0);var o=wt(n,i);return Wr(n.lastIndex,r)||(n.lastIndex=r),null===o?-1:o.index}]});var zr,Xr,Yr,Kr,qr={checkForRedirect:(zr={LANGUAGES:{EN:"en",ES:"es",FR:"fr"},ATTRIBUTES:{DATA_SEGMENT:"data-segment",DATA_CURRENT_SEGMENT:"data-current-segment",ARIA_CURRENT:"aria-current",ARIA_SELECTED:"aria-selected",ARIA_HIDDEN:"aria-hidden"},ATTRIBUTE_VALUES:{GLOBAL_LOGIN:"global-login"},CLASSES:{TAB_PANEL:".js-lx-tabs__panel",LIST_SEGMENT:".header__navigation-list--segments",TAB_LIST:".header__segment-tabs-list",LOGIN_BUTTON_OPTION:".header__login-button-option",FOOTER_NAV_PRIMARY:".footer-nav--primary"},CLASSES_NO_DOT:{STICKY_SEGMENTS:"sticky-segments",STICKY_SEGMENTS_SHOW_NOTICE:"sticky-segments-show-notice",IS_ACTIVE:"is-active",IS_DEFAULT:"is-default",IS_VISIBLE:"is-visible"},IDS:{HEADER:"#js-header"},EVENTS:{REDIRECT_NOTICE:"redirectNotice",REDIRECT_NOTICE_GO_TO_PAGE:"goToPage",REDIRECT_NOTICE_CANCEL:"cancel"},TRANSFER_MESSAGES:{EN:"Redirecting to ",ES:"Redirigiendo a ",FR:"Redirection vers "},CANCEL_BUTTON_TEXT:{EN:"Cancel",ES:"Cancelar",FR:"Annuler"},LOCAL_STORAGE:{LAST_SEGMENT:"lastSegment"},SESSION_STORAGE:{REDIRECTED_TO_SEGMENT_HOME:"redirectedToSegmentHome"},SEGMENTS:{STORED:localStorage.getItem("lastSegment"),CURRENT:S("#js-header").attr("data-current-segment"),SITE_HOME:S(".header__navigation-list--segments li").first().attr("data-segment")},
// FOR TESTING - uncomment this line and comment the following one
// PAGE_URL: 'http://local.host/segment1?abc',
PAGE_URL:location.href,
// FOR TESTING - uncomment this line and comment the following one
// PAGE_DOMAIN: 'local.host',
PAGE_DOMAIN:location.hostname,
// FOR TESTING - uncomment this line and comment the following one
PAGE_PARAMETERS:location.search,
// PAGE_PARAMETERS: '?abc',
PAGE_PROTOCOL:location.protocol,
// FOR TESTING - uncomment this line out and comment the following one
// PAGE_LANGUAGE: 'en',
PAGE_LANGUAGE:S("html").attr("lang"),redirect:{storedSegmentHref:null,$noticeElement:null},checkForRedirect:function(){var e=S("body.".concat(zr.CLASSES_NO_DOT.STICKY_SEGMENTS)).length,t=S("body.".concat(zr.CLASSES_NO_DOT.STICKY_SEGMENTS_SHOW_NOTICE)).length,n="true"===sessionStorage.getItem(zr.SESSION_STORAGE.REDIRECTED_TO_SEGMENT_HOME);// if sticky segments are turned on and if there hasn't already been a redirect
// and if there is a stored segment
if((e||t)&&!n&&zr.SEGMENTS.STORED){var i=S("".concat(zr.CLASSES.LIST_SEGMENT," li")).first().find("a").attr("href"),r=S("".concat(zr.CLASSES.LIST_SEGMENT," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(zr.SEGMENTS.STORED,"']")).find("a").attr("href"),o=zr.PAGE_URL.replace(zr.PAGE_PARAMETERS,"");i&&r&&(
// build out the full urls for comparison purposes in case the url in the segment
// href is just relative to the site root
-1===i.indexOf(zr.PAGE_DOMAIN)&&(i="".concat(zr.PAGE_PROTOCOL,"//").concat(zr.PAGE_DOMAIN).concat(i)),-1===r.indexOf(zr.PAGE_DOMAIN)&&(r="".concat(zr.PAGE_PROTOCOL,"//").concat(zr.PAGE_DOMAIN).concat(r)),// check if the current page is the site home page
// and that the stored segment's home page is different } from the current page
i===o&&i!==r&&r&&(
// only allow one redirect per session
// FOR TESTING - comment out the following line
sessionStorage.setItem(zr.SESSION_STORAGE.REDIRECTED_TO_SEGMENT_HOME,"true"),e?
// redirect immediately
zr.redirectImmediately(r):t&&
// show a redirect notice
zr.setUpRedirectNotice(r)))}},redirectImmediately:function(e){zr.goToTargetSite(e)},setUpRedirectNotice:function(e){var t="",n="",i=S("".concat(zr.CLASSES.LIST_SEGMENT," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(zr.SEGMENTS.STORED,"']")).find("a").text();switch(zr.PAGE_LANGUAGE){case zr.LANGUAGES.EN:t=zr.TRANSFER_MESSAGES.EN,n=zr.CANCEL_BUTTON_TEXT.EN;break;case zr.LANGUAGES.ES:t=zr.TRANSFER_MESSAGES.ES,n=zr.CANCEL_BUTTON_TEXT.ES;break;case zr.LANGUAGES.FR:t=zr.TRANSFER_MESSAGES.FR,n=zr.CANCEL_BUTTON_TEXT.FR;break;default:t=zr.TRANSFER_MESSAGES.EN,n=zr.CANCEL_BUTTON_TEXT.EN}t="".concat(t).concat(i),// create a redirect notice
null===zr.redirect.storedSegmentHref&&(zr.redirect.storedSegmentHref=e,zr.redirect.$noticeElement=xr.createModal("",t,n))},hasRedirectNotice:function(){return null!==zr.$redirectNoticeElement},displayRedirectNotice:function(){zr.redirect.$noticeElement&&(
// listen for an event to trigger the redirect or to cancel the redirect
zr.redirect.$noticeElement.on(zr.EVENTS.REDIRECT_NOTICE,{storedSegmentHref:zr.redirect.storedSegmentHref},zr.redirectNoticeEventHandler),// display the modal
xr.displayModal(zr.redirect.$noticeElement))},redirectNoticeEventHandler:function(e){
// either redirects to a new page or cancels the redirect
// based on an event } from the redirect notice
switch(e.detail.type){case zr.EVENTS.REDIRECT_NOTICE_GO_TO_PAGE:zr.goToTargetSite(e.data.storedSegmentHref);break;case zr.EVENTS.REDIRECT_NOTICE_CANCEL:zr.redirect.storedSegmentHref=null,zr.redirect.$noticeElement=null}},goToTargetSite:function(e){
// FOR TESTING - uncomment this line and comment the following one
// console.log( `targetHref = ${storedSegmentHref}` );
location.href=e},showActiveSegment:function(){
// check if there is a segment specified - if so it is a segment page, if not it is a utility page
if(zr.SEGMENTS.CURRENT)
// it is a segment page, track the segment
zr.SEGMENTS.STORED!==zr.SEGMENTS.CURRENT&&localStorage.setItem(zr.LOCAL_STORAGE.LAST_SEGMENT,zr.SEGMENTS.CURRENT);else{
// it is a utility page, display the segment, primary nav, login button,
// and footer primary nav that maps to the last segment
var e="";// check that the site has segments
if(zr.SEGMENTS.SITE_HOME){
// check if there is a stored segment and that it is valid
S("".concat(zr.CLASSES.LIST_SEGMENT," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(zr.SEGMENTS.STORED,"']")).length?e=zr.SEGMENTS.STORED:(
// use the site home segment and write it to local storage
e=zr.SEGMENTS.SITE_HOME,localStorage.setItem(zr.LOCAL_STORAGE.LAST_SEGMENT,zr.SEGMENTS.SITE_HOME)),// display the correct segment in the desktop and mobile navs
S("".concat(zr.CLASSES.LIST_SEGMENT," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"'] a")).addClass(zr.CLASSES_NO_DOT.IS_ACTIVE),S("".concat(zr.CLASSES.LIST_SEGMENT," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"'] a")).attr(zr.ATTRIBUTES.ARIA_CURRENT,"true"),S("".concat(zr.CLASSES.TAB_LIST," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"']")).addClass("".concat(zr.CLASSES_NO_DOT.IS_ACTIVE," ").concat(zr.CLASSES_NO_DOT.IS_DEFAULT)),S("".concat(zr.CLASSES.TAB_LIST," li[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"']")).attr(zr.ATTRIBUTES.ARIA_SELECTED,"true"),// display the correct primary navigation grouping
S("".concat(zr.CLASSES.TAB_PANEL,"[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"']")).addClass("".concat(zr.CLASSES_NO_DOT.IS_ACTIVE," ").concat(zr.CLASSES_NO_DOT.IS_DEFAULT)).attr(zr.ATTRIBUTES.ARIA_HIDDEN,"false");// display the correct login button
var t=S("".concat(zr.CLASSES.LOGIN_BUTTON_OPTION,"[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(zr.ATTRIBUTE_VALUES.GLOBAL_LOGIN,"']")),n=S("".concat(zr.CLASSES.LOGIN_BUTTON_OPTION,"[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"']"));t.length&&!n.length?t.addClass(zr.CLASSES_NO_DOT.IS_VISIBLE):n.addClass(zr.CLASSES_NO_DOT.IS_VISIBLE),// display the correct footer primary navigation grouping
S("".concat(zr.CLASSES.FOOTER_NAV_PRIMARY,"[").concat(zr.ATTRIBUTES.DATA_SEGMENT,"='").concat(e,"']")).addClass(zr.CLASSES_NO_DOT.IS_VISIBLE)}}}}).checkForRedirect,hasRedirectNotice:zr.hasRedirectNotice,displayRedirectNotice:zr.displayRedirectNotice,showActiveSegment:zr.showActiveSegment},$r={init:(Xr={updateHeader:function(){
// insert a screen-reader-only h2; usability testing indicates that users navigate by headings more frequently than by landmarks
S(".js-header__skip-nav").after('<h2 class="lx-screen-reader-only">Header</h2>'),// TO BE REMOVED
// add role="presentation" to the ul and the li that wrap the login button because it is currently a list of one item; remove this if we ever add another item to the list
1===S(".header__wrapper--primary-navbar--right .navbar--primary__list .navbar--primary__list-item").length&&(S(".header__wrapper--primary-navbar--right .navbar--primary__list").attr("role","presentation"),S(".header__wrapper--primary-navbar--right .navbar--primary__list .navbar--primary__list-item").attr("role","presentation"))},updateFooter:function(){
// insert a screen-reader-only h2; usability testing indicates that users navigate by headings more frequently than by landmarks
S("footer").prepend('<h2 class="lx-screen-reader-only">Footer</h2>')},updateFields:function(){
// removes all fields with required='false'; required is a boolean attribute - any value means true
S("input[required='false']").removeAttr("required"),S("fieldset[required='false']").removeAttr("required"),S("select[required='false']").removeAttr("required"),S("textarea[required='false']").removeAttr("required")},
// TO BE REMOVED
updateFilters:function(){
// modifies the results header in the filter and display tagged cards component so that the whole
// header is read when the user selects a filter instead of just the updated number of results
S(".js-filter__results-lead").attr("aria-atomic","true")},
// TO BE REMOVED
updateTabs:function(){
// removes the aria-label attribute on icons in tabs; they repeat the visible text of the tab
S(".js-lx-tabs__tab svg").removeAttr("aria-label")},
// This functionality needs to remain to accomodate RTE fields that were authored before the
// upgrade to AEM 6.3.3.3
updateBullets:function(){
// the RTE adds a style default, remove that style and add a class so we
// can target RTE lists via css
S("ul, ol").each(function(e,t){var n=S(t);""!==n.prop("style")["list-style-position"]&&(n.removeAttr("style"),n.addClass("rte__list"))})},
// TO BE REMOVED
updateBadges:function(){
// make badges aria-hidden and put the content of the badge at the
// end of the card title in the format (badge content)
S(".card__badge").each(function(e,t){var n=S(t),i=n.find(".card__badge-label").first(),r=n.closest(".js-card").find(".card__title").first(),o=i.text().replace(/\n/g,"").trim();""!==o&&(i.attr("aria-hidden","true"),r.html().includes(o)||r.append(' <span class="lx-screen-reader-only">&nbsp;('.concat(o,")</span>")))})},
// TO BE REMOVED
updateCardIconLabels:function(){
// make card icon labels aria-hidden and put the content of the icon label at the
// end of the card title in the format (icon label content)
S(".card__icon-label").each(function(e,t){var n=S(t),i=n.closest(".js-card").find(".card__title").first(),r=n.text().replace(/\n/g,"").trim();""!==r&&(n.attr("aria-hidden","true"),i.html().includes(r)||i.append(' <span class="lx-screen-reader-only">&nbsp;('.concat(r,")</span>")))})},
// TO BE REMOVED
updateSrOnlyGenericTextInputLabel:function(){
// fixes incorrect markup when "Make label screenreader only?" is set to on
// for the generic text input component
S("form.js-generic-text-input div.label-wrapper").each(function(e,t){var n=S(t),i=n.find("label");if(i){var r=i.html().replace("&nbsp;",""),o=n.siblings(".js-input-group").find("input");i.removeAttr("type"),n.hasClass("lx-screen-reader-only")&&o.attr("aria-label",r)}})},
// TO BE REMOVED
updateQuickQuote:function(){
// adds type="button" to the help collapse button to allow the
// form to submit with an enter key in a form field
S(".form--qq .collapse--qq-help .js-lx-collapsible__trigger").attr("type","button"),// adds grid classes
S(".grid--qq").addClass("lx-grid--2-columns-md-up lx-grid--4-columns-lg-up"),S(".card__title__icon-container--qq").each(function(e,t){var n=S(t),i=n.find("svg");n.closest(".card--qq").find(".card__image-wrapper").append(n),n.addClass("card__icon-container card__icon-container--qq"),n.removeClass("card__title__icon-container card__title__icon-container--body card__title__icon-container--qq"),i.addClass("card__icon card__icon--qq"),i.removeClass("card__title__icon card__title__icon--body card__title__icon--qq")})},
// TO BE REMOVED
updateCurrencyFields:function(){
// cleans up attributes and maps the input to a textual description of the dollar sign add on
S(".js-form-validation-currency").each(function(e,t){var n=S(t),i=n.attr("ariadescribedby"),r="".concat(n.attr("id"),"-icon"),o=n.prev(".input__add-on").find("svg");// the required attribute is binary, so any value in it is interpreted as true by browsers
-1<n.closest(".js-form-group").find(".js-label").text().indexOf("(Optional)")&&n.removeAttr("required"),// remove the incorrect aria-describedby attribute if it exists
void 0!==i&&n.removeAttr("ariadescribedby"),// add the correct aria-describedby attribute
n.attr("aria-describedby",r),// add an id and an aria-label to the dollar sign svg if they don't already exist
o.length&&o.attr("id",r),// add an aria-label that textually describes the dollar sign
o.attr("aria-label","as a dollar amount")})},
// TO BE REMOVED
updateVideo:function(){
// adds a tab index, so keyboard users can scroll through the transcript
S(".video-player__transcript").attr("tabindex","0"),// use the video title as additional screen-reader-only text on the transcript button
S(".js-video-player-wrapper").each(function(e,t){var n=S(t),i=n.find(".video-player__intro .text-block__title").first().text().replace(/\n/g,"").trim();if(i){var r=n.find(".js-lx-collapsible__trigger");r.length&&(r.html().includes(i)||r.append('<span class="screen-reader-only">&nbsp;for '.concat(i,"</span>")))}})},supportSpaceBarForAnchorButtons:function(){
// support a space bar press for keyboard users
// this is primarily used for inline disclosure superscripts
S('a[role="button"]').on("keypress",Xr.listenForSpacebar)},listenForSpacebar:function(e){
// trigger a click on the link for a spacebar press
32===e.which&&(e.preventDefault(),e.target.click())},addSpaceToScreenReaderOnlyText:function(){
// insert a space before the start of screen-reader-only text
S(".lx-screen-reader-only, .screen-reader-only").each(function(e,t){var n=S(t),i=n.parent().hasClass("disclosures__number")&&n.parent().hasClass("in-list");if(0==n.children().length&&!i){var r=n.text();0<r.length&&n.html("&nbsp;".concat(r.trim()))}})},
// TO BE REMOVED
updateDisclosureListNumber:function(){
// this period and space is useful for screenreaders to distinguish between
// the tooltip number and the start of the content
S(".disclosures__number.in-list").each(function(e,t){var n=S(t);n.html().replace(/\n/g,"").trim().includes('<span class="screen-reader-only">.&nbsp;</span>')||n.append('<span class="screen-reader-only">.&nbsp;</span>')})},updateBreadcrumbs:function(){
// breadcrumbs currently have a <span> between li elements, which isn't allowed by html standards
S("span.breadcrumbs__separator").remove()},updateFilterCompact:function(){
// add type="submit" to the form submission button for filter compact
S(".js-card--filter .input__add-on--button").attr("type","submit")},init:function(){Xr.updateHeader(),Xr.updateFooter(),Xr.updateFields(),Xr.updateFilters(),// TO BE REMOVED
Xr.updateTabs(),// TO BE REMOVED
Xr.updateBullets(),Xr.updateBadges(),// TO BE REMOVED
Xr.updateCardIconLabels(),// TO BE REMOVED
Xr.updateSrOnlyGenericTextInputLabel(),// TO BE REMOVED
Xr.updateQuickQuote(),// TO BE REMOVED
Xr.updateCurrencyFields(),// TO BE REMOVED
Xr.updateVideo(),// TO BE REMOVED
Xr.supportSpaceBarForAnchorButtons(),Xr.addSpaceToScreenReaderOnlyText(),Xr.updateDisclosureListNumber(),// TO BE REMOVED
Xr.updateBreadcrumbs(),Xr.updateFilterCompact()}}).init},Jr={init:(Yr={URL_PARAMETER:"show-sr-only",LX_SCREEN_READER_CLASS:".lx-screen-reader-only",SCREEN_READER_CLASS:".screen-reader-only",VISIBLE_CLASS_NO_DOT:"is-visible",checkUrl:function(){Tr.getUrlParameters()[Yr.URL_PARAMETER]&&(S(Yr.LX_SCREEN_READER_CLASS).addClass(Yr.VISIBLE_CLASS_NO_DOT),S(Yr.SCREEN_READER_CLASS).addClass(Yr.VISIBLE_CLASS_NO_DOT))},init:function(){Yr.checkUrl()}}).init},Qr={Element:function i(e,t,n){
/* eslint-disable prefer-arrow-callback */
return{elem:function(e,t){var n=i(e,t,this);return this.children.push(n),n},children:[],name:e,_attrs:t||{},_parent:n,parent:function(){return this._parent},attrs:function(e){return this._attrs=e,this},text:function(e,t){return t?this._textAfter=e:this._textBefore=e,this},toString:function(){var e=Object.keys(this._attrs).filter(function(e){return this._attrs[e]||0===this._attrs[e]}.bind(this)).map(function(e){return[e,'="',this._attrs[e],'"'].join("")}.bind(this)).join(" ");
/* eslint-disable prefer-template */return["<",this.name,e?" "+e:"",">",this._textBefore].concat(this.children.map(function(e){return e.toString()})).concat([this._textAfter,"</",this.name,">"]).join("");
/* eslint-enable prefer-template */}}}},Zr={createTable:(Kr={CLASSES_NO_DOT:{SCREEN_READER_ONLY:"lx-screen-reader-only",TABLE_WRAPPER:"table-wrapper js-table-wrapper",TABLE:"lx-table table js-table analytics-table lx-table--zebra",CAPTION:"lx-table__caption",THEAD:"lx-table__head",TBODY:"lx-table__content",TR_TH:"lx-table__head-row",TH:"lx-table__head-cell",TR:"lx-table__row",TD:"lx-table__content-cell"},createTable:function(e){var t,n,i,r,o,a=Kr.CLASSES_NO_DOT.TABLE_WRAPPER;// Create the table wrapper
return e.makeScreenReaderOnly||(a+=" ".concat(Kr.CLASSES_NO_DOT.SCREEN_READER_ONLY)),e.classesForAdditionalStyling&&(a+=" ".concat(e.classesForAdditionalStyling)),// Create the thead
i=(// Create the table body with a caption if available
n=(t=Qr.Element("div",{class:a,id:e.tableId})).elem("table",{class:Kr.CLASSES_NO_DOT.TABLE}).elem("caption",{class:Kr.CLASSES_NO_DOT.CAPTION}).text(e.caption)).elem("thead",{class:Kr.CLASSES_NO_DOT.THEAD}),// Add column headers
r=i.elem("tr",{class:Kr.CLASSES_NO_DOT.TR_TH}),e.tableCellsByRow[0].forEach(function(e){r.elem("th",{class:Kr.CLASSES_NO_DOT.TH,scope:"col"}).text(e)}),// Create the tbody
o=n.elem("tbody",{class:Kr.CLASSES_NO_DOT.TBODY}),// Add rows
e.tableCellsByRow.forEach(function(e,t){
// Skip the first row because it is column headers
if(0<t){
// Create the row
var i=o.elem("tr",{class:Kr.CLASSES_NO_DOT.TR});e.forEach(function(e,t){var n={class:Kr.CLASSES_NO_DOT.TD};// The first cell in the row is a row header
0===t&&(n.scope="row"),i.elem("td",n).text(e)})}}),(new DOMParser).parseFromString(t.toString(),"text/html").getElementById(e.tableId)}}).createTable};var eo=992;// header on window resize show the active second level nodes
function to(){S(window).width()>eo?S("body").addClass("lg-screen").removeClass("sm-screen"):S("body").addClass("sm-screen").removeClass("lg-screen")}S(window).on("resize",function(){to()});var no,io,ro,oo,ao,so,lo,co,uo,fo,_o,So,po,Eo,ho,Ao,mo,To,go,Co,Lo,Oo,Ro,vo,Io,yo,bo,No,Do,Mo,Po,wo,Go,Fo={init:(no={CLASSES:{BLOCK_ALERT:{ALERT:".js-block-alert",CLOSE_BUTTON:".js-block-alert__close-button",IS_VISIBLE:".is-visible",WRAPPER:".js-block-alert-wrapper"},TEXT_BLOCK:{PARAGRAPH:".block-alert__paragraph",TITLE:".block-alert__heading"}},DISMISS_STATE:{DISPLAY:"display",DISMISSED:"dismissed"},bindEvents:function(){S(no.CLASSES.BLOCK_ALERT.CLOSE_BUTTON).on("click",no.removeBlockAlert)},checkDismissStatus:function(){
// displays alerts that haven't been previously dismissed
// the dismiss status of an alert is tracked based on a hash of its title and paragraph fields -
// changing the content of the fields will show the alert to the user
// alerts are initially hidden on page load via css - a class is added to display them
S(no.CLASSES.BLOCK_ALERT.ALERT).each(function(e,t){var n=S(t);// exclude block alerts inside of branch locator
if(0===n.closest(".js-branch-locator").length)
// display the alert if it doesn't have a close button
if(1!==n.find(no.CLASSES.BLOCK_ALERT.CLOSE_BUTTON).length)no.displayAlert(n);else{var i=no.generateKey(n),r=localStorage.getItem(i);null===r?(
// if the alert doesn't exist in local storage, add it
// and then display the alert
window.localStorage.setItem(i,no.DISMISS_STATE.DISPLAY),no.displayAlert(n)):
// if it exists, check whether it has been dismissed
// and display it if it hasn't been dismissed
r===no.DISMISS_STATE.DISPLAY&&no.displayAlert(n)}})},displayAlert:function(e){
// add a class to the block alert to make it visible
e.addClass(no.CLASSES.BLOCK_ALERT.IS_VISIBLE.slice(1)),// add a class to the block alert wrapper if there is one
e.closest(no.CLASSES.BLOCK_ALERT.WRAPPER).addClass(no.CLASSES.BLOCK_ALERT.IS_VISIBLE.slice(1))},generateKey:function(e){var t=0,n=0,i=e.find(no.CLASSES.TEXT_BLOCK.TITLE).text(),r=e.find(no.CLASSES.TEXT_BLOCK.PARAGRAPH).text(),o="".concat(i," ").concat(r);if(0<o.length)for(n=0;n<o.length;n++)t=(t<<5)-t+o.charCodeAt(n),// convert to a 32 bit integer
t|=0;return"alert-".concat(t)},removeBlockAlert:function(e){var t=S(e.target).closest(no.CLASSES.BLOCK_ALERT.ALERT),n=t.closest(no.CLASSES.BLOCK_ALERT.WRAPPER),i=no.generateKey(t);// set a local storage value to indicate that the alert has been dismissed
window.localStorage.setItem(i,no.DISMISS_STATE.DISMISSED),n.length?
// remove the whole column for a standalone block alert
n.fadeOut(200,function(){n.remove(),no.setFocus()}):t.length&&
// remove only the block alert for a child block alert
t.fadeOut(200,function(){t.remove(),no.setFocus()})},setFocus:function(){S("body").find(no.CLASSES.BLOCK_ALERT.ALERT).length?S("body "+no.CLASSES.BLOCK_ALERT.ALERT).first().focus():S('[role="main"]').focus()},init:function(){no.bindEvents(),no.checkDismissStatus()}}).init,generateKey:no.generateKey},xo={preRender:(io={ANIMATE_NONE:"none",ANIMATE_SLIDE:"slide",ANIMATE_SLIDE_SPEED:250,ANIMATE_FADE:"fade",ANIMATE_FADE_SPEED:250,ANIMATE_CUSTOM:"custom",ANIMATE_MOBILE_ATTRIBUTE:"data-animate-mobile",ANIMATE_DESKTOP_ATTRIBUTE:"data-animate-desktop",ACCORDION_ATTRIBUTE:"data-accordion",DISMISS_ATTRIBUTE:"data-dismiss",EXPANDED_CLASS_NO_DOT:"is-expanded",INITIALLY_EXPANDED_CLASS_NO_DOT:"is-initially-expanded",LISTENING_FOR_CLICK_CLASS_NO_DOT:"is-listening-for-click",ROTATED_CLASS_NO_DOT:"is-rotated",MOBILE_CLASS_NO_DOT:"sm-screen",DESKTOP_CLASS_NO_DOT:"lg-screen",COLLAPSIBLE_WRAPPER_CLASS:".js-lx-collapsible",COLLAPSIBLE_TRIGGER_CLASS:".js-lx-collapsible__trigger",COLLAPSIBLE_TARGET_CLASS:".js-lx-collapsible__target",COLLAPSIBLE_ICON_CLASS:".js-lx-collapsible__icon",COLLAPSIBLE_TRIGGER_VIA_DELEGATION_CLASS:".js-lx-collapsible__trigger-via-delegation",TRIGGER_PREFIX:"js-collapsible__trigger--",TARGET_PREFIX:"js-collapsible__target--",MOBILE_MENU_TIMING_ADJUSTMENT_FOR_CHROME:200,
// expandedCtr = number of expanded dismissable collapses; tracking = true when a listener is attached; inProgress = true when collapses are being closed; expanded is an object having the trigger id and expanded state of a dismissable collapse
dismissableCollapses:{},dismissMouseDown:null,
// inProgress = true when accordions are being closed, groups is an object where the key is the accordion group id and value is an array of objects with each object having the trigger id and expanded state of an collapse with that accordion group id
accordionCollapses:{},cacheDom:function(){io.$collapsible=S(io.COLLAPSIBLE_WRAPPER_CLASS),io.$trigger=S(io.COLLAPSIBLE_TRIGGER_CLASS),io.$target=S(io.COLLAPSIBLE_TARGET_CLASS),io.$icon=S(io.COLLAPSIBLE_ICON_CLASS),// for efficiency reasons, the dismissableCollapses and accordionCollapses objects are not cached until the user actually interacts with one of the collapses with the related data attributes
io.dismissableCollapses.inProgress=!1,io.accordionCollapses.groups={},io.accordionCollapses.inProgress=!1},bindEvents:function(){io.$trigger.on("click",io.handleTriggerClickEvent),io.$trigger.addClass(io.LISTENING_FOR_CLICK_CLASS_NO_DOT),// the standard collapses work by attaching listeners to individual elements
// this approach uses delegation to attach a listener to the body
// in case a collapse gets added dynamically after bindEvents has run
S(document.body).on("click",io.COLLAPSIBLE_TRIGGER_VIA_DELEGATION_CLASS,io.handleTriggerClickEvent)},handleTriggerClickEvent:function(e){e.preventDefault();var n=S(e.target);// checks to see if the target of the click was the actual trigger <a> or <button>
// this can happen based on the markup of elements inside of the trigger
// tries other strategies to find the trigger
n.hasClass(io.COLLAPSIBLE_TRIGGER_CLASS.slice(1))||(n=S(e.target).closest(io.COLLAPSIBLE_WRAPPER_CLASS).find(io.COLLAPSIBLE_TRIGGER_CLASS).first()).hasClass(io.COLLAPSIBLE_TRIGGER_CLASS.slice(1))||(n=S(e.target).closest(io.COLLAPSIBLE_TRIGGER_CLASS).first());// if the trigger was discovered through delegation, add it to the cached list
// of triggers and mark it as listening for a click
var i=!1;io.$trigger.each(function(e,t){if(t===n[0])return!(i=!0)}),i||(io.$trigger=S(io.COLLAPSIBLE_TRIGGER_CLASS),n.addClass(io.LISTENING_FOR_CLICK_CLASS_NO_DOT)),io.toggleTarget(n),n.focus()},preRender:function(){
// set up the collapse for accessibility - add ids and aria attributes
// expand each collapse target that has the class is-initially-expanded
io.$trigger.each(function(e,t){var n=io.TRIGGER_PREFIX+e,i=S(t).closest(io.COLLAPSIBLE_WRAPPER_CLASS).find(io.COLLAPSIBLE_TARGET_CLASS).first();S(t).find(io.COLLAPSIBLE_ICON_CLASS);// assign an id to the trigger and indicate which target it controls
S(t).attr({id:n,"aria-controls":io.TARGET_PREFIX+e}),// assign an id to the target and indicate which trigger labels it
i.attr({id:io.TARGET_PREFIX+e,"aria-labelledby":n,role:"region"}),// for triggers that are links, set their role to button and provide an href to make sure that they are in the tab order
S(t).is(":not(:button)")&&S(t).attr({role:"button",href:"javascript:void(0);"}),// if the target is marked as initially expanded, expand it
// otherwise, contract it
S(i).hasClass(io.INITIALLY_EXPANDED_CLASS_NO_DOT)?(S(t).attr("aria-expanded","true"),S(t).addClass(io.EXPANDED_CLASS_NO_DOT),S(i).css("display","block")):S(t).attr("aria-expanded",!1)})},toggleTarget:function(e){var t,n=e.closest(io.$collapsible),i=S("#"+e.attr("aria-controls")),r=n.find(io.$icon),o=e.attr(io.ANIMATE_MOBILE_ATTRIBUTE),a=e.attr(io.ANIMATE_DESKTOP_ATTRIBUTE),s=e.attr(io.ACCORDION_ATTRIBUTE),l=e.attr(io.DISMISS_ATTRIBUTE);// determine the type of animation based on the breakpoint
if(e.toggleClass(io.EXPANDED_CLASS_NO_DOT).attr("aria-expanded",function(e,t){return"true"===t?"false":"true"}),t=e.hasClass(io.EXPANDED_CLASS_NO_DOT),S("body").hasClass(io.MOBILE_CLASS_NO_DOT))switch(o){case io.ANIMATE_NONE:io.toggleNoAnimation(i);break;case io.ANIMATE_SLIDE:i.slideToggle(io.ANIMATE_SLIDE_SPEED);break;case io.ANIMATE_FADE:i.fadeToggle(io.ANIMATE_FADE_SPEED);break;case io.ANIMATE_CUSTOM:io.toggleCustomAnimation(i);break;default:i.slideToggle(io.ANIMATE_SLIDE_SPEED)}else if(S("body").hasClass(io.DESKTOP_CLASS_NO_DOT))switch(a){case io.ANIMATE_NONE:io.toggleNoAnimation(i);break;case io.ANIMATE_SLIDE:i.slideToggle(io.ANIMATE_SLIDE_SPEED);break;case io.ANIMATE_FADE:i.fadeToggle(io.ANIMATE_FADE_SPEED);break;case io.ANIMATE_CUSTOM:io.toggleCustomAnimation(i);break;default:i.slideToggle(io.ANIMATE_SLIDE_SPEED)}r.toggleClass(io.ROTATED_CLASS_NO_DOT),// add and remove listeners for clicks or focus outside of expanded collapses with data-dismiss set to true
l&&io.operateDismissableCollapses(e[0].id,t),// if the collapse is part of an accordion and it is opening, close any other open collapses in that accordion
s&&io.operateAccordion(e[0].id,s,t)},toggleNoAnimation:function(e){e.hasClass("no-collapse-animation--open")?(
// close an expanded collapse
e.removeClass("no-collapse-animation--open"),e.addClass("no-collapse-animation--close")):(e.hasClass("no-collapse-animation--close")&&
// expand a closed collapse
e.removeClass("no-collapse-animation--close"),e.addClass("no-collapse-animation--open"))},toggleCustomAnimation:function(e){e.hasClass("custom-collapse-animation--open")?(
// close an expanded collapse
e.removeClass("custom-collapse-animation--open"),e.addClass("custom-collapse-animation--close")):(e.hasClass("custom-collapse-animation--close")&&
// expand a closed collapse
e.removeClass("custom-collapse-animation--close"),e.addClass("custom-collapse-animation--open"))},operateDismissableCollapses:function(e,t){io.dismissableCollapses.expanded?
// the elements have already been cached
io.operateDismissableCollapsesHelper(e,t):
// cache the elements that are dismissable
// this only runs once the first time a dismissable trigger is clicked
io.operateDismissableCollapsesInitialize(e,t)},operateDismissableCollapsesInitialize:function(e,t){io.dismissableCollapses.expanded={},io.dismissableCollapses.expandedCtr=0,io.dismissableCollapses.tracking=!1,S(io.COLLAPSIBLE_TRIGGER_CLASS+"[ "+io.DISMISS_ATTRIBUTE+'="true" ]').map(function(e,t){var n=S(t).hasClass(io.EXPANDED_CLASS_NO_DOT);(io.dismissableCollapses.expanded[t.id]=n)&&io.dismissableCollapses.expandedCtr++}),// add listeners
0<io.dismissableCollapses.expandedCtr&&(
// decrement this because the next function increments the counter
io.dismissableCollapses.expandedCtr--,io.operateDismissableCollapsesAddListener(e))},operateDismissableCollapsesHelper:function(e,t){
// if the current trigger is expanding and no other dismissable collapses are expanded, add listeners
t&&0===io.dismissableCollapses.expandedCtr?io.operateDismissableCollapsesAddListener(e):t&&0<io.dismissableCollapses.expandedCtr?
// if the current trigger is expanding and other dismissable collapses are expanded, increment counter
io.operateDismissableCollapsesIncrement(e):t||1!==io.dismissableCollapses.expandedCtr?!t&&1<io.dismissableCollapses.expandedCtr&&
// if the current trigger is expanding and other dismissable collapses are expanded, decrement counter
io.operateDismissableCollapsesDecrement(e):
// if the current trigger is closing and no other dismissable collapses are expanded, remove listeners
io.operateDismissableCollapsesRemoveListener(e)},operateDismissableCollapsesAddListener:function(e){S(document).on("click focusin",io.handleDismissEvent),io.dismissableCollapses.expanded[e]=!0,io.dismissableCollapses.expandedCtr++,io.dismissableCollapses.tracking=!0},operateDismissableCollapsesIncrement:function(e){io.dismissableCollapses.expanded[e]=!0,io.dismissableCollapses.expandedCtr++},operateDismissableCollapsesRemoveListener:function(e){S(document).off("click focusin",io.handleDismissEvent),io.dismissableCollapses.expanded[e]=!1,io.dismissableCollapses.expandedCtr--,io.dismissableCollapses.tracking=!1},operateDismissableCollapsesDecrement:function(e){io.dismissableCollapses.expanded[e]=!1,io.dismissableCollapses.expandedCtr--},handleDismissEvent:function(e){if(!io.dismissableCollapses.inProgress&&!io.accordionCollapses.inProgress){var t=S(e.target).parents(io.COLLAPSIBLE_WRAPPER_CLASS),i=[];S.each(t,function(e,t){var n=S(t).find(io.COLLAPSIBLE_TRIGGER_CLASS);i.push(n.attr("id"))}),// delay to allow the click event to process before the focusin event to address a bug in Chrome that doesn't fire a click event if the focusin event fires first
"focusin"===e.type?setTimeout(function(){io.handleDismissEventHelper(i)},io.MOBILE_MENU_TIMING_ADJUSTMENT_FOR_CHROME):io.handleDismissEventHelper(i)}},handleDismissEventHelper:function(e){for(var t in io.dismissableCollapses.expanded)
// close all open collapses with the data-dismiss attribute
// only keep open a collapse if the click/focus occurred in it or in one of its children
// IE11 substitution
// if ( !activeCollapseTriggerIds.includes( triggerId ) && _private.dismissableCollapses.expanded[ triggerId ]) {
-1===e.indexOf(t)&&io.dismissableCollapses.expanded[t]&&(io.dismissableCollapses.inProgress=!0,io.toggleTarget(S("#"+t)));io.dismissableCollapses.inProgress=!1},operateAccordion:function(e,t,n){
// cache the elements that have the same accordion group id
// this only runs once for each group the first time a trigger } from the group is activated
io.accordionCollapses.groups[t]?
// the elements have already been cached
io.operateAccordionHelper(e,t,n):io.operateAccordionInitialize(t)},operateAccordionInitialize:function(n){
// cache the elements that have the same accordion group id
// this only runs once for each group the first time a trigger } from the group is activated
io.accordionCollapses.groups[n]=[],S(io.COLLAPSIBLE_TRIGGER_CLASS+"[ "+io.ACCORDION_ATTRIBUTE+'="'+n+'" ]').map(function(e,t){io.accordionCollapses.groups[n].push({id:t.id,expanded:S(t).hasClass(io.EXPANDED_CLASS_NO_DOT)})})},operateAccordionHelper:function(e,t,n){io.dismissableCollapses.inProgress?
// only update the accordion model if a dismiss update is in progress
io.operateAccordionUpdateModel(e,t,n):io.accordionCollapses.inProgress||
// if the target trigger is opening, close all other open triggers in the accordion
io.operateAccordionCloseOtherOpenTriggers(e,t,n)},operateAccordionUpdateModel:function(e,t,n){var i=!0,r=!1,o=void 0;try{for(var a,s=io.accordionCollapses.groups[t][Symbol.iterator]();!(i=(a=s.next()).done);i=!0){var l=a.value;l.id===e&&(l.expanded=!!n)}}catch(e){r=!0,o=e}finally{try{i||null==s.return||s.return()}finally{if(r)throw o}}},operateAccordionCloseOtherOpenTriggers:function(e,t,n){
// if the target trigger is opening, close all other open triggers in the accordion
var i=!0,r=!1,o=void 0;try{for(var a,s=io.accordionCollapses.groups[t][Symbol.iterator]();!(i=(a=s.next()).done);i=!0){var l=a.value;n&&l.id!==e&&l.expanded?(
// close another open trigger
io.accordionCollapses.inProgress=!0,io.toggleTarget(S("#"+l.id)),l.expanded=!1):n||l.id!==e?n&&l.id===e&&(
// active trigger is opening
l.expanded=!0):
// active trigger is closing
l.expanded=!1}}catch(e){r=!0,o=e}finally{try{i||null==s.return||s.return()}finally{if(r)throw o}}io.accordionCollapses.inProgress=!1},init:function(){io.cacheDom(),io.bindEvents(),io.preRender()}}).preRender,toggleTarget:io.toggleTarget,init:io.init},Bo={init:(ro={COLLECTION_URL_PARAMETER:"collection",COLLECTION_CLASS_NO_DOT:"js-collection",COLLECTION_WRAPPER_CLASS_NO_DOT:"js-collection-wrapper",COLLECTION_ITEM_CLASS_NO_DOT:"js-collection__card",COLLECTION_TRIGGER_CLASS:".js-lx-collapsible__trigger",COLLECTION_COLLAPSE_CLASS:".js-lx-collapsible",EXPANDED_CLASS_NO_DOT:"is-expanded",focusOnCollectionOrItem:function(e){
// opens a collection and sets focus on it
// opens the collection that houses a collection item and sets focus on the collection item
var t,n=S("#"+e);0<n.length?(n.hasClass(ro.COLLECTION_WRAPPER_CLASS_NO_DOT)?t=n.find(ro.COLLECTION_TRIGGER_CLASS).first():n.hasClass(ro.COLLECTION_ITEM_CLASS_NO_DOT)&&(t=n.closest(ro.COLLECTION_COLLAPSE_CLASS).find(ro.COLLECTION_TRIGGER_CLASS).first()),t&&(t.hasClass(ro.EXPANDED_CLASS_NO_DOT)||t.click()),Ur(n[0])):console.error("There isn't a collection or collection item with id=\""+e+'" on this page')},checkUrl:function(){
// open and set focus on a collection or collection item if a collection id is provided in the url parameter
// the format is .html?collection=[id]
var e=Tr.getUrlParameters()[ro.COLLECTION_URL_PARAMETER];e&&ro.focusOnCollectionOrItem(e)},init:function(){ro.checkUrl()}}).init},Uo={init:(oo={CLASSES:{DTC:".js-display-tagged-cards",DTC_MORE_BUTTON:".js-display-tagged-cards__more-button",DTC_MORE_BUTTON_VIA_DELEGATION_CLASS:".js-display-tagged-cards__more-button-via-delegation",DTC_COLLAPSIBLE:".js-display-tagged-cards__collapsible",DTC_TAGGED_CARD:".js-tagged-card"},CLASSES_NO_DOT:{DISPLAY_NONE:"display-none"},ATTRIBUTES:{TABINDEX:"tabindex",SRC:"src",SRCSET:"srcset",DATA_SRC:"data-src",DATA_SRCSET:"data-srcset"},FADE_SPEEDS:{SLOW:200,MEDIUM:400,FAST:600},bindEvents:function(){S(oo.CLASSES.DTC_MORE_BUTTON).on("click",oo.displayNextGroupOfCards),// the standard collapses work by attaching listeners to individual elements
// this approach uses delegation to attach a listener to the body
// in case a display tagged cards gets added dynamically after bindEvents has run
S(document.body).on("click",oo.CLASSES.DTC_MORE_BUTTON_VIA_DELEGATION_CLASS,oo.displayNextGroupOfCards)},hideAdditionalCardGroups:function(){S(oo.CLASSES.DTC).each(function(e,t){S(t).find(oo.CLASSES.DTC_COLLAPSIBLE).slice(1).addClass(oo.CLASSES_NO_DOT.DISPLAY_NONE)})},displayNextGroupOfCards:function(e){var t=S(e.target).closest(oo.CLASSES.DTC_MORE_BUTTON),n=t.closest(oo.CLASSES.DTC_COLLAPSIBLE),i=n.next(oo.CLASSES.DTC_COLLAPSIBLE),r=n.find(oo.CLASSES.DTC_TAGGED_CARD),o=r.first();r.each(function(e,t){oo.updateResultToActualImage(t)}),t.fadeOut(oo.FADE_SPEEDS.MEDIUM),i.length&&S(i).fadeIn(oo.FADE_SPEEDS.MEDIUM),o.attr(oo.ATTRIBUTES.TABINDEX,-1),o.focus()},updateResultToActualImage:function(e){var t=S(e).find(".card__image-wrapper img"),n=t.attr(oo.ATTRIBUTES.DATA_SRCSET),i=t.attr(oo.ATTRIBUTES.DATA_SRC);n&&(t.removeAttr(oo.ATTRIBUTES.DATA_SRCSET),t.attr(oo.ATTRIBUTES.SRCSET,n)),i&&(t.removeAttr(oo.ATTRIBUTES.DATA_SRC),t.attr(oo.ATTRIBUTES.SRC,i))},init:function(){oo.bindEvents(),oo.hideAdditionalCardGroups()}}).init},Ho={init:(ao={
// MOBILE_CLASS_NO_DOT: 'sm-screen',
DISCLOSURES_TRIGGER_CLASS:".js-disclosures__collapse-trigger",USER_INIT_CLASS:".js-user-init",MOBILE_THRESHOLD:992,
// cacheDom: function cacheDom() {},
bindEvents:function(){S(window).on("resize",function(){ao.disclosureCollapseStateHandler()}),S(ao.DISCLOSURES_TRIGGER_CLASS).click(function(){ao.disclosureCollapseUserInit()})},disclosureCollapseStateHandler:function(){var e=S(window).width();S(ao.DISCLOSURES_TRIGGER_CLASS).hasClass(ao.USER_INIT_CLASS)||(e>=ao.MOBILE_THRESHOLD&&!S(ao.DISCLOSURES_TRIGGER_CLASS).hasClass("is-expanded")?xo.toggleTarget(S(ao.DISCLOSURES_TRIGGER_CLASS)):e<ao.MOBILE_THRESHOLD&&S(ao.DISCLOSURES_TRIGGER_CLASS).hasClass("is-expanded")&&xo.toggleTarget(S(ao.DISCLOSURES_TRIGGER_CLASS)))},disclosureCollapseUserInit:function(){S(ao.DISCLOSURES_TRIGGER_CLASS).hasClass(ao.USER_INIT_CLASS)||S(ao.DISCLOSURES_TRIGGER_CLASS).addClass(ao.USER_INIT_CLASS)},init:function(){ao.bindEvents(),ao.disclosureCollapseStateHandler()}}).init},ko=Math.max,jo=Math.min,Vo=ke("splice");
// `Array.prototype.splice` method
// https://tc39.github.io/ecma262/#sec-array.prototype.splice
// with adding support of @@species
Ne({target:"Array",proto:!0,forced:!Vo},{splice:function(e,t/* , ...items */){var n,i,r,o,a,s,l=Rt(this),c=le(l.length),d=ue(e,c),u=arguments.length;if(0===u?n=i=0:i=1===u?(n=0,c-d):(n=u-2,jo(ko(ae(t),0),c-d)),9007199254740991<c+n-i)throw TypeError("Maximum allowed length exceeded");for(r=Ii(l,i),o=0;o<i;o++)(a=d+o)in l&&Ge(r,o,l[a]);if(n<(r.length=i)){for(o=d;o<c-i;o++)s=o+n,(a=o+i)in l?l[s]=l[a]:delete l[s];for(o=c;c-i+n<o;o--)delete l[o-1]}else if(i<n)for(o=c-i;d<o;o--)s=o+n-1,(a=o+i-1)in l?l[s]=l[a]:delete l[s];for(o=0;o<n;o++)l[o+d]=arguments[o+2];return l.length=c-i+n,r}}),
// @@match logic
Bt("match",1,function(i,c,d){return[
// `String.prototype.match` method
// https://tc39.github.io/ecma262/#sec-string.prototype.match
function(e){var t=f(this),n=null==e?void 0:e[i];return void 0!==n?n.call(e,t):new RegExp(e)[i](String(t))},
// `RegExp.prototype[@@match]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@match
function(e){var t=d(c,e,this);if(t.done)return t.value;var n=w(e),i=String(this);if(!n.global)return wt(n,i);for(var r,o=n.unicode,a=[],s=n.lastIndex=0;null!==(r=wt(n,i));){var l=String(r[0]);""===(a[s]=l)&&(n.lastIndex=It(i,le(n.lastIndex),o)),s++}return 0===s?null:a}]}),so=window,lo=function(e,t){var u=Array.prototype.slice,n=e.console,f=void 0===n?function(){}:function(e){n.error(e)};// helper function for logging errors
// $.error breaks jQuery chaining
// ----- jQueryBridget ----- //
function i(c,r,d){(d=d||t||e.jQuery)&&(// add option method -> $().plugin('option', {...})
r.prototype.option||(
// option setter
r.prototype.option=function(e){
// bail out if not an object
d.isPlainObject(e)&&(this.options=d.extend(!0,this.options,e))}),// make jQuery plugin
d.fn[c]=function(e
/*, arg1 */){if("string"!=typeof e)// just $().plugin({ options })
return i=e,this.each(function(e,t){var n=d.data(t,c);n?(
// set options & init
n.option(i),n._init()):(
// initialize new instance
n=new r(t,i),d.data(t,c,n))}),this;// $().plugin('methodName')
var t,o,a,s,l,i,n=u.call(arguments,1);return a=n,l="$()."+c+'("'+(o=e)+'")',(t=this).each(function(e,t){
// get instance
var n=d.data(t,c);if(n){var i=n[o];if(i&&"_"!=o.charAt(0)){// apply method, get return value
var r=i.apply(n,a);// set return value if value is returned, use only first value
s=void 0===s?r:s}else f(l+" is not a valid method")}else f(c+" not initialized. Cannot call methods, i.e. "+l)}),void 0!==s?s:t},o(d))}// ----- updateJQuery ----- //
// set $.bridget for v1 backwards compatibility
function o(e){!e||e&&e.bridget||(e.bridget=i)}// -----  ----- //
return o(t||e.jQuery),i},
// universal module definition
/*jshint strict: false */
/* globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("jquery-bridget/jquery-bridget",["jquery"],function(e){return lo(so,e)}):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=lo(so,require("jquery")):
// browser global
so.jQueryBridget=lo(so,so.jQuery),
/**
   * EvEmitter v1.0.3
   * Lil' event emitter
   * MIT License
   */
/* jshint unused: true, undef: true, strict: true */
co=window,uo=function(){function e(){}var t=e.prototype;return t.on=function(e,t){if(e&&t){// set events hash
var n=this._events=this._events||{},i=n[e]=n[e]||[];// set listeners array
// only add once
return-1==i.indexOf(t)&&i.push(t),this}},t.once=function(e,t){if(e&&t){// add event
this.on(e,t);// set once flag
// set onceEvents hash
var n=this._onceEvents=this._onceEvents||{};// set onceListeners object
// set flag
return(n[e]=n[e]||{})[t]=!0,this}},t.off=function(e,t){var n=this._events&&this._events[e];if(n&&n.length){var i=n.indexOf(t);return-1!=i&&n.splice(i,1),this}},t.emitEvent=function(e,t){var n=this._events&&this._events[e];if(n&&n.length){var i=0,r=n[i];t=t||[];for(// once stuff
var o=this._onceEvents&&this._onceEvents[e];r;){var a=o&&o[r];a&&(
// remove listener
// remove before trigger to prevent recursion
this.off(e,r),// unset once flag
delete o[r]),// trigger listener
r.apply(this,t),r=n[// get next listener
i+=a?0:1]}return this}},e},
// universal module definition
/* jshint strict: false */
/* globals define, module, window */
"function"==typeof define&&define.amd?
// AMD - RequireJS
define("ev-emitter/ev-emitter",uo):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS - Browserify, Webpack
module.exports=uo():
// Browser globals
co.EvEmitter=uo(),
/*!
   * getSize v2.0.2
   * measure size of elements
   * MIT license
   */
/*jshint browser: true, strict: true, undef: true, unused: true */
/*global define: false, module: false, console: false */
fo=window,_o=function(){
// get a number } from a string, not a percentage
function h(e){var t=parseFloat(e);// not a percent like '100%', and a number
return-1==e.indexOf("%")&&!isNaN(t)&&t}var n="undefined"==typeof console?function(){}:function(e){console.error(e)},A=["paddingLeft","paddingRight","paddingTop","paddingBottom","marginLeft","marginRight","marginTop","marginBottom","borderLeftWidth","borderRightWidth","borderTopWidth","borderBottomWidth"],m=A.length;// -------------------------- measurements -------------------------- //
// -------------------------- getStyle -------------------------- //
/**
     * getStyle, get style of element, check for Firefox bug
     * https://bugzilla.mozilla.org/show_bug.cgi?id=548397
     */
function T(e){var t=getComputedStyle(e);return t||n("Style returned "+t+". Are you running this code in a hidden iframe on Firefox? See http://bit.ly/getsizebug1"),t}// -------------------------- setup -------------------------- //
var g,C=!1;// -------------------------- getSize -------------------------- //
function L(e){// do not proceed on non-objects
if(
/**
     * setup
     * check isBoxSizerOuter
     * do on first getSize() rather than on page load for Firefox bug
     */
function(){
// setup once
if(!C){C=!0;// -------------------------- box sizing -------------------------- //
/**
       * WebKit measures the outer-width on style.width on border-box elems
       * IE & Firefox<29 measures the inner-width
       */
var e=document.createElement("div");e.style.width="200px",e.style.padding="1px 2px 3px 4px",e.style.borderStyle="solid",e.style.borderWidth="1px 2px 3px 4px",e.style.boxSizing="border-box";var t=document.body||document.documentElement;t.appendChild(e);var n=T(e);L.isBoxSizeOuter=g=200==h(n.width),t.removeChild(e)}}(),// use querySeletor if elem is string
"string"==typeof e&&(e=document.querySelector(e)),e&&"object"==B(e)&&e.nodeType){var t=T(e);// if hidden, everything is 0
if("none"==t.display)return function(){for(var e={width:0,height:0,innerWidth:0,innerHeight:0,outerWidth:0,outerHeight:0},t=0;t<m;t++)e[A[t]]=0;return e}();var n={};n.width=e.offsetWidth,n.height=e.offsetHeight;// get all measurements
for(var i=n.isBorderBox="border-box"==t.boxSizing,r=0;r<m;r++){var o=A[r],a=t[o],s=parseFloat(a);// any 'auto', 'medium' value will be 0
n[o]=isNaN(s)?0:s}var l=n.paddingLeft+n.paddingRight,c=n.paddingTop+n.paddingBottom,d=n.marginLeft+n.marginRight,u=n.marginTop+n.marginBottom,f=n.borderLeftWidth+n.borderRightWidth,_=n.borderTopWidth+n.borderBottomWidth,S=i&&g,p=h(t.width);!1!==p&&(n.width=p+(// add padding and border unless it's already including it
S?0:l+f));var E=h(t.height);return!1!==E&&(n.height=E+(// add padding and border unless it's already including it
S?0:c+_)),n.innerWidth=n.width-(l+f),n.innerHeight=n.height-(c+_),n.outerWidth=n.width+d,n.outerHeight=n.height+u,n}}return L},"function"==typeof define&&define.amd?
// AMD
define("get-size/get-size",[],function(){return _o()}):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=_o():
// browser global
fo.getSize=_o(),
/**
   * matchesSelector v2.0.2
   * matchesSelector( element, '.selector' )
   * MIT license
   */
/*jshint browser: true, strict: true, undef: true, unused: true */
So=window,po=function(){var n=function(){var e=window.Element.prototype;// check for the standard method name first
if(e.matches)return"matches";// check un-prefixed
if(e.matchesSelector)return"matchesSelector";// check vendor prefixes
for(var t=["webkit","moz","ms","o"],n=0;n<t.length;n++){var i=t[n]+"MatchesSelector";if(e[i])return i}}();return function(e,t){return e[n](t)}},"function"==typeof define&&define.amd?
// AMD
define("desandro-matches-selector/matches-selector",po):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=po():
// browser global
So.matchesSelector=po(),
/**
   * Fizzy UI utils v2.0.5
   * MIT license
   */
/*jshint browser: true, undef: true, unused: true, strict: true */
Eo=window,ho=function(c,o){var d={// ----- extend ----- //
// extends objects
extend:function(e,t){for(var n in t)e[n]=t[n];return e},// ----- modulo ----- //
modulo:function(e,t){return(e%t+t)%t},// ----- makeArray ----- //
// turn element or nodeList into an array
makeArray:function(e){var t=[];if(Array.isArray(e))
// use object if already an array
t=e;else if(e&&"object"==B(e)&&"number"==typeof e.length)
// convert nodeList to array
for(var n=0;n<e.length;n++)t.push(e[n]);else
// array of single index
t.push(e);return t},// ----- removeFrom ----- //
removeFrom:function(e,t){var n=e.indexOf(t);-1!=n&&e.splice(n,1)},// ----- getParent ----- //
getParent:function(e,t){for(;e.parentNode&&e!=document.body;)if(e=e.parentNode,o(e,t))return e},// ----- getQueryElement ----- //
// use element as selector string
getQueryElement:function(e){return"string"==typeof e?document.querySelector(e):e},// ----- handleEvent ----- //
// enable .ontype to trigger } from .addEventListener( elem, 'type' )
handleEvent:function(e){var t="on"+e.type;this[t]&&this[t](e)},// ----- filterFindElements ----- //
filterFindElements:function(e,i){
// make array of elems
e=d.makeArray(e);var r=[];return e.forEach(function(e){
// check that elem is an actual element
if(e instanceof HTMLElement)// add elem if no selector
if(i){// filter & find items if we have a selector
// filter
o(e,i)&&r.push(e);// find children
// concat childElems to filterFound array
for(var t=e.querySelectorAll(i),n=0;n<t.length;n++)r.push(t[n])}else r.push(e)}),r},// ----- debounceMethod ----- //
debounceMethod:function(e,t,i){
// original method
var r=e.prototype[t],o=t+"Timeout";e.prototype[t]=function(){var e=this[o];e&&clearTimeout(e);var t=arguments,n=this;this[o]=setTimeout(function(){r.apply(n,t),delete n[o]},i||100)}},// ----- docReady ----- //
docReady:function(e){var t=document.readyState;"complete"==t||"interactive"==t?
// do async to allow for other scripts to run. metafizzy/flickity#441
setTimeout(e):document.addEventListener("DOMContentLoaded",e)},// ----- htmlInit ----- //
// http://jamesroberts.name/blog/2010/02/22/string-functions-for-javascript-trim-to-camel-case-to-dashed-and-to-underscore/
toDashed:function(e){return e.replace(/(.)([A-Z])/g,function(e,t,n){return t+"-"+n}).toLowerCase()}},u=c.console;// -----  ----- //
/**
     * allow user to initialize classes via [data-namespace] or .js-namespace class
     * htmlInit( Widget, 'widgetName' )
     * options are parsed } from data-namespace-options
     */
return d.htmlInit=function(s,l){d.docReady(function(){var e=d.toDashed(l),r="data-"+e,t=document.querySelectorAll("["+r+"]"),n=document.querySelectorAll(".js-"+e),i=d.makeArray(t).concat(d.makeArray(n)),o=r+"-options",a=c.jQuery;i.forEach(function(t){var e,n=t.getAttribute(r)||t.getAttribute(o);try{e=n&&JSON.parse(n)}catch(e){
// log error, do not initialize
return void(u&&u.error("Error parsing "+r+" on "+t.className+": "+e))}// initialize
var i=new s(t,e);// make available via $().data('namespace')
a&&a.data(t,l,i)})})},d},
// universal module definition
/*jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("fizzy-ui-utils/utils",["desandro-matches-selector/matches-selector"],function(e){return ho(Eo,e)}):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=ho(Eo,require("desandro-matches-selector")):
// browser global
Eo.fizzyUIUtils=ho(Eo,Eo.matchesSelector),
/**
   * Outlayer Item
   */
Ao=window,mo=function(e,t){// -------------------------- CSS3 support -------------------------- //
var n=document.documentElement.style,i="string"==typeof n.transition?"transition":"WebkitTransition",r="string"==typeof n.transform?"transform":"WebkitTransform",o={WebkitTransition:"webkitTransitionEnd",transition:"transitionend"}[i],a={transform:r,transition:i,transitionDuration:i+"Duration",transitionProperty:i+"Property",transitionDelay:i+"Delay"};// -------------------------- Item -------------------------- //
function s(e,t){e&&(this.element=e,// parent layout class, i.e. Masonry, Isotope, or Packery
this.layout=t,this.position={x:0,y:0},this._create())}// inherit EvEmitter
var l=s.prototype=Object.create(e.prototype);l.constructor=s,l._create=function(){
// transition objects
this._transn={ingProperties:{},clean:{},onEnd:{}},this.css({position:"absolute"})},// trigger specified handler for event type
l.handleEvent=function(e){var t="on"+e.type;this[t]&&this[t](e)},l.getSize=function(){this.size=t(this.element)},
/**
     * apply CSS styles to element
     * @param {Object} style
     */
l.css=function(e){var t=this.element.style;for(var n in e){t[a[n]||n]=e[n]}},// measure position, and sets it
l.getPosition=function(){var e=getComputedStyle(this.element),t=this.layout._getOption("originLeft"),n=this.layout._getOption("originTop"),i=e[t?"left":"right"],r=e[n?"top":"bottom"],o=this.layout.size,a=-1!=i.indexOf("%")?parseFloat(i)/100*o.width:parseInt(i,10),s=-1!=r.indexOf("%")?parseFloat(r)/100*o.height:parseInt(r,10);// clean up 'auto' or other non-integer values
a=isNaN(a)?0:a,s=isNaN(s)?0:s,// remove padding } from measurement
a-=t?o.paddingLeft:o.paddingRight,s-=n?o.paddingTop:o.paddingBottom,this.position.x=a,this.position.y=s},// set settled position, apply padding
l.layoutPosition=function(){var e=this.layout.size,t={},n=this.layout._getOption("originLeft"),i=this.layout._getOption("originTop"),r=n?"paddingLeft":"paddingRight",o=n?"left":"right",a=n?"right":"left",s=this.position.x+e[r];// set in percentage or pixels
t[o]=this.getXValue(s),// reset other property
t[a]="";// y
var l=i?"paddingTop":"paddingBottom",c=i?"top":"bottom",d=i?"bottom":"top",u=this.position.y+e[l];// set in percentage or pixels
t[c]=this.getYValue(u),// reset other property
t[d]="",this.css(t),this.emitEvent("layout",[this])},l.getXValue=function(e){var t=this.layout._getOption("horizontal");return this.layout.options.percentPosition&&!t?e/this.layout.size.width*100+"%":e+"px"},l.getYValue=function(e){var t=this.layout._getOption("horizontal");return this.layout.options.percentPosition&&t?e/this.layout.size.height*100+"%":e+"px"},l._transitionTo=function(e,t){this.getPosition();// get current x & y } from top/left
var n=this.position.x,i=this.position.y,r=parseInt(e,10),o=parseInt(t,10),a=r===this.position.x&&o===this.position.y;// if did not move and not transitioning, just go to layout
if(// save end position
this.setPosition(e,t),!a||this.isTransitioning){var s=e-n,l=t-i,c={};c.transform=this.getTranslate(s,l),this.transition({to:c,onTransitionEnd:{transform:this.layoutPosition},isCleaning:!0})}else this.layoutPosition()},l.getTranslate=function(e,t){return"translate3d("+(e=this.layout._getOption("originLeft")?e:-e)+"px, "+(t=this.layout._getOption("originTop")?t:-t)+"px, 0)"},// non transition + transform support
l.goTo=function(e,t){this.setPosition(e,t),this.layoutPosition()},l.moveTo=l._transitionTo,l.setPosition=function(e,t){this.position.x=parseInt(e,10),this.position.y=parseInt(t,10)},// ----- transition ----- //
/**
     * @param {Object} style - CSS
     * @param {Function} onTransitionEnd
     */
// non transition, just trigger callback
l._nonTransition=function(e){for(var t in this.css(e.to),e.isCleaning&&this._removeStyles(e.to),e.onTransitionEnd)e.onTransitionEnd[t].call(this)},
/**
     * proper transition
     * @param {Object} args - arguments
     *   @param {Object} to - style to transition to
     *   @param {Object} } from - style to start transition from
     *   @param {Boolean} isCleaning - removes transition styles after transition
     *   @param {Function} onTransitionEnd - callback
     */
l.transition=function(e){
// redirect to nonTransition if no transition duration
if(parseFloat(this.layout.options.transitionDuration)){var t=this._transn;// keep track of onTransitionEnd callback by css property
for(var n in e.onTransitionEnd)t.onEnd[n]=e.onTransitionEnd[n];// keep track of properties that are transitioning
for(n in e.to)t.ingProperties[n]=!0,// keep track of properties to clean up when transition is done
e.isCleaning&&(t.clean[n]=!0);// set } from styles
if(e.from){this.css(e.from);// force redraw. http://blog.alexmaccaw.com/css-transitions
this.element.offsetHeight;// hack for JSHint to hush about unused var
null}// enable transition
this.enableTransition(e.to),// set styles that are transitioning
this.css(e.to),this.isTransitioning=!0}else this._nonTransition(e)};var c="opacity,"+r.replace(/([A-Z])/g,function(e){return"-"+e.toLowerCase()});l.enableTransition=function(){
// HACK changing transitionProperty during a transition
// will cause transition to jump
if(!this.isTransitioning){// make `transition: foo, bar, baz` } from style object
// HACK un-comment this when enableTransition can work
// while a transition is happening
// var transitionValues = [];
// for ( var prop in style ) {
//   // dash-ify camelCased properties like WebkitTransition
//   prop = vendorProperties[ prop ] || prop;
//   transitionValues.push( toDashedAll( prop ) );
// }
// munge number to millisecond, to match stagger
var e=this.layout.options.transitionDuration;e="number"==typeof e?e+"ms":e,// enable transition styles
this.css({transitionProperty:c,transitionDuration:e,transitionDelay:this.staggerDelay||0}),// listen for transition end event
this.element.addEventListener(o,this,!1)}},// ----- events ----- //
l.onwebkitTransitionEnd=function(e){this.ontransitionend(e)},l.onotransitionend=function(e){this.ontransitionend(e)};// properties that I munge to make my life easier
var d={"-webkit-transform":"transform"};l.ontransitionend=function(e){
// disregard bubbled events } from children
if(e.target===this.element){var t=this._transn,n=d[e.propertyName]||e.propertyName;// get property name of transitioned property, convert to prefix-free
// trigger onTransitionEnd callback
if(// remove property that has completed transitioning
delete t.ingProperties[n],// check if any properties are still transitioning
function(e){for(var t in e)return!1;return!0}(t.ingProperties)&&
// all properties have completed transitioning
this.disableTransition(),// clean style
n in t.clean&&(
// clean up style
this.element.style[e.propertyName]="",delete t.clean[n]),n in t.onEnd)t.onEnd[n].call(this),delete t.onEnd[n];this.emitEvent("transitionEnd",[this])}},l.disableTransition=function(){this.removeTransitionStyles(),this.element.removeEventListener(o,this,!1),this.isTransitioning=!1},
/**
     * removes style property } from element
     * @param {Object} style
     **/
l._removeStyles=function(e){
// clean up transition styles
var t={};for(var n in e)t[n]="";this.css(t)};var u={transitionProperty:"",transitionDuration:"",transitionDelay:""};return l.removeTransitionStyles=function(){
// remove transition
this.css(u)},// ----- stagger ----- //
l.stagger=function(e){e=isNaN(e)?0:e,this.staggerDelay=e+"ms"},// ----- show/hide/remove ----- //
// remove element } from DOM
l.removeElem=function(){this.element.parentNode.removeChild(this.element),// remove display: none
this.css({display:""}),this.emitEvent("remove",[this])},l.remove=function(){
// just remove element if no transition support or no transition
i&&parseFloat(this.layout.options.transitionDuration)?(// start transition
this.once("transitionEnd",function(){this.removeElem()}),this.hide()):this.removeElem()},l.reveal=function(){delete this.isHidden,// remove display: none
this.css({display:""});var e=this.layout.options,t={};t[this.getHideRevealTransitionEndProperty("visibleStyle")]=this.onRevealTransitionEnd,this.transition({from:e.hiddenStyle,to:e.visibleStyle,isCleaning:!0,onTransitionEnd:t})},l.onRevealTransitionEnd=function(){
// check if still visible
// during transition, item may have been hidden
this.isHidden||this.emitEvent("reveal")},
/**
     * get style property use for hide/reveal transition end
     * @param {String} styleProperty - hiddenStyle/visibleStyle
     * @returns {String}
     */
l.getHideRevealTransitionEndProperty=function(e){var t=this.layout.options[e];// use opacity
if(t.opacity)return"opacity";// get first property
for(var n in t)return n},l.hide=function(){
// set flag
this.isHidden=!0,// remove display: none
this.css({display:""});var e=this.layout.options,t={};t[this.getHideRevealTransitionEndProperty("hiddenStyle")]=this.onHideTransitionEnd,this.transition({from:e.visibleStyle,to:e.hiddenStyle,
// keep hidden stuff hidden
isCleaning:!0,onTransitionEnd:t})},l.onHideTransitionEnd=function(){
// check if still hidden
// during transition, item may have been un-hidden
this.isHidden&&(this.css({display:"none"}),this.emitEvent("hide"))},l.destroy=function(){this.css({position:"",left:"",right:"",top:"",bottom:"",transition:"",transform:""})},s},
// universal module definition
/* jshint strict: false */
/* globals define, module, require */
"function"==typeof define&&define.amd?
// AMD - RequireJS
define("outlayer/item",["ev-emitter/ev-emitter","get-size/get-size"],mo):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS - Browserify, Webpack
module.exports=mo(require("ev-emitter"),require("get-size")):(
// browser global
Ao.Outlayer={},Ao.Outlayer.Item=mo(Ao.EvEmitter,Ao.getSize)),
/*!
   * Outlayer v2.1.0
   * the brains and guts of a layout library
   * MIT license
   */
To=window,go=function(e,t,r,o,i){var a=e.console,s=e.jQuery,n=function(){},l=0,c={};
/**
     * @param {Element, String} element
     * @param {Object} options
     * @constructor
     */
function d(e,t){var n=o.getQueryElement(e);if(n){this.element=n,// add jQuery
s&&(this.$element=s(this.element)),// options
this.options=o.extend({},this.constructor.defaults),this.option(t);// add id for Outlayer.getFromElement
var i=++l;this.element.outlayerGUID=i,// associate via id
// kick it off
(// expando
c[i]=this)._create(),this._getOption("initLayout")&&this.layout()}else a&&a.error("Bad element for "+this.constructor.namespace+": "+(n||e))}// settings are for internal use only
d.namespace="outlayer",d.Item=i,// default options
d.defaults={containerStyle:{position:"relative"},initLayout:!0,originLeft:!0,originTop:!0,resize:!0,resizeContainer:!0,
// item options
transitionDuration:"0.4s",hiddenStyle:{opacity:0,transform:"scale(0.001)"},visibleStyle:{opacity:1,transform:"scale(1)"}};var u=d.prototype;// inherit EvEmitter
function f(e){function t(){e.apply(this,arguments)}return(t.prototype=Object.create(e.prototype)).constructor=t}// ----- helpers ----- //
// how many milliseconds are in each unit
o.extend(u,t.prototype),
/**
     * set options
     * @param {Object} opts
     */
u.option=function(e){o.extend(this.options,e)},
/**
     * get backwards compatible option value, check old name
     */
u._getOption=function(e){var t=this.constructor.compatOptions[e];return t&&void 0!==this.options[t]?this.options[t]:this.options[e]},d.compatOptions={
// currentName: oldName
initLayout:"isInitLayout",horizontal:"isHorizontal",layoutInstant:"isLayoutInstant",originLeft:"isOriginLeft",originTop:"isOriginTop",resize:"isResizeBound",resizeContainer:"isResizingContainer"},u._create=function(){
// get items } from children
this.reloadItems(),// elements that affect layout, but are not laid out
this.stamps=[],this.stamp(this.options.stamp),// set container style
o.extend(this.element.style,this.options.containerStyle),this._getOption("resize")&&this.bindResize()},// goes through all children again and gets bricks in proper order
u.reloadItems=function(){
// collection of item elements
this.items=this._itemize(this.element.children)},
/**
     * turn elements into Outlayer.Items to be used in layout
     * @param {Array or NodeList or HTMLElement} elems
     * @returns {Array} items - collection of new Outlayer Items
     */
u._itemize=function(e){for(var t=this._filterFindItemElements(e),n=this.constructor.Item,i=[],r=0;r<t.length;r++){var o=new n(t[r],this);i.push(o)}return i},
/**
     * get item elements to be used in layout
     * @param {Array or NodeList or HTMLElement} elems
     * @returns {Array} items - item elements
     */
u._filterFindItemElements=function(e){return o.filterFindElements(e,this.options.itemSelector)},
/**
     * getter method for getting item elements
     * @returns {Array} elems - collection of item elements
     */
u.getItemElements=function(){return this.items.map(function(e){return e.element})},// ----- init & layout ----- //
/**
     * lays out all items
     */
u.layout=function(){this._resetLayout(),this._manageStamps();// don't animate first layout
var e=this._getOption("layoutInstant"),t=void 0!==e?e:!this._isLayoutInited;this.layoutItems(this.items,t),// flag for initalized
this._isLayoutInited=!0},// _init is alias for layout
u._init=u.layout,
/**
     * logic before any new layout
     */
u._resetLayout=function(){this.getSize()},u.getSize=function(){this.size=r(this.element)},
/**
     * get measurement } from option, for columnWidth, rowHeight, gutter
     * if option is String -> get element } from selector string, & get size of element
     * if option is Element -> get size of element
     * else use option as a number
     *
     * @param {String} measurement
     * @param {String} size - width or height
     * @private
     */
u._getMeasurement=function(e,t){var n,i=this.options[e];// use size of element, if element
this[e]=i?(
// use option as an element
"string"==typeof i?n=this.element.querySelector(i):i instanceof HTMLElement&&(n=i),n?r(n)[t]:i):0},
/**
     * layout a collection of item elements
     * @api public
     */
u.layoutItems=function(e,t){e=this._getItemsForLayout(e),this._layoutItems(e,t),this._postLayout()},
/**
     * get the items to be laid out
     * you may want to skip over some items
     * @param {Array} items
     * @returns {Array} items
     */
u._getItemsForLayout=function(e){return e.filter(function(e){return!e.isIgnored})},
/**
     * layout items
     * @param {Array} items
     * @param {Boolean} isInstant
     */
u._layoutItems=function(e,n){if(this._emitCompleteOnItems("layout",e),e&&e.length){var i=[];e.forEach(function(e){
// get x/y object } from method
var t=this._getItemLayoutPosition(e);// enqueue
t.item=e,t.isInstant=n||e.isLayoutInstant,i.push(t)},this),this._processLayoutQueue(i)}},
/**
     * get item layout position
     * @param {Outlayer.Item} item
     * @returns {Object} x and y position
     */
u._getItemLayoutPosition=function(){return{x:0,y:0}},
/**
     * iterate over array and position each item
     * Reason being - separating this logic prevents 'layout invalidation'
     * thx @paul_irish
     * @param {Array} queue
     */
u._processLayoutQueue=function(e){this.updateStagger(),e.forEach(function(e,t){this._positionItem(e.item,e.x,e.y,e.isInstant,t)},this)},// set stagger } from option in milliseconds number
u.updateStagger=function(){var e=this.options.stagger;if(null!=e)return this.stagger=// munge time-like parameter into millisecond number
// '0.4s' -> 40
function(e){if("number"==typeof e)return e;var t=e.match(/(^\d*\.?\d*)(\w*)/),n=t&&t[1],i=t&&t[2];if(!n.length)return 0;n=parseFloat(n);var r=_[i]||1;return n*r}// ----- fin ----- //
// back in global
(e),this.stagger;this.stagger=0},
/**
     * Sets position of item in DOM
     * @param {Outlayer.Item} item
     * @param {Number} x - horizontal position
     * @param {Number} y - vertical position
     * @param {Boolean} isInstant - disables transitions
     */
u._positionItem=function(e,t,n,i,r){i?
// if not transition, just set CSS
e.goTo(t,n):(e.stagger(r*this.stagger),e.moveTo(t,n))},
/**
     * Any logic you want to do after each layout,
     * i.e. size the container
     */
u._postLayout=function(){this.resizeContainer()},u.resizeContainer=function(){if(this._getOption("resizeContainer")){var e=this._getContainerSize();e&&(this._setContainerMeasure(e.width,!0),this._setContainerMeasure(e.height,!1))}},
/**
     * Sets width or height of container if returned
     * @returns {Object} size
     *   @param {Number} width
     *   @param {Number} height
     */
u._getContainerSize=n,
/**
     * @param {Number} measure - size of width or height
     * @param {Boolean} isWidth
     */
u._setContainerMeasure=function(e,t){if(void 0!==e){var n=this.size;// add padding and border width if border box
n.isBorderBox&&(e+=t?n.paddingLeft+n.paddingRight+n.borderLeftWidth+n.borderRightWidth:n.paddingBottom+n.paddingTop+n.borderTopWidth+n.borderBottomWidth),e=Math.max(e,0),this.element.style[t?"width":"height"]=e+"px"}},
/**
     * emit eventComplete on a collection of items events
     * @param {String} eventName
     * @param {Array} items - Outlayer.Items
     */
u._emitCompleteOnItems=function(t,e){var n=this;function i(){n.dispatchEvent(t+"Complete",null,[e])}var r=e.length;if(e&&r){var o=0;// bind callback
e.forEach(function(e){e.once(t,a)})}else i();function a(){++o==r&&i()}},
/**
     * emits events via EvEmitter and jQuery events
     * @param {String} type - name of event
     * @param {Event} event - original event
     * @param {Array} args - extra arguments
     */
u.dispatchEvent=function(e,t,n){
// add original event to arguments
var i=t?[t].concat(n):n;if(this.emitEvent(e,i),s)if(
// set this.$element
this.$element=this.$element||s(this.element),t){
// create jQuery event
var r=s.Event(t);r.type=e,this.$element.trigger(r,n)}else
// just trigger with type if no event available
this.$element.trigger(e,n)},// -------------------------- ignore & stamps -------------------------- //
/**
     * keep item in collection, but do not lay it out
     * ignored items do not get skipped in layout
     * @param {Element} elem
     */
u.ignore=function(e){var t=this.getItem(e);t&&(t.isIgnored=!0)},
/**
     * return item to layout collection
     * @param {Element} elem
     */
u.unignore=function(e){var t=this.getItem(e);t&&delete t.isIgnored},
/**
     * adds elements to stamps
     * @param {NodeList, Array, Element, or String} elems
     */
u.stamp=function(e){(e=this._find(e))&&(this.stamps=this.stamps.concat(e),// ignore
e.forEach(this.ignore,this))},
/**
     * removes elements to stamps
     * @param {NodeList, Array, or Element} elems
     */
u.unstamp=function(e){(e=this._find(e))&&e.forEach(function(e){
// filter out removed stamp elements
o.removeFrom(this.stamps,e),this.unignore(e)},this)},
/**
     * finds child elements
     * @param {NodeList, Array, Element, or String} elems
     * @returns {Array} elems
     */
u._find=function(e){if(e)// if string, use argument as selector string
return"string"==typeof e&&(e=this.element.querySelectorAll(e)),e=o.makeArray(e)},u._manageStamps=function(){this.stamps&&this.stamps.length&&(this._getBoundingRect(),this.stamps.forEach(this._manageStamp,this))},// update boundingLeft / Top
u._getBoundingRect=function(){
// get bounding rect for container element
var e=this.element.getBoundingClientRect(),t=this.size;this._boundingRect={left:e.left+t.paddingLeft+t.borderLeftWidth,top:e.top+t.paddingTop+t.borderTopWidth,right:e.right-(t.paddingRight+t.borderRightWidth),bottom:e.bottom-(t.paddingBottom+t.borderBottomWidth)}},
/**
     * @param {Element} stamp
     **/
u._manageStamp=n,
/**
     * get x/y position of element relative to container element
     * @param {Element} elem
     * @returns {Object} offset - has left, top, right, bottom
     */
u._getElementOffset=function(e){var t=e.getBoundingClientRect(),n=this._boundingRect,i=r(e);return{left:t.left-n.left-i.marginLeft,top:t.top-n.top-i.marginTop,right:n.right-t.right-i.marginRight,bottom:n.bottom-t.bottom-i.marginBottom}},// -------------------------- resize -------------------------- //
// enable event handlers for listeners
// i.e. resize -> onresize
u.handleEvent=o.handleEvent,
/**
     * Bind layout to window resizing
     */
u.bindResize=function(){e.addEventListener("resize",this),this.isResizeBound=!0},
/**
     * Unbind layout to window resizing
     */
u.unbindResize=function(){e.removeEventListener("resize",this),this.isResizeBound=!1},u.onresize=function(){this.resize()},o.debounceMethod(d,"onresize",100),u.resize=function(){
// don't trigger if size did not change
// or if resize was unbound. See #9
this.isResizeBound&&this.needsResizeLayout()&&this.layout()},
/**
     * check if layout is needed post layout
     * @returns Boolean
     */
u.needsResizeLayout=function(){var e=r(this.element);// check that this.size and size are there
// IE8 triggers resize on body size change, so they might not be
return this.size&&e&&e.innerWidth!==this.size.innerWidth},// -------------------------- methods -------------------------- //
/**
     * add items to Outlayer instance
     * @param {Array or NodeList or Element} elems
     * @returns {Array} items - Outlayer.Items
     **/
u.addItems=function(e){var t=this._itemize(e);// add items to collection
return t.length&&(this.items=this.items.concat(t)),t},
/**
     * Layout newly-appended item elements
     * @param {Array or NodeList or Element} elems
     */
u.appended=function(e){var t=this.addItems(e);t.length&&(// layout and reveal just the new items
this.layoutItems(t,!0),this.reveal(t))},
/**
     * Layout prepended elements
     * @param {Array or NodeList or Element} elems
     */
u.prepended=function(e){var t=this._itemize(e);if(t.length){// add items to beginning of collection
var n=this.items.slice(0);this.items=t.concat(n),// start new layout
this._resetLayout(),this._manageStamps(),// layout new stuff without transition
this.layoutItems(t,!0),this.reveal(t),// layout previous items
this.layoutItems(n)}},
/**
     * reveal a collection of items
     * @param {Array of Outlayer.Items} items
     */
u.reveal=function(e){if(this._emitCompleteOnItems("reveal",e),e&&e.length){var n=this.updateStagger();e.forEach(function(e,t){e.stagger(t*n),e.reveal()})}},
/**
     * hide a collection of items
     * @param {Array of Outlayer.Items} items
     */
u.hide=function(e){if(this._emitCompleteOnItems("hide",e),e&&e.length){var n=this.updateStagger();e.forEach(function(e,t){e.stagger(t*n),e.hide()})}},
/**
     * reveal item elements
     * @param {Array}, {Element}, {NodeList} items
     */
u.revealItemElements=function(e){var t=this.getItems(e);this.reveal(t)},
/**
     * hide item elements
     * @param {Array}, {Element}, {NodeList} items
     */
u.hideItemElements=function(e){var t=this.getItems(e);this.hide(t)},
/**
     * get Outlayer.Item, given an Element
     * @param {Element} elem
     * @param {Function} callback
     * @returns {Outlayer.Item} item
     */
u.getItem=function(e){
// loop through items to get the one that matches
for(var t=0;t<this.items.length;t++){var n=this.items[t];if(n.element==e)
// return item
return n}},
/**
     * get collection of Outlayer.Items, given Elements
     * @param {Array} elems
     * @returns {Array} items - Outlayer.Items
     */
u.getItems=function(e){e=o.makeArray(e);var n=[];return e.forEach(function(e){var t=this.getItem(e);t&&n.push(t)},this),n},
/**
     * remove element(s) } from instance and DOM
     * @param {Array or NodeList or Element} elems
     */
u.remove=function(e){var t=this.getItems(e);this._emitCompleteOnItems("remove",t),// bail if no items to remove
t&&t.length&&t.forEach(function(e){e.remove(),// remove item } from collection
o.removeFrom(this.items,e)},this)},// ----- destroy ----- //
// remove and disable Outlayer instance
u.destroy=function(){
// clean up dynamic styles
var e=this.element.style;e.height="",e.position="",e.width="",// destroy items
this.items.forEach(function(e){e.destroy()}),this.unbindResize();var t=this.element.outlayerGUID;delete c[t],// remove reference to instance by id
delete this.element.outlayerGUID,// remove data for jQuery
s&&s.removeData(this.element,this.constructor.namespace)},// -------------------------- data -------------------------- //
/**
     * get Outlayer instance } from element
     * @param {Element} elem
     * @returns {Outlayer}
     */
d.data=function(e){var t=(e=o.getQueryElement(e))&&e.outlayerGUID;return t&&c[t]},// -------------------------- create Outlayer class -------------------------- //
/**
     * create a layout class
     * @param {String} namespace
     */
d.create=function(e,t){
// sub-class Outlayer
var n=f(d);// apply new options and compatOptions
return n.defaults=o.extend({},d.defaults),o.extend(n.defaults,t),n.compatOptions=o.extend({},d.compatOptions),n.namespace=e,n.data=d.data,// sub-class Item
n.Item=f(i),// -------------------------- declarative -------------------------- //
o.htmlInit(n,e),// -------------------------- jQuery bridge -------------------------- //
// make into jQuery plugin
s&&s.bridget&&s.bridget(e,n),n};var _={ms:1,s:1e3};return d.Item=i,d},
/* jshint strict: false */
"function"==typeof define&&define.amd?
// AMD - RequireJS
define("outlayer/outlayer",["ev-emitter/ev-emitter","get-size/get-size","fizzy-ui-utils/utils","./item"],function(e,t,n,i){return go(To,e,t,n,i)}):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS - Browserify, Webpack
module.exports=go(To,require("ev-emitter"),require("get-size"),require("fizzy-ui-utils"),require("./item")):
// browser global
To.Outlayer=go(To,To.EvEmitter,To.getSize,To.fizzyUIUtils,To.Outlayer.Item),
/**
   * Isotope Item
   **/
Co=window,Lo=function(e){
// sub-class Outlayer Item
function t(){e.Item.apply(this,arguments)}var n=t.prototype=Object.create(e.Item.prototype),i=n._create;n._create=function(){
// assign id, used for original-order sorting
this.id=this.layout.itemGUID++,i.call(this),this.sortData={}},n.updateSortData=function(){if(!this.isIgnored){// default sorters
this.sortData.id=this.id,// for backward compatibility
this.sortData["original-order"]=this.id,this.sortData.random=Math.random();// go thru getSortData obj and apply the sorters
var e=this.layout.options.getSortData,t=this.layout._sorters;for(var n in e){var i=t[n];this.sortData[n]=i(this.element,this)}}};var r=n.destroy;return n.destroy=function(){
// call super
r.apply(this,arguments),// reset display, #741
this.css({display:""})},t},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("isotope/js/item",["outlayer/outlayer"],Lo):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=Lo(require("outlayer")):(
// browser global
Co.Isotope=Co.Isotope||{},Co.Isotope.Item=Lo(Co.Outlayer)),
/**
   * Isotope LayoutMode
   */
Oo=window,Ro=function(t,n){function i(e){// link properties
(this.isotope=e)&&(this.options=e.options[this.namespace],this.element=e.element,this.items=e.filteredItems,this.size=e.size)}var r=i.prototype;
/**
     * some methods should just defer to default Outlayer method
     * and reference the Isotope instance as `this`
     **/return["_resetLayout","_getItemLayoutPosition","_manageStamp","_getContainerSize","_getElementOffset","needsResizeLayout","_getOption"].forEach(function(e){r[e]=function(){return n.prototype[e].apply(this.isotope,arguments)}}),// -----  ----- //
// for horizontal layout modes, check vertical size
r.needsVerticalResizeLayout=function(){
// don't trigger if size did not change
var e=t(this.isotope.element);// check that this.size and size are there
// IE8 triggers resize on body size change, so they might not be
return this.isotope.size&&e&&e.innerHeight!=this.isotope.size.innerHeight},// ----- measurements ----- //
r._getMeasurement=function(){this.isotope._getMeasurement.apply(this,arguments)},r.getColumnWidth=function(){this.getSegmentSize("column","Width")},r.getRowHeight=function(){this.getSegmentSize("row","Height")},
/**
     * get columnWidth or rowHeight
     * segment: 'column' or 'row'
     * size 'Width' or 'Height'
     **/
r.getSegmentSize=function(e,t){var n=e+t,i="outer"+t;// got rowHeight or columnWidth, we can chill
if(// columnWidth / outerWidth // rowHeight / outerHeight
this._getMeasurement(n,i),!this[n]){// fall back to item of first element
var r=this.getFirstItemSize();this[n]=r&&r[i]||// or size of container
this.isotope.size["inner"+t]}},r.getFirstItemSize=function(){var e=this.isotope.filteredItems[0];return e&&e.element&&t(e.element)},// ----- methods that should reference isotope ----- //
r.layout=function(){this.isotope.layout.apply(this.isotope,arguments)},r.getSize=function(){this.isotope.getSize(),this.size=this.isotope.size},// -------------------------- create -------------------------- //
i.modes={},i.create=function(e,t){function n(){i.apply(this,arguments)}return(n.prototype=Object.create(r)).constructor=n,// default options
t&&(n.options=t),// register in Isotope
i.modes[n.prototype.namespace=e]=n},i},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("isotope/js/layout-mode",["get-size/get-size","outlayer/outlayer"],Ro):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=Ro(require("get-size"),require("outlayer")):(
// browser global
Oo.Isotope=Oo.Isotope||{},Oo.Isotope.LayoutMode=Ro(Oo.getSize,Oo.Outlayer)),
/*!
   * Masonry v4.2.0
   * Cascading grid layout library
   * http://masonry.desandro.com
   * MIT License
   * by David DeSandro
   */
vo=window,Io=function(e,c){
// -------------------------- masonryDefinition -------------------------- //
// create an Outlayer layout class
var t=e.create("masonry");// isFitWidth -> fitWidth
t.compatOptions.fitWidth="isFitWidth";var n=t.prototype;return n._resetLayout=function(){this.getSize(),this._getMeasurement("columnWidth","outerWidth"),this._getMeasurement("gutter","outerWidth"),this.measureColumns(),// reset column Y
this.colYs=[];for(var e=0;e<this.cols;e++)this.colYs.push(0);this.maxY=0,this.horizontalColIndex=0},n.measureColumns=function(){// if columnWidth is 0, default to outerWidth of first item
if(this.getContainerWidth(),!this.columnWidth){var e=this.items[0],t=e&&e.element;// columnWidth fall back to item of first element
this.columnWidth=t&&c(t).outerWidth||// if first elem has no width, default to size of container
this.containerWidth}var n=this.columnWidth+=this.gutter,i=this.containerWidth+this.gutter,r=i/n,o=n-i%n;// calculate columns
r=Math[o&&o<1?"round":"floor"](r),this.cols=Math.max(r,1)},n.getContainerWidth=function(){
// container is parent if fit width
var e=this._getOption("fitWidth")?this.element.parentNode:this.element,t=c(e);this.containerWidth=t&&t.innerWidth},n._getItemLayoutPosition=function(e){e.getSize();// how many columns does this brick span
var t=e.size.outerWidth%this.columnWidth,n=Math[t&&t<1?"round":"ceil"](e.size.outerWidth/this.columnWidth);n=Math.min(n,this.cols);for(// use horizontal or top column position
var i=this[this.options.horizontalOrder?"_getHorizontalColPosition":"_getTopColPosition"](n,e),r={x:this.columnWidth*i.col,y:i.y},o=i.y+e.size.outerHeight,a=n+i.col,s=i.col;s<a;s++)this.colYs[s]=o;return r},n._getTopColPosition=function(e){var t=this._getTopColGroup(e),n=Math.min.apply(Math,t);// get the minimum Y value } from the columns
return{col:t.indexOf(n),y:n}},
/**
     * @param {Number} colSpan - number of columns the element spans
     * @returns {Array} colGroup
     */
n._getTopColGroup=function(e){if(e<2)
// if brick spans only one column, use all the column Ys
return this.colYs;// for each group potential horizontal position
for(var t=[],n=this.cols+1-e,i=0// how many different places could this brick fit horizontally
;i<n;i++)t[i]=this._getColGroupY(i,e);return t},n._getColGroupY=function(e,t){if(t<2)return this.colYs[e];// make an array of colY values for that one group
var n=this.colYs.slice(e,e+t);// and get the max value of the array
return Math.max.apply(Math,n)},// get column position based on horizontal index. #873
n._getHorizontalColPosition=function(e,t){var n=this.horizontalColIndex%this.cols;// shift to next row if item can't fit on current row
n=1<e&&n+e>this.cols?0:n;// don't let zero-size items take up space
var i=t.size.outerWidth&&t.size.outerHeight;return this.horizontalColIndex=i?n+e:this.horizontalColIndex,{col:n,y:this._getColGroupY(n,e)}},n._manageStamp=function(e){var t=c(e),n=this._getElementOffset(e),i=this._getOption("originLeft")?n.left:n.right,r=i+t.outerWidth,o=Math.floor(i/this.columnWidth);o=Math.max(0,o);var a=Math.floor(r/this.columnWidth);// lastCol should not go over if multiple of columnWidth #425
a-=r%this.columnWidth?0:1,a=Math.min(this.cols-1,a);for(// set colYs to bottom of the stamp
var s=(this._getOption("originTop")?n.top:n.bottom)+t.outerHeight,l=o;l<=a;l++)this.colYs[l]=Math.max(s,this.colYs[l])},n._getContainerSize=function(){this.maxY=Math.max.apply(Math,this.colYs);var e={height:this.maxY};return this._getOption("fitWidth")&&(e.width=this._getContainerFitWidth()),e},n._getContainerFitWidth=function(){for(var e=0,t=this.cols// count unused columns
;--t&&0===this.colYs[t];)e++;// fit container to columns that have been used
return(this.cols-e)*this.columnWidth-this.gutter},n.needsResizeLayout=function(){var e=this.containerWidth;return this.getContainerWidth(),e!=this.containerWidth},t},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("masonry/masonry",["outlayer/outlayer","get-size/get-size"],Io):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=Io(require("outlayer"),require("get-size")):
// browser global
vo.Masonry=Io(vo.Outlayer,vo.getSize),
/*!
   * Masonry layout mode
   * sub-classes Masonry
   * http://masonry.desandro.com
   */
yo=window,bo=function(e,t){
// create an Outlayer layout class
var n=e.create("masonry"),i=n.prototype,r={_getElementOffset:!0,layout:!0,_getMeasurement:!0};// inherit Masonry prototype
for(var o in t.prototype)
// do not inherit mode methods
r[o]||(i[o]=t.prototype[o]);var a=i.measureColumns;i.measureColumns=function(){
// set items, used if measuring first item
this.items=this.isotope.filteredItems,a.call(this)};// point to mode options for fitWidth
var s=i._getOption;return i._getOption=function(e){return"fitWidth"==e?void 0!==this.options.isFitWidth?this.options.isFitWidth:this.options.fitWidth:s.apply(this.isotope,arguments)},n},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("isotope/js/layout-modes/masonry",["../layout-mode","masonry/masonry"],bo):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=bo(require("../layout-mode"),require("masonry-layout")):
// browser global
bo(yo.Isotope.LayoutMode,yo.Masonry),
/**
   * fitRows layout mode
   */
No=window,Do=function(e){var t=e.create("fitRows"),n=t.prototype;return n._resetLayout=function(){if(this.x=0,this.y=0,this.maxY=0,this.row=0,this.rows=[],this._getMeasurement("gutter","outerWidth"),this.options.equalheight)for(var e=0;e<this.isotope.items.length;e++)this.isotope.items[e].css({height:"auto"})},n._getItemLayoutPosition=function(e){e.getSize();// var itemWidth = item.size.outerWidth + this.gutter;
var t=e.size.outerWidth,n=Math.ceil(this.isotope.size.innerWidth+1);// if this element cannot fit in the current row
// var containerWidth = this.isotope.size.innerWidth + this.gutter;
0!==this.x&&t+this.x>n&&(this.x=0,this.y=this.maxY),// New row?
0==this.x&&0!=this.y&&this.row++;var i={x:this.x,y:this.y};return this.maxY=Math.max(this.maxY,this.y+e.size.outerHeight),this.x+=t,// Compare Y } from this row and previous row
void 0===this.rows[this.row]?(this.rows[this.row]=[],this.rows[this.row].start=this.y,this.rows[this.row].end=this.maxY):this.rows[this.row].end=Math.max(this.rows[this.row].end,this.maxY),// Record row number to item
e.row=this.row,i},t.prototype._equalHeight=function(){
// Should we use this.isotope.filteredItems or this.isotope.items?
for(var e=0;e<this.isotope.items.length;e++){var t=this.isotope.items[e].row,n=this.rows[t];if(n){var i=n.end-n.start;i-=this.isotope.items[e].size.borderTopWidth+this.isotope.items[e].size.borderBottomWidth,i-=this.isotope.items[e].size.marginTop+this.isotope.items[e].size.marginBottom,i-=this.gutter.height||0,0==this.isotope.items[e].size.isBorderBox&&(i-=this.isotope.items[e].size.paddingTop+this.isotope.items[e].size.paddingBottom),this.isotope.items[e].size.height=i,this.isotope.items[e].css({height:i.toString()+"px"})}}},n._getContainerSize=function(){return this.options.equalheight&&this._equalHeight(),{height:this.maxY}},t},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("isotope/js/layout-modes/fit-rows",["../layout-mode"],Do):"object"==("undefined"==typeof exports?"undefined":B(exports))?
// CommonJS
module.exports=Do(require("../layout-mode")):
// browser global
Do(No.Isotope.LayoutMode),
/**
   * vertical layout mode
   */
Mo=window,Po=function(e){var t=e.create("vertical",{horizontalAlignment:0}),n=t.prototype;return n._resetLayout=function(){this.y=0},n._getItemLayoutPosition=function(e){e.getSize();var t=(this.isotope.size.innerWidth-e.size.outerWidth)*this.options.horizontalAlignment,n=this.y;return this.y+=e.size.outerHeight,{x:t,y:n}},n._getContainerSize=function(){return{height:this.y}},t},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define("isotope/js/layout-modes/vertical",["../layout-mode"],Po):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=Po(require("../layout-mode")):
// browser global
Po(Mo.Isotope.LayoutMode),
/*!
   * Isotope v3.0.4
   *
   * Licensed GPLv3 for open source use
   * or Isotope Commercial License for commercial use
   *
   * http://isotope.metafizzy.co
   * Copyright 2017 Metafizzy
   */
wo=window,Go=function(e,n,t,i,o,r,a){
// -------------------------- vars -------------------------- //
var s=e.jQuery,l=String.prototype.trim?function(e){return e.trim()}:function(e){return e.replace(/^\s+|\s+$/g,"")},c=n.create("isotope",{layoutMode:"masonry",isJQueryFiltering:!0,sortAscending:!0});// -------------------------- helpers -------------------------- //
c.Item=r,c.LayoutMode=a;var d=c.prototype;d._create=function(){// create } from registered layout modes
for(var e in this.itemGUID=0,// functions that sort items
this._sorters={},this._getSorters(),// call super
n.prototype._create.call(this),// create layout modes
this.modes={},// start filteredItems with all items
this.filteredItems=this.items,// keep of track of sortBys
this.sortHistory=["original-order"],a.modes)this._initLayoutMode(e)},d.reloadItems=function(){
// reset item ID counter
this.itemGUID=0,// call super
n.prototype.reloadItems.call(this)},d._itemize=function(){// assign ID for original-order
for(var e=n.prototype._itemize.apply(this,arguments),t=0;t<e.length;t++){e[t].id=this.itemGUID++}return this._updateItemsSortData(e),e},// -------------------------- layout -------------------------- //
d._initLayoutMode=function(e){var t=a.modes[e],n=this.options[e]||{};// set mode options
// HACK extend initial options, back-fill in default options
this.options[e]=t.options?o.extend(t.options,n):n,// init layout mode instance
this.modes[e]=new t(this)},d.layout=function(){
// if first time doing layout, do all magic
this._isLayoutInited||!this._getOption("initLayout")?this._layout():this.arrange()},// private method to be used in layout() & magic()
d._layout=function(){
// don't animate first layout
var e=this._getIsInstant();// layout flow
this._resetLayout(),this._manageStamps(),this.layoutItems(this.filteredItems,e),// flag for initalized
this._isLayoutInited=!0},// filter + sort + layout
d.arrange=function(e){
// set any options pass
this.option(e),this._getIsInstant();// filter, sort, and layout
// filter
var t=this._filter(this.items);this.filteredItems=t.matches,this._bindArrangeComplete(),this._isInstant?this._noTransition(this._hideReveal,[t]):this._hideReveal(t),this._sort(),this._layout()},// alias to _init for main plugin method
d._init=d.arrange,d._hideReveal=function(e){this.reveal(e.needReveal),this.hide(e.needHide)},// HACK
// Don't animate/transition first layout
// Or don't animate/transition other layouts
d._getIsInstant=function(){var e=this._getOption("layoutInstant"),t=void 0!==e?e:!this._isLayoutInited;return this._isInstant=t},// listen for layoutComplete, hideComplete and revealComplete
// to trigger arrangeComplete
d._bindArrangeComplete=function(){
// listen for 3 events to trigger arrangeComplete
var e,t,n,i=this;function r(){e&&t&&n&&i.dispatchEvent("arrangeComplete",null,[i.filteredItems])}this.once("layoutComplete",function(){e=!0,r()}),this.once("hideComplete",function(){t=!0,r()}),this.once("revealComplete",function(){n=!0,r()})},// -------------------------- filter -------------------------- //
d._filter=function(e){var t=this.options.filter;t=t||"*";// test each item
for(var n=[],i=[],r=[],o=this._getFilterTest(t),a=0;a<e.length;a++){var s=e[a];if(!s.isIgnored){// add item to either matched or unmatched group
var l=o(s);// item.isFilterMatched = isMatched;
// add to matches if its a match
l&&n.push(s),// add to additional group if item needs to be hidden or revealed
l&&s.isHidden?i.push(s):l||s.isHidden||r.push(s)}}// return collections of items to be manipulated
return{matches:n,needReveal:i,needHide:r}},// get a jQuery, function, or a matchesSelector test given the filter
d._getFilterTest=function(t){return s&&this.options.isJQueryFiltering?function(e){return s(e.element).is(t)}:"function"==typeof t?function(e){return t(e.element)}:function(e){return i(e.element,t)}},// -------------------------- sorting -------------------------- //
/**
     * @params {Array} elems
     * @public
     */
d.updateSortData=function(e){
// get items
var t;t=e?(e=o.makeArray(e),this.getItems(e)):this.items,this._getSorters(),this._updateItemsSortData(t)},d._getSorters=function(){var e=this.options.getSortData;for(var t in e){var n=e[t];this._sorters[t]=u(n)}},
/**
     * @params {Array} items - of Isotope.Items
     * @private
     */
d._updateItemsSortData=function(e){for(
// do not update if no items
var t=e&&e.length,n=0;t&&n<t;n++){e[n].updateSortData()}};// ----- munge sorter ----- //
// encapsulate this, as we just need mungeSorter
// other functions in here are just for munging
var u=
// add a magic layer to sorters for convienent shorthands
// `.foo-bar` will use the text of .foo-bar querySelector
// `[foo-bar]` will use attribute
// you can also add parser
// `.foo-bar parseInt` will parse that as a number
function(e){
// if not a string, return function or whatever it is
if("string"!=typeof e)return e;// parse the sorter string
var t,n,i=l(e).split(" "),r=i[0],o=r.match(/^\[(.+)\]$/),a=(t=o&&o[1],n=r,
// if query looks like [foo-bar], get attribute
t?function(e){return e.getAttribute(t)}:function(e){var t=e.querySelector(n);return t&&t.textContent}),s=c.sortDataParsers[i[1]];// parse the value, if there was a parser
return e=s?function(e){return e&&s(a(e))}:// otherwise just return value
function(e){return e&&a(e)}}// get an attribute getter, or get text of the querySelector;
// parsers used in getSortData shortcut strings
c.sortDataParsers={parseInt:function(t){function e(e){return t.apply(this,arguments)}return e.toString=function(){return t.toString()},e}(function(e){return parseInt(e,10)}),parseFloat:function(t){function e(e){return t.apply(this,arguments)}return e.toString=function(){return t.toString()},e}(function(e){return parseFloat(e)})},// ----- sort method ----- //
// sort filteredItem order
d._sort=function(){if(this.options.sortBy){// keep track of sortBy History
var e=o.makeArray(this.options.sortBy);this._getIsSameSortBy(e)||(
// concat all sortBy and sortHistory, add to front, oldest goes in last
this.sortHistory=e.concat(this.sortHistory));// sort magic
var l,c,t=(l=this.sortHistory,c=this.options.sortAscending,function(e,t){
// cycle through all sortKeys
for(var n=0;n<l.length;n++){var i=l[n],r=e.sortData[i],o=t.sortData[i];if(o<r||r<o){
// if sortAsc is an object, use the value given the sortBy key
var a=void 0!==c[i]?c[i]:c,s=a?1:-1;return(o<r?1:-1)*s}}return 0});this.filteredItems.sort(t)}},// check if sortBys is same as start of sortHistory
d._getIsSameSortBy=function(e){for(var t=0;t<e.length;t++)if(e[t]!=this.sortHistory[t])return!1;return!0},// -------------------------- methods -------------------------- //
// get layout mode
d._mode=function(){var e=this.options.layoutMode,t=this.modes[e];if(!t)
// TODO console.error
throw new Error("No layout mode: "+e);// HACK sync mode's options
// any options set after init for layout mode need to be synced
return t.options=this.options[e],t},d._resetLayout=function(){
// trigger original reset layout
n.prototype._resetLayout.call(this),this._mode()._resetLayout()},d._getItemLayoutPosition=function(e){return this._mode()._getItemLayoutPosition(e)},d._manageStamp=function(e){this._mode()._manageStamp(e)},d._getContainerSize=function(){return this._mode()._getContainerSize()},d.needsResizeLayout=function(){return this._mode().needsResizeLayout()},// -------------------------- adding & removing -------------------------- //
// HEADS UP overwrites default Outlayer appended
d.appended=function(e){var t=this.addItems(e);if(t.length){// filter, layout, reveal new items
var n=this._filterRevealAdded(t);// add to filteredItems
this.filteredItems=this.filteredItems.concat(n)}},// HEADS UP overwrites default Outlayer prepended
d.prepended=function(e){var t=this._itemize(e);if(t.length){// start new layout
this._resetLayout(),this._manageStamps();// filter, layout, reveal new items
var n=this._filterRevealAdded(t);// layout previous items
this.layoutItems(this.filteredItems),// add to items and filteredItems
this.filteredItems=n.concat(this.filteredItems),this.items=t.concat(this.items)}},d._filterRevealAdded=function(e){var t=this._filter(e);return this.hide(t.needHide),// reveal all new items
this.reveal(t.matches),// layout new items, no transition
this.layoutItems(t.matches,!0),t.matches},
/**
     * Filter, sort, and layout newly-appended item elements
     * @param {Array or NodeList or Element} elems
     */
d.insert=function(e){var t=this.addItems(e);if(t.length){// append item elements
var n,i,r=t.length;for(n=0;n<r;n++)i=t[n],this.element.appendChild(i.element);// filter new stuff
var o=this._filter(t).matches;// set flag
for(n=0;n<r;n++)t[n].isLayoutInstant=!0;// reset flag
for(this.arrange(),n=0;n<r;n++)delete t[n].isLayoutInstant;this.reveal(o)}};var f=d.remove;// -----  ----- //
return d.remove=function(e){e=o.makeArray(e);var t=this.getItems(e);// do regular thing
f.call(this,e);// remove elems } from filteredItems
for(// bail if no items to remove
var n=t&&t.length,i=0;n&&i<n;i++){var r=t[i];// remove item } from collection
o.removeFrom(this.filteredItems,r)}},d.shuffle=function(){
// update random sortData
for(var e=0;e<this.items.length;e++){this.items[e].sortData.random=Math.random()}this.options.sortBy="random",this._sort(),this._layout()},
/**
     * trigger fn without transition
     * kind of hacky to have this in the first place
     * @param {Function} fn
     * @param {Array} args
     * @returns ret
     * @private
     */
d._noTransition=function(e,t){
// save transitionDuration before disabling
var n=this.options.transitionDuration;// disable transition
this.options.transitionDuration=0;// do it
var i=e.apply(this,t);// re-enable transition for reveal
return this.options.transitionDuration=n,i},// ----- helper methods ----- //
/**
     * getter method for getting filtered item elements
     * @returns {Array} elems - collection of item elements
     */
d.getFilteredItemElements=function(){return this.filteredItems.map(function(e){return e.element})},c},
// universal module definition
/* jshint strict: false */
/*globals define, module, require */
"function"==typeof define&&define.amd?
// AMD
define(["outlayer/outlayer","get-size/get-size","desandro-matches-selector/matches-selector","fizzy-ui-utils/utils","isotope/js/item","isotope/js/layout-mode",// include default layout modes
"isotope/js/layout-modes/masonry","isotope/js/layout-modes/fit-rows","isotope/js/layout-modes/vertical"],function(e,t,n,i,r,o){return Go(wo,e,0,n,i,r,o)}):"object"==("undefined"==typeof module?"undefined":B(module))&&module.exports?
// CommonJS
module.exports=Go(wo,require("outlayer"),require("get-size"),require("desandro-matches-selector"),require("fizzy-ui-utils"),require("isotope/js/item"),require("isotope/js/layout-mode"),// include default layout modes
require("isotope/js/layout-modes/masonry"),require("isotope/js/layout-modes/fit-rows"),require("isotope/js/layout-modes/vertical")):
// browser global
wo.Isotope=Go(wo,wo.Outlayer,wo.getSize,wo.matchesSelector,wo.fizzyUIUtils,wo.Isotope.Item,wo.Isotope.LayoutMode);var Wo=function(){
// provides a case insensitive version of the jquery contains function
S.extend(S.expr[":"],{containsCaseInsensitive:function(e,t,n,i){return 0<=(e.textContent||e.innerText||"").toLowerCase().indexOf((n[3]||"").toLowerCase())}});var u={
// appropriately shifts the mobile utility link so it displays until the results are fully in the view area
FILTER_AREA_Y_SHIFT:125,
// the id of the currently active filter wrapper
activeFilterId:"",
// each entry in this object is a isotope filter result; key is the filter id; value is the Isotope filter result object
filterResults:{},
// whether a listener for the mobile utility link is attached; key is the filter id; value is boolean
filterListenerAttached:{},
// the delay when triggers are selected via url parameter
filterTriggersViaUrlParameterDelay:0,
// records whether an isotope arrangeComplete event handler has been attached
filterArrangeListenerAttached:{},
// records the last clicked trigger for a given filter
filterLastTriggerValue:{},
// records the number of triggers checked
filterNumberOfTriggersChecked:{},FILTER_INITIAL_DELAY:500,MOBILE_UTILITY_SCROLL_DELAY:500,FILTER_CLASS:".js-filter-wrapper",FILTER_INTRO_CLASS:".filter__intro",FILTER_HEADING_CLASS:".text-block__title",TRIGGER_LABEL_CLASS:".js-filter-trigger",TRIGGER_INPUT_CLASS:".js-filter-trigger__input",TRIGGER_ICON_WRAPPER_CLASS:".js-filter-trigger__icon-wrapper",TRIGGER_ICON_CLASS:".js-filter-trigger__icon",TRIGGER_FOCUS_CLASS_NO_DOT:"has-focus",TRIGGER_CONTENT_CLASS:".filter-trigger__content",CARD_TITLE_CLASS:".card__title",CARD_PARAGRAPH_CLASS:".card__paragraph",RESULT_CONTAINER_CLASS:".js-filter__results",RESULT_CLASS:".js-filter-item",RESULTS_NONE_CLASS:".js-filter__results--none",RESULTS_LEAD_CLASS:".js-filter__results-lead",RESULTS_NUMBER_CLASS:".result-number",MOBILE_UTILITY_CLASS:".js-filter__mobile-utility",MOBILE_CLASS_NO_DOT:"sm-screen",URL_FILTER_PARAMETER:"filter",URL_FILTER_TRIGGER_PARAMETER:"filterTrigger",URL_FILTER_TEXT_PARAMETER:"filterText",COLUMN_COLLAPSE_CLASS:".js-lx-collapsible",COLUMN_COLLAPSE_TRIGGER:".js-lx-collapsible__trigger",COLUMN_COLLAPSE_TARGET:".js-lx-collapsible__target",COLUMN_COLLAPSE_EXPANDED_CLASS_NO_DOT:"is-expanded",COLUMN_COLLAPSE_INITIALLY_EXPANDED_CLASS_NO_DOT:"is-initially-expanded",TAB_PANEL_CLASS:".js-lx-tabs__panel",TAB_PANEL_TRIGGER_ATTR:"data-tabtrigger",LISTENING_FOR_CLICK_CLASS_NO_DOT:"is-listening-for-click",ACTIVE_CLASS:"is-active",bindEvents:function(){
// this change handles the issue where a checkbox acts like it is checked only after it has been checked and unchecked when the user returns to the page via the back button
S(u.TRIGGER_INPUT_CLASS).prop("checked",!1),S(u.FILTER_CLASS+" .js-input").val(""),// listen for check/uncheck on triggers
S(u.TRIGGER_INPUT_CLASS).on("change",function(e){u.updateResults(S(e.target),e)}),// scroll to results lead at mobile when the user clicks on the utility link
S(u.MOBILE_UTILITY_CLASS).click(function(e){
// the id of the filter wrapper that contains the utility link
var t="#"+u.getFilterId(e.target)+" "+u.RESULTS_LEAD_CLASS;S("html, body").animate({scrollTop:S(t).offset().top},u.MOBILE_UTILITY_SCROLL_DELAY)}),// displays a visual indicator when a trigger has focus
S(u.TRIGGER_LABEL_CLASS).on("focusin",function(e){S(e.target).closest(u.TRIGGER_LABEL_CLASS).addClass(u.TRIGGER_FOCUS_CLASS_NO_DOT)}),S(u.TRIGGER_LABEL_CLASS).on("focusout",function(e){S(e.target).closest(u.TRIGGER_LABEL_CLASS).removeClass(u.TRIGGER_FOCUS_CLASS_NO_DOT)}),// handles submits for text filters
S(u.FILTER_CLASS+" .js-form").on("submit",function(e){u.showTextFilterResults(e)})},setUpIsotope:function(){
// set up isotope on the results container for each filter
S.each(S(u.RESULT_CONTAINER_CLASS),function(e,t){var n=u.getFilterId(t);u.filterResults[n]=new Isotope(t,{itemSelector:u.RESULT_CLASS,layoutMode:"fitRows",fitRows:{equalheight:!0},filter:"none"})})},setUpMobileUtilityListener:function(){
// build the object that monitors the mobile utility listener for each filter
S.each(S(u.FILTER_CLASS),function(e,t){u.filterListenerAttached[t.id]=!1})},updateResults:function(r,e){setTimeout(function(){var e,t=u.getFilterId(r[0]),n=[],i="#"+t+" ";(u.filterLastTriggerValue[t]=r).closest(u.TRIGGER_LABEL_CLASS).toggleClass("is-active"),r.next(u.TRIGGER_ICON_WRAPPER_CLASS).toggleClass("is-active"),r.next(u.TRIGGER_ICON_WRAPPER_CLASS).find(u.TRIGGER_ICON_CLASS).toggleClass("is-active"),// determine which filters are checked
S.each(S(i+" "+u.TRIGGER_INPUT_CLASS),function(e,t){t.checked&&n.push(t.value)}),u.filterNumberOfTriggersChecked[t]=n.length,// create the filtering string
e=0<n.length?n.join(", "):"none",// arrange the isotope object based on the checked filters
u.filterResults[t].arrange({filter:e}),// when the arrange is complete, display the results and update the results count
!0==!u.filterArrangeListenerAttached[t]&&(u.filterResults[t].on("arrangeComplete",function(e){u.updateResultsHelper(t,i)}),0<n.length&&!S(i+" "+u.RESULTS_LEAD_CLASS).is(":visible")&&
// this is called in the edge case that the first checkbox clicked for the filter maps to 0 results
u.updateResultsHelper(t,i),u.filterArrangeListenerAttached[t]=!0),// write the analytics object
u.writeCheckboxTriggerAnalyticsObject(r,i)},u.filterTriggersViaUrlParameterDelay),// reset the delay; it is only needed when filters are checked via url parameters
u.filterTriggersViaUrlParameterDelay=0},
// is called when the arrange is complete for the isotope object
updateResultsHelper:function(e,t){0===u.filterNumberOfTriggersChecked[e]?(S(t+" "+u.RESULTS_NONE_CLASS).fadeIn("fast"),S(t+" "+u.RESULTS_LEAD_CLASS).hide(),S(t+" "+u.RESULTS_NUMBER_CLASS).html("0"),u.removeMobileUtilityLink(e)):(S(t+" "+u.RESULTS_NONE_CLASS).hide(),S(t+" "+u.RESULTS_LEAD_CLASS).fadeIn("fast",function(){S(t+" "+u.RESULTS_NUMBER_CLASS).html(u.filterResults[e].getFilteredItemElements().length)}),u.addMobileUtilityLink(e)),S.each(S(t+" "+u.RESULT_CONTAINER_CLASS).find(u.filterLastTriggerValue[e].attr("value")),function(e,t){u.updateResultToActualImage(t)})},addMobileUtilityLink:function(n){
// adds the mobile utility link that is displayed when a trigger is checked at mobile and the results are not scrolled into view
u.activeFilterId=n,// there should only be a utility link for the filter that the user most recently interacted with
S.each(u.filterListenerAttached,function(e,t){e!==n&&t&&u.removeMobileUtilityLink(e)}),// display the utility link if the user is viewing the filters area
u.isWithinFiltersArea(n)&&S("#"+n+" "+u.MOBILE_UTILITY_CLASS).fadeIn("fast"),// attach listeners if they haven't already been added
u.filterListenerAttached[n]||(S(window).on("scroll",u.monitorMobileUtilityLink),u.filterResults[n].on("layoutComplete",u.monitorMobileUtilityLink),S(document).on("focusin",u.monitorFocus),u.filterListenerAttached[n]=!0)},removeMobileUtilityLink:function(e){
// removes the mobile utility link that is displayed when a trigger is checked at mobile and the results are not scrolled into view
u.activeFilterId="",S("#"+e+" "+u.MOBILE_UTILITY_CLASS).hide(),S(window).off("scroll",u.monitorMobileUtilityLink),u.filterResults[e].off("layoutComplete",u.monitorMobileUtilityLink),S(document).off("focusin",u.monitorFocus),u.filterListenerAttached[e]=!1},isWithinFiltersArea:function(e){
// determines if only the filters are in the view area at mobile, so that it is possible to display a utility link to scroll down to the results
var t=S(window).scrollTop(),n=S(window).height(),i=S("#"+e+" "+u.RESULT_CONTAINER_CLASS).offset().top,r=S("#"+e).offset().top;// if the user is viewing the page at a mobile screen size
if(S("body").hasClass(u.MOBILE_CLASS_NO_DOT)&&t+n<i+u.FILTER_AREA_Y_SHIFT&&r<t+n)return!0},monitorMobileUtilityLink:function(){
// displays/hides the utility navigation link
var e=S("#"+u.activeFilterId+" "+u.MOBILE_UTILITY_CLASS);u.isWithinFiltersArea(u.activeFilterId)?e.fadeIn("fast"):e.hide()},monitorFocus:function(){
// considers a filter to no longer be active if it loses focus
var e=S(":focus");// remove the utility link if the focus is outside of the filter wrapper
// for some reason, the active element when referencing a filter or trigger through a # in the url is an empty <input>, so the first condition below checks for that
0!==document.activeElement.attributes.length&&e.attr("id")!==u.activeFilterId&&0===e.parents("#"+u.activeFilterId).length&&u.removeMobileUtilityLink(u.activeFilterId)},getFilterId:function(e){
// gets the id for the filter; any element of the filter - lead, results container, etc - can be passed in
return S(e).closest(u.FILTER_CLASS).attr("id")},checkUrl:function(){
// check to see if there are parameters in the url and if there are:
// if there is one or more trigger ids, scroll to the parent filter and check the trigger(s)
// if it is filter wrapper id, scroll to the filter
// additionally if the target is within a column collapse or tab, open the column collapse or tab
// filter=[id of the the element with class="js-filter-wrapper"]
// filterTrigger=[one or more ids of the trigger checkboxes separated by commas]
// filterTrigger=[id of the the element with class="js-filter-wrapper"] and filterText=[text that should populate the search input field]
var e=Tr.getUrlParameters();if(e[u.URL_FILTER_TRIGGER_PARAMETER]){
// is a filter trigger
// supports one or more triggers, more than one trigger is represented as a comma separated list
var t=e[u.URL_FILTER_TRIGGER_PARAMETER].split(","),n=S("#"+t[0]).closest(u.FILTER_CLASS);u.filterTriggersViaUrlParameterDelay=u.FILTER_INITIAL_DELAY,0<n.length?(u.focusOnFilter(n),S.each(t,function(e,t){0<S("#"+t).length?S("#"+t).click():console.error("There isn't a filter trigger with id=\""+t+'" on this page')})):console.error("One or more of the filter triggers specified in the url parameter are not valid.")}else if(e[u.URL_FILTER_PARAMETER]&&!e[u.URL_FILTER_TEXT_PARAMETER]){
// is a filter
var i=S("#"+e[u.URL_FILTER_PARAMETER]);0<i.length?u.focusOnFilter(i):console.error("There isn't a filter with id=\""+e[u.URL_FILTER_PARAMETER]+'" on this page')}else if(e[u.URL_FILTER_PARAMETER]&&e[u.URL_FILTER_TEXT_PARAMETER]){
// is a filter text input
var r=S("#"+e[u.URL_FILTER_PARAMETER]),o=r.find(".js-input-group .js-input"),a=r.find('.js-input-group button[type="submit"]'),s=decodeURIComponent(e[u.URL_FILTER_TEXT_PARAMETER]).replace(/(\+)/g," ");0<r.length?(u.focusOnFilter(r),o.val(s),a.submit()):console.error("There isn't a filter with id=\""+e[u.URL_FILTER_PARAMETER]+'" on this page')}},focusOnFilter:function(t){var e=t.closest(u.COLUMN_COLLAPSE_CLASS),n=t.closest(u.TAB_PANEL_CLASS);if(0<e.length){
// if it is inside of a column collapse that is closed, open the collapse
var i=e.find(u.COLUMN_COLLAPSE_TRIGGER),r=e.find(u.COLUMN_COLLAPSE_TARGET);if(i.hasClass(u.COLUMN_COLLAPSE_EXPANDED_CLASS_NO_DOT))Ur("#"+t.attr("id"));else{
// wait until the collapse starts listening for a click and then click it
if(!r.hasClass(u.COLUMN_COLLAPSE_INITIALLY_EXPANDED_CLASS_NO_DOT))if(i.hasClass(u.LISTENING_FOR_CLICK_CLASS_NO_DOT))i.click();else{var o=new MutationObserver(function(e){i.hasClass(u.LISTENING_FOR_CLICK_CLASS_NO_DOT)&&(i.click(),o.disconnect())});// create an observer instance linked to the callback function
// start observing the target node for configured mutations
o.observe(r[0],{attributes:!0})}// once it has been clicked, wait until it is displayed and then scroll to it
var a=new MutationObserver(function(e){i.hasClass(u.COLUMN_COLLAPSE_EXPANDED_CLASS_NO_DOT)&&(Ur("#"+t.attr("id")),a.disconnect())});// create an observer instance linked to the callback function
// start observing the target node for configured mutations
a.observe(r[0],{attributes:!0})}}else if(0<n.length){
// if it is inside of a tab, open the tab
var s=n.attr(u.TAB_PANEL_TRIGGER_ATTR),l=S(s);if(l.hasClass(u.LISTENING_FOR_CLICK_CLASS_NO_DOT))l.click();else{var c=new MutationObserver(function(e){l.hasClass(u.LISTENING_FOR_CLICK_CLASS_NO_DOT)&&(l.click(),c.disconnect())});// create an observer instance linked to the callback function
// start observing the target node for configured mutations
c.observe(l[0],{attributes:!0})}// once it has been clicked, wait until it is displayed and then scroll to it
if(n.hasClass(u.ACTIVE_CLASS))Ur("#"+t.attr("id"));else{var d=new MutationObserver(function(e){n.hasClass(u.ACTIVE_CLASS)&&(Ur("#"+t.attr("id")),d.disconnect())});// create an observer instance linked to the callback function
// start observing the target node for configured mutations
d.observe(n[0],{attributes:!0})}}else
// it isn't inside of a column collapse or a tab
Ur("#"+t.attr("id"))},showTextFilterResults:function(e){e.preventDefault(),setTimeout(function(){var t=S(e.target).closest(u.FILTER_CLASS).attr("id"),n="#"+t+" ",i=S(n).find(".js-input-group .js-input")[0];i.validity.valid&&(u.filterResults[t].arrange({filter:function(){return u.matchSearchText(i.value,this)}}),!0==!u.filterArrangeListenerAttached[t]&&(u.filterResults[t].on("arrangeComplete",function(e){u.showTextFilterResultsHelper(t,n,i)}),// handles the case where the first search returns 0 results
S(n+" "+u.RESULTS_LEAD_CLASS).is(":visible")||u.showTextFilterResultsHelper(t,n,i),u.filterArrangeListenerAttached[t]=!0))},u.filterTriggersViaUrlParameterDelay),u.filterTriggersViaUrlParameterDelay=0},showTextFilterResultsHelper:function(e,t,n){var i=[];S(t+" "+u.RESULTS_NONE_CLASS).hide(),S(t+" "+u.RESULTS_LEAD_CLASS).fadeIn("fast",function(){S(t+" "+u.RESULTS_NUMBER_CLASS).html(u.filterResults[e].getFilteredItemElements().length)}),S.each(S(t+" "+u.RESULT_CONTAINER_CLASS+" "+u.RESULT_CLASS),function(e,t){u.matchSearchText(n.value,t)&&(u.updateResultToActualImage(t),i.push(S(t).find(u.CARD_TITLE_CLASS).text().replace(/(\r\n\t|\n|\r\t)/gm,"").trim()))}),u.writeTextFilterAnalyticsObject(t,n.value,i)},updateResultToActualImage:function(e){var t=S(e).find(".card__image-wrapper img"),n=t.attr("data-src"),i=t.attr("data-srcset");i&&(t.removeAttr("data-srcset"),t.attr("srcset",i)),n&&(t.removeAttr("data-src"),t.attr("src",n))},matchSearchText:function(e,t){var n=!1;return 0<S(t).find(u.CARD_TITLE_CLASS+':containsCaseInsensitive("'+e+'")').length?n=!0:0<S(t).find(u.CARD_PARAGRAPH_CLASS+':containsCaseInsensitive("'+e+'")').length&&(n=!0),n},writeCheckboxTriggerAnalyticsObject:function(e,t){
// create an analytics object that tracks which trigger was checked and which cards were displayed
var n=e.is(":checked")?"on":"off",i=S(e).closest(u.TRIGGER_LABEL_CLASS).find(u.TRIGGER_CONTENT_CLASS).text().replace(/(\r\n\t|\n|\r\t)/gm,"").trim(),r=[];e.is(":checked")&&S.each(S(t+u.RESULT_CONTAINER_CLASS).find(S(e).attr("value")),function(e,t){r.push(S(t).find(u.CARD_TITLE_CLASS).text().replace(/(\r\n\t|\n|\r\t)/gm,"").trim())}),u.writeFilterAnalyticsObject(t,"checkbox",n,i,r)},writeTextFilterAnalyticsObject:function(e,t,n){u.writeFilterAnalyticsObject(e,"text","on",t,n)},writeFilterAnalyticsObject:function(e,t,n,i,r){var o={eventName:"aemContentFilter",filterHeading:S(e+" "+u.FILTER_INTRO_CLASS+" "+u.FILTER_HEADING_CLASS).text().replace(/(\r\n\t|\n|\r\t)/gm,"").trim(),filterType:t,filterToggle:n,filterLabel:i,filterDisplayedCardHeadings:r};try{window.digitalData.eventTrack("aemContentFilter",o)}catch(e){console.warn("Unable to submit the filter analytics object: "+e)}},init:function(){u.bindEvents(),u.setUpIsotope(),u.setUpMobileUtilityListener(),u.checkUrl()}};return{init:u.init,updateResults:u.updateResults}}(),zo=C.f;
// `Object.values` method
// https://tc39.github.io/ecma262/#sec-object.values
Ne({target:"Object",stat:!0},{values:function(e){return function(e,t){for(var n,i=c(e),r=nn(i),o=r.length,a=0,s=[];a<o;)n=r[a++],A&&!zo.call(i,n)||s.push(t?[n,i[n]]:i[n]);return s}(e)}});var Xo,Yo,Ko,qo,$o,Jo,Qo={setContactFormLanguage:(Xo={
// stores the attributes for fields
attributes:{},
// all messages are stored as objects in the messaging object the key for each message is the field class
messaging:{},EMPTY_TEXT:"emptyText",INVALID_TEXT:"invalidText",EXAMPLE:"example",EXAMPLE_CLASS:".js-form-group__example",EXAMPLE_CLASS_NO_JS:".form-group__example",LABEL_CLASS:".js-label",LABEL_FIELDSET_CLASS_NO_DOT:"js-label--fieldset",FIELDSET_LEGEND_CLASS:".js-fieldset__legend",INPUT_GROUP_CLASS:"js-input-group",FORM_CLASS:".js-form",FORM_GROUP_CLASS:".js-form-group",FORM_GROUP_EXAMPLE_CLASS:".js-form-group__example",FORM_WRAPPER_CLASS:".js-form-wrapper",ERROR_MESSAGE_CLASS:".form__error-message",INVALID_CLASS_NO_DOT:"is-invalid",VALIDATION_CLASS_PREFIX:"js-form-validation-",SEARCH_CLASS:"js-form-validation-search",USERNAME_CLASS:"js-form-validation-username",PASSWORD_CLASS:"js-form-validation-password",PASSWORD_TOGGLE_CLASS:"js-password-toggle",PASSWORD_TOGGLE_BUTTON_CLASS:".password-toggle-is-on",JS_PASSWORD_TOGGLE_BUTTON_CLASS:".js-password-toggle-is-on",SECURITY_MESSAGE:".security-message",TITLE_CLASS:"js-form-validation-title",NAME_CLASS:"js-form-validation-name",COMPANY_NAME_CLASS:"js-form-validation-company-name",POSITION_CLASS:"js-form-validation-position",ADDRESS_CLASS:"js-form-validation-address",CITY_CLASS:"js-form-validation-city",STATE_CLASS:"js-form-validation-state",COUNTRY_CLASS:"js-form-validation-country",ZIP_CLASS:"js-form-validation-zip",COUNTY_CLASS:"js-form-validation-county",EMAIL_CLASS:"js-form-validation-email",PHONE_CLASS:"js-form-validation-phone",PHONE_EXT_CLASS:"js-form-validation-phone-ext",PREFERRED_CONTACT_CLASS:"js-form-validation-preferred-contact",PREFERRED_CONTACT_CLASS_GROUP:"js-form-validation-preferred-contact-group",BEST_TIME_TO_CALL_CLASS:"js-form-validation-best-time-to-call",BEST_TIME_TO_CALL_CLASS_GROUP:"js-form-validation-best-time-to-call-group",CURRENCY_CLASS:"js-form-validation-currency",POSITIVE_WHOLE_NUMBER_CLASS:"js-form-validation-positive-whole-number",FREEFORM_CLASS:"js-form-validation-freeform",CHECKBOX_CLASS:"js-form-validation-checkbox",CHECKBOX_CLASS_GROUP:"js-form-validation-checkbox-group",SELECT_CLASS:"js-form-validation-select",RADIO_CLASS:"js-form-validation-radio",RADIO_CLASS_GROUP:"js-form-validation-radio-group",TEXT_CLASS:"js-form-validation-text-input",TEXTAREA_CLASS:"js-form-validation-textarea",EXAMPLE_PREFIXES:{ENGLISH:"Example",SPANISH:"Ejemplo",FRENCH:"Exemple"},ERROR_PREFIXES:{ENGLISH:"Error!",SPANISH:"¡Error!",FRENCH:"Erreur!"},LANGUAGES:{EN:"en",ES:"es",FR:"fr"},SHOW_PASSWORD_TIMEOUT:18e4,timers:{},pageLanguage:void 0===S("html").attr("lang")?"en":S("html").attr("lang"),contactFormLanguage:"",bindEvents:function(){S(Xo.FORM_CLASS+" button[type=submit]").each(function(e,t){t.addEventListener("click",function(e){Xo.validateForm(S(e.target).closest(Xo.FORM_CLASS),e)})})},setUpAttributes:function(){Xo.attributes={
// SEARCH
searchTypeAttr:"text",searchAutocompleteAttr:"off",
// USER NAME
usernameTypeAttr:"username",usernameAutocapitalizeAttr:"none",usernameAutocompleteAttr:"off",
// PASSWORD
passwordTypeAttr:"password",passwordAutocapitalizeAttr:"none",passwordAutocompleteAttr:"off",
// NAME
nameTypeAttr:"text",
// COMPANY NAME
companyNameTypeAttr:"text",
// POSITION/TITLE
positionTitleTypeAttr:"text",
// ADDRESS
addressTypeAttr:"text",
// CITY
cityTypeAttr:"text",
// STATE
// There are no attributes for state
// ZIP CODE
zipTypeAttr:"text",zipPatternAttr:"[0-9]{5}",
// COUNTY
// There are no attributes for county
// EMAIL
emailTypeAttr:"email",
// PHONE
phoneTypeAttr:"tel",
/* eslint-disable no-useless-escape */
phonePatternAttr:"(?:\\(\\d{3}\\)|\\d{3})[-. ]?\\d{3}[-. ]?\\d{4}",
/* eslint-ensable no-useless-escape */
// PHONE EXT
phoneExtTypeAttr:"tel",phoneExtMinAttr:0,
// PREFERRED CONTACT
// There are no attributes for preferred contact
// BEST TIME TO CALL
// There are no attributes for best time to call
// FREEFORM #1
// There are no attributes for freeform #1
// FREEFORM #2
// There are no attributes for freeform #2
// CURRENCY
currencyTypeAttr:"text",currencyPatternAttr:"^\\$?(([1-9](\\d*|\\d{0,2}(,\\d{3})*))|0)(\\.\\d{1,2})?$",currencyMinAttr:0,
// POSITIVE NUMBER
positiveNumberTypeAttr:"number",positiveNumberMinAttr:0}},setUpMessaging:function(){Xo.setUpEnglishMessaging(),Xo.setUpSpanishMessaging(),Xo.setUpFrenchMessaging()},setUpEnglishMessaging:function(){var e,t,n,i,r,o,a,s,l,c,d,u,f;Xo.messaging.en={},// SEARCH
Xo.messaging.en[Xo.SEARCH_CLASS]=(_(e={},Xo.EMPTY_TEXT,"Please enter your search terms."),_(e,Xo.INVALID_TEXT,"Please enter your search terms."),e),// USER NAME
Xo.messaging.en[Xo.USERNAME_CLASS]=(_(t={},Xo.EMPTY_TEXT,"Please enter your user ID."),_(t,Xo.INVALID_TEXT,"Please enter your user ID."),t),// PASSWORD
Xo.messaging.en[Xo.PASSWORD_CLASS]=(_(n={},Xo.EMPTY_TEXT,"Please enter your password."),_(n,Xo.INVALID_TEXT,"Please enter your password."),n),// TITLE
Xo.messaging.en[Xo.TITLE_CLASS]=_({},Xo.EMPTY_TEXT,"Please select a title from the list."),// NAME
Xo.messaging.en[Xo.NAME_CLASS]=(_(i={},Xo.EMPTY_TEXT,"Please enter your name."),_(i,Xo.INVALID_TEXT,function(e){return"The name ".concat(e.value," is invalid.")}),i),// COMPANY NAME
Xo.messaging.en[Xo.COMPANY_NAME_CLASS]=(_(r={},Xo.EMPTY_TEXT,"Please enter your company name."),_(r,Xo.INVALID_TEXT,"Please enter your company name."),r),// POSITION
Xo.messaging.en[Xo.POSITION_CLASS]=(_(o={},Xo.EMPTY_TEXT,"Please enter your position."),_(o,Xo.INVALID_TEXT,"Please enter your position."),o),// ADDRESS
Xo.messaging.en[Xo.ADDRESS_CLASS]=(_(a={},Xo.EMPTY_TEXT,"Please enter a street address."),_(a,Xo.INVALID_TEXT,"Please enter a street address."),a),// CITY
Xo.messaging.en[Xo.CITY_CLASS]=(_(s={},Xo.EMPTY_TEXT,"Please enter a city."),_(s,Xo.INVALID_TEXT,"Please enter a city."),s),// STATE
Xo.messaging.en[Xo.STATE_CLASS]=_({},Xo.EMPTY_TEXT,"Please select a state from the list."),// COUNTRY
Xo.messaging.en[Xo.COUNTRY_CLASS]=_({},Xo.EMPTY_TEXT,"Please select a country from the list."),// ZIP CODE
Xo.messaging.en[Xo.ZIP_CLASS]=(_(l={},Xo.EMPTY_TEXT,"Please enter a ZIP code."),_(l,Xo.INVALID_TEXT,function(e){return"The ZIP code ".concat(e.value," is invalid. A 5-digit ZIP code is required.")}),_(l,Xo.EXAMPLE,"12345"),l),// COUNTY
Xo.messaging.en[Xo.COUNTY_CLASS]=_({},Xo.EMPTY_TEXT,"Please select a county } from the list."),// EMAIL
Xo.messaging.en[Xo.EMAIL_CLASS]=(_(c={},Xo.EMPTY_TEXT,"Please enter your email address."),_(c,Xo.INVALID_TEXT,function(e){return"The email address ".concat(e.value," is invalid. An email using the following format is required: abc@xyz.com")}),c),// TELEPHONE
Xo.messaging.en[Xo.PHONE_CLASS]=(_(d={},Xo.EMPTY_TEXT,"Please enter your phone number."),_(d,Xo.INVALID_TEXT,function(e){return"The phone number ".concat(e.value," is invalid. A 10-digit United States phone number is required.")}),_(d,Xo.EXAMPLE,"123-456-7890 or 1234567890"),d),// TELEPHONE EXT
Xo.messaging.en[Xo.PHONE_EXT_CLASS]=(_(u={},Xo.EMPTY_TEXT,"Please enter your phone extension."),_(u,Xo.INVALID_TEXT,"Please enter your phone extension."),u),// PREFERRED CONTACT
Xo.messaging.en[Xo.PREFERRED_CONTACT_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Please select your preferred contact method."),// BEST TIME TO CALL
Xo.messaging.en[Xo.BEST_TIME_TO_CALL_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Please select the best time for us to call."),// CURRENCY
Xo.messaging.en[Xo.CURRENCY_CLASS]=(_(f={},Xo.EMPTY_TEXT,"Please enter a dollar figure."),_(f,Xo.INVALID_TEXT,"Please enter a dollar figure."),f),// POSITIVE NUMBER
Xo.messaging.en[Xo.POSITIVE_WHOLE_NUMBER_CLASS]=_({},Xo.INVALID_TEXT,"Please enter a whole dollar amount greater than or equal to 0."),// FREEFORM
Xo.messaging.en[Xo.FREEFORM_CLASS]=_({},Xo.EMPTY_TEXT,"Please provide a response."),// GENERIC CHECKBOX
Xo.messaging.en[Xo.CHECKBOX_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Please select at least one checkbox."),// GENERIC SELECT
Xo.messaging.en[Xo.SELECT_CLASS]=_({},Xo.EMPTY_TEXT,"Please select an option."),// GENERIC RADIO
Xo.messaging.en[Xo.RADIO_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Please select one radio button."),// GENERIC TEXT INPUT
Xo.messaging.en[Xo.TEXT_CLASS]=_({},Xo.EMPTY_TEXT,"Please enter a response."),// GENERIC TEXTAREA
Xo.messaging.en[Xo.TEXTAREA_CLASS]=_({},Xo.EMPTY_TEXT,"Please enter a response.")},setUpSpanishMessaging:function(){var e,t,n,i,r,o,a,s,l,c,d,u,f;Xo.messaging.es={},// SEARCH
Xo.messaging.es[Xo.SEARCH_CLASS]=(_(e={},Xo.EMPTY_TEXT,"Por favor ingrese sus términos de búsqueda."),_(e,Xo.INVALID_TEXT,"Por favor ingrese sus términos de búsqueda."),e),// USER NAME
Xo.messaging.es[Xo.USERNAME_CLASS]=(_(t={},Xo.EMPTY_TEXT,"Por favor ingrese su identificación de usuario."),_(t,Xo.INVALID_TEXT,"Por favor ingrese su identificación de usuario."),t),// PASSWORD
Xo.messaging.es[Xo.PASSWORD_CLASS]=(_(n={},Xo.EMPTY_TEXT,"Por favor, ingrese su contraseña."),_(n,Xo.INVALID_TEXT,"Por favor, ingrese su contraseña."),n),// TITLE
Xo.messaging.es[Xo.TITLE_CLASS]=_({},Xo.EMPTY_TEXT,"Por favor, seleccione un título de la lista."),// NAME
Xo.messaging.es[Xo.NAME_CLASS]=(_(i={},Xo.EMPTY_TEXT,"Por favor, escriba su nombre."),_(i,Xo.INVALID_TEXT,function(e){return"El nombre ".concat(e.value," es inválido.")}),i),// COMPANY NAME
Xo.messaging.es[Xo.COMPANY_NAME_CLASS]=(_(r={},Xo.EMPTY_TEXT,"Por favor ingrese el nombre de su compañía."),_(r,Xo.INVALID_TEXT,"Por favor ingrese el nombre de su compañía."),r),// POSITION
Xo.messaging.es[Xo.POSITION_CLASS]=(_(o={},Xo.EMPTY_TEXT,"Por favor ingrese su posición."),_(o,Xo.INVALID_TEXT,"Por favor ingrese su posición."),o),// ADDRESS
Xo.messaging.es[Xo.ADDRESS_CLASS]=(_(a={},Xo.EMPTY_TEXT,"Por favor ingrese una dirección."),_(a,Xo.INVALID_TEXT,"Por favor ingrese una dirección."),a),// CITY
Xo.messaging.es[Xo.CITY_CLASS]=(_(s={},Xo.EMPTY_TEXT,"Por favor ingrese una ciudad."),_(s,Xo.INVALID_TEXT,"Por favor ingrese una ciudad."),s),// STATE
Xo.messaging.es[Xo.STATE_CLASS]=_({},Xo.EMPTY_TEXT,"Por favor, seleccione un estado de la lista."),// COUNTRY
Xo.messaging.es[Xo.COUNTRY_CLASS]=_({},Xo.EMPTY_TEXT,"Por favor, seleccione un país de la lista."),// ZIP CODE
Xo.messaging.es[Xo.ZIP_CLASS]=(_(l={},Xo.EMPTY_TEXT,"Por favor ingrese un codigo postal."),_(l,Xo.INVALID_TEXT,function(e){return"El codigo postal ".concat(e.value," es inválido. Se requiere un código postal de 5 dígitos.")}),_(l,Xo.EXAMPLE,"12345"),l),// COUNTY
Xo.messaging.es[Xo.COUNTY_CLASS]=_({},Xo.EMPTY_TEXT,"Por favor seleccione un condado de la lista."),// EMAIL
Xo.messaging.es[Xo.EMAIL_CLASS]=(_(c={},Xo.EMPTY_TEXT,"Por favor, ingrese su dirección de correo electrónico."),_(c,Xo.INVALID_TEXT,function(e){return"El correo electrónico ".concat(e.value," es inválido. Se requiere un correo electrónico con el siguiente formato: abc@xyz.com.")}),c),// TELEPHONE
Xo.messaging.es[Xo.PHONE_CLASS]=(_(d={},Xo.EMPTY_TEXT,"Por favor, ingrese su número de teléfono."),_(d,Xo.INVALID_TEXT,function(e){return"El número ".concat(e.value," es inválido. Se requiere un número de teléfono estadounidense de diez dígitos.")}),_(d,Xo.EXAMPLE,"123-456-7890 or 1234567890"),d),// TELEPHONE EXT
Xo.messaging.es[Xo.PHONE_EXT_CLASS]=(_(u={},Xo.EMPTY_TEXT,"Por favor ingrese su extensión de teléfono."),_(u,Xo.INVALID_TEXT,"Por favor ingrese su extensión de teléfono."),u),// PREFERRED CONTACT EXAMPLE
Xo.messaging.es[Xo.PREFERRED_CONTACT_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Por favor seleccione su método de contacto preferido."),// BEST TIME TO CALL
Xo.messaging.es[Xo.BEST_TIME_TO_CALL_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Por favor seleccione el mejor momento para llamar."),// CURRENCY
Xo.messaging.es[Xo.CURRENCY_CLASS]=(_(f={},Xo.EMPTY_TEXT,"Por favor ingrese una cifra en dólares."),_(f,Xo.INVALID_TEXT,"Por favor ingrese una cifra en dólares."),f),// TODO: Translate this
// POSITIVE NUMBER
Xo.messaging.es[Xo.POSITIVE_WHOLE_NUMBER_CLASS]=_({},Xo.INVALID_TEXT,"Por favor ingrese un monte de dólar entero mayor que o igual de 0."),// FREEFORM
Xo.messaging.es[Xo.FREEFORM_CLASS]=_({},Xo.EMPTY_TEXT,"Por favor de una respuesta."),// GENERIC CHECKBOX
Xo.messaging.es[Xo.CHECKBOX_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Marque al menos una casilla, por favor."),// GENERIC SELECT
Xo.messaging.es[Xo.SELECT_CLASS]=_({},Xo.EMPTY_TEXT,"Seleccione una opción, por favor."),// GENERIC RADIO
Xo.messaging.es[Xo.RADIO_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Imprima un botón, por favor."),// GENERIC TEXT INPUT
Xo.messaging.es[Xo.TEXT_CLASS]=_({},Xo.EMPTY_TEXT,"Ingrese una repuesta, por favor."),// GENERIC TEXTAREA
Xo.messaging.es[Xo.TEXTAREA_CLASS]=_({},Xo.EMPTY_TEXT,"Ingrese una repuesta, por favor. ")},setUpFrenchMessaging:function(){var e,t,n,i,r,o,a,s,l,c,d,u,f;Xo.messaging.fr={},// SEARCH
Xo.messaging.fr[Xo.SEARCH_CLASS]=(_(e={},Xo.EMPTY_TEXT,"Veuillez saisir vos termes de recherche."),_(e,Xo.INVALID_TEXT,"Veuillez saisir vos termes de recherche."),e),// USER NAME
Xo.messaging.fr[Xo.USERNAME_CLASS]=(_(t={},Xo.EMPTY_TEXT,"Veuillez saisir votre identifiant d'utilisateur."),_(t,Xo.INVALID_TEXT,"Veuillez saisir votre identifiant d'utilisateur."),t),// PASSWORD
Xo.messaging.fr[Xo.PASSWORD_CLASS]=(_(n={},Xo.EMPTY_TEXT,"Veuillez saisir votre mot de passe."),_(n,Xo.INVALID_TEXT,"Veuillez saisir votre mot de passe."),n),// TODO: Translate this
// TITLE
Xo.messaging.fr[Xo.TITLE_CLASS]=_({},Xo.EMPTY_TEXT,"Please select a title from the list."),// NAME
Xo.messaging.fr[Xo.NAME_CLASS]=(_(i={},Xo.EMPTY_TEXT,"Veuillez saisir votre nom."),_(i,Xo.INVALID_TEXT,function(e){return"Le nom ".concat(e.value," n'est pas valide.")}),i),// COMPANY NAME
Xo.messaging.fr[Xo.COMPANY_NAME_CLASS]=(_(r={},Xo.EMPTY_TEXT,"Veuillez saisir le nom de votre entreprise."),_(r,Xo.INVALID_TEXT,"Veuillez saisir le nom de votre entreprise."),r),// POSITION
Xo.messaging.fr[Xo.POSITION_CLASS]=(_(o={},Xo.EMPTY_TEXT,"Veuillez saisir votre poste."),_(o,Xo.INVALID_TEXT,"Veuillez saisir votre poste."),o),// ADDRESS
Xo.messaging.fr[Xo.ADDRESS_CLASS]=(_(a={},Xo.EMPTY_TEXT,"Veuillez saisir une adresse municipale."),_(a,Xo.INVALID_TEXT,"Veuillez saisir une adresse municipale."),a),// CITY
Xo.messaging.fr[Xo.CITY_CLASS]=(_(s={},Xo.EMPTY_TEXT,"Veuillez saisir une ville."),_(s,Xo.INVALID_TEXT,"Veuillez saisir une ville."),s),// STATE
Xo.messaging.fr[Xo.STATE_CLASS]=_({},Xo.EMPTY_TEXT,"Veuillez saisir un État dans la liste."),// TODO: Translate this
// COUNTRY
Xo.messaging.fr[Xo.COUNTRY_CLASS]=_({},Xo.EMPTY_TEXT,"Please select a country from the list."),// ZIP CODE
Xo.messaging.fr[Xo.ZIP_CLASS]=(_(l={},Xo.EMPTY_TEXT,"Veuillez saisir un code postal."),_(l,Xo.INVALID_TEXT,function(e){return"Le code postal ".concat(e.value," n'est pas valide. Un code postal à 5 chiffres est obligatoire.")}),_(l,Xo.EXAMPLE,"12345"),l),// COUNTY
Xo.messaging.fr[Xo.COUNTY_CLASS]=_({},Xo.EMPTY_TEXT,"Veuillez saisir un pays dans la liste."),// EMAIL
Xo.messaging.fr[Xo.EMAIL_CLASS]=(_(c={},Xo.EMPTY_TEXT,"Veuillez saisir votre adresse courriel."),_(c,Xo.INVALID_TEXT,function(e){return"L'adresse courriel ".concat(e.value," n'est pas valide. L'adresse courriel doit avoir le format suivant: abc@xyz.com.")}),c),// TELEPHONE
Xo.messaging.fr[Xo.PHONE_CLASS]=(_(d={},Xo.EMPTY_TEXT,"Veuillez saisir votre numéro de téléphone."),_(d,Xo.INVALID_TEXT,function(e){return"Le numéro de téléphone ".concat(e.value," n'est pas valide. Un numéro de téléphone à 10 chiffres des États-Unis est obligatoire.")}),_(d,Xo.EXAMPLE,"123-456-7890 or 1234567890"),d),// TELEPHONE EXT
Xo.messaging.fr[Xo.PHONE_EXT_CLASS]=(_(u={},Xo.EMPTY_TEXT,"Veuillez saisir votre numéro de poste."),_(u,Xo.INVALID_TEXT,"Veuillez saisir votre numéro de poste."),u),// PREFERRED CONTACT
Xo.messaging.fr[Xo.PREFERRED_CONTACT_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Veuillez saisir votre mode de communication préféré."),// BEST TIME TO CALL
Xo.messaging.fr[Xo.BEST_TIME_TO_CALL_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Veuillez sélectionner le meilleur moment pour un appel téléphonique."),// CURRENCY
Xo.messaging.fr[Xo.CURRENCY_CLASS]=(_(f={},Xo.EMPTY_TEXT,"Veuillez saisir un montant en dollars."),_(f,Xo.INVALID_TEXT,"Veuillez saisir un montant en dollars."),f),// TODO: Translate this
// POSITIVE NUMBER
Xo.messaging.fr[Xo.POSITIVE_WHOLE_NUMBER_CLASS]=_({},Xo.INVALID_TEXT,"Please enter a whole dollar amount greater than or equal to 0."),// FREEFORM
Xo.messaging.fr[Xo.FREEFORM_CLASS]=_({},Xo.EMPTY_TEXT,"Veuillez fournir une réponse."),// GENERIC CHECKBOX
Xo.messaging.fr[Xo.CHECKBOX_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Veuillez cocher au moins une case."),// GENERIC SELECT
Xo.messaging.fr[Xo.SELECT_CLASS]=_({},Xo.EMPTY_TEXT,"Veuillez sélectionner une option."),// GENERIC RADIO
Xo.messaging.fr[Xo.RADIO_CLASS_GROUP]=_({},Xo.EMPTY_TEXT,"Veuillez sélectionner une case d'option."),// GENERIC TEXT INPUT
Xo.messaging.fr[Xo.TEXT_CLASS]=_({},Xo.EMPTY_TEXT,"Veuillez saisir une réponse."),// GENERIC TEXTAREA
Xo.messaging.fr[Xo.TEXTAREA_CLASS]=_({},Xo.EMPTY_TEXT,"Veuillez saisir une réponse.")},setUpFormValidation:function(){
// wrap submit buttons associated with captcha-enabled forms, so that they will update screen reader users when the form has been submitting but the captcha is still processing
S(Xo.FORM_CLASS).each(function(e,t){var n=S(t);0<n.find(".g-recaptcha").length&&n.find('button[type="submit"]').wrap('<span aria-live="polite" aria-atomic="true"></span>')}),// sets up form fields
S("input, textarea, select").each(function(e,t){var n=S(t);// SEARCH
// PASSWORD
if(n.hasClass(Xo.SEARCH_CLASS)&&(n.attr({type:Xo.attributes.searchTypeAttr,autocomplete:Xo.attributes.searchAutocompleteAttr}),Xo.setUpFieldValidation(t)),// USER NAME
n.hasClass(Xo.USERNAME_CLASS)&&(n.attr({type:Xo.attributes.usernameTypeAttr,autocapitalize:Xo.attributes.usernameAutocapitalizeAttr,autocomplete:Xo.attributes.usernameAutocompleteAttr}),Xo.setUpFieldValidation(t)),n.hasClass(Xo.PASSWORD_CLASS)){// add functionality to show/hide the password
if(n.attr("type")!==Xo.attributes.passwordTypeAttr&&n.attr({type:Xo.attributes.passwordTypeAttr}),n.attr({autocapitalize:Xo.attributes.passwordAutocapitalizeAttr,autocomplete:Xo.attributes.passwordAutocompleteAttr}),n.hasClass(Xo.PASSWORD_TOGGLE_CLASS)){var i=n.closest(".js-form-group"),r=n.detach(),o=Xo.contactFormLanguage?Xo.contactFormLanguage:Xo.pageLanguage,a="",s=i.closest("form").find('button[type="submit"]');switch(o){case Xo.LANGUAGES.EN:a="Show";break;case Xo.LANGUAGES.ES:a="Esconder";break;case Xo.LANGUAGES.FR:default:a="Show"}i.append('<div class="input-group js-input-group"></div>'),i.find(".js-input-group").append(r),n=i.find("input"),i.find(".js-input-group").append('\n                <span class="input__add-on">\n                  <a id="'.concat(n.attr("id"),'-show-hide" class="lx-button lx-button--tertiary input__add-on--button ').concat(Xo.PASSWORD_TOGGLE_BUTTON_CLASS.slice(1)," ").concat(Xo.JS_PASSWORD_TOGGLE_BUTTON_CLASS.slice(1),'" href="javascript:void(0);" type="button">\n                    ').concat(a,"\n                  </a>\n                </span>\n              ")),s.before('<div aria-atomic="true" aria-live="assertive" class="'.concat(Xo.SECURITY_MESSAGE.slice(1),'"></div>')),S("#".concat(n.attr("id"),"-show-hide")).on("click",Xo.togglePassword)}Xo.setUpFieldValidation(t)}// TITLE
n.hasClass(Xo.TITLE_CLASS)&&Xo.setUpFieldValidation(t),// NAME
n.hasClass(Xo.NAME_CLASS)&&(n.attr({type:Xo.attributes.nameTypeAttr}),Xo.setUpFieldValidation(t)),// COMPANY NAME
n.hasClass(Xo.COMPANY_NAME_CLASS)&&(n.attr({type:Xo.attributes.companyNameTypeAttr}),Xo.setUpFieldValidation(t)),// POSITION
n.hasClass(Xo.POSITION_CLASS)&&(n.attr({type:Xo.attributes.positionTitleTypeAttr}),Xo.setUpFieldValidation(t)),// ADDRESS
n.hasClass(Xo.ADDRESS_CLASS)&&(n.attr({type:Xo.attributes.addressTypeAttr}),Xo.setUpFieldValidation(t)),// ADDRESS
n.hasClass(Xo.CITY_CLASS)&&(n.attr({type:Xo.attributes.cityTypeAttr}),Xo.setUpFieldValidation(t)),// STATE
n.hasClass(Xo.STATE_CLASS)&&Xo.setUpFieldValidation(t),// COUNTRY
n.hasClass(Xo.COUNTRY_CLASS)&&Xo.setUpFieldValidation(t),// ZIP CODE
n.hasClass(Xo.ZIP_CLASS)&&(n.attr({type:Xo.attributes.zipTypeAttr,pattern:Xo.attributes.zipPatternAttr}),Xo.setUpFieldValidation(t)),// COUNTY
n.hasClass(Xo.COUNTY_CLASS)&&Xo.setUpFieldValidation(t),// EMAIL
n.hasClass(Xo.EMAIL_CLASS)&&(n.attr({type:Xo.attributes.emailTypeAttr}),Xo.setUpFieldValidation(t)),// PHONE
n.hasClass(Xo.PHONE_CLASS)&&(n.attr({type:Xo.attributes.phoneTypeAttr,pattern:Xo.attributes.phonePatternAttr}),Xo.setUpFieldValidation(t)),// PHONE EXT
n.hasClass(Xo.PHONE_EXT_CLASS)&&(n.attr({type:Xo.attributes.phoneExtTypeAttr,min:Xo.attributes.phoneExtMinAttr}),Xo.setUpFieldValidation(t)),// PREFERRED CONTACT
n.hasClass(Xo.PREFERRED_CONTACT_CLASS)&&Xo.setUpFieldValidation(t),// BEST TIME TO CALL
n.hasClass(Xo.BEST_TIME_TO_CALL_CLASS)&&Xo.setUpFieldValidation(t),// FREEFORM
n.hasClass(Xo.FREEFORM_CLASS)&&Xo.setUpFieldValidation(t),// CURRENCY
n.hasClass(Xo.CURRENCY_CLASS)&&(n.attr({type:Xo.attributes.currencyTypeAttr,pattern:Xo.attributes.currencyPatternAttr,min:Xo.attributes.currencyMinAttr}),Xo.setUpFieldValidation(t)),// POSITIVE NUMBER
n.hasClass(Xo.POSITIVE_WHOLE_NUMBER_CLASS)&&(n.attr({type:Xo.attributes.positiveNumberTypeAttr,min:Xo.attributes.positiveNumberMinAttr}),Xo.setUpFieldValidation(t)),// GENERIC CHECKBOX
n.hasClass(Xo.CHECKBOX_CLASS)&&Xo.setUpFieldValidation(t),// GENERIC SELECT
n.hasClass(Xo.SELECT_CLASS)&&Xo.setUpFieldValidation(t),// GENERIC RADIO BUTTON
n.hasClass(Xo.RADIO_CLASS)&&Xo.setUpFieldValidation(t),// GENERIC TEXT INPUT
n.hasClass(Xo.TEXT_CLASS)&&Xo.setUpFieldValidation(t),// GENERIC TEXTAREA INPUT
n.hasClass(Xo.TEXTAREA_CLASS)&&Xo.setUpFieldValidation(t)})},
// sets up validation on the form fields
setUpFieldValidation:function(t){
// Adds example text after the field if it is available
var e=Xo.getMessaging(t),n=Xo.getTargetElement(t);if(e[Xo.EXAMPLE]){var i=e[Xo.EXAMPLE],r=S(n).prop("id")+"-"+Xo.EXAMPLE;switch(S(t).closest(Xo.FORM_WRAPPER_CLASS).length&&Xo.contactFormLanguage?Xo.contactFormLanguage:Xo.pageLanguage){case Xo.LANGUAGES.EN:i="".concat(Xo.EXAMPLE_PREFIXES.ENGLISH,": ").concat(i);break;case Xo.LANGUAGES.ES:i="".concat(Xo.EXAMPLE_PREFIXES.SPANISH,": ").concat(i);break;case Xo.LANGUAGES.FR:i="".concat(Xo.EXAMPLE_PREFIXES.FRENCH,": ").concat(i);break;default:i="".concat(Xo.EXAMPLE_PREFIXES.ENGLISH,": ").concat(i)}i='<div id="'+r+'" class="'+Xo.EXAMPLE_CLASS.slice(1)+" "+Xo.EXAMPLE_CLASS_NO_JS.slice(1)+'">'+i+"</div>",0<!S(t).closest(Xo.FORM_GROUP_CLASS).find(Xo.FORM_GROUP_EXAMPLE_CLASS).length&&S(t).closest(Xo.FORM_GROUP_CLASS).append(i),S(n).attr("aria-describedby",r)}// Sets a value in the messaging object that is specific to the field based on the field's id that is used to indicate whether the specific field has been validated through a change or submit events. The desired result is to only show the first error message when the user leaves the field, otherwise the user will see error messaging as soon as they start typing in the field.
Xo.setFieldReadyForValidationStatus(t,!1),S(t).on("change",function(e){Xo.validateField(t,e)}),// input listens to character strokes within a field
S(t).on("input",function(e){Xo.validateField(t,e)})},valOrFunction:function(e,t,n){
/* eslint-disable no-else-return */
// returns static error messages and error messages that include the field value as part of the error message
return"function"==typeof e?e.apply(t,n):e
/* eslint-enable no-else-return */},getMessaging:function(e){
// returns the object that houses messages associated with the field
var t=Xo.getTargetElement(e),n=S(t).attr("class").split(/\s+/),i="",r=S(e).closest(Xo.FORM_WRAPPER_CLASS).length&&Xo.contactFormLanguage?Xo.contactFormLanguage:Xo.pageLanguage;return S.each(n,function(e,t){0===t.indexOf(Xo.VALIDATION_CLASS_PREFIX)&&(i=t)}),Xo.messaging[r][i]},getTargetElement:function(e){
// the target element for displaying error messages is actually the group and not the individual element for radio buttons and checkboxes
// for all form fields other than radio buttons and checkboxes
var t=e;// For radio buttons
return S(e).is("[type=radio]")&&(t=S(e).closest("fieldset")),// For checkboxes
S(e).is("[type=checkbox]")&&(t=S(e).closest("fieldset")),t},getFieldReadyForValidationStatus:function(e){
// gets a field's status as ready (true) or not ready (false) for validation
// a field is ready after a change or submit event
var t=Xo.getMessaging(e),n=!0;// For radio buttons
if(// For all form fields other than radio buttons and checkboxes
S(e).is("[type=radio]")||S(e).is("[type=checkbox]")||(n=t[S(e).prop("id")]),S(e).is("[type=radio]")){var i=S(e).closest("fieldset");n=t[S(i).prop("id")]}// For checkboxes
if(S(e).is("[type=checkbox]")){var r=S(e).closest("fieldset");n=t[S(r).prop("id")]}return n},setFieldReadyForValidationStatus:function(e,t){
// marks a specific field as ready (true) or not ready (false) for validation
// a field is ready after a change or submit event
var n=Xo.getMessaging(e);// For all form fields other than radio buttons and checkboxes
// For radio buttons
if(S(e).is("[type=radio]")||S(e).is("[type=checkbox]")||(n[S(e).prop("id")]=t),S(e).is("[type=radio]")){var i=S(e).closest("fieldset");n[S(i).prop("id")]=t}// For checkboxes
if(S(e).is("[type=checkbox]")){var r=S(e).closest("fieldset");n[S(r).prop("id")]=t}},validateField:function(e,t){
// validates form fields and displays an error message if the field is invalid
var n=Xo.getMessaging(e),i=!0;// only validate if the field has been flagged as having had a change or submit event
if(// indicate if the field is being validated via a change
"change"===t.type&&Xo.setFieldReadyForValidationStatus(e,!0),Xo.getFieldReadyForValidationStatus(e)){
// the targetElement is the group for radio buttons and checkboxes - check for validation status at the group level but use the validate API on individual radio buttons/checkboxes
var r=Xo.getTargetElement(e),o=Xo.getTargetElement(S(e).closest(Xo.FORM_GROUP_CLASS)),a=S(r).attr("aria-describedby");// -- SET new error message --
// only show the visible error and add an aria-describedby mapping if the field is invalid
if(// -- CLEAR existing error messages --
S(o).find(Xo.ERROR_MESSAGE_CLASS).length&&S(o).find(Xo.ERROR_MESSAGE_CLASS).remove(),// clear any visual error formatting on the parent and children
S(o).removeClass(Xo.INVALID_CLASS_NO_DOT),S(o).find(".is-invalid").removeClass(Xo.INVALID_CLASS_NO_DOT),// clear any aria-describedby mapping
"undefined"!==B(a)&&!1!==a&&S(r).removeAttr("aria-describedby"),// -- SET validity on the actual field --
// reset the custom validity message on the field to the empty string
e.setCustomValidity(""),// set the empty field or invalid field message if appropriate
e.validity.valueMissing?e.setCustomValidity(Xo.valOrFunction(n.emptyText,window,[e])):e.validity.valid||e.setCustomValidity(Xo.valOrFunction(n.invalidText,window,[e])),e===r?
// for all form fields other than radio buttons and checkboxes
i=r.validity.valid:S(e).is("[type=radio]")?
// for radio buttons check to see if at least one radio button in the group is checked
S(e).prop("required")&&0===S(r).find("input[type=radio]:checked").length&&(i=!1):S(e).is("[type=checkbox]")&&S(e).prop("required")&&0===S(r).find("input[type=checkbox]:checked").length&&(i=!1),i){if(S(o).find(Xo.EXAMPLE_CLASS_NO_JS).length){
// reset the aria-describedby attribute if there is example text
var s=S(r).prop("id")+"-example";S(r).attr("aria-describedby",s)}}else{var l=e.validationMessage,c=S(r).prop("id")+"-error";switch(S(e).closest(Xo.FORM_WRAPPER_CLASS).length&&Xo.contactFormLanguage?Xo.contactFormLanguage:Xo.pageLanguage){case Xo.LANGUAGES.EN:l="".concat(Xo.ERROR_PREFIXES.ENGLISH," ").concat(l);break;case Xo.LANGUAGES.ES:l="".concat(Xo.ERROR_PREFIXES.SPANISH," ").concat(l);break;case Xo.LANGUAGES.FR:l="".concat(Xo.ERROR_PREFIXES.FRENCH," ").concat(l);break;default:l="".concat(Xo.ERROR_PREFIXES.ENGLISH," ").concat(l)}if(l='<div id="'+c+'" class="'+Xo.ERROR_MESSAGE_CLASS.slice(1)+'">'+l+"</div>",S(o).append(l).addClass(Xo.INVALID_CLASS_NO_DOT),S(o).find(Xo.FIELDSET_LEGEND_CLASS).addClass(Xo.INVALID_CLASS_NO_DOT),S(o).find(Xo.LABEL_CLASS).hasClass(Xo.LABEL_FIELDSET_CLASS_NO_DOT)||S(o).find(Xo.LABEL_CLASS).addClass(Xo.INVALID_CLASS_NO_DOT),S(o).find(Xo.EXAMPLE_CLASS_NO_JS).length){var d="".concat(S(r).prop("id"),"-example");S(r).attr("aria-describedby",c+" "+d),S(o).find(Xo.EXAMPLE_CLASS).addClass(Xo.INVALID_CLASS_NO_DOT)}else S(r).attr("aria-describedby",c);S(r).parent().hasClass(Xo.INPUT_GROUP_CLASS)?S(r).parent().addClass(Xo.INVALID_CLASS_NO_DOT):S(r).addClass(Xo.INVALID_CLASS_NO_DOT)}}return i},validateForm:function(e,n){var t="#"+S(e).prop("id"),i=t+" input:not([type=hidden]), "+t+" textarea:not( .g-recaptcha-response ), "+t+" select",r=null;S(i).each(function(e,t){Xo.setFieldReadyForValidationStatus(t,!0),Xo.validateField(t,n)||null===r&&(r=t)}),null!==r?(n.preventDefault(),r.focus()):0<S(t+" .g-recaptcha").length&&(S(i).each(function(e,t){S(t).attr("disabled","disabled")}),Xo.checkCaptcha(i,e,n))},renderedReCaptchas:{},checkCaptcha:function(t,e,n){try{// hides the submit button so that the user doesn't resubmit the form while the captcha is being evaluated
// created a temporary button that shows an animated icon
if(
// sets a window variable so that the value can be referenced via an inline script on a page
window.captchaCheckSubmitButtonId=S(e).find("button:submit").prop("id"),0===S("#temporary-button").length){S("#".concat(window.captchaCheckSubmitButtonId)).css("display","none");var i=S("#"+window.captchaCheckSubmitButtonId).attr("class");S('<button class="'.concat(i,'" id="temporary-button" disabled="disabled" style="margin-left:0;">Submitting ...<svg id="rotate-cw" class="lx-icon lx-icon--rotate-cw icon--rotate" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" style="margin-left: 5px"><defs><style>.cls-1,.cls-2{fill:none;stroke:#000;stroke-linecap:round;}.cls-1{stroke-miterlimit:10;}.cls-2{stroke-linejoin:round;}</style></defs><title>action-refresh</title><path class="cls-1" d="M14,8A5.88,5.88,0,0,0,8.1,2.09,6.11,6.11,0,0,0,3,4.85"/><path class="cls-1" d="M2.18,7.14c0,.29-.09.57-.09.86A5.88,5.88,0,0,0,8,13.91a5.84,5.84,0,0,0,5.34-3.33"/><polyline class="cls-2" points="3.42 8.38 2.09 7.05 0.75 8.38"/><polyline class="cls-2" points="12.58 7.05 13.91 8.38 15.25 7.05"/></svg></button>')).insertAfter("#".concat(window.captchaCheckSubmitButtonId)),S("#"+window.captchaCheckSubmitButtonId).focus()}// render the captcha if necessary
var r,o=window.captchaCheckSubmitButtonId+"-recaptcha";void 0===Xo.renderedReCaptchas[o]&&window.captchaCheckReadyForRender&&(r=grecaptcha.render(o,{sitekey:window.captchaKey}),Xo.renderedReCaptchas[o]=r),// execute the captcha if there isn't already a response
grecaptcha.getResponse(r)?S(t).each(function(e,t){S(t).removeAttr("disabled")}):(n.preventDefault(),grecaptcha.execute(r))}catch(e){console.error("Google reCAPTCHA is either not implemented or not functioning correctly: "+e),S("#temporary-button").remove(),S("#"+window.captchaCheckSubmitButtonId).css("display","inline-flex"),S(t).each(function(e,t){S(t).removeAttr("disabled")})}},
// Some sites such as BBT.com will not translate contact forms because
// the people receiving the submissions may not speak a language other than
// English. Specify the language of the form as a two letter abbreviation:
// en for English, es for Spanish, and fr for French.
setContactFormLanguage:function(t){Object.values(Xo.LANGUAGES).forEach(function(e){t===e&&(Xo.contactFormLanguage=t)})},
// if the option to show password field characters is enabled
// NOTE: this only works for one password field in a form
togglePassword:function(e){var t=S(e.target).closest(".".concat(Xo.INPUT_GROUP_CLASS)),n=t.find(".".concat(Xo.PASSWORD_CLASS)),i=t.find(Xo.JS_PASSWORD_TOGGLE_BUTTON_CLASS),r=Xo.contactFormLanguage?Xo.contactFormLanguage:Xo.pageLanguage,o="",a="",s=t.closest("form").find(Xo.SECURITY_MESSAGE),l="",c="";switch(r){case Xo.LANGUAGES.EN:o="Show",a="Hide",l="Showing your password in public may compromise security.",c="For security reasons, your password was hidden after three minutes of inactivity.";break;case Xo.LANGUAGES.ES:o="Mostrar",a="Esconder",l="Mostrar su contraseña puede comprometer su seguridad.",c="Para su seguridad, su contraseña se ocultó después de tres minutos de inactividad.";break;case Xo.LANGUAGES.FR:default:o="Show",a="Hide",l="Showing your password in public may compromise security.",c="For security reasons, your password was hidden after three minutes of inactivity."}var d="".concat(l),u="".concat(c);"password"===n.prop("type")?Xo.showPassword(n,i,s,d,u,o,a):Xo.hidePassword(n,i,s,o,u,!1)},showPassword:function(e,t,n,i,r,o,a){
// update the display
e.prop("type","text"),t.text(a),n.html(i),// start a timer
window.clearInterval(Xo.timers[e.attr("id")]),Xo.timers[e.attr("id")]=window.setTimeout(Xo.hidePassword,Xo.SHOW_PASSWORD_TIMEOUT,e,t,n,o,r,!0)},hidePassword:function(e,t,n,i,r,o){
// clear the timer
window.clearInterval(Xo.timers[e.attr("id")]),// update the display
e.prop("type","password"),t.text(i),o?n.html(r):n.html("")},updateCurrencyFieldIcon:function(){S(".js-form-validation-currency").prev(".input__add-on").find("svg").attr("aria-hidden","true")},setShowPasswordTimeout:function(e){Xo.SHOW_PASSWORD_TIMEOUT=e},init:function(){
// _private.cacheDom();
Xo.bindEvents(),Xo.setUpAttributes(),Xo.setUpMessaging(),Xo.setUpFormValidation(),Xo.updateCurrencyFieldIcon()}}).setContactFormLanguage,init:Xo.init,validateField:Xo.validateField,validateForm:Xo.validateForm,setShowPasswordTimeout:Xo.setShowPasswordTimeout},Zo={init:(Yo={GENERIC_SELECT_FORM_CLASS:".js-generic-select",GENERIC_SELECT_SELECT_CLASS:".js-generic-select-select",
// cacheDom: function cacheDom() {},
bindEvents:function(){S(Yo.GENERIC_SELECT_FORM_CLASS).on("submit",function(e){Yo.goToTargetUrl(e)})},
// looks at the event to determine the active generic select form
// checks to ensure that an option has been selected
// checks to see if there is a data attribute to determine if the link should open in a new window
// then goes to that link
goToTargetUrl:function(e){e.preventDefault();var t=S(e.target).find(Yo.GENERIC_SELECT_SELECT_CLASS+" option").filter(":selected"),n=t.val(),i=t.attr("data-open-in-new-tab");n&&(i?window.open(n,"_blank"):window.open(n,"_self"))},init:function(){Yo.bindEvents()}}).init},ea={init:(Ko={init:function(){Ko.cacheDom(),Ko.wrapElements(Ko.$grid)},cacheDom:function(){Ko.$grid=S(".js-lx-grid")},wrapElements:function(e){e.children().wrap("<div class='lx-grid__cell'></div>")}}).init},ta={init:(qo={menuWrapper:document.getElementById("js-header"),focusOutListenerAdded:!1,OFFCANVAS_TRIGGER_CLASS:".js-header__offcanvas__trigger",OFFCANVAS_TRIGGER_CLASS_NO_DOT:"js-header__offcanvas__trigger",OFFCANVAS_TARGET_CLASS:".js-header__offcanvas__target",OFFCANVAS_TRIGGER_TEXT_CLASS:".js-header__offcanvas__trigger-text",HEADER_CLASS:".js-header",SKIPNAV_CLASS:".js-header__skip-nav",SEARCH_FORM_CLASS:".js-header__search-form",SEARCH_FORM_INPUT_CLASS:".js-header__search-form__input",SEARCH_FORM_SUBMIT_CLASS:".js-header__search-form__submit-button",SEARCH_FORM_DESKTOP_ID:"#js-header__search-form--desktop",SEARCH_FORM_INPUT_DESKTOP_ID:"#header__search-form__input--desktop",SEARCH_FORM_MOBILE_ID:"#js-header__search-form--mobile",SEARCH_FORM_INPUT_MOBILE_ID:"#header__search-form__input--mobile",MOBILE_MENU_FOCUSABLE_CLASS:"js-header__mobile-menu-focusable",BRAND_LOGO_CLASS:".js-header__brand-logo",TAB_PANEL_CLASS:".js-lx-tabs__panel",TAB_CLASS:".js-lx-tabs__tab",ALERT_CLASS:".js-lx-block-alert",ACTIVE_CLASS_NO_DOT:"is-active",OVERFLOW_CLASS_NO_DOT:"overflow-hidden",EXPANDED_CLASS_NO_DOT:"is-expanded--v1",OPENING_CLASS_NO_DOT:"is-opening--v1",CLOSING_CLASS_NO_DOT:"is-closing--v1",DEFAULT_CLASS_NO_DOT:"is-default",MOBILE_CLASS_NO_DOT:"sm-screen",DESKTOP_CLASS_NO_DOT:"lg-screen",MAIN_CONTENT_ID:"#main-content",bindEvents:function(){
// listen for a focus out event on the mobile menu trigger
// only at mobile and only if the menu is shown
S(qo.OFFCANVAS_TRIGGER_CLASS).focusout(function(){qo.focusOutListenerAdded||(S("body").on("focusin",qo.offCanvasFocusOutEventHandler),qo.focusOutListenerAdded=!0)}),// listen for a focus out event on any item in the mobile menu at mobile breakpoints
S(qo.OFFCANVAS_TARGET_CLASS).focusout(function(){S("body").hasClass(qo.MOBILE_CLASS_NO_DOT)&&(qo.focusOutListenerAdded||(S("body").on("focusin",qo.offCanvasFocusOutEventHandler),qo.focusOutListenerAdded=!0))}),// handle a click on the hamburger menu
S(qo.OFFCANVAS_TRIGGER_CLASS).click(function(){S(qo.HEADER_CLASS).hasClass(qo.EXPANDED_CLASS_NO_DOT)?qo.offCanvasHideEventHandler():qo.offCanvasShowEventHandler()}),S(qo.MAIN_CONTENT_ID).on("blur",function(){S(qo.MAIN_CONTENT_ID).removeAttr("tabindex")}),// if ( $( _private.HEADER_CLASS ).length ) {
//   _private.menuWrapper.addEventListener( 'animationstart', _private.animationListener, false );
//   _private.menuWrapper.addEventListener( 'animationend', _private.animationListener, false );
// }
S(window).on("resize",function(){qo.headerWidthHandler()}),S(qo.SEARCH_FORM_CLASS).focusin(function(){S(qo.SEARCH_FORM_CLASS).addClass(qo.ACTIVE_CLASS_NO_DOT)}),S(qo.SEARCH_FORM_CLASS).focusout(function(){S(qo.SEARCH_FORM_CLASS).removeClass(qo.ACTIVE_CLASS_NO_DOT),qo.headerSubmitButtonHandler()}),S(qo.SEARCH_FORM_INPUT_CLASS).on("input",function(){qo.headerSubmitButtonHandler()}),// mirror input values between search input fields
S(qo.SEARCH_FORM_INPUT_DESKTOP_ID).on("keypress keyup blur",function(e){S(qo.SEARCH_FORM_INPUT_MOBILE_ID).val(S(e.target).val())}),S(qo.SEARCH_FORM_INPUT_MOBILE_ID).on("keypress keyup blur",function(e){S(qo.SEARCH_FORM_INPUT_DESKTOP_ID).val(S(e.target).val())}),S(qo.SKIPNAV_CLASS).click(function(e){e.preventDefault(),qo.skipNavFocusHandler()})},offCanvasFocusOutEventHandler:function e(t){
// listens for a focus event outside of the mobile menu and the hamburger button
S(document.activeElement).hasClass(qo.MOBILE_MENU_FOCUSABLE_CLASS)||S(document.activeElement).hasClass(qo.OFFCANVAS_TRIGGER_CLASS_NO_DOT)||S(qo.HEADER_CLASS).hasClass(qo.EXPANDED_CLASS_NO_DOT)&&(S("body").off("focusin",e),qo.focusOutListenerAdded=!1,qo.offCanvasHideEventHandler())},
// animationListener: function animationListener( event ) {
//   console.log( 'animationListener' );
//   if ( event.animationName === 'opening' && event.type.toLowerCase().indexOf( 'animationstart' ) >= 0 ) {
//     $( _private.OFFCANVAS_TARGET_CLASS ).css( 'display', 'flex' );
//   }
//   if ( event.animationName === 'opening' && event.type.toLowerCase().indexOf( 'animationend' ) >= 0 ) {
//     _private.offCanvasShownEventHandler();
//   }
//   if ( event.animationName === 'closing' && event.type.toLowerCase().indexOf( 'animationend' ) >= 0 ) {
//     _private.offCanvasHiddenEventHandler();
//   }
// },
// called when the mobile menu shows
offCanvasShowEventHandler:function(){S("body").addClass(qo.OVERFLOW_CLASS_NO_DOT),S(qo.HEADER_CLASS).addClass(qo.OPENING_CLASS_NO_DOT),qo.offCanvasShownEventHandler()},offCanvasShownEventHandler:function(){S(qo.OFFCANVAS_TARGET_CLASS).css("display","flex"),S(qo.HEADER_CLASS).addClass(qo.EXPANDED_CLASS_NO_DOT),S(qo.HEADER_CLASS).removeClass(qo.OPENING_CLASS_NO_DOT),S(qo.OFFCANVAS_TARGET_CLASS).addClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.OFFCANVAS_TRIGGER_CLASS).attr("aria-expanded",!0)},
// called when the off canvas starts the hide process
offCanvasHideEventHandler:function(e){S(qo.HEADER_CLASS).removeClass(qo.EXPANDED_CLASS_NO_DOT),S(qo.HEADER_CLASS).addClass(qo.CLOSING_CLASS_NO_DOT),S(qo.OFFCANVAS_TARGET_CLASS).removeClass(qo.ACTIVE_CLASS_NO_DOT),qo.offCanvasHiddenEventHandler()},
// called when the off canvas is fully hidden
offCanvasHiddenEventHandler:function(e){S(qo.OFFCANVAS_TARGET_CLASS).css("display","none"),S(qo.HEADER_CLASS).removeClass(qo.CLOSING_CLASS_NO_DOT),S("body").removeClass(qo.OVERFLOW_CLASS_NO_DOT),// handle reseting all tab and tab panel attributes so that nothing is active
S(qo.HEADER_CLASS+" "+qo.TAB_CLASS).removeClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.HEADER_CLASS+" "+qo.TAB_CLASS).attr("tabindex",-1),S(qo.HEADER_CLASS+" "+qo.TAB_CLASS).attr("aria-selected",!1),S(qo.HEADER_CLASS+" "+qo.TAB_PANEL_CLASS).attr("aria-hidden",!0),S(qo.HEADER_CLASS+" "+qo.TAB_PANEL_CLASS).removeClass(qo.ACTIVE_CLASS_NO_DOT),// handle adding active classes to default tab and tab panel
S(qo.HEADER_CLASS+" "+qo.TAB_CLASS+"."+qo.DEFAULT_CLASS_NO_DOT).addClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.HEADER_CLASS+" "+qo.TAB_CLASS+"."+qo.DEFAULT_CLASS_NO_DOT).attr("tabindex",0),S(qo.HEADER_CLASS+" "+qo.TAB_CLASS+"."+qo.DEFAULT_CLASS_NO_DOT).attr("aria-selected",!0),S(qo.HEADER_CLASS+" "+qo.TAB_PANEL_CLASS+"."+qo.DEFAULT_CLASS_NO_DOT).attr("aria-hidden",!1),S(qo.HEADER_CLASS+" "+qo.TAB_PANEL_CLASS+"."+qo.DEFAULT_CLASS_NO_DOT).addClass(qo.ACTIVE_CLASS_NO_DOT),// handle reseting display of active segment if resized to desktop
S("body").hasClass(qo.DESKTOP_CLASS_NO_DOT)&&S(qo.OFFCANVAS_TARGET_CLASS).css("display","flex"),// handle offcanvas nav trigger attributes
S(qo.OFFCANVAS_TRIGGER_CLASS).attr("aria-expanded",!1)},headerWidthHandler:function(){
// called on resize
S("body").hasClass(qo.DESKTOP_CLASS_NO_DOT)&&(S(qo.BRAND_LOGO_CLASS).removeAttr("tabindex"),S(qo.BRAND_LOGO_CLASS).removeAttr("aria-hidden"),S(qo.TAB_PANEL_CLASS).removeAttr("role"),S(qo.OFFCANVAS_TRIGGER_TEXT_CLASS).text("Primary navigation"),S(qo.OFFCANVAS_TARGET_CLASS).css("display","flex"),S(qo.HEADER_CLASS).hasClass(qo.EXPANDED_CLASS_NO_DOT)&&qo.offCanvasHideEventHandler()),S("body").hasClass(qo.MOBILE_CLASS_NO_DOT)&&(S(qo.BRAND_LOGO_CLASS).attr("tabindex",-1),S(qo.BRAND_LOGO_CLASS).attr("aria-hidden",!0),S(qo.OFFCANVAS_TRIGGER_TEXT_CLASS).text("Menu"),S(qo.TAB_PANEL_CLASS).attr("role","tabpanel"),S(qo.HEADER_CLASS).hasClass(qo.EXPANDED_CLASS_NO_DOT)||S(qo.OFFCANVAS_TARGET_CLASS).css("display","none"))},headerSubmitButtonHandler:function(){
// on input change, check to see if the input has a value, if so add active class,
// and remove aria hidden and tabindex -1 so that's available to screen readers
// if it does not, remove active class and add aria hidden and tabindex -1 to hide
// it } from screen readers
// desktop search
S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_INPUT_CLASS).val()?(S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).addClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",null),S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!1)):(S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).removeClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",-1),S(qo.SEARCH_FORM_DESKTOP_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!0)),// mobile search
S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_INPUT_CLASS).val()?(S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).addClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",null),S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!1)):(S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).removeClass(qo.ACTIVE_CLASS_NO_DOT),S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",-1),S(qo.SEARCH_FORM_MOBILE_ID+" "+qo.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!0))},skipNavFocusHandler:function(){
// skip navigation
S(qo.HEADER_CLASS).find(qo.ALERT_CLASS).length?S("body "+qo.ALERT_CLASS+":first-of-type").focus():(S(qo.MAIN_CONTENT_ID).attr("tabindex",-1),S(qo.MAIN_CONTENT_ID).focus())},init:function(){qo.bindEvents()}}).init},na={init:($o={MOBILE_NAV_WRAPPER:".header__navigation-collapse",MOBILE_NAV_TRIGGER_CLASS:".js-header__offcanvas__trigger",MOBILE_NAV_TRIGGER_CLASS_NO_DOT:"js-header__offcanvas__trigger",MOBILE_NAV_TARGET_WRAPPER_CLASS:".header__offcanvas__target__wrapper",MOBILE_NAV_TARGET_CLASS:".js-header__offcanvas__target",MOBILE_NAV_TRIGGER_TEXT_CLASS:".js-header__offcanvas__trigger-text",MOBILE_NAV_TABLIST_CLASS:".js-lx-tabs__list",MOBILE_NAV_TAB_CLASS:".js-lx-tabs__panel",LOGIN_TRIGGER_CLASS:".navbar--primary__list-item__button--collapse",HEADER_CLASS:".js-header",SKIPNAV_CLASS:".js-header__skip-nav",SEARCH_TRIGGER_CLASS:".header__search-collapse__button",SEARCH_FORM_CLASS:".js-header__search-form",SEARCH_FORM_INPUT_CLASS:".js-header__search-form__input",SEARCH_FORM_SUBMIT_CLASS:".js-header__search-form__submit-button",SEARCH_COLLAPSE_TARGET_CLASS:".header__search-collapse--search__target",SEARCH_FORM_DESKTOP_ID:"#js-header__search-form--desktop",SEARCH_FORM_INPUT_DESKTOP_ID:"#header__search-form__input--desktop",SEARCH_FORM_MOBILE_ID:"#js-header__search-form--mobile",SEARCH_FORM_INPUT_MOBILE_ID:"#header__search-form__input--mobile",MOBILE_MENU_FOCUSABLE_CLASS:"js-header__mobile-menu-focusable",ALERT_CLASS:".js-lx-block-alert",ACTIVE_CLASS_NO_DOT:"is-active",DEFAULT_CLASS_NO_DOT:"is-default",EXPANDED_CLASS_NO_DOT:"is-expanded",MOBILE_CLASS_NO_DOT:"sm-screen",DESKTOP_CLASS_NO_DOT:"lg-screen",MAIN_CONTENT_ID:"#main-content",PRIMARY_NAV_COLLAPSE_TRIGGER_CLASS:".header__navigation-list-item--primary__button--collapsible",BACKDROP_CLASS_NO_DOT:"backdrop",HEADER_BACKDROP_ON_CLASS_NO_DOT:"backdrop-on",DISPLAY_PRIMARY_NAV_CLASS_NO_DOT:"display-primary-nav-at-desktop",DISPLAY_PRIMARY_NAV_DELAY:100,BREADCRUMBS_CLASS:".js-breadcrumbs",SCREEN_READER_ONLY_CLASS:".lx-screen-reader-only",pageContentDisplayIsOn:!0,primaryNavIsDisplayed:void 0,tabPanelRoleIsAdded:!1,
// cacheDom: function cacheDom() {},
bindEvents:function(){
// set the page content to display none when the mobile nav or login are expanded
$o.observeMobileNavTrigger(),$o.observeLoginTrigger(),// always show the primary nav at desktop
// always show the page content at desktop
$o.toggleTabPanelRole(),$o.togglePrimaryNavAndPageContentDisplay(),S(window).resize(function(e){$o.togglePrimaryNavAndPageContentDisplay()}),// skip to main
S($o.SKIPNAV_CLASS).click(function(e){e.preventDefault(),$o.skipNavFocusHandler()}),// remove the tabindex on main when main loses focus; the tabindex is added when the skip nav is selected
S($o.MAIN_CONTENT_ID).on("blur",function(){S($o.MAIN_CONTENT_ID).removeAttr("tabindex")}),// focus management for the desktop and mobile searches
S($o.SEARCH_TRIGGER_CLASS).click(function(){S($o.SEARCH_TRIGGER_CLASS).hasClass($o.EXPANDED_CLASS_NO_DOT)&&S($o.SEARCH_FORM_INPUT_CLASS).focus()}),S($o.SEARCH_FORM_CLASS).focusin(function(){S($o.SEARCH_FORM_CLASS).addClass($o.ACTIVE_CLASS_NO_DOT)}),S($o.SEARCH_FORM_CLASS).focusout(function(){S($o.SEARCH_FORM_CLASS).removeClass($o.ACTIVE_CLASS_NO_DOT);// for accessibility reasons - the search button is always displayed and in the tab order
// comment the setUpSearchHandler() lines if you uncomment out the line below
// _private.headerSearchHandler();
}),S($o.SEARCH_FORM_INPUT_CLASS).on("input",function(){// for accessibility reasons - the search button is always displayed and in the tab order
// comment the setUpSearchHandler() lines if you uncomment out the line below
// _private.headerSearchHandler();
}),// for accessibility reasons - the search button is always displayed and in the tab order
// uncomment the headerSearchHandler() lines if you comment out the line below
$o.setUpSearchHandler(),// mirror input values between search input fields
S($o.SEARCH_FORM_INPUT_DESKTOP_ID).on("keypress keyup blur",function(e){S($o.SEARCH_FORM_INPUT_MOBILE_ID).val(S(e.target).val())}),S($o.SEARCH_FORM_INPUT_MOBILE_ID).on("keypress keyup blur",function(e){S($o.SEARCH_FORM_INPUT_DESKTOP_ID).val(S(e.target).val())})},observeMobileNavTrigger:function(){
// create an observer instance linked to the callback function and start observing the target nodes for configured mutations
var e=S($o.MOBILE_NAV_TRIGGER_CLASS);1===e.length&&new MutationObserver($o.togglePrimaryNavAndPageContentDisplay).observe(e[0],{attributes:!0,attributeFilter:["class"]})},observeLoginTrigger:function(){
// create an observer instance linked to the callback function and start observing the target nodes for configured mutations
var e=S($o.LOGIN_TRIGGER_CLASS);1===e.length&&new MutationObserver($o.togglePrimaryNavAndPageContentDisplay).observe(e[0],{attributes:!0,attributeFilter:["class"]})},togglePrimaryNavAndPageContentDisplay:function(){if(S("body").hasClass($o.DESKTOP_CLASS_NO_DOT))
// collapse the mobile nav if it is open and display the primary nav
$o.primaryNavIsDisplayed||$o.displayPrimaryNav(),// remove the tabpanel role
$o.tabPanelRoleIsAdded&&$o.toggleTabPanelRole(),// always display page content at desktop
$o.togglePageContentDisplayOn();else{var e=S($o.MOBILE_NAV_TRIGGER_CLASS)[0],t=S($o.LOGIN_TRIGGER_CLASS)[0];// set the primary nav to display based on the state of its parent collapse
$o.primaryNavFunctionsAsACollapse(),// add the tabpanel role
$o.tabPanelRoleIsAdded||$o.toggleTabPanelRole(),// at mobile, check if either the mobile nav or login is expanded and set the page content to display none if either one is
S(e).hasClass($o.EXPANDED_CLASS_NO_DOT)||S(t).hasClass($o.EXPANDED_CLASS_NO_DOT)?$o.pageContentDisplayIsOn&&$o.togglePageContentDisplayOff():$o.pageContentDisplayIsOn||$o.togglePageContentDisplayOn()}},toggleTabPanelRole:function(){S("body").hasClass($o.DESKTOP_CLASS_NO_DOT)?(S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS+" "+$o.MOBILE_NAV_TAB_CLASS).removeAttr("role"),$o.tabPanelRoleIsAdded=!1):0<S($o.MOBILE_NAV_TABLIST_CLASS).length&&S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS+" "+$o.MOBILE_NAV_TAB_CLASS).attr("role","tabpanel"),$o.tabPanelRoleIsAdded=!0},
// displays the primary nav at desktop
displayPrimaryNav:function(){var e=S($o.MOBILE_NAV_TRIGGER_CLASS)[0],t=S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("role"),n=S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("aria-labelledby");// remove the role region and save its value to a data- attribute
S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("data-role",t),S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).removeAttr("role"),// remove the aria-labelledby attribute and save its value to a data- attribute
S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("data-aria-labelledby",n),S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).removeAttr("aria-labelledby"),// display the primary nav items
S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).addClass($o.DISPLAY_PRIMARY_NAV_CLASS_NO_DOT),// ensure that the correct group of primary nav items is displayed at desktop
S("".concat($o.MOBILE_NAV_TARGET_WRAPPER_CLASS," ").concat($o.MOBILE_NAV_TAB_CLASS)).each(function(e,t){var n=S(t);n.hasClass($o.DEFAULT_CLASS_NO_DOT)?(n.hasClass($o.ACTIVE_CLASS_NO_DOT)||n.addClass($o.ACTIVE_CLASS_NO_DOT),S(this).attr("aria-hidden","false")):(n.removeClass($o.ACTIVE_CLASS_NO_DOT),S(this).attr("aria-hidden","true"))}),// hide the collapse before closing it to deal with a animation that is part of the collapse
S(e).hasClass($o.EXPANDED_CLASS_NO_DOT)&&(S($o.MOBILE_NAV_WRAPPER).attr("style","display: none"),S(e).click(),setTimeout(function(){S($o.MOBILE_NAV_WRAPPER).removeAttr("style","display: none")},$o.DISPLAY_PRIMARY_NAV_DELAY)),$o.primaryNavIsDisplayed=!0},primaryNavFunctionsAsACollapse:function(){var e=S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("data-role"),t=S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("data-aria-labelledby");// remove the role region and save its value to a data- attribute
S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("role",e),S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).removeAttr("data-role"),// remove the aria-labelledby region and save its value to a data- attribute
S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).attr("aria-labelledby",t),S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).removeAttr("data-aria-labelledby"),S($o.MOBILE_NAV_TARGET_WRAPPER_CLASS).removeClass($o.DISPLAY_PRIMARY_NAV_CLASS_NO_DOT),$o.primaryNavIsDisplayed=!1},togglePageContentDisplayOn:function(){S(".header").removeClass($o.HEADER_BACKDROP_ON_CLASS_NO_DOT),S("main").removeClass($o.BACKDROP_CLASS_NO_DOT),S("nav"+$o.BREADCRUMBS_CLASS).removeClass($o.BACKDROP_CLASS_NO_DOT),S("footer").removeClass($o.BACKDROP_CLASS_NO_DOT),$o.pageContentDisplayIsOn=!0},togglePageContentDisplayOff:function(){S(".header").addClass($o.HEADER_BACKDROP_ON_CLASS_NO_DOT),S("main").addClass($o.BACKDROP_CLASS_NO_DOT),S("nav"+$o.BREADCRUMBS_CLASS).addClass($o.BACKDROP_CLASS_NO_DOT),S("footer").addClass($o.BACKDROP_CLASS_NO_DOT),$o.pageContentDisplayIsOn=!1},skipNavFocusHandler:function(){
// skip navigation
S($o.HEADER_CLASS).find($o.ALERT_CLASS).length?S("body "+$o.ALERT_CLASS+":first-of-type").focus():(S($o.MAIN_CONTENT_ID).attr("tabindex",-1),S($o.MAIN_CONTENT_ID).focus())},headerSearchHandler:function(){
// on input change, check to see if the input has a value, if so add active class,
// and remove aria hidden and tabindex -1 so that's available to screen readers
// if it does not, remove active class and add aria hidden and tabindex -1 to hide
// it } from screen readers
// desktop search
S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_INPUT_CLASS).val()?(S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).addClass($o.ACTIVE_CLASS_NO_DOT),S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",null),S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!1)):(S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).removeClass($o.ACTIVE_CLASS_NO_DOT),S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",-1),S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!0)),// mobile search
S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_INPUT_CLASS).val()?(S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).addClass($o.ACTIVE_CLASS_NO_DOT),S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",null),S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!1)):(S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).removeClass($o.ACTIVE_CLASS_NO_DOT),S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",-1),S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!0))},setUpSearchHandler:function(){
// this is a more accessible alternative to the headerSearchHandler function
// it always shows the search button within the search form
// both desktop and mobile
S($o.SEARCH_COLLAPSE_TARGET_CLASS).attr("role","search"),S($o.SEARCH_FORM_CLASS).removeAttr("role"),// desktop
S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).addClass($o.ACTIVE_CLASS_NO_DOT),S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",null),S($o.SEARCH_FORM_DESKTOP_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!1),S("".concat($o.SEARCH_FORM_DESKTOP_ID," ").concat($o.SEARCH_FORM_SUBMIT_CLASS," ").concat($o.SCREEN_READER_ONLY_CLASS)).remove(),S("".concat($o.SEARCH_FORM_DESKTOP_ID," ").concat($o.SEARCH_FORM_SUBMIT_CLASS)).after('<span id="desktop-search-button-description" class="screen-reader-only">&nbsp;tabbing past this button closes search</span>'),S("".concat($o.SEARCH_FORM_DESKTOP_ID," ").concat($o.SEARCH_FORM_SUBMIT_CLASS)).attr("aria-describedby","desktop-search-button-description"),// mobile
S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).addClass($o.ACTIVE_CLASS_NO_DOT),S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("tabindex",null),S($o.SEARCH_FORM_MOBILE_ID+" "+$o.SEARCH_FORM_SUBMIT_CLASS).attr("aria-hidden",!1),S("".concat($o.SEARCH_FORM_MOBILE_ID," ").concat($o.SEARCH_FORM_SUBMIT_CLASS," ").concat($o.SCREEN_READER_ONLY_CLASS)).remove()},init:function(){$o.bindEvents()}}).init},ia={init:(Jo={PARENT_CLASS:".aem-template .component--parent",removeEmptyParents:function(){S.each(S(Jo.PARENT_CLASS),function(e,t){S(t).find(".js-lx-grid").has("div").length||S(t).find(".js-lx-grid").has("img").length||S(t).remove()})},init:function(){Jo.removeEmptyParents()}}).init},ra=he.f,oa=P.f,aa=F.f,sa="Number",la=h[sa],ca=la.prototype,da=s(un(ca))==sa,ua="trim"in String.prototype,fa=function(e){var t,n,i,r,o,a,s,l,c=R(e,!1);if("string"==typeof c&&2<c.length)if(43===(t=(c=ua?c.trim():br(c,3)).charCodeAt(0))||45===t){if(88===(n=c.charCodeAt(2))||120===n)return NaN;// Number('+0x1') should be NaN, old V8 fix
}else if(48===t){switch(c.charCodeAt(1)){case 66:case 98:i=2,r=49;break;// fast equal of /^0b[01]+$/i
case 79:case 111:i=8,r=55;break;// fast equal of /^0o[0-7]+$/i
default:return+c}for(a=(o=c.slice(2)).length,s=0;s<a;s++)
// parseInt parses a string to a first unavailable symbol
// but ToNumber should return NaN if a string contains unavailable symbols
if((l=o.charCodeAt(s))<48||r<l)return NaN;return parseInt(o,i)}return+c};
// `Number` constructor
// https://tc39.github.io/ecma262/#sec-number-constructor
if(ye(sa,!la(" 0o1")||!la("0b1")||la("+0x1"))){for(var _a,Sa=function(e){var t=arguments.length<1?0:e,n=this;return n instanceof Sa&&(da?u(function(){ca.valueOf.call(n)}):s(n)!=sa)?Ze(new la(fa(t)),n,Sa):fa(t)},pa=A?ra(la):
// ES3:
"MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger".split(","),Ea=0;pa.length>Ea;Ea++)I(la,_a=pa[Ea])&&!I(Sa,_a)&&aa(Sa,_a,oa(la,_a));(Sa.prototype=ca).constructor=Sa,ie(h,sa,Sa)}
/* eslint-disable */
/*
   * File: iframeResizer.js
   * Desc: Force iframes to size to content.
   * Requires: iframeResizer.contentWindow.js to be loaded into the target frame.
   * Doc: https://github.com/davidjbradshaw/iframe-resizer
   * Author: David J. Bradshaw - dave@bradshaw.net
   * Contributor: Jure Mav - jure.mav@gmail.com
   * Contributor: Reed Dadoune - reed@dadoune.com
   */
/* BB&T has modified this file to wrap the functionality, so that
   * it doesn't execute on import. We require three different resizing
   * approaches for different vendors, and we only want to initialize
   * the ones that we need on a page.
   */for(var ha,Aa,ma,Ta={initIframeResizer:function(){if("undefined"!=typeof window){// don't run for server side render
var e,l=0,c=!1,t=!1,h="message".length,A="[iFrameSizer]",
//Must match iframe msg ID
m=A.length,T=null,o=window.requestAnimationFrame,d={max:1,scroll:1,bodyScroll:1,documentElementScroll:1},g={},n=null,u={autoResize:!0,bodyBackground:null,bodyMargin:null,bodyMarginV1:8,bodyPadding:null,checkOrigin:!0,inPageLinks:!1,enablePublicMethods:!0,heightCalculationMethod:"bodyOffset",id:"iFrameResizer",interval:32,log:!1,maxHeight:1/0,maxWidth:1/0,minHeight:0,minWidth:0,resizeFrom:"parent",scrolling:!1,sizeHeight:!0,sizeWidth:!1,warningTimeout:5e3,tolerance:0,widthCalculationMethod:"scroll",closedCallback:function(){},initCallback:function(){},messageCallback:function(){v("MessageCallback function not defined")},resizedCallback:function(){},scrollCallback:function(){return!0}};window.jQuery&&((e=window.jQuery).fn?e.fn.iFrameResize||(e.fn.iFrameResize=function(n){return this.filter("iframe").each(function(e,t){f(t,n)}).end()}):R("","Unable to bind to jQuery, it is not fully loaded.")),"function"==typeof define&&define.amd?define([],E):"object"===("undefined"==typeof module?"undefined":B(module))&&"object"===B(module.exports)?
//Node for browserfy
module.exports=E():window.iFrameResize=window.iFrameResize||E()}function C(e,t,n){
/* istanbul ignore else */
// Not testable in PhantonJS
"addEventListener"in window?e.addEventListener(t,n,!1):"attachEvent"in window&&
//IE
e.attachEvent("on"+t,n)}function L(e,t,n){
/* istanbul ignore else */
// Not testable in phantonJS
"removeEventListener"in window?e.removeEventListener(t,n,!1):"detachEvent"in window&&
//IE
e.detachEvent("on"+t,n)}function r(e){return A+"["+(n="Host page: "+(t=e),window.top!==window.self&&(n=window.parentIFrame&&window.parentIFrame.getId?window.parentIFrame.getId()+": "+t:"Nested host page: "+t),n)+"]";var t,n}function i(e){return g[e]?g[e].log:c}function O(e,t){a("log",e,t,i(e))}function R(e,t){a("info",e,t,i(e))}function v(e,t){a("warn",e,t,!0)}function a(e,t,n,i){!0===i&&"object"===B(window.console)&&console[e](r(t),n)}function s(t){function a(){e("Height"),e("Width"),w(function(){P(p),N(E),f("resizedCallback",p)},p,"init")}function e(e){var t=Number(g[E]["max"+e]),n=Number(g[E]["min"+e]),i=e.toLowerCase(),r=Number(p[i]);O(E,"Checking "+i+" is in range "+n+"-"+t),r<n&&(r=n,O(E,"Set "+i+" to min value")),t<r&&(r=t,O(E,"Set "+i+" to max value")),p[i]=""+r}function s(e){return S.substr(S.indexOf(":")+h+e)}function l(n,i){x(function(){var e,t;G("Send Page Info","pageInfo:"+(e=document.body.getBoundingClientRect(),t=p.iframe.getBoundingClientRect(),JSON.stringify({iframeHeight:t.height,iframeWidth:t.width,clientHeight:Math.max(document.documentElement.clientHeight,window.innerHeight||0),clientWidth:Math.max(document.documentElement.clientWidth,window.innerWidth||0),offsetTop:parseInt(t.top-e.top,10),offsetLeft:parseInt(t.left-e.left,10),scrollTop:window.pageYOffset,scrollLeft:window.pageXOffset})),n,i)},32)}function c(e){var t=e.getBoundingClientRect();return b(E),{x:Math.floor(Number(t.left)+Number(T.x)),y:Math.floor(Number(t.top)+Number(T.y))}}function d(e){var t=e?c(p.iframe):{x:0,y:0},n={x:Number(p.width)+t.x,y:Number(p.height)+t.y};O(E,"Reposition requested } from iFrame (offset x:"+t.x+" y:"+t.y+")"),window.top!==window.self?window.parentIFrame?window.parentIFrame["scrollTo"+(e?"Offset":"")](n.x,n.y):v(E,"Unable to scroll to requested position, window.parentIFrame not found"):(T=n,u(),O(E,"--"))}function u(){!1!==f("scrollCallback",T)?N(E):D()}function f(e,t){return I(E,e,t)}var n,i,r,o,_,S=t.data,p={},E=null;"[iFrameResizerChild]Ready"===S?function(){for(var e in g)G("iFrame requested init",F(e),document.getElementById(e),e)}():A===(""+S).substr(0,m)&&S.substr(m).split(":")[0]in g?(_=S.substr(m).split(":"),p={iframe:g[_[0]]&&g[_[0]].iframe,id:_[0],height:_[1],width:_[2],type:_[3]},E=p.id,g[E]&&(g[E].loaded=!0),(o=p.type in{true:1,false:1,undefined:1})&&O(E,"Ignoring init message } from meta parent page"),!o&&(r=!0,g[i=E]||(r=!1,v(p.type+" No settings for "+i+". Message was: "+S)),r)&&(O(E,"Received: "+S),n=!0,null===p.iframe&&(v(E,"IFrame ("+p.id+") not found"),n=!1),n&&function(){var e,n=t.origin,i=g[E]&&g[E].checkOrigin;if(i&&""+n!="null"&&!(i.constructor===Array?function(){var e=0,t=!1;for(O(E,"Checking connection is } from allowed list of origins: "+i);e<i.length;e++)if(i[e]===n){t=!0;break}return t}():(e=g[E]&&g[E].remoteHost,O(E,"Checking connection is from: "+e),n===e)))throw new Error("Unexpected message received from: "+n+" for "+p.iframe.id+". Message was: "+t.data+". This error can be disabled by setting the checkOrigin: false option or by providing of array of trusted domains.");return!0}()&&function(){switch(g[E]&&g[E].firstRun&&g[E]&&(g[E].firstRun=!1),p.type){case"close":g[E].closeRequestCallback?I(E,"closeRequestCallback",g[E].iframe):y(p.iframe);break;case"message":o=s(6),O(E,"MessageCallback passed: {iframe: "+p.iframe.id+", message: "+o+"}"),f("messageCallback",{iframe:p.iframe,message:JSON.parse(o)}),O(E,"--");break;case"scrollTo":d(!1);break;case"scrollToOffset":d(!0);break;case"pageInfo":l(g[E]&&g[E].iframe,E),function(){function e(t,n){function i(){g[o]?l(g[o].iframe,o):r()}["scroll","resize"].forEach(function(e){O(o,t+e+" listener for sendPageInfo"),n(window,e,i)})}function r(){e("Remove ",L)}var o=E;//Create locally scoped copy of iFrame ID
e("Add ",C),g[o]&&(g[o].stopPageInfo=r)}();break;case"pageInfoStop":g[E]&&g[E].stopPageInfo&&(g[E].stopPageInfo(),delete g[E].stopPageInfo);break;case"inPageLink":e=s(9),n=e.split("#")[1]||"",i=decodeURIComponent(n),(r=document.getElementById(i)||document.getElementsByName(i)[0])?(t=c(r),O(E,"Moving to in page link (#"+n+") at x: "+t.x+" y: "+t.y),T={x:t.x,y:t.y},u(),O(E,"--")):window.top!==window.self?window.parentIFrame?window.parentIFrame.moveToAnchor(n):O(E,"In page link #"+n+" not found and window.parentIFrame not found"):O(E,"In page link #"+n+" not found");break;case"reset":M(p);break;case"init":a(),f("initCallback",p.iframe);break;default:a()}var e,t,n,i,r,o}())):R(E,"Ignored: "+S)}function I(e,t,n){var i=null,r=null;if(g[e]){if("function"!=typeof(i=g[e][t]))throw new TypeError(t+" on iFrame["+e+"] is not a function");r=i(n)}return r}function y(e){var t=e.id;O(t,"Removing iFrame: "+t),e.parentNode&&e.parentNode.removeChild(e),I(t,"closedCallback",t),O(t,"--"),delete g[t]}function b(e){null===T&&O(e,"Get page position: "+(T={x:void 0!==window.pageXOffset?window.pageXOffset:document.documentElement.scrollLeft,y:void 0!==window.pageYOffset?window.pageYOffset:document.documentElement.scrollTop}).x+","+T.y)}function N(e){null!==T&&(window.scrollTo(T.x,T.y),O(e,"Set page position: "+T.x+","+T.y),D())}function D(){T=null}function M(e){O(e.id,"Size reset requested by "+("init"===e.type?"host page":"iFrame")),b(e.id),w(function(){P(e),G("reset","reset",e.iframe,e.id)},e,"reset")}function P(n){function i(e){
//FireFox sets dimension of hidden iFrames to zero.
//So if we detect that set up an event to check for
//when iFrame becomes visible.
/* istanbul ignore next */
//Not testable in PhantomJS
t||"0"!==n[e]||(t=!0,O(r,"Hidden iFrame detected, creating visibility listener"),//Not testable in PhantomJS
/* istanbul ignore next */
function(){function t(){function e(t){function e(e){return"0px"===(g[t]&&g[t].iframe.style[e])}g[t]&&null!==g[t].iframe.offsetParent&&(e("height")||e("width"))&&G("Visibility change","resize",g[t].iframe,t)}for(var t in g)e(t)}function e(e){O("window","Mutation observed: "+e[0].target+" "+e[0].type),x(t,16)}var n,i,r=window.MutationObserver||window.WebKitMutationObserver;r&&(n=document.querySelector("body"),i={attributes:!0,attributeOldValue:!1,characterData:!0,characterDataOldValue:!1,childList:!0,subtree:!0},new r(e).observe(n,i))}())}function e(e){var t;t=e,n.iframe.style[t]=n[t]+"px",O(n.id,"IFrame ("+r+") "+t+" set to "+n[t]+"px"),i(e)}var r=n.iframe.id;g[r]&&(g[r].sizeHeight&&e("height"),g[r].sizeWidth&&e("width"))}function w(e,t,n){
/* istanbul ignore if */
//Not testable in PhantomJS
n!==t.type&&o?(O(t.id,"Requesting animation frame"),o(e)):e()}function G(e,t,n,i,r){var o,a=!1;i=i||n.id,g[i]&&(n&&"contentWindow"in n&&null!==n.contentWindow?(
//Null test for PhantomJS
o=g[i]&&g[i].targetOrigin,O(i,"["+e+"] Sending msg to iframe["+i+"] ("+t+") targetOrigin: "+o),n.contentWindow.postMessage(A+t,o)):v(i,"["+e+"] IFrame("+i+") not found"),r&&g[i]&&g[i].warningTimeout&&(g[i].msgTimeout=setTimeout(function(){!g[i]||g[i].loaded||a||(a=!0,v(i,"IFrame has not responded within "+g[i].warningTimeout/1e3+" seconds. Check iFrameResizer.contentWindow.js has been loaded in iFrame. This message can be ingored if everything is working, or you can set the warningTimeout option to a higher value or zero to suppress this warning."))},g[i].warningTimeout)))}function F(e){return e+":"+g[e].bodyMarginV1+":"+g[e].sizeWidth+":"+g[e].log+":"+g[e].interval+":"+g[e].enablePublicMethods+":"+g[e].autoResize+":"+g[e].bodyMargin+":"+g[e].heightCalculationMethod+":"+g[e].bodyBackground+":"+g[e].bodyPadding+":"+g[e].tolerance+":"+g[e].inPageLinks+":"+g[e].resizeFrom+":"+g[e].widthCalculationMethod}function f(n,e){var t,i,r,o,a,s=(""===(t=n.id)&&(n.id=(i=e&&e.id||u.id+l++,null!==document.getElementById(i)&&(i+=l++),t=i),c=(e||{}).log,O(t,"Added missing iframe ID: "+t+" ("+n.src+")")),t);s in g&&"iFrameResizer"in n?v(s,"Ignored iFrame, already setup."):(o=(o=e)||{},g[s]={firstRun:!0,iframe:n,remoteHost:n.src.split("/").slice(0,3).join("/")},function(e){if("object"!==B(e))throw new TypeError("Options is not an object")}(o),function(e){for(var t in u)u.hasOwnProperty(t)&&(g[s][t]=e.hasOwnProperty(t)?e[t]:u[t])}(o),g[s]&&(g[s].targetOrigin=!0===g[s].checkOrigin?""===(a=g[s].remoteHost)||"file://"===a?"*":a:"*"),function(){switch(O(s,"IFrame scrolling "+(g[s]&&g[s].scrolling?"enabled":"disabled")+" for "+s),n.style.overflow=!1===(g[s]&&g[s].scrolling)?"hidden":"auto",g[s]&&g[s].scrolling){case!0:n.scrolling="yes";break;case!1:n.scrolling="no";break;default:n.scrolling=g[s]?g[s].scrolling:"no"}}//The V1 iFrame script expects an int, where as in V2 expects a CSS
//string value such as '1px 3em', so if we have an int for V2, set V1=V2
//and then convert V2 to a string PX value.
(),function(){function e(e){1/0!==g[s][e]&&0!==g[s][e]&&(n.style[e]=g[s][e]+"px",O(s,"Set "+e+" = "+g[s][e]+"px"))}function t(e){if(g[s]["min"+e]>g[s]["max"+e])throw new Error("Value for min"+e+" can not be greater than max"+e)}t("Height"),t("Width"),e("maxHeight"),e("minHeight"),e("maxWidth"),e("minWidth")}(),"number"!=typeof(g[s]&&g[s].bodyMargin)&&"0"!==(g[s]&&g[s].bodyMargin)||(g[s].bodyMarginV1=g[s].bodyMargin,g[s].bodyMargin=g[s].bodyMargin+"px"),r=F(s),C(n,"load",function(){var e,t;G("iFrame.onload",r,n,void 0,!0),e=g[s]&&g[s].firstRun,t=g[s]&&g[s].heightCalculationMethod in d,!e&&t&&M({iframe:n,height:0,width:0,type:"init"})}),G("init",r,n,void 0,!0),Function.prototype.bind&&g[s]&&(
//Ignore unpolyfilled IE8.
g[s].iframe.iFrameResizer={close:y.bind(null,g[s].iframe),resize:G.bind(null,"Window resize","resize",g[s].iframe),moveToAnchor:function(e){G("Move to anchor","moveToAnchor:"+e,g[s].iframe,s)},sendMessage:function(e){G("Send Message","message:"+(e=JSON.stringify(e)),g[s].iframe,s)}}))}function x(e,t){null===n&&(n=setTimeout(function(){n=null,e()},t))}function _(e){O("window","Trigger event: "+e),x(function(){p("Window "+e,"resize")},16)}//Not testable in PhantomJS
/* istanbul ignore next */function S(){"hidden"!==document.visibilityState&&(O("document","Trigger event: Visiblity change"),x(function(){p("Tab Visable","resize")},16))}function p(e,t){for(var n in g)g[i=n]&&"parent"===g[i].resizeFrom&&g[i].autoResize&&!g[i].firstRun&&G(e,t,document.getElementById(n),n);var i}function E(){function i(e,t){t&&(function(){if(!t.tagName)throw new TypeError("Object is not a valid DOM element");if("IFRAME"!==t.tagName.toUpperCase())throw new TypeError("Expected <IFRAME> tag, found <"+t.tagName+">")}(),f(t,e),r.push(t))}var r;return function(){var e,t=["moz","webkit","o","ms"];// Remove vendor prefixing if prefixed and break early if not
for(e=0;e<t.length&&!o;e+=1)o=window[t[e]+"RequestAnimationFrame"];o||O("setup","RequestAnimationFrame not supported")}(),C(window,"message",s),C(window,"resize",function(){_("resize")}),C(document,"visibilitychange",S),C(document,"-webkit-visibilitychange",S),//Andriod 4.4
C(window,"focusin",function(){_("focus")}),//IE8-9
C(window,"focus",function(){_("focus")}),function(e,t){var n;switch(r=[],(//Only return iFrames past in on this call
n=e)&&n.enablePublicMethods&&v("enablePublicMethods option has been removed, public methods are now always available in the iFrame"),B(t)){case"undefined":case"string":Array.prototype.forEach.call(document.querySelectorAll(t||"iframe"),i.bind(void 0,e));break;case"object":i(e,t);break;default:throw new TypeError("Unexpected data type ("+B(t)+")")}return r}}}},ga={initPym:(ha={pymLib:{},initPym:function(){!function(e){"function"==typeof define&&define.amd?define(e):"undefined"!=typeof module&&module.exports?module.exports=e():window.pym=e.call(this)}(function(){var o="xPYMx",u={},f=function(e){var t=document.createEvent("Event");t.initEvent("pym:"+e,!0,!0),document.dispatchEvent(t)},i=function(e){var t=new RegExp("[\\?&]"+e.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]")+"=([^&#]*)").exec(location.search);return null===t?"":decodeURIComponent(t[1].replace(/\+/g," "))},a=function(e,t){if(("*"===t.xdomain||e.origin.match(new RegExp(t.xdomain+"$")))&&"string"==typeof e.data)return!0;// Ignore events that do not carry string data #151
},s=function(e,t,n){return["pym",e,t,n].join(o)},_=Date.now||function(){return(new Date).getTime()},S=function(){// Loop backwards to avoid index issues
for(var e=u.autoInitInstances.length-1;0<=e;e--){var t=u.autoInitInstances[e];// If instance has been removed or is contentless then remove it
t.el.getElementsByTagName("iframe").length&&t.el.getElementsByTagName("iframe")[0].contentWindow||
// Remove the reference to the removed or orphan instance
u.autoInitInstances.splice(e,1)}};
/**
           * Store auto initialized Pym instances for further reference
           * @name module:pym#autoInitInstances
           * @type Array
           * @default []
           */
u.autoInitInstances=[],
/**
           * Initialize Pym for elements on page that have data-pym attributes.
           * Expose autoinit in case we need to call it } from the outside
           * @instance
           * @method autoInit
           * @param {Boolean} doNotRaiseEvents flag to avoid sending custom events
           */
u.autoInit=function(e){var t=document.querySelectorAll("[data-pym-src]:not([data-pym-auto-initialized])"),n=t.length;// Clean stored instances in case needed
S();for(var i=0;i<n;++i){var r=t[i];
/*
               * Mark automatically-initialized elements so they are not
               * re-initialized if the user includes pym.js more than once in the
               * same document.
               */r.setAttribute("data-pym-auto-initialized",""),// Ensure elements have an id
""===r.id&&(r.id="pym-"+i+"-"+Math.random().toString(36).substr(2,5));var o=r.getAttribute("data-pym-src"),a={xdomain:"string",title:"string",name:"string",id:"string",sandbox:"string",allowfullscreen:"boolean",parenturlparam:"string",parenturlvalue:"string",optionalparams:"boolean",trackscroll:"boolean",scrollwait:"number"},s={};// List of data attributes to configure the component
// structure: {'attribute name': 'type'}
for(var l in a)
// via https://developer.mozilla.org/en-US/docs/Web/API/Element/getAttribute#Notes
if(null!==r.getAttribute("data-pym-"+l))switch(a[l]){case"boolean":s[l]=!("false"===r.getAttribute("data-pym-"+l));// jshint ignore:line
break;case"string":s[l]=r.getAttribute("data-pym-"+l);break;case"number":var c=Number(r.getAttribute("data-pym-"+l));isNaN(c)||(s[l]=c);break;default:console.err("unrecognized attribute type")}// Store references to autoinitialized pym instances
var d=new u.Parent(r.id,o,s);u.autoInitInstances.push(d)}// Fire customEvent
// Return stored autoinitalized pym instances
return e||f("pym-initialized"),u.autoInitInstances},
/**
           * The Parent half of a response iframe.
           *
           * @memberof module:pym
           * @class Parent
           * @param {String} id The id of the div into which the iframe will be rendered. sets {@link module:pym.Parent~id}
           * @param {String} url The url of the iframe source. sets {@link module:pym.Parent~url}
           * @param {Object} [config] Configuration for the parent instance. sets {@link module:pym.Parent~settings}
           * @param {string} [config.xdomain='*'] - xdomain to validate messages received
           * @param {string} [config.title] - if passed it will be assigned to the iframe title attribute
           * @param {string} [config.name] - if passed it will be assigned to the iframe name attribute
           * @param {string} [config.id] - if passed it will be assigned to the iframe id attribute
           * @param {boolean} [config.allowfullscreen] - if passed and different than false it will be assigned to the iframe allowfullscreen attribute
           * @param {string} [config.sandbox] - if passed it will be assigned to the iframe sandbox attribute (we do not validate the syntax so be careful!!)
           * @param {string} [config.parenturlparam] - if passed it will be override the default parentUrl query string parameter name passed to the iframe src
           * @param {string} [config.parenturlvalue] - if passed it will be override the default parentUrl query string parameter value passed to the iframe src
           * @param {string} [config.optionalparams] - if passed and different than false it will strip the querystring params parentUrl and parentTitle passed to the iframe src
           * @param {boolean} [config.trackscroll] - if passed it will activate scroll tracking on the parent
           * @param {number} [config.scrollwait] - if passed it will set the throttle wait in order to fire scroll messaging. Defaults to 100 ms.
           * @see {@link https://developer.mozilla.org/en-US/docs/Web/HTML/Element/iframe iFrame}
           */
u.Parent=function(e,t,n){var i;// Add any overrides to settings coming } from config.
for(var r in
/**
             * The id of the container element
             *
             * @memberof module:pym.Parent
             * @member {string} id
             * @inner
             */
this.id=e,
/**
             * The url that will be set as the iframe's src
             *
             * @memberof module:pym.Parent
             * @member {String} url
             * @inner
             */
this.url=t,
/**
             * The container DOM object
             *
             * @memberof module:pym.Parent
             * @member {HTMLElement} el
             * @inner
             */
this.el=document.getElementById(e),
/**
             * The contained child iframe
             *
             * @memberof module:pym.Parent
             * @member {HTMLElement} iframe
             * @inner
             * @default null
             */
this.iframe=null,
/**
             * The parent instance settings, updated by the values passed in the config object
             *
             * @memberof module:pym.Parent
             * @member {Object} settings
             * @inner
             */
this.settings={xdomain:"*",optionalparams:!0,parenturlparam:"parentUrl",parenturlvalue:window.location.href,trackscroll:!1,scrollwait:100},
/**
             * RegularExpression to validate the received messages
             *
             * @memberof module:pym.Parent
             * @member {String} messageRegex
             * @inner
             */
this.messageRegex=(i=this.id,new RegExp("^"+["pym",i,"(\\S+)","(.*)"].join(o)+"$")),
/**
             * Stores the registered messageHandlers for each messageType
             *
             * @memberof module:pym.Parent
             * @member {Object} messageHandlers
             * @inner
             */
this.messageHandlers={},// ensure a config object
n=n||{},
/**
             * Construct the iframe.
             *
             * @memberof module:pym.Parent
             * @method _constructIframe
             * @inner
             */
this._constructIframe=function(){
// Calculate the width of this element.
var e=this.el.offsetWidth.toString();// Create an iframe element attached to the document.
this.iframe=document.createElement("iframe");// Save fragment id
var t="",n=this.url.indexOf("#");// Replace the child content if needed
// (some CMSs might strip out empty elements)
for(-1<n&&(t=this.url.substring(n,this.url.length),this.url=this.url.substring(0,n)),// If the URL contains querystring bits, use them.
// Otherwise, just create a set of valid params.
this.url.indexOf("?")<0?this.url+="?":this.url+="&",// Append the initial width as a querystring parameter
// and optional params if configured to do so
this.iframe.src=this.url+"initialWidth="+e+"&childId="+this.id,this.settings.optionalparams&&(
// Removed parent title option because of server configuration issue with
// vertical pipe used in page title for SIT and UAT domains, -JGS 11/17
// this.iframe.src += '&parentTitle=' + encodeURIComponent(document.title);
this.iframe.src+="&"+this.settings.parenturlparam+"="+encodeURIComponent(this.settings.parenturlvalue)),this.iframe.src+=t,// Set some attributes to this proto-iframe.
this.iframe.setAttribute("width","100%"),this.iframe.setAttribute("scrolling","no"),this.iframe.setAttribute("marginheight","0"),this.iframe.setAttribute("frameborder","0"),this.settings.title&&this.iframe.setAttribute("title",this.settings.title),void 0!==this.settings.allowfullscreen&&!1!==this.settings.allowfullscreen&&this.iframe.setAttribute("allowfullscreen",""),void 0!==this.settings.sandbox&&"string"==typeof this.settings.sandbox&&this.iframe.setAttribute("sandbox",this.settings.sandbox),this.settings.id&&(document.getElementById(this.settings.id)||this.iframe.setAttribute("id",this.settings.id)),this.settings.name&&this.iframe.setAttribute("name",this.settings.name);this.el.firstChild;)this.el.removeChild(this.el.firstChild);// Append the iframe to our element.
this.el.appendChild(this.iframe),// Add an event listener that will handle redrawing the child on resize.
window.addEventListener("resize",this._onResize),// Add an event listener that will send the child the viewport.
this.settings.trackscroll&&window.addEventListener("scroll",this._throttleOnScroll)},
/**
             * Send width on resize.
             *
             * @memberof module:pym.Parent
             * @method _onResize
             * @inner
             */
this._onResize=function(){this.sendWidth(),this.settings.trackscroll&&this.sendViewportAndIFramePosition()}.bind(this),
/**
             * Send viewport and iframe info on scroll.
             *
             * @memberof module:pym.Parent
             * @method _onScroll
             * @inner
             */
this._onScroll=function(){this.sendViewportAndIFramePosition()}.bind(this),
/**
             * Fire all event handlers for a given message type.
             *
             * @memberof module:pym.Parent
             * @method _fire
             * @inner
             *
             * @param {String} messageType The type of message.
             * @param {String} message The message data.
             */
this._fire=function(e,t){if(e in this.messageHandlers)for(var n=0;n<this.messageHandlers[e].length;n++)this.messageHandlers[e][n].call(this,t)},
/**
             * Remove this parent } from the page and unbind it's event handlers.
             *
             * @memberof module:pym.Parent
             * @method remove
             * @instance
             */
this.remove=function(){window.removeEventListener("message",this._processMessage),window.removeEventListener("resize",this._onResize),this.el.removeChild(this.iframe),// _cleanAutoInitInstances in case this parent was autoInitialized
S()},
/**
             * Process a new message } from the child.
             *
             * @memberof module:pym.Parent
             * @method _processMessage
             * @inner
             *
             * @param {Event} e A message event.
             */
this._processMessage=function(e){
// First, punt if this isn't } from an acceptable xdomain.
if(a(e,this.settings)&&"string"==typeof e.data)// Discard object messages, we only care about strings
{// Grab the message } from the child and parse it.
var t=e.data.match(this.messageRegex);// If there's no match or too many matches in the message, punt.
if(!t||3!==t.length)return!1;var n=t[1],i=t[2];this._fire(n,i)}}.bind(this),
/**
             * Resize iframe in response to new height message } from child.
             *
             * @memberof module:pym.Parent
             * @method _onHeightMessage
             * @inner
             *
             * @param {String} message The new height.
             */
this._onHeightMessage=function(e){
/*
               * Handle parent height message } from child.
               */
var t=parseInt(e);this.iframe.setAttribute("height",t+"px")},
/**
             * Navigate parent to a new url.
             *
             * @memberof module:pym.Parent
             * @method _onNavigateToMessage
             * @inner
             *
             * @param {String} message The url to navigate to.
             */
this._onNavigateToMessage=function(e){
/*
               * Handle parent scroll message } from child.
               */
(function(e){if(e.match(/^(?:(?:https?|mailto|ftp):|[^&:/?#]*(?:[/?#]|$))/gi))return!0})(e)&&(document.location.href=e)},
/**
             * Scroll parent to a given child position.
             *
             * @memberof module:pym.Parent
             * @method _onScrollToChildPosMessage
             * @inner
             *
             * @param {String} message The offset inside the child page.
             */
this._onScrollToChildPosMessage=function(e){
// Get the child container position using getBoundingClientRect + pageYOffset
// via https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect
var t=document.getElementById(this.id).getBoundingClientRect().top+window.pageYOffset+parseInt(e);window.scrollTo(0,t)},
/**
             * Bind a callback to a given messageType } from the child.
             *
             * Reserved message names are: "height", "scrollTo" and "navigateTo".
             *
             * @memberof module:pym.Parent
             * @method onMessage
             * @instance
             *
             * @param {String} messageType The type of message being listened for.
             * @param {module:pym.Parent~onMessageCallback} callback The callback to invoke when a message of the given type is received.
             */
this.onMessage=function(e,t){e in this.messageHandlers||(this.messageHandlers[e]=[]),this.messageHandlers[e].push(t)},
/**
             * @callback module:pym.Parent~onMessageCallback
             * @param {String} message The message data.
             */
/**
             * Send a message to the the child.
             *
             * @memberof module:pym.Parent
             * @method sendMessage
             * @instance
             *
             * @param {String} messageType The type of message to send.
             * @param {String} message The message data to send.
             */
this.sendMessage=function(e,t){
// When used alongside with pjax some references are lost
this.el.getElementsByTagName("iframe").length&&(this.el.getElementsByTagName("iframe")[0].contentWindow?this.el.getElementsByTagName("iframe")[0].contentWindow.postMessage(s(this.id,e,t),"*"):
// Contentless child detected remove listeners and iframe
this.remove())},
/**
             * Transmit the current iframe width to the child.
             *
             * You shouldn't need to call this directly.
             *
             * @memberof module:pym.Parent
             * @method sendWidth
             * @instance
             */
this.sendWidth=function(){var e=this.el.offsetWidth.toString();this.sendMessage("width",e)},
/**
             * Transmit the current viewport and iframe position to the child.
             * Sends viewport width, viewport height
             * and iframe bounding rect top-left-bottom-right
             * all separated by spaces
             *
             * You shouldn't need to call this directly.
             *
             * @memberof module:pym.Parent
             * @method sendViewportAndIFramePosition
             * @instance
             */
this.sendViewportAndIFramePosition=function(){var e=this.iframe.getBoundingClientRect(),t=(window.innerWidth||document.documentElement.clientWidth)+" "+(window.innerHeight||document.documentElement.clientHeight);t+=" "+e.top+" "+e.left,t+=" "+e.bottom+" "+e.right,this.sendMessage("viewport-iframe-position",t)},n)this.settings[r]=n[r];
/**
             * Throttled scroll function.
             *
             * @memberof module:pym.Parent
             * @method _throttleOnScroll
             * @inner
             */return this._throttleOnScroll=function(n,i,r){var o,a,s,l=null,c=0;r||(r={});var d=function(){c=!1===r.leading?0:_(),l=null,s=n.apply(o,a),l||(o=a=null)};return function(){var e=_();c||!1!==r.leading||(c=e);var t=i-(e-c);return o=this,a=arguments,t<=0||i<t?(l&&(clearTimeout(l),l=null),c=e,s=n.apply(o,a),l||(o=a=null)):l||!1===r.trailing||(l=setTimeout(d,t)),s}}(this._onScroll.bind(this),this.settings.scrollwait),// Bind required message handlers
this.onMessage("height",this._onHeightMessage),this.onMessage("navigateTo",this._onNavigateToMessage),this.onMessage("scrollToChildPos",this._onScrollToChildPosMessage),this.onMessage("parentPositionInfo",this.sendViewportAndIFramePosition),// Add a listener for processing messages } from the child.
window.addEventListener("message",this._processMessage,!1),// Construct the iframe in the container element.
this._constructIframe(),this},
/**
           * The Child half of a responsive iframe.
           *
           * @memberof module:pym
           * @class Child
           * @param {Object} [config] Configuration for the child instance. sets {@link module:pym.Child~settings}
           * @param {function} [config.renderCallback=null] Callback invoked after receiving a resize event } from the parent, sets {@link module:pym.Child#settings.renderCallback}
           * @param {string} [config.xdomain='*'] - xdomain to validate messages received
           * @param {number} [config.polling=0] - polling frequency in milliseconds to send height to parent
           * @param {number} [config.id] - parent container id used when navigating the child iframe to a new page but we want to keep it responsive.
           * @param {string} [config.parenturlparam] - if passed it will be override the default parentUrl query string parameter name expected on the iframe src
           */
u.Child=function(e){
/**
             * The initial width of the parent page
             *
             * @memberof module:pym.Child
             * @member {string} parentWidth
             * @inner
             */
this.parentWidth=null,
/**
             * The id of the parent container
             *
             * @memberof module:pym.Child
             * @member {String} id
             * @inner
             */
this.id=null,
/**
             * The title of the parent page } from document.title.
             *
             * @memberof module:pym.Child
             * @member {String} parentTitle
             * @inner
             */
this.parentTitle=null,
/**
             * The URL of the parent page } from window.location.href.
             *
             * @memberof module:pym.Child
             * @member {String} parentUrl
             * @inner
             */
this.parentUrl=null,
/**
             * The settings for the child instance. Can be overriden by passing a config object to the child constructor
             * i.e.: var pymChild = new pym.Child({renderCallback: render, xdomain: "\\*\.npr\.org"})
             *
             * @memberof module:pym.Child.settings
             * @member {Object} settings - default settings for the child instance
             * @inner
             */
this.settings={renderCallback:null,xdomain:"*",polling:0,parenturlparam:"parentUrl"},
/**
             * The timerId in order to be able to stop when polling is enabled
             *
             * @memberof module:pym.Child
             * @member {String} timerId
             * @inner
             */
this.timerId=null,
/**
             * RegularExpression to validate the received messages
             *
             * @memberof module:pym.Child
             * @member {String} messageRegex
             * @inner
             */
this.messageRegex=null,
/**
             * Stores the registered messageHandlers for each messageType
             *
             * @memberof module:pym.Child
             * @member {Object} messageHandlers
             * @inner
             */
this.messageHandlers={},// Ensure a config object
e=e||{},
/**
             * Bind a callback to a given messageType } from the child.
             *
             * Reserved message names are: "width".
             *
             * @memberof module:pym.Child
             * @method onMessage
             * @instance
             *
             * @param {String} messageType The type of message being listened for.
             * @param {module:pym.Child~onMessageCallback} callback The callback to invoke when a message of the given type is received.
             */
this.onMessage=function(e,t){e in this.messageHandlers||(this.messageHandlers[e]=[]),this.messageHandlers[e].push(t)},
/**
             * @callback module:pym.Child~onMessageCallback
             * @param {String} message The message data.
             */
/**
             * Fire all event handlers for a given message type.
             *
             * @memberof module:pym.Child
             * @method _fire
             * @inner
             *
             * @param {String} messageType The type of message.
             * @param {String} message The message data.
             */
this._fire=function(e,t){
/*
               * Fire all event handlers for a given message type.
               */
if(e in this.messageHandlers)for(var n=0;n<this.messageHandlers[e].length;n++)this.messageHandlers[e][n].call(this,t)},
/**
             * Process a new message } from the parent.
             *
             * @memberof module:pym.Child
             * @method _processMessage
             * @inner
             *
             * @param {Event} e A message event.
             */
this._processMessage=function(e){
/*
               * Process a new message } from parent frame.
               */
// First, punt if this isn't } from an acceptable xdomain.
if(a(e,this.settings)&&"string"==typeof e.data)// Discard object messages, we only care about strings
{// Get the message } from the parent.
var t=e.data.match(this.messageRegex);// If there's no match or it's a bad format, punt.
if(t&&3===t.length){var n=t[1],i=t[2];this._fire(n,i)}}}.bind(this),
/**
             * Resize iframe in response to new width message } from parent.
             *
             * @memberof module:pym.Child
             * @method _onWidthMessage
             * @inner
             *
             * @param {String} message The new width.
             */
this._onWidthMessage=function(e){
/*
               * Handle width message } from the child.
               */
var t=parseInt(e);// Change the width if it's different.
t!==this.parentWidth&&(this.parentWidth=t,// Call the callback function if it exists.
this.settings.renderCallback&&this.settings.renderCallback(t),// Send the height back to the parent.
this.sendHeight())},
/**
             * Send a message to the the Parent.
             *
             * @memberof module:pym.Child
             * @method sendMessage
             * @instance
             *
             * @param {String} messageType The type of message to send.
             * @param {String} message The message data to send.
             */
this.sendMessage=function(e,t){
/*
               * Send a message to the parent.
               */
window.parent.postMessage(s(this.id,e,t),"*")},
/**
             * Transmit the current iframe height to the parent.
             *
             * Call this directly in cases where you manually alter the height of the iframe contents.
             *
             * @memberof module:pym.Child
             * @method sendHeight
             * @instance
             */
this.sendHeight=function(){
// Get the child's height.
var e=document.getElementsByTagName("body")[0].offsetHeight.toString();// Send the height to the parent.
return this.sendMessage("height",e),e}.bind(this),
/**
             * Ask parent to send the current viewport and iframe position information
             *
             * @memberof module:pym.Child
             * @method sendHeight
             * @instance
             */
this.getParentPositionInfo=function(){
// Send the height to the parent.
this.sendMessage("parentPositionInfo")},
/**
             * Scroll parent to a given element id.
             *
             * @memberof module:pym.Child
             * @method scrollParentTo
             * @instance
             *
             * @param {String} hash The id of the element to scroll to.
             */
this.scrollParentTo=function(e){this.sendMessage("navigateTo","#"+e)},
/**
             * Navigate parent to a given url.
             *
             * @memberof module:pym.Child
             * @method navigateParentTo
             * @instance
             *
             * @param {String} url The url to navigate to.
             */
this.navigateParentTo=function(e){this.sendMessage("navigateTo",e)},
/**
             * Scroll parent to a given child element id.
             *
             * @memberof module:pym.Child
             * @method scrollParentToChildEl
             * @instance
             *
             * @param {String} id The id of the child element to scroll to.
             */
this.scrollParentToChildEl=function(e){
// Get the child element position using getBoundingClientRect + pageYOffset
// via https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect
var t=document.getElementById(e).getBoundingClientRect().top+window.pageYOffset;this.scrollParentToChildPos(t)},
/**
             * Scroll parent to a particular child offset.
             *
             * @memberof module:pym.Child
             * @method scrollParentToChildPos
             * @instance
             *
             * @param {Number} pos The offset of the child element to scroll to.
             */
this.scrollParentToChildPos=function(e){this.sendMessage("scrollToChildPos",e.toString())};// Initialize settings with overrides.
for(var t in
/**
             * @callback module:pym.Child~onMarkedEmbeddedStatus
             * @param {String} classname "embedded" or "not-embedded".
             */
/**
             * Unbind child event handlers and timers.
             *
             * @memberof module:pym.Child
             * @method remove
             * @instance
             */
this.remove=function(){window.removeEventListener("message",this._processMessage),this.timerId&&clearInterval(this.timerId)},e)this.settings[t]=e[t];// Identify what ID the parent knows this child as.
this.id=i("childId")||e.id,this.messageRegex=new RegExp("^pym"+o+this.id+o+"(\\S+)"+o+"(.*)$");// Get the initial width } from a URL parameter.
var n=parseInt(i("initialWidth"));// Get the url of the parent frame
return this.parentUrl=i(this.settings.parenturlparam),// Get the title of the parent frame
this.parentTitle=i("parentTitle"),// Bind the required message handlers
this.onMessage("width",this._onWidthMessage),// Set up a listener to handle any incoming messages.
window.addEventListener("message",this._processMessage,!1),// If there's a callback function, call it.
this.settings.renderCallback&&this.settings.renderCallback(n),// Send the initial height to the parent.
this.sendHeight(),// If we're configured to poll, create a setInterval to handle that.
this.settings.polling&&(this.timerId=window.setInterval(this.sendHeight,this.settings.polling)),function(e){var t,n=document.getElementsByTagName("html")[0],i=n.className;try{t=window.self!==window.top?"embedded":"not-embedded"}catch(e){t="embedded"}i.indexOf(t)<0&&(n.className=i?i+" "+t:t,e&&e(t),f("marked-embedded"))}(e.onMarkedEmbeddedStatus),this},// Initialize elements with pym data attributes
// if we are not in server configuration
"undefined"!=typeof document&&u.autoInit(!0),// return lib;
ha.pymLib=u})},getPymLib:function(){return ha.pymLib}}).initPym,getPymLib:ha.getPymLib},Ca={initLeadFusion:function(){window.lf_onMessage=function(e){try{if("string"==typeof e.data&&"{"===e.data.charAt(0))var t=JSON.parse(e.data.replace(new RegExp('}"',"g"),"}").replace(new RegExp('"{',"g"),"{").trim());if(!e||!t||"resetTimer"!==t.action&&"scrollTop"!==t.action&&"resize"!==t.action&&void 0===t.action)return;if("resize"===t.action)document.getElementById("lf_tool_frame_"+t.iframeID).height=t.height;else if("scrollTop"===t.action)var n=setInterval(function(){clearInterval(n),document.body.scrollTo(0,0)},500)}catch(e){window.lf_consoleErrors[t.iframeID]||(console.error("LeadFusion error for iframe with id ".concat(t.iframeID,": ").concat(e)),window.lf_consoleErrors[t.iframeID]="displayed")}},// keep track of which iframes have displayed an error
// only display the error once per iframe
window.lf_consoleErrors={},window.attachEvent?
//IE9, capability based.
window.attachEvent("onmessage",window.lf_onMessage):window.addEventListener&&
//Others, capability based.
window.addEventListener("message",window.lf_onMessage,!1)}},La={init:(Aa={CLASSES:{IFRAME_WRAPPER:".js-responsive-iframe-wrapper",IFRAME_OUTER_CONTAINER:".responsive-iframe-outer-container",SPINNER_CONTAINER:".js-responsive-iframe-spinner",IFRAME_CONTAINER:".js-responsive-iframe",IFRAME_RESIZER_CONTAINER:".js-responsive-iframe--resizer",PYM_CONTAINER:".js-responsive-iframe--pym",LEADFUSION_CONTAINER:".js-responsive-iframe--leadfusion"},CLASSES_NO_DOT:{LEADFUSION_IFRAME_CLASS_NO_DOT:"js-iframe--leadfusion",DISPLAY_NONE:"display-none",IS_LOADED:"is-loaded"},SELECTORS:{IFRAME_INTRO_HEADING:".responsive-iframe__intro .text-block__title"},ATTRIBUTES:{DATA_URL:"data-url",DATA_URL_PARAMETERS:"data-url-parameters"},TIMEOUTS:{FADE_FAST:"fast",FADE_SLOW:"slow",FADE_IFRAME:300},IFRAME_TYPE:{IFRAME_RESIZER:"iframeResizer",PYM:"pym",LEADFUSION:"leadfusion"},configurableTimeouts:{iframeResizerDelay:1e3,pymDelay:1e3,leadFusionDelay:1e3},LEADFUSION_ID_PREFIX:"lf_tool_frame_",pymLib:{},setUpResizers:function(){S(Aa.CLASSES.IFRAME_RESIZER_CONTAINER).length&&(
// init Iframe Resizer
Ta.initIframeResizer(),// set up iframe resizer on each iframe
S(Aa.CLASSES.IFRAME_RESIZER_CONTAINER).each(function(e,t){Aa.setUpIframeResizerOnIframe(t)})),S(Aa.CLASSES.PYM_CONTAINER).length&&(
// init Pym
ga.initPym(),Aa.pymLib=ga.getPymLib(),// set up pym on each iframe
S(Aa.CLASSES.PYM_CONTAINER).each(function(e,t){Aa.setUpPymOnIframe(t)})),S(Aa.CLASSES.LEADFUSION_CONTAINER)&&(
// change the id of each LeadFusion iframe because they
// require a specific naming scheme
S(Aa.CLASSES.LEADFUSION_CONTAINER).each(function(e,t){Aa.setUpLeadFusionOnIframe(e,t)}),// init LeadFusion
Ca.initLeadFusion())},setUpIframeResizerOnIframe:function(e){Aa.iframeLoading(e,Aa.configurableTimeouts.iframeResizerDelay),S(e).find("iframe").iFrameResize({checkOrigin:!1,heightCalculationMethod:"taggedElement"})},setUpPymOnIframe:function(e){var t=S(e),n=t.attr("id"),i=t.attr(Aa.ATTRIBUTES.DATA_URL);if(i){new Aa.pymLib.Parent(n,i);Aa.iframeLoading(e,Aa.configurableTimeouts.pymDelay)}else n?console.error("No url has been specified for the pym iframe with id ".concat(n)):console.error("No id has been specified for the pym iframe container")},setUpLeadFusionOnIframe:function(e,t){Aa.iframeLoading(t,Aa.configurableTimeouts.leadFusionDelay);// To support multiple LeadFusion iframes on the same page
// Assign each iframe an id using the following format:
// id=”lf_tool_frame_[toolId]”
// where [toolId] is the final part of the tool URL
var n=S(S(t).find("iframe")),i=n.attr("src").split("/").pop();i?n.attr("id","".concat(Aa.LEADFUSION_ID_PREFIX).concat(i)):console.error("The LeadFusion iframe with src ".concat(iframe.src," does not have a valid tool id."))},iframeLoading:function(e,t){var n=S(e).find("iframe").first(),i=Aa.getSpinner(e),r=S(e).closest(Aa.CLASSES.IFRAME_WRAPPER).find(Aa.SELECTORS.IFRAME_INTRO_HEADING).text();i.attr("aria-label","loading content for ".concat(r)),
/* eslint-disable object-shorthand */
n.on("load",{iframeContainer:e,delay:t},Aa.iframeLoaded)},iframeLoaded:function(e){var t=S(e.data.iframeContainer).find("iframe").first(),n=Aa.getSpinner(e.data.iframeContainer),i=t.parent().hasClass(Aa.CLASSES.PYM_CONTAINER.slice(1)),r=t.closest(Aa.CLASSES.IFRAME_WRAPPER).find(Aa.SELECTORS.IFRAME_INTRO_HEADING);t.addClass(Aa.CLASSES_NO_DOT.IS_LOADED),// sets a title attribute on the pym iframe
i&&r.length&&t.attr("title",r.text().trim()),// removes width attribute } from iframe since we need to
// control it by CSS for iOS fix
t.removeAttr("width"),setTimeout(function(){n.fadeOut(Aa.TIMEOUTS.FADE_FAST),setTimeout(function(){t.fadeIn(Aa.TIMEOUTS.FADE_SLOW)},Aa.TIMEOUTS.FADE_IFRAME)},e.data.delay)},getSpinner:function(e){
// as a fallback, search for the spinner after the iframe instead of before the iframe
var t=S(e).prev(Aa.CLASSES.SPINNER_CONTAINER).first();return t.length||(t=S(e).find(Aa.CLASSES.SPINNER_CONTAINER).first()),t},setDelays:function(e,t,n){Aa.configurableTimeouts.iframeResizerDelay=e,Aa.configurableTimeouts.pymDelay=t,Aa.configurableTimeouts.leadFusionDelay=n},init:function(){Aa.setUpResizers()}}).init,setDelays:Aa.setDelays},Oa={init:(ma={targetId:null,
// holds the Isotope objects for each tab list; key is tab list id; value is the Isotope object
tabLists:{},isSetUpForAnimation:!1,
// this class needs to be present on the tab list to make the tabs animate
ANIMATE_TABS_CLASS_NO_DOT:"js-animate-tabs",TAB_URL_PARAMETER:"tab",TAB_WRAPPER_CLASS:".js-lx-tabs",TAB_LIST_CLASS:".js-lx-tabs__list",TAB_CLASS:".js-lx-tabs__tab",TAB_PANEL:".js-lx-tabs__panel",
// TAB_TRIGGER_WRAPPER_CLASS_NO_DOT: 'tabs__trigger-wrap',
DATA_TAB_TARGET:"data-tabtarget",DATA_TAB_TRIGGER:"data-tabtrigger",LISTENING_FOR_CLICK_CLASS_NO_DOT:"is-listening-for-click",ACTIVE_CLASS_NO_DOT:"is-active",ANIMATED_CLASS_NO_DOT:"is-animated",ISOTOPE_DELAY:250,MOBILE_SORT_BY:"displayOrder",DESKTOP_SORT_BY:"original-order",MOBILE_LAYOUT:"vertical",DESKTOP_LAYOUT:"fitRows",DATA_DISPLAY_ORDER:"data-display-order",DATA_ORIGINAL_ORDER:"data-original-order",MOBILE_CLASS_NO_DOT:"sm-screen",DESKTOP_CLASS_NO_DOT:"lg-screen",MOBILE_THRESHOLD:992,cacheDom:function(){ma.$tabs=S(ma.TAB_WRAPPER_CLASS),ma.$tab=S(ma.TAB_CLASS),ma.$panel=S(ma.TAB_PANEL)},bindEvents:function(){ma.$tab.on("click",function(e){e.preventDefault(),ma.storeThisTarget(S(e.target)),ma.activateTab(ma.targetId)}),ma.$tab.addClass(ma.LISTENING_FOR_CLICK_CLASS_NO_DOT),// Detecting right and left arrow key
ma.$tab.on("keyup",function(e){39===e.keyCode?(ma.storeNextTarget(S(e.target)),ma.activateTab(ma.targetId)):37===e.keyCode&&(ma.storePrevTarget(S(e.target)),ma.activateTab(ma.targetId))}),S(window).on("resize",function(){
// mobile
S(window).width()<ma.MOBILE_THRESHOLD?ma.isSetUpForAnimation?
// _private.updateTabLayoutWraps();
S.each(S(ma.TAB_LIST_CLASS),function(e,t){var n=S(t).find(".is-active").attr("id");""!==t.id&&ma.animateTabs(t.id,n)}):ma.setUpTabAnimation():ma.isSetUpForAnimation&&(
// _private.updateTabLayoutWraps();
S.each(S(ma.TAB_LIST_CLASS),function(e,t){S(t).hasClass(ma.ANIMATE_TABS_CLASS_NO_DOT)&&""!==t.id&&(S(t).removeClass(ma.ANIMATED_CLASS_NO_DOT),ma.tabLists[t.id].destroy())}),ma.isSetUpForAnimation=!1)})},storeThisTarget:function(e){var t=e.attr(ma.DATA_TAB_TARGET);ma.targetId=t},storeNextTarget:function(e){var t;// checks to see if each tab is wrapped in a div that allows for additional visual formatting
// If the targetId is undefined, that means the user is at the end of the tab list
void 0===(t=e.parent().hasClass(ma.TAB_TRIGGER_WRAPPER_CLASS_NO_DOT)?e.parent().next().find(ma.TAB_CLASS).attr(ma.DATA_TAB_TARGET):e.next().attr(ma.DATA_TAB_TARGET))&&(t=e.closest(ma.$tabs).find(ma.TAB_CLASS+":first").attr(ma.DATA_TAB_TARGET));ma.targetId=t},storePrevTarget:function(e){var t;// checks to see if each tab is wrapped in a div that allows for additional visual formatting
// If the targetId is undefined, that means the user is at the beginning of the tab list
void 0===(t=e.parent().hasClass(ma.TAB_TRIGGER_WRAPPER_CLASS_NO_DOT)?e.parent().prev().find(ma.TAB_CLASS).attr(ma.DATA_TAB_TARGET):e.prev().attr(ma.DATA_TAB_TARGET))&&(t=e.closest(ma.$tabs).find(ma.TAB_CLASS+":last").attr(ma.DATA_TAB_TARGET));ma.targetId=t},activateTab:function(e){var t,n=S(e),i=n.siblings(ma.$panel),r=n.attr(ma.DATA_TAB_TRIGGER),o=S(r),a=(S(r).closest(ma.TAB_LIST_CLASS),o.closest(ma.TAB_LIST_CLASS).attr("id")),s=S("#"+a).hasClass(ma.ANIMATE_TABS_CLASS_NO_DOT);(// it is necessary to determine sibiling tabs by finding all tabs in a tablist and then removing the current one in case each tab is wrapped in a div that allows for additional visual formatting
t=o.closest(ma.TAB_LIST_CLASS).find(ma.TAB_CLASS)).remove(o),s&&ma.animateTabs(a,o.attr("id")),// De-activate all other tabs
t.removeClass(ma.ACTIVE_CLASS_NO_DOT).attr("aria-selected","false").attr("tabindex","-1"),// Activate the associated trigger tab
o.addClass(ma.ACTIVE_CLASS_NO_DOT).attr("aria-selected","true").attr("tabindex","0").focus(),// De-activate all other panels
i.removeClass(ma.ACTIVE_CLASS_NO_DOT).attr("aria-hidden","true"),// Activate the associated target panel
n.addClass(ma.ACTIVE_CLASS_NO_DOT).attr("aria-hidden","false")},animateTabs:function(t,n){if(ma.isSetUpForAnimation)
// wait until the tab list is ready to be animated
if(S("#"+t).hasClass(ma.ANIMATED_CLASS_NO_DOT))ma.animateTabsHelper(t,n);else{var i=new MutationObserver(function(e){S("#"+t).hasClass(ma.ANIMATED_CLASS_NO_DOT)&&(ma.animateTabsHelper(t,n),i.disconnect())});// create an observer instance linked to the callback function
// start observing the target node for configured mutations
i.observe(S("#"+t)[0],{attributes:!0})}},animateTabsHelper:function(e,t){var n,i=S("#"+e).find(ma.TAB_CLASS),r=S("body").hasClass(ma.MOBILE_CLASS_NO_DOT),o=ma.tabLists[e].sortHistory[0];// targetTabId is optional and is only provided when a tab has been selected
t&&(n=S("#"+t)),// update the display order when a tab has been selected
n&&(
// reset all tabs to their original order
S.each(i,function(e,t){S(t).attr(ma.DATA_DISPLAY_ORDER,S(t).attr(ma.DATA_ORIGINAL_ORDER))}),// set the display order of the target tab to be one greater than the number of tabs, so that it has the highest display order
n.attr(ma.DATA_DISPLAY_ORDER,i.length+1)),// arrange the tabs based on the cases shown below
r&&n?(
// tab selection at mobile
ma.tabLists[e].updateSortData(),ma.tabLists[e].arrange({sortBy:ma.MOBILE_SORT_BY,layoutMode:ma.MOBILE_LAYOUT})):r&&o!==ma.MOBILE_SORT_BY?setTimeout(function(){
// resizing } from desktop to mobile
ma.tabLists[e].updateSortData(),ma.tabLists[e].arrange({sortBy:ma.MOBILE_SORT_BY,layoutMode:ma.MOBILE_LAYOUT})},ma.ISOTOPE_DELAY):r||o===ma.DESKTOP_SORT_BY||setTimeout(function(){
// resizing mobile to desktop
ma.tabLists[e].updateSortData(),ma.tabLists[e].arrange({sortBy:ma.DESKTOP_SORT_BY,layoutMode:ma.DESKTOP_LAYOUT})},ma.ISOTOPE_DELAY)},setUpTabAnimation:function(){var t=S("body").hasClass(ma.MOBILE_CLASS_NO_DOT),n=S("body").hasClass(ma.DESKTOP_CLASS_NO_DOT);// wait until the viewscreen size has been determined and then set up the animation helper
if(t)ma.setUpTabAnimationHelper(!0);else if(n)ma.setUpTabAnimationHelper(!1);else{var i=new MutationObserver(function(e){t=S("body").hasClass(ma.MOBILE_CLASS_NO_DOT),n=S("body").hasClass(ma.DESKTOP_CLASS_NO_DOT),t?ma.setUpTabAnimationHelper(!0):n&&ma.setUpTabAnimationHelper(!1),(t||n)&&i.disconnect()});// create an observer instance linked to the callback function
// start observing the target node for configured mutations
i.observe(S("body")[0],{attributes:!0})}},setUpTabAnimationHelper:function(a){a&&!ma.isSetUpForAnimation&&(S.each(S(ma.TAB_LIST_CLASS),function(e,t){var n,i,r=S(t).attr("id"),o=S("#"+r).hasClass(ma.ANIMATE_TABS_CLASS_NO_DOT);// set the starting values based on the size of the user's display
i=a?(n=ma.MOBILE_LAYOUT,ma.MOBILE_SORT_BY):(n=ma.DESKTOP_LAYOUT,ma.DESKTOP_SORT_BY),// set up Isotope if the tabs will be animated
o&&(ma.tabLists[r]=new Isotope(t,{itemSelector:".js-tabs__trigger",layoutMode:n,fitRows:{equalheight:!0},vertical:{horizontalAlignment:0},sortBy:i,sortAscending:!0,getSortData:{displayOrder:"["+ma.DATA_DISPLAY_ORDER+"] parseInt"}}),// update the tab list to indicate that it is ready for animation
S("#"+r).addClass(ma.ANIMATED_CLASS_NO_DOT))}),ma.isSetUpForAnimation=!0)},updateTabLayoutWraps:function(){
// adds a wrap at desktop and removes it at mobile; the wrap adjusts the visual layout of the tabs
var n=S("body").hasClass(ma.MOBILE_CLASS_NO_DOT);S.each(S(ma.TAB_LIST_CLASS),function(e,t){S.each(S(t).find(ma.TAB_CLASS),function(e,t){n||S(t).parent().hasClass(ma.TAB_TRIGGER_WRAPPER_CLASS_NO_DOT)?n&&S(t).parent().hasClass(ma.TAB_TRIGGER_WRAPPER_CLASS_NO_DOT)&&S(t).unwrap():S(t).wrap("<div class="+ma.TAB_TRIGGER_WRAPPER_CLASS_NO_DOT+"></div>")})})},checkUrl:function(){
// open and set focus on the tab based if a tab id is provided in the url parameter
// the format is .html?tab=[id]
var e=Tr.getUrlParameters(),o="#"+e[ma.TAB_URL_PARAMETER],t=S(o);e[ma.TAB_URL_PARAMETER]&&(0<t.length?t.hasClass(ma.TAB_CLASS.slice(1))&&setTimeout(function(){t.click(),Ur(o,0)},ma.ISOTOPE_DELAY):console.error("There isn't a tab with id=\""+o+'" on this page')),S.each(S(ma.TAB_LIST_CLASS),function(e,t){if(S(t).hasClass(ma.ANIMATE_TABS_CLASS_NO_DOT)){var n=S(o).closest(ma.TAB_LIST_CLASS),i=!0;if(0<n.length&&n.attr("id")===t.id&&(i=!1),i){
// $(tabList).find('.is-default').click();
var r=S(t).find(".is-default").first().attr("id");ma.animateTabs(t.id,r)}}})},init:function(){ma.cacheDom(),ma.bindEvents(),// _private.updateTabLayoutWraps();
ma.setUpTabAnimation(),ma.checkUrl()}}).init,activateTab:ma.activateTab},Ra="undefined"!=typeof window&&"undefined"!=typeof document,va=["Edge","Trident","Firefox"],Ia=0,ya=0
/* eslint-disable */
// Credit: http://blog.apps.npr.org/pym.js/
/*! pym.js - v1.3.2 - 2018-02-13 */
/*
   * Pym.js is library that resizes an iframe based on the width of the parent and the resulting height of the child.
   * Check out the docs at http://blog.apps.npr.org/pym.js/ or the readme at README.md for usage.
   */
/* BB&T has modified this file to wrap the functionality, so that
   * it doesn't execute on import. We require three different resizing
   * approaches for different vendors, and we only want to initialize
   * the ones that we need on a page.
   */;ya<va.length;ya+=1)if(Ra&&0<=navigator.userAgent.indexOf(va[ya])){Ia=1;break}var ba=Ra&&window.Promise?function(e){var t=!1;return function(){t||(t=!0,window.Promise.resolve().then(function(){t=!1,e()}))}}:function(e){var t=!1;return function(){t||(t=!0,setTimeout(function(){t=!1,e()},Ia))}};
/**
  * Create a debounced version of a method, that's asynchronously deferred
  * but called in the minimum time possible.
  *
  * @method
  * @memberof Popper.Utils
  * @argument {Function} fn
  * @returns {Function}
  */
/**
   * Check if the given variable is a function
   * @method
   * @memberof Popper.Utils
   * @argument {Any} functionToCheck - variable to check
   * @returns {Boolean} answer to: is a function?
   */
function Na(e){return e&&"[object Function]"==={}.toString.call(e)}
/**
   * Get CSS computed property of the given element
   * @method
   * @memberof Popper.Utils
   * @argument {Eement} element
   * @argument {String} property
   */function Da(e,t){if(1!==e.nodeType)return[];
// NOTE: 1 DOM access here
var n=e.ownerDocument.defaultView.getComputedStyle(e,null);return t?n[t]:n}
/**
   * Returns the parentNode or the host of the element
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @returns {Element} parent
   */function Ma(e){return"HTML"===e.nodeName?e:e.parentNode||e.host}
/**
   * Returns the scrolling parent of the given element
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @returns {Element} scroll parent
   */function Pa(e){
// Return body, `getScroll` will take care to get the correct `scrollTop` from it
if(!e)return document.body;switch(e.nodeName){case"HTML":case"BODY":return e.ownerDocument.body;case"#document":return e.body}
// Firefox want us to check `-x` and `-y` variations as well
var t=Da(e),n=t.overflow,i=t.overflowX,r=t.overflowY;return/(auto|scroll|overlay)/.test(n+r+i)?e:Pa(Ma(e))}var wa=Ra&&!(!window.MSInputMethodContext||!document.documentMode),Ga=Ra&&/MSIE 10/.test(navigator.userAgent);
/**
   * Determines if the browser is Internet Explorer
   * @method
   * @memberof Popper.Utils
   * @param {Number} version to check
   * @returns {Boolean} isIE
   */
function Fa(e){return 11===e?wa:10===e?Ga:wa||Ga}
/**
   * Returns the offset parent of the given element
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @returns {Element} offset parent
   */function xa(e){if(!e)return document.documentElement;
// Skip hidden elements which don't have an offsetParent
for(var t=Fa(10)?document.body:null,n=e.offsetParent||null
// NOTE: 1 DOM access here
;n===t&&e.nextElementSibling;)n=(e=e.nextElementSibling).offsetParent;var i=n&&n.nodeName;return i&&"BODY"!==i&&"HTML"!==i?
// .offsetParent will return the closest TH, TD or TABLE in case
// no offsetParent is present, I hate this job...
-1!==["TH","TD","TABLE"].indexOf(n.nodeName)&&"static"===Da(n,"position")?xa(n):n:e?e.ownerDocument.documentElement:document.documentElement}
/**
   * Finds the root node (document, shadowDOM root) of the given element
   * @method
   * @memberof Popper.Utils
   * @argument {Element} node
   * @returns {Element} root node
   */
function Ba(e){return null!==e.parentNode?Ba(e.parentNode):e}
/**
   * Finds the offset parent common to the two provided nodes
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element1
   * @argument {Element} element2
   * @returns {Element} common offset parent
   */function Ua(e,t){
// This check is needed to avoid errors in case one of the elements isn't defined for any reason
if(!(e&&e.nodeType&&t&&t.nodeType))return document.documentElement;
// Here we make sure to give as "start" the element that comes first in the DOM
var n=e.compareDocumentPosition(t)&Node.DOCUMENT_POSITION_FOLLOWING,i=n?e:t,r=n?t:e,o=document.createRange();o.setStart(i,0),o.setEnd(r,0);var a,s,l=o.commonAncestorContainer;
// Both nodes are inside #document
if(e!==l&&t!==l||i.contains(r))return"BODY"===(s=(a=l).nodeName)||"HTML"!==s&&xa(a.firstElementChild)!==a?xa(l):l;
// one of the nodes is inside shadowDOM, find which one
var c=Ba(e);return c.host?Ua(c.host,t):Ua(e,Ba(t).host)}
/**
   * Gets the scroll value of the given element in the given side (top and left)
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @argument {String} side `top` or `left`
   * @returns {number} amount of scrolled pixels
   */function Ha(e){var t="top"===(1<arguments.length&&void 0!==arguments[1]?arguments[1]:"top")?"scrollTop":"scrollLeft",n=e.nodeName;if("BODY"!==n&&"HTML"!==n)return e[t];var i=e.ownerDocument.documentElement;return(e.ownerDocument.scrollingElement||i)[t]}
/*
   * Sum or subtract the element scroll values (left and top) from a given rect object
   * @method
   * @memberof Popper.Utils
   * @param {Object} rect - Rect object you want to change
   * @param {HTMLElement} element - The element from the function reads the scroll values
   * @param {Boolean} subtract - set to true if you want to subtract the scroll values
   * @return {Object} rect - The modifier rect object
   */
/*
   * Helper to detect borders of a given element
   * @method
   * @memberof Popper.Utils
   * @param {CSSStyleDeclaration} styles
   * Result of `getStyleComputedProperty` on the given element
   * @param {String} axis - `x` or `y`
   * @return {number} borders - The borders size of the given axis
   */
function ka(e,t){var n="x"===t?"Left":"Top",i="Left"===n?"Right":"Bottom";return parseFloat(e["border"+n+"Width"],10)+parseFloat(e["border"+i+"Width"],10)}function ja(e,t,n,i){return Math.max(t["offset"+e],t["scroll"+e],n["client"+e],n["offset"+e],n["scroll"+e],Fa(10)?parseInt(n["offset"+e])+parseInt(i["margin"+("Height"===e?"Top":"Left")])+parseInt(i["margin"+("Height"===e?"Bottom":"Right")]):0)}function Va(e){var t=e.body,n=e.documentElement,i=Fa(10)&&getComputedStyle(n);return{height:ja("Height",t,n,i),width:ja("Width",t,n,i)}}var Wa=function(){function i(e,t){for(var n=0;n<t.length;n++){var i=t[n];i.enumerable=i.enumerable||!1,i.configurable=!0,"value"in i&&(i.writable=!0),Object.defineProperty(e,i.key,i)}}return function(e,t,n){return t&&i(e.prototype,t),n&&i(e,n),e}}(),za=function(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e},Xa=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(e[i]=n[i])}return e};
/**
   * Given element offsets, generate an output similar to getBoundingClientRect
   * @method
   * @memberof Popper.Utils
   * @argument {Object} offsets
   * @returns {Object} ClientRect like output
   */
function Ya(e){return Xa({},e,{right:e.left+e.width,bottom:e.top+e.height})}
/**
   * Get bounding client rect of given element
   * @method
   * @memberof Popper.Utils
   * @param {HTMLElement} element
   * @return {Object} client rect
   */function Ka(e){var t={};
// IE10 10 FIX: Please, don't ask, the element isn't
// considered in DOM in some circumstances...
// This isn't reproducible in IE10 compatibility mode of IE11
try{if(Fa(10)){t=e.getBoundingClientRect();var n=Ha(e,"top"),i=Ha(e,"left");t.top+=n,t.left+=i,t.bottom+=n,t.right+=i}else t=e.getBoundingClientRect()}catch(e){}var r={left:t.left,top:t.top,width:t.right-t.left,height:t.bottom-t.top},o="HTML"===e.nodeName?Va(e.ownerDocument):{},a=o.width||e.clientWidth||r.right-r.left,s=o.height||e.clientHeight||r.bottom-r.top,l=e.offsetWidth-a,c=e.offsetHeight-s;
// subtract scrollbar size from sizes
// if an hypothetical scrollbar is detected, we must be sure it's not a `border`
// we make this check conditional for performance reasons
if(l||c){var d=Da(e);l-=ka(d,"x"),c-=ka(d,"y"),r.width-=l,r.height-=c}return Ya(r)}function qa(e,t){var n=2<arguments.length&&void 0!==arguments[2]&&arguments[2],i=Fa(10),r="HTML"===t.nodeName,o=Ka(e),a=Ka(t),s=Pa(e),l=Da(t),c=parseFloat(l.borderTopWidth,10),d=parseFloat(l.borderLeftWidth,10);
// In cases where the parent is fixed, we must ignore negative scroll in offset calc
n&&r&&(a.top=Math.max(a.top,0),a.left=Math.max(a.left,0));var u=Ya({top:o.top-a.top-c,left:o.left-a.left-d,width:o.width,height:o.height});
// Subtract margins of documentElement in case it's being used as parent
// we do this only on HTML because it's the only element that behaves
// differently when margins are applied to it. The margins are included in
// the box of the documentElement, in the other cases not.
if(u.marginTop=0,u.marginLeft=0,!i&&r){var f=parseFloat(l.marginTop,10),_=parseFloat(l.marginLeft,10);u.top-=c-f,u.bottom-=c-f,u.left-=d-_,u.right-=d-_,
// Attach marginTop and marginLeft because in some circumstances we may need them
u.marginTop=f,u.marginLeft=_}return(i&&!n?t.contains(s):t===s&&"BODY"!==s.nodeName)&&(u=function(e,t){var n=2<arguments.length&&void 0!==arguments[2]&&arguments[2],i=Ha(t,"top"),r=Ha(t,"left"),o=n?-1:1;return e.top+=i*o,e.bottom+=i*o,e.left+=r*o,e.right+=r*o,e}(u,t)),u}
/**
   * Finds the first parent of an element that has a transformed property defined
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @returns {Element} first transformed parent or documentElement
   */
function $a(e){
// This check is needed to avoid errors in case one of the elements isn't defined for any reason
if(!e||!e.parentElement||Fa())return document.documentElement;for(var t=e.parentElement;t&&"none"===Da(t,"transform");)t=t.parentElement;return t||document.documentElement}
/**
   * Computed the boundaries limits and return them
   * @method
   * @memberof Popper.Utils
   * @param {HTMLElement} popper
   * @param {HTMLElement} reference
   * @param {number} padding
   * @param {HTMLElement} boundariesElement - Element used to define the boundaries
   * @param {Boolean} fixedPosition - Is in fixed position mode
   * @returns {Object} Coordinates of the boundaries
   */function Ja(e,t,n,i){var r=4<arguments.length&&void 0!==arguments[4]&&arguments[4],o={top:0,left:0},a=r?$a(e):Ua(e,t);
// NOTE: 1 DOM access here
// Handle viewport case
if("viewport"===i)o=function(e){var t=1<arguments.length&&void 0!==arguments[1]&&arguments[1],n=e.ownerDocument.documentElement,i=qa(e,n),r=Math.max(n.clientWidth,window.innerWidth||0),o=Math.max(n.clientHeight,window.innerHeight||0),a=t?0:Ha(n),s=t?0:Ha(n,"left");return Ya({top:a-i.top+i.marginTop,left:s-i.left+i.marginLeft,width:r,height:o})}
/**
   * Check if the given element is fixed or is inside a fixed parent
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @argument {Element} customContainer
   * @returns {Boolean} answer to "isFixed?"
   */(a,r);else{
// Handle other cases based on DOM element used as boundaries
var s=void 0;"scrollParent"===i?"BODY"===(s=Pa(Ma(t))).nodeName&&(s=e.ownerDocument.documentElement):s="window"===i?e.ownerDocument.documentElement:i;var l=qa(s,a,r);
// In case of HTML, we need a different computation
if("HTML"!==s.nodeName||function e(t){var n=t.nodeName;if("BODY"===n||"HTML"===n)return!1;if("fixed"===Da(t,"position"))return!0;var i=Ma(t);return!!i&&e(i)}(a))
// for all the other DOM elements, this one is good
o=l;else{var c=Va(e.ownerDocument),d=c.height,u=c.width;o.top+=l.top-l.marginTop,o.bottom=d+l.top,o.left+=l.left-l.marginLeft,o.right=u+l.left}}
// Add paddings
var f="number"==typeof(n=n||0);return o.left+=f?n:n.left||0,o.top+=f?n:n.top||0,o.right-=f?n:n.right||0,o.bottom-=f?n:n.bottom||0,o}
/**
   * Utility used to transform the `auto` placement to the placement with more
   * available space.
   * @method
   * @memberof Popper.Utils
   * @argument {Object} data - The data object generated by update method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
function Qa(e,t,i,n,r){var o=5<arguments.length&&void 0!==arguments[5]?arguments[5]:0;if(-1===e.indexOf("auto"))return e;var a=Ja(i,n,o,r),s={top:{width:a.width,height:t.top-a.top},right:{width:a.right-t.right,height:a.height},bottom:{width:a.width,height:a.bottom-t.bottom},left:{width:t.left-a.left,height:a.height}},l=Object.keys(s).map(function(e){return Xa({key:e},s[e],{area:(t=s[e],t.width*t.height)});var t}).sort(function(e,t){return t.area-e.area}),c=l.filter(function(e){var t=e.width,n=e.height;return t>=i.clientWidth&&n>=i.clientHeight}),d=0<c.length?c[0].key:l[0].key,u=e.split("-")[1];return d+(u?"-"+u:"")}
/**
   * Get offsets to the reference element
   * @method
   * @memberof Popper.Utils
   * @param {Object} state
   * @param {Element} popper - the popper element
   * @param {Element} reference - the reference element (the popper will be relative to this)
   * @param {Element} fixedPosition - is in fixed position mode
   * @returns {Object} An object containing the offsets which will be applied to the popper
   */function Za(e,t,n){var i=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return qa(n,i?$a(t):Ua(t,n),i)}
/**
   * Get the outer sizes of the given element (offset size + margins)
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element
   * @returns {Object} object containing width and height properties
   */function es(e){var t=e.ownerDocument.defaultView.getComputedStyle(e),n=parseFloat(t.marginTop||0)+parseFloat(t.marginBottom||0),i=parseFloat(t.marginLeft||0)+parseFloat(t.marginRight||0);return{width:e.offsetWidth+i,height:e.offsetHeight+n}}
/**
   * Get the opposite placement of the given one
   * @method
   * @memberof Popper.Utils
   * @argument {String} placement
   * @returns {String} flipped placement
   */function ts(e){var t={left:"right",right:"left",bottom:"top",top:"bottom"};return e.replace(/left|right|bottom|top/g,function(e){return t[e]})}
/**
   * Get offsets to the popper
   * @method
   * @memberof Popper.Utils
   * @param {Object} position - CSS position the Popper will get applied
   * @param {HTMLElement} popper - the popper element
   * @param {Object} referenceOffsets - the reference offsets (the popper will be relative to this)
   * @param {String} placement - one of the valid placement options
   * @returns {Object} popperOffsets - An object containing the offsets which will be applied to the popper
   */function ns(e,t,n){n=n.split("-")[0];
// Get popper node sizes
var i=es(e),r={width:i.width,height:i.height},o=-1!==["right","left"].indexOf(n),a=o?"top":"left",s=o?"left":"top",l=o?"height":"width",c=o?"width":"height";
// Add position, width and height to our offsets object
return r[a]=t[a]+t[l]/2-i[l]/2,r[s]=n===s?t[s]-i[c]:t[ts(s)],r}
/**
   * Mimics the `find` method of Array
   * @method
   * @memberof Popper.Utils
   * @argument {Array} arr
   * @argument prop
   * @argument value
   * @returns index or -1
   */function is(e,t){
// use native find if supported
return Array.prototype.find?e.find(t):e.filter(t)[0];
// use `filter` to obtain the same behavior of `find`
}
/**
   * Return the index of the matching object
   * @method
   * @memberof Popper.Utils
   * @argument {Array} arr
   * @argument prop
   * @argument value
   * @returns index or -1
   */
/**
   * Loop trough the list of modifiers and run them in order,
   * each of them will then edit the data object.
   * @method
   * @memberof Popper.Utils
   * @param {dataObject} data
   * @param {Array} modifiers
   * @param {String} ends - Optional modifier name used as stopper
   * @returns {dataObject}
   */
function rs(e,n,t){return(void 0===t?e:e.slice(0,function(e,t,n){
// use native findIndex if supported
if(Array.prototype.findIndex)return e.findIndex(function(e){return e[t]===n});
// use `find` + `indexOf` if `findIndex` isn't supported
var i=is(e,function(e){return e[t]===n});return e.indexOf(i)}(e,"name",t))).forEach(function(e){e.function&&
// eslint-disable-line dot-notation
console.warn("`modifier.function` is deprecated, use `modifier.fn`!");var t=e.function||e.fn;// eslint-disable-line dot-notation
e.enabled&&Na(t)&&(
// Add properties to offsets to make them a complete clientRect object
// we do this before each modifier to make sure the previous one doesn't
// mess with these values
n.offsets.popper=Ya(n.offsets.popper),n.offsets.reference=Ya(n.offsets.reference),n=t(n,e))}),n}
/**
   * Updates the position of the popper, computing the new offsets and applying
   * the new style.<br />
   * Prefer `scheduleUpdate` over `update` because of performance reasons.
   * @method
   * @memberof Popper
   */
/**
   * Helper used to know if the given modifier is enabled.
   * @method
   * @memberof Popper.Utils
   * @returns {Boolean}
   */
function os(e,n){return e.some(function(e){var t=e.name;return e.enabled&&t===n})}
/**
   * Get the prefixed supported property name
   * @method
   * @memberof Popper.Utils
   * @argument {String} property (camelCase)
   * @returns {String} prefixed property (camelCase or PascalCase, depending on the vendor prefix)
   */function as(e){for(var t=[!1,"ms","Webkit","Moz","O"],n=e.charAt(0).toUpperCase()+e.slice(1),i=0;i<t.length;i++){var r=t[i],o=r?""+r+n:e;if(void 0!==document.body.style[o])return o}return null}
/**
   * Destroys the popper.
   * @method
   * @memberof Popper
   */
/**
   * Get the window associated with the element
   * @argument {Element} element
   * @returns {Window}
   */
function ss(e){var t=e.ownerDocument;return t?t.defaultView:window}
/**
   * Setup needed event listeners used to update the popper position
   * @method
   * @memberof Popper.Utils
   * @private
   */
function ls(e,t,n,i){
// Resize event listener on window
n.updateBound=i,ss(e).addEventListener("resize",n.updateBound,{passive:!0});
// Scroll event listener on scroll parents
var r=Pa(e);return function e(t,n,i,r){var o="BODY"===t.nodeName,a=o?t.ownerDocument.defaultView:t;a.addEventListener(n,i,{passive:!0}),o||e(Pa(a.parentNode),n,i,r),r.push(a)}(r,"scroll",n.updateBound,n.scrollParents),n.scrollElement=r,n.eventsEnabled=!0,n}
/**
   * It will add resize/scroll events and start recalculating
   * position of the popper element when they are triggered.
   * @method
   * @memberof Popper
   */
/**
   * It will remove resize/scroll events and won't recalculate popper position
   * when they are triggered. It also won't trigger `onUpdate` callback anymore,
   * unless you call `update` method manually.
   * @method
   * @memberof Popper
   */
function cs(){
/**
   * Remove event listeners used to update the popper position
   * @method
   * @memberof Popper.Utils
   * @private
   */
var e,t;this.state.eventsEnabled&&(cancelAnimationFrame(this.scheduleUpdate),this.state=(e=this.reference,t=this.state,
// Remove resize event listener on window
ss(e).removeEventListener("resize",t.updateBound),
// Remove scroll event listener on scroll parents
t.scrollParents.forEach(function(e){e.removeEventListener("scroll",t.updateBound)}),
// Reset state
t.updateBound=null,t.scrollParents=[],t.scrollElement=null,t.eventsEnabled=!1,t))}
/**
   * Tells if a given input is a number
   * @method
   * @memberof Popper.Utils
   * @param {*} input to check
   * @return {Boolean}
   */function ds(e){return""!==e&&!isNaN(parseFloat(e))&&isFinite(e)}
/**
   * Set the style to the given popper
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element - Element to apply the style to
   * @argument {Object} styles
   * Object with a list of properties and values which will be applied to the element
   */function us(n,i){Object.keys(i).forEach(function(e){var t="";
// add unit if the value is numeric and is one of the following
-1!==["width","height","top","right","bottom","left"].indexOf(e)&&ds(i[e])&&(t="px"),n.style[e]=i[e]+t})}
/**
   * Set the attributes to the given popper
   * @method
   * @memberof Popper.Utils
   * @argument {Element} element - Element to apply the attributes to
   * @argument {Object} styles
   * Object with a list of properties and values which will be applied to the element
   */var fs=Ra&&/Firefox/i.test(navigator.userAgent);
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by `update` method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
/**
   * Helper used to know if the given modifier depends from another one.<br />
   * It checks if the needed modifier is listed and enabled.
   * @method
   * @memberof Popper.Utils
   * @param {Array} modifiers - list of modifiers
   * @param {String} requestingName - name of requesting modifier
   * @param {String} requestedName - name of requested modifier
   * @returns {Boolean}
   */
function _s(e,t,n){var i=is(e,function(e){return e.name===t}),r=!!i&&e.some(function(e){return e.name===n&&e.enabled&&e.order<i.order});if(!r){var o="`"+t+"`",a="`"+n+"`";console.warn(a+" modifier is required by "+o+" modifier in order to work, be sure to include it before "+o+"!")}return r}
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by update method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
/**
   * List of accepted placements to use as values of the `placement` option.<br />
   * Valid placements are:
   * - `auto`
   * - `top`
   * - `right`
   * - `bottom`
   * - `left`
   *
   * Each placement can have a variation from this list:
   * - `-start`
   * - `-end`
   *
   * Variations are interpreted easily if you think of them as the left to right
   * written languages. Horizontally (`top` and `bottom`), `start` is left and `end`
   * is right.<br />
   * Vertically (`left` and `right`), `start` is top and `end` is bottom.
   *
   * Some valid examples are:
   * - `top-end` (on top of reference, right aligned)
   * - `right-start` (on right of reference, top aligned)
   * - `bottom` (on bottom, centered)
   * - `auto-end` (on the side with more space available, alignment depends by placement)
   *
   * @static
   * @type {Array}
   * @enum {String}
   * @readonly
   * @method placements
   * @memberof Popper
   */
var Ss=["auto-start","auto","auto-end","top-start","top","top-end","right-start","right","right-end","bottom-end","bottom","bottom-start","left-end","left","left-start"],ps=Ss.slice(3);
// Get rid of `auto` `auto-start` and `auto-end`
/**
   * Given an initial placement, returns all the subsequent placements
   * clockwise (or counter-clockwise).
   *
   * @method
   * @memberof Popper.Utils
   * @argument {String} placement - A valid placement (it accepts variations)
   * @argument {Boolean} counter - Set to true to walk the placements counterclockwise
   * @returns {Array} placements including their variations
   */
function Es(e){var t=1<arguments.length&&void 0!==arguments[1]&&arguments[1],n=ps.indexOf(e),i=ps.slice(n+1).concat(ps.slice(0,n));return t?i.reverse():i}var hs="flip",As="clockwise",ms="counterclockwise";
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by update method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
/**
   * Parse an `offset` string to extrapolate `x` and `y` numeric offsets.
   * @function
   * @memberof {modifiers~offset}
   * @private
   * @argument {String} offset
   * @argument {Object} popperOffsets
   * @argument {Object} referenceOffsets
   * @argument {String} basePlacement
   * @returns {Array} a two cells array with x and y offsets in numbers
   */
function Ts(e,r,o,t){var a=[0,0],s=-1!==["right","left"].indexOf(t),n=e.split(/(\+|\-)/).map(function(e){return e.trim()}),i=n.indexOf(is(n,function(e){return-1!==e.search(/,|\s/)}));
// Use height if placement is left or right and index is 0 otherwise use width
// in this way the first offset will use an axis and the second one
// will use the other one
n[i]&&-1===n[i].indexOf(",")&&console.warn("Offsets separated by white space(s) are deprecated, use a comma (,) instead.");
// If divider is found, we divide the list of values and operands to divide
// them by ofset X and Y.
var l=/\s*,\s*|\s+/,c=-1!==i?[n.slice(0,i).concat([n[i].split(l)[0]]),[n[i].split(l)[1]].concat(n.slice(i+1))]:[n];
// Convert the values with units to absolute pixels to allow our computations
// Loop trough the offsets arrays and execute the operations
return(c=c.map(function(e,t){
// Most of the units rely on the orientation of the popper
var n=(1===t?!s:s)?"height":"width",i=!1;return e.reduce(function(e,t){return""===e[e.length-1]&&-1!==["+","-"].indexOf(t)?(e[e.length-1]=t,i=!0,e):i?(e[e.length-1]+=t,i=!1,e):e.concat(t)},[]).map(function(e){
/**
   * Converts a string containing value + unit into a px value number
   * @function
   * @memberof {modifiers~offset}
   * @private
   * @argument {String} str - Value + unit string
   * @argument {String} measurement - `height` or `width`
   * @argument {Object} popperOffsets
   * @argument {Object} referenceOffsets
   * @returns {Number|String}
   * Value in pixels, or original string if no values were extracted
   */
return function(e,t,n,i){
// separate value from unit
var r=e.match(/((?:\-|\+)?\d*\.?\d*)(.*)/),o=+r[1],a=r[2];
// If it's not a number it's an operator, I guess
if(!o)return e;if(0!==a.indexOf("%"))return"vh"!==a&&"vw"!==a?o:("vh"===a?Math.max(document.documentElement.clientHeight,window.innerHeight||0):Math.max(document.documentElement.clientWidth,window.innerWidth||0))/100*o;var s=void 0;switch(a){case"%p":s=n;break;case"%":case"%r":default:s=i}return Ya(s)[t]/100*o}(e,n,r,o)})})).forEach(function(n,i){n.forEach(function(e,t){ds(e)&&(a[i]+=e*("-"===n[t-1]?-1:1))})}),a}
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by update method
   * @argument {Object} options - Modifiers configuration and options
   * @argument {Number|String} options.offset=0
   * The offset value as described in the modifier description
   * @returns {Object} The data object, properly modified
   */
/**
   * Modifier function, each modifier can have a function of this type assigned
   * to its `fn` property.<br />
   * These functions will be called on each update, this means that you must
   * make sure they are performant enough to avoid performance bottlenecks.
   *
   * @function ModifierFn
   * @argument {dataObject} data - The data object generated by `update` method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {dataObject} The data object, properly modified
   */
/**
   * Modifiers are plugins used to alter the behavior of your poppers.<br />
   * Popper.js uses a set of 9 modifiers to provide all the basic functionalities
   * needed by the library.
   *
   * Usually you don't want to override the `order`, `fn` and `onLoad` props.
   * All the other properties are configurations that could be tweaked.
   * @namespace modifiers
   */
var gs={
/**
     * Popper's placement.
     * @prop {Popper.placements} placement='bottom'
     */
placement:"bottom",
/**
     * Set this to true if you want popper to position it self in 'fixed' mode
     * @prop {Boolean} positionFixed=false
     */
positionFixed:!1,
/**
     * Whether events (resize, scroll) are initially enabled.
     * @prop {Boolean} eventsEnabled=true
     */
eventsEnabled:!0,
/**
     * Set to true if you want to automatically remove the popper when
     * you call the `destroy` method.
     * @prop {Boolean} removeOnDestroy=false
     */
removeOnDestroy:!1,
/**
     * Callback called when the popper is created.<br />
     * By default, it is set to no-op.<br />
     * Access Popper.js instance with `data.instance`.
     * @prop {onCreate}
     */
onCreate:function(){},
/**
     * Callback called when the popper is updated. This callback is not called
     * on the initialization/creation of the popper, but only on subsequent
     * updates.<br />
     * By default, it is set to no-op.<br />
     * Access Popper.js instance with `data.instance`.
     * @prop {onUpdate}
     */
onUpdate:function(){},
/**
     * List of modifiers used to modify the offsets before they are applied to the popper.
     * They provide most of the functionalities of Popper.js.
     * @prop {modifiers}
     */
modifiers:{
/**
     * Modifier used to shift the popper on the start or end of its reference
     * element.<br />
     * It will read the variation of the `placement` property.<br />
     * It can be one either `-end` or `-start`.
     * @memberof modifiers
     * @inner
     */
shift:{
/** @prop {number} order=100 - Index used to define the order of execution */
order:100,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by `update` method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
function(e){var t=e.placement,n=t.split("-")[0],i=t.split("-")[1];
// if shift shiftvariation is specified, run the modifier
if(i){var r=e.offsets,o=r.reference,a=r.popper,s=-1!==["bottom","top"].indexOf(n),l=s?"left":"top",c=s?"width":"height",d={start:za({},l,o[l]),end:za({},l,o[l]+o[c]-a[c])};e.offsets.popper=Xa({},a,d[i])}return e}
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by update method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */},
/**
     * The `offset` modifier can shift your popper on both its axis.
     *
     * It accepts the following units:
     * - `px` or unit-less, interpreted as pixels
     * - `%` or `%r`, percentage relative to the length of the reference element
     * - `%p`, percentage relative to the length of the popper element
     * - `vw`, CSS viewport width unit
     * - `vh`, CSS viewport height unit
     *
     * For length is intended the main axis relative to the placement of the popper.<br />
     * This means that if the placement is `top` or `bottom`, the length will be the
     * `width`. In case of `left` or `right`, it will be the `height`.
     *
     * You can provide a single value (as `Number` or `String`), or a pair of values
     * as `String` divided by a comma or one (or more) white spaces.<br />
     * The latter is a deprecated method because it leads to confusion and will be
     * removed in v2.<br />
     * Additionally, it accepts additions and subtractions between different units.
     * Note that multiplications and divisions aren't supported.
     *
     * Valid examples are:
     * ```
     * 10
     * '10%'
     * '10, 10'
     * '10%, 10'
     * '10 + 10%'
     * '10 - 5vh + 3%'
     * '-10px + 5vh, 5px - 6%'
     * ```
     * > **NB**: If you desire to apply offsets to your poppers in a way that may make them overlap
     * > with their reference element, unfortunately, you will have to disable the `flip` modifier.
     * > You can read more on this at this [issue](https://github.com/FezVrasta/popper.js/issues/373).
     *
     * @memberof modifiers
     * @inner
     */
offset:{
/** @prop {number} order=200 - Index used to define the order of execution */
order:200,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:function(e,t){var n=t.offset,i=e.placement,r=e.offsets,o=r.popper,a=r.reference,s=i.split("-")[0],l=void 0;return l=ds(+n)?[+n,0]:Ts(n,o,a,s),"left"===s?(o.top+=l[0],o.left-=l[1]):"right"===s?(o.top+=l[0],o.left+=l[1]):"top"===s?(o.left+=l[0],o.top-=l[1]):"bottom"===s&&(o.left+=l[0],o.top+=l[1]),e.popper=o,e}
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by `update` method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */,
/** @prop {Number|String} offset=0
       * The offset value as described in the modifier description
       */
offset:0},
/**
     * Modifier used to prevent the popper from being positioned outside the boundary.
     *
     * A scenario exists where the reference itself is not within the boundaries.<br />
     * We can say it has "escaped the boundaries" — or just "escaped".<br />
     * In this case we need to decide whether the popper should either:
     *
     * - detach from the reference and remain "trapped" in the boundaries, or
     * - if it should ignore the boundary and "escape with its reference"
     *
     * When `escapeWithReference` is set to`true` and reference is completely
     * outside its boundaries, the popper will overflow (or completely leave)
     * the boundaries in order to remain attached to the edge of the reference.
     *
     * @memberof modifiers
     * @inner
     */
preventOverflow:{
/** @prop {number} order=300 - Index used to define the order of execution */
order:300,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:function(e,i){var t=i.boundariesElement||xa(e.instance.popper);
// If offsetParent is the reference element, we really want to
// go one step up and use the next offsetParent as reference to
// avoid to make this modifier completely useless and look like broken
e.instance.reference===t&&(t=xa(t));
// NOTE: DOM access here
// resets the popper's position so that the document size can be calculated excluding
// the size of the popper element itself
var n=as("transform"),r=e.instance.popper.style,o=r.top,a=r.left,s=r[n];r.top="",r.left="",r[n]="";var l=Ja(e.instance.popper,e.instance.reference,i.padding,t,e.positionFixed);
// NOTE: DOM access here
// restores the original style properties after the offsets have been computed
r.top=o,r.left=a,r[n]=s,i.boundaries=l;var c=i.priority,d=e.offsets.popper,u={primary:function(e){var t=d[e];return d[e]<l[e]&&!i.escapeWithReference&&(t=Math.max(d[e],l[e])),za({},e,t)},secondary:function(e){var t="right"===e?"left":"top",n=d[t];return d[e]>l[e]&&!i.escapeWithReference&&(n=Math.min(d[t],l[e]-("right"===e?d.width:d.height))),za({},t,n)}};return c.forEach(function(e){var t=-1!==["left","top"].indexOf(e)?"primary":"secondary";d=Xa({},d,u[t](e))}),e.offsets.popper=d,e},
/**
       * @prop {Array} [priority=['left','right','top','bottom']]
       * Popper will try to prevent overflow following these priorities by default,
       * then, it could overflow on the left and on top of the `boundariesElement`
       */
priority:["left","right","top","bottom"],
/**
       * @prop {number} padding=5
       * Amount of pixel used to define a minimum distance between the boundaries
       * and the popper. This makes sure the popper always has a little padding
       * between the edges of its container
       */
padding:5,
/**
       * @prop {String|HTMLElement} boundariesElement='scrollParent'
       * Boundaries used by the modifier. Can be `scrollParent`, `window`,
       * `viewport` or any DOM element.
       */
boundariesElement:"scrollParent"},
/**
     * Modifier used to make sure the reference and its popper stay near each other
     * without leaving any gap between the two. Especially useful when the arrow is
     * enabled and you want to ensure that it points to its reference element.
     * It cares only about the first axis. You can still have poppers with margin
     * between the popper and its reference element.
     * @memberof modifiers
     * @inner
     */
keepTogether:{
/** @prop {number} order=400 - Index used to define the order of execution */
order:400,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by update method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
function(e){var t=e.offsets,n=t.popper,i=t.reference,r=e.placement.split("-")[0],o=Math.floor,a=-1!==["top","bottom"].indexOf(r),s=a?"right":"bottom",l=a?"left":"top",c=a?"width":"height";return n[s]<o(i[l])&&(e.offsets.popper[l]=o(i[l])-n[c]),n[l]>o(i[s])&&(e.offsets.popper[l]=o(i[s])),e}},
/**
     * This modifier is used to move the `arrowElement` of the popper to make
     * sure it is positioned between the reference element and its popper element.
     * It will read the outer size of the `arrowElement` node to detect how many
     * pixels of conjunction are needed.
     *
     * It has no effect if no `arrowElement` is provided.
     * @memberof modifiers
     * @inner
     */
arrow:{
/** @prop {number} order=500 - Index used to define the order of execution */
order:500,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:function(e,t){var n;
// arrow depends on keepTogether in order to work
if(!_s(e.instance.modifiers,"arrow","keepTogether"))return e;var i=t.element;
// if arrowElement is a string, suppose it's a CSS selector
if("string"==typeof i){
// if arrowElement is not found, don't run the modifier
if(!(i=e.instance.popper.querySelector(i)))return e}else
// if the arrowElement isn't a query selector we must check that the
// provided DOM node is child of its popper node
if(!e.instance.popper.contains(i))return console.warn("WARNING: `arrow.element` must be child of its popper element!"),e;var r=e.placement.split("-")[0],o=e.offsets,a=o.popper,s=o.reference,l=-1!==["left","right"].indexOf(r),c=l?"height":"width",d=l?"Top":"Left",u=d.toLowerCase(),f=l?"left":"top",_=l?"bottom":"right",S=es(i)[c];
//
// extends keepTogether behavior making sure the popper and its
// reference have enough pixels in conjunction
//
// top/left side
s[_]-S<a[u]&&(e.offsets.popper[u]-=a[u]-(s[_]-S)),
// bottom/right side
s[u]+S>a[_]&&(e.offsets.popper[u]+=s[u]+S-a[_]),e.offsets.popper=Ya(e.offsets.popper);
// compute center of the popper
var p=s[u]+s[c]/2-S/2,E=Da(e.instance.popper),h=parseFloat(E["margin"+d],10),A=parseFloat(E["border"+d+"Width"],10),m=p-e.offsets.popper[u]-h-A;
// Compute the sideValue using the updated popper offsets
// take popper margin in account because we don't have this info available
// prevent arrowElement from being placed not contiguously to its popper
return m=Math.max(Math.min(a[c]-S,m),0),e.arrowElement=i,e.offsets.arrow=(za(n={},u,Math.round(m)),za(n,f,""),n),e}
/**
   * Get the opposite placement variation of the given one
   * @method
   * @memberof Popper.Utils
   * @argument {String} placement variation
   * @returns {String} flipped placement variation
   */,
/** @prop {String|HTMLElement} element='[x-arrow]' - Selector or node used as arrow */
element:"[x-arrow]"},
/**
     * Modifier used to flip the popper's placement when it starts to overlap its
     * reference element.
     *
     * Requires the `preventOverflow` modifier before it in order to work.
     *
     * **NOTE:** this modifier will interrupt the current update cycle and will
     * restart it if it detects the need to flip the placement.
     * @memberof modifiers
     * @inner
     */
flip:{
/** @prop {number} order=600 - Index used to define the order of execution */
order:600,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:function(S,p){
// if `inner` modifier is enabled, we can't use the `flip` modifier
if(os(S.instance.modifiers,"inner"))return S;if(S.flipped&&S.placement===S.originalPlacement)
// seems like flip is trying to loop, probably there's not enough space on any of the flippable sides
return S;var E=Ja(S.instance.popper,S.instance.reference,p.padding,p.boundariesElement,S.positionFixed),h=S.placement.split("-")[0],A=ts(h),m=S.placement.split("-")[1]||"",T=[];switch(p.behavior){case hs:T=[h,A];break;case As:T=Es(h);break;case ms:T=Es(h,!0);break;default:T=p.behavior}return T.forEach(function(e,t){if(h!==e||T.length===t+1)return S;h=S.placement.split("-")[0],A=ts(h);var n,i=S.offsets.popper,r=S.offsets.reference,o=Math.floor,a="left"===h&&o(i.right)>o(r.left)||"right"===h&&o(i.left)<o(r.right)||"top"===h&&o(i.bottom)>o(r.top)||"bottom"===h&&o(i.top)<o(r.bottom),s=o(i.left)<o(E.left),l=o(i.right)>o(E.right),c=o(i.top)<o(E.top),d=o(i.bottom)>o(E.bottom),u="left"===h&&s||"right"===h&&l||"top"===h&&c||"bottom"===h&&d,f=-1!==["top","bottom"].indexOf(h),_=!!p.flipVariations&&(f&&"start"===m&&s||f&&"end"===m&&l||!f&&"start"===m&&c||!f&&"end"===m&&d);(a||u||_)&&(
// this boolean to detect any flip loop
S.flipped=!0,(a||u)&&(h=T[t+1]),_&&(m="end"===(n=m)?"start":"start"===n?"end":n),S.placement=h+(m?"-"+m:""),
// this object contains `position`, we want to preserve it along with
// any additional property we may add in the future
S.offsets.popper=Xa({},S.offsets.popper,ns(S.instance.popper,S.offsets.reference,S.placement)),S=rs(S.instance.modifiers,S,"flip"))}),S},
/**
       * @prop {String|Array} behavior='flip'
       * The behavior used to change the popper's placement. It can be one of
       * `flip`, `clockwise`, `counterclockwise` or an array with a list of valid
       * placements (with optional variations)
       */
behavior:"flip",
/**
       * @prop {number} padding=5
       * The popper will flip if it hits the edges of the `boundariesElement`
       */
padding:5,
/**
       * @prop {String|HTMLElement} boundariesElement='viewport'
       * The element which will define the boundaries of the popper position.
       * The popper will never be placed outside of the defined boundaries
       * (except if `keepTogether` is enabled)
       */
boundariesElement:"viewport"},
/**
     * Modifier used to make the popper flow toward the inner of the reference element.
     * By default, when this modifier is disabled, the popper will be placed outside
     * the reference element.
     * @memberof modifiers
     * @inner
     */
inner:{
/** @prop {number} order=700 - Index used to define the order of execution */
order:700,
/** @prop {Boolean} enabled=false - Whether the modifier is enabled or not */
enabled:!1,
/** @prop {ModifierFn} */
fn:
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by `update` method
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The data object, properly modified
   */
function(e){var t=e.placement,n=t.split("-")[0],i=e.offsets,r=i.popper,o=i.reference,a=-1!==["left","right"].indexOf(n),s=-1===["top","left"].indexOf(n);return r[a?"left":"top"]=o[n]-(s?r[a?"width":"height"]:0),e.placement=ts(t),e.offsets.popper=Ya(r),e}},
/**
     * Modifier used to hide the popper when its reference element is outside of the
     * popper boundaries. It will set a `x-out-of-boundaries` attribute which can
     * be used to hide with a CSS selector the popper when its reference is
     * out of boundaries.
     *
     * Requires the `preventOverflow` modifier before it in order to work.
     * @memberof modifiers
     * @inner
     */
hide:{
/** @prop {number} order=800 - Index used to define the order of execution */
order:800,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:function(e){if(!_s(e.instance.modifiers,"hide","preventOverflow"))return e;var t=e.offsets.reference,n=is(e.instance.modifiers,function(e){return"preventOverflow"===e.name}).boundaries;if(t.bottom<n.top||t.left>n.right||t.top>n.bottom||t.right<n.left){
// Avoid unnecessary DOM access if visibility hasn't changed
if(!0===e.hide)return e;e.hide=!0,e.attributes["x-out-of-boundaries"]=""}else{
// Avoid unnecessary DOM access if visibility hasn't changed
if(!1===e.hide)return e;e.hide=!1,e.attributes["x-out-of-boundaries"]=!1}return e}},
/**
     * Computes the style that will be applied to the popper element to gets
     * properly positioned.
     *
     * Note that this modifier will not touch the DOM, it just prepares the styles
     * so that `applyStyle` modifier can apply it. This separation is useful
     * in case you need to replace `applyStyle` with a custom implementation.
     *
     * This modifier has `850` as `order` value to maintain backward compatibility
     * with previous versions of Popper.js. Expect the modifiers ordering method
     * to change in future major versions of the library.
     *
     * @memberof modifiers
     * @inner
     */
computeStyle:{
/** @prop {number} order=850 - Index used to define the order of execution */
order:850,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:function(e,t){var n=t.x,i=t.y,r=e.offsets.popper,o=is(e.instance.modifiers,function(e){return"applyStyle"===e.name}).gpuAcceleration;void 0!==o&&console.warn("WARNING: `gpuAcceleration` option moved to `computeStyle` modifier and will not be supported in future versions of Popper.js!");var a,s,l,c,d,u,f,_,S,p,E,h,A,m,T=void 0!==o?o:t.gpuAcceleration,g=xa(e.instance.popper),C=Ka(g),L={position:r.position},O=(a=e,s=window.devicePixelRatio<2||!fs,l=a.offsets,c=l.popper,d=l.reference,u=Math.round,f=Math.floor,_=function(e){return e},S=u(d.width),p=u(c.width),E=-1!==["left","right"].indexOf(a.placement),h=-1!==a.placement.indexOf("-"),m=s?u:_,{left:(A=s?E||h||S%2==p%2?u:f:_)(S%2==1&&p%2==1&&!h&&s?c.left-1:c.left),top:m(c.top),bottom:m(c.bottom),right:A(c.right)}),R="bottom"===n?"top":"bottom",v="right"===i?"left":"right",I=as("transform"),y=void 0,b=void 0;if(b="bottom"===R?
// when offsetParent is <html> the positioning is relative to the bottom of the screen (excluding the scrollbar)
// and not the bottom of the html element
"HTML"===g.nodeName?-g.clientHeight+O.bottom:-C.height+O.bottom:O.top,y="right"===v?"HTML"===g.nodeName?-g.clientWidth+O.right:-C.width+O.right:O.left,T&&I)L[I]="translate3d("+y+"px, "+b+"px, 0)",L[R]=0,L[v]=0,L.willChange="transform";else{
// othwerise, we use the standard `top`, `left`, `bottom` and `right` properties
var N="bottom"===R?-1:1,D="right"===v?-1:1;L[R]=b*N,L[v]=y*D,L.willChange=R+", "+v}
// Attributes
var M={"x-placement":e.placement};
// Update `data` attributes, styles and arrowStyles
return e.attributes=Xa({},M,e.attributes),e.styles=Xa({},L,e.styles),e.arrowStyles=Xa({},e.offsets.arrow,e.arrowStyles),e},
/**
       * @prop {Boolean} gpuAcceleration=true
       * If true, it uses the CSS 3D transformation to position the popper.
       * Otherwise, it will use the `top` and `left` properties
       */
gpuAcceleration:!0,
/**
       * @prop {string} [x='bottom']
       * Where to anchor the X axis (`bottom` or `top`). AKA X offset origin.
       * Change this if your popper should grow in a direction different from `bottom`
       */
x:"bottom",
/**
       * @prop {string} [x='left']
       * Where to anchor the Y axis (`left` or `right`). AKA Y offset origin.
       * Change this if your popper should grow in a direction different from `right`
       */
y:"right"},
/**
     * Applies the computed styles to the popper element.
     *
     * All the DOM manipulations are limited to this modifier. This is useful in case
     * you want to integrate Popper.js inside a framework or view library and you
     * want to delegate all the DOM manipulations to it.
     *
     * Note that if you disable this modifier, you must make sure the popper element
     * has its position set to `absolute` before Popper.js can do its work!
     *
     * Just disable this modifier and define your own to achieve the desired effect.
     *
     * @memberof modifiers
     * @inner
     */
applyStyle:{
/** @prop {number} order=900 - Index used to define the order of execution */
order:900,
/** @prop {Boolean} enabled=true - Whether the modifier is enabled or not */
enabled:!0,
/** @prop {ModifierFn} */
fn:
/**
   * @function
   * @memberof Modifiers
   * @argument {Object} data - The data object generated by `update` method
   * @argument {Object} data.styles - List of style properties - values to apply to popper element
   * @argument {Object} data.attributes - List of attribute properties - values to apply to popper element
   * @argument {Object} options - Modifiers configuration and options
   * @returns {Object} The same data object
   */
function(e){var t,n;
// any property present in `data.styles` will be applied to the popper,
// in this way we can make the 3rd party modifiers add custom styles to it
// Be aware, modifiers could override the properties defined in the previous
// lines of this modifier!
return us(e.instance.popper,e.styles),
// any property present in `data.attributes` will be applied to the popper,
// they will be set as HTML attributes of the element
t=e.instance.popper,n=e.attributes,Object.keys(n).forEach(function(e){!1!==n[e]?t.setAttribute(e,n[e]):t.removeAttribute(e)}),
// if arrowElement is defined and arrowStyles has some properties
e.arrowElement&&Object.keys(e.arrowStyles).length&&us(e.arrowElement,e.arrowStyles),e}
/**
   * Set the x-placement attribute before everything else because it could be used
   * to add margins to the popper margins needs to be calculated to get the
   * correct popper offsets.
   * @method
   * @memberof Popper.modifiers
   * @param {HTMLElement} reference - The reference element used to position the popper
   * @param {HTMLElement} popper - The HTML element used as popper
   * @param {Object} options - Popper.js options
   */,
/** @prop {Function} */
onLoad:function(e,t,n,i,r){
// compute reference element offsets
var o=Za(r,t,e,n.positionFixed),a=Qa(n.placement,o,t,e,n.modifiers.flip.boundariesElement,n.modifiers.flip.padding);
// compute auto placement, store placement inside the data object,
// modifiers will be able to edit `placement` if needed
// and refer to originalPlacement to know the original value
return t.setAttribute("x-placement",a),
// Apply `position` to popper before anything else because
// without the position applied we can't guarantee correct computations
us(t,{position:n.positionFixed?"fixed":"absolute"}),n}
/**
   * @function
   * @memberof Popper.Utils
   * @argument {Object} data - The data object generated by `update` method
   * @argument {Boolean} shouldRound - If the offsets should be rounded at all
   * @returns {Object} The popper's position offsets rounded
   *
   * The tale of pixel-perfect positioning. It's still not 100% perfect, but as
   * good as it can be within reason.
   * Discussion here: https://github.com/FezVrasta/popper.js/pull/715
   *
   * Low DPI screens cause a popper to be blurry if not using full pixels (Safari
   * as well on High DPI screens).
   *
   * Firefox prefers no rounding for positioning and does not have blurriness on
   * high DPI screens.
   *
   * Only horizontal placement and left/right values need to be considered.
   */,
/**
       * @deprecated since version 1.10.0, the property moved to `computeStyle` modifier
       * @prop {Boolean} gpuAcceleration=true
       * If true, it uses the CSS 3D transformation to position the popper.
       * Otherwise, it will use the `top` and `left` properties
       */
gpuAcceleration:void 0}}},Cs=function(){
/**
     * Creates a new Popper.js instance.
     * @class Popper
     * @param {HTMLElement|referenceObject} reference - The reference element used to position the popper
     * @param {HTMLElement} popper - The HTML element used as the popper
     * @param {Object} options - Your custom options to override the ones defined in [Defaults](#defaults)
     * @return {Object} instance - The generated Popper.js instance
     */
function o(e,t){var n=this,i=2<arguments.length&&void 0!==arguments[2]?arguments[2]:{};!function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,o),this.scheduleUpdate=function(){return requestAnimationFrame(n.update)},
// make update() debounced, so that it only runs at most once-per-tick
this.update=ba(this.update.bind(this)),
// with {} we create a new object with the options inside it
this.options=Xa({},o.Defaults,i),
// init state
this.state={isDestroyed:!1,isCreated:!1,scrollParents:[]},
// get reference and popper elements (allow jQuery wrappers)
this.reference=e&&e.jquery?e[0]:e,this.popper=t&&t.jquery?t[0]:t,
// Deep merge modifiers options
this.options.modifiers={},Object.keys(Xa({},o.Defaults.modifiers,i.modifiers)).forEach(function(e){n.options.modifiers[e]=Xa({},o.Defaults.modifiers[e]||{},i.modifiers?i.modifiers[e]:{})}),
// Refactoring modifiers' list (Object => Array)
this.modifiers=Object.keys(this.options.modifiers).map(function(e){return Xa({name:e},n.options.modifiers[e])}).sort(function(e,t){return e.order-t.order}),
// modifiers have the ability to execute arbitrary code when Popper.js get inited
// such code is executed in the same order of its modifier
// they could add new properties to their options configuration
// BE AWARE: don't add options to `options.modifiers.name` but to `modifierOptions`!
this.modifiers.forEach(function(e){e.enabled&&Na(e.onLoad)&&e.onLoad(n.reference,n.popper,n.options,e,n.state)}),
// fire the first update to position the popper in the right place
this.update();var r=this.options.eventsEnabled;r&&
// setup event listeners, they will take care of update the position in specific situations
this.enableEventListeners(),this.state.eventsEnabled=r}
// We can't use class properties because they don't get listed in the
// class prototype and break stuff like Sinon stubs
return Wa(o,[{key:"update",value:function(){return function(){
// if popper is destroyed, don't perform any further update
if(!this.state.isDestroyed){var e={instance:this,styles:{},arrowStyles:{},attributes:{},flipped:!1,offsets:{}};
// compute reference element offsets
e.offsets.reference=Za(this.state,this.popper,this.reference,this.options.positionFixed),
// compute auto placement, store placement inside the data object,
// modifiers will be able to edit `placement` if needed
// and refer to originalPlacement to know the original value
e.placement=Qa(this.options.placement,e.offsets.reference,this.popper,this.reference,this.options.modifiers.flip.boundariesElement,this.options.modifiers.flip.padding),
// store the computed placement inside `originalPlacement`
e.originalPlacement=e.placement,e.positionFixed=this.options.positionFixed,
// compute the popper offsets
e.offsets.popper=ns(this.popper,e.offsets.reference,e.placement),e.offsets.popper.position=this.options.positionFixed?"fixed":"absolute",
// run the modifiers
e=rs(this.modifiers,e),
// the first `update` will call `onCreate` callback
// the other ones will call `onUpdate` callback
this.state.isCreated?this.options.onUpdate(e):(this.state.isCreated=!0,this.options.onCreate(e))}}.call(this)}},{key:"destroy",value:function(){return function(){return this.state.isDestroyed=!0,
// touch DOM only if `applyStyle` modifier is enabled
os(this.modifiers,"applyStyle")&&(this.popper.removeAttribute("x-placement"),this.popper.style.position="",this.popper.style.top="",this.popper.style.left="",this.popper.style.right="",this.popper.style.bottom="",this.popper.style.willChange="",this.popper.style[as("transform")]=""),this.disableEventListeners(),
// remove the popper if user explicity asked for the deletion on destroy
// do not use `remove` because IE11 doesn't support it
this.options.removeOnDestroy&&this.popper.parentNode.removeChild(this.popper),this}.call(this)}},{key:"enableEventListeners",value:function(){return function(){this.state.eventsEnabled||(this.state=ls(this.reference,this.options,this.state,this.scheduleUpdate))}.call(this)}},{key:"disableEventListeners",value:function(){return cs.call(this)}
/**
       * Schedules an update. It will run on the next UI update available.
       * @method scheduleUpdate
       * @memberof Popper
       */
/**
       * Collection of utilities useful when writing custom modifiers.
       * Starting from version 1.7, this method is available only if you
       * include `popper-utils.js` before `popper.js`.
       *
       * **DEPRECATION**: This way to access PopperUtils is deprecated
       * and will be removed in v2! Use the PopperUtils module directly instead.
       * Due to the high instability of the methods contained in Utils, we can't
       * guarantee them to follow semver. Use them at your own risk!
       * @static
       * @private
       * @type {Object}
       * @deprecated since version 1.8
       * @member Utils
       * @memberof Popper
       */}]),o}();
/**
   * The `dataObject` is an object containing all the information used by Popper.js.
   * This object is passed to modifiers and to the `onCreate` and `onUpdate` callbacks.
   * @name dataObject
   * @property {Object} data.instance The Popper.js instance
   * @property {String} data.placement Placement applied to popper
   * @property {String} data.originalPlacement Placement originally defined on init
   * @property {Boolean} data.flipped True if popper has been flipped by flip modifier
   * @property {Boolean} data.hide True if the reference element is out of boundaries, useful to know when to hide the popper
   * @property {HTMLElement} data.arrowElement Node used as arrow by arrow modifier
   * @property {Object} data.styles Any CSS property defined here will be applied to the popper. It expects the JavaScript nomenclature (eg. `marginBottom`)
   * @property {Object} data.arrowStyles Any CSS property defined here will be applied to the popper arrow. It expects the JavaScript nomenclature (eg. `marginBottom`)
   * @property {Object} data.boundaries Offsets of the popper boundaries
   * @property {Object} data.offsets The measurements of popper, reference and arrow elements
   * @property {Object} data.offsets.popper `top`, `left`, `width`, `height` values
   * @property {Object} data.offsets.reference `top`, `left`, `width`, `height` values
   * @property {Object} data.offsets.arrow] `top` and `left` offsets, only one of them will be different from 0
   */
/**
   * Default options provided to Popper.js constructor.<br />
   * These can be overridden using the `options` argument of Popper.js.<br />
   * To override an option, simply pass an object with the same
   * structure of the `options` object, as the 3rd argument. For example:
   * ```
   * new Popper(ref, pop, {
   *   modifiers: {
   *     preventOverflow: { enabled: false }
   *   }
   * })
   * ```
   * @type {Object}
   * @static
   * @memberof Popper
   */
/**
   * The `referenceObject` is an object that provides an interface compatible with Popper.js
   * and lets you use it as replacement of a real DOM node.<br />
   * You can use this method to position a popper relatively to a set of coordinates
   * in case you don't have a DOM node to use as reference.
   *
   * ```
   * new Popper(referenceObject, popperNode);
   * ```
   *
   * NB: This feature isn't supported in Internet Explorer 10.
   * @name referenceObject
   * @property {Function} data.getBoundingClientRect
   * A function that returns a set of coordinates compatible with the native `getBoundingClientRect` method.
   * @property {number} data.clientWidth
   * An ES6 getter that will return the width of the virtual reference element.
   * @property {number} data.clientHeight
   * An ES6 getter that will return the height of the virtual reference element.
   */
Cs.Utils=("undefined"!=typeof window?window:global).PopperUtils,Cs.placements=Ss,Cs.Defaults=gs;var Ls,Os,Rs={init:(Ls={targetId:null,tooltipId:null,TOOLTIP_CLASS:".js-lx-tooltip",TOOLTIP_TRIGGER_CLASS:".js-lx-tooltip__trigger",cacheDom:function(){Ls.$tooltip=S(Ls.TOOLTIP_CLASS),Ls.$trigger=S(Ls.TOOLTIP_TRIGGER_CLASS)},bindEvents:function(){Ls.$trigger.on("click",Ls.handleTooltipClickEvent),S(document).on("click",Ls.handleTooltipDismissClickEvent)},handleTooltipClickEvent:function(e){e.preventDefault(),Ls.storeTarget(e.target),Ls.toggleTooltip(Ls.targetId)},handleTooltipDismissClickEvent:function(e){if(!S(e.target).hasClass("js-lx-tooltip__trigger")&&0<S(".js-lx-tooltip").filter(".is-visible").length)if(0===S(e.target).closest(".js-lx-tooltip").length)Ls.closeAll();else if(0!==S(e.target).closest(".js-lx-tooltip__close").length){var t="#"+S(e.target).closest(".js-lx-tooltip").attr("data-trigger");Ls.closeSelf(S(e.target).closest(".js-lx-tooltip"),S(t))}},
// Initializes the popper.js plugin
// For documentation, see: https://popper.js.org/popper-documentation.html
initPopper:function(){for(var e=0;e<Ls.$trigger.length;e++)new Cs(Ls.$trigger[e],Ls.$tooltip[e],{placement:"auto",reference:Ls.$trigger[e],modifiers:{flip:{enabled:!0,boundariesElement:"viewport"},preventOverflow:{boundariesElement:"window"}}})},storeTarget:function(e){Ls.targetId=e.getAttribute("data-target")},toggleTooltip:function(e){var t=S("#".concat(e)),n=t.attr("data-trigger"),i=S("#".concat(n));Ls.initPopper(t),t.toggleClass("is-invisible is-visible").attr("aria-hidden",function(e,t){return"true"===t?"false":"true"}),i.toggleClass("is-pressed").attr("aria-expanded",function(e,t){return"true"===t?"false":"true"})},closeSelf:function(e,t){S(e).removeClass("is-visible"),S(e).addClass("is-invisible"),S(e).attr("aria-hidden","true"),S(t).removeClass("is-pressed"),S(t).attr("aria-expanded","false"),S(t).focus()},closeAll:function(){for(var e=0;e<Ls.$tooltip.length;e++)Ls.$tooltip[e].classList.remove("is-visible"),Ls.$tooltip[e].classList.add("is-invisible"),Ls.$tooltip[e].setAttribute("aria-hidden","true");for(var t=0;t<Ls.$trigger.length;t++)Ls.$trigger[t].classList.remove("is-pressed"),Ls.$trigger[t].setAttribute("aria-expanded","false")},init:function(){Ls.cacheDom(),Ls.bindEvents(),Ls.toggleTooltip()}}).init,toggleTooltip:Ls.toggleTooltip},vs={init:(Os={VIDEO_PLAYER_WRAPPER_CLASS:".js-video-player-wrapper",VIDEO_PLAYER_CLASS:".js-video-player",VIDEO_PLAYER_INTRO_CLASS:".video-player__intro",BRIGHTCOVE_VIDEO_PLAYER_SELECTOR:".js-video-player-wrapper .responsive-embed",WISTIA_VIDEO_PLAYER_SELECTOR:".wistia_responsive_wrapper",WISTIA_URL_BASE:"https://fast.wistia.com/embed/medias/",WISTIA_URL_EXT:".jsonp",WISTIA_PLAY_BUTTON:".w-big-play-button",addBrightcovePlayerScript:function(){
// add and execute the player script tag
var e=document.createElement("script");e.src="//players.brightcove.net/1775614125001/Hkgj5rUrM_default/index.min.js",document.body.appendChild(e)},
// fires a call back when the video is loaded
createWistiaCallback:function(){
// this variable is necessary to determine when wistia videos are ready
window._wq=window._wq||[],
/* eslint-disable no-invalid-this */
S('script[src^="'.concat(Os.WISTIA_URL_BASE,'"]')).each(function(){var e=S(this).attr("src").replace(Os.WISTIA_URL_BASE,"").replace(Os.WISTIA_URL_EXT,""),t=S(this).closest(Os.VIDEO_PLAYER_WRAPPER_CLASS).attr("id");_wq.push({id:e,onReady:function(e){Os.wistiaReady(t)}})})},wistiaReady:function(e){var t=S("#".concat(e," ").concat(Os.VIDEO_PLAYER_INTRO_CLASS," .text-block__title")).first().text();// update the label of the player button to include the title of the video
// for accessibility reasons
S("#".concat(e," .w-big-play-button")).attr("aria-label","play video: ".concat(t)),// set all images inside of the video to have alt=""
S("#".concat(e," img")).attr("alt","")},init:function(){
// for Brightcove players
S(Os.BRIGHTCOVE_VIDEO_PLAYER_SELECTOR).length&&Os.addBrightcovePlayerScript(),// for Wistia players
S(Os.WISTIA_VIDEO_PLAYER_SELECTOR).length&&Os.createWistiaCallback()}}).init},Is={CONTEXT_HUB_TARGETED:"context-hub-targeted"},ys={PLATFORM:{READY:"platformReady",STATUS:"platformStatus"}},bs=!1;// initialize modules
function Ns(){
// ensures that modules are only initialized once
if(!bs){var e;bs=!0,S("body.".concat(Is.CONTEXT_HUB_TARGETED)).length&&(S(".experiencefragment.section").children().addClass("main-content-row").appendTo(S(".experiencefragment.section").parent().parent()),S(".experiencefragment.section").parent().remove(),S("script.main-content-row").removeClass("main-content-row"),S("body").removeClass(Is.CONTEXT_HUB_TARGETED)),o({fallback:function(e,t,n){return"images/fallback-icon.png"}}),n=document.createElement("script"),i=document.getElementsByTagName("script")[0],
/* eslint-disable yoda */
n.src="".concat("https:"===document.location.protocol?"https":"http","://ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js"),
/* eslint-enable yoda */
n.type="text/javascript",n.async="true",i.parentNode.insertBefore(n,i),to(),jr.init(),Jr.init(),$r.init(),function(){if("function"==typeof window.CustomEvent)return;function e(e,t){var n=document.createEvent("CustomEvent");return t=t||{bubbles:!1,cancelable:!1,detail:void 0},n.initCustomEvent(e,t.bubbles,t.cancelable,t.detail),n}e.prototype=window.Event.prototype,window.CustomEvent=e}(),gr.appendPageParameters(),qr.showActiveSegment(),Br.setUpLanguageLinks(),qr.checkForRedirect(),S(".js-block-alert").length&&Fo.init(),S(".js-lx-collapsible").length&&xo.init(),S(".js-collection").length&&Bo.init(),S(".js-disclosures").length&&Ho.init(),S(".js-display-tagged-cards").length&&Uo.init(),S(".js-filter-wrapper").length&&Wo.init(),S(".js-form").length&&Qo.init(),S(".js-generic-select").length&&Zo.init(),S(".js-lx-grid").length&&!1===Modernizr.cssgrid&&ea.init(),S(".js-header").length&&(
// there will be two versions of the header component until all existing production sites can be converted to use version 2
// the headers have different js, so this loads the correct version
// once all sites are converted, rename the js to just "Header" and remove the if statement below
0<S(".js-lx-collapsible.header__navigation-collapse--mobile-menu").length?na.init():ta.init()),S(".js-component--parent").length&&ia.init(),S(".js-responsive-iframe").length&&La.init(),S(".js-lx-tabs").length&&Oa.init(),S(".js-lx-tooltip").length&&Rs.init(),S(".js-video-player").length&&vs.init(),// only have one redirect notice - the priority is language and then segment
Br.hasRedirectNotice()?
// redirect users to/from MotionPoint proxy sites based on the language-specific cookie
Br.displayRedirectNotice():qr.hasRedirectNotice()&&
// redirect users who land on the site homepage to the homepage for their last active segment
qr.displayRedirectNotice(),// add the components to a global object for reference
window.BBT_AEM_Platform=(_(e={
// components
BlockAlert:Fo,Collapsible:xo,Collection:Bo,Counties:Zi,Disclosures:Ho,DisplayTaggedCards:Uo,Filter:Wo,Form:Qo,GenericSelect:Zo,Grid:ea,HeaderV1:ta,HeaderV2:na,Parent:ia,ResponsiveIframe:La,Tabs:Oa,Tooltip:Rs,VideoPlayer:vs,MotionPointRedirect:Br,SegmentHandler:qr,
// supporting functionality
debounce:er,GetPageParameters:gr},"MotionPointRedirect",Br),_(e,"scrollToTarget",Ur),_(e,"ScrollToTop",Vr),_(e,"SegmentHandler",qr),_(e,"Shame",$r),_(e,"ShowScreenReaderOnlyContent",Jr),_(e,"SmoothScroll",jr),_(e,"TableBuilder",Zr),e);// dispatch an event to notify sites that platform js is ready
var t=new CustomEvent(ys.PLATFORM.STATUS,{detail:{type:ys.PLATFORM.READY}});console.log("platform js version 1.5.17 is initialized"),S("body")[0].dispatchEvent(t)}var n,i}// if there is conditional display via context hub, wait until the conditional content
// has loaded before displaying the page, otherwise load it
// check for segment redirects and context hub
S(document).ready(function(){!function(){if(S("body.".concat(Is.CONTEXT_HUB_TARGETED)).length)
// if the body element has the class context-hub-targeted, wait for a context hub event that indicates that the page has been loaded
try{window.ContextHub.eventing.on(ContextHub.SegmentEngine.PageInteraction.Teaser.prototype.info.loadEvent,Ns)}catch(e){Ns()}else
// otherwise load the modules on document.ready()
Ns()}// clean up after context hub runs
// remove the context hub event handler so we don't initialize modules more than once
// move the page contents outside of the elements created by context hub
// remove the context hub class to display the contents of the page
()})}($);
//# sourceMappingURL=platform-1.5.17.js.map
//# sourceMappingURL=build/platform/js/platform-1.5.17.js.map
var_ns=new function(){this.e=(new Date(2005,0,15)).getTimezoneOffset();this.f=(new Date(2005,6,15)).getTimezoneOffset();this.plugins=[];this.d={Flash:["ShockwaveFlash.ShockwaveFlash",function(b){return b.getVariable("$version")}],Director:["SWCtl.SWCtl",function(b){return b.ShockwaveVersion("")}]};this.q=function(b){var c;try{c=document.getElementById(b)}catch(d){}if(c===null||typeof c==="undefined")try{c=document.getElementsByName(b)[0]}catch(e){}if(c===null||typeof c==="undefined")for(var f=0;f<
document.forms.length;f++)for(var g=document.forms[f],h=0;h<g.elements.length;h++){var a=g[h];if(a.name===b||a.id===b)return a}return c};this.b=function(b){var c="";try{if(typeof this.c.getComponentVersion!=="undefined")c=this.c.getComponentVersion(b,"ComponentID")}catch(d){b=d.message.length;b=b>40?40:b;c=escape(d.message.substr(0,b))}return c};this.exec=function(b){for(var c=0;c<b.length;c++)try{var d=eval(b[c]);if(d)return d}catch(e){}return""};this.o=function(b){var c="";try{if(navigator.plugins&&
navigator.plugins.length){var d=RegExp(b+".* ([0-9._]+)");for(b=0;b<navigator.plugins.length;b++){var e=d.exec(navigator.plugins[b].name);if(e===null)e=d.exec(navigator.plugins[b].description);if(e)c=e[1]}}else if(window.ActiveXObject&&this.d[b])try{var f=new ActiveXObject(this.d[b][0]);c=this.d[b][1](f)}catch(g){c=""}}catch(h){c=h.message}return c};this.p=function(){for(var b=["Acrobat","Flash","QuickTime","Java Plug-in","Director","Office"],c=0;c<b.length;c++){var d=b[c];this.plugins[d]=this.o(d)}};
this.g=function(){return Math.abs(this.e-this.f)};this.h=function(){return this.g()!==0};this.i=function(b){var c=Math.min(this.e,this.f);return this.h()&&b.getTimezoneOffset()===c};this.m=function(b){var c=0;c=0;if(this.i(b))c=this.g();return c=-(b.getTimezoneOffset()+c)/60};this.j=function(b,c,d,e){if(typeof e!=="boolean")e=false;for(var f=true,g;(g=b.indexOf(c))>=0&&(e||f);){b=b.substr(0,g)+d+b.substr(g+c.length);f=false}return b};this.k=function(){return(new Date(2005,5,7,21,33,44,888)).toLocaleString()};
this.r=function(b){var c=new Date,d=[function(){return"TF1"},function(){return"015"},function(){return ScriptEngineMajorVersion()},function(){return ScriptEngineMinorVersion()},function(){return ScriptEngineBuildVersion()},function(a){return a.b("{7790769C-0471-11D2-AF11-00C04FA35D02}")},function(a){return a.b("{89820200-ECBD-11CF-8B85-00AA005B4340}")},function(a){return a.b("{283807B5-2C60-11D0-A31D-00AA00B92C03}")},function(a){return a.b("{4F216970-C90C-11D1-B5C7-0000F8051515}")},function(a){return a.b("{44BBA848-CC51-11CF-AAFA-00AA00B6015C}")},
function(a){return a.b("{9381D8F2-0288-11D0-9501-00AA00B911A5}")},function(a){return a.b("{4F216970-C90C-11D1-B5C7-0000F8051515}")},function(a){return a.b("{5A8D6EE0-3E18-11D0-821E-444553540000}")},function(a){return a.b("{89820200-ECBD-11CF-8B85-00AA005B4383}")},function(a){return a.b("{08B0E5C0-4FCB-11CF-AAA5-00401C608555}")},function(a){return a.b("{45EA75A0-A269-11D1-B5BF-0000F8051515}")},function(a){return a.b("{DE5AED00-A4BF-11D1-9948-00C04F98BBC9}")},function(a){return a.b("{22D6F312-B0F6-11D0-94AB-0080C74C7E95}")},
function(a){return a.b("{44BBA842-CC51-11CF-AAFA-00AA00B6015B}")},function(a){return a.b("{3AF36230-A269-11D1-B5BF-0000F8051515}")},function(a){return a.b("{44BBA840-CC51-11CF-AAFA-00AA00B6015C}")},function(a){return a.b("{CC2A9BA0-3BDD-11D0-821E-444553540000}")},function(a){return a.b("{08B0E5C0-4FCB-11CF-AAA5-00401C608500}")},function(){return eval("navigator.appCodeName")},function(){return eval("navigator.appName")},function(){return eval("navigator.appVersion")},function(a){return a.exec(["navigator.productSub",
"navigator.appMinorVersion"])},function(){return eval("navigator.browserLanguage")},function(){return eval("navigator.cookieEnabled")},function(a){return a.exec(["navigator.oscpu","navigator.cpuClass"])},function(){return eval("navigator.onLine")},function(){return eval("navigator.platform")},function(){return eval("navigator.systemLanguage")},function(){return eval("navigator.userAgent")},function(a){return a.exec(["navigator.language","navigator.userLanguage"])},function(){return eval("document.defaultCharset")},
function(){return eval("document.domain")},function(){return eval("screen.deviceXDPI")},function(){return eval("screen.deviceYDPI")},function(){return eval("screen.fontSmoothingEnabled")},function(){return eval("screen.updateInterval")},function(a){return a.h()},function(a){return a.i(c)},function(){return"@UTC@"},function(a){return a.m(c)},function(a){return a.k()},function(){return eval("screen.width")},function(){return eval("screen.height")},function(a){return a.plugins.Acrobat},function(a){return a.plugins.Flash},
function(a){return a.plugins.QuickTime},function(a){return a.plugins["Java Plug-in"]},function(a){return a.plugins.Director},function(a){return a.plugins.Office},function(){return(new Date).getTime()-c.getTime()},function(a){return a.e},function(a){return a.f},function(){return c.toLocaleString()},function(){return eval("screen.colorDepth")},function(){return eval("window.screen.availWidth")},function(){return eval("window.screen.availHeight")},function(){return eval("window.screen.availLeft")},function(){return eval("window.screen.availTop")},
function(a){return a.a("Acrobat")},function(a){return a.a("Adobe SVG")},function(a){return a.a("Authorware")},function(a){return a.a("Citrix ICA")},function(a){return a.a("Director")},function(a){return a.a("Flash")},function(a){return a.a("MapGuide")},function(a){return a.a("MetaStream")},function(a){return a.a("PDFViewer")},function(a){return a.a("QuickTime")},function(a){return a.a("RealOne")},function(a){return a.a("RealPlayer Enterprise")},function(a){return a.a("RealPlayer Plugin")},function(a){return a.a("Seagate Software Report")},
function(a){return a.a("Silverlight")},function(a){return a.a("Windows Media")},function(a){return a.a("iPIX")},function(a){return a.a("nppdf.so")},function(a){return a.n()}];this.p();for(var e="",f=0;f<d.length;f++){if(b){e+=this.j(d[f].toString(),'"',"'",true);e+="="}var g;try{g=d[f](this)}catch(h){g=""}e+=b?g:escape(g);e+=";";if(b)e+="\\n"}return e=this.j(e,escape("@UTC@"),(new Date).getTime())};this.l=function(b){try{var c;c=this.q(b);if(c!==null)try{c.value=this.r()}catch(d){c.value=escape(d.message)}}catch(e){}};
this.a=function(b){try{if(navigator.plugins&&navigator.plugins.length)for(var c=0;c<navigator.plugins.length;c++){var d=navigator.plugins[c];if(d.name.indexOf(b)>=0)return d.name+(d.description?"|"+d.description:"")}}catch(e){}return""};this.n=function(){var b=document.createElement("span");b.innerHTML="&nbsp;";b.style.position="absolute";b.style.left="-9999px";document.body.appendChild(b);var c=b.offsetHeight;document.body.removeChild(b);return c}};
try{var_ns.c=document.createElement("span");typeof var_ns.c.addBehavior!=="undefined"&&var_ns.c.addBehavior("#default#clientCaps")}catch(i){}window.var_ns=var_ns;window.var_ns.data_parse=var_ns.l;
/*@preserve BB&T bbtcom, version 1.1.14 */
!function(d){"use strict";d=d&&d.hasOwnProperty("default")?d.default:d;var e="URLSearchParams"in self,n="Symbol"in self&&"iterator"in Symbol,s="FileReader"in self&&"Blob"in self&&function(){try{return new Blob,!0}catch(t){return!1}}(),r="FormData"in self,a="ArrayBuffer"in self;if(a)var i=["[object Int8Array]","[object Uint8Array]","[object Uint8ClampedArray]","[object Int16Array]","[object Uint16Array]","[object Int32Array]","[object Uint32Array]","[object Float32Array]","[object Float64Array]"],o=ArrayBuffer.isView||function(t){return t&&-1<i.indexOf(Object.prototype.toString.call(t))};function c(t){if("string"!=typeof t&&(t=String(t)),/[^a-z0-9\-#$%&'*+.^_`|~]/i.test(t))throw new TypeError("Invalid character in header field name");return t.toLowerCase()}function l(t){return"string"!=typeof t&&(t=String(t)),t}
// Build a destructive iterator for the value list
function t(e){var t={next:function(){var t=e.shift();return{done:void 0===t,value:t}}};return n&&(t[Symbol.iterator]=function(){return t}),t}function u(e){this.map={},e instanceof u?e.forEach(function(t,e){this.append(e,t)},this):Array.isArray(e)?e.forEach(function(t){this.append(t[0],t[1])},this):e&&Object.getOwnPropertyNames(e).forEach(function(t){this.append(t,e[t])},this)}function h(t){if(t.bodyUsed)return Promise.reject(new TypeError("Already read"));t.bodyUsed=!0}function f(n){return new Promise(function(t,e){n.onload=function(){t(n.result)},n.onerror=function(){e(n.error)}})}function p(t){var e=new FileReader,n=f(e);return e.readAsArrayBuffer(t),n}function E(t){if(t.slice)return t.slice(0);var e=new Uint8Array(t.byteLength);return e.set(new Uint8Array(t)),e.buffer}function S(){return this.bodyUsed=!1,this._initBody=function(t){(this._bodyInit=t)?"string"==typeof t?this._bodyText=t:s&&Blob.prototype.isPrototypeOf(t)?this._bodyBlob=t:r&&FormData.prototype.isPrototypeOf(t)?this._bodyFormData=t:e&&URLSearchParams.prototype.isPrototypeOf(t)?this._bodyText=t.toString():a&&s&&function(t){return t&&DataView.prototype.isPrototypeOf(t)}(t)?(this._bodyArrayBuffer=E(t.buffer),
// IE 10-11 can't handle a DataView body.
this._bodyInit=new Blob([this._bodyArrayBuffer])):a&&(ArrayBuffer.prototype.isPrototypeOf(t)||o(t))?this._bodyArrayBuffer=E(t):this._bodyText=t=Object.prototype.toString.call(t):this._bodyText="",this.headers.get("content-type")||("string"==typeof t?this.headers.set("content-type","text/plain;charset=UTF-8"):this._bodyBlob&&this._bodyBlob.type?this.headers.set("content-type",this._bodyBlob.type):e&&URLSearchParams.prototype.isPrototypeOf(t)&&this.headers.set("content-type","application/x-www-form-urlencoded;charset=UTF-8"))},s&&(this.blob=function(){var t=h(this);if(t)return t;if(this._bodyBlob)return Promise.resolve(this._bodyBlob);if(this._bodyArrayBuffer)return Promise.resolve(new Blob([this._bodyArrayBuffer]));if(this._bodyFormData)throw new Error("could not read FormData body as blob");return Promise.resolve(new Blob([this._bodyText]))},this.arrayBuffer=function(){return this._bodyArrayBuffer?h(this)||Promise.resolve(this._bodyArrayBuffer):this.blob().then(p)}),this.text=function(){var t=h(this);if(t)return t;if(this._bodyBlob)return function(t){var e=new FileReader,n=f(e);return e.readAsText(t),n}(this._bodyBlob);if(this._bodyArrayBuffer)return Promise.resolve(function(t){for(var e=new Uint8Array(t),n=new Array(e.length),r=0;r<e.length;r++)n[r]=String.fromCharCode(e[r]);return n.join("")}(this._bodyArrayBuffer));if(this._bodyFormData)throw new Error("could not read FormData body as text");return Promise.resolve(this._bodyText)},r&&(this.formData=function(){return this.text().then(A)}),this.json=function(){return this.text().then(JSON.parse)},this}
// HTTP methods whose capitalization should be normalized
u.prototype.append=function(t,e){t=c(t),e=l(e);var n=this.map[t];this.map[t]=n?n+", "+e:e},u.prototype.delete=function(t){delete this.map[c(t)]},u.prototype.get=function(t){return t=c(t),this.has(t)?this.map[t]:null},u.prototype.has=function(t){return this.map.hasOwnProperty(c(t))},u.prototype.set=function(t,e){this.map[c(t)]=l(e)},u.prototype.forEach=function(t,e){for(var n in this.map)this.map.hasOwnProperty(n)&&t.call(e,this.map[n],n,this)},u.prototype.keys=function(){var n=[];return this.forEach(function(t,e){n.push(e)}),t(n)},u.prototype.values=function(){var e=[];return this.forEach(function(t){e.push(t)}),t(e)},u.prototype.entries=function(){var n=[];return this.forEach(function(t,e){n.push([e,t])}),t(n)},n&&(u.prototype[Symbol.iterator]=u.prototype.entries);var m=["DELETE","GET","HEAD","OPTIONS","POST","PUT"];function _(t,e){var n=(e=e||{}).body;if(t instanceof _){if(t.bodyUsed)throw new TypeError("Already read");this.url=t.url,this.credentials=t.credentials,e.headers||(this.headers=new u(t.headers)),this.method=t.method,this.mode=t.mode,this.signal=t.signal,n||null==t._bodyInit||(n=t._bodyInit,t.bodyUsed=!0)}else this.url=String(t);if(this.credentials=e.credentials||this.credentials||"same-origin",!e.headers&&this.headers||(this.headers=new u(e.headers)),this.method=function(t){var e=t.toUpperCase();return-1<m.indexOf(e)?e:t}(e.method||this.method||"GET"),this.mode=e.mode||this.mode||null,this.signal=e.signal||this.signal,this.referrer=null,("GET"===this.method||"HEAD"===this.method)&&n)throw new TypeError("Body not allowed for GET or HEAD requests");this._initBody(n)}function A(t){var a=new FormData;return t.trim().split("&").forEach(function(t){if(t){var e=t.split("="),n=e.shift().replace(/\+/g," "),r=e.join("=").replace(/\+/g," ");a.append(decodeURIComponent(n),decodeURIComponent(r))}}),a}function g(t,e){e||(e={}),this.type="default",this.status=void 0===e.status?200:e.status,this.ok=200<=this.status&&this.status<300,this.statusText="statusText"in e?e.statusText:"OK",this.headers=new u(e.headers),this.url=e.url||"",this._initBody(t)}_.prototype.clone=function(){return new _(this,{body:this._bodyInit})},S.call(_.prototype),S.call(g.prototype),g.prototype.clone=function(){return new g(this._bodyInit,{status:this.status,statusText:this.statusText,headers:new u(this.headers),url:this.url})},g.error=function(){var t=new g(null,{status:0,statusText:""});return t.type="error",t};var T=[301,302,303,307,308];g.redirect=function(t,e){if(-1===T.indexOf(e))throw new RangeError("Invalid status code");return new g(null,{status:e,headers:{location:t}})};var v=self.DOMException;try{new v}catch(t){(v=function(t,e){this.message=t,this.name=e;var n=Error(t);this.stack=n.stack}).prototype=Object.create(Error.prototype),v.prototype.constructor=v}function y(i,o){return new Promise(function(n,t){var e=new _(i,o);if(e.signal&&e.signal.aborted)return t(new v("Aborted","AbortError"));var r=new XMLHttpRequest;function a(){r.abort()}r.onload=function(){var t={status:r.status,statusText:r.statusText,headers:function(t){var a=new u;
// Replace instances of \r\n and \n followed by at least one space or horizontal tab with a space
// https://tools.ietf.org/html/rfc7230#section-3.2
return t.replace(/\r?\n[\t ]+/g," ").split(/\r?\n/).forEach(function(t){var e=t.split(":"),n=e.shift().trim();if(n){var r=e.join(":").trim();a.append(n,r)}}),a}(r.getAllResponseHeaders()||"")};t.url="responseURL"in r?r.responseURL:t.headers.get("X-Request-URL");var e="response"in r?r.response:r.responseText;n(new g(e,t))},r.onerror=function(){t(new TypeError("Network request failed"))},r.ontimeout=function(){t(new TypeError("Network request failed"))},r.onabort=function(){t(new v("Aborted","AbortError"))},r.open(e.method,e.url,!0),"include"===e.credentials?r.withCredentials=!0:"omit"===e.credentials&&(r.withCredentials=!1),"responseType"in r&&s&&(r.responseType="blob"),e.headers.forEach(function(t,e){r.setRequestHeader(e,t)}),e.signal&&(e.signal.addEventListener("abort",a),r.onreadystatechange=function(){
// DONE (success or failure)
4===r.readyState&&e.signal.removeEventListener("abort",a)}),r.send(void 0===e._bodyInit?null:e._bodyInit)})}y.polyfill=!0,self.fetch||(self.fetch=y,self.Headers=u,self.Request=_,self.Response=g);var O="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};function C(t,e){return t(e={exports:{}},e.exports),e.exports}function R(t){return t&&t.Math==Math&&t}function N(t){try{return!!t()}catch(t){return!0}}function b(t,e){return{enumerable:!(1&t),configurable:!(2&t),writable:!(4&t),value:e}}function L(t){return $.call(t).slice(8,-1)}function I(t){if(null==t)throw TypeError("Can't call method on "+t);return t}function w(t){return Q(I(t))}function x(t){return"object"==typeof t?null!==t:"function"==typeof t}function P(t,e){if(!x(t))return t;var n,r;if(e&&"function"==typeof(n=t.toString)&&!x(r=n.call(t)))return r;if("function"==typeof(n=t.valueOf)&&!x(r=n.call(t)))return r;if(!e&&"function"==typeof(n=t.toString)&&!x(r=n.call(t)))return r;throw TypeError("Can't convert object to primitive value")}function D(t,e){return Z.call(t,e)}function M(t){return tt?J.createElement(t):{}}function U(t){if(!x(t))throw TypeError(String(t)+" is not an object");return t}function B(e,n){try{ot(z,e,n)}catch(t){z[e]=n}return n}function H(t){return"Symbol(".concat(void 0===t?"":t,")_",(++dt+ht).toString(36))}function j(t){return ft[t]||(ft[t]=H(t))}var G,k,F,Y="object",z=
// eslint-disable-next-line no-undef
R(typeof globalThis==Y&&globalThis)||R(typeof window==Y&&window)||R(typeof self==Y&&self)||R(typeof O==Y&&O)||
// eslint-disable-next-line no-new-func
Function("return this")(),W=!N(function(){return 7!=Object.defineProperty({},"a",{get:function(){return 7}}).a}),V={}.propertyIsEnumerable,X=Object.getOwnPropertyDescriptor,q={f:X&&!V.call({1:2},1)?function(t){var e=X(this,t);return!!e&&e.enumerable}:V},$={}.toString,K="".split,Q=N(function(){
// throws an error in rhino, see https://github.com/mozilla/rhino/issues/346
// eslint-disable-next-line no-prototype-builtins
return!Object("z").propertyIsEnumerable(0)})?function(t){return"String"==L(t)?K.call(t,""):Object(t)}:Object,Z={}.hasOwnProperty,J=z.document,tt=x(J)&&x(J.createElement),et=!W&&!N(function(){return 7!=Object.defineProperty(M("div"),"a",{get:function(){return 7}}).a}),nt=Object.getOwnPropertyDescriptor,rt={f:W?nt:function(t,e){if(t=w(t),e=P(e,!0),et)try{return nt(t,e)}catch(t){/* empty */}if(D(t,e))return b(!q.f.call(t,e),t[e])}},at=Object.defineProperty,it={f:W?at:function(t,e,n){if(U(t),e=P(e,!0),U(n),et)try{return at(t,e,n)}catch(t){/* empty */}if("get"in n||"set"in n)throw TypeError("Accessors not supported");return"value"in n&&(t[e]=n.value),t}},ot=W?function(t,e,n){return it.f(t,e,b(1,n))}:function(t,e,n){return t[e]=n,t},st=C(function(t){var e="__core-js_shared__",n=z[e]||B(e,{});(t.exports=function(t,e){return n[t]||(n[t]=void 0!==e?e:{})})("versions",[]).push({version:"3.1.3",mode:"global",copyright:"© 2019 Denis Pushkarev (zloirock.ru)"})}),ct=st("native-function-to-string",Function.toString),lt=z.WeakMap,ut="function"==typeof lt&&/native code/.test(ct.call(lt)),dt=0,ht=Math.random(),ft=st("keys"),pt={},Et=z.WeakMap;if(ut){var St=new Et,mt=St.get,_t=St.has,At=St.set;G=function(t,e){return At.call(St,t,e),e},k=function(t){return mt.call(St,t)||{}},F=function(t){return _t.call(St,t)}}else{var gt=j("state");pt[gt]=!0,G=function(t,e){return ot(t,gt,e),e},k=function(t){return D(t,gt)?t[gt]:{}},F=function(t){return D(t,gt)}}function Tt(t){return isNaN(t=+t)?0:(0<t?Ht:Bt)(t)}function vt(t){return 0<t?jt(Tt(t),9007199254740991):0;// 2 ** 53 - 1 == 9007199254740991
}function yt(t,e){var n=Tt(t);return n<0?Gt(n+e,0):kt(n,e)}function Ot(t,e){var n,r=w(t),a=0,i=[];for(n in r)!D(pt,n)&&D(r,n)&&i.push(n);
// Don't enum bug & hidden keys
for(;e.length>a;)D(r,n=e[a++])&&(~Ft(i,n)||i.push(n));return i}function Ct(t,e){for(var n=qt(e),r=it.f,a=rt.f,i=0;i<n.length;i++){var o=n[i];D(t,o)||r(t,o,a(e,o))}}function Rt(t,e){var n=Qt[Kt(t)];return n==Jt||n!=Zt&&("function"==typeof e?N(e):!!e)}function Nt(t,e){var n,r,a,i,o,s=t.target,c=t.global,l=t.stat;if(n=c?z:l?z[s]||B(s,{}):(z[s]||{}).prototype)for(r in e){
// contained in target
if(i=e[r],a=t.noTargetGet?(o=ee(n,r))&&o.value:n[r],!te(c?r:s+(l?".":"#")+r,t.forced)&&void 0!==a){if(typeof i==typeof a)continue;Ct(i,a)}
// add a flag to not completely full polyfills
(t.sham||a&&a.sham)&&ot(i,"sham",!0),
// extend global
Ut(n,r,i,t)}}function bt(t){return Object(I(t))}function Lt(t,e,n){var r=P(e);r in t?it.f(t,r,b(0,n)):t[r]=n}function It(t){return ie[t]||(ie[t]=re&&ae[t]||(re?ae:H)("Symbol."+t))}function wt(t,e){var n;return ne(t)&&(
// cross-realm fallback
"function"!=typeof(n=t.constructor)||n!==Array&&!ne(n.prototype)?x(n)&&null===(n=n[oe])&&(n=void 0):n=void 0),new(void 0===n?Array:n)(0===e?0:e)}function xt(e){return!N(function(){var t=[];return(t.constructor={})[se]=function(){return{foo:1}},1!==t[e](Boolean).foo})}function Pt(t){if(!x(t))return!1;var e=t[ce];return void 0!==e?!!e:ne(t)}var Dt,Mt={set:G,get:k,has:F,enforce:function(t){return F(t)?k(t):G(t,{})},getterFor:function(n){return function(t){var e;if(!x(t)||(e=k(t)).type!==n)throw TypeError("Incompatible receiver, "+n+" required");return e}}},Ut=C(function(t){var e=Mt.get,s=Mt.enforce,c=String(ct).split("toString");st("inspectSource",function(t){return ct.call(t)}),(t.exports=function(t,e,n,r){var a=!!r&&!!r.unsafe,i=!!r&&!!r.enumerable,o=!!r&&!!r.noTargetGet;"function"==typeof n&&("string"!=typeof e||D(n,"name")||ot(n,"name",e),s(n).source=c.join("string"==typeof e?e:"")),t!==z?(a?!o&&t[e]&&(i=!0):delete t[e],i?t[e]=n:ot(t,e,n)):i?t[e]=n:B(e,n)})(Function.prototype,"toString",function(){return"function"==typeof this&&e(this).source||ct.call(this)})}),Bt=Math.ceil,Ht=Math.floor,jt=Math.min,Gt=Math.max,kt=Math.min,Ft=(Dt=!1,function(t,e,n){var r,a=w(t),i=vt(a.length),o=yt(n,i);
// Array#includes uses SameValueZero equality algorithm
// eslint-disable-next-line no-self-compare
if(Dt&&e!=e){for(;o<i;)
// eslint-disable-next-line no-self-compare
if((r=a[o++])!=r)return!0;
// Array#indexOf ignores holes, Array#includes - not
}else for(;o<i;o++)if((Dt||o in a)&&a[o]===e)return Dt||o||0;return!Dt&&-1}),Yt=["constructor","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","toLocaleString","toString","valueOf"],zt=Yt.concat("length","prototype"),Wt={f:Object.getOwnPropertyNames||function(t){return Ot(t,zt)}},Vt={f:Object.getOwnPropertySymbols},Xt=z.Reflect,qt=Xt&&Xt.ownKeys||function(t){var e=Wt.f(U(t)),n=Vt.f;return n?e.concat(n(t)):e},$t=/#|\.prototype\./,Kt=Rt.normalize=function(t){return String(t).replace($t,".").toLowerCase()},Qt=Rt.data={},Zt=Rt.NATIVE="N",Jt=Rt.POLYFILL="P",te=Rt,ee=rt.f,ne=Array.isArray||function(t){return"Array"==L(t)},re=!!Object.getOwnPropertySymbols&&!N(function(){
// Chrome 38 Symbol has incorrect toString conversion
// eslint-disable-next-line no-undef
return!String(Symbol())}),ae=z.Symbol,ie=st("wks"),oe=It("species"),se=It("species"),ce=It("isConcatSpreadable"),le=9007199254740991,ue="Maximum allowed index exceeded",de=!N(function(){var t=[];return t[ce]=!1,t.concat()[0]!==t}),he=xt("concat");
// `Array.prototype.concat` method
// https://tc39.github.io/ecma262/#sec-array.prototype.concat
// with adding support of @@isConcatSpreadable and @@species
Nt({target:"Array",proto:!0,forced:!de||!he},{concat:function(t){// eslint-disable-line no-unused-vars
var e,n,r,a,i,o=bt(this),s=wt(o,0),c=0;for(e=-1,r=arguments.length;e<r;e++)if(Pt(i=-1===e?o:arguments[e])){if(a=vt(i.length),le<c+a)throw TypeError(ue);for(n=0;n<a;n++,c++)n in i&&Lt(s,c,i[n])}else{if(le<=c)throw TypeError(ue);Lt(s,c++,i)}return s.length=c,s}});function fe(t){if("function"!=typeof t)throw TypeError(String(t)+" is not a function");return t}function pe(r,a,t){if(fe(r),void 0===a)return r;switch(t){case 0:return function(){return r.call(a)};case 1:return function(t){return r.call(a,t)};case 2:return function(t,e){return r.call(a,t,e)};case 3:return function(t,e,n){return r.call(a,t,e,n)}}return function(){return r.apply(a,arguments)}}function Ee(d,t){var h=1==d,f=2==d,p=3==d,E=4==d,S=6==d,m=5==d||S,_=t||wt;return function(t,e,n){for(var r,a,i=bt(t),o=Q(i),s=pe(e,n,3),c=vt(o.length),l=0,u=h?_(t,c):f?_(t,0):void 0;l<c;l++)if((m||l in o)&&(a=s(r=o[l],l,i),d))if(h)u[l]=a;// map
else if(a)switch(d){case 3:return!0;// some
case 5:return r;// find
case 6:return l;// findIndex
case 2:u.push(r);// filter
}else if(E)return!1;// every
return S?-1:p||E?E:u}}function Se(){/* empty */}var me=Object.keys||function(t){return Ot(t,Yt)},_e=W?Object.defineProperties:function(t,e){U(t);for(var n,r=me(e),a=r.length,i=0;i<a;)it.f(t,n=r[i++],e[n]);return t},Ae=z.document,ge=Ae&&Ae.documentElement,Te=j("IE_PROTO"),ve="prototype",ye=function(){
// Thrash, waste and sodomy: IE GC bug
var t,e=M("iframe"),n=Yt.length,r="script";for(e.style.display="none",ge.appendChild(e),e.src=String("javascript:"),(t=e.contentWindow.document).open(),t.write("<script>document.F=Object</"+r+">"),t.close(),ye=t.F;n--;)delete ye[ve][Yt[n]];return ye()},Oe=Object.create||function(t,e){var n;return null!==t?(Se[ve]=U(t),n=new Se,Se[ve]=null,
// add "__proto__" for Object.getPrototypeOf polyfill
n[Te]=t):n=ye(),void 0===e?n:_e(n,e)};
// optional / simple context binding
pt[Te]=!0;var Ce=It("unscopables"),Re=Array.prototype;
// Array.prototype[@@unscopables]
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
null==Re[Ce]&&ot(Re,Ce,Oe(null));
// add a key to Array.prototype[@@unscopables]
function Ne(t){Re[Ce][t]=!0}var be=Ee(5),Le="find",Ie=!0;
// Shouldn't skip holes
Le in[]&&Array(1)[Le](function(){Ie=!1}),
// `Array.prototype.find` method
// https://tc39.github.io/ecma262/#sec-array.prototype.find
Nt({target:"Array",proto:!0,forced:Ie},{find:function(t/* , that = undefined */,e){return be(this,t,1<arguments.length?e:void 0)}}),
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
Ne(Le);function we(t){var e,n,r;return void 0===t?"Undefined":null===t?"Null":"string"==typeof(n=function(t,e){try{return t[e]}catch(t){/* empty */}}(e=Object(t),xe))?n:Pe?L(e):"Object"==(r=L(e))&&"function"==typeof e.callee?"Arguments":r}var xe=It("toStringTag"),Pe="Arguments"==L(function(){return arguments}()),De={};
// ES3 wrong here
De[It("toStringTag")]="z";
// `Object.prototype.toString` method implementation
// https://tc39.github.io/ecma262/#sec-object.prototype.tostring
var Me="[object z]"!==String(De)?function(){return"[object "+we(this)+"]"}:De.toString,Ue=Object.prototype;
// `Object.prototype.toString` method
// https://tc39.github.io/ecma262/#sec-object.prototype.tostring
Me!==Ue.toString&&Ut(Ue,"toString",Me,{unsafe:!0});
// `RegExp.prototype.flags` getter implementation
// https://tc39.github.io/ecma262/#sec-get-regexp.prototype.flags
function Be(){var t=U(this),e="";return t.global&&(e+="g"),t.ignoreCase&&(e+="i"),t.multiline&&(e+="m"),t.unicode&&(e+="u"),t.sticky&&(e+="y"),e}var He="toString",je=/./[He],Ge=RegExp.prototype,ke=N(function(){return"/a/b"!=je.call({source:"a",flags:"b"})}),Fe=je.name!=He;
// `RegExp.prototype.toString` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype.tostring
(ke||Fe)&&Ut(RegExp.prototype,He,function(){var t=U(this),e=String(t.source),n=t.flags;return"/"+e+"/"+String(void 0===n&&t instanceof RegExp&&!("flags"in Ge)?Be.call(t):n)},{unsafe:!0});var Ye,ze,We=RegExp.prototype.exec,Ve=String.prototype.replace,Xe=We,qe=(Ye=/a/,ze=/b*/g,We.call(Ye,"a"),We.call(ze,"a"),0!==Ye.lastIndex||0!==ze.lastIndex),$e=void 0!==/()??/.exec("")[1];
// This always refers to the native implementation, because the
// String#replace polyfill uses ./fix-regexp-well-known-symbol-logic.js,
// which loads this file before patching the method.
(qe||$e)&&(Xe=function(t){var e,n,r,a,i=this;return $e&&(n=new RegExp("^"+i.source+"$(?!\\s)",Be.call(i))),qe&&(e=i.lastIndex),r=We.call(i,t),qe&&r&&(i.lastIndex=i.global?r.index+r[0].length:e),$e&&r&&1<r.length&&
// Fix browsers whose `exec` methods don't consistently return `undefined`
// for NPCG, like IE8. NOTE: This doesn' work for /(.?)?/
Ve.call(r[0],n,function(){for(a=1;a<arguments.length-2;a++)void 0===arguments[a]&&(r[a]=void 0)}),r});function Ke(n,t,e,r){var a=It(n),i=!N(function(){
// String methods call symbol-named RegEp methods
var t={};return t[a]=function(){return 7},7!=""[n](t)}),o=i&&!N(function(){
// Symbol-named RegExp methods call .exec
var t=!1,e=/a/;return e.exec=function(){return t=!0,null},"split"===n&&(
// RegExp[@@split] doesn't call the regex's exec method, but first creates
// a new one. We need to return the patched regex when creating the new one.
e.constructor={},e.constructor[en]=function(){return e}),e[a](""),!t});if(!i||!o||"replace"===n&&!nn||"split"===n&&!rn){var s=/./[a],c=e(a,""[n],function(t,e,n,r,a){return e.exec===tn?i&&!a?{done:!0,value:s.call(e,n,r)}:{done:!0,value:t.call(n,e,r)}:{done:!1}}),l=c[0],u=c[1];Ut(String.prototype,n,l),Ut(RegExp.prototype,a,2==t?function(t,e){return u.call(t,this,e)}
// 21.2.5.6 RegExp.prototype[@@match](string)
// 21.2.5.9 RegExp.prototype[@@search](string)
:function(t){return u.call(t,this)}),r&&ot(RegExp.prototype[a],"sham",!0)}}function Qe(t,e,n){var r,a,i=String(I(t)),o=Tt(e),s=i.length;return o<0||s<=o?n?"":void 0:(r=i.charCodeAt(o))<55296||56319<r||o+1===s||(a=i.charCodeAt(o+1))<56320||57343<a?n?i.charAt(o):r:n?i.slice(o,o+2):a-56320+(r-55296<<10)+65536}function Ze(t,e,n){return e+(n?Qe(t,e,!0).length:1)}function Je(t,e){var n=t.exec;if("function"==typeof n){var r=n.call(t,e);if("object"!=typeof r)throw TypeError("RegExp exec method returned something other than an Object or null");return r}if("RegExp"!==L(t))throw TypeError("RegExp#exec called on incompatible receiver");return tn.call(t,e)}var tn=Xe,en=It("species"),nn=!N(function(){
// #replace needs built-in support for named groups.
// #match works fine because it just return the exec results, even if it has
// a "grops" property.
var t=/./;return t.exec=function(){var t=[];return t.groups={a:"7"},t},"7"!=="".replace(t,"$<a>")}),rn=!N(function(){var t=/(?:)/,e=t.exec;t.exec=function(){return e.apply(this,arguments)};var n="ab".split(t);return 2!==n.length||"a"!==n[0]||"b"!==n[1]}),an=Math.max,on=Math.min,sn=Math.floor,cn=/\$([$&'`]|\d\d?|<[^>]*>)/g,ln=/\$([$&'`]|\d\d?)/g;
// @@replace logic
Ke("replace",2,function(a,T,v){return[
// `String.prototype.replace` method
// https://tc39.github.io/ecma262/#sec-string.prototype.replace
function(t,e){var n=I(this),r=null==t?void 0:t[a];return void 0!==r?r.call(t,n,e):T.call(String(n),t,e)},
// `RegExp.prototype[@@replace]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@replace
function(t,e){var n=v(T,t,this,e);if(n.done)return n.value;var r=U(t),a=String(this),i="function"==typeof e;i||(e=String(e));var o=r.global;if(o){var s=r.unicode;r.lastIndex=0}for(var c=[];;){var l=Je(r,a);if(null===l)break;if(c.push(l),!o)break;""===String(l[0])&&(r.lastIndex=Ze(a,vt(r.lastIndex),s))}for(var u,d="",h=0,f=0;f<c.length;f++){l=c[f];
// NOTE: This is equivalent to
//   captures = result.slice(1).map(maybeToString)
// but for some reason `nativeSlice.call(result, 1, result.length)` (called in
// the slice polyfill when slicing native arrays) "doesn't work" in safari 9 and
// causes a crash (https://pastebin.com/N21QzeQA) when trying to debug it.
for(var p=String(l[0]),E=an(on(Tt(l.index),a.length),0),S=[],m=1;m<l.length;m++)S.push(void 0===(u=l[m])?u:String(u));var _=l.groups;if(i){var A=[p].concat(S,E,a);void 0!==_&&A.push(_);var g=String(e.apply(void 0,A))}else g=y(p,a,E,S,_,e);h<=E&&(d+=a.slice(h,E)+g,h=E+p.length)}return d+a.slice(h)}];
// https://tc39.github.io/ecma262/#sec-getsubstitution
function y(i,o,s,c,l,t){var u=s+i.length,d=c.length,e=ln;return void 0!==l&&(l=bt(l),e=cn),T.call(t,e,function(t,e){var n;switch(e.charAt(0)){case"$":return"$";case"&":return i;case"`":return o.slice(0,s);case"'":return o.slice(u);case"<":n=l[e.slice(1,-1)];break;default:// \d\d?
var r=+e;if(0==r)return t;if(d<r){var a=sn(r/10);return 0===a?t:a<=d?void 0===c[a-1]?e.charAt(1):c[a-1]+e.charAt(1):t}n=c[r-1]}return void 0===n?"":n})}});var un,dn={createHeaderStructure:(un={ATTRIBUTES:{DATA_INPUT:"data-input"},CLASSES:{PARENT_COMPONENT:".js-component--parent",RELATIVE_HEADING_1:".calculator__heading--1",RELATIVE_HEADING_2:".calculator__heading--2",RELATIVE_HEADING_3:".calculator__heading--3",RELATIVE_HEADING_4:".calculator__heading--4",TAB_COMPONENT_WRAPPER:".js-tabs-wrapper"},CLASSES_NO_DOT:{IS_ACTIVE:"is-active",SCREEN_READER_ONLY:"screen-reader-only"},createHeaderStructure:function(t){
// creates a header structure by looking at the top heading level of the parent
// component that contains the calculator
var e=t.closest(un.CLASSES.TAB_COMPONENT_WRAPPER),n=t.closest(un.CLASSES.PARENT_COMPONENT),r=1;if(// tabs have a different structure, check for a tab wrapper around a column
e.length&&(n=e),n.length){var a=1;n.find(":header").each(function(t,e){var n=d(e),r=1;n.is("h2")?r=2:n.is("h3")?r=3:n.is("h4")?r=4:n.is("h5")?r=5:n.is("h6")&&(r=6),a<r&&(a=r)}),r=a}un.convertElementToHeader(n,un.CLASSES.RELATIVE_HEADING_1,r+1),un.convertElementToHeader(n,un.CLASSES.RELATIVE_HEADING_2,r+2),un.convertElementToHeader(n,un.CLASSES.RELATIVE_HEADING_3,r+3),un.convertElementToHeader(n,un.CLASSES.RELATIVE_HEADING_4,r+4)},convertElementToHeader:function(t,e,a){
// copies the attributes of an element and then replaces that element
// with a header with headerLevel and the same attributes and content
t.find(e).each(function(t,e){var n=d(e),r={};d.each(n.get(0).attributes,function(t,e){r[e.nodeName]=e.nodeValue}),n.replaceWith(d("<h".concat(a," />"),r).append(n.contents()))})},monitorPositiveNumberInput:function(t){
// disallow negative signs and periods in positive number fields
/* eslint-disable operator-linebreak */
"."!==t.key&&"-"!==t.key&&","!==t.key&&"e"!==t.key||t.preventDefault()
/* eslint-enable operator-linebreak */},
// increase and reset icon size
increaseIconSize:function(t){var e=d(t.target).attr("id");d("[".concat(un.ATTRIBUTES.DATA_INPUT,'="').concat(e,'"]')).addClass(un.CLASSES_NO_DOT.IS_ACTIVE)},resetIconSize:function(t){var e=d(t.target).attr("id");d("[".concat(un.ATTRIBUTES.DATA_INPUT,'="').concat(e,'"]')).removeClass(un.CLASSES_NO_DOT.IS_ACTIVE)},
// make elements screen reader only or visible
makeScreenReaderOnly:function(t){d(t.target).attr("id");d(t.target).addClass(un.CLASSES_NO_DOT.SCREEN_READER_ONLY)},makeVisible:function(t){d(t.target).removeClass(un.CLASSES_NO_DOT.SCREEN_READER_ONLY)},formatNumberWithCommas:function(t){return t.toString().replace(/\B(?=(\d{3})+(?!\d))/g,",")}}).createHeaderStructure,monitorPositiveNumberInput:un.monitorPositiveNumberInput,increaseIconSize:un.increaseIconSize,resetIconSize:un.resetIconSize,makeScreenReaderOnly:un.makeScreenReaderOnly,makeVisible:un.makeVisible,formatNumberWithCommas:un.formatNumberWithCommas},hn=It("species"),fn=[].slice,pn=Math.max,En=xt("slice");
// `Array.prototype.slice` method
// https://tc39.github.io/ecma262/#sec-array.prototype.slice
// fallback for not array-like ES3 strings and DOM objects
Nt({target:"Array",proto:!0,forced:!En},{slice:function(t,e){var n,r,a,i=w(this),o=vt(i.length),s=yt(t,o),c=yt(void 0===e?o:e,o);if(ne(i)&&(
// cross-realm fallback
"function"!=typeof(n=i.constructor)||n!==Array&&!ne(n.prototype)?x(n)&&null===(n=n[hn])&&(n=void 0):n=void 0,n===Array||void 0===n))return fn.call(i,s,c);for(r=new(void 0===n?Array:n)(pn(c-s,0)),a=0;s<c;s++,a++)s in i&&Lt(r,a,i[s]);return r.length=a,r}});function Sn(t,e){var n=[][t];return!n||!N(function(){
// eslint-disable-next-line no-useless-call,no-throw-literal
n.call(null,e||function(){throw 1},1)})}var mn=[].sort,_n=[1,2,3],An=N(function(){_n.sort(void 0)}),gn=N(function(){_n.sort(null)}),Tn=Sn("sort");
// `Array.prototype.sort` method
// https://tc39.github.io/ecma262/#sec-array.prototype.sort
Nt({target:"Array",proto:!0,forced:An||!gn||Tn},{sort:function(t){return void 0===t?mn.call(bt(this)):mn.call(bt(this),fe(t))}});
// `Array.prototype.fill` method
// https://tc39.github.io/ecma262/#sec-array.prototype.fill
Nt({target:"Array",proto:!0},{fill:function(t/* , start = 0, end = @length */,e,n){for(var r=bt(this),a=vt(r.length),i=arguments.length,o=yt(1<i?e:void 0,a),s=2<i?n:void 0,c=void 0===s?a:yt(s,a);o<c;)r[o++]=t;return r}}),
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
Ne("fill");var vn=Ee(2),yn=xt("filter");
// `Array.prototype.filter` method
// https://tc39.github.io/ecma262/#sec-array.prototype.filter
// with adding support of @@species
Nt({target:"Array",proto:!0,forced:!yn},{filter:function(t/* , thisArg */,e){return vn(this,t,e)}});var On,Cn,Rn,Nn={},bn=!N(function(){function t(){/* empty */}return t.prototype.constructor=null,Object.getPrototypeOf(new t)!==t.prototype}),Ln=j("IE_PROTO"),In=Object.prototype,wn=bn?Object.getPrototypeOf:function(t){return t=bt(t),D(t,Ln)?t[Ln]:"function"==typeof t.constructor&&t instanceof t.constructor?t.constructor.prototype:t instanceof Object?In:null},xn=It("iterator"),Pn=!1;[].keys&&(
// Safari 8 has buggy iterators w/o `next`
"next"in(Rn=[].keys())?(Cn=wn(wn(Rn)))!==Object.prototype&&(On=Cn):Pn=!0),null==On&&(On={}),
// 25.1.2.1.1 %IteratorPrototype%[@@iterator]()
D(On,xn)||ot(On,xn,function(){return this});function Dn(t,e,n){t&&!D(t=n?t:t.prototype,Gn)&&jn(t,Gn,{configurable:!0,value:e})}function Mn(){return this}function Un(){return this}function Bn(t,e,n,r,a,i,o){function s(t){if(t===a&&E)return E;if(!zn&&t in f)return f[t];switch(t){case"keys":case Vn:case Xn:return function(){return new n(this,t)}}return function(){return new n(this)}}!function(t,e,n){var r=e+" Iterator";t.prototype=Oe(kn,{next:b(1,n)}),Dn(t,r,!1),Nn[r]=Mn}(n,e,r);var c,l,u,d=e+" Iterator",h=!1,f=t.prototype,p=f[Wn]||f["@@iterator"]||a&&f[a],E=!zn&&p||s(a),S="Array"==e&&f.entries||p;
// export additional methods
if(
// fix native
S&&(c=wn(S.call(new t)),Yn!==Object.prototype&&c.next&&(wn(c)!==Yn&&(Fn?Fn(c,Yn):"function"!=typeof c[Wn]&&ot(c,Wn,Un)),
// Set @@toStringTag to native iterators
Dn(c,d,!0))),
// fix Array#{values, @@iterator}.name in V8 / FF
a==Vn&&p&&p.name!==Vn&&(h=!0,E=function(){return p.call(this)}),
// define iterator
f[Wn]!==E&&ot(f,Wn,E),Nn[e]=E,a)if(l={values:s(Vn),keys:i?E:s("keys"),entries:s(Xn)},o)for(u in l)!zn&&!h&&u in f||Ut(f,u,l[u]);else Nt({target:e,proto:!0,forced:zn||h},l);return l}var Hn={IteratorPrototype:On,BUGGY_SAFARI_ITERATORS:Pn},jn=it.f,Gn=It("toStringTag"),kn=Hn.IteratorPrototype,Fn=Object.setPrototypeOf||("__proto__"in{}?function(){var n,r=!1,t={};try{(n=Object.getOwnPropertyDescriptor(Object.prototype,"__proto__").set).call(t,[]),r=t instanceof Array}catch(t){/* empty */}return function(t,e){return function(t,e){if(U(t),!x(e)&&null!==e)throw TypeError("Can't set "+String(e)+" as a prototype")}(t,e),r?n.call(t,e):t.__proto__=e,t}}():void 0),Yn=Hn.IteratorPrototype,zn=Hn.BUGGY_SAFARI_ITERATORS,Wn=It("iterator"),Vn="values",Xn="entries",qn="Array Iterator",$n=Mt.set,Kn=Mt.getterFor(qn),Qn=Bn(Array,"Array",function(t,e){$n(this,{type:qn,target:w(t),// target
index:0,// next index
kind:e});
// `%ArrayIteratorPrototype%.next` method
// https://tc39.github.io/ecma262/#sec-%arrayiteratorprototype%.next
},function(){var t=Kn(this),e=t.target,n=t.kind,r=t.index++;return!e||r>=e.length?{value:t.target=void 0,done:!0}:"keys"==n?{value:r,done:!1}:"values"==n?{value:e[r],done:!1}:{value:[r,e[r]],done:!1}},"values");
// argumentsList[@@iterator] is %ArrayProto_values%
// https://tc39.github.io/ecma262/#sec-createunmappedargumentsobject
// https://tc39.github.io/ecma262/#sec-createmappedargumentsobject
Nn.Arguments=Nn.Array,
// https://tc39.github.io/ecma262/#sec-array.prototype-@@unscopables
Ne("keys"),Ne("values"),Ne("entries");var Zn=[].join,Jn=Q!=Object,tr=Sn("join",",");
// `Array.prototype.join` method
// https://tc39.github.io/ecma262/#sec-array.prototype.join
Nt({target:"Array",proto:!0,forced:Jn||tr},{join:function(t){return Zn.call(w(this),void 0===t?",":t)}});var er=Ee(1),nr=xt("map");
// `Array.prototype.map` method
// https://tc39.github.io/ecma262/#sec-array.prototype.map
// with adding support of @@species
Nt({target:"Array",proto:!0,forced:!nr},{map:function(t/* , thisArg */,e){return er(this,t,e)}});var rr=Math.max,ar=Math.min,ir=xt("splice");
// `Array.prototype.splice` method
// https://tc39.github.io/ecma262/#sec-array.prototype.splice
// with adding support of @@species
Nt({target:"Array",proto:!0,forced:!ir},{splice:function(t,e/* , ...items */){var n,r,a,i,o,s,c=bt(this),l=vt(c.length),u=yt(t,l),d=arguments.length;if(0===d?n=r=0:r=1===d?(n=0,l-u):(n=d-2,ar(rr(Tt(e),0),l-u)),9007199254740991<l+n-r)throw TypeError("Maximum allowed length exceeded");for(a=wt(c,r),i=0;i<r;i++)(o=u+i)in c&&Lt(a,i,c[o]);if(n<(a.length=r)){for(i=u;i<l-r;i++)s=i+n,(o=i+r)in c?c[s]=c[o]:delete c[s];for(i=l;l-r+n<i;i--)delete c[i-1]}else if(r<n)for(i=l-r;u<i;i--)s=i+n-1,(o=i+r-1)in c?c[s]=c[o]:delete c[s];for(i=0;i<n;i++)c[i+u]=arguments[i+2];return c.length=l-r+n,a}});var or=it.f,sr=Function.prototype,cr=sr.toString,lr=/^\s*function ([^ (]*)/;
// Function instances `.name` property
// https://tc39.github.io/ecma262/#sec-function-instances-name
!W||"name"in sr||or(sr,"name",{configurable:!0,get:function(){try{return cr.call(this).match(lr)[1]}catch(t){return""}}});function ur(t,e,n){var r,a=e.constructor;return a!==n&&"function"==typeof a&&(r=a.prototype)!==n.prototype&&x(r)&&Fn&&Fn(t,r),t}function dr(t,e){return t=String(I(t)),1&e&&(t=t.replace(Er,"")),2&e&&(t=t.replace(Sr,"")),t}function hr(t){var e,n,r,a,i,o,s,c,l=P(t,!1);if("string"==typeof l&&2<l.length)if(43===(e=(l=Or?l.trim():dr(l,3)).charCodeAt(0))||45===e){if(88===(n=l.charCodeAt(2))||120===n)return NaN;// Number('+0x1') should be NaN, old V8 fix
}else if(48===e){switch(l.charCodeAt(1)){case 66:case 98:r=2,a=49;break;// fast equal of /^0b[01]+$/i
case 79:case 111:r=8,a=55;break;// fast equal of /^0o[0-7]+$/i
default:return+l}for(o=(i=l.slice(2)).length,s=0;s<o;s++)
// parseInt parses a string to a first unavailable symbol
// but ToNumber should return NaN if a string contains unavailable symbols
if((c=i.charCodeAt(s))<48||a<c)return NaN;return parseInt(i,r)}return+l}var fr="\t\n\v\f\r                　\u2028\u2029\ufeff",pr="["+fr+"]",Er=RegExp("^"+pr+pr+"*"),Sr=RegExp(pr+pr+"*$"),mr=Wt.f,_r=rt.f,Ar=it.f,gr="Number",Tr=z[gr],vr=Tr.prototype,yr=L(Oe(vr))==gr,Or="trim"in String.prototype;
// a string of all valid unicode whitespaces
// eslint-disable-next-line max-len
// `Number` constructor
// https://tc39.github.io/ecma262/#sec-number-constructor
if(te(gr,!Tr(" 0o1")||!Tr("0b1")||Tr("+0x1"))){for(var Cr,Rr=function(t){var e=arguments.length<1?0:t,n=this;return n instanceof Rr&&(yr?N(function(){vr.valueOf.call(n)}):L(n)!=gr)?ur(new Tr(hr(e)),n,Rr):hr(e)},Nr=W?mr(Tr):
// ES3:
"MAX_VALUE,MIN_VALUE,NaN,NEGATIVE_INFINITY,POSITIVE_INFINITY,EPSILON,isFinite,isInteger,isNaN,isSafeInteger,MAX_SAFE_INTEGER,MIN_SAFE_INTEGER,parseFloat,parseInt,isInteger".split(","),br=0;Nr.length>br;br++)D(Tr,Cr=Nr[br])&&!D(Rr,Cr)&&Ar(Rr,Cr,_r(Tr,Cr));(Rr.prototype=vr).constructor=Rr,Ut(z,gr,Rr)}var Lr=rt.f,Ir=N(function(){Lr(1)});
// `Object.getOwnPropertyDescriptor` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertydescriptor
Nt({target:"Object",stat:!0,forced:!W||Ir,sham:!W},{getOwnPropertyDescriptor:function(t,e){return Lr(w(t),e)}});var wr=Wt.f,xr={}.toString,Pr="object"==typeof window&&window&&Object.getOwnPropertyNames?Object.getOwnPropertyNames(window):[],Dr={f:function(t){return Pr&&"[object Window]"==xr.call(t)?function(t){try{return wr(t)}catch(t){return Pr.slice()}}(t):wr(w(t))}},Mr=Dr.f,Ur=N(function(){return!Object.getOwnPropertyNames(1)});
// `Object.getOwnPropertyNames` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertynames
Nt({target:"Object",stat:!0,forced:Ur},{getOwnPropertyNames:Mr});var Br=N(function(){me(1)});
// `Object.keys` method
// https://tc39.github.io/ecma262/#sec-object.keys
Nt({target:"Object",stat:!0,forced:Br},{keys:function(t){return me(bt(t))}});function Hr(t){var e;return x(t)&&(void 0!==(e=t[kr])?!!e:"RegExp"==L(t))}function jr(t){return"function"==typeof t?t:void 0}function Gr(t){var e=function(t,e){return arguments.length<2?jr(Fr[t])||jr(z[t]):Fr[t]&&Fr[t][e]||z[t]&&z[t][e]}(t),n=it.f;W&&e&&!e[Yr]&&n(e,Yr,{configurable:!0,get:function(){return this}})}var kr=It("match"),Fr=z,Yr=It("species"),zr=it.f,Wr=Wt.f,Vr=It("match"),Xr=z.RegExp,qr=Xr.prototype,$r=/a/g,Kr=/a/g,Qr=new Xr($r)!==$r;
// `IsRegExp` abstract operation
// https://tc39.github.io/ecma262/#sec-isregexp
// `RegExp` constructor
// https://tc39.github.io/ecma262/#sec-regexp-constructor
if(te("RegExp",W&&(!Qr||N(function(){
// RegExp constructor can alter flags and IsRegExp works correct with @@match
return Kr[Vr]=!1,Xr($r)!=$r||Xr(Kr)==Kr||"/a/i"!=Xr($r,"i")})))){for(var Zr=function(t,e){var n=this instanceof Zr,r=Hr(t),a=void 0===e;return!n&&r&&t.constructor===Zr&&a?t:ur(Qr?new Xr(r&&!a?t.source:t,e):Xr((r=t instanceof Zr)?t.source:t,r&&a?Be.call(t):e),n?this:qr,Zr)},Jr=function(e){e in Zr||zr(Zr,e,{configurable:!0,get:function(){return Xr[e]},set:function(t){Xr[e]=t}})},ta=Wr(Xr),ea=0;ea<ta.length;)Jr(ta[ea++]);(qr.constructor=Zr).prototype=qr,Ut(z,"RegExp",Zr)}
// https://tc39.github.io/ecma262/#sec-get-regexp-@@species
Gr("RegExp"),
// @@match logic
Ke("match",1,function(r,l,u){return[
// `String.prototype.match` method
// https://tc39.github.io/ecma262/#sec-string.prototype.match
function(t){var e=I(this),n=null==t?void 0:t[r];return void 0!==n?n.call(t,e):new RegExp(t)[r](String(e))},
// `RegExp.prototype[@@match]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@match
function(t){var e=u(l,t,this);if(e.done)return e.value;var n=U(t),r=String(this);if(!n.global)return Je(n,r);for(var a,i=n.unicode,o=[],s=n.lastIndex=0;null!==(a=Je(n,r));){var c=String(a[0]);""===(o[s]=c)&&(n.lastIndex=Ze(r,vt(n.lastIndex),i)),s++}return 0===s?null:o}]});function na(t,e){var n,r=U(t).constructor;return void 0===r||null==(n=U(r)[ra])?e:fe(n)}var ra=It("species"),aa=[].push,ia=Math.min,oa=4294967295,sa=!N(function(){return!RegExp(oa,"y")});
// `SpeciesConstructor` abstract operation
// https://tc39.github.io/ecma262/#sec-speciesconstructor
// @@split logic
Ke("split",2,function(a,S,m){var _;
// based on es5-shim implementation, need to rework it
return _="c"=="abbc".split(/(b)*/)[1]||4!="test".split(/(?:)/,-1).length||2!="ab".split(/(?:ab)*/).length||4!=".".split(/(.?)(.?)/).length||1<".".split(/()()/).length||"".split(/.?/).length?function(t,e){var n=String(I(this)),r=void 0===e?oa:e>>>0;if(0==r)return[];if(void 0===t)return[n];
// If `separator` is not a regex, use native split
if(!Hr(t))return S.call(n,t,r);for(var a,i,o,s=[],c=(t.ignoreCase?"i":"")+(t.multiline?"m":"")+(t.unicode?"u":"")+(t.sticky?"y":""),l=0,u=new RegExp(t.source,c+"g");(a=tn.call(u,n))&&!(l<(i=u.lastIndex)&&(s.push(n.slice(l,a.index)),1<a.length&&a.index<n.length&&aa.apply(s,a.slice(1)),o=a[0].length,l=i,s.length>=r));)u.lastIndex===a.index&&u.lastIndex++;// Avoid an infinite loop
return l===n.length?!o&&u.test("")||s.push(""):s.push(n.slice(l)),s.length>r?s.slice(0,r):s}:"0".split(void 0,0).length?function(t,e){return void 0===t&&0===e?[]:S.call(this,t,e)}:S,[
// `String.prototype.split` method
// https://tc39.github.io/ecma262/#sec-string.prototype.split
function(t,e){var n=I(this),r=null==t?void 0:t[a];return void 0!==r?r.call(t,n,e):_.call(String(n),t,e)},
// `RegExp.prototype[@@split]` method
// https://tc39.github.io/ecma262/#sec-regexp.prototype-@@split
//
// NOTE: This cannot be properly polyfilled in engines that don't support
// the 'y' flag.
function(t,e){var n=m(_,t,this,e,_!==S);if(n.done)return n.value;var r=U(t),a=String(this),i=na(r,RegExp),o=r.unicode,s=(r.ignoreCase?"i":"")+(r.multiline?"m":"")+(r.unicode?"u":"")+(sa?"y":"g"),c=new i(sa?r:"^(?:"+r.source+")",s),l=void 0===e?oa:e>>>0;if(0==l)return[];if(0===a.length)return null===Je(c,a)?[a]:[];for(var u=0,d=0,h=[];d<a.length;){c.lastIndex=sa?d:0;var f,p=Je(c,sa?a:a.slice(d));if(null===p||(f=ia(vt(c.lastIndex+(sa?0:d)),a.length))===u)d=Ze(a,d,o);else{if(h.push(a.slice(u,d)),h.length===l)return h;for(var E=1;E<=p.length-1;E++)if(h.push(p[E]),h.length===l)return h;d=u=f}}return h.push(a.slice(u)),h}]},!sa);var ca,la=(ca="trim",N(function(){return!!fr[ca]()||"​᠎"!="​᠎"[ca]()||fr[ca].name!==ca}));
// check that a method works with the correct list
// of whitespaces and has a correct name
// `String.prototype.trim` method
// https://tc39.github.io/ecma262/#sec-string.prototype.trim
Nt({target:"String",proto:!0,forced:la},{trim:function(){return dr(this,3)}});
// iterable DOM collections
// flag - `iterable` interface - 'entries', 'keys', 'values', 'forEach' methods
var ua={CSSRuleList:0,CSSStyleDeclaration:0,CSSValueList:0,ClientRectList:0,DOMRectList:0,DOMStringList:0,DOMTokenList:1,DataTransferItemList:0,FileList:0,HTMLAllCollection:0,HTMLCollection:0,HTMLFormElement:0,HTMLSelectElement:0,MediaList:0,MimeTypeArray:0,NamedNodeMap:0,NodeList:1,PaintRequestList:0,Plugin:0,PluginArray:0,SVGLengthList:0,SVGNumberList:0,SVGPathSegList:0,SVGPointList:0,SVGStringList:0,SVGTransformList:0,SourceBufferList:0,StyleSheetList:0,TextTrackCueList:0,TextTrackList:0,TouchList:0},da=Ee(0),ha=Sn("forEach")?function(t/* , thisArg */,e){return da(this,t,e)}:[].forEach;for(var fa in ua){var pa=z[fa],Ea=pa&&pa.prototype;
// some Chrome versions have non-configurable methods on DOMTokenList
if(Ea&&Ea.forEach!==ha)try{ot(Ea,"forEach",ha)}catch(t){Ea.forEach=ha}}var Sa=It("iterator"),ma=It("toStringTag"),_a=Qn.values;for(var Aa in ua){var ga=z[Aa],Ta=ga&&ga.prototype;if(Ta){
// some Chrome versions have non-configurable methods on DOMTokenList
if(Ta[Sa]!==_a)try{ot(Ta,Sa,_a)}catch(t){Ta[Sa]=_a}if(Ta[ma]||ot(Ta,ma,Aa),ua[Aa])for(var va in Qn)
// some Chrome versions have non-configurable methods on DOMTokenList
if(Ta[va]!==Qn[va])try{ot(Ta,va,Qn[va])}catch(t){Ta[va]=Qn[va]}}}function ya(t){return(ya="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t})(t)}function Oa(t,e,n){return e in t?Object.defineProperty(t,e,{value:n,enumerable:!0,configurable:!0,writable:!0}):t[e]=n,t}
/* eslint-disable */function Ca(e,t,n,r){try{return r?t(U(n)[0],n[1]):t(n);
// 7.4.6 IteratorClose(iterator, completion)
}catch(t){var a=e.return;throw void 0!==a&&U(a.call(e)),t}}var Ra,Na,ba,La={initChartist:(Ra={intialized:!1,initChartist:function(){
// ensure that this module is only initialized once
Ra.initialized||Ra.initChartistHelper()},initChartistHelper:function(){var t,e;
// ensure that this module is only initialized once
Ra.initialized=!0,e=function(){
/* Chartist.js 0.11.0
           * Copyright © 2017 Gion Kunz
           * Free to use under either the WTFPL license or the MIT license.
           * https://raw.githubusercontent.com/gionkunz/chartist-js/master/LICENSE-WTFPL
           * https://raw.githubusercontent.com/gionkunz/chartist-js/master/LICENSE-MIT
           */
/**
           * The core module of Chartist that is mainly providing static functions and higher level functions for chart modules.
           *
           * @module Chartist.Core
           */
var l,p,E,S,i,o,s,c,u,n,h,a,d,f,m,_,A,v,y,N,b,t={version:"0.11.0"};function g(t,e,n,r,a,i){var o=c.extend({command:a?t.toLowerCase():t.toUpperCase()},e,i?{data:i}:{});n.splice(r,0,o)}function e(a,i){a.forEach(function(n,r){u[n.command.toLowerCase()].forEach(function(t,e){i(n,t,r,e,a)})})}
/**
             * Used to construct a new path object.
             *
             * @memberof Chartist.Svg.Path
             * @param {Boolean} close If set to true then this path will be closed when stringified (with a Z at the end)
             * @param {Object} options Options object that overrides the default objects. See default options for more details.
             * @constructor
             */
/**
             * Determines SVG anchor position based on direction and center parameter
             *
             * @param center
             * @param label
             * @param direction
             * @return {string}
             */
function L(t,e,n){var r=e.x>t.x;return r&&"explode"===n||!r&&"implode"===n?"start":r&&"implode"===n||!r&&"explode"===n?"end":"middle"}
/**
             * Creates the pie chart
             *
             * @param options
             */l=window,p=document,
/**
             * This object contains all namespaces used within Chartist.
             *
             * @memberof Chartist.Core
             * @type {{svg: string, xmlns: string, xhtml: string, xlink: string, ct: string}}
             */
(E=t).namespaces={svg:"http://www.w3.org/2000/svg",xmlns:"http://www.w3.org/2000/xmlns/",xhtml:"http://www.w3.org/1999/xhtml",xlink:"http://www.w3.org/1999/xlink",ct:"http://gionkunz.github.com/chartist-js/ct"},
/**
             * Helps to simplify functional style code
             *
             * @memberof Chartist.Core
             * @param {*} n This exact value will be returned by the noop function
             * @return {*} The same value that was provided to the n parameter
             */
E.noop=function(t){return t},
/**
             * Generates a-z } from a number 0 to 26
             *
             * @memberof Chartist.Core
             * @param {Number} n A number } from 0 to 26 that will result in a letter a-z
             * @return {String} A character } from a-z based on the input number n
             */
E.alphaNumerate=function(t){
// Limit to a-z
return String.fromCharCode(97+t%26)},
/**
             * Simple recursive object extend
             *
             * @memberof Chartist.Core
             * @param {Object} target Target object where the source will be merged into
             * @param {Object...} sources This object (objects) will be merged into target and then target is returned
             * @return {Object} An object that has the same reference as target but is extended and merged with the properties of source
             */
E.extend=function(t){var e,n,r;for(t=t||{},e=1;e<arguments.length;e++)for(var a in n=arguments[e])"object"!==ya(r=n[a])||null===r||r instanceof Array?t[a]=r:t[a]=E.extend(t[a],r);return t},
/**
             * Replaces all occurrences of subStr in str with newSubStr and returns a new string.
             *
             * @memberof Chartist.Core
             * @param {String} str
             * @param {String} subStr
             * @param {String} newSubStr
             * @return {String}
             */
E.replaceAll=function(t,e,n){return t.replace(new RegExp(e,"g"),n)},
/**
             * Converts a number to a string with a unit. If a string is passed then this will be returned unmodified.
             *
             * @memberof Chartist.Core
             * @param {Number} value
             * @param {String} unit
             * @return {String} Returns the passed number value with unit.
             */
E.ensureUnit=function(t,e){return"number"==typeof t&&(t+=e),t},
/**
             * Converts a number or string to a quantity object.
             *
             * @memberof Chartist.Core
             * @param {String|Number} input
             * @return {Object} Returns an object containing the value as number and the unit as string.
             */
E.quantity=function(t){if("string"!=typeof t)return{value:t};var e=/^(\d+)\s*(.*)$/g.exec(t);return{value:+e[1],unit:e[2]||void 0}},
/**
             * This is a wrapper around document.querySelector that will return the query if it's already of type Node
             *
             * @memberof Chartist.Core
             * @param {String|Node} query The query to use for selecting a Node or a DOM node that will be returned directly
             * @return {Node}
             */
E.querySelector=function(t){return t instanceof Node?t:p.querySelector(t)},
/**
             * Functional style helper to produce array with given length initialized with undefined values
             *
             * @memberof Chartist.Core
             * @param length
             * @return {Array}
             */
E.times=function(t){return Array.apply(null,new Array(t))},
/**
             * Sum helper to be used in reduce functions
             *
             * @memberof Chartist.Core
             * @param previous
             * @param current
             * @return {*}
             */
E.sum=function(t,e){return t+(e||0)},
/**
             * Multiply helper to be used in `Array.map` for multiplying each value of an array with a factor.
             *
             * @memberof Chartist.Core
             * @param {Number} factor
             * @returns {Function} Function that can be used in `Array.map` to multiply each value in an array
             */
E.mapMultiply=function(e){return function(t){return t*e}},
/**
             * Add helper to be used in `Array.map` for adding a addend to each value of an array.
             *
             * @memberof Chartist.Core
             * @param {Number} addend
             * @returns {Function} Function that can be used in `Array.map` to add a addend to each value in an array
             */
E.mapAdd=function(e){return function(t){return t+e}},
/**
             * Map for multi dimensional arrays where their nested arrays will be mapped in serial. The output array will have the length of the largest nested array. The callback function is called with variable arguments where each argument is the nested array value (or undefined if there are no more values).
             *
             * @memberof Chartist.Core
             * @param arr
             * @param cb
             * @return {Array}
             */
E.serialMap=function(r,a){var i=[],t=Math.max.apply(null,r.map(function(t){return t.length}));return E.times(t).forEach(function(t,e){var n=r.map(function(t){return t[e]});i[e]=a.apply(null,n)}),i},
/**
             * This helper function can be used to round values with certain precision level after decimal. This is used to prevent rounding errors near float point precision limit.
             *
             * @memberof Chartist.Core
             * @param {Number} value The value that should be rounded with precision
             * @param {Number} [digits] The number of digits after decimal used to do the rounding
             * @returns {number} Rounded value
             */
E.roundWithPrecision=function(t,e){var n=Math.pow(10,e||E.precision);return Math.round(t*n)/n},
/**
             * Precision level used internally in Chartist for rounding. If you require more decimal places you can increase this number.
             *
             * @memberof Chartist.Core
             * @type {number}
             */
E.precision=8,
/**
             * A map with characters to escape for strings to be safely used as attribute values.
             *
             * @memberof Chartist.Core
             * @type {Object}
             */
E.escapingMap={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"},
/**
             * This function serializes arbitrary data to a string. In case of data that can't be easily converted to a string, this function will create a wrapper object and serialize the data using JSON.stringify. The outcoming string will always be escaped using Chartist.escapingMap.
             * If called with null or undefined the function will return immediately with null or undefined.
             *
             * @memberof Chartist.Core
             * @param {Number|String|Object} data
             * @return {String}
             */
E.serialize=function(t){return null==t?t:("number"==typeof t?t=""+t:"object"===ya(t)&&(t=JSON.stringify({data:t})),Object.keys(E.escapingMap).reduce(function(t,e){return E.replaceAll(t,e,E.escapingMap[e])},t))},
/**
             * This function de-serializes a string previously serialized with Chartist.serialize. The string will always be unescaped using Chartist.escapingMap before it's returned. Based on the input value the return type can be Number, String or Object. JSON.parse is used with try / catch to see if the unescaped string can be parsed into an Object and this Object will be returned on success.
             *
             * @memberof Chartist.Core
             * @param {String} data
             * @return {String|Number|Object}
             */
E.deserialize=function(t){if("string"!=typeof t)return t;t=Object.keys(E.escapingMap).reduce(function(t,e){return E.replaceAll(t,E.escapingMap[e],e)},t);try{t=void 0!==(t=JSON.parse(t)).data?t.data:t}catch(t){}return t},
/**
             * Create or reinitialize the SVG element for the chart
             *
             * @memberof Chartist.Core
             * @param {Node} container The containing DOM Node object that will be used to plant the SVG element
             * @param {String} width Set the width of the SVG element. Default is 100%
             * @param {String} height Set the height of the SVG element. Default is 100%
             * @param {String} className Specify a class to be added to the SVG element
             * @return {Object} The created/reinitialized SVG element
             */
E.createSvg=function(e,t,n,r){var a;return t=t||"100%",n=n||"100%",// Check if there is a previous SVG element in the container that contains the Chartist XML namespace and remove it
// Since the DOM API does not support namespaces we need to manually search the returned list http://www.w3.org/TR/selectors-api/
Array.prototype.slice.call(e.querySelectorAll("svg")).filter(function(t){return t.getAttributeNS(E.namespaces.xmlns,"ct")}).forEach(function(t){e.removeChild(t)}),(// Create svg object with width and height or use 100% as default
a=new E.Svg("svg").attr({width:t,height:n,"aria-hidden":"true"}).addClass(r))._node.style.width=t,a._node.style.height=n,// Add the DOM node to our container
e.appendChild(a._node),a},
/**
             * Ensures that the data object passed as second argument to the charts is present and correctly initialized.
             *
             * @param  {Object} data The data object that is passed as second argument to the charts
             * @return {Object} The normalized data object
             */
E.normalizeData=function(t,e,n){var r,a={raw:t,normalized:{}};// Check if we should generate some labels based on existing series data
return a.normalized.series=E.getDataArray({series:t.series||[]},e,n),// If all elements of the normalized data array are arrays we're dealing with
// multi series data and we need to find the largest series if they are un-even
// Getting the series with the the most elements
r=a.normalized.series.every(function(t){return t instanceof Array})?Math.max.apply(null,a.normalized.series.map(function(t){return t.length})):a.normalized.series.length,a.normalized.labels=(t.labels||[]).slice(),// Padding the labels to labelCount with empty strings
Array.prototype.push.apply(a.normalized.labels,E.times(Math.max(0,r-a.normalized.labels.length)).map(function(){return""})),e&&E.reverseData(a.normalized),a},
/**
             * This function safely checks if an objects has an owned property.
             *
             * @param {Object} object The object where to check for a property
             * @param {string} property The property name
             * @returns {boolean} Returns true if the object owns the specified property
             */
E.safeHasProperty=function(t,e){return null!==t&&"object"===ya(t)&&t.hasOwnProperty(e)},
/**
             * Checks if a value is considered a hole in the data series.
             *
             * @param {*} value
             * @returns {boolean} True if the value is considered a data hole
             */
E.isDataHoleValue=function(t){return null==t||"number"==typeof t&&isNaN(t)},
/**
             * Reverses the series, labels and series data arrays.
             *
             * @memberof Chartist.Core
             * @param data
             */
E.reverseData=function(t){t.labels.reverse(),t.series.reverse();for(var e=0;e<t.series.length;e++)"object"===ya(t.series[e])&&void 0!==t.series[e].data?t.series[e].data.reverse():t.series[e]instanceof Array&&t.series[e].reverse()},
/**
             * Convert data series into plain array
             *
             * @memberof Chartist.Core
             * @param {Object} data The series object that contains the data to be visualized in the chart
             * @param {Boolean} [reverse] If true the whole data is reversed by the getDataArray call. This will modify the data object passed as first parameter. The labels as well as the series order is reversed. The whole series data arrays are reversed too.
             * @param {Boolean} [multi] Create a multi dimensional array } from a series data array where a value object with `x` and `y` values will be created.
             * @return {Array} A plain array that contains the data to be visualized in the chart
             */
E.getDataArray=function(t,e,r){return t.series.map(
// Recursively walks through nested arrays and convert string values to numbers and objects with value properties
// to values. Check the tests in data core -> data normalization for a detailed specification of expected values
function t(e){if(E.safeHasProperty(e,"value"))
// We are dealing with value object notation so we need to recurse on value property
return t(e.value);if(E.safeHasProperty(e,"data"))
// We are dealing with series object notation so we need to recurse on data property
return t(e.data);if(e instanceof Array)
// Data is of type array so we need to recurse on the series
return e.map(t);if(!E.isDataHoleValue(e)){
// We need to prepare multi value output (x and y data)
if(r){var n={};// Single series value arrays are assumed to specify the Y-Axis value
// For example: [1, 2] => [{x: undefined, y: 1}, {x: undefined, y: 2}]
// If multi is a string then it's assumed that it specified which dimension should be filled as default
return"string"==typeof r?n[r]=E.getNumberOrUndefined(e):n.y=E.getNumberOrUndefined(e),n.x=e.hasOwnProperty("x")?E.getNumberOrUndefined(e.x):n.x,n.y=e.hasOwnProperty("y")?E.getNumberOrUndefined(e.y):n.y,n}
// We can return simple data
return E.getNumberOrUndefined(e)}})},
/**
             * Converts a number into a padding object.
             *
             * @memberof Chartist.Core
             * @param {Object|Number} padding
             * @param {Number} [fallback] This value is used to fill missing values if a incomplete padding object was passed
             * @returns {Object} Returns a padding object containing top, right, bottom, left properties filled with the padding number passed in as argument. If the argument is something else than a number (presumably already a correct padding object) then this argument is directly returned.
             */
E.normalizePadding=function(t,e){return e=e||0,"number"==typeof t?{top:t,right:t,bottom:t,left:t}:{top:"number"==typeof t.top?t.top:e,right:"number"==typeof t.right?t.right:e,bottom:"number"==typeof t.bottom?t.bottom:e,left:"number"==typeof t.left?t.left:e}},E.getMetaData=function(t,e){var n=t.data?t.data[e]:t[e];return n?n.meta:void 0},
/**
             * Calculate the order of magnitude for the chart scale
             *
             * @memberof Chartist.Core
             * @param {Number} value The value Range of the chart
             * @return {Number} The order of magnitude
             */
E.orderOfMagnitude=function(t){return Math.floor(Math.log(Math.abs(t))/Math.LN10)},
/**
             * Project a data length into screen coordinates (pixels)
             *
             * @memberof Chartist.Core
             * @param {Object} axisLength The svg element for the chart
             * @param {Number} length Single data value } from a series array
             * @param {Object} bounds All the values to set the bounds of the chart
             * @return {Number} The projected data length in pixels
             */
E.projectLength=function(t,e,n){return e/n.range*t},
/**
             * Get the height of the area in the chart for the data series
             *
             * @memberof Chartist.Core
             * @param {Object} svg The svg element for the chart
             * @param {Object} options The Object that contains all the optional values for the chart
             * @return {Number} The height of the area in the chart for the data series
             */
E.getAvailableHeight=function(t,e){return Math.max((E.quantity(e.height).value||t.height())-(e.chartPadding.top+e.chartPadding.bottom)-e.axisX.offset,0)},
/**
             * Get highest and lowest value of data array. This Array contains the data that will be visualized in the chart.
             *
             * @memberof Chartist.Core
             * @param {Array} data The array that contains the data to be visualized in the chart
             * @param {Object} options The Object that contains the chart options
             * @param {String} dimension Axis dimension 'x' or 'y' used to access the correct value and high / low configuration
             * @return {Object} An object that contains the highest and lowest value that will be visualized on the chart.
             */
E.getHighLow=function(t,e,a){var i={high:void 0===(
// TODO: Remove workaround for deprecated global high / low config. Axis high / low configuration is preferred
e=E.extend({},e,a?e["axis"+a.toUpperCase()]:{})).high?-Number.MAX_VALUE:+e.high,low:void 0===e.low?Number.MAX_VALUE:+e.low},o=void 0===e.high,s=void 0===e.low;// Start to find highest and lowest number recursively
return(o||s)&&// Function to recursively walk through arrays and find highest and lowest number
function t(e){if(void 0!==e)if(e instanceof Array)for(var n=0;n<e.length;n++)t(e[n]);else{var r=a?+e[a]:+e;o&&r>i.high&&(i.high=r),s&&r<i.low&&(i.low=r)}}(t),// Overrides of high / low based on reference value, it will make sure that the invisible reference value is
// used to generate the chart. This is useful when the chart always needs to contain the position of the
// invisible reference value in the view i.e. for bipolar scales.
!e.referenceValue&&0!==e.referenceValue||(i.high=Math.max(e.referenceValue,i.high),i.low=Math.min(e.referenceValue,i.low)),// If high and low are the same because of misconfiguration or flat data (only the same value) we need
// to set the high or low to 0 depending on the polarity
i.high<=i.low&&(
// If both values are 0 we set high to 1
0===i.low?i.high=1:i.low<0?
// If we have the same negative value for the bounds we set bounds.high to 0
i.high=0:(0<i.high||(
// If data array was empty, values are Number.MAX_VALUE and -Number.MAX_VALUE. Set bounds to prevent errors
i.high=1),
// If we have the same positive value for the bounds we set bounds.low to 0
i.low=0)),i},
/**
             * Checks if a value can be safely coerced to a number. This includes all values except null which result in finite numbers when coerced. This excludes NaN, since it's not finite.
             *
             * @memberof Chartist.Core
             * @param value
             * @returns {Boolean}
             */
E.isNumeric=function(t){return null!==t&&isFinite(t)},
/**
             * Returns true on all falsey values except the numeric value 0.
             *
             * @memberof Chartist.Core
             * @param value
             * @returns {boolean}
             */
E.isFalseyButZero=function(t){return!t&&0!==t},
/**
             * Returns a number if the passed parameter is a valid number or the function will return undefined. On all other values than a valid number, this function will return undefined.
             *
             * @memberof Chartist.Core
             * @param value
             * @returns {*}
             */
E.getNumberOrUndefined=function(t){return E.isNumeric(t)?+t:void 0},
/**
             * Checks if provided value object is multi value (contains x or y properties)
             *
             * @memberof Chartist.Core
             * @param value
             */
E.isMultiValue=function(t){return"object"===ya(t)&&("x"in t||"y"in t)},
/**
             * Gets a value } from a dimension `value.x` or `value.y` while returning value directly if it's a valid numeric value. If the value is not numeric and it's falsey this function will return `defaultValue`.
             *
             * @memberof Chartist.Core
             * @param value
             * @param dimension
             * @param defaultValue
             * @returns {*}
             */
E.getMultiValue=function(t,e){return E.isMultiValue(t)?E.getNumberOrUndefined(t[e||"y"]):E.getNumberOrUndefined(t)},
/**
             * Pollard Rho Algorithm to find smallest factor of an integer value. There are more efficient algorithms for factorization, but this one is quite efficient and not so complex.
             *
             * @memberof Chartist.Core
             * @param {Number} num An integer number where the smallest factor should be searched for
             * @returns {Number} The smallest integer factor of the parameter num.
             */
E.rho=function(t){if(1===t)return t;function n(t,e){return t%e==0?e:n(e,t%e)}function e(t){return t*t+1}var r,a=2,i=2;if(t%2==0)return 2;for(;a=e(a)%t,i=e(e(i))%t,1===(r=n(Math.abs(a-i),t)););return r},
/**
             * Calculate and retrieve all the bounds for the chart and return them in one array
             *
             * @memberof Chartist.Core
             * @param {Number} axisLength The length of the Axis used for
             * @param {Object} highLow An object containing a high and low property indicating the value range of the chart.
             * @param {Number} scaleMinSpace The minimum projected length a step should result in
             * @param {Boolean} onlyInteger
             * @return {Object} All the values to set the bounds of the chart
             */
E.getBounds=function(t,e,n,r){var a,i,o,s=0,c={high:e.high,low:e.low};c.valueRange=c.high-c.low,c.oom=E.orderOfMagnitude(c.valueRange),c.step=Math.pow(10,c.oom),c.min=Math.floor(c.low/c.step)*c.step,c.max=Math.ceil(c.high/c.step)*c.step,c.range=c.max-c.min,c.numberOfSteps=Math.round(c.range/c.step);// Optimize scale step by checking if subdivision is possible based on horizontalGridMinSpace
// If we are already below the scaleMinSpace value we will scale up
var l=E.projectLength(t,c.step,c)<n,u=r?E.rho(c.range):0;// First check if we should only use integer steps and if step 1 is still larger than scaleMinSpace so we can use 1
if(r&&E.projectLength(t,1,c)>=n)c.step=1;else if(r&&u<c.step&&E.projectLength(t,u,c)>=n)
// If step 1 was too small, we can try the smallest factor of range
// If the smallest factor is smaller than the current bounds.step and the projected length of smallest factor
// is larger than the scaleMinSpace we should go for it.
c.step=u;else
// Trying to divide or multiply by 2 and find the best step value
for(;;){if(l&&E.projectLength(t,c.step,c)<=n)c.step*=2;else{if(l||!(E.projectLength(t,c.step/2,c)>=n))break;if(c.step/=2,r&&c.step%1!=0){c.step*=2;break}}if(1e3<s++)throw new Error("Exceeded maximum number of iterations while optimizing scale step!")}var d=2221e-19;function h(t,e){
// If increment is too small use *= (1+EPSILON) as a simple nextafter
return t===(t+=e)&&(t*=1+(0<e?d:-d)),t}// Narrow min and max based on new step
for(c.step=Math.max(c.step,d),i=c.min,o=c.max;i+c.step<=c.low;)i=h(i,c.step);for(;o-c.step>=c.high;)o=h(o,-c.step);c.min=i,c.max=o,c.range=c.max-c.min;var f=[];for(a=c.min;a<=c.max;a=h(a,c.step)){var p=E.roundWithPrecision(a);p!==f[f.length-1]&&f.push(p)}return c.values=f,c},
/**
             * Calculate cartesian coordinates of polar coordinates
             *
             * @memberof Chartist.Core
             * @param {Number} centerX X-axis coordinates of center point of circle segment
             * @param {Number} centerY X-axis coordinates of center point of circle segment
             * @param {Number} radius Radius of circle segment
             * @param {Number} angleInDegrees Angle of circle segment in degrees
             * @return {{x:Number, y:Number}} Coordinates of point on circumference
             */
E.polarToCartesian=function(t,e,n,r){var a=(r-90)*Math.PI/180;return{x:t+n*Math.cos(a),y:e+n*Math.sin(a)}},
/**
             * Initialize chart drawing rectangle (area where chart is drawn) x1,y1 = bottom left / x2,y2 = top right
             *
             * @memberof Chartist.Core
             * @param {Object} svg The svg element for the chart
             * @param {Object} options The Object that contains all the optional values for the chart
             * @param {Number} [fallbackPadding] The fallback padding if partial padding objects are used
             * @return {Object} The chart rectangles coordinates inside the svg element plus the rectangles measurements
             */
E.createChartRect=function(t,e,n){var r=!(!e.axisX&&!e.axisY),a=r?e.axisY.offset:0,i=r?e.axisX.offset:0,o=t.width()||E.quantity(e.width).value||0,s=t.height()||E.quantity(e.height).value||0,c=E.normalizePadding(e.chartPadding,n);// If settings were to small to cope with offset (legacy) and padding, we'll adjust
o=Math.max(o,a+c.left+c.right),s=Math.max(s,i+c.top+c.bottom);var l={padding:c,width:function(){return this.x2-this.x1},height:function(){return this.y1-this.y2}};return r?("start"===e.axisX.position?(l.y2=c.top+i,l.y1=Math.max(s-c.bottom,l.y2+1)):(l.y2=c.top,l.y1=Math.max(s-c.bottom-i,l.y2+1)),"start"===e.axisY.position?(l.x1=c.left+a,l.x2=Math.max(o-c.right,l.x1+1)):(l.x1=c.left,l.x2=Math.max(o-c.right-a,l.x1+1))):(l.x1=c.left,l.x2=Math.max(o-c.right,l.x1+1),l.y2=c.top,l.y1=Math.max(s-c.bottom,l.y2+1)),l},
/**
             * Creates a grid line based on a projected value.
             *
             * @memberof Chartist.Core
             * @param position
             * @param index
             * @param axis
             * @param offset
             * @param length
             * @param group
             * @param classes
             * @param eventEmitter
             */
E.createGrid=function(t,e,n,r,a,i,o,s){var c={};c[n.units.pos+"1"]=t,c[n.units.pos+"2"]=t,c[n.counterUnits.pos+"1"]=r,c[n.counterUnits.pos+"2"]=r+a;var l=i.elem("line",c,o.join(" "));// Event for grid draw
s.emit("draw",E.extend({type:"grid",axis:n,index:e,group:i,element:l},c))},
/**
             * Creates a grid background rect and emits the draw event.
             *
             * @memberof Chartist.Core
             * @param gridGroup
             * @param chartRect
             * @param className
             * @param eventEmitter
             */
E.createGridBackground=function(t,e,n,r){var a=t.elem("rect",{x:e.x1,y:e.y2,width:e.width(),height:e.height()},n,!0);// Event for grid background draw
r.emit("draw",{type:"gridBackground",group:t,element:a})},
/**
             * Creates a label based on a projected value and an axis.
             *
             * @memberof Chartist.Core
             * @param position
             * @param length
             * @param index
             * @param labels
             * @param axis
             * @param axisOffset
             * @param labelOffset
             * @param group
             * @param classes
             * @param useForeignObject
             * @param eventEmitter
             */
E.createLabel=function(t,e,n,r,a,i,o,s,c,l,u){var d,h={};if(h[a.units.pos]=t+o[a.units.pos],h[a.counterUnits.pos]=o[a.counterUnits.pos],h[a.units.len]=e,h[a.counterUnits.len]=Math.max(0,i-10),l){
// We need to set width and height explicitly to px as span will not expand with width and height being
// 100% in all browsers
var f=p.createElement("span");f.className=c.join(" "),f.setAttribute("xmlns",E.namespaces.xhtml),f.innerText=r[n],f.style[a.units.len]=Math.round(h[a.units.len])+"px",f.style[a.counterUnits.len]=Math.round(h[a.counterUnits.len])+"px",d=s.foreignObject(f,E.extend({style:"overflow: visible;"},h))}else d=s.elem("text",h,c.join(" ")).text(r[n]);u.emit("draw",E.extend({type:"label",axis:a,index:n,group:s,element:d,text:r[n]},h))},
/**
             * Helper to read series specific options } from options object. It automatically falls back to the global option if
             * there is no option in the series options.
             *
             * @param {Object} series Series object
             * @param {Object} options Chartist options object
             * @param {string} key The options key that should be used to obtain the options
             * @returns {*}
             */
E.getSeriesOption=function(t,e,n){if(t.name&&e.series&&e.series[t.name]){var r=e.series[t.name];return r.hasOwnProperty(n)?r[n]:e[n]}return e[n]},
/**
             * Provides options handling functionality with callback for options changes triggered by responsive options and media query matches
             *
             * @memberof Chartist.Core
             * @param {Object} options Options set by user
             * @param {Array} responsiveOptions Optional functions to add responsive behavior to chart
             * @param {Object} eventEmitter The event emitter that will be used to emit the options changed events
             * @return {Object} The consolidated options object } from the defaults, base and matching responsive options
             */
E.optionsProvider=function(t,n,r){var a,i,o=E.extend({},t),e=[];function s(t){var e=a;if(a=E.extend({},o),n)for(i=0;i<n.length;i++)l.matchMedia(n[i][0]).matches&&(a=E.extend(a,n[i][1]));r&&t&&r.emit("optionsChanged",{previousOptions:e,currentOptions:a})}if(!l.matchMedia)throw"window.matchMedia not found! Make sure you're using a polyfill.";// Execute initially without an event argument so we get the correct options
if(n)for(i=0;i<n.length;i++){var c=l.matchMedia(n[i][0]);c.addListener(s),e.push(c)}return s(),{removeMediaQueryListeners:function(){e.forEach(function(t){t.removeListener(s)})},getCurrentOptions:function(){return E.extend({},a)}}},
/**
             * Splits a list of coordinates and associated values into segments. Each returned segment contains a pathCoordinates
             * valueData property describing the segment.
             *
             * With the default options, segments consist of contiguous sets of points that do not have an undefined value. Any
             * points with undefined values are discarded.
             *
             * **Options**
             * The following options are used to determine how segments are formed
             * ```javascript
             * var options = {
             *   // If fillHoles is true, undefined values are simply discarded without creating a new segment. Assuming other options are default, this returns single segment.
             *   fillHoles: false,
             *   // If increasingX is true, the coordinates in all segments have strictly increasing x-values.
             *   increasingX: false
             * };
             * ```
             *
             * @memberof Chartist.Core
             * @param {Array} pathCoordinates List of point coordinates to be split in the form [x1, y1, x2, y2 ... xn, yn]
             * @param {Array} values List of associated point values in the form [v1, v2 .. vn]
             * @param {Object} options Options set by user
             * @return {Array} List of segments, each containing a pathCoordinates and valueData property.
             */
E.splitIntoSegments=function(t,e,n){n=E.extend({},{increasingX:!1,fillHoles:!1},n);for(var r=[],a=!0,i=0;i<t.length;i+=2)
// If this value is a "hole" we set the hole flag
void 0===E.getMultiValue(e[i/2].value)?
// if(valueData[i / 2].value === undefined) {
n.fillHoles||(a=!0):(n.increasingX&&2<=i&&t[i]<=t[i-2]&&(
// X is not increasing, so we need to make sure we start a new segment
a=!0),// If it's a valid value we need to check if we're coming out of a hole and create a new empty segment
a&&(r.push({pathCoordinates:[],valueData:[]}),// As we have a valid value now, we are not in a "hole" anymore
a=!1),// Add to the segment pathCoordinates and valueData
r[r.length-1].pathCoordinates.push(t[i],t[i+1]),r[r.length-1].valueData.push(e[i/2]));return r},window,document,(
/**
           * Chartist path interpolation functions.
           *
           * @module Chartist.Interpolation
           */
/* global Chartist */
S=t).Interpolation={},
/**
             * This interpolation function does not smooth the path and the result is only containing lines and no curves.
             *
             * @example
             * var chart = new Chartist.Line('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5],
             *   series: [[1, 2, 8, 1, 7]]
             * }, {
             *   lineSmooth: Chartist.Interpolation.none({
             *     fillHoles: false
             *   })
             * });
             *
             *
             * @memberof Chartist.Interpolation
             * @return {Function}
             */
S.Interpolation.none=function(c){return c=S.extend({},{fillHoles:!1},c),function(t,e){for(var n=new S.Svg.Path,r=!0,a=0;a<t.length;a+=2){var i=t[a],o=t[a+1],s=e[a/2];void 0!==S.getMultiValue(s.value)?(r?n.move(i,o,!1,s):n.line(i,o,!1,s),r=!1):c.fillHoles||(r=!0)}return n}},
/**
             * Simple smoothing creates horizontal handles that are positioned with a fraction of the length between two data points. You can use the divisor option to specify the amount of smoothing.
             *
             * Simple smoothing can be used instead of `Chartist.Smoothing.cardinal` if you'd like to get rid of the artifacts it produces sometimes. Simple smoothing produces less flowing lines but is accurate by hitting the points and it also doesn't swing below or above the given data point.
             *
             * All smoothing functions within Chartist are factory functions that accept an options parameter. The simple interpolation function accepts one configuration parameter `divisor`, between 1 and ∞, which controls the smoothing characteristics.
             *
             * @example
             * var chart = new Chartist.Line('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5],
             *   series: [[1, 2, 8, 1, 7]]
             * }, {
             *   lineSmooth: Chartist.Interpolation.simple({
             *     divisor: 2,
             *     fillHoles: false
             *   })
             * });
             *
             *
             * @memberof Chartist.Interpolation
             * @param {Object} options The options of the simple interpolation factory function.
             * @return {Function}
             */
S.Interpolation.simple=function(d){d=S.extend({},{divisor:2,fillHoles:!1},d);var h=1/Math.max(1,d.divisor);return function(t,e){for(var n,r,a,i=new S.Svg.Path,o=0;o<t.length;o+=2){var s=t[o],c=t[o+1],l=(s-n)*h,u=e[o/2];void 0!==u.value?(void 0===a?i.move(s,c,!1,u):i.curve(n+l,r,s-l,c,s,c,!1,u),n=s,r=c,a=u):d.fillHoles||(n=s=a=void 0)}return i}},
/**
             * Cardinal / Catmull-Rome spline interpolation is the default smoothing function in Chartist. It produces nice results where the splines will always meet the points. It produces some artifacts though when data values are increased or decreased rapidly. The line may not follow a very accurate path and if the line should be accurate this smoothing function does not produce the best results.
             *
             * Cardinal splines can only be created if there are more than two data points. If this is not the case this smoothing will fallback to `Chartist.Smoothing.none`.
             *
             * All smoothing functions within Chartist are factory functions that accept an options parameter. The cardinal interpolation function accepts one configuration parameter `tension`, between 0 and 1, which controls the smoothing intensity.
             *
             * @example
             * var chart = new Chartist.Line('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5],
             *   series: [[1, 2, 8, 1, 7]]
             * }, {
             *   lineSmooth: Chartist.Interpolation.cardinal({
             *     tension: 1,
             *     fillHoles: false
             *   })
             * });
             *
             * @memberof Chartist.Interpolation
             * @param {Object} options The options of the cardinal factory function.
             * @return {Function}
             */
S.Interpolation.cardinal=function(l){l=S.extend({},{tension:1,fillHoles:!1},l);var u=Math.min(1,Math.max(0,l.tension)),d=1-u;return function e(t,n){
// First we try to split the coordinates into segments
// This is necessary to treat "holes" in line charts
var r=S.splitIntoSegments(t,n,{fillHoles:l.fillHoles});if(r.length){if(1<r.length){
// If the split resulted in more that one segment we need to interpolate each segment individually and join them
// afterwards together into a single path.
var a=[];// For each segment we will recurse the cardinal function
// Join the segment path data into a single path and return
return r.forEach(function(t){a.push(e(t.pathCoordinates,t.valueData))}),S.Svg.Path.join(a)}// If less than two points we need to fallback to no smoothing
if(
// If there was only one segment we can proceed regularly by using pathCoordinates and valueData } from the first
// segment
t=r[0].pathCoordinates,n=r[0].valueData,t.length<=4)return S.Interpolation.none()(t,n);for(var i=(new S.Svg.Path).move(t[0],t[1],!1,n[0]),o=0,s=t.length;o<s-2;o+=2){var c=[{x:+t[o-2],y:+t[o-1]},{x:+t[o],y:+t[o+1]},{x:+t[o+2],y:+t[o+3]},{x:+t[o+4],y:+t[o+5]}];s-4===o?c[3]=c[2]:o||(c[0]={x:+t[o],y:+t[o+1]}),i.curve(u*(-c[0].x+6*c[1].x+c[2].x)/6+d*c[2].x,u*(-c[0].y+6*c[1].y+c[2].y)/6+d*c[2].y,u*(c[1].x+6*c[2].x-c[3].x)/6+d*c[2].x,u*(c[1].y+6*c[2].y-c[3].y)/6+d*c[2].y,c[2].x,c[2].y,!1,n[(o+2)/2])}return i}
// If there were no segments return 'Chartist.Interpolation.none'
return S.Interpolation.none()([])}},
/**
             * Monotone Cubic spline interpolation produces a smooth curve which preserves monotonicity. Unlike cardinal splines, the curve will not extend beyond the range of y-values of the original data points.
             *
             * Monotone Cubic splines can only be created if there are more than two data points. If this is not the case this smoothing will fallback to `Chartist.Smoothing.none`.
             *
             * The x-values of subsequent points must be increasing to fit a Monotone Cubic spline. If this condition is not met for a pair of adjacent points, then there will be a break in the curve between those data points.
             *
             * All smoothing functions within Chartist are factory functions that accept an options parameter.
             *
             * @example
             * var chart = new Chartist.Line('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5],
             *   series: [[1, 2, 8, 1, 7]]
             * }, {
             *   lineSmooth: Chartist.Interpolation.monotoneCubic({
             *     fillHoles: false
             *   })
             * });
             *
             * @memberof Chartist.Interpolation
             * @param {Object} options The options of the monotoneCubic factory function.
             * @return {Function}
             */
S.Interpolation.monotoneCubic=function(p){return p=S.extend({},{fillHoles:!1},p),function e(t,n){
// First we try to split the coordinates into segments
// This is necessary to treat "holes" in line charts
var r=S.splitIntoSegments(t,n,{fillHoles:p.fillHoles,increasingX:!0});if(r.length){if(1<r.length){
// If the split resulted in more that one segment we need to interpolate each segment individually and join them
// afterwards together into a single path.
var a=[];// For each segment we will recurse the monotoneCubic fn function
// Join the segment path data into a single path and return
return r.forEach(function(t){a.push(e(t.pathCoordinates,t.valueData))}),S.Svg.Path.join(a)}// If less than three points we need to fallback to no smoothing
if(
// If there was only one segment we can proceed regularly by using pathCoordinates and valueData } from the first
// segment
t=r[0].pathCoordinates,n=r[0].valueData,t.length<=4)return S.Interpolation.none()(t,n);var i,o,s=[],c=[],l=t.length/2,u=[],d=[],h=[],f=[];// Populate x and y coordinates into separate arrays, for readability
for(i=0;i<l;i++)s[i]=t[2*i],c[i]=t[2*i+1];// Calculate deltas and derivative
for(i=0;i<l-1;i++)h[i]=c[i+1]-c[i],f[i]=s[i+1]-s[i],d[i]=h[i]/f[i];// Determine desired slope (m) at each point using Fritsch-Carlson method
// See: http://math.stackexchange.com/questions/45218/implementation-of-monotone-cubic-interpolation
for(u[0]=d[0],u[l-1]=d[l-2],i=1;i<l-1;i++)0===d[i]||0===d[i-1]||0<d[i-1]!=0<d[i]?u[i]=0:(u[i]=3*(f[i-1]+f[i])/((2*f[i]+f[i-1])/d[i-1]+(f[i]+2*f[i-1])/d[i]),isFinite(u[i])||(u[i]=0));// Now build a path } from the slopes
for(o=(new S.Svg.Path).move(s[0],c[0],!1,n[0]),i=0;i<l-1;i++)o.curve(// First control point
s[i]+f[i]/3,c[i]+u[i]*f[i]/3,// Second control point
s[i+1]-f[i]/3,c[i+1]-u[i+1]*f[i]/3,// End point
s[i+1],c[i+1],!1,n[i+1]);return o}
// If there were no segments return 'Chartist.Interpolation.none'
return S.Interpolation.none()([])}},
/**
             * Step interpolation will cause the line chart to move in steps rather than diagonal or smoothed lines. This interpolation will create additional points that will also be drawn when the `showPoint` option is enabled.
             *
             * All smoothing functions within Chartist are factory functions that accept an options parameter. The step interpolation function accepts one configuration parameter `postpone`, that can be `true` or `false`. The default value is `true` and will cause the step to occur where the value actually changes. If a different behaviour is needed where the step is shifted to the left and happens before the actual value, this option can be set to `false`.
             *
             * @example
             * var chart = new Chartist.Line('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5],
             *   series: [[1, 2, 8, 1, 7]]
             * }, {
             *   lineSmooth: Chartist.Interpolation.step({
             *     postpone: true,
             *     fillHoles: false
             *   })
             * });
             *
             * @memberof Chartist.Interpolation
             * @param options
             * @returns {Function}
             */
S.Interpolation.step=function(u){return u=S.extend({},{postpone:!0,fillHoles:!1},u),function(t,e){for(var n,r,a,i=new S.Svg.Path,o=0;o<t.length;o+=2){var s=t[o],c=t[o+1],l=e[o/2];// If the current point is also not a hole we can draw the step lines
void 0!==l.value?(void 0===a?i.move(s,c,!1,l):(u.postpone?
// If postponed we should draw the step line with the value of the previous value
i.line(s,r,!1,a):
// If not postponed we should draw the step line with the value of the current value
i.line(n,c,!1,l),// Line to the actual point (this should only be a Y-Axis movement
i.line(s,c,!1,l)),n=s,r=c,a=l):u.fillHoles||(n=r=a=void 0)}return i}},window,document,t.EventEmitter=function(){var r=[];
/**
               * Add an event handler for a specific event
               *
               * @memberof Chartist.Event
               * @param {String} event The event name
               * @param {Function} handler A event handler function
               */return{addEventHandler:function(t,e){r[t]=r[t]||[],r[t].push(e)}
/**
               * Remove an event handler of a specific event name or remove all event handlers for a specific event.
               *
               * @memberof Chartist.Event
               * @param {String} event The event name where a specific or all handlers should be removed
               * @param {Function} [handler] An optional event handler function. If specified only this specific handler will be removed and otherwise all handlers are removed.
               */,removeEventHandler:function(t,e){
// Only do something if there are event handlers with this name existing
r[t]&&(
// If handler is set we will look for a specific handler and only remove this
e?(r[t].splice(r[t].indexOf(e),1),0===r[t].length&&delete r[t]):
// If no handler is specified we remove all handlers for this event
delete r[t])}
/**
               * Use this function to emit an event. All handlers that are listening for this event will be triggered with the data parameter.
               *
               * @memberof Chartist.Event
               * @param {String} event The event name that should be triggered
               * @param {*} data Arbitrary data that will be passed to the event handler callback functions
               */,emit:function(e,n){
// Only do something if there are event handlers with this name existing
r[e]&&r[e].forEach(function(t){t(n)}),// Emit event to star event handlers
r["*"]&&r["*"].forEach(function(t){t(e,n)})}}},window,document,(
/**
           * This module provides some basic prototype inheritance utilities.
           *
           * @module Chartist.Class
           */
/* global Chartist */
i=t).Class={extend:
/**
             * Method to extend } from current prototype.
             *
             * @memberof Chartist.Class
             * @param {Object} properties The object that serves as definition for the prototype that gets created for the new class. This object should always contain a constructor property that is the desired constructor for the newly created class.
             * @param {Object} [superProtoOverride] By default extens will use the current class prototype or Chartist.class. With this parameter you can specify any super prototype that will be used.
             * @return {Function} Constructor function of the new class
             *
             * @example
             * var Fruit = Class.extend({
             * color: undefined,
             *   sugar: undefined,
             *
             *   constructor: function(color, sugar) {
             *     this.color = color;
             *     this.sugar = sugar;
             *   },
             *
             *   eat: function() {
             *     this.sugar = 0;
             *     return this;
             *   }
             * });
             *
             * var Banana = Fruit.extend({
             *   length: undefined,
             *
             *   constructor: function(length, sugar) {
             *     Banana.super.constructor.call(this, 'Yellow', sugar);
             *     this.length = length;
             *   }
             * });
             *
             * var banana = new Banana(20, 40);
             * console.log('banana instanceof Fruit', banana instanceof Fruit);
             * console.log('Fruit is prototype of banana', Fruit.prototype.isPrototypeOf(banana));
             * console.log('bananas prototype is Fruit', Object.getPrototypeOf(banana) === Fruit.prototype);
             * console.log(banana.sugar);
             * console.log(banana.eat().sugar);
             * console.log(banana.color);
             */
function(t,e){var n=e||this.prototype||i.Class,r=Object.create(n);function a(){var t,e=r.constructor||function(){};// If this is linked to the Chartist namespace the constructor was not called with new
// To provide a fallback we will instantiate here and return the instance
// If this constructor was not called with new we need to return the instance
// This will not harm when the constructor has been called with new as the returned value is ignored
return t=this===i?Object.create(r):this,e.apply(t,Array.prototype.slice.call(arguments,0)),t}return i.Class.cloneDefinitions(r,t),a.prototype=r,a.super=n,a.extend=this.extend,a}// Variable argument list clones args > 0 into args[0] and retruns modified args[0]
,cloneDefinitions:function(){var t=function(t){var e=[];if(t.length)for(var n=0;n<t.length;n++)e.push(t[n]);return e}(arguments),n=t[0];return t.splice(1,t.length-1).forEach(function(e){Object.getOwnPropertyNames(e).forEach(function(t){
// If this property already exist in target we delete it first
delete n[t],// Define the property with the descriptor } from source
Object.defineProperty(n,t,Object.getOwnPropertyDescriptor(e,t))})}),n}},
/**
           * Base for all chart types. The methods in Chartist.Base are inherited to all chart types.
           *
           * @module Chartist.Base
           */
/* global Chartist */
o=window,document,// Creating the chart base class
(s=t).Base=s.Class.extend({constructor:
/**
             * Constructor of chart base class.
             *
             * @param query
             * @param data
             * @param defaultOptions
             * @param options
             * @param responsiveOptions
             * @constructor
             */
function(t,e,n,r,a){this.container=s.querySelector(t),this.data=e||{},this.data.labels=this.data.labels||[],this.data.series=this.data.series||[],this.defaultOptions=n,this.options=r,this.responsiveOptions=a,this.eventEmitter=s.EventEmitter(),this.supportsForeignObject=s.Svg.isSupported("Extensibility"),this.supportsAnimations=s.Svg.isSupported("AnimationEventsAttribute"),this.resizeListener=function(){this.update()}.bind(this),this.container&&(
// If chartist was already initialized in this container we are detaching all event listeners first
this.container.__chartist__&&this.container.__chartist__.detach(),this.container.__chartist__=this),// Using event loop for first draw to make it possible to register event listeners in the same call stack where
// the chart was created.
this.initializeTimeoutId=setTimeout(function(){
// Add window resize listener that re-creates the chart
o.addEventListener("resize",this.resizeListener),// Obtain current options based on matching media queries (if responsive options are given)
// This will also register a listener that is re-creating the chart based on media changes
this.optionsProvider=s.optionsProvider(this.options,this.responsiveOptions,this.eventEmitter),// Register options change listener that will trigger a chart update
this.eventEmitter.addEventHandler("optionsChanged",function(){this.update()}.bind(this)),// Before the first chart creation we need to register us with all plugins that are configured
// Initialize all relevant plugins with our chart object and the plugin options specified in the config
this.options.plugins&&this.options.plugins.forEach(function(t){t instanceof Array?t[0](this,t[1]):t(this)}.bind(this)),// Event for data transformation that allows to manipulate the data before it gets rendered in the charts
this.eventEmitter.emit("data",{type:"initial",data:this.data}),// Create the first chart
this.createChart(this.optionsProvider.getCurrentOptions()),// As chart is initialized } from the event loop now we can reset our timeout reference
// This is important if the chart gets initialized on the same element twice
this.initializeTimeoutId=void 0}.bind(this),0)},optionsProvider:void 0,container:void 0,svg:void 0,eventEmitter:void 0,createChart:function(){throw new Error("Base chart type can't be instantiated!")},update:
// This is done because we can't work with relative coordinates when drawing the chart because SVG Path does not
// work with relative positions yet. We need to check if we can do a viewBox hack to switch to percentage.
// See http://mozilla.6506.n7.nabble.com/Specyfing-paths-with-percentages-unit-td247474.html
// Update: can be done using the above method tested here: http://codepen.io/gionkunz/pen/KDvLj
// The problem is with the label offsets that can't be converted into percentage and affecting the chart container
/**
             * Updates the chart which currently does a full reconstruction of the SVG DOM
             *
             * @param {Object} [data] Optional data you'd like to set for the chart before it will update. If not specified the update method will use the data that is already configured with the chart.
             * @param {Object} [options] Optional options you'd like to add to the previous options for the chart before it will update. If not specified the update method will use the options that have been already configured with the chart.
             * @param {Boolean} [override] If set to true, the passed options will be used to extend the options that have been configured already. Otherwise the chart default options will be used as the base
             * @memberof Chartist.Base
             */
function(t,e,n){// Return a reference to the chart object to chain up calls
return t&&(this.data=t||{},this.data.labels=this.data.labels||[],this.data.series=this.data.series||[],// Event for data transformation that allows to manipulate the data before it gets rendered in the charts
this.eventEmitter.emit("data",{type:"update",data:this.data})),e&&(this.options=s.extend({},n?this.options:this.defaultOptions,e),// If chartist was not initialized yet, we just set the options and leave the rest to the initialization
// Otherwise we re-create the optionsProvider at this point
this.initializeTimeoutId||(this.optionsProvider.removeMediaQueryListeners(),this.optionsProvider=s.optionsProvider(this.options,this.responsiveOptions,this.eventEmitter))),// Only re-created the chart if it has been initialized yet
this.initializeTimeoutId||this.createChart(this.optionsProvider.getCurrentOptions()),this}
/**
             * This method can be called on the API object of each chart and will un-register all event listeners that were added to other components. This currently includes a window.resize listener as well as media query listeners if any responsive options have been provided. Use this function if you need to destroy and recreate Chartist charts dynamically.
             *
             * @memberof Chartist.Base
             */,detach:function(){
// Only detach if initialization already occurred on this chart. If this chart still hasn't initialized (therefore
// the initializationTimeoutId is still a valid timeout reference, we will clear the timeout
return this.initializeTimeoutId?o.clearTimeout(this.initializeTimeoutId):(o.removeEventListener("resize",this.resizeListener),this.optionsProvider.removeMediaQueryListeners()),this}
/**
             * Use this function to register event handlers. The handler callbacks are synchronous and will run in the main thread rather than the event loop.
             *
             * @memberof Chartist.Base
             * @param {String} event Name of the event. Check the examples for supported events.
             * @param {Function} handler The handler function that will be called when an event with the given name was emitted. This function will receive a data argument which contains event data. See the example for more details.
             */,on:function(t,e){return this.eventEmitter.addEventHandler(t,e),this}
/**
             * Use this function to un-register event handlers. If the handler function parameter is omitted all handlers for the given event will be un-registered.
             *
             * @memberof Chartist.Base
             * @param {String} event Name of the event for which a handler should be removed
             * @param {Function} [handler] The handler function that that was previously used to register a new event handler. This handler will be removed } from the event handler list. If this parameter is omitted then all event handlers for the given event are removed } from the list.
             */,off:function(t,e){return this.eventEmitter.removeEventHandler(t,e),this},version:s.version,supportsForeignObject:!1}),
/**
           * Chartist SVG module for simple SVG DOM abstraction
           *
           * @module Chartist.Svg
           */
/* global Chartist */
function(t,o,c){c.Svg=c.Class.extend({constructor:
/**
             * Chartist.Svg creates a new SVG object wrapper with a starting element. You can use the wrapper to fluently create sub-elements and modify them.
             *
             * @memberof Chartist.Svg
             * @constructor
             * @param {String|Element} name The name of the SVG element to create or an SVG dom element which should be wrapped into Chartist.Svg
             * @param {Object} attributes An object with properties that will be added as attributes to the SVG element that is created. Attributes with undefined values will not be added.
             * @param {String} className This class or class list will be added to the SVG element
             * @param {Object} parent The parent SVG wrapper object where this newly created wrapper and it's element will be attached to as child
             * @param {Boolean} insertFirst If this param is set to true in conjunction with a parent element the newly created element will be added as first child element in the parent element
             */
function(t,e,n,r,a){
// If Svg is getting called with an SVG element we just return the wrapper
t instanceof Element?this._node=t:(this._node=o.createElementNS(c.namespaces.svg,t),// If this is an SVG element created then custom namespace
"svg"===t&&this.attr({"xmlns:ct":c.namespaces.ct})),e&&this.attr(e),n&&this.addClass(n),r&&(a&&r._node.firstChild?r._node.insertBefore(this._node,r._node.firstChild):r._node.appendChild(this._node))}
/**
             * Set attributes on the current SVG element of the wrapper you're currently working on.
             *
             * @memberof Chartist.Svg
             * @param {Object|String} attributes An object with properties that will be added as attributes to the SVG element that is created. Attributes with undefined values will not be added. If this parameter is a String then the function is used as a getter and will return the attribute value.
             * @param {String} [ns] If specified, the attribute will be obtained using getAttributeNs. In order to write namepsaced attributes you can use the namespace:attribute notation within the attributes object.
             * @return {Object|String} The current wrapper object will be returned so it can be used for chaining or the attribute value if used as getter function.
             */,attr:function(n,t){return"string"==typeof n?t?this._node.getAttributeNS(t,n):this._node.getAttribute(n):(Object.keys(n).forEach(function(t){
// If the attribute value is undefined we can skip this one
if(void 0!==n[t])if(-1!==t.indexOf(":")){var e=t.split(":");this._node.setAttributeNS(c.namespaces[e[0]],t,n[t])}else this._node.setAttribute(t,n[t])}.bind(this)),this)}
/**
             * Create a new SVG element whose wrapper object will be selected for further operations. This way you can also create nested groups easily.
             *
             * @memberof Chartist.Svg
             * @param {String} name The name of the SVG element that should be created as child element of the currently selected element wrapper
             * @param {Object} [attributes] An object with properties that will be added as attributes to the SVG element that is created. Attributes with undefined values will not be added.
             * @param {String} [className] This class or class list will be added to the SVG element
             * @param {Boolean} [insertFirst] If this param is set to true in conjunction with a parent element the newly created element will be added as first child element in the parent element
             * @return {Chartist.Svg} Returns a Chartist.Svg wrapper object that can be used to modify the containing SVG data
             */,elem:function(t,e,n,r){return new c.Svg(t,e,n,this,r)}
/**
             * Returns the parent Chartist.SVG wrapper object
             *
             * @memberof Chartist.Svg
             * @return {Chartist.Svg} Returns a Chartist.Svg wrapper around the parent node of the current node. If the parent node is not existing or it's not an SVG node then this function will return null.
             */,parent:function(){return this._node.parentNode instanceof SVGElement?new c.Svg(this._node.parentNode):null}
/**
             * This method returns a Chartist.Svg wrapper around the root SVG element of the current tree.
             *
             * @memberof Chartist.Svg
             * @return {Chartist.Svg} The root SVG element wrapped in a Chartist.Svg element
             */,root:function(){for(var t=this._node;"svg"!==t.nodeName;)t=t.parentNode;return new c.Svg(t)}
/**
             * Find the first child SVG element of the current element that matches a CSS selector. The returned object is a Chartist.Svg wrapper.
             *
             * @memberof Chartist.Svg
             * @param {String} selector A CSS selector that is used to query for child SVG elements
             * @return {Chartist.Svg} The SVG wrapper for the element found or null if no element was found
             */,querySelector:function(t){var e=this._node.querySelector(t);return e?new c.Svg(e):null}
/**
             * Find the all child SVG elements of the current element that match a CSS selector. The returned object is a Chartist.Svg.List wrapper.
             *
             * @memberof Chartist.Svg
             * @param {String} selector A CSS selector that is used to query for child SVG elements
             * @return {Chartist.Svg.List} The SVG wrapper list for the element found or null if no element was found
             */,querySelectorAll:function(t){var e=this._node.querySelectorAll(t);return e.length?new c.Svg.List(e):null}
/**
             * Returns the underlying SVG node for the current element.
             *
             * @memberof Chartist.Svg
             * @returns {Node}
             */,getNode:function(){return this._node}
/**
             * This method creates a foreignObject (see https://developer.mozilla.org/en-US/docs/Web/SVG/Element/foreignObject) that allows to embed HTML content into a SVG graphic. With the help of foreignObjects you can enable the usage of regular HTML elements inside of SVG where they are subject for SVG positioning and transformation but the Browser will use the HTML rendering capabilities for the containing DOM.
             *
             * @memberof Chartist.Svg
             * @param {Node|String} content The DOM Node, or HTML string that will be converted to a DOM Node, that is then placed into and wrapped by the foreignObject
             * @param {String} [attributes] An object with properties that will be added as attributes to the foreignObject element that is created. Attributes with undefined values will not be added.
             * @param {String} [className] This class or class list will be added to the SVG element
             * @param {Boolean} [insertFirst] Specifies if the foreignObject should be inserted as first child
             * @return {Chartist.Svg} New wrapper object that wraps the foreignObject element
             */,foreignObject:function(t,e,n,r){
// If content is string then we convert it to DOM
// TODO: Handle case where content is not a string nor a DOM Node
if("string"==typeof t){var a=o.createElement("div");a.innerHTML=t,t=a.firstChild}// Adding namespace to content element
t.setAttribute("xmlns",c.namespaces.xmlns);// Creating the foreignObject without required extension attribute (as described here
// http://www.w3.org/TR/SVG/extend.html#ForeignObjectElement)
var i=this.elem("foreignObject",e,n,r);// Add content to foreignObjectElement
return i._node.appendChild(t),i}
/**
             * This method adds a new text element to the current Chartist.Svg wrapper.
             *
             * @memberof Chartist.Svg
             * @param {String} t The text that should be added to the text element that is created
             * @return {Chartist.Svg} The same wrapper object that was used to add the newly created element
             */,text:function(t){return this._node.appendChild(o.createTextNode(t)),this}
/**
             * This method will clear all child nodes of the current wrapper object.
             *
             * @memberof Chartist.Svg
             * @return {Chartist.Svg} The same wrapper object that got emptied
             */,empty:function(){for(;this._node.firstChild;)this._node.removeChild(this._node.firstChild);return this}
/**
             * This method will cause the current wrapper to remove itself } from its parent wrapper. Use this method if you'd like to get rid of an element in a given DOM structure.
             *
             * @memberof Chartist.Svg
             * @return {Chartist.Svg} The parent wrapper object of the element that got removed
             */,remove:function(){return this._node.parentNode.removeChild(this._node),this.parent()}
/**
             * This method will replace the element with a new element that can be created outside of the current DOM.
             *
             * @memberof Chartist.Svg
             * @param {Chartist.Svg} newElement The new Chartist.Svg object that will be used to replace the current wrapper object
             * @return {Chartist.Svg} The wrapper of the new element
             */,replace:function(t){return this._node.parentNode.replaceChild(t._node,this._node),t}
/**
             * This method will append an element to the current element as a child.
             *
             * @memberof Chartist.Svg
             * @param {Chartist.Svg} element The Chartist.Svg element that should be added as a child
             * @param {Boolean} [insertFirst] Specifies if the element should be inserted as first child
             * @return {Chartist.Svg} The wrapper of the appended object
             */,append:function(t,e){return e&&this._node.firstChild?this._node.insertBefore(t._node,this._node.firstChild):this._node.appendChild(t._node),this}
/**
             * Returns an array of class names that are attached to the current wrapper element. This method can not be chained further.
             *
             * @memberof Chartist.Svg
             * @return {Array} A list of classes or an empty array if there are no classes on the current element
             */,classes:function(){return this._node.getAttribute("class")?this._node.getAttribute("class").trim().split(/\s+/):[]}
/**
             * Adds one or a space separated list of classes to the current element and ensures the classes are only existing once.
             *
             * @memberof Chartist.Svg
             * @param {String} names A white space separated list of class names
             * @return {Chartist.Svg} The wrapper of the current element
             */,addClass:function(t){return this._node.setAttribute("class",this.classes(this._node).concat(t.trim().split(/\s+/)).filter(function(t,e,n){return n.indexOf(t)===e}).join(" ")),this}
/**
             * Removes one or a space separated list of classes } from the current element.
             *
             * @memberof Chartist.Svg
             * @param {String} names A white space separated list of class names
             * @return {Chartist.Svg} The wrapper of the current element
             */,removeClass:function(t){var e=t.trim().split(/\s+/);return this._node.setAttribute("class",this.classes(this._node).filter(function(t){return-1===e.indexOf(t)}).join(" ")),this}
/**
             * Removes all classes } from the current element.
             *
             * @memberof Chartist.Svg
             * @return {Chartist.Svg} The wrapper of the current element
             */,removeAllClasses:function(){return this._node.setAttribute("class",""),this}
/**
             * Get element height using `getBoundingClientRect`
             *
             * @memberof Chartist.Svg
             * @return {Number} The elements height in pixels
             */,height:function(){return this._node.getBoundingClientRect().height}
/**
             * Get element width using `getBoundingClientRect`
             *
             * @memberof Chartist.Core
             * @return {Number} The elements width in pixels
             */,width:function(){return this._node.getBoundingClientRect().width}
/**
             * The animate function lets you animate the current element with SMIL animations. You can add animations for multiple attributes at the same time by using an animation definition object. This object should contain SMIL animation attributes. Please refer to http://www.w3.org/TR/SVG/animate.html for a detailed specification about the available animation attributes. Additionally an easing property can be passed in the animation definition object. This can be a string with a name of an easing function in `Chartist.Svg.Easing` or an array with four numbers specifying a cubic Bézier curve.
             * **An animations object could look like this:**
             * ```javascript
             * element.animate({
             *   opacity: {
             *     dur: 1000,
             *     from: 0,
             *     to: 1
             *   },
             *   x1: {
             *     dur: '1000ms',
             *     from: 100,
             *     to: 200,
             *     easing: 'easeOutQuart'
             *   },
             *   y1: {
             *     dur: '2s',
             *     from: 0,
             *     to: 100
             *   }
             * });
             * ```
             * **Automatic unit conversion**
             * For the `dur` and the `begin` animate attribute you can also omit a unit by passing a number. The number will automatically be converted to milli seconds.
             * **Guided mode**
             * The default behavior of SMIL animations with offset using the `begin` attribute is that the attribute will keep it's original value until the animation starts. Mostly this behavior is not desired as you'd like to have your element attributes already initialized with the animation `from` value even before the animation starts. Also if you don't specify `fill="freeze"` on an animate element or if you delete the animation after it's done (which is done in guided mode) the attribute will switch back to the initial value. This behavior is also not desired when performing simple one-time animations. For one-time animations you'd want to trigger animations immediately instead of relative to the document begin time. That's why in guided mode Chartist.Svg will also use the `begin` property to schedule a timeout and manually start the animation after the timeout. If you're using multiple SMIL definition objects for an attribute (in an array), guided mode will be disabled for this attribute, even if you explicitly enabled it.
             * If guided mode is enabled the following behavior is added:
             * - Before the animation starts (even when delayed with `begin`) the animated attribute will be set already to the `from` value of the animation
             * - `begin` is explicitly set to `indefinite` so it can be started manually without relying on document begin time (creation)
             * - The animate element will be forced to use `fill="freeze"`
             * - The animation will be triggered with `beginElement()` in a timeout where `begin` of the definition object is interpreted in milli seconds. If no `begin` was specified the timeout is triggered immediately.
             * - After the animation the element attribute value will be set to the `to` value of the animation
             * - The animate element is deleted } from the DOM
             *
             * @memberof Chartist.Svg
             * @param {Object} animations An animations object where the property keys are the attributes you'd like to animate. The properties should be objects again that contain the SMIL animation attributes (usually begin, dur, from, and to). The property begin and dur is auto converted (see Automatic unit conversion). You can also schedule multiple animations for the same attribute by passing an Array of SMIL definition objects. Attributes that contain an array of SMIL definition objects will not be executed in guided mode.
             * @param {Boolean} guided Specify if guided mode should be activated for this animation (see Guided mode). If not otherwise specified, guided mode will be activated.
             * @param {Object} eventEmitter If specified, this event emitter will be notified when an animation starts or ends.
             * @return {Chartist.Svg} The current element where the animation was added
             */,animate:function(t,n,s){return void 0===n&&(n=!0),Object.keys(t).forEach(function(o){function e(e,t){var n,r,a,i={};// Check if an easing is specified in the definition object and delete it } from the object as it will not
// be part of the animate element attributes.
e.easing&&(
// If already an easing Bézier curve array we take it or we lookup a easing array in the Easing object
a=e.easing instanceof Array?e.easing:c.Svg.Easing[e.easing],delete e.easing),// If numeric dur or begin was provided we assume milli seconds
e.begin=c.ensureUnit(e.begin,"ms"),e.dur=c.ensureUnit(e.dur,"ms"),a&&(e.calcMode="spline",e.keySplines=a.join(" "),e.keyTimes="0;1"),// Adding "fill: freeze" if we are in guided mode and set initial attribute values
t&&(e.fill="freeze",// Animated property on our element should already be set to the animation } from value in guided mode
i[o]=e.from,this.attr(i),// In guided mode we also set begin to indefinite so we can trigger the start manually and put the begin
// which needs to be in ms aside
r=c.quantity(e.begin||0).value,e.begin="indefinite"),n=this.elem("animate",c.extend({attributeName:o},e)),t&&
// If guided we take the value that was put aside in timeout and trigger the animation manually with a timeout
setTimeout(function(){
// If beginElement fails we set the animated attribute to the end position and remove the animate element
// This happens if the SMIL ElementTimeControl interface is not supported or any other problems occured in
// the browser. (Currently FF 34 does not support animate elements in foreignObjects)
try{n._node.beginElement()}catch(t){
// Set animated attribute to current animated value
i[o]=e.to,this.attr(i),// Remove the animate element as it's no longer required
n.remove()}}.bind(this),r),s&&n._node.addEventListener("beginEvent",function(){s.emit("animationBegin",{element:this,animate:n._node,params:e})}.bind(this)),n._node.addEventListener("endEvent",function(){s&&s.emit("animationEnd",{element:this,animate:n._node,params:e}),t&&(
// Set animated attribute to current animated value
i[o]=e.to,this.attr(i),// Remove the animate element as it's no longer required
n.remove())}.bind(this))}// If current attribute is an array of definition objects we create an animate for each and disable guided mode
t[o]instanceof Array?t[o].forEach(function(t){e.bind(this)(t,!1)}.bind(this)):e.bind(this)(t[o],n)}.bind(this)),this}}),
/**
             * This method checks for support of a given SVG feature like Extensibility, SVG-animation or the like. Check http://www.w3.org/TR/SVG11/feature for a detailed list.
             *
             * @memberof Chartist.Svg
             * @param {String} feature The SVG 1.1 feature that should be checked for support.
             * @return {Boolean} True of false if the feature is supported or not
             */
c.Svg.isSupported=function(t){return o.implementation.hasFeature("http://www.w3.org/TR/SVG11/feature#"+t,"1.1")};c.Svg.Easing={easeInSine:[.47,0,.745,.715],easeOutSine:[.39,.575,.565,1],easeInOutSine:[.445,.05,.55,.95],easeInQuad:[.55,.085,.68,.53],easeOutQuad:[.25,.46,.45,.94],easeInOutQuad:[.455,.03,.515,.955],easeInCubic:[.55,.055,.675,.19],easeOutCubic:[.215,.61,.355,1],easeInOutCubic:[.645,.045,.355,1],easeInQuart:[.895,.03,.685,.22],easeOutQuart:[.165,.84,.44,1],easeInOutQuart:[.77,0,.175,1],easeInQuint:[.755,.05,.855,.06],easeOutQuint:[.23,1,.32,1],easeInOutQuint:[.86,0,.07,1],easeInExpo:[.95,.05,.795,.035],easeOutExpo:[.19,1,.22,1],easeInOutExpo:[1,0,0,1],easeInCirc:[.6,.04,.98,.335],easeOutCirc:[.075,.82,.165,1],easeInOutCirc:[.785,.135,.15,.86],easeInBack:[.6,-.28,.735,.045],easeOutBack:[.175,.885,.32,1.275],easeInOutBack:[.68,-.55,.265,1.55]},c.Svg.List=c.Class.extend({constructor:
/**
             * This helper class is to wrap multiple `Chartist.Svg` elements into a list where you can call the `Chartist.Svg` functions on all elements in the list with one call. This is helpful when you'd like to perform calls with `Chartist.Svg` on multiple elements.
             * An instance of this class is also returned by `Chartist.Svg.querySelectorAll`.
             *
             * @memberof Chartist.Svg
             * @param {Array<Node>|NodeList} nodeList An Array of SVG DOM nodes or a SVG DOM NodeList (as returned by document.querySelectorAll)
             * @constructor
             */
function(t){var r=this;this.svgElements=[];for(var e=0;e<t.length;e++)this.svgElements.push(new c.Svg(t[e]));// Add delegation methods for Chartist.Svg
Object.keys(c.Svg.prototype).filter(function(t){return-1===["constructor","parent","querySelector","querySelectorAll","replace","append","classes","height","width"].indexOf(t)}).forEach(function(n){r[n]=function(){var e=Array.prototype.slice.call(arguments,0);return r.svgElements.forEach(function(t){c.Svg.prototype[n].apply(t,e)}),r}})}})}(window,document,t),window,document,
/**
           * Chartist SVG path module for SVG path description creation and modification.
           *
           * @module Chartist.Svg.Path
           */
/* global Chartist */
u={m:["x","y"],l:["x","y"],c:["x1","y1","x2","y2","x","y"],a:["rx","ry","xAr","lAf","sf","x","y"]},n={
// The accuracy in digit count after the decimal point. This will be used to round numbers in the SVG path. If this option is set to false then no rounding will be performed.
accuracy:3},(c=t).Svg.Path=c.Class.extend({constructor:function(t,e){this.pathElements=[],this.pos=0,this.close=t,this.options=c.extend({},n,e)}
/**
             * Gets or sets the current position (cursor) inside of the path. You can move around the cursor freely but limited to 0 or the count of existing elements. All modifications with element functions will insert new elements at the position of this cursor.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} [pos] If a number is passed then the cursor is set to this position in the path element array.
             * @return {Chartist.Svg.Path|Number} If the position parameter was passed then the return value will be the path object for easy call chaining. If no position parameter was passed then the current position is returned.
             */,position:function(t){return void 0!==t?(this.pos=Math.max(0,Math.min(this.pathElements.length,t)),this):this.pos}
/**
             * Removes elements } from the path starting at the current position.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} count Number of path elements that should be removed } from the current position.
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,remove:function(t){return this.pathElements.splice(this.pos,t),this}
/**
             * Use this function to add a new move SVG path element.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} x The x coordinate for the move element.
             * @param {Number} y The y coordinate for the move element.
             * @param {Boolean} [relative] If set to true the move element will be created with relative coordinates (lowercase letter)
             * @param {*} [data] Any data that should be stored with the element object that will be accessible in pathElement
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,move:function(t,e,n,r){return g("M",{x:+t,y:+e},this.pathElements,this.pos++,n,r),this}
/**
             * Use this function to add a new line SVG path element.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} x The x coordinate for the line element.
             * @param {Number} y The y coordinate for the line element.
             * @param {Boolean} [relative] If set to true the line element will be created with relative coordinates (lowercase letter)
             * @param {*} [data] Any data that should be stored with the element object that will be accessible in pathElement
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,line:function(t,e,n,r){return g("L",{x:+t,y:+e},this.pathElements,this.pos++,n,r),this}
/**
             * Use this function to add a new curve SVG path element.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} x1 The x coordinate for the first control point of the bezier curve.
             * @param {Number} y1 The y coordinate for the first control point of the bezier curve.
             * @param {Number} x2 The x coordinate for the second control point of the bezier curve.
             * @param {Number} y2 The y coordinate for the second control point of the bezier curve.
             * @param {Number} x The x coordinate for the target point of the curve element.
             * @param {Number} y The y coordinate for the target point of the curve element.
             * @param {Boolean} [relative] If set to true the curve element will be created with relative coordinates (lowercase letter)
             * @param {*} [data] Any data that should be stored with the element object that will be accessible in pathElement
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,curve:function(t,e,n,r,a,i,o,s){return g("C",{x1:+t,y1:+e,x2:+n,y2:+r,x:+a,y:+i},this.pathElements,this.pos++,o,s),this}
/**
             * Use this function to add a new non-bezier curve SVG path element.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} rx The radius to be used for the x-axis of the arc.
             * @param {Number} ry The radius to be used for the y-axis of the arc.
             * @param {Number} xAr Defines the orientation of the arc
             * @param {Number} lAf Large arc flag
             * @param {Number} sf Sweep flag
             * @param {Number} x The x coordinate for the target point of the curve element.
             * @param {Number} y The y coordinate for the target point of the curve element.
             * @param {Boolean} [relative] If set to true the curve element will be created with relative coordinates (lowercase letter)
             * @param {*} [data] Any data that should be stored with the element object that will be accessible in pathElement
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,arc:function(t,e,n,r,a,i,o,s,c){return g("A",{rx:+t,ry:+e,xAr:+n,lAf:+r,sf:+a,x:+i,y:+o},this.pathElements,this.pos++,s,c),this}
/**
             * Parses an SVG path seen in the d attribute of path elements, and inserts the parsed elements into the existing path object at the current cursor position. Any closing path indicators (Z at the end of the path) will be ignored by the parser as this is provided by the close option in the options of the path object.
             *
             * @memberof Chartist.Svg.Path
             * @param {String} path Any SVG path that contains move (m), line (l) or curve (c) components.
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,scale:
/**
             * Scales all elements in the current SVG path object. There is an individual parameter for each coordinate. Scaling will also be done for control points of curves, affecting the given coordinate.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} x The number which will be used to scale the x, x1 and x2 of all path elements.
             * @param {Number} y The number which will be used to scale the y, y1 and y2 of all path elements.
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */
function(n,r){return e(this.pathElements,function(t,e){t[e]*="x"===e[0]?n:r}),this}
/**
             * Translates all elements in the current SVG path object. The translation is relative and there is an individual parameter for each coordinate. Translation will also be done for control points of curves, affecting the given coordinate.
             *
             * @memberof Chartist.Svg.Path
             * @param {Number} x The number which will be used to translate the x, x1 and x2 of all path elements.
             * @param {Number} y The number which will be used to translate the y, y1 and y2 of all path elements.
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,translate:function(n,r){return e(this.pathElements,function(t,e){t[e]+="x"===e[0]?n:r}),this}
/**
             * This function will run over all existing path elements and then loop over their attributes. The callback function will be called for every path element attribute that exists in the current path.
             * The method signature of the callback function looks like this:
             * ```javascript
             * function(pathElement, paramName, pathElementIndex, paramIndex, pathElements)
             * ```
             * If something else than undefined is returned by the callback function, this value will be used to replace the old value. This allows you to build custom transformations of path objects that can't be achieved using the basic transformation functions scale and translate.
             *
             * @memberof Chartist.Svg.Path
             * @param {Function} transformFnc The callback function for the transformation. Check the signature in the function description.
             * @return {Chartist.Svg.Path} The current path object for easy call chaining.
             */,transform:function(o){return e(this.pathElements,function(t,e,n,r,a){var i=o(t,e,n,r,a);!i&&0!==i||(t[e]=i)}),this}
/**
             * This function clones a whole path object with all its properties. This is a deep clone and path element objects will also be cloned.
             *
             * @memberof Chartist.Svg.Path
             * @param {Boolean} [close] Optional option to set the new cloned path to closed. If not specified or false, the original path close option will be used.
             * @return {Chartist.Svg.Path}
             */,parse:function(t){
// Parsing the SVG path string into an array of arrays [['M', '10', '10'], ['L', '100', '100']]
var e=t.replace(/([A-Za-z])([0-9])/g,"$1 $2").replace(/([0-9])([A-Za-z])/g,"$1 $2").split(/[\s,]+/).reduce(function(t,e){return e.match(/[A-Za-z]/)&&t.push([]),t[t.length-1].push(e),t},[]);// If this is a closed path we remove the Z at the end because this is determined by the close option
"Z"===e[e.length-1][0].toUpperCase()&&e.pop();// Using svgPathElementDescriptions to map raw path arrays into objects that contain the command and the parameters
// For example {command: 'M', x: '10', y: '10'}
var n=e.map(function(r){var t=r.shift(),e=u[t.toLowerCase()];return c.extend({command:t},e.reduce(function(t,e,n){return t[e]=+r[n],t},{}))}),r=[this.pos,0];// Preparing a splice call with the elements array as var arg params and insert the parsed elements at the current position
return Array.prototype.push.apply(r,n),Array.prototype.splice.apply(this.pathElements,r),// Increase the internal position by the element count
this.pos+=n.length,this}
/**
             * This function renders to current SVG path object into a final SVG string that can be used in the d attribute of SVG path elements. It uses the accuracy option to round big decimals. If the close parameter was set in the constructor of this path object then a path closing Z will be appended to the output string.
             *
             * @memberof Chartist.Svg.Path
             * @return {String}
             */,stringify:function(){var r=Math.pow(10,this.options.accuracy);return this.pathElements.reduce(function(t,e){var n=u[e.command.toLowerCase()].map(function(t){return this.options.accuracy?Math.round(e[t]*r)/r:e[t]}.bind(this));return t+e.command+n.join(",")}.bind(this),"")+(this.close?"Z":"")},clone:function(t){var e=new c.Svg.Path(t||this.close);return e.pos=this.pos,e.pathElements=this.pathElements.slice().map(function(t){return c.extend({},t)}),e.options=c.extend({},this.options),e}
/**
             * Split a Svg.Path object by a specific command in the path chain. The path chain will be split and an array of newly created paths objects will be returned. This is useful if you'd like to split an SVG path by it's move commands, for example, in order to isolate chunks of drawings.
             *
             * @memberof Chartist.Svg.Path
             * @param {String} command The command you'd like to use to split the path
             * @return {Array<Chartist.Svg.Path>}
             */,splitByCommand:function(e){var n=[new c.Svg.Path];return this.pathElements.forEach(function(t){t.command===e.toUpperCase()&&0!==n[n.length-1].pathElements.length&&n.push(new c.Svg.Path),n[n.length-1].pathElements.push(t)}),n}
/**
             * This static function on `Chartist.Svg.Path` is joining multiple paths together into one paths.
             *
             * @memberof Chartist.Svg.Path
             * @param {Array<Chartist.Svg.Path>} paths A list of paths to be joined together. The order is important.
             * @param {boolean} close If the newly created path should be a closed path
             * @param {Object} options Path options for the newly created path.
             * @return {Chartist.Svg.Path}
             */}),c.Svg.Path.elementDescriptions=u,c.Svg.Path.join=function(t,e,n){for(var r=new c.Svg.Path(e,n),a=0;a<t.length;a++)for(var i=t[a],o=0;o<i.pathElements.length;o++)r.pathElements.push(i.pathElements[o]);return r},window,document,
/* global Chartist */
a={x:{pos:"x",len:"width",dir:"horizontal",rectStart:"x1",rectEnd:"x2",rectOffset:"y2"},y:{pos:"y",len:"height",dir:"vertical",rectStart:"y2",rectEnd:"y1",rectOffset:"x1"}},(h=t).Axis=h.Class.extend({constructor:function(t,e,n,r){this.units=t,this.counterUnits=t===a.x?a.y:a.x,this.chartRect=e,this.axisLength=e[t.rectEnd]-e[t.rectStart],this.gridOffset=e[t.rectOffset],this.ticks=n,this.options=r},createGridAndLabels:function(a,i,o,s,c){var l=s["axis"+this.units.pos.toUpperCase()],u=this.ticks.map(this.projectValue.bind(this)),d=this.ticks.map(l.labelInterpolationFnc);u.forEach(function(t,e){var n,r={x:0,y:0};// TODO: Find better solution for solving this problem
// Calculate how much space we have available for the label
// If we still have one label ahead, we can calculate the distance to the next tick / label
n=u[e+1]?u[e+1]-t:Math.max(this.axisLength-t,30),// Skip grid lines and labels where interpolated label values are falsey (execpt for 0)
h.isFalseyButZero(d[e])&&""!==d[e]||(// Transform to global coordinates using the chartRect
// We also need to set the label offset for the createLabel function
"x"===this.units.pos?(t=this.chartRect.x1+t,r.x=s.axisX.labelOffset.x,// If the labels should be positioned in start position (top side for vertical axis) we need to set a
// different offset as for positioned with end (bottom)
"start"===s.axisX.position?r.y=this.chartRect.padding.top+s.axisX.labelOffset.y+(o?5:20):r.y=this.chartRect.y1+s.axisX.labelOffset.y+(o?5:20)):(t=this.chartRect.y1-t,r.y=s.axisY.labelOffset.y-(o?n:0),// If the labels should be positioned in start position (left side for horizontal axis) we need to set a
// different offset as for positioned with end (right side)
"start"===s.axisY.position?r.x=o?this.chartRect.padding.left+s.axisY.labelOffset.x:this.chartRect.x1-10:r.x=this.chartRect.x2+s.axisY.labelOffset.x+10),l.showGrid&&h.createGrid(t,e,this,this.gridOffset,this.chartRect[this.counterUnits.len](),a,[s.classNames.grid,s.classNames[this.units.dir]],c),l.showLabel&&h.createLabel(t,n,e,d,this,l.offset,r,i,[s.classNames.label,s.classNames[this.units.dir],"start"===l.position?s.classNames[l.position]:s.classNames.end],o,c))}.bind(this))},projectValue:function(t,e,n){throw new Error("Base axis can't be instantiated!")}}),h.Axis.units=a,window,document,(
/**
           * The auto scale axis uses standard linear scale projection of values along an axis. It uses order of magnitude to find a scale automatically and evaluates the available space in order to find the perfect amount of ticks for your chart.
           * **Options**
           * The following options are used by this axis in addition to the default axis options outlined in the axis configuration of the chart default settings.
           * ```javascript
           * var options = {
           *   // If high is specified then the axis will display values explicitly up to this value and the computed maximum } from the data is ignored
           *   high: 100,
           *   // If low is specified then the axis will display values explicitly down to this value and the computed minimum } from the data is ignored
           *   low: 0,
           *   // This option will be used when finding the right scale division settings. The amount of ticks on the scale will be determined so that as many ticks as possible will be displayed, while not violating this minimum required space (in pixel).
           *   scaleMinSpace: 20,
           *   // Can be set to true or false. If set to true, the scale will be generated with whole numbers only.
           *   onlyInteger: true,
           *   // The reference value can be used to make sure that this value will always be on the chart. This is especially useful on bipolar charts where the bipolar center always needs to be part of the chart.
           *   referenceValue: 5
           * };
           * ```
           *
           * @module Chartist.AutoScaleAxis
           */
/* global Chartist */
d=t).AutoScaleAxis=d.Axis.extend({constructor:function(t,e,n,r){
// Usually we calculate highLow based on the data but this can be overriden by a highLow object in the options
var a=r.highLow||d.getHighLow(e,r,t.pos);this.bounds=d.getBounds(n[t.rectEnd]-n[t.rectStart],a,r.scaleMinSpace||20,r.onlyInteger),this.range={min:this.bounds.min,max:this.bounds.max},d.AutoScaleAxis.super.constructor.call(this,t,n,this.bounds.values,r)},projectValue:function(t){return this.axisLength*(+d.getMultiValue(t,this.units.pos)-this.bounds.min)/this.bounds.range}}),window,document,(
/**
           * The fixed scale axis uses standard linear projection of values along an axis. It makes use of a divisor option to divide the range provided } from the minimum and maximum value or the options high and low that will override the computed minimum and maximum.
           * **Options**
           * The following options are used by this axis in addition to the default axis options outlined in the axis configuration of the chart default settings.
           * ```javascript
           * var options = {
           *   // If high is specified then the axis will display values explicitly up to this value and the computed maximum } from the data is ignored
           *   high: 100,
           *   // If low is specified then the axis will display values explicitly down to this value and the computed minimum } from the data is ignored
           *   low: 0,
           *   // If specified then the value range determined } from minimum to maximum (or low and high) will be divided by this number and ticks will be generated at those division points. The default divisor is 1.
           *   divisor: 4,
           *   // If ticks is explicitly set, then the axis will not compute the ticks with the divisor, but directly use the data in ticks to determine at what points on the axis a tick need to be generated.
           *   ticks: [1, 10, 20, 30]
           * };
           * ```
           *
           * @module Chartist.FixedScaleAxis
           */
/* global Chartist */
f=t).FixedScaleAxis=f.Axis.extend({constructor:function(t,e,n,r){var a=r.highLow||f.getHighLow(e,r,t.pos);this.divisor=r.divisor||1,this.ticks=r.ticks||f.times(this.divisor).map(function(t,e){return a.low+(a.high-a.low)/this.divisor*e}.bind(this)),this.ticks.sort(function(t,e){return t-e}),this.range={min:a.low,max:a.high},f.FixedScaleAxis.super.constructor.call(this,t,n,this.ticks,r),this.stepLength=this.axisLength/this.divisor},projectValue:function(t){return this.axisLength*(+f.getMultiValue(t,this.units.pos)-this.range.min)/(this.range.max-this.range.min)}}),window,document,(
/**
           * The step axis for step based charts like bar chart or step based line charts. It uses a fixed amount of ticks that will be equally distributed across the whole axis length. The projection is done using the index of the data value rather than the value itself and therefore it's only useful for distribution purpose.
           * **Options**
           * The following options are used by this axis in addition to the default axis options outlined in the axis configuration of the chart default settings.
           * ```javascript
           * var options = {
           *   // Ticks to be used to distribute across the axis length. As this axis type relies on the index of the value rather than the value, arbitrary data that can be converted to a string can be used as ticks.
           *   ticks: ['One', 'Two', 'Three'],
           *   // If set to true the full width will be used to distribute the values where the last value will be at the maximum of the axis length. If false the spaces between the ticks will be evenly distributed instead.
           *   stretch: true
           * };
           * ```
           *
           * @module Chartist.StepAxis
           */
/* global Chartist */
m=t).StepAxis=m.Axis.extend({constructor:function(t,e,n,r){m.StepAxis.super.constructor.call(this,t,n,r.ticks,r);var a=Math.max(1,r.ticks.length-(r.stretch?1:0));this.stepLength=this.axisLength/a},projectValue:function(t,e){return this.stepLength*e}}),window,document,
/**
           * The Chartist line chart can be used to draw Line or Scatter charts. If used in the browser you can access the global `Chartist` namespace where you find the `Line` function as a main entry point.
           *
           * For examples on how to use the line chart please check the examples of the `Chartist.Line` method.
           *
           * @module Chartist.Line
           */
/* global Chartist */
A={
// Options for X-Axis
axisX:{
// The offset of the labels to the chart area
offset:30,
// Position where labels are placed. Can be set to `start` or `end` where `start` is equivalent to left or top on vertical axis and `end` is equivalent to right or bottom on horizontal axis.
position:"end",
// Allows you to correct label positioning on this axis by positive or negative x and y offset.
labelOffset:{x:0,y:0},
// If labels should be shown or not
showLabel:!0,
// If the axis grid should be drawn or not
showGrid:!0,
// Interpolation function that allows you to intercept the value } from the axis label
labelInterpolationFnc:(_=t).noop,
// Set the axis type to be used to project values on this axis. If not defined, Chartist.StepAxis will be used for the X-Axis, where the ticks option will be set to the labels in the data and the stretch option will be set to the global fullWidth option. This type can be changed to any axis constructor available (e.g. Chartist.FixedScaleAxis), where all axis options should be present here.
type:void 0},
// Options for Y-Axis
axisY:{
// The offset of the labels to the chart area
offset:40,
// Position where labels are placed. Can be set to `start` or `end` where `start` is equivalent to left or top on vertical axis and `end` is equivalent to right or bottom on horizontal axis.
position:"start",
// Allows you to correct label positioning on this axis by positive or negative x and y offset.
labelOffset:{x:0,y:0},
// If labels should be shown or not
showLabel:!0,
// If the axis grid should be drawn or not
showGrid:!0,
// Interpolation function that allows you to intercept the value } from the axis label
labelInterpolationFnc:_.noop,
// Set the axis type to be used to project values on this axis. If not defined, Chartist.AutoScaleAxis will be used for the Y-Axis, where the high and low options will be set to the global high and low options. This type can be changed to any axis constructor available (e.g. Chartist.FixedScaleAxis), where all axis options should be present here.
type:void 0,
// This value specifies the minimum height in pixel of the scale steps
scaleMinSpace:20,
// Use only integer values (whole numbers) for the scale steps
onlyInteger:!1},
// Specify a fixed width for the chart as a string (i.e. '100px' or '50%')
width:void 0,
// Specify a fixed height for the chart as a string (i.e. '100px' or '50%')
height:void 0,
// If the line should be drawn or not
showLine:!0,
// If dots should be drawn or not
showPoint:!0,
// If the line chart should draw an area
showArea:!1,
// The base for the area chart that will be used to close the area shape (is normally 0)
areaBase:0,
// Specify if the lines should be smoothed. This value can be true or false where true will result in smoothing using the default smoothing interpolation function Chartist.Interpolation.cardinal and false results in Chartist.Interpolation.none. You can also choose other smoothing / interpolation functions available in the Chartist.Interpolation module, or write your own interpolation function. Check the examples for a brief description.
lineSmooth:!0,
// If the line chart should add a background fill to the .ct-grids group.
showGridBackground:!1,
// Overriding the natural low of the chart allows you to zoom in or limit the charts lowest displayed value
low:void 0,
// Overriding the natural high of the chart allows you to zoom in or limit the charts highest displayed value
high:void 0,
// Padding of the chart drawing area to the container element and labels as a number or padding object {top: 5, right: 5, bottom: 5, left: 5}
chartPadding:{top:15,right:15,bottom:5,left:10},
// When set to true, the last grid line on the x-axis is not drawn and the chart elements will expand to the full available width of the chart. For the last label to be drawn correctly you might need to add chart padding or offset the last label with a draw event handler.
fullWidth:!1,
// If true the whole data is reversed including labels, the series order as well as the whole series data arrays.
reverseData:!1,
// Override the class names that get used to generate the SVG structure of the chart
classNames:{chart:"ct-chart-line",label:"ct-label",labelGroup:"ct-labels",series:"ct-series",line:"ct-line",point:"ct-point",area:"ct-area",grid:"ct-grid",gridGroup:"ct-grids",gridBackground:"ct-grid-background",vertical:"ct-vertical",horizontal:"ct-horizontal",start:"ct-start",end:"ct-end"}},// Creating line chart type in Chartist namespace
_.Line=_.Base.extend({constructor:
/**
             * This method creates a new line chart.
             *
             * @memberof Chartist.Line
             * @param {String|Node} query A selector query string or directly a DOM element
             * @param {Object} data The data object that needs to consist of a labels and a series array
             * @param {Object} [options] The options object with options that override the default options. Check the examples for a detailed list.
             * @param {Array} [responsiveOptions] Specify an array of responsive option arrays which are a media query and options object pair => [[mediaQueryString, optionsObject],[more...]]
             * @return {Object} An object which exposes the API for the created chart
             *
             * @example
             * // Create a simple line chart
             * var data = {
             *   // A labels array that can contain any sort of values
             *   labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
             *   // Our series array that contains series objects or in this case series data arrays
             *   series: [
             *     [5, 2, 4, 2, 0]
             *   ]
             * };
             *
             * // As options we currently only set a static size of 300x200 px
             * var options = {
             *   width: '300px',
             *   height: '200px'
             * };
             *
             * // In the global name space Chartist we call the Line function to initialize a line chart. As a first parameter we pass in a selector where we would like to get our chart created. Second parameter is the actual data object and as a third parameter we pass in our options
             * new Chartist.Line('.ct-chart', data, options);
             *
             * @example
             * // Use specific interpolation function with configuration } from the Chartist.Interpolation module
             *
             * var chart = new Chartist.Line('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5],
             *   series: [
             *     [1, 1, 8, 1, 7]
             *   ]
             * }, {
             *   lineSmooth: Chartist.Interpolation.cardinal({
             *     tension: 0.2
             *   })
             * });
             *
             * @example
             * // Create a line chart with responsive options
             *
             * var data = {
             *   // A labels array that can contain any sort of values
             *   labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
             *   // Our series array that contains series objects or in this case series data arrays
             *   series: [
             *     [5, 2, 4, 2, 0]
             *   ]
             * };
             *
             * // In addition to the regular options we specify responsive option overrides that will override the default configutation based on the matching media queries.
             * var responsiveOptions = [
             *   ['screen and (min-width: 641px) and (max-width: 1024px)', {
             *     showPoint: false,
             *     axisX: {
             *       labelInterpolationFnc: function(value) {
             *         // Will return Mon, Tue, Wed etc. on medium screens
             *         return value.slice(0, 3);
             *       }
             *     }
             *   }],
             *   ['screen and (max-width: 640px)', {
             *     showLine: false,
             *     axisX: {
             *       labelInterpolationFnc: function(value) {
             *         // Will return M, T, W etc. on small screens
             *         return value[0];
             *       }
             *     }
             *   }]
             * ];
             *
             * new Chartist.Line('.ct-chart', data, null, responsiveOptions);
             *
             */
function(t,e,n,r){_.Line.super.constructor.call(this,t,e,A,_.extend({},A,n),r)},createChart:
/**
             * Creates a new chart
             *
             */
function(u){var d=_.normalizeData(this.data,u.reverseData,!0);// Create new svg object
this.svg=_.createSvg(this.container,u.width,u.height,u.classNames.chart);// Create groups for labels, grid and series
var h,f,t=this.svg.elem("g").addClass(u.classNames.gridGroup),p=this.svg.elem("g"),e=this.svg.elem("g").addClass(u.classNames.labelGroup),E=_.createChartRect(this.svg,u,A.padding);h=void 0===u.axisX.type?new _.StepAxis(_.Axis.units.x,d.normalized.series,E,_.extend({},u.axisX,{ticks:d.normalized.labels,stretch:u.fullWidth})):u.axisX.type.call(_,_.Axis.units.x,d.normalized.series,E,u.axisX),f=void 0===u.axisY.type?new _.AutoScaleAxis(_.Axis.units.y,d.normalized.series,E,_.extend({},u.axisY,{high:_.isNumeric(u.high)?u.high:u.axisY.high,low:_.isNumeric(u.low)?u.low:u.axisY.low})):u.axisY.type.call(_,_.Axis.units.y,d.normalized.series,E,u.axisY),h.createGridAndLabels(t,e,this.supportsForeignObject,u,this.eventEmitter),f.createGridAndLabels(t,e,this.supportsForeignObject,u,this.eventEmitter),u.showGridBackground&&_.createGridBackground(t,E,u.classNames.gridBackground,this.eventEmitter),// Draw the series
d.raw.series.forEach(function(r,a){var n=p.elem("g");// Write attributes to series group element. If series name or meta is undefined the attributes will not be written
n.attr({"ct:series-name":r.name,"ct:meta":_.serialize(r.meta)}),// Use series class } from series data or if not set generate one
n.addClass([u.classNames.series,r.className||u.classNames.series+"-"+_.alphaNumerate(a)].join(" "));var i=[],o=[];d.normalized.series[a].forEach(function(t,e){var n={x:E.x1+h.projectValue(t,e,d.normalized.series[a]),y:E.y1-f.projectValue(t,e,d.normalized.series[a])};i.push(n.x,n.y),o.push({value:t,valueIndex:e,meta:_.getMetaData(r,e)})}.bind(this));var t={lineSmooth:_.getSeriesOption(r,u,"lineSmooth"),showPoint:_.getSeriesOption(r,u,"showPoint"),showLine:_.getSeriesOption(r,u,"showLine"),showArea:_.getSeriesOption(r,u,"showArea"),areaBase:_.getSeriesOption(r,u,"areaBase")},e=("function"==typeof t.lineSmooth?t.lineSmooth:t.lineSmooth?_.Interpolation.monotoneCubic():_.Interpolation.none())(i,o);if(// If we should show points we need to create them now to avoid secondary loop
// Points are drawn } from the pathElements returned by the interpolation function
// Small offset for Firefox to render squares correctly
t.showPoint&&e.pathElements.forEach(function(t){var e=n.elem("line",{x1:t.x,y1:t.y,x2:t.x+.01,y2:t.y},u.classNames.point).attr({"ct:value":[t.data.value.x,t.data.value.y].filter(_.isNumeric).join(","),"ct:meta":_.serialize(t.data.meta)});this.eventEmitter.emit("draw",{type:"point",value:t.data.value,index:t.data.valueIndex,meta:t.data.meta,series:r,seriesIndex:a,axisX:h,axisY:f,group:n,element:e,x:t.x,y:t.y})}.bind(this)),t.showLine){var s=n.elem("path",{d:e.stringify()},u.classNames.line,!0);this.eventEmitter.emit("draw",{type:"line",values:d.normalized.series[a],path:e.clone(),chartRect:E,index:a,series:r,seriesIndex:a,seriesMeta:r.meta,axisX:h,axisY:f,group:n,element:s})}// Area currently only works with axes that support a range!
if(t.showArea&&f.range){
// If areaBase is outside the chart area (< min or > max) we need to set it respectively so that
// the area is not drawn outside the chart area.
var c=Math.max(Math.min(t.areaBase,f.range.max),f.range.min),l=E.y1-f.projectValue(c);// We project the areaBase value into screen coordinates
// In order to form the area we'll first split the path by move commands so we can chunk it up into segments
e.splitByCommand("M").filter(function(t){
// We filter only "solid" segments that contain more than one point. Otherwise there's no need for an area
return 1<t.pathElements.length}).map(function(t){
// Receiving the filtered solid path segments we can now convert those segments into fill areas
var e=t.pathElements[0],n=t.pathElements[t.pathElements.length-1];// Cloning the solid path segment with closing option and removing the first move command } from the clone
// We then insert a new move that should start at the area base and draw a straight line up or down
// at the end of the path we add an additional straight line to the projected area base value
// As the closing option is set our path will be automatically closed
return t.clone(!0).position(0).remove(1).move(e.x,l).line(e.x,e.y).position(t.pathElements.length+1).line(n.x,l)}).forEach(function(t){
// For each of our newly created area paths, we'll now create path elements by stringifying our path objects
// and adding the created DOM elements to the correct series group
var e=n.elem("path",{d:t.stringify()},u.classNames.area,!0);// Emit an event for each area that was drawn
this.eventEmitter.emit("draw",{type:"area",values:d.normalized.series[a],path:t.clone(),series:r,seriesIndex:a,axisX:h,axisY:f,chartRect:E,index:a,group:n,element:e})}.bind(this))}}.bind(this)),this.eventEmitter.emit("created",{bounds:f.bounds,chartRect:E,axisX:h,axisY:f,svg:this.svg,options:u})}}),window,document,
/**
           * The bar chart module of Chartist that can be used to draw unipolar or bipolar bar and grouped bar charts.
           *
           * @module Chartist.Bar
           */
/* global Chartist */
y={
// Options for X-Axis
axisX:{
// The offset of the chart drawing area to the border of the container
offset:30,
// Position where labels are placed. Can be set to `start` or `end` where `start` is equivalent to left or top on vertical axis and `end` is equivalent to right or bottom on horizontal axis.
position:"end",
// Allows you to correct label positioning on this axis by positive or negative x and y offset.
labelOffset:{x:0,y:0},
// If labels should be shown or not
showLabel:!0,
// If the axis grid should be drawn or not
showGrid:!0,
// Interpolation function that allows you to intercept the value } from the axis label
labelInterpolationFnc:(v=t).noop,
// This value specifies the minimum width in pixel of the scale steps
scaleMinSpace:30,
// Use only integer values (whole numbers) for the scale steps
onlyInteger:!1},
// Options for Y-Axis
axisY:{
// The offset of the chart drawing area to the border of the container
offset:40,
// Position where labels are placed. Can be set to `start` or `end` where `start` is equivalent to left or top on vertical axis and `end` is equivalent to right or bottom on horizontal axis.
position:"start",
// Allows you to correct label positioning on this axis by positive or negative x and y offset.
labelOffset:{x:0,y:0},
// If labels should be shown or not
showLabel:!0,
// If the axis grid should be drawn or not
showGrid:!0,
// Interpolation function that allows you to intercept the value } from the axis label
labelInterpolationFnc:v.noop,
// This value specifies the minimum height in pixel of the scale steps
scaleMinSpace:20,
// Use only integer values (whole numbers) for the scale steps
onlyInteger:!1},
// Specify a fixed width for the chart as a string (i.e. '100px' or '50%')
width:void 0,
// Specify a fixed height for the chart as a string (i.e. '100px' or '50%')
height:void 0,
// Overriding the natural high of the chart allows you to zoom in or limit the charts highest displayed value
high:void 0,
// Overriding the natural low of the chart allows you to zoom in or limit the charts lowest displayed value
low:void 0,
// Unless low/high are explicitly set, bar chart will be centered at zero by default. Set referenceValue to null to auto scale.
referenceValue:0,
// Padding of the chart drawing area to the container element and labels as a number or padding object {top: 5, right: 5, bottom: 5, left: 5}
chartPadding:{top:15,right:15,bottom:5,left:10},
// Specify the distance in pixel of bars in a group
seriesBarDistance:15,
// If set to true this property will cause the series bars to be stacked. Check the `stackMode` option for further stacking options.
stackBars:!1,
// If set to 'overlap' this property will force the stacked bars to draw } from the zero line.
// If set to 'accumulate' this property will form a total for each series point. This will also influence the y-axis and the overall bounds of the chart. In stacked mode the seriesBarDistance property will have no effect.
stackMode:"accumulate",
// Inverts the axes of the bar chart in order to draw a horizontal bar chart. Be aware that you also need to invert your axis settings as the Y Axis will now display the labels and the X Axis the values.
horizontalBars:!1,
// If set to true then each bar will represent a series and the data array is expected to be a one dimensional array of data values rather than a series array of series. This is useful if the bar chart should represent a profile rather than some data over time.
distributeSeries:!1,
// If true the whole data is reversed including labels, the series order as well as the whole series data arrays.
reverseData:!1,
// If the bar chart should add a background fill to the .ct-grids group.
showGridBackground:!1,
// Override the class names that get used to generate the SVG structure of the chart
classNames:{chart:"ct-chart-bar",horizontalBars:"ct-horizontal-bars",label:"ct-label",labelGroup:"ct-labels",series:"ct-series",bar:"ct-bar",grid:"ct-grid",gridGroup:"ct-grids",gridBackground:"ct-grid-background",vertical:"ct-vertical",horizontal:"ct-horizontal",start:"ct-start",end:"ct-end"}},// Creating bar chart type in Chartist namespace
v.Bar=v.Base.extend({constructor:
/**
             * This method creates a new bar chart and returns API object that you can use for later changes.
             *
             * @memberof Chartist.Bar
             * @param {String|Node} query A selector query string or directly a DOM element
             * @param {Object} data The data object that needs to consist of a labels and a series array
             * @param {Object} [options] The options object with options that override the default options. Check the examples for a detailed list.
             * @param {Array} [responsiveOptions] Specify an array of responsive option arrays which are a media query and options object pair => [[mediaQueryString, optionsObject],[more...]]
             * @return {Object} An object which exposes the API for the created chart
             *
             * @example
             * // Create a simple bar chart
             * var data = {
             *   labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
             *   series: [
             *     [5, 2, 4, 2, 0]
             *   ]
             * };
             *
             * // In the global name space Chartist we call the Bar function to initialize a bar chart. As a first parameter we pass in a selector where we would like to get our chart created and as a second parameter we pass our data object.
             * new Chartist.Bar('.ct-chart', data);
             *
             * @example
             * // This example creates a bipolar grouped bar chart where the boundaries are limitted to -10 and 10
             * new Chartist.Bar('.ct-chart', {
             *   labels: [1, 2, 3, 4, 5, 6, 7],
             *   series: [
             *     [1, 3, 2, -5, -3, 1, -6],
             *     [-5, -2, -4, -1, 2, -3, 1]
             *   ]
             * }, {
             *   seriesBarDistance: 12,
             *   low: -10,
             *   high: 10
             * });
             *
             */
function(t,e,n,r){v.Bar.super.constructor.call(this,t,e,y,v.extend({},y,n),r)},createChart:
/**
             * Creates a new chart
             *
             */
function(f){var p,t;f.distributeSeries?(p=v.normalizeData(this.data,f.reverseData,f.horizontalBars?"x":"y")).normalized.series=p.normalized.series.map(function(t){return[t]}):p=v.normalizeData(this.data,f.reverseData,f.horizontalBars?"x":"y"),// Create new svg element
this.svg=v.createSvg(this.container,f.width,f.height,f.classNames.chart+(f.horizontalBars?" "+f.classNames.horizontalBars:""));// Drawing groups in correct order
var e=this.svg.elem("g").addClass(f.classNames.gridGroup),n=this.svg.elem("g"),r=this.svg.elem("g").addClass(f.classNames.labelGroup);if(f.stackBars&&0!==p.normalized.series.length){
// If stacked bars we need to calculate the high low } from stacked values } from each series
var a=v.serialMap(p.normalized.series,function(){return Array.prototype.slice.call(arguments).map(function(t){return t}).reduce(function(t,e){return{x:t.x+(e&&e.x)||0,y:t.y+(e&&e.y)||0}},{x:0,y:0})});t=v.getHighLow([a],f,f.horizontalBars?"x":"y")}else t=v.getHighLow(p.normalized.series,f,f.horizontalBars?"x":"y");// Overrides of high / low } from settings
t.high=+f.high||(0===f.high?0:t.high),t.low=+f.low||(0===f.low?0:t.low);var E,i,S,m,_,A=v.createChartRect(this.svg,f,y.padding);// We need to set step count based on some options combinations
// If distributed series are enabled and bars need to be stacked, we'll only have one bar and therefore should
// use only the first label for the step axis
i=f.distributeSeries&&f.stackBars?p.normalized.labels.slice(0,1):p.normalized.labels,// Set labelAxis and valueAxis based on the horizontalBars setting. This setting will flip the axes if necessary.
f.horizontalBars?(E=m=void 0===f.axisX.type?new v.AutoScaleAxis(v.Axis.units.x,p.normalized.series,A,v.extend({},f.axisX,{highLow:t,referenceValue:0})):f.axisX.type.call(v,v.Axis.units.x,p.normalized.series,A,v.extend({},f.axisX,{highLow:t,referenceValue:0})),S=_=void 0===f.axisY.type?new v.StepAxis(v.Axis.units.y,p.normalized.series,A,{ticks:i}):f.axisY.type.call(v,v.Axis.units.y,p.normalized.series,A,f.axisY)):(S=m=void 0===f.axisX.type?new v.StepAxis(v.Axis.units.x,p.normalized.series,A,{ticks:i}):f.axisX.type.call(v,v.Axis.units.x,p.normalized.series,A,f.axisX),E=_=void 0===f.axisY.type?new v.AutoScaleAxis(v.Axis.units.y,p.normalized.series,A,v.extend({},f.axisY,{highLow:t,referenceValue:0})):f.axisY.type.call(v,v.Axis.units.y,p.normalized.series,A,v.extend({},f.axisY,{highLow:t,referenceValue:0})));// Projected 0 point
var g=f.horizontalBars?A.x1+E.projectValue(0):A.y1-E.projectValue(0),T=[];// Used to track the screen coordinates of stacked bars
S.createGridAndLabels(e,r,this.supportsForeignObject,f,this.eventEmitter),E.createGridAndLabels(e,r,this.supportsForeignObject,f,this.eventEmitter),f.showGridBackground&&v.createGridBackground(e,A,f.classNames.gridBackground,this.eventEmitter),// Draw the series
p.raw.series.forEach(function(c,l){
// Calculating bi-polar value of index for seriesOffset. For i = 0..4 biPol will be -1.5, -0.5, 0.5, 1.5 etc.
var u,d,h=l-(p.raw.series.length-1)/2;// Half of the period width between vertical grid lines used to position bars
// We need to set periodHalfLength based on some options combinations
// If distributed series are enabled but stacked bars aren't, we need to use the length of the normaizedData array
// which is the series count and divide by 2
u=f.distributeSeries&&!f.stackBars?S.axisLength/p.normalized.series.length/2:f.distributeSeries&&f.stackBars?S.axisLength/2:S.axisLength/p.normalized.series[l].length/2,// Write attributes to series group element. If series name or meta is undefined the attributes will not be written
(// Adding the series group to the series element
d=n.elem("g")).attr({"ct:series-name":c.name,"ct:meta":v.serialize(c.meta)}),// Use series class } from series data or if not set generate one
d.addClass([f.classNames.series,c.className||f.classNames.series+"-"+v.alphaNumerate(l)].join(" ")),p.normalized.series[l].forEach(function(t,e){var n,r,a,i;// We need to set labelAxisValueIndex based on some options combinations
// Skip if value is undefined
if(
// If distributed series are enabled but stacked bars aren't, we can use the seriesIndex for later projection
// on the step axis for label positioning
i=f.distributeSeries&&!f.stackBars?l:f.distributeSeries&&f.stackBars?0:e,// We need to transform coordinates differently based on the chart layout
n=f.horizontalBars?{x:A.x1+E.projectValue(t&&t.x?t.x:0,e,p.normalized.series[l]),y:A.y1-S.projectValue(t&&t.y?t.y:0,i,p.normalized.series[l])}:{x:A.x1+S.projectValue(t&&t.x?t.x:0,i,p.normalized.series[l]),y:A.y1-E.projectValue(t&&t.y?t.y:0,e,p.normalized.series[l])},// If the label axis is a step based axis we will offset the bar into the middle of between two steps using
// the periodHalfLength value. Also we do arrange the different series so that they align up to each other using
// the seriesBarDistance. If we don't have a step axis, the bar positions can be chosen freely so we should not
// add any automated positioning.
S instanceof v.StepAxis&&(
// Offset to center bar between grid lines, but only if the step axis is not stretched
S.options.stretch||(n[S.units.pos]+=u*(f.horizontalBars?-1:1)),// Using bi-polar offset for multiple series if no stacked bars or series distribution is used
n[S.units.pos]+=f.stackBars||f.distributeSeries?0:h*f.seriesBarDistance*(f.horizontalBars?-1:1)),// Enter value in stacked bar values used to remember previous screen value for stacking up bars
a=T[e]||g,T[e]=a-(g-n[S.counterUnits.pos]),void 0!==t){var o={};o[S.units.pos+"1"]=n[S.units.pos],o[S.units.pos+"2"]=n[S.units.pos],!f.stackBars||"accumulate"!==f.stackMode&&f.stackMode?(
// Draw } from the zero line normally
// This is also the same code for Stack mode: overlap
o[S.counterUnits.pos+"1"]=g,o[S.counterUnits.pos+"2"]=n[S.counterUnits.pos]):(
// Stack mode: accumulate (default)
// If bars are stacked we use the stackedBarValues reference and otherwise base all bars off the zero line
// We want backwards compatibility, so the expected fallback without the 'stackMode' option
// to be the original behaviour (accumulate)
o[S.counterUnits.pos+"1"]=a,o[S.counterUnits.pos+"2"]=T[e]),// Limit x and y so that they are within the chart rect
o.x1=Math.min(Math.max(o.x1,A.x1),A.x2),o.x2=Math.min(Math.max(o.x2,A.x1),A.x2),o.y1=Math.min(Math.max(o.y1,A.y2),A.y1),o.y2=Math.min(Math.max(o.y2,A.y2),A.y1);var s=v.getMetaData(c,e);// Create bar element
r=d.elem("line",o,f.classNames.bar).attr({"ct:value":[t.x,t.y].filter(v.isNumeric).join(","),"ct:meta":v.serialize(s)}),this.eventEmitter.emit("draw",v.extend({type:"bar",value:t,index:e,meta:s,series:c,seriesIndex:l,axisX:m,axisY:_,chartRect:A,group:d,element:r},o))}}.bind(this))}.bind(this)),this.eventEmitter.emit("created",{bounds:E.bounds,chartRect:A,axisX:m,axisY:_,svg:this.svg,options:f})}}),window,document,
/**
           * The pie chart module of Chartist that can be used to draw pie, donut or gauge charts
           *
           * @module Chartist.Pie
           */
/* global Chartist */
b={
// Specify a fixed width for the chart as a string (i.e. '100px' or '50%')
width:void 0,
// Specify a fixed height for the chart as a string (i.e. '100px' or '50%')
height:void 0,
// Padding of the chart drawing area to the container element and labels as a number or padding object {top: 5, right: 5, bottom: 5, left: 5}
chartPadding:5,
// Override the class names that are used to generate the SVG structure of the chart
classNames:{chartPie:"ct-chart-pie",chartDonut:"ct-chart-donut",series:"ct-series",slicePie:"ct-slice-pie",sliceDonut:"ct-slice-donut",sliceDonutSolid:"ct-slice-donut-solid",label:"ct-label"},
// The start angle of the pie chart in degrees where 0 points north. A higher value offsets the start angle clockwise.
startAngle:0,
// An optional total you can specify. By specifying a total value, the sum of the values in the series must be this total in order to draw a full pie. You can use this parameter to draw only parts of a pie or gauge charts.
total:void 0,
// If specified the donut CSS classes will be used and strokes will be drawn instead of pie slices.
donut:!1,
// If specified the donut segments will be drawn as shapes instead of strokes.
donutSolid:!1,
// Specify the donut stroke width, currently done in javascript for convenience. May move to CSS styles in the future.
// This option can be set as number or string to specify a relative width (i.e. 100 or '30%').
donutWidth:60,
// If a label should be shown or not
showLabel:!0,
// Label position offset } from the standard position which is half distance of the radius. This value can be either positive or negative. Positive values will position the label away } from the center.
labelOffset:0,
// This option can be set to 'inside', 'outside' or 'center'. Positioned with 'inside' the labels will be placed on half the distance of the radius to the border of the Pie by respecting the 'labelOffset'. The 'outside' option will place the labels at the border of the pie and 'center' will place the labels in the absolute center point of the chart. The 'center' option only makes sense in conjunction with the 'labelOffset' option.
labelPosition:"inside",
// An interpolation function for the label value
labelInterpolationFnc:(N=t).noop,
// Label direction can be 'neutral', 'explode' or 'implode'. The labels anchor will be positioned based on those settings as well as the fact if the labels are on the right or left side of the center of the chart. Usually explode is useful when labels are positioned far away } from the center.
labelDirection:"neutral",
// If true the whole data is reversed including labels, the series order as well as the whole series data arrays.
reverseData:!1,
// If true empty values will be ignored to avoid drawing unncessary slices and labels
ignoreEmptyValues:!1},// Creating pie chart type in Chartist namespace
N.Pie=N.Base.extend({constructor:
/**
             * This method creates a new pie chart and returns an object that can be used to redraw the chart.
             *
             * @memberof Chartist.Pie
             * @param {String|Node} query A selector query string or directly a DOM element
             * @param {Object} data The data object in the pie chart needs to have a series property with a one dimensional data array. The values will be normalized against each other and don't necessarily need to be in percentage. The series property can also be an array of value objects that contain a value property and a className property to override the CSS class name for the series group.
             * @param {Object} [options] The options object with options that override the default options. Check the examples for a detailed list.
             * @param {Array} [responsiveOptions] Specify an array of responsive option arrays which are a media query and options object pair => [[mediaQueryString, optionsObject],[more...]]
             * @return {Object} An object with a version and an update method to manually redraw the chart
             *
             * @example
             * // Simple pie chart example with four series
             * new Chartist.Pie('.ct-chart', {
             *   series: [10, 2, 4, 3]
             * });
             *
             * @example
             * // Drawing a donut chart
             * new Chartist.Pie('.ct-chart', {
             *   series: [10, 2, 4, 3]
             * }, {
             *   donut: true
             * });
             *
             * @example
             * // Using donut, startAngle and total to draw a gauge chart
             * new Chartist.Pie('.ct-chart', {
             *   series: [20, 10, 30, 40]
             * }, {
             *   donut: true,
             *   donutWidth: 20,
             *   startAngle: 270,
             *   total: 200
             * });
             *
             * @example
             * // Drawing a pie chart with padding and labels that are outside the pie
             * new Chartist.Pie('.ct-chart', {
             *   series: [20, 10, 30, 40]
             * }, {
             *   chartPadding: 30,
             *   labelOffset: 50,
             *   labelDirection: 'explode'
             * });
             *
             * @example
             * // Overriding the class names for individual series as well as a name and meta data.
             * // The name will be written as ct:series-name attribute and the meta data will be serialized and written
             * // to a ct:meta attribute.
             * new Chartist.Pie('.ct-chart', {
             *   series: [{
             *     value: 20,
             *     name: 'Series 1',
             *     className: 'my-custom-class-one',
             *     meta: 'Meta One'
             *   }, {
             *     value: 10,
             *     name: 'Series 2',
             *     className: 'my-custom-class-two',
             *     meta: 'Meta Two'
             *   }, {
             *     value: 70,
             *     name: 'Series 3',
             *     className: 'my-custom-class-three',
             *     meta: 'Meta Three'
             *   }]
             * });
             */
function(t,e,n,r){N.Pie.super.constructor.call(this,t,e,b,N.extend({},b,n),r)},createChart:function(S){var m,t,_,A,g,T=N.normalizeData(this.data),v=[],y=S.startAngle;// Create SVG.js draw
this.svg=N.createSvg(this.container,S.width,S.height,S.donut?S.classNames.chartDonut:S.classNames.chartPie),// Calculate charting rect
t=N.createChartRect(this.svg,S,b.padding),// Get biggest circle radius possible within chartRect
_=Math.min(t.width()/2,t.height()/2),// Calculate total of all series to get reference value or use total reference } from optional options
g=S.total||T.normalized.series.reduce(function(t,e){return t+e},0);var O=N.quantity(S.donutWidth);"%"===O.unit&&(O.value*=_/100),// If this is a donut chart we need to adjust our radius to enable strokes to be drawn inside
// Unfortunately this is not possible with the current SVG Spec
// See this proposal for more details: http://lists.w3.org/Archives/Public/www-svg/2003Oct/0000.html
_-=S.donut&&!S.donutSolid?O.value/2:0,// If labelPosition is set to `outside` or a donut chart is drawn then the label position is at the radius,
// if regular pie chart it's half of the radius
A="outside"===S.labelPosition||S.donut&&!S.donutSolid?_:"center"===S.labelPosition?0:S.donutSolid?_-O.value/2:_/2,// Add the offset to the labelRadius where a negative offset means closed to the center of the chart
A+=S.labelOffset;// Calculate end angle based on total sum and current data value and offset with padding
var C={x:t.x1+t.width()/2,y:t.y2+t.height()/2},R=1===T.raw.series.filter(function(t){return t.hasOwnProperty("value")?0!==t.value:0!==t}).length;// Check if there is only one non-zero value in the series array.
// Creating the series groups
T.raw.series.forEach(function(t,e){v[e]=this.svg.elem("g",null,null)}.bind(this)),//if we need to show labels we create the label group now
S.showLabel&&(m=this.svg.elem("g",null,null)),// Draw the series
// initialize series groups
T.raw.series.forEach(function(t,e){
// If current value is zero and we are ignoring empty values then skip to next value
if(0!==T.normalized.series[e]||!S.ignoreEmptyValues){// If the series is an object and contains a name or meta data we add a custom attribute
v[e].attr({"ct:series-name":t.name}),// Use series class } from series data or if not set generate one
v[e].addClass([S.classNames.series,t.className||S.classNames.series+"-"+N.alphaNumerate(e)].join(" "));// If the whole dataset is 0 endAngle should be zero. Can't divide by 0.
var n=0<g?y+T.normalized.series[e]/g*360:0,r=Math.max(0,y-(0===e||R?0:.2));// Use slight offset so there are no transparent hairline issues
// If we need to draw the arc for all 360 degrees we need to add a hack where we close the circle
// with Z and use 359.99 degrees
359.99<=n-r&&(n=r+359.99);var a,i,o,s=N.polarToCartesian(C.x,C.y,_,r),c=N.polarToCartesian(C.x,C.y,_,n),l=new N.Svg.Path(!S.donut||S.donutSolid).move(c.x,c.y).arc(_,_,0,180<n-y,0,s.x,s.y);// If regular pie chart (no donut) we add a line to the center of the circle for completing the pie
S.donut?S.donutSolid&&(o=_-O.value,a=N.polarToCartesian(C.x,C.y,o,y-(0===e||R?0:.2)),i=N.polarToCartesian(C.x,C.y,o,n),l.line(a.x,a.y),l.arc(o,o,0,180<n-y,1,i.x,i.y)):l.line(C.x,C.y);// Create the SVG path
// If this is a donut chart we add the donut class, otherwise just a regular slice
var u=S.classNames.slicePie;S.donut&&(u=S.classNames.sliceDonut,S.donutSolid&&(u=S.classNames.sliceDonutSolid));var d=v[e].elem("path",{d:l.stringify()},u);// Adding the pie series value to the path
// If we need to show labels we need to add the label for this slice now
if(d.attr({"ct:value":T.normalized.series[e],"ct:meta":N.serialize(t.meta)}),// If this is a donut, we add the stroke-width as style attribute
S.donut&&!S.donutSolid&&(d._node.style.strokeWidth=O.value+"px"),// Fire off draw event
this.eventEmitter.emit("draw",{type:"slice",value:T.normalized.series[e],totalDataSum:g,index:e,meta:t.meta,series:t,group:v[e],element:d,path:l.clone(),center:C,radius:_,startAngle:y,endAngle:n}),S.showLabel){var h,f;
// If we have only 1 series, we can position the label in the center of the pie
h=1===T.raw.series.length?{x:C.x,y:C.y}:N.polarToCartesian(C.x,C.y,A,y+(n-y)/2),f=T.normalized.labels&&!N.isFalseyButZero(T.normalized.labels[e])?T.normalized.labels[e]:T.normalized.series[e];var p=S.labelInterpolationFnc(f,e);if(p||0===p){var E=m.elem("text",{dx:h.x,dy:h.y,"text-anchor":L(C,h,S.labelDirection)},S.classNames.label).text(""+p);// Fire off draw event
this.eventEmitter.emit("draw",{type:"label",index:e,group:m,element:E,text:""+p,x:h.x,y:h.y})}}// Set next startAngle to current endAngle.
// (except for last slice)
y=n}}.bind(this)),this.eventEmitter.emit("created",{chartRect:t,svg:this.svg,options:S})},determineAnchorPosition:L}),window.Chartist=t},
// Used fix described in the following thread to avoid "Uncaught TypeError: Cannot set property 'Chartist' of undefined" error
// https://github.com/gionkunz/chartist-js/issues/403
(t=this)&&"function"==typeof define&&define.amd?
// AMD. Register as an anonymous module unless amdModuleId is set
define("Chartist",[],function(){return t.Chartist=e()}):"object"===("undefined"==typeof module?"undefined":ya(module))&&module.exports?
// Node. Does not work with strict CommonJS, but
// only CommonJS-like environments that support module.exports,
// like Node.
module.exports=e():t.Chartist=e()}}).initChartist},Ia={init:(Na={ATTRIBUTES:{DATA_INPUT:"data-input",DATA_TYPE:"data-type",DATA_SEGMENT:"data-segment"},CLASSES:{BONUS_CASH_ICON:".js-bonus-cash-input__checkbox-icon",BONUS_CASH_INPUT:".js-bonus-cash-form-group__input",CASH_REWARDS_CALCULATOR_WRAPPER:".js-cash-rewards-calculator-wrapper",CHART_LEGEND_PERCENTAGE:".js-rewards-results-chart-legend__percentage",INCLUDED_IN_CALCULATION:".js-included-in-calculation",INCREASE_ICON_SIZE_WHEN_FOCUSED:".js-increase-icon-size-when-focused",MAKE_VISIBLE_WHEN_FOCUSED:".js-make-visible-when-focused",POSITIVE_NUMBER_INPUT:".js-form-validation-positive-number",REWARDS_CALCULATOR:".js-rewards-calculator",REWARDS_CALCULATOR_FORM:".js-rewards-calculator-form"},CLASS_BASES:{LEGEND_ITEM:".js-rewards-results-chart-legend__item"},DURATIONS:{ANIMATION:500,DEBOUNCE:500},IDS_NO_HASH:{CASH_PERSONAL_CALCULATOR:"cash-rewards-calculator--personal",CASH_SMALL_BUSINESS_CALCULATOR:"cash-rewards-calculator--small-business"},
// bases for ids - append the segment (personal or small business)
ID_BASES_INPUT:{BONUS_CASH_INPUT:"#cash-bonus-cash-input",GAS_INPUT:"#cash-monthly-gas-input",GROCERIES_INPUT:"#cash-monthly-groceries-input",OTHER_INPUT:"#cash-other-monthly-input",RESTAURANT_INPUT:"#cash-monthly-restaurant-input",SUPPLIES_INPUT:"#cash-monthly-supplies-input",UTILITIES_INPUT:"#cash-monthly-utilities-input"},ID_BASES_RESULTS:{AMOUNT:"#cash-rewards-calculator-results-amount",CONTAINER:"#cash-rewards-calculator-results-container",CONTAINER_TEXT:"#cash-rewards-calculator-results-text-container",CHART_OUTER:"#cash-rewards-calculator-results-chart-outer",CHART:"#cash-rewards-calculator-results-chart",LEGEND_INCORRECT_CLASS:"#cash-rewards-results-chart-legend-wrapper",LEGEND:"#cash-rewards-calculator-results-chart-legend-wrapper"},LABELS:{PERCENTAGES_BY_CATEGORY:"Cash back percentages by category"},LIMITS:{PERSONAL:1e3,SMALL_BUSINESS:2e3},SEGMENTS:{PERSONAL:"personal",SMALL_BUSINESS:"small-business"},
// the chart object by chart id
charts:{},
// an array of delay multipliers for animating the chart by chart id
animationStartTime:{},barChartConfiguration:{horizontalBars:!0,stackBars:!0,showGridBackground:!1,distributeSeries:!0,low:0,high:100,chartPadding:{top:0,right:0,bottom:0,left:0},axisX:{showGrid:!1,showLabel:!1,offset:0},axisY:{showGrid:!1,showLabel:!1,offset:0}},ensureOnlyInstancePerSegment:function(){
// ensure that there is only one instance of each segment's calculator on the page
// to prevent id issues
d('[id="'.concat(Na.IDS_NO_HASH.CASH_PERSONAL_CALCULATOR,'"]')).each(function(t,e){0<t&&(d(e).remove(),console.error("Only one personal cash rewards credit card calculator is allowed per page. All others have been removed."))}),d('[id="'.concat(Na.IDS_NO_HASH.CASH_SMALL_BUSINESS_CALCULATOR,'"]')).each(function(t,e){0<t&&(d(e).remove(),console.error("Only one small business cash rewards credit card calculator is allowed per page. All others have been removed."))})},createHeaderStructure:function(){d(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER).each(function(t,e){dn.createHeaderStructure(d(e))})},bindEvents:function(){
// display and hide the bonus checkmark
d("".concat(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER," ").concat(Na.CLASSES.BONUS_CASH_INPUT)).on("change",Na.calculatorUpdated),// perform calculations when a user enters a value
d("".concat(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER," ").concat(Na.CLASSES.INCLUDED_IN_CALCULATION)).on("input",window.BBT_AEM_Platform.debounce(function(t){
// checkboxes are handled with the change event
"checkbox"!==d(t.target).attr("type")&&Na.calculatorUpdated(t)},Na.DURATIONS.DEBOUNCE)),// increase and reset the size of the icon when the field has focus
d("".concat(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER," ").concat(Na.CLASSES.INCREASE_ICON_SIZE_WHEN_FOCUSED)).on("focus",dn.increaseIconSize),d("".concat(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER," ").concat(Na.CLASSES.INCREASE_ICON_SIZE_WHEN_FOCUSED)).on("blur",dn.resetIconSize),// disallow negative signs and periods in positive number fields
d("".concat(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER," ").concat(Na.CLASSES.POSITIVE_NUMBER_INPUT)).on("keydown",dn.monitorPositiveNumberInput)},calculatorUpdated:function(t){var e=d(t.target).closest(Na.CLASSES.REWARDS_CALCULATOR);Na.performCashBackCalculations(e)},performCashBackCalculations:function(t){var e,n,r,a={three:null,twoA:null,twoB:null,one:null},i=null,o=!1,s=null,c=null,l=null,u="";// get the correct inputs based on the segment
switch(t.attr(Na.ATTRIBUTES.DATA_SEGMENT)){case Na.SEGMENTS.PERSONAL:a.three=d("".concat(Na.ID_BASES_INPUT.GAS_INPUT,"--").concat(Na.SEGMENTS.PERSONAL)),a.twoA=d("".concat(Na.ID_BASES_INPUT.GROCERIES_INPUT,"--").concat(Na.SEGMENTS.PERSONAL)),a.twoB=d("".concat(Na.ID_BASES_INPUT.UTILITIES_INPUT,"--").concat(Na.SEGMENTS.PERSONAL)),a.one=d("".concat(Na.ID_BASES_INPUT.OTHER_INPUT,"--").concat(Na.SEGMENTS.PERSONAL)),i=d("".concat(Na.ID_BASES_INPUT.BONUS_CASH_INPUT,"--").concat(Na.SEGMENTS.PERSONAL)),s=Na.LIMITS.PERSONAL,d("".concat(Na.ID_BASES_RESULTS.CONTAINER,"--").concat(Na.SEGMENTS.PERSONAL)),d("".concat(Na.ID_BASES_RESULTS.CONTAINER_TEXT,"--").concat(Na.SEGMENTS.PERSONAL)),c=d("".concat(Na.ID_BASES_RESULTS.AMOUNT,"--").concat(Na.SEGMENTS.PERSONAL)),d("".concat(Na.ID_BASES_RESULTS.CHART_OUTER,"--").concat(Na.SEGMENTS.PERSONAL)),// eventually, this will be deleted when we no longer support the original calculator
(l=d("".concat(Na.ID_BASES_RESULTS.LEGEND,"--").concat(Na.SEGMENTS.PERSONAL))).length||(l=d("".concat(Na.ID_BASES_RESULTS.LEGEND_INCORRECT_CLASS,"--").concat(Na.SEGMENTS.PERSONAL))),u="".concat(Na.ID_BASES_RESULTS.CHART.slice(1),"--").concat(Na.SEGMENTS.PERSONAL);break;case Na.SEGMENTS.SMALL_BUSINESS:a.three=d("".concat(Na.ID_BASES_INPUT.GAS_INPUT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),a.twoA=d("".concat(Na.ID_BASES_INPUT.SUPPLIES_INPUT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),a.twoB=d("".concat(Na.ID_BASES_INPUT.RESTAURANT_INPUT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),a.one=d("".concat(Na.ID_BASES_INPUT.OTHER_INPUT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),i=d("".concat(Na.ID_BASES_INPUT.BONUS_CASH_INPUT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),s=Na.LIMITS.SMALL_BUSINESS,d("".concat(Na.ID_BASES_RESULTS.CONTAINER,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),d("".concat(Na.ID_BASES_RESULTS.CONTAINER_TEXT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),c=d("".concat(Na.ID_BASES_RESULTS.AMOUNT,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),d("".concat(Na.ID_BASES_RESULTS.CHART_OUTER,"--").concat(Na.SEGMENTS.SMALL_BUSINESS)),// eventually, this will be deleted when we no longer support the original calculator
(l=d("".concat(Na.ID_BASES_RESULTS.LEGEND,"--").concat(Na.SEGMENTS.SMALL_BUSINESS))).length||(l=d("".concat(Na.ID_BASES_RESULTS.LEGEND_INCORRECT_CLASS,"--").concat(Na.SEGMENTS.SMALL_BUSINESS))),u="".concat(Na.ID_BASES_RESULTS.CHART.slice(1),"--").concat(Na.SEGMENTS.SMALL_BUSINESS)}// determine if the bonus checkbox is checked
i.is(":checked")&&(o=!0),// gets the amounts in the input fields and converts them to integers
e=Na.getCashBackInputAmounts(a),// calculates cash back amounts per percentage level
n=Na.calculateCashBackAmounts(e,s,o),// calculates the percentage represented by each cash back amount
r=Na.calculateCashBackPercentages(n),// update the results
c.text("$".concat(dn.formatNumberWithCommas(n.total))),// the chart is created and inserted into the dom by the createCashBackChart function
// after that the labels and series are updated
Na.charts[u]?Na.updateCashBackChart(r,u):Na.createCashBackChart(r,u),// update the legend
Na.updateLegend(r,l)},getCashBackInputAmounts:function(t){
// gets the amounts in the input fields and converts them to integers
var e={three:null,twoA:null,twoB:null,one:null};// checks for an entry in the field
return e.three=""!==t.three.val()?parseInt(t.three.val(),10):0,e.twoA=""!==t.twoA.val()?parseInt(t.twoA.val(),10):0,e.twoB=""!==t.twoB.val()?parseInt(t.twoB.val(),10):0,e.one=""!==t.one.val()?parseInt(t.one.val(),10):0,// uses 0 for negative numbers
e.three=-1<e.three?e.three:0,e.twoA=-1<e.twoA?e.twoA:0,e.twoB=-1<e.twoB?e.twoB:0,e.one=-1<e.one?e.one:0,e},calculateCashBackAmounts:function(t,e,n){
// calculates cash back amounts per percentage
var r={three:null,two:null,one:null,bonus:null,total:null},a=e;// handle the case when the 3% and 2% categories exceed the limit
// process the 2% category first to be more conservative in the estimate
// 2% category
return t.twoA+t.twoB>a?(r.two=.02*a+.01*(t.twoA+t.twoB-a),a=0):(r.two=.02*(t.twoA+t.twoB),a-=t.twoA+t.twoB),r.two=Math.round(12*r.two),// 3% category
t.three>a?r.three=.03*a+.01*(t.three-a):r.three=.03*t.three,r.three=Math.round(12*r.three),// 1% category
r.one=Math.round(.01*t.one*12),// bonus
r.bonus=n?Math.round(.1*(r.three+r.two+r.one)):0,// total
r.total=r.three+r.two+r.one+r.bonus,r},calculateCashBackPercentages:function(t){
// calculates the percentage represented by each cash back amount
var e={three:null,two:null,one:null,bonus:null,total:null};return 0<t.total?(e.three=Math.round(t.three/t.total*100),e.two=Math.round(t.two/t.total*100),e.one=Math.round(t.one/t.total*100),e.bonus=Math.round(t.bonus/t.total*100)):(e.three=0,e.two=0,e.one=0,e.bonus=0),e.total=e.three+e.two+e.one+e.bonus,e},createCashBackChart:function(t,e){
// configure the bar chart data and options
var n=Na.createCashBackChartDataObject(t),r=new Chartist.Bar("#".concat(e),n,Na.barChartConfiguration);// create the bar chart
// specify how to animate data changes
Na.animateChart(r,e),// set the chart to be visually hidden for screen readers because we always include a legend
d("#".concat(e)).attr("aria-hidden","true"),// store the chart in the chart object
Na.charts[e]=r},updateCashBackChart:function(t,e){var n=Na.createCashBackChartDataObject(t);// update the data for the chart
Na.charts[e].update(n,Na.barChartConfiguration)},createCashBackChartDataObject:function(t){var e=[Na.LABELS.PERCENTAGES_BY_CATEGORY],n=[t.three,t.two,t.one,t.bonus],r={labels:e,series:n};if(0<t.total&&100!==t.total){var a=null,i=null,o=Math.abs(t.total-100),s=0;// add 1 or subtract 1 } from each chart percentage until the total
// is 100; start with the largest percentages because a difference of 1
// will be less visually noticeable
for(// determine if the difference } from 100 is positive or negative
// and create a function to adjust the value accordingly
a=t.total<100?function(t){return t+1}:function(t){return t-1},(// copy the array in order and sort it } from greatest to least percentage
i=n.slice()).sort(function(t,e){return e-t});0<o;){if(0<i[s]){var c=n.indexOf(i[s]);n[c]=a(n[c]),i[s]=a(n[c]),o-=1}s<i.length-1?s+=1:s=0}}return r},animateChart:function(t,r){
// specify how to animate data changes
t.on("draw",function(t){var e=d("#".concat(r)).width(),n=Na.DURATIONS.ANIMATION*((t.x2-t.x1)/e);0===t.seriesIndex&&(Na.animationStartTime[r]=0),t.element.animate({x2:{begin:Na.animationStartTime[r],dur:n,from:t.x1,to:t.x2,easing:"easeOutQuart"}}),Na.animationStartTime[r]+=n})},updateLegend:function(t,e){
// updates the percentages in the legend each time the chart updates
e.find("".concat(Na.CLASS_BASES.LEGEND_ITEM,"--three ").concat(Na.CLASSES.CHART_LEGEND_PERCENTAGE)).text("".concat(t.three,"%")),e.find("".concat(Na.CLASS_BASES.LEGEND_ITEM,"--two ").concat(Na.CLASSES.CHART_LEGEND_PERCENTAGE)).text("".concat(t.two,"%")),e.find("".concat(Na.CLASS_BASES.LEGEND_ITEM,"--one ").concat(Na.CLASSES.CHART_LEGEND_PERCENTAGE)).text("".concat(t.one,"%")),e.find("".concat(Na.CLASS_BASES.LEGEND_ITEM,"--bonus ").concat(Na.CLASSES.CHART_LEGEND_PERCENTAGE)).text("".concat(t.bonus,"%"))},init:function(){La.initChartist(),Na.ensureOnlyInstancePerSegment(),Na.createHeaderStructure(),Na.bindEvents(),// the calculators are prepopulated with values
// run calculations and show an initial value
d("".concat(Na.CLASSES.CASH_REWARDS_CALCULATOR_WRAPPER," ").concat(Na.CLASSES.REWARDS_CALCULATOR)).each(function(t,e){Na.performCashBackCalculations(d(e))})}}).init},wa={init:(ba={ATTRIBUTES:{DATA_INPUT:"data-input",DATA_TYPE:"data-type",DATA_SEGMENT:"data-segment"},CLASSES:{CHART_LEGEND_PERCENTAGE:".js-rewards-results-chart-legend__percentage",INCLUDED_IN_CALCULATION:".js-included-in-calculation",INCREASE_ICON_SIZE_WHEN_FOCUSED:".js-increase-icon-size-when-focused",POSITIVE_NUMBER_INPUT:".js-form-validation-positive-number",REWARDS_CALCULATOR:".js-rewards-calculator",REWARDS_CALCULATOR_FORM:".js-rewards-calculator-form",TRAVEL_REWARDS_CALCULATOR_WRAPPER:".js-travel-rewards-calculator-wrapper"},CLASS_BASES:{LEGEND_ITEM:".js-rewards-results-chart-legend__item"},DURATIONS:{ANIMATION:500,DEBOUNCE:500},IDS_NO_HASH:{TRAVEL_PERSONAL_CALCULATOR:"travel-rewards-calculator--personal",TRAVEL_SMALL_BUSINESS_CALCULATOR:"travel-rewards-calculator--small-business"},
// bases for ids - append the segment (personal or small business)
ID_BASES_INPUT:{AIRLINE_INPUT:"#travel-monthly-airline-input",CAR_RENTAL_INPUT:"#travel-monthly-car-rental-input",HOTEL_INPUT:"#travel-monthly-hotel-input",OTHER_INPUT:"#travel-other-monthly-input"},ID_BASES_RESULTS:{AMOUNT:"#travel-rewards-calculator-results-amount",CONTAINER:"#travel-rewards-calculator-results-container",CONTAINER_TEXT:"#travel-rewards-calculator-results-text-container",CHART_OUTER:"#travel-rewards-calculator-results-chart-outer",CHART:"#travel-rewards-calculator-results-chart",LEGEND_INCORRECT_CLASS:"#travel-rewards-results-chart-legend-wrapper",LEGEND:"#travel-rewards-calculator-results-chart-legend-wrapper"},LABELS:{PERCENTAGES_BY_CATEGORY:"Annual mile percentages by category"},SEGMENTS:{PERSONAL:"personal",SMALL_BUSINESS:"small-business"},
// the chart object by chart id
charts:{},
// an array of delay multipliers for animating the chart by chart id
animationStartTime:{},barChartConfiguration:{horizontalBars:!0,stackBars:!0,showGridBackground:!1,distributeSeries:!0,low:0,high:100,chartPadding:{top:0,right:0,bottom:0,left:0},axisX:{showGrid:!1,showLabel:!1,offset:0},axisY:{showGrid:!1,showLabel:!1,offset:0}},ensureOnlyInstancePerSegment:function(){
// ensure that there is only one instance of each segment's calculator on the page
// to prevent id issues
d('[id="'.concat(ba.IDS_NO_HASH.TRAVEL_PERSONAL_CALCULATOR,'"]')).each(function(t,e){0<t&&(d(e).remove(),console.error("Only one personal travel rewards credit card calculator is allowed per page. All others have been removed."))}),d('[id="'.concat(ba.IDS_NO_HASH.TRAVEL_SMALL_BUSINESS_CALCULATOR,'"]')).each(function(t,e){0<t&&(d(e).remove(),console.error("Only one small business travel rewards credit card calculator is allowed per page. All others have been removed."))})},createHeaderStructure:function(){d(ba.CLASSES.TRAVEL_REWARDS_CALCULATOR_WRAPPER).each(function(t,e){dn.createHeaderStructure(d(e))})},bindEvents:function(){
// perform calculations when a user enters a value
d("".concat(ba.CLASSES.TRAVEL_REWARDS_CALCULATOR_WRAPPER," ").concat(ba.CLASSES.INCLUDED_IN_CALCULATION)).on("input",window.BBT_AEM_Platform.debounce(function(t){
// checkboxes are handled with the change event
"checkbox"!==d(t.target).attr("type")&&ba.calculatorUpdated(t)},ba.DURATIONS.DEBOUNCE)),// increase and reset the size of the icon when the field has focus
d("".concat(ba.CLASSES.TRAVEL_REWARDS_CALCULATOR_WRAPPER," ").concat(ba.CLASSES.INCREASE_ICON_SIZE_WHEN_FOCUSED)).on("focus",dn.increaseIconSize),d("".concat(ba.CLASSES.TRAVEL_REWARDS_CALCULATOR_WRAPPER," ").concat(ba.CLASSES.INCREASE_ICON_SIZE_WHEN_FOCUSED)).on("blur",dn.resetIconSize),// disallow negative signs and periods in positive number fields
d("".concat(ba.CLASSES.TRAVEL_REWARDS_CALCULATOR_WRAPPER," ").concat(ba.CLASSES.POSITIVE_NUMBER_INPUT)).on("keydown",dn.monitorPositiveNumberInput)},calculatorUpdated:function(t){var e=d(t.target).closest(ba.CLASSES.REWARDS_CALCULATOR);ba.performCashBackCalculations(e)},performCashBackCalculations:function(t){var e,n,r,a={twoA:null,twoB:null,twoC:null,one:null},i=null,o=null,s="";// get the correct inputs based on the segment
switch(t.attr(ba.ATTRIBUTES.DATA_SEGMENT)){case ba.SEGMENTS.PERSONAL:a.twoA=d("".concat(ba.ID_BASES_INPUT.AIRLINE_INPUT,"--").concat(ba.SEGMENTS.PERSONAL)),a.twoB=d("".concat(ba.ID_BASES_INPUT.CAR_RENTAL_INPUT,"--").concat(ba.SEGMENTS.PERSONAL)),a.twoC=d("".concat(ba.ID_BASES_INPUT.HOTEL_INPUT,"--").concat(ba.SEGMENTS.PERSONAL)),a.one=d("".concat(ba.ID_BASES_INPUT.OTHER_INPUT,"--").concat(ba.SEGMENTS.PERSONAL)),d("".concat(ba.ID_BASES_RESULTS.CONTAINER,"--").concat(ba.SEGMENTS.PERSONAL)),d("".concat(ba.ID_BASES_RESULTS.CONTAINER_TEXT,"--").concat(ba.SEGMENTS.PERSONAL)),i=d("".concat(ba.ID_BASES_RESULTS.AMOUNT,"--").concat(ba.SEGMENTS.PERSONAL)),d("".concat(ba.ID_BASES_RESULTS.CHART_OUTER,"--").concat(ba.SEGMENTS.PERSONAL)),// eventually, this will be deleted when we no longer support the original calculator
(o=d("".concat(ba.ID_BASES_RESULTS.LEGEND,"--").concat(ba.SEGMENTS.PERSONAL))).length||(o=d("".concat(ba.ID_BASES_RESULTS.LEGEND_INCORRECT_CLASS,"--").concat(ba.SEGMENTS.SMALL_BUSINESS))),s="".concat(ba.ID_BASES_RESULTS.CHART.slice(1),"--").concat(ba.SEGMENTS.PERSONAL);break;case ba.SEGMENTS.SMALL_BUSINESS:a.twoA=d("".concat(ba.ID_BASES_INPUT.AIRLINE_INPUT,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),a.twoB=d("".concat(ba.ID_BASES_INPUT.CAR_RENTAL_INPUT,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),a.twoC=d("".concat(ba.ID_BASES_INPUT.HOTEL_INPUT,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),a.one=d("".concat(ba.ID_BASES_INPUT.OTHER_INPUT,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),d("".concat(ba.ID_BASES_RESULTS.CONTAINER,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),d("".concat(ba.ID_BASES_RESULTS.CONTAINER_TEXT,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),i=d("".concat(ba.ID_BASES_RESULTS.AMOUNT,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),d("".concat(ba.ID_BASES_RESULTS.CHART_OUTER,"--").concat(ba.SEGMENTS.SMALL_BUSINESS)),// eventually, this will be deleted when we no longer support the original calculator
(o=d("".concat(ba.ID_BASES_RESULTS.LEGEND,"--").concat(ba.SEGMENTS.SMALL_BUSINESS))).length||(o=d("".concat(ba.ID_BASES_RESULTS.LEGEND_INCORRECT_CLASS,"--").concat(ba.SEGMENTS.SMALL_BUSINESS))),s="".concat(ba.ID_BASES_RESULTS.CHART.slice(1),"--").concat(ba.SEGMENTS.SMALL_BUSINESS)}// gets the amounts in the input fields and converts them to integers
e=ba.getCashBackInputAmounts(a),// calculates cash back amounts per percentage level
n=ba.calculateMileAmounts(e),// calculates the percentage represented by each cash back amount
r=ba.calculateMilePercentages(n),// update the results
i.text(dn.formatNumberWithCommas(n.total)),// the chart is created and inserted into the dom by the createMileChart function
// after that the labels and series are updated
ba.charts[s]?ba.updateMileChart(r,s):ba.createMileChart(r,s),// update the legend
ba.updateLegend(r,o)},getCashBackInputAmounts:function(t){
// gets the amounts in the input fields and converts them to integers
var e={twoA:null,twoB:null,twoC:null,one:null};// checks for an entry in the field
return e.twoA=""!==t.twoA.val()?parseInt(t.twoA.val(),10):0,e.twoB=""!==t.twoB.val()?parseInt(t.twoB.val(),10):0,e.twoC=""!==t.twoC.val()?parseInt(t.twoC.val(),10):0,e.one=""!==t.one.val()?parseInt(t.one.val(),10):0,// uses 0 for negative numbers
e.twoA=-1<e.twoA?e.twoA:0,e.twoB=-1<e.twoB?e.twoB:0,e.twoC=-1<e.twoC?e.twoC:0,e.one=-1<e.one?e.one:0,e},calculateMileAmounts:function(t){
// calculates cash back amounts per percentage
var e={two:null,one:null,total:null};// handle the case when the 3% and 2% categories exceed the limit
// process the 2% category first to be more conservative in the estimate
// 2 miles per $1
return e.two=2*(t.twoA+t.twoB+t.twoC)*12,// 1 mile per $1
e.one=12*t.one,// total
e.total=e.two+e.one,e},calculateMilePercentages:function(t){
// calculates the percentage represented by each cash back amount
var e={two:null,one:null,total:null};return 0<t.total?(e.two=Math.round(t.two/t.total*100),e.one=Math.round(t.one/t.total*100)):(e.two=0,e.one=0),e.total=e.two+e.one,e},createMileChart:function(t,e){
// configure the bar chart data and options
var n=ba.createMileChartDataObject(t),r=new Chartist.Bar("#".concat(e),n,ba.barChartConfiguration);// create the bar chart
// specify how to animate data changes
ba.animateChart(r,e),// set the chart to be visually hidden for screen readers because we always include a legend
d("#".concat(e)).attr("aria-hidden","true"),// store the chart in the chart object
ba.charts[e]=r},updateMileChart:function(t,e){var n=ba.createMileChartDataObject(t);// update the data for the chart
ba.charts[e].update(n,ba.barChartConfiguration)},createMileChartDataObject:function(t){var e=[ba.LABELS.PERCENTAGES_BY_CATEGORY],n=[t.two,t.one],r={labels:e,series:n};if(0<t.total&&100!==t.total){var a=null,i=null,o=Math.abs(t.total-100),s=0;// add 1 or subtract 1 } from each chart percentage until the total
// is 100; start with the largest percentages because a difference of 1
// will be less visually noticeable
for(// determine if the difference } from 100 is positive or negative
// and create a function to adjust the value accordingly
a=t.total<100?function(t){return t+1}:function(t){return t-1},(// copy the array in order and sort it } from greatest to least percentage
i=n.slice()).sort(function(t,e){return e-t});0<o;){if(0<i[s]){var c=n.indexOf(i[s]);n[c]=a(n[c]),i[s]=a(n[c]),o-=1}s<i.length-1?s+=1:s=0}}return r},animateChart:function(t,r){
// specify how to animate data changes
t.on("draw",function(t){var e=d("#".concat(r)).width(),n=ba.DURATIONS.ANIMATION*((t.x2-t.x1)/e);0===t.seriesIndex&&(ba.animationStartTime[r]=0),t.element.animate({x2:{begin:ba.animationStartTime[r],dur:n,from:t.x1,to:t.x2,easing:"easeOutQuart"}}),ba.animationStartTime[r]+=n})},updateLegend:function(t,e){
// updates the percentages in the legend each time the chart updates
e.find("".concat(ba.CLASS_BASES.LEGEND_ITEM,"--two-miles ").concat(ba.CLASSES.CHART_LEGEND_PERCENTAGE)).text("".concat(t.two,"%")),e.find("".concat(ba.CLASS_BASES.LEGEND_ITEM,"--one-mile ").concat(ba.CLASSES.CHART_LEGEND_PERCENTAGE)).text("".concat(t.one,"%"))},init:function(){La.initChartist(),ba.ensureOnlyInstancePerSegment(),ba.createHeaderStructure(),ba.bindEvents(),// the calculators are prepopulated with values
// run calculations and show an initial value
d("".concat(ba.CLASSES.TRAVEL_REWARDS_CALCULATOR_WRAPPER," ").concat(ba.CLASSES.REWARDS_CALCULATOR)).each(function(t,e){ba.performCashBackCalculations(d(e))})}}).init},xa=It("iterator"),Pa=Array.prototype,Da=It("iterator"),Ma=C(function(t){var d={};(t.exports=function(t,e,n,r,a){var i,o,s,c,l,u=pe(e,n,r?2:1);if(a)i=t;else{if("function"!=typeof(o=function(t){if(null!=t)return t[Da]||t["@@iterator"]||Nn[we(t)]}(t)))throw TypeError("Target is not iterable");
// optimisation for array iterators
if(function(t){return void 0!==t&&(Nn.Array===t||Pa[xa]===t)}(o)){for(s=0,c=vt(t.length);s<c;s++)if((r?u(U(l=t[s])[0],l[1]):u(t[s]))===d)return d;return}i=o.call(t)}for(;!(l=i.next()).done;)if(Ca(i,u,l.value,r)===d)return d}).BREAK=d}),Ua=It("iterator"),Ba=!1;try{var Ha=0;({next:function(){return{done:!!Ha++}},return:function(){Ba=!0}})[Ua]=function(){return this}}catch(t){/* empty */}function ja(t){
// eslint-disable-next-line no-prototype-builtins
if(Ja.hasOwnProperty(t)){var e=Ja[t];delete Ja[t],e()}}function Ga(t){return function(){ja(t)}}function ka(t){ja(t.data)}function Fa(t){
// old engines have not location.origin
z.postMessage(t+"",Va.protocol+"//"+Va.host)}var Ya,za,Wa,Va=z.location,Xa=z.setImmediate,qa=z.clearImmediate,$a=z.process,Ka=z.MessageChannel,Qa=z.Dispatch,Za=0,Ja={},ti="onreadystatechange";
// Node.js 0.9+ & IE10+ has setImmediate, otherwise:
Xa&&qa||(Xa=function(t){for(var e=[],n=1;n<arguments.length;)e.push(arguments[n++]);return Ja[++Za]=function(){
// eslint-disable-next-line no-new-func
("function"==typeof t?t:Function(t)).apply(void 0,e)},Ya(Za),Za},qa=function(t){delete Ja[t]},
// Node.js 0.8-
"process"==L($a)?Ya=function(t){$a.nextTick(Ga(t))}:Qa&&Qa.now?Ya=function(t){Qa.now(Ga(t))}:Ka?(Wa=(za=new Ka).port2,za.port1.onmessage=ka,Ya=pe(Wa.postMessage,Wa,1)):!z.addEventListener||"function"!=typeof postMessage||z.importScripts||N(Fa)?Ya=ti in M("script")?function(t){ge.appendChild(M("script"))[ti]=function(){ge.removeChild(this),ja(t)}}:function(t){setTimeout(Ga(t),0)}:(Ya=Fa,z.addEventListener("message",ka,!1)));var ei,ni,ri,ai,ii,oi,si,ci={set:Xa,clear:qa},li=z.navigator,ui=li&&li.userAgent||"",di=rt.f,hi=ci.set,fi=z.MutationObserver||z.WebKitMutationObserver,pi=z.process,Ei=z.Promise,Si="process"==L(pi),mi=di(z,"queueMicrotask"),_i=mi&&mi.value;
// modern engines have queueMicrotask method
_i||(ei=function(){var t,e;for(Si&&(t=pi.domain)&&t.exit();ni;){e=ni.fn,ni=ni.next;try{e()}catch(t){throw ni?ai():ri=void 0,t}}ri=void 0,t&&t.enter()},
// Node.js
ai=Si?function(){pi.nextTick(ei)}:fi&&!/(iphone|ipod|ipad).*applewebkit/i.test(ui)?(ii=!0,oi=document.createTextNode(""),new fi(ei).observe(oi,{characterData:!0}),function(){oi.data=ii=!ii}):Ei&&Ei.resolve?(
// Promise.resolve without an argument throws an error in LG WebOS 2
si=Ei.resolve(void 0),function(){si.then(ei)}):function(){
// strange IE + webpack dev server bug - use .call(global)
hi.call(z,ei)});function Ai(t){var n,r;this.promise=new t(function(t,e){if(void 0!==n||void 0!==r)throw TypeError("Bad Promise constructor");n=t,r=e}),this.resolve=fe(n),this.reject=fe(r)}function gi(t,e){if(U(t),x(e)&&e.constructor===t)return e;var n=wi.f(t);return(0,n.resolve)(e),n.promise}function Ti(t){try{return{error:!1,value:t()}}catch(t){return{error:!0,value:t}}}function vi(t){var e;return!(!x(t)||"function"!=typeof(e=t.then))&&e}function yi(u,d,n){if(!d.notified){d.notified=!0;var r=d.reactions;Ii(function(){for(var c=d.value,l=1==d.state,t=0,e=function(t){var e,n,r,a=l?t.ok:t.fail,i=t.resolve,o=t.reject,s=t.domain;try{a?(l||(2===d.rejection&&to(u,d),d.rejection=1),!0===a?e=c:(s&&s.enter(),e=a(c),// may throw
s&&(s.exit(),r=!0)),e===t.promise?o(ji("Promise-chain cycle")):(n=vi(e))?n.call(e,i,o):i(e)):o(c)}catch(t){s&&!r&&s.exit(),o(t)}};r.length>t;)e(r[t++]);// variable length - can't use forEach
d.reactions=[],d.notified=!1,n&&!d.rejection&&Zi(u,d)})}}function Oi(t,e,n){var r,a;qi?((r=Gi.createEvent("Event")).promise=e,r.reason=n,r.initEvent(t,!1,!0),z.dispatchEvent(r)):r={promise:e,reason:n},(a=z["on"+t])?a(r):t===$i&&function(t,e){var n=z.console;n&&n.error&&(1===arguments.length?n.error(t):n.error(t,e))}("Unhandled promise rejection",n)}function Ci(e,n,r,a){return function(t){e(n,r,t,a)}}function Ri(t,e,n,r){e.done||(e.done=!0,r&&(e=r),e.value=n,e.state=2,yi(t,e,!0))}var Ni,bi,Li,Ii=_i||function(t){var e={fn:t,next:void 0};ri&&(ri.next=e),ni||(ni=e,ai()),ri=e},wi={f:function(t){return new Ai(t)}},xi=ci.set,Pi=It("species"),Di="Promise",Mi=Mt.get,Ui=Mt.set,Bi=Mt.getterFor(Di),Hi=z[Di],ji=z.TypeError,Gi=z.document,ki=z.process,Fi=z.fetch,Yi=ki&&ki.versions,zi=Yi&&Yi.v8||"",Wi=wi.f,Vi=Wi,Xi="process"==L(ki),qi=!!(Gi&&Gi.createEvent&&z.dispatchEvent),$i="unhandledrejection",Ki=te(Di,function(){function e(){/* empty */}
// correct subclassing with @@species support
var t=Hi.resolve(1),n=(t.constructor={})[Pi]=function(t){t(e,e)};
// unhandled rejections tracking support, NodeJS Promise without it fails @@species test
return!((Xi||"function"==typeof PromiseRejectionEvent)&&t.then(e)instanceof n&&0!==zi.indexOf("6.6")&&-1===ui.indexOf("Chrome/66"))}),Qi=Ki||!function(t,e){if(!e&&!Ba)return!1;var n=!1;try{var r={};r[Ua]=function(){return{next:function(){return{done:n=!0}}}},t(r)}catch(t){/* empty */}return n}(function(t){Hi.all(t).catch(function(){/* empty */})}),Zi=function(n,r){xi.call(z,function(){var t,e=r.value;if(Ji(r)&&(t=Ti(function(){Xi?ki.emit("unhandledRejection",e,n):Oi($i,n,e)}),
// Browsers should not trigger `rejectionHandled` event if it was handled here, NodeJS - should
r.rejection=Xi||Ji(r)?2:1,t.error))throw t.value})},Ji=function(t){return 1!==t.rejection&&!t.parent},to=function(t,e){xi.call(z,function(){Xi?ki.emit("rejectionHandled",t):Oi("rejectionhandled",t,e.value)})},eo=function(n,r,t,e){if(!r.done){r.done=!0,e&&(r=e);try{if(n===t)throw ji("Promise can't be resolved itself");var a=vi(t);a?Ii(function(){var e={done:!1};try{a.call(t,Ci(eo,n,e,r),Ci(Ri,n,e,r))}catch(t){Ri(n,e,t,r)}}):(r.value=t,r.state=1,yi(n,r,!1))}catch(t){Ri(n,{done:!1},t,r)}}};
// constructor polyfill
Ki&&(
// 25.4.3.1 Promise(executor)
Hi=function(t){!function(t,e,n){if(!(t instanceof e))throw TypeError("Incorrect "+(n?n+" ":"")+"invocation")}(this,Hi,Di),fe(t),Ni.call(this);var e=Mi(this);try{t(Ci(eo,this,e),Ci(Ri,this,e))}catch(t){Ri(this,e,t)}},(
// eslint-disable-next-line no-unused-vars
Ni=function(t){Ui(this,{type:Di,done:!1,notified:!1,parent:!1,reactions:[],rejection:!1,state:0,value:void 0})}).prototype=function(t,e,n){for(var r in e)Ut(t,r,e[r],n);return t}(Hi.prototype,{
// `Promise.prototype.then` method
// https://tc39.github.io/ecma262/#sec-promise.prototype.then
then:function(t,e){var n=Bi(this),r=Wi(na(this,Hi));return r.ok="function"!=typeof t||t,r.fail="function"==typeof e&&e,r.domain=Xi?ki.domain:void 0,n.parent=!0,n.reactions.push(r),0!=n.state&&yi(this,n,!1),r.promise},
// `Promise.prototype.catch` method
// https://tc39.github.io/ecma262/#sec-promise.prototype.catch
catch:function(t){return this.then(void 0,t)}}),bi=function(){var t=new Ni,e=Mi(t);this.promise=t,this.resolve=Ci(eo,t,e),this.reject=Ci(Ri,t,e)},wi.f=Wi=function(t){return t===Hi||t===Li?new bi(t):Vi(t)},
// wrap fetch result
"function"==typeof Fi&&Nt({global:!0,enumerable:!0,forced:!0},{
// eslint-disable-next-line no-unused-vars
fetch:function(t){return gi(Hi,Fi.apply(z,arguments))}})),Nt({global:!0,wrap:!0,forced:Ki},{Promise:Hi}),Dn(Hi,Di,!1),Gr(Di),Li=Fr[Di],
// statics
Nt({target:Di,stat:!0,forced:Ki},{
// `Promise.reject` method
// https://tc39.github.io/ecma262/#sec-promise.reject
reject:function(t){var e=Wi(this);return e.reject.call(void 0,t),e.promise}}),Nt({target:Di,stat:!0,forced:Ki},{
// `Promise.resolve` method
// https://tc39.github.io/ecma262/#sec-promise.resolve
resolve:function(t){return gi(this,t)}}),Nt({target:Di,stat:!0,forced:Qi},{
// `Promise.all` method
// https://tc39.github.io/ecma262/#sec-promise.all
all:function(t){var s=this,e=Wi(s),c=e.resolve,l=e.reject,n=Ti(function(){var r=fe(s.resolve),a=[],i=0,o=1;Ma(t,function(t){var e=i++,n=!1;a.push(void 0),o++,r.call(s,t).then(function(t){n||(n=!0,a[e]=t,--o||c(a))},l)}),--o||c(a)});return n.error&&l(n.value),e.promise},
// `Promise.race` method
// https://tc39.github.io/ecma262/#sec-promise.race
race:function(t){var n=this,r=Wi(n),a=r.reject,e=Ti(function(){var e=fe(n.resolve);Ma(t,function(t){e.call(n,t).then(r.resolve,a)})});return e.error&&a(e.value),r.promise}});
// helper for String#{startsWith, endsWith, includes}
var no=It("match"),ro="startsWith",ao=""[ro];
// `String.prototype.startsWith` method
// https://tc39.github.io/ecma262/#sec-string.prototype.startswith
Nt({target:"String",proto:!0,forced:!function(e){var n=/./;try{"/./"[e](n)}catch(t){try{return n[no]=!1,"/./"[e](n)}catch(t){/* empty */}}return!1}(ro)},{startsWith:function(t/* , position = 0 */,e){var n=function(t,e,n){if(Hr(e))throw TypeError("String.prototype."+n+" doesn't accept regex");return String(I(t))}(this,t,ro),r=vt(Math.min(1<arguments.length?e:void 0,n.length)),a=String(t);return ao?ao.call(n,a,r):n.slice(r,r+a.length)===a}});function io(t){var e=Fr.Symbol||(Fr.Symbol={});D(e,t)||go(e,t,{value:Ao.f(t)})}function oo(t,e){var n=Mo[t]=Oe(bo[wo]);return yo(n,{type:vo,tag:t,description:e}),W||(n.description=e),n}function so(t,e){U(t);for(var n,r=function(t){var e=me(t),n=Vt.f;if(n)for(var r,a=n(t),i=q.f,o=0;a.length>o;)i.call(t,r=a[o++])&&e.push(r);return e}(e=w(e)),a=0,i=r.length;a<i;)Yo(t,n=r[a++],e[n]);return t}function co(t){var e=Po.call(this,t=P(t,!0));return!(this===Ho&&D(Mo,t)&&!D(Uo,t))&&(!(e||!D(this,t)||!D(Mo,t)||D(this,To)&&this[To][t])||e)}function lo(t,e){if(t=w(t),e=P(e,!0),t!==Ho||!D(Mo,e)||D(Uo,e)){var n=Co(t,e);return!n||!D(Mo,e)||D(t,To)&&t[To][e]||(n.enumerable=!0),n}}function uo(t){for(var e,n=No(w(t)),r=[],a=0;n.length>a;)D(Mo,e=n[a++])||D(pt,e)||r.push(e);return r}function ho(t){for(var e,n=t===Ho,r=No(n?Uo:w(t)),a=[],i=0;r.length>i;)!D(Mo,e=r[i++])||n&&!D(Ho,e)||a.push(Mo[e]);return a}
/**
   * This is a BB&T-specific version of Chartist.js plugin to put labels on top of bar charts.
   *
   * Copyright (c) 2015 Yorkshire Interactive (yorkshireinteractive.com)
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in
   * all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   */
var fo,po,Eo,So={initChartistBarLabels:(fo={intialized:!1,initChartistBarLabels:function(){
// ensure that this module is only initialized once
fo.initialized||fo.initChartistBarLabelsHelper()},initChartistBarLabelsHelper:function(){var e,t;
// ensure that this module is only initialized once
fo.initialized=!0,window,document,e=Chartist,t={
// The class name so you can style the text
labelClass:"ct-bar-label",
// Use this to get the text of the data and you can return your own
// formatted text. For example, for a percentage:
// {
//  labelInterpolationFnc: function (text) { return text + '%' }
// }
labelInterpolationFnc:e.noop,
// Depending on your font size you may need to tweak these
labelOffset:{x:0,y:0},
// If labelOffset doesn't work for you and you need more custom positioning
// you can use this. You can set position.x and position.y to functions and
// instead of centering + labelOffset. This will _completely_ override the
// built in positioning so labelOffset will no longer do anything. It will
// pass the bar `data` back as the first param.
//
// Example:
// Chartist.plugins.ctBarLabels({
//   position: {
//     x: function (data) {
//       return data.x1 + 50; // align left with 50px of padding
//     }
//   }
// });
position:{x:null,y:null}},e.plugins=e.plugins||{},e.plugins.ctBarLabelsBbtMortgage=function(n){var r=(n=e.extend({},t,n)).position.x||function(t){return(t.x1+t.x2)/2+n.labelOffset.x},a=n.position.y||function(t){return(t.y1+t.y2)/2+n.labelOffset.y};return function(t){
// Since it's specific to bars, verify its a bar chart
t instanceof e.Bar&&t.on("draw",function(t){
// If the data we're drawing is the actual bar, let's add the text
// inside of it
if("bar"===t.type){var e=n.labelInterpolationFnc();e.rate&&
// rate
t.group.elem("text",{
// This gets the middle point of the bars and then adds the
// optional offset to them
x:r(t),y:a(t)+n.labelOffset.y,style:"text-anchor: left"},n.labelClass).text("".concat(e.rate," ").concat(e.apr));// if ( barLabels.apr ) {
//   // apr
//   data.group.elem( 'text', {
//     // This gets the middle point of the bars and then adds the
//     // optional offset to them
//     x: positionX( data ),
//     y: positionY( data ),
//     style: 'text-anchor: left'
//   }, options.labelClass )
//     .text( barLabels.apr );
// }
}})}}}}).initChartistBarLabels},mo={init:(po={DYNAMIC_RATES:{SERIES_RATE:"Rate",SERIES_APR:"APR",SERIES_APY:"APY"},ADAPTER:{MORTGAGE:"mortgage",MORTGAGE_DISCLOSURES:"mortgage-disclosures",PRODUCT:"product",TERM:"term",FOREIGN_EXCHANGE:"foreign-exchange",FOREIGN_EXCHANGE_MEMO:"foreign-exchange-memo"},DATA_ATTRIBUTES:{SERVICE_URL:"data-service-url",ADAPTER:"data-adapter",SHOW_CHART:"data-show-chart",SHOW_CHART_LABELS:"data-show-chart-labels",REVERSE_CHART_DATA:"data-reverse-chart-data",SHOW_TABLE:"data-show-table",IS_PROTOTYPE:"data-is-prototype"},CLASSES:{WRAPPER:".js-dynamic-rates-wrapper",CHART_WRAPPER:".js-dynamic-rates-chart-wrapper",TABLE_WRAPPER:".js-dynamic-rates-table-wrapper",INTRO:".dynamic-rates__intro",OUTRO:".dynamic-rates__outro"},CLASSES_NO_DOT:{DISPLAY_NONE:"display-none",SPINNER_WRAPPER_DYNAMIC_RATES:"spinner--dynamic-rates-wrapper",SPINNER_DYNAMIC_RATES:"spinner--dynamic-rates",FULL_OPACITY:"dynamic-rates-full-opacity",DATA_SERVICE_ERROR:"dynamic-rates-data-service-error",CHART_WRAPPER:"dynamic-rates-chart-wrapper js-dynamic-rates-chart-wrapper",FOREIGN_EXCHANGE_DATE_TIME:"dynamic-rates-foreign-exchange-rates-date-time",FOREIGN_EXCHANGE_MEMO:"dynamic-rates-foreign-exchange-rates-memo",MORTGAGE_DISCLOSURES:"dynamic-rates-mortgage-disclosures"},TIMEOUTS:{FADE_FAST:200,FADE_DELAY:300},dynamicRateInstances:{},
// The instance id is the key
// Each value is an object that includes the following:
// chartId: 'id'
// tableId: 'id'
// showChart: true
// showChartLabels: true
// reverseChartData: true
// showTable: true
// serviceUrl: ''
// adapter: ''
// adapterFunction: null
// series: []
// labels: []
// tableCaptionText: ''
// tableCellsByRow: []
// seriesTotal: 0
// seriesCounter: 0
// mortgageDisclosures: ''
// dateAndTime: ''
// memo: ''
// valid: true
setUpDynamicRateInstances:function(){
// Iterates through each dynamic rate component on the
// page and creates an dynamicRateInstance object
// that contains the configuration choices
d(po.CLASSES.WRAPPER).each(function(t,e){var n={};// Set the chart and table ids
if(n.chartId="".concat(e.id,"-chart"),n.tableId="".concat(e.id,"-table"),// These determine how the rates are displayed
n.showChart="true"===d(e).attr(po.DATA_ATTRIBUTES.SHOW_CHART),n.showChartLabels="true"===d(e).attr(po.DATA_ATTRIBUTES.SHOW_CHART_LABELS),n.reverseChartData="true"===d(e).attr(po.DATA_ATTRIBUTES.REVERSE_CHART_DATA),n.showTable="true"===d(e).attr(po.DATA_ATTRIBUTES.SHOW_TABLE),// Check if this is a prototype
n.isPrototype="true"===d(e).attr(po.DATA_ATTRIBUTES.IS_PROTOTYPE),// Service url
n.serviceUrl=d(e).attr(po.DATA_ATTRIBUTES.SERVICE_URL),""===n.serviceUrl||void 0===n.serviceUrl||null===n.serviceUrl)n.serviceUrl=null;else if(!n.isPrototype){
// Use the hostname of the page
var r=location.hostname,a="";(a=document.createElement("a")).href=n.serviceUrl,n.serviceUrl.startsWith("/")?(n.serviceUrl=n.serviceUrl.slice(1),n.serviceUrl="https://".concat(r,"/").concat(n.serviceUrl)):"localhost"!==a.hostname&&(
// replace any existing hostname with the page's hostname
n.serviceUrl=n.serviceUrl.replace(a.hostname,r))}// Adapter
// Only attempt a service call if there is a url and adapter specified
if(n.adapter=d(e).attr(po.DATA_ATTRIBUTES.ADAPTER),""===n.adapter||void 0===n.adapter||null===n.adapter?n.adapter=null:n.adapter&&(n.adapter=n.adapter.toLowerCase()),// Chart data is set to empty by default
n.series=[],n.labels=[],n.seriesTotal=0,n.seriesCounter=0,// Table data is set to empty by default
n.tableCaptionText="",n.tableCellsByRow=[],// This value is used by the mortgage disclosures
n.mortgageDisclosures="",// These values are used by the foreign exchange rates memo
n.dateAndTime="",n.memo="",// An instance is considered valid until it fails a check/test
n.valid=!0,n.serviceUrl&&n.adapter)
// Specify the correct adapter based on the product
switch(n.adapter){case po.ADAPTER.MORTGAGE:n.adapterFunction=po.mortgageRatesAdapter;break;case po.ADAPTER.MORTGAGE_DISCLOSURES:n.adapterFunction=po.mortgageDisclosuresAdapter,// No table or chart is shown for the mortgage disclosures
n.showChart=!1,n.showChartLabels=!1,n.reverseChartData=!1,n.showTable=!1;break;case po.ADAPTER.PRODUCT:n.adapterFunction=po.productRatesAdapter;break;case po.ADAPTER.TERM:n.adapterFunction=po.termRatesAdapter,// Only a table is shown for term rates
n.showChart=!1,n.showChartLabels=!1,n.showTable=!0;break;case po.ADAPTER.FOREIGN_EXCHANGE:n.adapterFunction=po.foreignExchangeRatesAdapter,// Only a table is shown for foreign exchange rates
// and the values are not reversed
n.showChart=!1,n.showChartLabels=!1,n.reverseChartData=!1,n.showTable=!0;break;case po.ADAPTER.FOREIGN_EXCHANGE_MEMO:n.adapterFunction=po.foreignExchangeRatesMemoAdapter,// No table or chart is shown for the foreign exchange rate memo
n.showChart=!1,n.showChartLabels=!1,n.reverseChartData=!1,n.showTable=!1;break;default:n.adapterFunction=null,n.valid=!1}else n.valid=!1;// Add the instance to the object of instances
po.dynamicRateInstances[e.id]=n,// Add a spinner in case there is a delay is retrieving rates data
po.addAndDisplaySpinner(e.id)})},addAndDisplaySpinner:function(t){var e='\n        <div class="'.concat(po.CLASSES_NO_DOT.SPINNER_WRAPPER_DYNAMIC_RATES,'" aria-label="loading rates" tabindex="0">\n          <div class="spinner spinner--md spinner--background ').concat(po.CLASSES_NO_DOT.SPINNER_DYNAMIC_RATES,'" aria-hidden="true"></div>\n        </div>\n      ');d("#".concat(t," ").concat(po.CLASSES.INTRO)).length?d("#".concat(t," ").concat(po.CLASSES.INTRO)).after(e):d("#".concat(t)).append(e)},removeSpinner:function(t){var e=d("#".concat(t," .").concat(po.CLASSES_NO_DOT.SPINNER_WRAPPER_DYNAMIC_RATES));e.fadeOut(po.TIMEOUTS.FADE_FAST),setTimeout(function(){e.remove(),d("#".concat(t)).addClass(po.CLASSES_NO_DOT.FULL_OPACITY)},po.TIMEOUTS.FADE_DELAY)},
/* eslint-disable no-loop-func */
getAndDisplayRates:function(){for(
// Iterates through dynamic rate instances
// Calls the service at the url
// Passes the response data through the appropriate adapter
// Displays the chart and/or table
var t=Object.keys(po.dynamicRateInstances),e=function(){var i=r[n],o=po.getDynamicRateInstance(i);// Only call the service on dynamic rate instances with both a service url and an adapter
o.valid?fetch(o.serviceUrl).then(function(t){if(t.ok)return t.json();throw new Error("The network response was not ok.")}).then(function(t){
// Set up the series and labels appropriately based on the particular service
o.adapterFunction(i,t);var e=0<o.series.length&&0<o.labels.length,n=1<o.tableCellsByRow.length,r=""!==o.mortgageDisclosures,a=""!==o.memo;// Display the chart and/or table or memo
e||n||r||a?
// There is data to display
po.displayDynamicRateInstance(i):(
// There is not data to display
o.valid=!1,po.displayServiceErrorMessage(i))}).catch(function(t){console.error("There has been a problem with your fetch operation for url ".concat(o.serviceUrl,": ").concat(t.message)),po.displayServiceErrorMessage(i)}):po.displayServiceErrorMessage(i)},n=0,r=t;n<r.length;n++)e()},
/* eslint-enable no-loop-func */
getDynamicRateInstance:function(t){return po.dynamicRateInstances[t]},mortgageRatesAdapter:function(t,e){
// Returns a fully configured dynamic rate instance that is specific
// to mortgage rates data
// Current url for the mortgage rates service is:
// https://sit.bbt.com/clocator/getDefaultProductDetails.do?input=getDefaultProductDetails
// Json response for mortgage rates has this format:
// {
//   "responseList": [
//     {
//       "apr": "4.585",
//       "discountPoints": "1.25",
//       "interestRate": "4.5",
//       "noOfPayments": 360,
//       "originationFee": "895",
//       "paymentAmount": 1013.28,
//       "product": "101",
//       "purposeCode": "00"
//     }
//   ]
// }
var n=po.getDynamicRateInstance(t),r=po.mortgageAdapterHelper(e);n.tableCaptionText="Current rates",n.tableCellsByRow=[["Tier","Rate","APR"]],n.labels=["15 Year Refinance","30 Year Refinance","15 Year Fixed","30 Year Fixed"],n.series=[{name:po.DYNAMIC_RATES.SERIES_RATE,data:[r.refinance15Rate,r.refinance30Rate,r.fixed15Rate,r.fixed30Rate]},{name:po.DYNAMIC_RATES.SERIES_APR,data:[r.refinance15Apr,r.refinance30Apr,r.fixed15Apr,r.fixed30Apr]}],// Reverse the labels and data if necessary
po.checkLabelAndDataOrder(t),// This calculation tells us when to switch to the APR label
po.calculateSeriesTotalAndCounter(t);// Set up the table data
// The table rows have to be in the reverse order of the chart rows
// to render in the same order } from top to bottom
var a=n.labels.length;n.labels.forEach(function(t,e){n.tableCellsByRow[a-e]=[t,po.formatNumberAsPercent(n.series[0].data[e]),po.formatNumberAsPercent(n.series[1].data[e])]})},mortgageDisclosuresAdapter:function(t,e){
// Returns a fully configured dynamic rate instance that is specific
// to mortgage disclosures
// Current url for the mortgage disclosures service is:
// https://sit.bbt.com/clocator/getDefaultProductDetails.do?input=getDefaultProductDetails
// Json response for mortgage disclosures has this format:
// {
//   "responseList": [
//     {
//       "apr": "4.585",
//       "discountPoints": "1.25",
//       "interestRate": "4.5",
//       "noOfPayments": 360,
//       "originationFee": "895",
//       "paymentAmount": 1013.28,
//       "product": "101",
//       "purposeCode": "00"
//     }
//   ]
// }
var n=po.getDynamicRateInstance(t),r=po.mortgageAdapterHelper(e);n.mortgageDisclosures="\n        <p>The current rate for the 30-year fixed purchase mortgage is based on a $".concat(r.fixed30OriginationFee," origination fee; ").concat(r.fixed30DiscountPoints," discount points and an APR of ").concat(r.fixed30Apr,"%; which would yield 360 equal payments of $").concat(r.fixed30PaymentAmount,".</p>\n        <p>The current rate for the 15-year fixed purchase mortgage is based on a $").concat(r.fixed15OriginationFee," origination fee; ").concat(r.fixed15DiscountPoints," discount points and an APR of ").concat(r.fixed15Apr,"%; which would yield 180 equal payments of $").concat(r.fixed15PaymentAmount,".</p>\n        <p>The current rate for the 30-year fixed refinance mortgage is based on a $").concat(r.refinance30OriginationFee," origination fee; ").concat(r.refinance30DiscountPoints," discount points and an APR of ").concat(r.refinance30Apr,"%; which would yield 360 equal payments of $").concat(r.refinance30PaymentAmount,".</p>\n        <p>The current rate for the 15-year fixed refinance mortgage is based on a $").concat(r.refinance15OriginationFee," origination fee; ").concat(r.refinance15DiscountPoints," discount points and an APR of ").concat(r.refinance15Apr,"%; which would yield 360 equal payments of $").concat(r.refinance15PaymentAmount,".</p>\n        ")},mortgageAdapterHelper:function(t){var n={};return t.responseList.forEach(function(t,e){switch(t.purposeCode){case"00":
// fixed loans
switch(t.product){case"101":
// 30 year
n.fixed30Rate=t.interestRate,n.fixed30Apr=t.apr,n.fixed30OriginationFee=t.originationFee,n.fixed30DiscountPoints=t.discountPoints,n.fixed30PaymentAmount=t.paymentAmount;break;case"102":
// 15 year
n.fixed15Rate=t.interestRate,n.fixed15Apr=t.apr,n.fixed15OriginationFee=t.originationFee,n.fixed15DiscountPoints=t.discountPoints,n.fixed15PaymentAmount=t.paymentAmount}break;case"01":
// refinance loans
switch(t.product){case"101":
// 30 year
n.refinance30Rate=t.interestRate,n.refinance30Apr=t.apr,n.refinance30OriginationFee=t.originationFee,n.refinance30DiscountPoints=t.discountPoints,n.refinance30PaymentAmount=t.paymentAmount;break;case"102":
// 15 year
n.refinance15Rate=t.interestRate,n.refinance15Apr=t.apr,n.refinance15OriginationFee=t.originationFee,n.refinance15DiscountPoints=t.discountPoints,n.refinance15PaymentAmount=t.paymentAmount}}}),n},productRatesAdapter:function(t,e){
// Returns a fully configured dynamic rate instance that is specific
// to mortgage rates data
// Current example url for the product rates service is:
// https://sit.bbt.com/clocator/promotionDetails.do?regionCode=NC-102-101&productCode=126
// Json response for mortgage rates has this format:
// {
//   "status": {
//     "statusCode": "000",
//     "statusDescription": "Success"
//   },
//   "productInfo": [
//     {
//       "regionCode": "NC-102-101",
//       "productCode": "126",
//       "productDescription": "Investor's Deposit Account",
//       "termName": "\"UNLIMITED\"",
//       "tierFrom": "0",
//       "tierTo": "9999",
//       "termFrom": "00000",
//       "rate": "00.05",
//       "apy": "00.05",
//       "termTo": "00000"
//     }
//   ]
// }
var a=po.getDynamicRateInstance(t),n=e.productInfo;a.tableCaptionText="Current rates",a.tableCellsByRow=[["Tier","Rate","APY"]],a.series=[{name:po.DYNAMIC_RATES.SERIES_RATE,data:[]},{name:po.DYNAMIC_RATES.SERIES_APY,data:[]}],// Sorts the tier information, so that the lowest tier is first in the array
n.sort(function(t,e){return parseInt(e.tierTo,10)-parseInt(t.tierTo,10)}),n.forEach(function(t,e){var n=po.formatNumberWithCommas(t.tierFrom),r=po.formatNumberWithCommas(t.tierTo);a.labels.push("$".concat(n," - $").concat(r)),a.series[0].data.push("".concat(t.rate)),a.series[1].data.push("".concat(t.apy))}),// Reverse the labels and data if necessary
po.checkLabelAndDataOrder(t),// This calculation tells us when to switch to the APY label
po.calculateSeriesTotalAndCounter(t);// Set up the table data
// The table rows have to be in the reverse order of the chart rows
// to render in the same order } from top to bottom
var r=a.labels.length;a.labels.forEach(function(t,e){a.tableCellsByRow[r-e]=[t,po.formatNumberAsPercent(a.series[0].data[e]),po.formatNumberAsPercent(a.series[1].data[e])]})},termRatesAdapter:function(t,e){
// Returns a fully configured dynamic rate instance that is specific
// to products with terms, such as CDs
// Current example url for the product rates service is:
// https://sit.bbt.com/clocator/promotionDetails.do?regionCode=NC-102-000&productCode=801
// Json response for mortgage rates has this format:
// {
//   "status": {
//     "statusCode": "000",
//     "statusDescription": "Success"
//   },
//   "productInfo": [
//     {
//       "regionCode": "NC-102-100",
//       "productCode": "801",
//       "productDescription": "Personal CD < $100K",
//       "termName": "7 DAYS",
//       "tierFrom": "0",
//       "tierTo": "9999",
//       "termFrom": "00000",
//       "rate": "00.05",
//       "apy": "00.05",
//       "termTo": "00029"
//     }
//   ]
// }
var l=po.getDynamicRateInstance(t),n=e.productInfo;l.tableCaptionText="Current rates",l.tableCellsByRow=[["Term","Tier","APY","Interest Rate"]],// Sorts the tier information
// First it groups the information by term
// Then it sorts them by tier within a term
n.sort(function(t,e){var n=parseInt(t.tierTo,10),r=parseInt(e.tierTo,10),a=parseInt(t.termTo,10),i=parseInt(e.termTo,10),o=0;return o=a<i?-1:a===i?n<r?-1:n===r?0:1:1,// Reverses the sort if the reverse option is true
l.reverseChartData&&(o*=-1),o});// Used to ensure that repeated term names are screen reader only
var u="";n.forEach(function(t,e){var n=po.toTitleCase(t.termName),r=n,a=po.formatNumberWithCommas(t.tierFrom),i=po.formatNumberWithCommas(t.tierTo),o="$".concat(a," - $").concat(i),s=po.formatNumberAsPercent(t.apy),c=po.formatNumberAsPercent(t.rate);// Used to ensure that repeated term names are screen reader only
n===u&&(r='<span class="lx-screen-reader-only">'.concat(n,"</span>")),// Removes rows with "Fill Days" as the term name
"Fill Days"!==(u=n)&&l.tableCellsByRow.push([r,o,s,c])})},foreignExchangeRatesAdapter:function(t,e){
// Returns a fully configured dynamic rate instance that is specific
// to foreign exchange rates
// Current example url for the currency rates service is:
// https://sit.bbt.com/clocator/foreignExchangeRates.do
// Json response for mortgage rates has this format:
// {
//   "lstExchangeRates": [
//     {
//       "currencyID": "19",
//       "countryName": "Australia",
//       "exchangeRate": "0.785",
//       "rateLastUpdated": "02/27/2018 08:50:04 GMT-05:00",
//       "currencyName": "Dollar",
//       "currencySymbol": "$"
//     },
//     {
//       "currencyID": "34",
//       "countryName": "UK",
//       "exchangeRate": "1.3945",
//       "rateLastUpdated": "02/27/2018 08:50:04 GMT-05:00",
//       "currencyName": "Pound",
//       "currencySymbol": "$"
//     }
//   ],
//   "status": {
//     "statusCode": "000",
//     "statusDescription": "Success"
//   }
// }
var i=po.getDynamicRateInstance(t),n=e.lstExchangeRates;i.tableCaptionText="Current rates",i.tableCellsByRow=[["Country","Currency","Exchange Rate"]],// Is used to display the dateAndTime above the table
i.dateAndTime=n[0].rateLastUpdated,// Sorts rates in alphabetical order by country name
n.sort(function(t,e){var n=0;return t.countryName<e.countryName?n=-1:t.countryName>e.countryName&&(n=1),n}),n.forEach(function(t,e){var n=po.toTitleCase(t.currencyName),r=po.toTitleCase(t.countryName),a=t.currencySymbol?t.currencySymbol:"";i.tableCellsByRow.push([r,n,"".concat(a).concat(t.exchangeRate)])})},foreignExchangeRatesMemoAdapter:function(t,e){
// Returns a fully configured dynamic rate instance that is specific
// to the foreign exchange rates memo
// Current example url for the currency rates service is:
// https://sit.bbt.com/clocator/foreignExchangeNote.do?memoKey=5
// Json response for mortgage rates has this format:
// {
//   "lastUpdate": "02/27/2018 08:50:04 GMT-05:00",
//   "description": "FXUpdate",
//   "memo": "<![CDATA[<h3>The text of the memo goes here ...</h3>]]>",
//   "status": {
//     "statusCode": "000",
//     "statusDescription": "Success"
//   }
// }
var n=po.getDynamicRateInstance(t);n.dateAndTime=e.lastUpdate,// get the memo content and remove non-content characters
n.memo=e.memo.replace(/.*\[.*\[/g,"").replace(/\].*\].*/g,"").replace(/<[^>]*>/g,"").replace(/&nbsp;/g," ").trim()},toTitleCase:function(t){return t.toLowerCase().split(" ").map(function(t){return t.charAt(0).toUpperCase()+t.slice(1)}).join(" ")},checkLabelAndDataOrder:function(t){
// Reverse the labels and data if necessary
var e=po.getDynamicRateInstance(t);e.reverseChartData&&(e.labels.reverse(),e.series[0].data.reverse(),e.series[1].data.reverse())},calculateSeriesTotalAndCounter:function(t){
// This calculation tells us when to switch to the APR/APY label
var e=po.getDynamicRateInstance(t);e.seriesTotal=e.series[0].data.length+e.series[1].data.length,e.seriesCounter=0},formatNumberWithCommas:function(t){return t.toString().replace(/\B(?=(\d{3})+(?!\d))/g,",")},formatNumberAsPercent:function(t){return"".concat(po.ensureAtLeastTwoDecimalPlaces(parseFloat(t)),"%")},ensureAtLeastTwoDecimalPlaces:function(t){var e=t.toString(),n=e.match(/^\d+.(\d+)$/),r="";n?r=1===n[1].length?"".concat(e,"0"):e:e.match(/^\d+$/)&&(
// it is a number, but it doesn't have a decimal point
r="".concat(e,".00"));return r},displayDynamicRateInstance:function(t){var e=po.getDynamicRateInstance(t);// Generate a chart
e.showChart&&po.generateChart(t),// Generate a table
e.showTable&&po.generateTable(t),// Show mortgage disclosures
""!==e.mortgageDisclosures&&po.generateMortgageDisclosures(t),// Show a memo
""!==e.memo&&po.generateMemo(t),// Remove the spinner
po.removeSpinner(t)},generateChart:function(t){var e=po.getDynamicRateInstance(t);d("#".concat(t," .").concat(po.CLASSES_NO_DOT.SPINNER_WRAPPER_DYNAMIC_RATES)).after('\n          <div \n            class="'.concat(po.CLASSES_NO_DOT.CHART_WRAPPER,'"\n            id="').concat(e.chartId,'">\n          </div>\n        ')),// Adjust the height of the chart wrapper based on the number of bars in the chart
d("#".concat(e.chartId)).closest(po.CLASSES.CHART_WRAPPER).addClass("".concat(po.CLASSES.CHART_WRAPPER.replace(".js-",""),"-").concat(e.labels.length,"-bars"));var n=po.calculateAxisRangeLow(e.series),r=po.configurePlugins(t),a={low:n,seriesBarDistance:0,horizontalBars:!0,reverseData:!1,chartPadding:{right:45},axisX:{offset:60,scaleMinSpace:50,labelInterpolationFnc:
/* eslint-disable arrow-body-style */
/* eslint-disable semi */
function(t){return"".concat(po.formatNumberAsPercent(t))}
/* eslint-enable arrow-body-style */
/* eslint-enable semi */},axisY:{offset:0,scaleMinSpace:0}};r&&(a.plugins=r);// Create the bar chart
new Chartist.Bar("#".concat(e.chartId),{labels:e.labels,series:e.series},a);// Label the y axis
po.labelYAxis(t),// Set the chart to be visually hidden for screen readers because we always include a table
d("#".concat(e.chartId)).attr("aria-hidden","true")},generateTable:function(t){var e=po.getDynamicRateInstance(t),n={tableId:e.chartId,makeScreenReaderOnly:e.showTable,classesForAdditionalStyling:"".concat(po.CLASSES.TABLE_WRAPPER.slice(1).replace("js-","")," ").concat(po.CLASSES.TABLE_WRAPPER.slice(1)),caption:e.tableCaptionText,tableCellsByRow:e.tableCellsByRow},r=window.BBT_AEM_Platform.TableBuilder.createTable(n);// Add the table to the page
d("#".concat(t," ").concat(po.CLASSES.OUTRO)).length?d("#".concat(t," ").concat(po.CLASSES.OUTRO)).before(r):d("#".concat(t)).append(r),// Additional functionality for foreign exchange rates
e.adapter===po.ADAPTER.FOREIGN_EXCHANGE&&po.generateTableHelperForForeignExchange(t)},generateTableHelperForForeignExchange:function(t){var e=po.getDynamicRateInstance(t);// Display the date and time if available
""!==e.dateAndTime&&d("#".concat(e.chartId)).before('<div class="'.concat(po.CLASSES_NO_DOT.FOREIGN_EXCHANGE_DATE_TIME,'">').concat(e.dateAndTime,"</div>"))},generateMortgageDisclosures:function(t){var e=po.getDynamicRateInstance(t);d("#".concat(t," .").concat(po.CLASSES_NO_DOT.SPINNER_WRAPPER_DYNAMIC_RATES)).after('\n          <div class="'.concat(po.CLASSES_NO_DOT.MORTGAGE_DISCLOSURES,'">\n            ').concat(e.mortgageDisclosures,"\n        "))},generateMemo:function(t){var e=po.getDynamicRateInstance(t);d("#".concat(t," .").concat(po.CLASSES_NO_DOT.SPINNER_WRAPPER_DYNAMIC_RATES)).after('\n          <div class="'.concat(po.CLASSES_NO_DOT.FOREIGN_EXCHANGE_DATE_TIME,'">\n            ').concat(e.dateAndTime,'\n          </div>\n          <div class="').concat(po.CLASSES_NO_DOT.FOREIGN_EXCHANGE_MEMO,'">\n            ').concat(e.memo,"\n          </div>\n        "))},calculateAxisRangeLow:function(t){
// Parameter is an array of series; each series has an array of values mapped to the 'data' key
var n=null;return t.forEach(function(t,e){t.data.forEach(function(t,e){n?t<n&&(n=t):n=t})}),Math.floor(n)},configurePlugins:function(t){
// The accessibility plugin was originally used to generate a table
// This functionality is now handled by a table generator
// let accessibilityPlugin = _private.configureAccessibilityPlugin( dynamicRateInstanceId );
// let labelPlugin = _private.configureLabelPlugin( dynamicRateInstanceId );
// let barChartPlugins = null;
// // The label plugin is only needed if the option to show chart labels is true
// if ( accessibilityPlugin && labelPlugin ) {
//   barChartPlugins = [ accessibilityPlugin, labelPlugin ];
// } else {
//   barChartPlugins = [accessibilityPlugin];
// }
// This is an alternate plugin setup that only includes a label plugin
// Add logic here if other plugins are required
var e=po.configureLabelPlugin(t),n=null;// The label plugin is only needed if the option to show chart labels is true
return e&&(n=[e]),n},configureAccessibilityPlugin:function(t){var e=po.getDynamicRateInstance(t),n=null,r=null;switch(e.adapter){case po.ADAPTER.MORTGAGE:n="Current rates",r="Product";break;case po.ADAPTER.PRODUCT:n="Current rates",r="Tier";break;default:r=n=""}return Chartist.plugins.ctAccessibilityBbt({caption:n,labelsHeader:r,
// summary: '',
classForAdditionalStyling:"".concat(po.CLASSES.TABLE_WRAPPER.slice(1).replace("js-","")," ").concat(po.CLASSES.TABLE_WRAPPER.slice(1)),elementId:e.tableId,makeScreenReaderOnly:!e.showTable,
/* eslint-disable arrow-body-style */
/* eslint-disable semi */
valueTransform:function(t){return"".concat(po.formatNumberAsPercent(t))}
/* eslint-enable arrow-body-style */
/* eslint-enable semi */})},configureLabelPlugin:function(t){var r=po.getDynamicRateInstance(t),e=null;return r.showChartLabels&&(e=Chartist.plugins.ctBarLabelsBbtMortgage({labelOffset:{y:17},
/* eslint-disable object-shorthand */
position:{x:function(t){return t.x1+20}},
/* eslint-enable object-shorthand */
labelInterpolationFnc:function(t){
/* eslint-disable no-param-reassign */
var e,n="";return r.seriesCounter+=1,e=r.seriesCounter-(r.seriesTotal/2+1),r.seriesCounter>r.seriesTotal/2&&(n={rate:"".concat(po.formatNumberAsPercent(r.series[0].data[e])),apr:"(".concat(po.formatNumberAsPercent(r.series[1].data[e])," APR)")}),r.seriesCounter===r.seriesTotal&&(r.seriesCounter=0),n}})),e},labelYAxis:function(t){
// Create a <div> to label the y-axis
// IE11 doesn't support the <foreignObject> element in svgs, so this is a workaround
var e,n=po.getDynamicRateInstance(t),r=n.labels.map(function(t){return'<div class="ct-vertical-label"><span class="ct-vertical-label__span">'.concat(t,"</span></div>")});// The labels need to visually appear in the opposite order they are specified in the array
r.reverse(),e='<div class="ct-vertical-label-wrapper" aria-hidden="true">'.concat(r.join(""),"</div>"),d("#".concat(n.chartId)).prepend(e)},displayServiceErrorMessage:function(t){var e='\n        <div class="'.concat(po.CLASSES_NO_DOT.DATA_SERVICE_ERROR,'">We are unable to retrieve rates at this time. Please try again later.</div>\n      ');// Add the table to the page
d("#".concat(t," ").concat(po.CLASSES.INTRO)).length?d("#".concat(t," ").concat(po.CLASSES.INTRO)).after(e):d("#".concat(t)).prepend(e),// Remove the spinner
po.removeSpinner(t)},init:function(){La.initChartist(),So.initChartistBarLabels(),// The accessibility plugin was originally used to generate a table
// This functionality is now handled by a table generator
// ChartistAccessibilityBbt.initChartistAccessibility();
po.setUpDynamicRateInstances(),// FOR TESTING - uncomment to introduce a delay in the service call
// setTimeout( () => {
//   _private.getAndDisplayRates();
// }, 1000 );
po.getAndDisplayRates()}}).init},_o={init:(Eo={SUCCESS_MSG_STATUS:"SUCCESS",WRAPPER_SELECTOR:"div.mlo-wrapper",ITEMS_SELECTOR:"ul.mlo-profile__list > li",PROFILE_IMAGE_SELECTOR:"div.mlo-profile__image > img",LINK_SELECTOR:"a > span:empty",MLO_SELECTOR:"div.mlo-row--row-2",MLO_ROW_NOT_SELECTED_SELECTOR:".mlo-wrapper .mlo-row--row-2.mlo-row--not-selected",IS_INITIALIZED_CLASS_NO_DOT:"is-initialized",
// adds a branch locator link at mobile to the left of the login button
displayMlo:function(){
/* eslint-disable no-useless-escape */
var s=document.cookie.replace(/(?:(?:^|.*;\s*)bbtmortgage\s*\=\s*([^;]*).*$)|^.*$/,"$1");
/* eslint-enable no-useless-escape */if(s.match(/^\d{4,12}$/)||s.match(/^[0-9a-fA-F]{32}$/)){var c=location.pathname.replace(/\.html$/,"");d.ajax({type:"GET",url:"".concat(c,".mlo.json/").concat(s,"/detail.json"),success:function(t){var o=t.data;t.status===Eo.SUCCESS_MSG_STATUS&&o.mloId===s?d(Eo.WRAPPER_SELECTOR).each(function(t){
// Update MLO profile content, per ajax response data
/* eslint-disable no-invalid-this */
var e=d(this),n=e.find(Eo.ITEMS_SELECTOR),r=d(n[1]).find("a"),a=o.nmlsNumber,i=o.hashId;
/* eslint-enable no-invalid-this */e.find(Eo.PROFILE_IMAGE_SELECTOR).attr("src","".concat(c,".mlo.jpg/").concat(s,"/image.jpg")),d(n[0]).text(function(t,e){return"".concat(e).concat(o.firstName," ").concat(o.lastName)}),r.text(o.phoneNumber),r.attr("href",function(t,e){return"".concat(e).concat(o.phoneNumber.replace(/-/g,""))}),d(n[3]).find(Eo.LINK_SELECTOR).text(a),// Update various links requiring NMLS parameter
e.find('a[href*="nmls="]').attr("href",function(t,e){return e.replace(/\bnmls=/,"nmls=".concat(a))}),// Update various links requiring hash parameter
e.find('a[href*="mlo="]').attr("href",function(t,e){return e.replace(/\bmlo=/,"mlo=".concat(i));// return was.replace( /\bmlo=/, `mlo=${mlohash.replace( /-/g, '' ).toLowerCase()}` );
}),// Reveal
e.find(Eo.MLO_SELECTOR).fadeToggle(0)}):(console.error("no results for NMLS ".concat(s)),Eo.displayNotSelectedRow())},error:function(t,e,n){console.error("could not retrieve MLO data: ".concat(n)),Eo.displayNotSelectedRow()}})}else console.error("bbtmortgage cookie missing or invalid"),Eo.displayNotSelectedRow()},displayNotSelectedRow:function(){d(Eo.MLO_ROW_NOT_SELECTED_SELECTOR).addClass(Eo.IS_INITIALIZED_CLASS_NO_DOT)},init:function(){Eo.displayMlo()}}).init},Ao={f:It},go=it.f,To=j("hidden"),vo="Symbol",yo=Mt.set,Oo=Mt.getterFor(vo),Co=rt.f,Ro=it.f,No=Dr.f,bo=z.Symbol,Lo=z.JSON,Io=Lo&&Lo.stringify,wo="prototype",xo=It("toPrimitive"),Po=q.f,Do=st("symbol-registry"),Mo=st("symbols"),Uo=st("op-symbols"),Bo=st("wks"),Ho=Object[wo],jo=z.QObject,Go=!jo||!jo[wo]||!jo[wo].findChild,ko=W&&N(function(){return 7!=Oe(Ro({},"a",{get:function(){return Ro(this,"a",{value:7}).a}})).a})?function(t,e,n){var r=Co(Ho,e);r&&delete Ho[e],Ro(t,e,n),r&&t!==Ho&&Ro(Ho,e,r)}:Ro,Fo=re&&"symbol"==typeof bo.iterator?function(t){return"symbol"==typeof t}:function(t){return Object(t)instanceof bo},Yo=function(t,e,n){return t===Ho&&Yo(Uo,e,n),U(t),e=P(e,!0),U(n),D(Mo,e)?(n.enumerable?(D(t,To)&&t[To][e]&&(t[To][e]=!1),n=Oe(n,{enumerable:b(0,!1)})):(D(t,To)||Ro(t,To,b(1,{})),t[To][e]=!0),ko(t,e,n)):Ro(t,e,n)};
// This functionality is now handled by a table generator
// import { ChartistAccessibilityBbt } from 'vendor/ChartistPluginAccessibility-bbt';
// `Symbol` constructor
// https://tc39.github.io/ecma262/#sec-symbol-constructor
re||(Ut((bo=function(t){if(this instanceof bo)throw TypeError("Symbol is not a constructor");var e=void 0===t?void 0:String(t),n=H(e),r=function(t){this===Ho&&r.call(Uo,t),D(this,To)&&D(this[To],n)&&(this[To][n]=!1),ko(this,n,b(1,t))};return W&&Go&&ko(Ho,n,{configurable:!0,set:r}),oo(n,e)})[wo],"toString",function(){return Oo(this).tag}),q.f=co,it.f=Yo,rt.f=lo,Wt.f=Dr.f=uo,Vt.f=ho,W&&(
// https://github.com/tc39/proposal-Symbol-description
Ro(bo[wo],"description",{configurable:!0,get:function(){return Oo(this).description}}),Ut(Ho,"propertyIsEnumerable",co,{unsafe:!0})),Ao.f=function(t){return oo(It(t),t)}),Nt({global:!0,wrap:!0,forced:!re,sham:!re},{Symbol:bo});for(var zo=me(Bo),Wo=0;zo.length>Wo;)io(zo[Wo++]);Nt({target:vo,stat:!0,forced:!re},{
// `Symbol.for` method
// https://tc39.github.io/ecma262/#sec-symbol.for
for:function(t){return D(Do,t+="")?Do[t]:Do[t]=bo(t)},
// `Symbol.keyFor` method
// https://tc39.github.io/ecma262/#sec-symbol.keyfor
keyFor:function(t){if(!Fo(t))throw TypeError(t+" is not a symbol");for(var e in Do)if(Do[e]===t)return e},useSetter:function(){Go=!0},useSimple:function(){Go=!1}}),Nt({target:"Object",stat:!0,forced:!re,sham:!W},{
// `Object.create` method
// https://tc39.github.io/ecma262/#sec-object.create
create:function(t,e){return void 0===e?Oe(t):so(Oe(t),e)},
// `Object.defineProperty` method
// https://tc39.github.io/ecma262/#sec-object.defineproperty
defineProperty:Yo,
// `Object.defineProperties` method
// https://tc39.github.io/ecma262/#sec-object.defineproperties
defineProperties:so,
// `Object.getOwnPropertyDescriptor` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertydescriptors
getOwnPropertyDescriptor:lo}),Nt({target:"Object",stat:!0,forced:!re},{
// `Object.getOwnPropertyNames` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertynames
getOwnPropertyNames:uo,
// `Object.getOwnPropertySymbols` method
// https://tc39.github.io/ecma262/#sec-object.getownpropertysymbols
getOwnPropertySymbols:ho}),
// Chrome 38 and 39 `Object.getOwnPropertySymbols` fails on primitives
// https://bugs.chromium.org/p/v8/issues/detail?id=3443
Nt({target:"Object",stat:!0,forced:N(function(){Vt.f(1)})},{getOwnPropertySymbols:function(t){return Vt.f(bt(t))}}),
// `JSON.stringify` method behavior with symbols
// https://tc39.github.io/ecma262/#sec-json.stringify
Lo&&Nt({target:"JSON",stat:!0,forced:!re||N(function(){var t=bo();
// MS Edge converts symbol values to JSON as {}
return"[null]"!=Io([t])||"{}"!=Io({a:t})||"{}"!=Io(Object(t))})},{stringify:function(t){for(var e,n,r=[t],a=1;a<arguments.length;)r.push(arguments[a++]);if(n=e=r[1],(x(e)||void 0!==t)&&!Fo(t))// IE8 returns string on undefined
return ne(e)||(e=function(t,e){if("function"==typeof n&&(e=n.call(this,t,e)),!Fo(e))return e}),r[1]=e,Io.apply(Lo,r)}}),
// `Symbol.prototype[@@toPrimitive]` method
// https://tc39.github.io/ecma262/#sec-symbol.prototype-@@toprimitive
bo[wo][xo]||ot(bo[wo],xo,bo[wo].valueOf),
// `Symbol.prototype[@@toStringTag]` property
// https://tc39.github.io/ecma262/#sec-symbol.prototype-@@tostringtag
Dn(bo,vo),pt[To]=!0;var Vo=it.f,Xo=z.Symbol;if(!(!W||"function"!=typeof Xo||"description"in Xo.prototype&&
// Safari 12 bug
void 0===Xo().description)){var qo={},$o=function(t){var e=arguments.length<1||void 0===t?void 0:String(t),n=this instanceof $o?new Xo(e):void 0===e?Xo():Xo(e);return""===e&&(qo[n]=!0),n};
// wrap Symbol constructor for correct work with undefined description
Ct($o,Xo);var Ko=$o.prototype=Xo.prototype;Ko.constructor=$o;var Qo=Ko.toString,Zo="Symbol(test)"==String(Xo("test")),Jo=/^Symbol\((.*)\)[^)]+$/;Vo(Ko,"description",{configurable:!0,get:function(){var t=x(this)?this.valueOf():this,e=Qo.call(t);if(D(qo,t))return"";var n=Zo?e.slice(7,-1):e.replace(Jo,"$1");return""===n?void 0:n}}),Nt({global:!0,forced:!0},{Symbol:$o})}
// `Symbol.iterator` well-known symbol
// https://tc39.github.io/ecma262/#sec-symbol.iterator
io("iterator");var ts="String Iterator",es=Mt.set,ns=Mt.getterFor(ts);
// `String.prototype[@@iterator]` method
// https://tc39.github.io/ecma262/#sec-string.prototype-@@iterator
Bn(String,"String",function(t){es(this,{type:ts,string:String(t),index:0});
// `%StringIteratorPrototype%.next` method
// https://tc39.github.io/ecma262/#sec-%stringiteratorprototype%.next
},function(){var t,e=ns(this),n=e.string,r=e.index;return r>=n.length?{value:void 0,done:!0}:(t=Qe(n,r,!0),e.index+=t.length,{value:t,done:!1})});var rs,as,is,os={init:(rs={FORM_CLASS:".form--qq",LOAN_TYPE_SELECT:".js-loan-type--qq",HOME_EQUITY_OPTION:".js-home-equity--qq",MORTGAGE_BALANCE_FORM_GROUP:".js-form-group--mortgage-balance",MORTGAGE_BALANCE_FORM_GROUP_DURATION:"fast",MORTGAGE_BALANCE_INPUT:".js-mortgage-balance--qq",VALUE_OF_HOME_INPUT:".js-home-value--qq",LOAN_AMOUNT_INPUT:".js-loan-amount--qq",PROPERTY_TYPE_SELECT:".js-property-type--qq",PROPERTY_USE_SELECT:".js-property-use--qq",STATE_SELECT:".js-state--qq",COUNTY_SELECT:".js-county--qq",HIDDEN_LOAN_TYPE_NAME:"hidden-loan-type",HIDDEN_HOME_VALUE_NAME:"hidden-home-value",HIDDEN_LOAN_AMT_NAME:"hidden-loan-amt",HIDDEN_MORTGAGE_BALANCE_NAME:"hidden-mortgage-balance",HIDDEN_PROPERTY_TYPE:"hidden-property-type",HIDDEN_PROPERTY_USE_NAME:"hidden-property-use",HIDDEN_STATE:"hidden-state",HIDDEN_COUNTY:"hidden-county",bindEvents:function(){
// display the mortgage balance select only for the home equity loan type option
d(rs.LOAN_TYPE_SELECT).on("change",rs.toggleMortgageBalanceSelectEventHandler),// display the county select only after a state has been selected
d(rs.STATE_SELECT).on("change",rs.toggleCountyDisableEventHandler),// update hidden form fields on submit
d(rs.FORM_CLASS).on("submit",rs.copyValuesToHiddenFields)},checkForInitiallyShownMortgageBalance:function(){d(rs.LOAN_TYPE_SELECT).each(function(t,e){var n=d(e).find(rs.HOME_EQUITY_OPTION).first().is(":selected"),r=d(e).closest("form").find(rs.MORTGAGE_BALANCE_FORM_GROUP).first(),a=r.find(rs.MORTGAGE_BALANCE_INPUT).first();rs.toggleMortgageBalanceSelect(n,r,a)})},toggleMortgageBalanceSelectEventHandler:function(t){var e=d(t.target).find(rs.HOME_EQUITY_OPTION).first().is(":selected"),n=d(t.target).closest("form").find(rs.MORTGAGE_BALANCE_FORM_GROUP).first(),r=n.find(rs.MORTGAGE_BALANCE_INPUT).first();rs.toggleMortgageBalanceSelect(e,n,r)},toggleMortgageBalanceSelect:function(t,e,n){
// IE11 still honors a required attribute even if the field is display: none
// so be sure to remove that attribute when the field is not visible
0<e.length&&0<n.length&&(t?(e.fadeIn(rs.MORTGAGE_BALANCE_FORM_GROUP_DURATION),n.prop("disabled",!1),n.attr("required","true")):(e.fadeOut(rs.MORTGAGE_BALANCE_FORM_GROUP_DURATION),n.prop("disabled",!0),n.removeAttr("required")))},checkForInitiallySelectedState:function(){d(rs.STATE_SELECT).each(function(t,e){var n=d(e).find("option:selected").val(),r=d(e).closest("form").find(rs.COUNTY_SELECT).first();rs.toggleCountyDisable(n,r)})},toggleCountyDisableEventHandler:function(t){var e=d(t.target).find("option:selected").val(),n=d(t.target).closest("form").find(rs.COUNTY_SELECT).first();rs.toggleCountyDisable(e,n)},toggleCountyDisable:function(t,e){if(0<e.length)if(
// remove any existing options } from the select
e.find("option").remove(),""!==t){
// add one option per county to the select
var n=window.BBT_AEM_Platform.Counties.getCountiesForState(t);e.append("<option></option>");var r=!0,a=!1,i=void 0;try{for(var o,s=n[Symbol.iterator]();!(r=(o=s.next()).done);r=!0){var c=o.value;e.append(d("<option></option>").attr("value",c.toUpperCase()).text(c))}}catch(t){a=!0,i=t}finally{try{r||null==s.return||s.return()}finally{if(a)throw i}}e.prop("disabled",!1)}else e.prop("disabled",!0)},copyValuesToHiddenFields:function(t){var e=d(t.target);e.find("[name='".concat(rs.HIDDEN_LOAN_TYPE_NAME,"']")).val(e.find(rs.LOAN_TYPE_SELECT).val()),e.find("[name='".concat(rs.HIDDEN_MORTGAGE_BALANCE_NAME,"']")).val(e.find(rs.MORTGAGE_BALANCE_INPUT).val()),e.find("[name='".concat(rs.HIDDEN_HOME_VALUE_NAME,"']")).val(e.find(rs.VALUE_OF_HOME_INPUT).val()),e.find("[name='".concat(rs.HIDDEN_LOAN_AMT_NAME,"']")).val(e.find(rs.LOAN_AMOUNT_INPUT).val()),e.find("[name='".concat(rs.HIDDEN_PROPERTY_TYPE,"']")).val(e.find(rs.PROPERTY_TYPE_SELECT).val()),e.find("[name='".concat(rs.HIDDEN_PROPERTY_USE_NAME,"']")).val(e.find(rs.PROPERTY_USE_SELECT).val()),e.find("[name='".concat(rs.HIDDEN_STATE,"']")).val(e.find(rs.STATE_SELECT).val()),e.find("[name='".concat(rs.HIDDEN_COUNTY,"']")).val(e.find(rs.COUNTY_SELECT).val())},init:function(){rs.bindEvents(),rs.checkForInitiallyShownMortgageBalance(),rs.checkForInitiallySelectedState()}}).init},ss={init:(as={SELECTORS:{STATE_FORM:".js-state-selector .js-form",BODY:"body"},CLASSES:{STATE_SELECTOR_SELECT:".js-select--state-selector",AEM_TEMPLATE:".aem-template",AEM_TEMPLATE_OPACITY_TRANSITION:"aem-template--opacity-transition",AEM_TEMPLATE_TRANSPARENT:"aem-template--transparent",LIMIT_TO_VIEW_HEIGHT:"limit-to-view-height"},CLASSES_NO_DOT:{CONTEXT_HUB_SPINNER_WRAPPER:"context-hub-spinner-wrapper",CONTEXT_HUB_SPINNER:"context-hub-spinner"},IDS:{MAIN_CONTENT:"#main-content"},CONTEXT_HUB:{STORE:"bbt-state-selector-store",KEY:"stateCode"},COOKIES:{KEY:"BBT_StateAbbr"},TIMEOUTS:{FADE_OUT:200,CONTEXT_HUB_STORE_DELAY:300},
/* eslint-disable no-undefined */
$stateSelectorForms:void 0,
/* eslint-enable no-undefined */
cacheDom:function(){as.$stateSelectorForms=d(as.SELECTORS.STATE_FORM)},bindEvents:function(){as.$stateSelectorForms.on("submit",as.updateState)},
// looks at the event to determine the active state selector
// checks to ensure that an option has been selected
// updates Context Hub or local storage and the BB&T cookie
updateState:function(t){t.preventDefault();var e=d(t.target).find("".concat(as.CLASSES.STATE_SELECTOR_SELECT," option")).filter(":selected").val().toUpperCase();e&&(
// fades the main content to prevent a flash and shows a spinner
d(as.CLASSES.AEM_TEMPLATE).fadeOut(as.TIMEOUTS.FADE_OUT),setTimeout(function(){d(as.SELECTORS.BODY).addClass(as.CLASSES.LIMIT_TO_VIEW_HEIGHT),d(as.SELECTORS.BODY).prepend('\n              <div class="'.concat(as.CLASSES_NO_DOT.CONTEXT_HUB_SPINNER_WRAPPER," js-").concat(as.CLASSES_NO_DOT.CONTEXT_HUB_SPINNER_WRAPPER,'" \n                aria-label="loading content for your selected state"\n                tabindex="0"\n              >\n                <div \n                  class="spinner ').concat(as.CLASSES_NO_DOT.CONTEXT_HUB_SPINNER," js-").concat(as.CLASSES_NO_DOT.CONTEXT_HUB_SPINNER,' spinner--md spinner--background" \n                  aria-hidden="true"\n                >\n                </div>\n              </div>')),d(as.SELECTORS.BODY).find(".js-".concat(as.CLASSES_NO_DOT.CONTEXT_HUB_SPINNER_WRAPPER)).first().focus();try{ContextHub.getStore(as.CONTEXT_HUB.STORE).setItem(as.CONTEXT_HUB.KEY,e)}catch(t){
// if Context Hub isn't available,
// create a local store value that mimics the structure of the Context Hub value
localStorage.setItem("store",JSON.stringify({store:Oa({},as.CONTEXT_HUB.STORE,Oa({},as.CONTEXT_HUB.KEY,e))}))}// sets the BB&T cookie
document.cookie="".concat(as.COOKIES.KEY,"=").concat(e,"; path=/"),// reloads the page
/* eslint-disable no-self-assign */
location.href=location.href},as.TIMEOUTS.CONTEXT_HUB_STORE_DELAY))},initiallySelectState:function(){
// check to see if a state is already selected and if so, select it in the select element
/* eslint-disable no-undefined */
/* eslint-disable no-undef-init */
var r=void 0;
/* eslint-disable no-undef-init */
/* eslint-enable no-undefined */try{r=ContextHub.getStore(as.CONTEXT_HUB.STORE).getItem(as.CONTEXT_HUB.KEY).toUpperCase()}catch(t){
// if Context Hub isn't available,
// look for a local store value that mimics the structure of the Context Hub value
localStorage.getItem("store")&&(r=JSON.parse(localStorage.getItem("store")).store[as.CONTEXT_HUB.STORE][as.CONTEXT_HUB.KEY].toUpperCase())}r&&as.$stateSelectorForms.each(function(t,e){d(e).find("".concat(as.CLASSES.STATE_SELECTOR_SELECT," option")).each(function(t,e){var n=d(e);n.val().toUpperCase()===r&&n.prop("selected",!0)})})},init:function(){as.cacheDom(),as.initiallySelectState(),as.bindEvents()}}).init},cs={init:(is={IDS:{NEW_FOOTER_UTILITY_ROW:"#contact-utility-links"},IDS_NO_HASH:{CHAT_DESKTOP_HEADER:"liveperson-chat-header-desktop",CHAT_FOOTER:"liveperson-chat-footer",CHAT_MOBILE_HEADER:"liveperson-chat-header-mobile",CHAT_MOST_PROMINENT:"liveperson-chat-most-prominent"},CLASSES:{MOBILE_TOP_TASK_CONTAINER:".header__navigation-list--secondary .header__navigation-list--top-tasks .header__navigation-list--top-tasks--mobile",RESPONSIVE_IFRAME:".js-responsive-iframe",RESPONSIVE_IFRAME_WRAPPER:".js-responsive-iframe-wrapper",SCROLL_TO_TOP:".js-lx-button--scroll-to-top"},CLASSES_NO_DOT:{DISPLAY_NONE:"display-none",HIDDEN_LG_UP:"hide--lg-up",COLUMN_THREE_ADDITIONAL:"lx-grid--3-columns-lg-up",COLUMN_FOUR_ADDITIONAL:"lx-grid--4-columns-lg-up"},SELECTORS:{BRANCH_LOCATOR_UL:".header__wrapper--primary-navbar--right .navbar--primary__list",CHAT_MOST_PROMINENT_PARENT:".aem-template",EDUCATION_ROW:".column-wrapper--education-row .js-column .js-lx-grid",FOOTER_UTILITY_UL:".footer-nav--secondary",HEADER_CHAT_LOCATION_UL:".header__wrapper--secondary-navbar--right > .header__navigation-list--secondary.header__navigation-list--utilities",MOBILE_GLOBAL_SEARCH_FORM:"#js-header__search-form--mobile",MOBILE_SEGMENT_TABS:"#header__segment-tabs-list",MOBILE_UTILITY_UL:".header__wrapper--primary-navbar--center .header__navigation-list--utilities",MOBILE_TAB_PANEL_GROUP:".header__segment-tabs__panel-group",RESPONSIVE_IFRAME_HEADER:".responsive-iframe__intro .text-block__title",RELATED_ROW:".column-wrapper--related-row .js-column .js-lx-grid"},TEXT:{CONTACT:"Contact",CONTACT_SPANISH:"Contáctenos",LOCATIONS:"Locations",LOCATIONS_SPANISH:"Sucursales"},MOTIONPOINT:{DO_NOT_TRANSLATE_START:"\x3c!-- mp_trans_disable_start --\x3e",DO_NOT_TRANSLATE_END:"\x3c!-- mp_trans_disable_end --\x3e",ENGLISH_ONLY:'\n        \x3c!--mp_trans_add\n          <p class="mp-trans-es--before-component">\n            Solo en ingl&eacute;s\n          </p>\n        --\x3e \n      '},addBranchLocatorLink:function(){
// adds a branch locator link at mobile to the left of the login button
d(is.SELECTORS.BRANCH_LOCATOR_UL).prepend('\n        <li class="navbar--primary__list-item navbar--primary__list-item--locator" role="presentation">\n          <a class="navbar--primary__locator-button js-header__mobile-menu-focusable"  href="https://www.bbt.com/locator/search.page">\n            <svg class="lx-icon lx-icon--fill-map-marker" viewbox="0 0 16 16" aria-hidden="true" focusable="false">\n              <path d="M8 .5a4.64 4.64 0 0 0-4.66 4.66C3.34 7.74 8 15.5 8 15.5s4.66-7.76 4.66-10.34A4.64 4.64 0 0 0 8 .5zm0 6.21a1.66 1.66 0 1 1 1.66-1.66A1.66 1.66 0 0 1 8 6.71z"></path>\n            </svg>\n            <span class="lx-screen-reader-only">Locations</span>\n          </a>\n        </li>\n      ');// this change is currently commented out because the mobile view has two items,
// but the desktop view really only has one because the branch locator item is display:none
// remove role="presentation" from the header cta area if there is more than one item
// if (
//   $(
//     '.header__wrapper--primary-navbar--right .navbar--primary__list .navbar--primary__list-item'
//   ).length > 1
// ) {
//   $(
//     '.header__wrapper--primary-navbar--right .navbar--primary__list'
//   ).removeAttr('role');
//   $(
//     '.header__wrapper--primary-navbar--right .navbar--primary__list .navbar--primary__list-item'
//   ).removeAttr('role');
// }
},adjustColumnsOnFancyRows:function(){
// adjust the column classes to 2, 3, or 4 columns per row for education and related rows
/* eslint-disable no-invalid-this */
// adjust education row classes if necessary
d(is.SELECTORS.EDUCATION_ROW).each(function(){var t=d(this);switch(t.children().length){case 1:case 2:t.removeClass(is.CLASSES_NO_DOT.COLUMN_THREE_ADDITIONAL);break;case 4:t.removeClass(is.CLASSES_NO_DOT.COLUMN_THREE_ADDITIONAL).addClass(is.CLASSES_NO_DOT.COLUMN_FOUR_ADDITIONAL)}}),d(is.SELECTORS.RELATED_ROW).each(function(){
// adjust related row classes if necessary
var t=d(this);switch(t.children().length){case 2:t.removeClass(is.CLASSES_NO_DOT.COLUMN_THREE_ADDITIONAL);break;case 4:t.removeClass(is.CLASSES_NO_DOT.COLUMN_THREE_ADDITIONAL).addClass(is.CLASSES_NO_DOT.COLUMN_FOUR_ADDITIONAL)}})},updatePromoFull:function(){
// checks to see if a promo full has an h1
// if so, adds the promo--full-width-wrapper--contains-h1 class to the wrapper
d(".js-promo--full-width-wrapper").each(function(t,e){var n=d(e);0<n.find("h1").length&&n.addClass("promo--full-width-wrapper--contains-h1")})},removeParentComponent:function(t){t.data.$parent.remove()},addTabHeaders:function(){
// adds a header to the start of each tab panel
// the header has the same text as the tab
d(".js-component--parent.js-tabs-wrapper").each(function(t,e){var n=d(e),r=n.find(".tabs__intro .text-block__title"),a="h2";// if there is a intro, make the headers level 3
r.length&&(a="h3"),n.find(".js-tabs__trigger").each(function(t,e){var n=d(e),r=n.text().trim();d("[aria-labelledby='".concat(n.attr("id"),"'] ")).prepend("<".concat(a,' class="tab-pane-header">').concat(r,"</").concat(a,">"))})})},adjustMobileHeaderSearchPosition:function(){
// moves mobile search form to proper location for BBT.com mobile Menu
d(is.SELECTORS.MOBILE_GLOBAL_SEARCH_FORM).addClass(is.CLASSES_NO_DOT.HIDDEN_LG_UP).detach().insertAfter(is.SELECTORS.MOBILE_SEGMENT_TABS)},adjustMobileHeaderUtilityLinks:function(){
// moves the location and contact utility links to a more prominent
// position within the hamburger menu
var t=d("".concat(is.SELECTORS.MOBILE_UTILITY_UL," li a:contains('").concat(is.TEXT.CONTACT,"')")),e=d("".concat(is.SELECTORS.MOBILE_UTILITY_UL," li a:contains('").concat(is.TEXT.LOCATIONS,"')"));if(// check for different link text on Spanish language pages
t.length||(t=d("".concat(is.SELECTORS.MOBILE_UTILITY_UL," li a:contains('").concat(is.TEXT.CONTACT_SPANISH,"')"))),e.length||(e=d("".concat(is.SELECTORS.MOBILE_UTILITY_UL," li a:contains('").concat(is.TEXT.LOCATIONS_SPANISH,"')"))),t.length||e.length){// moves the contact utility link
if(
// create the container for the more prominent utility links if it doesn't already exist
d(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/ /g,"")).length||d(is.SELECTORS.MOBILE_TAB_PANEL_GROUP).after('\n            <div class="'.concat(is.CLASSES_NO_DOT.HIDDEN_LG_UP,'">\n              <ul class="').concat(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/\./g,""),'">\n              </ul>\n            </div>\n          ')),t.length){var n=t.parent("li");t.removeClass().addClass("lx-button header__navigation-list-item--secondary__button header__navigation-list--top-tasks__button js-header__mobile-menu-focusable").detach().appendTo(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/\s+/g,"")),t.wrap('<li class="header__navigation-list-item--secondary header__navigation-list-item--top-tasks"></li>'),n.remove()}// moves the location utility link
if(e.length){var r=e.parent("li");e.removeClass().addClass("lx-button header__navigation-list-item--secondary__button header__navigation-list--top-tasks__button js-header__mobile-menu-focusable").detach().appendTo(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/\s+/g,"")),e.wrap('<li class="header__navigation-list-item--secondary header__navigation-list-item--top-tasks"></li>'),r.remove()}}},adjustFooterUtilityLinks:function(){
// adds a contact phone number
// moves the contact and locations buttons to a more prominent position within the footer menu
// adds the footer chat container
// add a utility row above the existing utility row
d(is.SELECTORS.FOOTER_UTILITY_UL).before('\n        <ul id="'.concat(is.IDS.NEW_FOOTER_UTILITY_ROW.slice(1),'" class="footer-nav footer-nav--secondary">\n        </ul>\n      ')),// add a contact phone number
d(is.IDS.NEW_FOOTER_UTILITY_ROW).append('\n        <li class="footer-nav-item">\n          <a class="lx-button footer-nav-link" href="tel:1-800-226-5228">\n            Phone24: 800-BANK-BBT\n          </a>\n        </li>\n      ');var t=d("".concat(is.SELECTORS.FOOTER_UTILITY_UL," li:contains('").concat(is.TEXT.CONTACT,"')")),e=d("".concat(is.SELECTORS.FOOTER_UTILITY_UL," li:contains('").concat(is.TEXT.LOCATIONS,"')"));// check for different link text on Spanish language pages
t.length||(t=d("".concat(is.SELECTORS.FOOTER_UTILITY_UL," li:contains('").concat(is.TEXT.CONTACT_SPANISH,"')"))),e.length||(e=d("".concat(is.SELECTORS.FOOTER_UTILITY_UL," li:contains('").concat(is.TEXT.LOCATIONS_SPANISH,"')"))),// move the contact utility link
t.length&&t.detach().appendTo(is.IDS.NEW_FOOTER_UTILITY_ROW),// move the locations utility link
e.length&&e.detach().appendTo(is.IDS.NEW_FOOTER_UTILITY_ROW)},addChatContainers:function(){
// adds the containers that the chat vendor uses to inject a chat button/link
// add the header chat container
d(is.SELECTORS.HEADER_CHAT_LOCATION_UL).prepend('\n        <li class="header__navigation-list-item--secondary header__navigation-list-item--utilities">\n          <div id="'.concat(is.IDS_NO_HASH.CHAT_DESKTOP_HEADER,'"></div>\n        </li>\n      ')),// create the container for the more prominent utility links if it doesn't already exist
d(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/ /g,"")).length||d(is.SELECTORS.MOBILE_TAB_PANEL_GROUP).after('\n          <div class="'.concat(is.CLASSES_NO_DOT.HIDDEN_LG_UP,'">\n            <ul class="').concat(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/\./g,""),'">\n            </ul>\n          </div>\n        ')),// adds the mobile header chat link to the prominent utility links class
d(is.CLASSES.MOBILE_TOP_TASK_CONTAINER.replace(/\s+/g,"")).append('\n        <li class="header__navigation-list-item--secondary header__navigation-list-item--top-tasks">\n          <div id="'.concat(is.IDS_NO_HASH.CHAT_MOBILE_HEADER,'"></div>\n        </li>\n      ')),// adds the footer chat container
d(is.IDS.NEW_FOOTER_UTILITY_ROW).append('\n        <li class="footer-nav-item">\n          <div id="'.concat(is.IDS_NO_HASH.CHAT_FOOTER,'"></div>\n        </li>\n      ')),// adds the most prominent chat that appears to the left of the scroll to top link at the bottom right
d(is.CLASSES.SCROLL_TO_TOP).length?
// add it before the scroll to top link if it exists
d(is.CLASSES.SCROLL_TO_TOP).before('\n          <div id="'.concat(is.IDS_NO_HASH.CHAT_MOST_PROMINENT,'"></div>\n        ')):
// otherwise add it as the last item on the page
d(is.SELECTORS.CHAT_MOST_PROMINENT_PARENT).append('\n          <div id="'.concat(is.IDS_NO_HASH.CHAT_MOST_PROMINENT,'"></div>\n        '))},
/* eslint-disable */
configureAndActivateChat:function(){
// sets the account number to a sandbox account for sites other than prod
var t="aem-sit.bbt.com"==location.hostname||"aem-dev.bbt.com"==location.hostname||"sit.bbt.com"==location.hostname||"uat.bbt.com"==location.hostname||"dev.bbt.com"==location.hostname||"localhost"==location.hostname||"perf.bbt.com"==location.hostname||"pages.enuat.bbt.com"==location.hostname||"myuat.bbt.com"==location.hostname||"cmsauthor-dev.bbtnet.com"==location.hostname||"cmsauthor-sit.bbtnet.com"==location.hostname||"cmsauthor.bbtnet.com"==location.hostname?"28600839":"63135181";// initiates Live Person chat
// the configuration interface on Live Person allows for the specification of urls
// if the page is specified in the list of urls, the chat buttons will be injected
// this code is provided by Live Person
if(window.lpMTagConfig=window.lpMTagConfig||{},window.lpTag=window.lpTag||{},void 0===window.lpTag._tagCount){window.lpTag={site:t,section:lpTag.section||"",autoStart:!1!==lpTag.autoStart,ovr:lpTag.ovr||{},_v:"1.5.1",_tagCount:1,protocol:location.protocol,events:{bind:function(t,e,n){lpTag.defer(function(){lpTag.events.bind(t,e,n)},0)},trigger:function(t,e,n){lpTag.defer(function(){lpTag.events.trigger(t,e,n)},1)}},defer:function(t,e){0==e?(this._defB=this._defB||[],this._defB.push(t)):1==e?(this._defT=this._defT||[],this._defT.push(t)):(this._defL=this._defL||[],this._defL.push(t))},load:function(t,e,n){var r=this;setTimeout(function(){r._load(t,e,n)},0)},_load:function(t,e,n){var r=t;t||(r=this.protocol+"//"+(this.ovr&&this.ovr.domain?this.ovr.domain:"lptag.liveperson.net")+"/tag/tag.js?site="+this.site);var a=document.createElement("script");a.setAttribute("charset",e||"UTF-8"),n&&a.setAttribute("id",n),a.setAttribute("src",r),document.getElementsByTagName("head").item(0).appendChild(a)},init:function(){this._timing=this._timing||{},this._timing.start=(new Date).getTime();var t=this;window.attachEvent?window.attachEvent("onload",function(){t._domReady("domReady")}):(window.addEventListener("DOMContentLoaded",function(){t._domReady("contReady")},!1),window.addEventListener("load",function(){t._domReady("domReady")},!1)),void 0===window._lptStop&&this.load()},start:function(){this.autoStart=!0},_domReady:function(t){this.isDom||(this.isDom=!0,this.events.trigger("LPT","DOM_READY",{t:t})),this._timing[t]=(new Date).getTime()},vars:lpTag.vars||[],dbs:lpTag.dbs||[],ctn:lpTag.ctn||[],sdes:lpTag.sdes||[],ev:lpTag.ev||[]},lpTag.init();//Start datalayer event listeners
var e,n=["OFFER_CLICK","OFFER_TIMEOUT","OFFER_DECLINED"];for(e=0;e<n.length;e++)lpTag.events.bind("LP_OFFERS",n[e],function(t,e){digitalData&&digitalData.eventTrack&&digitalData.eventTrack("lpChatEvent",{eventName:"lpChatEvent",attributes:{lpEventType:e.eventName,lpEngagementName:t.engagementName}})});//End datalayer event listeners
}else window.lpTag._tagCount+=1},
/* eslint-enable */
/* eslint-disable wrap-iife */
/* eslint-disable func-names */
/* eslint-disable no-underscore-dangle */
/* eslint-disable prefer-const */
/* eslint-disable no-multi-str */
/* eslint-disable no-console */
addMotionPointTags:function(){
// wrap responsive iframes to prevent translating items inside of them
d(is.CLASSES.RESPONSIVE_IFRAME_WRAPPER).each(function(t,e){d(e).find(is.RESPONSIVE_IFRAME).prepend("".concat(is.MOTIONPOINT.ENGLISH_ONLY," ").concat(is.MOTIONPOINT.DO_NOT_TRANSLATE_START)).append("".concat(is.MOTIONPOINT.DO_NOT_TRANSLATE_END))}),// wraps contact forms to prevent translating items inside of them
d(is.SELECTORS.CONTACT_FORM).each(function(t,e){d(e).prepend("".concat(is.MOTIONPOINT.ENGLISH_ONLY," ").concat(is.MOTIONPOINT.DO_NOT_TRANSLATE_START)).append("".concat(is.MOTIONPOINT.DO_NOT_TRANSLATE_END))})},hideIframeHeaders:function(){is.hideIframeHeaderHelper("https://securemigrate.bbtsecurities.com/Public/MarketWidget"),is.hideIframeHeaderHelper("https://pages.en.bbt.com/lp.form.emlmkt.optdwn.globalv2.html")},hideIframeHeaderHelper:function(t){d('iframe[src*="'.concat(t,'"]')).each(function(t,e){var n=d(e);if(n.length){var r=n.closest(is.CLASSES.RESPONSIVE_IFRAME_WRAPPER).find(is.SELECTORS.RESPONSIVE_IFRAME_HEADER);r.length&&r.addClass(is.CLASSES_NO_DOT.DISPLAY_NONE)}})},addAccessibleNameToLogins:function(){
// login in the header component
d(".header-login__xf form").each(function(t,e){d(e).closest(".js-login-wrapper").length?d(e).attr("aria-label","Login"):d(e).closest(".js-generic-select-wrapper").length&&d(e).attr("aria-label","Login to another account")}),// login(s) in promo login components
d(".promo--login__xf").each(function(t,e){d(e).find("form").each(function(t,e){d(e).closest(".js-login-wrapper").length?d(e).attr("aria-label","Login"):d(e).closest(".js-generic-select-wrapper").length&&d(e).attr("aria-label","Login to another account")})})},augmentPlantracAndSponsorlinkLogins:function(){
// add hidden values to the forms for PlanTrac and Sponsorlink
// <input value="sponsorlink" type="hidden" name="Cookievalue">
var a=/.*\/\/plantrac\w*.bbt.com\/auth\/pltpwd.tb/,i=/.*\/\/sponsorlink\w*.bbt.com\/auth\/preMigrate.tb/;d(".js-login-wrapper form").each(function(t,e){var n=d(e),r=n.attr("action");r&&(a.exec(r)?n.find("input[value='plantrac'][name='Cookievalue']").length||n.append('<input value="plantrac" type="hidden" name="Cookievalue">'):i.exec(r)&&(n.find("input[value='sponsorlink'][name='Cookievalue']").length||n.append('<input value="sponsorlink" type="hidden" name="Cookievalue">')))})},addHiddenFieldsForLogins:function(){
// add hidden values to the forms for logging into u
// form action for targeting is https://bank[,sit,uat].bbt.com/auth/pwd.tb
// hidden field to insert is <input name="var_field" value="" id="[id specific to location on page]" type="hidden">
// var_ns is assumed to be present as a global object with a data_parse function
// - the code that creates var_ns is external to this function and should be run before this function is run
var a=/.*\/\/bank.*?\.bbt\.com\/auth\/pwd\.tb/,i="logon_primary_header",o="logon_secondary_banner";d(".js-login-wrapper form").each(function(t,e){var n=d(e),r=n.attr("action");r&&a.exec(r)&&(n.closest("header").length?(n.append('<input name="var_field" value="" id="'.concat(i,"-").concat(t,'" type="hidden">')),"undefined"!=typeof var_ns&&var_ns.data_parse("".concat(i,"-").concat(t))):(n.append('<input name="var_field" value="" id="'.concat(o,"-").concat(t,'" type="hidden">')),"undefined"!=typeof var_ns&&var_ns.data_parse("".concat(o,"-").concat(t))))})},addRoleNavigation:function(){
// sets up the segments in the header and sections of the footer with role="navigation"
var r=0;// header
d(".header__wrapper.header__wrapper--secondary-navbar.header__wrapper--secondary-navbar--left").attr("role","navigation"),// footer
d(".footer-nav.footer-nav--xf .js-text-block-wrapper").each(function(t,e){var n=d(e);n.find(".text-block__title").attr("id","a11y-navigation-".concat(r)),n.find(".text-block__paragraph").attr("role","navigation").attr("aria-labelledby","a11y-navigation-".concat(r)),r+=1})},updateLangForSpanishPodcasts:function(){
// set the main content language to Spanish
// except the final disclosure is in English
"en"===d("html").attr("lang")&&d("body").hasClass("spanish-main-content")&&(d("#main-content").attr("lang","es"),d(".disclosures__block").last().attr("lang","en"))},init:function(){is.addBranchLocatorLink(),is.adjustColumnsOnFancyRows(),is.updatePromoFull(),// _private.updateBlockAlerts();
is.addTabHeaders(),is.adjustMobileHeaderSearchPosition(),is.adjustMobileHeaderUtilityLinks(),is.adjustFooterUtilityLinks(),is.addChatContainers(),is.configureAndActivateChat(),is.addMotionPointTags(),is.hideIframeHeaders(),is.addAccessibleNameToLogins(),is.augmentPlantracAndSponsorlinkLogins(),is.addHiddenFieldsForLogins(),is.addRoleNavigation(),is.updateLangForSpanishPodcasts()}}).init},ls=!1;// listen for a dispatched event from platform to indicate that it is ready
d("body").on("platformStatus",// initialize modules
function(){
// ensures that modules are only initialized once
ls||(ls=!0,window.BBT_AEM_Platform.ScrollToTop.init("0 0 16 16"),d(".js-cash-rewards-calculator-wrapper").length&&Ia.init(),d(".js-travel-rewards-calculator-wrapper").length&&wa.init(),d(".js-dynamic-rates-wrapper").length&&mo.init(),d(".js-form").length&&
// the BBT.com forms will only be displayed in English regardless of the page language
window.BBT_AEM_Platform.Form.setContactFormLanguage("en"),d(".js-mlo-wrapper").length&&_o.init(),d(".js-qq-wrapper").length&&(window.BBT_AEM_Platform.Counties.init(),os.init()),d(".js-state-selector").length&&ss.init(),cs.init(),// add the components to a global object for reference
window.BBT_AEM_BBTCom={
// components
Calculator:dn,CalculatorCashRewards:Ia,CalculatorTravelRewards:wa,DynamicRates:mo,Mlo:_o,QuickQuote:os,SiteBBTcom:cs,StateSelector:ss},console.log("bbtcom js version 1.1.14 is initialized"))})}($);
//# sourceMappingURL=build/bbtcom/js/bbtcom-1.1.14.js.map
"use strict";

function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

var BranchLocator = function () {
  var _private = {
    CLASSES: {
      SEARCH_DETAILS_SEARCH_FOR_GROUP: '.js-search-type-group',
      LOCATE_ME_BUTTON: '.js-geolocation-button',
      MAP_WRAPPER: '.js-branch-locator__map-wrapper',
      UPDATE_DIRECTIONS_BUTTON: '.js-update-directions',
      STEPS_BUTTON: '.js-steps',
      DIRECTIONS_LINK: '.js-directions'
    },
    CLASSES_NO_DOT: {
      IS_ACTIVE: 'is-active',
      IS_EXPANDED: 'is-expanded',
      SCREEN_LARGE: 'lg-screen',
      SCREEN_SMALL: 'sm-screen',
      MAP_21BY9: 'responsive-embed--21by9',
      MAP_4BY3: 'responsive-embed--4by3',
      DISPLAY_NONE: 'display-none'
    },
    IDS: {
      SEARCH_TYPE_BRANCH: '#search-type-branch',
      SEARCH_TYPE_ATM: '#search-type-atm',
      BRANCH_DETAILS: '#js-branch-details',
      ATM_DETAILS: '#js-atm-details',
      LOCATE_ME_TEMP_BUTTON: '#geolocation-temp-button',
      NEAR_LOCATION_FORM: '#form--branch-locator',
      BY_CITY_FORM: '#branch-locator__state-select-form'
    },
    OBJECTS: {
      $WINDOW: $(window),
      $GEOLOCATION_INPUT: $('#geolocation-input--branch-locator'),
      $BACK_TO_SEARCH: $('p.branch-locator-back-to-search'),
      $ALERT_DIV: $('#attention2'),
      SEARCH_LOCATIONS_PARAM_HASH: {
        'zip': 'quickZip',
        'citystate': 'address',
        'address': 'address'
      }
    },
    MISC: {
      MAPQUEST_KEY: 'Gmjtd%7Cluurnu0tn5%2C82%3Do5-lrb0d',
      CHUNK_SIZE: 9,
      IE11_MODE: $('html').hasClass('no-cssgrid'),
      TODAY: function () {
        var today = new Date();

        function getDoris(format) {
          return today.toLocaleString('en-us', {
            weekday: format
          }).replace(/^\W*/, ''); // .replace call is here because IE11 prepends
        } // null character to result of .toLocaleString


        return {
          short: getDoris('short').toUpperCase(),
          long: getDoris('long')
        };
      }()
    },
    bindEvents: function bindEvents() {
      // display options for branches and atms
      $(_private.IDS.SEARCH_TYPE_BRANCH).on('click', _private.displayOptions);
      $(_private.IDS.SEARCH_TYPE_ATM).on('click', _private.displayOptions); // handlers for geo-location button and accompanying text field

      $(_private.CLASSES.LOCATE_ME_BUTTON).on('click', _private.showLocateMeWaitingIndicator);
      $('input[name="geolocation-input--branch-locator"]').on('change', _private.handleGeolocationInputChange);
      _private.OBJECTS.$GEOLOCATION_INPUT.val() && _private.OBJECTS.$GEOLOCATION_INPUT.change(); // invoke change handler now iff field is pre-populated (eg, we came here via back or forward button, and browser remembered prior input)
      // handle form submits

      $(_private.IDS.NEAR_LOCATION_FORM).on('submit', _private.handleFindLocations);
      $(_private.IDS.BY_CITY_FORM).on('submit', _private.handleSelectState); // getting directions

      $(_private.CLASSES.DIRECTIONS_LINK).on('click', _private.showDirections);
      $(_private.CLASSES.UPDATE_DIRECTIONS_BUTTON).on('click', _private.showDirections).on('click', _private.handleUpdateDirectionsClick); // also

      $(document).on('viewTransition', _private.handleViewTransition);
      $('a#branch-locator-new-search').on('click', _private.handleStartNewSearch);

      _private.OBJECTS.$BACK_TO_SEARCH.find('>a').on('click', _private.handleBackToSearchResults);

      _private.OBJECTS.$ALERT_DIV.find('a').on('click', function () {
        return _private.shifty.scroller(_private.OBJECTS.$GEOLOCATION_INPUT);
      });

      $('#suggest-cards').on('click', 'a', _private.handleSuggestionCardClick); // delegated event handler!

      $('div.js-display-tagged-cards').on('click', 'button.js-display-tagged-cards__more-button', _private.handleMoreClick); // delegated event handler!

      $('div.js-branch-locator').on('click', 'a.card__button[href="#main-content-row--branch-map"]', _private.handleViewOnMapClick); // delegated event handler!

      $('div.js-branch-locator').on('click', 'a[href^="#result-card"]', _private.handleGetDetailsClick); // delegated event handler!

      $('.branch-locator-map-results-steps-table__collapsible tbody').on('click', 'a', _private.mapper.handleStepClick); // delegated event handler!
    },
    // displays options based on the user selection of search type (branch or atm)
    displayOptions: function displayOptions(event) {
      var $branchOptions = $(_private.IDS.BRANCH_DETAILS);
      var $atmOptions = $(_private.IDS.ATM_DETAILS);

      if (event.target.id === _private.IDS.SEARCH_TYPE_BRANCH.slice(1)) {
        if (!$branchOptions.hasClass(_private.CLASSES_NO_DOT.IS_ACTIVE)) {
          $branchOptions.addClass(_private.CLASSES_NO_DOT.IS_ACTIVE);
        }

        if ($atmOptions.hasClass(_private.CLASSES_NO_DOT.IS_ACTIVE)) {
          $atmOptions.removeClass(_private.CLASSES_NO_DOT.IS_ACTIVE);
        }
      }

      if (event.target.id === _private.IDS.SEARCH_TYPE_ATM.slice(1)) {
        if (!$atmOptions.hasClass(_private.CLASSES_NO_DOT.IS_ACTIVE)) {
          $atmOptions.addClass(_private.CLASSES_NO_DOT.IS_ACTIVE);
        }

        if ($branchOptions.hasClass(_private.CLASSES_NO_DOT.IS_ACTIVE)) {
          $branchOptions.removeClass(_private.CLASSES_NO_DOT.IS_ACTIVE);
        }
      }
    },
    showLocateMeWaitingIndicator: function showLocateMeWaitingIndicator(event) {
      event.preventDefault();
      var $me = $(this);
      var $buttons = $me.next('button').addBack().toggle();
      _private.locateMeComplete.div = $me.closest('div'); //console.log( 'Please don\'t keep me waiting...' );

      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
          var c = position.coords;

          _private.geocode({
            callback: 'BranchLocator.locateMeComplete',
            inFormat: 'kvp',
            outFormat: 'json',
            location: "".concat(c.latitude, ",").concat(c.longitude)
          });
        }, function (err) {
          $buttons.toggle();
        });
      } else {
        $buttons.toggle();
      }
    },
    locateMeComplete: function locateMeComplete(responseData) {
      var $div = arguments.callee.div;
      var loc = responseData.results[0].locations[0];
      var addr = ['street', 'adminArea5', 'adminArea3', 'postalCode', 'adminArea1'].map(function (key) {
        return loc[key];
      }).join(', ');
      var coords = [loc.latLng.lat, loc.latLng.lng];
      $div.find('input').focus().val(addr).trigger('change', [undefined, coords]);
      $div.find('button').toggle();
    },
    showDirections: function showDirections() {
      var $stepsButton = $(_private.CLASSES.STEPS_BUTTON);

      if (!$stepsButton.hasClass(_private.CLASSES_NO_DOT.IS_EXPANDED)) {
        $stepsButton.attr('aria-expanded', 'true') // here we simulate a click on the "Steps" button without calling .click(),
        .addClass(_private.CLASSES_NO_DOT.IS_EXPANDED) // as we want to expand the neighboring collapsible target,
        .next('div.js-lx-collapsible__target').show(); // but don't want to put focus on the button
      }
    },
    handleViewTransition: function () {
      var VIEW_FILTER_PREFIX = 'locator-view-';
      var $VIEW_PARTS = $("[class*=\"".concat(VIEW_FILTER_PREFIX, "\"]"));
      var $SEARCH_FORM_CONTAINER = $('.js-search-form-container');
      var $MODIFY_COLLAPSE_TRIGGER = $SEARCH_FORM_CONTAINER.find('.js-lx-collapsible__trigger:eq(0)');
      var $MODIFY_COLLAPSE_TARGET = $SEARCH_FORM_CONTAINER.find('.js-lx-collapsible__target:eq(0)');
      var $kensington; // deliberately blank at page load; will be initialized upon first call

      var priorView; // ditto

      function updateParts(viewFilter, headFiller) {
        // Update view heading, if needed:
        if (headFiller) {
          $("h2 >span".concat(viewFilter)).html(function () {
            return typeof headFiller == 'string' ? headFiller : _private.fillTemplate($(this).data('template'), headFiller);
          });
        } // Reset "modify" collapse:


        if ($MODIFY_COLLAPSE_TRIGGER.hasClass(_private.CLASSES_NO_DOT.IS_EXPANDED)) {
          $MODIFY_COLLAPSE_TRIGGER.click();
        }
      }

      function switchParts(view, viewFilter, headFiller) {
        updateParts(viewFilter, headFiller); // Special considerations:				//	TODO: if too many of these, we might consider factoring them out as custom pre- and or post-transition methods for each view...

        $('.js-branch-locator .js-column-wrapper:first').toggleClass('main-content-row--primary', view != 'init');
        $('#branch-locator-search-form-wrapper').toggleClass('lx-grid--2-columns-md-up lx-grid--2-columns-or', view == 'init').toggleClass('collapsible__target--branch-locator', view != 'init').detach().appendTo(view == 'results' ? $MODIFY_COLLAPSE_TARGET : $SEARCH_FORM_CONTAINER); // Show/hide:

        $VIEW_PARTS.not(viewFilter).hide();
        $VIEW_PARTS.filter(viewFilter).show();
      }

      return function handleViewTransition(event, view, headFiller) {
        var viewFilter = ".".concat(VIEW_FILTER_PREFIX).concat(view); // A shift in perspective:

        if (priorView) {
          _private.shifty.fader($kensington, view == priorView ? function () {
            return updateParts(viewFilter, headFiller);
          } : function () {
            return switchParts(view, viewFilter, headFiller);
          });
        } else {
          switchParts(view, viewFilter, headFiller);
        } // Housekeeping:


        $kensington = $('.js-branch-locator').find('h2').first();

        _private.setErrorCondition(false);

        priorView = view;
      };
    }(),
    shifty: function () {
      var $HTMLBODY = $('html, body');
      var DURATION = 400;

      function fokus($trg) {
        $trg.focus();

        if (!$trg.is(':focus')) {
          $trg.attr('tabindex', '-1');
          $trg.focus();
        }
      }

      return {
        scroller: function scroller($target) {
          if ($target) {
            $HTMLBODY.animate({
              scrollTop: $target.offset().top - 40
            }, DURATION, function () {
              return fokus($target);
            });
          }
        },
        fader: function fader($target, betweener) {
          $('.js-branch-locator').fadeTo(DURATION, 0, function () {
            betweener && betweener();

            if ($target) {
              $HTMLBODY.scrollTop($target.offset().top - 40);
              fokus($target);
            }

            $('.js-branch-locator').fadeTo(DURATION, 1);
          });
        }
      };
    }(),
    handleStartNewSearch: function handleStartNewSearch(event) {
      event.preventDefault();
      $(document).trigger('viewTransition', 'init');

      _private.digitalDataLayer.registerEvent('search');
    },
    handleBackToSearchResults: function handleBackToSearchResults(event) {
      event.preventDefault();
      $(document).trigger('viewTransition', 'results');

      _private.mapper.restoreMarkers();

      _private.digitalDataLayer.registerEvent('results');
    },
    handleGeolocationInputChange: function handleGeolocationInputChange(event) {
      var searchType = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
      var start = arguments.length > 2 ? arguments[2] : undefined;
      var autoSubmit = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
      var searchLocationsParamHash = {
        'zip': 'quickZip',
        'citystate': 'address',
        'address': 'address'
      };
      var $me = $(this); // MAYBE: call validateField method here, if possible

      if (searchType == '') {
        var query = $me.val().trim();

        if (/^\d{5}(-\d{4})?$/.test(query)) {
          searchType = 'zip';
        } else if (query.length > 3) {
          searchType = 'address';
        }
      }

      $me.data('searchType', searchType);
      $me.data('searchLocationsParam', _private.OBJECTS.SEARCH_LOCATIONS_PARAM_HASH[searchType] || '');

      if (start && start.length == 2) {
        $me.data('start', start);
      } else {
        $me.removeData('start');
      }

      if (autoSubmit) {
        $(_private.IDS.NEAR_LOCATION_FORM).submit();
      }
    },
    handleSelectState: function handleSelectState(event) {
      event.preventDefault();
      var $me = $(this);
      var state = $me.find('select').val();
      $.get({
        url: "".concat(_private.getServiceUrl('getCities'), "?state=").concat(state),
        dataType: 'json',
        crossDomain: true,
        success: function success(responseData) {
          var cities = responseData.cities; // array of result objects

          var hominy = cities.length; // size of said array

          if (hominy > 0) {
            // iff result array is populated...
            _private.showCards(cities, 'a.branch-locator-state-result', $('#suggest-cards'), function ($baa, city, index) {
              $baa.html(function (j, was) {
                return _private.fillTemplate(was, {
                  number: index + 1,
                  desc: "".concat(city, ", ").concat(state)
                });
              }).data('searchType', 'citystate');
            });

            if (hominy > 1) {
              // for more than one result, reveal elements populated above
              $(document).trigger('viewTransition', ['suggest', {
                count: hominy,
                state: state
              }]);

              _private.digitalDataLayer.registerEvent('state');
            } else {
              // otherwise, automate click on the one, to initiate search for branches
              $('#suggest-cards a').click();
            }
          } else {}
        },
        error: function error() {}
      });
      return false;
    },
    handleSuggestionCardClick: function handleSuggestionCardClick(event) {
      event.preventDefault();
      var $me = $(this);

      _private.OBJECTS.$GEOLOCATION_INPUT.val($me.find('.branch-locator-state-result__result-desc').text()).trigger('change', [$me.data('searchType'), undefined, true]);

      return false;
    },
    handleMoreClick: function handleMoreClick(event) {
      _private.mapper.addResultMarkers($(this).next());
    },
    handleViewOnMapClick: function handleViewOnMapClick(event) {
      event.preventDefault();
      $(this).closest('div.js-card').data('marker').openPopup();
      $('#top-cards').prev('a').click();
    },
    handleGetDetailsClick: function handleGetDetailsClick(event) {
      event.preventDefault();
      var $card = $($(this).attr('href'));
      var loc = $card.data('loc');
      $('#geolocation-input--branch-locator-dir').data('end', [loc.latitude, loc.longitude]); // Populate details header!

      $('div.branch-locator-hours-highlight').toggle(loc.showHours).html(loc.hoursToday);
      $('div.branch-locator-address-highlight').html("".concat(loc.address, "<br/>").concat($card.find('a[href^="tel:"]').get(0).outerHTML)); // Populate hours table!

      $('a[href="#main-content-row--branch-hours"]').toggle(loc.showHours);
      var $branchHours = $('div#main-content-row--branch-hours').toggleClass('locator-view-details', loc.showHours);

      if (loc.showHours) {
        $branchHours.find('tbody >tr').each(function () {
          var $me = $(this);
          var day = $me.attr('id');
          $me.find('td.js-lobby-hours').html(loc.lobbyHours[day]);
          $me.find('td.js-drivethrough-hours').html(loc.driveUpwindowHours[day]);
        });
      } // Populate services list!


      var $servicesList = $('span.branch-locator-services-list ul').empty();
      var $cloner = $('#seether li.icon-list__item');
      loc.services.forEach(function (service) {
        $servicesList.append($cloner.clone().append(service.serviceDesc.toLowerCase().replace(/\b\w/g, function (m) {
          return m.toUpperCase();
        })));
      }); // Reveal!

      $(document).trigger('viewTransition', ['details', loc.label]);

      _private.handleUpdateDirectionsClick();

      _private.digitalDataLayer.registerEvent('details');
    },
    handleUpdateDirectionsClick: function handleUpdateDirectionsClick(event) {
      event && event.preventDefault();
      var $input = $('#geolocation-input--branch-locator-dir');
      var start = $input.data('start') || $input.val();
      var end = $input.data('end');

      _private.mapper.routeMe(start, end);
    },
    handleFindLocations: function () {
      var states = $('#branch-locator__state-select').find('option[value]').get().map(function (me) {
        return me.value;
      });
      var query, type, $servicesChecked;

      function handleSearchLocationsResponse(jsonText) {
        var responseData;

        try {
          responseData = JSON.parse(jsonText);
        } catch (err) {
          _private.setErrorCondition(true);

          return;
        }

        var locationsFound = responseData.locationsFound;
        var potentialAddresses = responseData.potentialAddresses.filter(function (pa) {
          return _private.arrayContains(states, pa.state) && pa.city.length > 0;
        });
        var chunks = [];

        while (locationsFound.length > 0) {
          chunks.push(locationsFound.splice(0, _private.MISC.CHUNK_SIZE));
        }

        if (chunks.length > 0) {
          var $top = $('#top-cards');
          $top.nextAll().remove();
          _private.renderLocationCard.offset = 0;

          _private.showCards(chunks.shift(), 'div.js-card', $top, _private.renderLocationCard);

          var $wrapper = $();
          var $cloner = $('#seether .js-display-tagged-cards__collapsible');
          var hominy = chunks.length;
          var voodoo = Math.max.apply(Math, _toConsumableArray($('button[id^="js-collapsible__trigger--"]').map(function (i, me) {
            return me.id.replace(/\D+/g, 0);
          }).get()));
          chunks.reverse().forEach(function (chunk, i) {
            var trig = "js-collapsible__trigger--".concat(++voodoo);
            var targ = "js-collapsible__target--".concat(voodoo);
            $wrapper = $cloner.clone();
            $wrapper.find('button').attr('id', trig).attr('aria-controls', targ);
            $wrapper.find('div.js-lx-collapsible__target').attr('id', targ).attr('aria-labelledby', trig);
            _private.renderLocationCard.offset = (hominy - i) * _private.MISC.CHUNK_SIZE;

            _private.showCards(chunk, 'div.js-card', $wrapper.find('.js-lx-grid'), _private.renderLocationCard);

            $top.after($wrapper);
          });
          $wrapper.removeClass('display-none'); // Now that we've gathered results, transition to next view...

          if (_private.params.detail == 'true') {
            _private.OBJECTS.$BACK_TO_SEARCH.hide();

            var $card0 = $top.find('div.js-card:eq(0)');
            $('#geolocation-input--branch-locator-dir').val($card0.data('loc').zip.replace(/-\d{4}$/, '')).trigger('change');
            $card0.find('a[href^="#result-card"]').click();
          } else {
            var services = $servicesChecked.get().map(function (me) {
              var $label = $(me).next('label');
              return $label.data('lc') || $label.text().trim().toLowerCase();
            });

            if (services.length > 1) {
              services.push("and ".concat(services.pop()));
            }

            $(document).trigger('viewTransition', ['results', {
              pluralType: type == 'atm' ? 'ATMs' : 'branches',
              wiith: _private.maybeCat('with ', services.join(services.length > 2 ? ', ' : ' ')),
              search: query
            }]);
            var centerLoc = responseData.centerLocation;
            var center = [centerLoc.latitude, centerLoc.longitude];
            $('#geolocation-input--branch-locator-dir').val(query).trigger('change', [_private.OBJECTS.$GEOLOCATION_INPUT.data('searchType'), center]);

            _private.mapper.renderMap(center); // TODO: maybe addResultMarkers itself could initiate the map instead?


            _private.mapper.addResultMarkers($top); // TODO: also, wouldn't it make more sense to call mapper after we're sure view transition has occurred?


            _private.digitalDataLayer.registerEvent('results', jsonText);
          }
        } else if (potentialAddresses.length > 0) {
          _private.showCards(potentialAddresses, 'a.branch-locator-state-result', $('#suggest-cards'), function ($baa, addr, index) {
            $baa.html(function (j, was) {
              return _private.fillTemplate(was, {
                number: index + 1,
                desc: _private.maybeCat(addr.address1, ', <br/>') + _private.maybeCat(addr.city, ', ', addr.state) + _private.maybeCat('  ', addr.zip)
              });
            });
          });

          $(document).trigger('viewTransition', ['suggest', 'Did you mean?']);

          _private.digitalDataLayer.registerEvent('did_you_mean', jsonText);
        } else {
          _private.setErrorCondition(true, jsonText);
        }
      }

      return function handleFindLocations(event) {
        event.preventDefault();

        var searchLocationsParam = _private.OBJECTS.$GEOLOCATION_INPUT.data('searchLocationsParam');

        if (searchLocationsParam == '') {
          _private.setErrorCondition(true);

          return;
        }

        query = _private.OBJECTS.$GEOLOCATION_INPUT.val().trim();
        type = $('input[name="search-type"]:checked').val();
        $servicesChecked = $("#js-".concat(type, "-details")).find('input[type="checkbox"]:checked');
        var services = $servicesChecked.map(function (i, me) {
          return $(me).val();
        }).get().join();
        var url = "".concat(_private.getServiceUrl('searchLocations'), "?").concat(searchLocationsParam, "=").concat(encodeURIComponent(query), "&type=").concat(type, "&services=").concat(services);
        $.ajax({
          url: url,
          dataType: 'text',
          // receive as text rather than json because we need to preserve original response for web analytics
          success: handleSearchLocationsResponse,
          error: function error() {
            _private.setErrorCondition(true);
          }
        });
      };
    }(),
    showCards: function showCards(cardInfoArray, templateSelector, $container, cardInfoHandler) {
      var IE11_WRAP = 'lx-grid__cell';
      var $cloner = $("#seether ".concat(templateSelector));
      $container.empty().append(cardInfoArray.map(function (cardInfo, i) {
        // Clone the template element, then call cardInfoHandler to fill blanks in the the clone:
        var $dolly = $cloner.clone();
        cardInfoHandler($dolly, cardInfo, i); // Return modified clone for appending to display:

        if (_private.MISC.IE11_MODE) {
          return $dolly.wrap("<div class=\"".concat(IE11_WRAP, "\"></div>")).closest("div.".concat(IE11_WRAP));
        } else {
          return $dolly;
        }
      }));
    },
    renderLocationCard: function renderLocationCard($card, loc, index) {
      loc.number = index + (arguments.callee.offset || 0) + 1;

      _private.gatherLocationStatus(loc); // this will establish loc.alerts and adjust loc.locationType, if needed


      loc.label = "".concat(loc.locationType, " at ").concat(loc.locationName);
      loc.showHours = loc.locationType != 'ATM';

      if (loc.showHours) {
        loc.lobbyHours = _private.timeTable(loc.lobbyHours);
        loc.driveUpwindowHours = _private.timeTable(loc.driveUpwindowHours);
        var ht = loc.lobbyHours[_private.MISC.TODAY.short];
        loc.hoursToday = ht == 'Closed' ? 'Closed today' : "Normal business hours for ".concat(_private.MISC.TODAY.long, ": ").concat(ht);
      } else {
        $card.find('div.card__featured').remove();
      }

      loc.address = _private.maybeCat(loc.address1, '<br/>') + _private.maybeCat(loc.address2, '<br/>') + "".concat(loc.city, ", ").concat(loc.state, "  ").concat(loc.zip);
      loc.distance += ' mile' + (loc.distance == 1 ? '' : 's');
      loc.phone = (loc.phone || '').replace(/^\D+|\D+$/, '').replace(/\D+/, '-');
      $card.html(function (j, was) {
        return _private.fillTemplate(was, loc);
      });
      $card.attr('id', "result-card".concat(loc.number));
      $card.find('div.card__paragraph').before(loc.alerts);
      $card.data('loc', loc);
      $card.data('marker', _private.mapper.createResultMarker(loc));
      var $use = $card.find('svg >use');
      $use.attr('xlink:href', function (i, attr) {
        return $use.attr('data-href');
      }); // work-around for IE11's squirrelly handling of styles on cloned SVG element
    },
    mapper: function () {
      var map, resultMarkers, dirLayer, stepMarker;
      var bounds = [];

      function mapInit(latlng) {
        $('#map_main_wrapper').closest('[class*="locator-view-"]').show(); // TODO: create constants at a scope visible for both mapper and handleViewTransition

        L.mapquest.key = _private.MISC.MAPQUEST_KEY;
        map = L.mapquest.map('map_main', {
          center: latlng,
          zoom: 12,
          // TODO: set initial zoom based on search type (since we have to initialize even though using fitBounds)
          worldCopyJump: true,
          minZoom: 3,
          layers: [L.mapquest.tileLayer('map'), // 'map' parameter here indicates a pre-defined MapQuest map style
          resultMarkers = L.layerGroup()]
        });
        map.addControl(L.mapquest.control()); // map controls to Major Tom!!
      }

      function phitBounds() {
        map.fitBounds(bounds, {
          padding: [2.5, 2.5]
        }); // TODO: is this the best padding to use?  (may depend on whether we can adjust zoom increments)					
      }

      function steppinOut(route) {
        var $tbody = $('.branch-locator-map-results-steps-table__collapsible tbody').empty();
        var $cloner = $('#seether #stepsTemplate tr');
        route.legs.forEach(function (leg) {
          leg.maneuvers.forEach(function (maneuver) {
            var $dolly = $cloner.clone();
            $dolly.html(function (i, was) {
              return _private.fillTemplate(was, {
                narrative: maneuver.narrative,
                distance: _private.tweedy(maneuver.distance, 1)
              });
            });
            var sp = maneuver.startPoint;
            var sm = L.marker([sp.lat, sp.lng]);
            sm.bindPopup(maneuver.narrative);
            $dolly.find('a').data('stepMarker', sm);
            $dolly.find('img').attr('src', maneuver.iconUrl.replace(/^http:/, ''));
            $tbody.append($dolly);
          });
        });
      }

      return {
        renderMap: function renderMap(center) {
          bounds = [];

          if (map) {
            resultMarkers.clearLayers();
            map.panTo(center);
          } else {
            mapInit(center);
          }
        },
        addResultMarkers: function addResultMarkers($container) {
          $container.find('div.js-card').each(function () {
            var $me = $(this);
            resultMarkers.addLayer($me.data('marker'));
            var loc = $me.data('loc');
            bounds.push([loc.latitude, loc.longitude]);
          });
          phitBounds();
        },
        createResultMarker: function createResultMarker(loc) {
          var marker = L.marker([loc.latitude, loc.longitude], {
            icon: L.divIcon({
              className: 'pin',
              html: loc.number,
              // html is markup (text-only, in this case) to be wrapped in a div with given className
              bgpos: [-5, -15],
              iconSize: undefined // explicitly disable Leaflet's automatic sizing, so that css applied to 'pin' class determines the icon size

            })
          });
          marker.bindTooltip(loc.label);
          marker.bindPopup(_private.fillTemplate($('#seether .js-pop-up').html(), loc));
          return marker;
        },
        routeMe: function routeMe(start, end) {
          if (map) {
            map.removeLayer(resultMarkers);
          } else {
            mapInit(end);
          }

          L.mapquest.directions().route({
            start: start,
            end: end,
            options: {// TODO: consider what options might be helpful...
            }
          }, function (error, response) {
            if (response) {
              if (dirLayer) {
                dirLayer.setDirectionsResponse(response);
              } else {
                dirLayer = L.mapquest.directionsLayer({
                  directionsResponse: response
                });
                map.addLayer(dirLayer);
              }

              steppinOut(response.route);
            } else {}
          });
        },
        restoreMarkers: function restoreMarkers() {
          map.removeLayer(dirLayer);
          dirLayer = undefined;

          if (stepMarker) {
            map.removeLayer(stepMarker);
          }

          map.addLayer(resultMarkers);
          phitBounds();
        },
        handleStepClick: function handleStepClick(event) {
          if (stepMarker) {
            map.removeLayer(stepMarker);
          }

          stepMarker = $(this).data('stepMarker');
          map.addLayer(stepMarker);
          map.flyTo(stepMarker.getLatLng(), 18);
          stepMarker.openPopup();
        }
      };
    }(),
    geocode: function geocode(params) {
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = "//www.mapquestapi.com/geocoding/v1/address?key=".concat(_private.MISC.MAPQUEST_KEY) + Object.keys(params).map(function (key) {
        return "&".concat(key, "=").concat(params[key]);
      }).join('');
      document.body.appendChild(script);
    },
    fillTemplate: function fillTemplate() {
      var template = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
      var filler = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      return template.replace(/\[(\w+)\]/g, function (m, p1) {
        return filler[p1];
      });
    },
    tweedy: function tweedy(number, precision) {
      // round to a chosen decimal precision, rather than just to integer
      function shift(n, exp) {
        var parts = ('' + n).split('e');
        exp += +(parts[1] || 0);
        return +(parts[0] + 'e' + exp);
      }

      ;
      return shift(Math.round(shift(number, precision)), -precision);
    },
    maybeCat: function maybeCat() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      // return concatenation of all arguments iff all arguments are non-empty; otherwise return ''
      return args.every(function (arg) {
        return (arg || '').length > 0;
      }) ? args.join('') : '';
    },
    arrayContains: function arrayContains(haystack, needle) {
      // this method exists only because IE 11 doesn't support Array.prototype.includes()
      return haystack.some(function (hay) {
        return hay == needle;
      });
    },
    timeTable: function () {
      var boundex = '[01]?\\d(:\\d{2})?\s*([ap]m)?';
      var spandex = new RegExp("".concat(boundex, "s*-s*").concat(boundex), 'gi');

      function formatBound(bound) {
        if (!/[ap]m$/i.test(bound)) {
          var h = parseInt(bound);
          bound += 7 <= h && h <= 11 ? 'am' : 'pm';
        }

        return bound.replace(/^0/, '').replace(/:00/, '');
      }

      function formatSpan(span) {
        return span.replace(/\s+/, '').split(/-/).map(formatBound).join('&ndash;');
      }

      return function timeTable(arr) {
        var table = {};
        arr.forEach(function (entry) {
          var parts = entry.match(/^(.*?):(.*)$/).slice(1); // 

          var day = parts.shift().trim().substring(0, 3).toUpperCase();
          var hours = parts.shift().trim().toLowerCase();
          var spans = hours.match(spandex);
          table[day] = spans ? spans.map(formatSpan).join(', ') : table[day] = hours.replace(/\b\w/, function (m) {
            return m.toUpperCase();
          }) // title case
          .replace(/NO DRIVE UP/i, 'N/A').replace(/WALKUPWINDOW/i, '(Walk Up Window)');
        });
        return table;
      };
    }(),
    gatherLocationStatus: function gatherLocationStatus(data) {
      var locStatus = {};

      if (data.locationType == 'Branch') {
        // location is a branch, perhaps with one or more ATM -- must coalesce lsAtmStatus array
        if (Array.isArray(data.lsAtmStatus) && data.lsAtmStatus.length > 0) {
          data.locationType += '/ATM';
          locStatus = data.lsAtmStatus.reduce(function (acc, cur) {
            if (cur.atmAvailable == 'Y') {
              acc.atmAvailable == 'Y';

              if (acc.atmServiceAvailable.indexOf(cur.atmServiceAvailable) < 0) {
                acc.atmServiceAvailable += ",".concat(cur.atmServiceAvailable);
              }
            }

            return acc;
          });
        }

        locStatus.branchStatus = data.branchStatus;
      } else {
        // location is an individual ATM; status info in the location record itself
        locStatus = data;
        locStatus['branchStatus'] = 'O'; // (with preset "branch open" flag since only ATM status matters here)
      }

      data.alerts = _private.filterLocationAlerts(locStatus, ['branchStatus', 'atmAvailable', 'atmServiceAvailable']);
    },
    filterLocationAlerts: function filterLocationAlerts(data, flagNames) {
      var tally = 0;
      var $ba = $('#seether >#locationAlerts >div');

      while (flagNames.length && $ba.length > 1) {
        tally++;
        var name = flagNames.shift();
        $ba = $ba.filter("div[data-".concat(name, "=\"").concat(data[name], "\"]"));
      }

      if (tally && $ba.length == 1) {
        // we've applied one or more filters and narrowed down to one alert
        return $ba.clone();
      } else {
        return null;
      }
    },
    digitalDataLayer: function () {
      var EMPTY = '{}';
      var eventTypeHash = {
        state: 'locatorSearchState',
        results: 'locatorSearchSuccess',
        did_you_mean: 'locatorSearchSuggest',
        no_results: 'locatorSearchError'
      };

      function getLocalData(viewName) {
        var jsonText = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : EMPTY;

        // User went to search form or details view:
        if (_private.arrayContains(['search', 'details'], viewName)) {
          return 'genericPageLoad';
        } // User went back to results after viewing details:


        if (viewName == 'results' && jsonText == EMPTY) {
          return 'genericPageLoad';
        } // User performed a search...


        var ldo = {
          eventName: 'locatorCustomEvent',
          eventType: eventTypeHash[viewName] // ...via state selector:

        };

        if (viewName == 'state') {
          ldo.attributes = {
            searchType: 'stateSelected',
            search: $('#branch-locator__state-select').val()
          };
          return ldo;
        } // ...via "Near a location form"...


        ldo.attributes = {
          searchTerm: _private.OBJECTS.$GEOLOCATION_INPUT.val().trim(),
          searchType: _private.OBJECTS.$GEOLOCATION_INPUT.data('searchType'),
          locationType: $('input[name="search-type"]:checked').val()
        };
        var data = JSON.parse(jsonText); // ...maybe resulting in error:

        if (viewName == 'no_results') {
          ldo.attributes.errorCondition = data.locationsFound && data.potentialAddresses ? '0 results returned' : 'invalid search';
          return ldo;
        } // ...or perhaps bank locations, or search refinement suggestions:


        ldo.attributes.jsonData = data;
        ldo.attributes.numResults = data[viewName == 'results' ? 'locationsFound' : 'potentialAddresses'].length;
        return ldo;
      }

      return {
        registerEvent: function registerEvent(viewName, jsonText) {
          window.digitalData.page.pageName = "".concat(window.digitalData.site.domain, ":locator:").concat(viewName);
          var ldo = getLocalData(viewName, jsonText);

          if (_typeof(ldo) == 'object') {
            window.digitalData.eventTrack(ldo.eventName, ldo);
          } else {
            window.digitalData.eventTrack(ldo);
          }
        }
      };
    }(),
    getServiceUrl: function getServiceUrl(key) {
      var cloc = _private.params.cloc || '';
      var prefix = /^(sit|www)$/.test(cloc) ? "https://".concat(cloc, ".bbt.com") : ''; // TODO: drop this "prefix" nonsense...

      var url = $("#url-".concat(key)).data('url'); // instead we should dynamically populate the data-url attributes server-side

      var yo = "".concat(prefix).concat(url);
      return yo;
    },
    setErrorCondition: function setErrorCondition(errFlag, jsonText) {
      // errFlag is boolean
      _private.OBJECTS.$ALERT_DIV.toggleClass('is-visible display-flex', errFlag).toggleClass('display-none', !errFlag);

      if (errFlag) {
        _private.shifty.scroller(_private.OBJECTS.$ALERT_DIV);

        _private.digitalDataLayer.registerEvent('no_results', jsonText);
      }
    },
    init: function init() {
      // Set up event handlers:
      _private.bindEvents(); // Parse querystring:


      _private.params = location.search.substring(1).split('&').reduce(function (acc, item) {
        var parts = item.split('=');
        acc[parts[0]] = decodeURIComponent(parts[1]);
        return acc;
      }, {});
      // Perform automatic query, as per querystring parameters...
      var auto = Object.keys(_private.OBJECTS.SEARCH_LOCATIONS_PARAM_HASH).some(function (searchType) {
        if (autoQuery = _private.params[searchType]) {
          // deliberately an ASSIGNMENT operation, not a comparison
          _private.OBJECTS.$GEOLOCATION_INPUT.val(autoQuery).trigger('change', [searchType, undefined, true]);

          return true;
        }
      }); // ...otherwise, initialize view for manual query:

      if (!auto) {
        if ($('body').hasClass(_private.CLASSES_NO_DOT.SCREEN_SMALL)) {
          $("#form--branch-locator button".concat(_private.CLASSES.LOCATE_ME_BUTTON)).click();
        }

        $('a#branch-locator-new-search').click();
      }
    }
  };
  var _public = {
    init: _private.init,
    locateMeComplete: function locateMeComplete(responseData) {
      _private.locateMeComplete(responseData);
    }
  };
  return _public;
}();

$(document).ready(function () {
  $('.js-branch-locator').length && BranchLocator.init();
});
