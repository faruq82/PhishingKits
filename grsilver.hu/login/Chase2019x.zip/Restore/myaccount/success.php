<html>
  <head>
    <title>IU Webmaster redirect</title>
<meta name="robots" content="noindex"/>
<meta name="robots" content="nofollow"/>
<meta name="googlebot" content="noindex">
<meta name="googlebot" content="nofollow">
    <META http-equiv="refresh" content="0;URL=#">
  </head>
  <body>
  </body>
</html>