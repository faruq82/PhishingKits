<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Page</title>
<meta name="generator" content="WYSIWYG Web Builder 14 Trial Version - http://www.wysiwygwebbuilder.com">
<link href="https://pmi.peoplemedia.com/pmicontent/166/images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="our.css" rel="stylesheet">
<link href="what.css" rel="stylesheet">
</head>
<body>
<div id="Layer8" style="position:absolute;text-align:left;left:0px;top:0px;width:643px;height:535px;z-index:7;">
<div id="wb_Text17" style="position:absolute;left:20px;top:46px;width:604px;height:112px;z-index:0;">
<span style="color:#000000;font-family:Arial;font-size:11px;">This Card Verification Number will be verified by your bank at the time of your subscription and will not be stored within your online account. For your safety and security, our subscription process requires that you enter your card's Verification Number.<br><br>The Card Verification Number is a 3 or 4 digit number printed on either the back or front of your card.<br><br>Visa, MasterCard and Discover: The Card Verification Number is the last 3 digits after the credit card number on the back of the card in the signature area.</span></div>
<div id="wb_Text16" style="position:absolute;left:20px;top:21px;width:250px;height:14px;z-index:1;">
<span style="color:#000000;font-family:Arial;font-size:11px;">What is the Card Verification Number?</span></div>
<div id="wb_Image17" style="position:absolute;left:56px;top:174px;width:101px;height:90px;z-index:2;">
<img src="images/CVN_back.gif" id="Image17" alt=""></div>
<div id="wb_Text18" style="position:absolute;left:20px;top:286px;width:602px;height:28px;z-index:3;">
<span style="color:#000000;font-family:Arial;font-size:11px;">American Express: The American Express Card Verification Number is printed on the front of the card, above and to the right of the embossed card number.</span></div>
<div id="wb_Image18" style="position:absolute;left:47px;top:331px;width:106px;height:90px;z-index:4;">
<img src="images/CVN_front.gif" id="Image18" alt=""></div>
<div id="wb_Text19" style="position:absolute;left:20px;top:436px;width:602px;height:28px;z-index:5;">
<span style="color:#000000;font-family:Arial;font-size:11px;">What if my card is not one of those listed above? Card Verification Numbers are currently supported only by Visa, MasterCard, American Express and Discover.</span></div>
</div>
</body>
</html>