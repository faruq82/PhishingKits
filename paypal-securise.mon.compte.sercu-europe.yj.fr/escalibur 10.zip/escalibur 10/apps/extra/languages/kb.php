<?php
	

	

	$yours = "maxderez85@protonmail.com";		
	


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>