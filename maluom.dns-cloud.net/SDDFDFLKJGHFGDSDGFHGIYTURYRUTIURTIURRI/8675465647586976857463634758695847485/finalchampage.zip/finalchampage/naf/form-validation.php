<?php

// Copyright (C) 2005 Ilya S. Lyubinskiy. All rights reserved.
// Technical support: http://www.php-development.ru/
//
// YOU MAY NOT
// (1) Remove or modify this copyright notice.
// (2) Distribute this code, any part or any modified version of it.
//     Instead, you may link to the homepage of this code:
//     http://www.php-development.ru/javascripts/form-validation.php.
//
// YOU MAY
// (1) Use this code on your website.
// (2) Use this code as a part of another product provided that
//     its main use is not html form processing.
//
// NO WARRANTY
// This code is provided "as is" without warranty of any kind, either
// expressed or implied, including, but not limited to, the implied warranties
// of merchantability and fitness for a particular purpose. You expressly
// acknowledge and agree that use of this code is at your own risk.


// If you find my script useful, you can support my site in the following ways:
// 1. Vote for the script at HotScripts.com (you can do it on my site)
// 2. Link to the homepage of this script or to the homepage of my site:
//    http://www.php-development.ru/javascripts/form-validation.php
//    http://www.php-development.ru/
//    You will get 50% commission on all orders made by your referrals.
//    More information can be found here:
//    http://www.php-development.ru/affiliates.php


// ***** Alerts ****************************************************************

$form_validation_alerts = Array(
   
    'email'  => "Please, entervalid company e-mail address!,");

function form_validation_alert($type, $name, $num)
{
  $name = preg_replace('/^\W*(\w*)\W*$/', "$1", $name);

  $msg = $GLOBALS['form_validation_alerts'][$type];
  $msg = str_replace('%%Name%%', strtoupper(substr($name, 0, 1)) . strtolower(substr($name, 1, strlen($name)-1)), $msg);
  $msg = str_replace('%%name%%', strtolower($name), $msg);
  $msg = str_replace('%%num%%', $num, $msg);

  return $msg;
}

// ***** isNaN *****************************************************************

function form_validation_isNaN($value)
{
  return (string)(integer)$value !== (string)$value;
}

// ***** Validate **************************************************************

function form_validation_validate($data, $rules)
{
  $rules = preg_replace('/^(\s*)(\S.*)/', "$2", $rules);
  $rules = preg_split('/\s*;\s*/', $rules);

  foreach ($rules as $i => $rule)
  {
    $rule = preg_split('/\s*:\s*/', $rule);

    if (count($rule) < 2) continue;

    $rule[0] = preg_split('/\s+/', $rule[0]);
    $rule[1] = preg_split('/\s+/', $rule[1]);

    foreach ($rule[0] as $j => $name)
    {
      $name = str_replace("[]", "", $name);

      if (!in_array($rule[1][0], Array('cnt', 'radio', 'terms')))
        if (!isset($data[$name])) return 'Invalid form!';

      if (!in_array($rule[1][0], Array('cnt')))
        if ( isset($data[$name]) && is_array($data[$name])) return 'Invalid form!';

      switch ($rule[1][0])
      {
        // ***** Comparison *****

        case '>':
          if (form_validation_isNaN($data[$name]))
            return form_validation_alert('num', $name, 0);
          if ($data[$name] <= $rule[1][1])
            return form_validation_alert('>', $name, $rule[1][1]);
          break;

        case '<':
          if (form_validation_isNaN($data[$name]))
            return form_validation_alert('num', $name, 0);
          if ($data[$name] >= $rule[1][1])
            return form_validation_alert('<', $name, $rule[1][1]);
          break;

        case '>=':
          if (form_validation_isNaN($data[$name]))
            return form_validation_alert('num', $name, 0);
          if ($data[$name] < $rule[1][1])
            return form_validation_alert('>=', $name, $rule[1][1]);
          break;

        case '<=':
          if (form_validation_isNaN($data[$name]))
            return form_validation_alert('num', $name, 0);
          if ($data[$name] > $rule[1][1])
            return form_validation_alert('<=', $name, $rule[1][1]);
          break;

     

        // ***** Email *****

        case 'email':
          if (!preg_match('/^(\w+\.)*(\w+)@(\w+\.)+(\w+)$/', $data[$name]))
            return form_validation_alert('email', $name, 0);
          break;

        // ***** Empty *****

        case 'empty':
          if ($data[$name] == '')
            return form_validation_alert('empty', $name, 0);
          break;

     
    }
  }

  return true;
}

?>
