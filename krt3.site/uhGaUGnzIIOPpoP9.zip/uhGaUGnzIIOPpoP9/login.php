<?php
    include('global.php');
    session_set_cookie_params(time() + (60 * 30));
    session_start();

	if (isset($_POST['username']) && isset($_POST['password']))
	{
		if ($_POST['username'] === LOGIN && md5($_POST['password']) === PASSWORD_MD5)
		{
			$_SESSION['id'] = md5(LOGIN.PASSWORD_MD5);
			header('Location: index.php');
			die();
		}
		else if ($_POST['username'] === GUEST_LOGIN && $_POST['password'] === GUEST_PASSWORD)
		{
			$_SESSION['id'] = md5(GUEST_LOGIN.GUEST_PASSWORD);
			header('Location: guest.php');
			die();
		}
	}
?>

<html>
    <body>
        <form method="post">
            <input type="text" name="username" />
            <input type="password" name="password" />
            <input type="submit"/>
        </form>
    </body>
</html>