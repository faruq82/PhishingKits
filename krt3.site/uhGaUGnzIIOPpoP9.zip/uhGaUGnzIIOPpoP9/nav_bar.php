<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css"/>

<title> KPOT 2.2 </title>
<meta charset="utf-8" />


<div class="logo-header">
	<div class="logo"></div>
	<a href="logout.php" onclick="return confirm('Are you sure?');" class="logout-link">
		<i class="fas fa-sign-out-alt" style="margin-right: 5px;"></i> Log Out
	</a>
</div>
<div class="sidebar">
	<div class="menu">
		<a href="index.php" class="menu-link <?php if ($type == 'index') echo 'menu-active'; ?>">Home Page</a>
		<a href="reports.php" class="menu-link <?php if ($type == 'reports') echo 'menu-active'; ?>">Reports List</a>
		<a href="passwords.php" class="menu-link <?php if ($type == 'passwords') echo 'menu-active'; ?>">Passwords</a>
		<a href="creditCards.php" class="menu-link <?php if ($type == 'creditCards') echo 'menu-active'; ?>">Credit Cards</a>
		<a href="settings.php?menu=config" class="menu-link <?php if ($type == 'settings') echo 'menu-active'; ?>">Settings</a>
	</div>
</div>
