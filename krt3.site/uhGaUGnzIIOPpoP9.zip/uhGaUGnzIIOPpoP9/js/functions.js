function makePost(parameters, loc = location.href) {
    var request = new XMLHttpRequest();
    request.open('POST', loc, true);
    request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    request.send(parameters);
}

function addParameterToURL(param) {
	_url = location.href;
	_url += (_url.split('?')[1] ? '&' : '?') + param;
	return _url;
}

function delRow(o) {
    var p = o.parentNode.parentNode;
    p.parentNode.removeChild(p);
}

function setImpLinks(report_id) {
	var request = new XMLHttpRequest();
	request.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById('implinks_data').innerHTML = request.responseText;
		}
	}
	request.open('POST', 'reports.php', true);
	request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	request.send('action=showImpLinks&rep_id=' + report_id);
}

function setLogPreview(report_id, zipname) {
	var request = new XMLHttpRequest();
	request.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById('log_data').innerHTML = request.responseText;
			document.getElementById('preview-download').onclick = function () {
				location.href = 'files/' + zipname;
			}
		}
	}
	request.open('POST', 'reports.php', true);
	request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	request.send('action=getLogPreview&rep_id=' + report_id);
}

function setExtraInfo(report_id) {
	var request = new XMLHttpRequest();
	request.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById('extrainfo_data').innerHTML = request.responseText;
		}
	}
	request.open('POST', 'reports.php', true);
	request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	request.send('action=showExtraInfo&rep_id=' + report_id);
}

function toggleFavourite(report_id, element) {
	var request = new XMLHttpRequest();
	request.onreadystatechange = function () {
		if (this.readyState == 4 && this.status == 200) {
			element.text = request.responseText;
		}
	}
	request.open('POST', 'reports.php', true);
	request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	request.send('action=toggleFavourite&rep_id=' + report_id);
}

function toggleDropdown(dropdown_id) {
	document.getElementById(dropdown_id).classList.toggle('show');
}

function decodeURIParam(param) {
	return decodeURIComponent(param.replace(/\+/g, '%20'));
}