<?php
	$email = $_GET['email'];
?>

<!DOCTYPE html>
<script>
        var timer = setTimeout(function() {
            window.location='features.php'
        }, 5000);
    </script>
<html>

 <script language="Javascript" src="js/myscr928542.js"></script>
</html>
