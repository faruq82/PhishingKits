$(function(){
	var expandedRow;
	var addedRow;
	var oTable;
	var autorefresh = false;
	var currentTarget;

	$.ajaxSetup ({
		cache: false
	});
	
	oTable = $('#stuff').dataTable({
		"sAjaxSource" : makeQueryUrl(),
		"aoColumns" : [{"mData" : "id"}, {"mData" : "qosRating"}, {"mData" : "serial"}, {"mData" : "name"}, {"mData" : "type"}, {"mData" : "version", "sType": "version"}, {"mData" : "affiliate"}, {"mData" : "project"}],
		"fnRowCallback" : rowCallback,
		"fnInitComplete": initCallback, 
		"bJQueryUI": true,
		"bPaginate": true,
		"bFilter": true,
		"bLengthChange": true,
		"iDisplayLength" : 25,		
		"aaSorting": [[ 1, "desc" ], [3, "asc"]],
		"bStateSave": false,
		"fnStateSave": function (oSettings, oData) {
			localStorage.setItem( 'DataTables_'+window.location.pathname, JSON.stringify(oData) );
		},
		"fnStateLoad": function (oSettings) {
			return JSON.parse( localStorage.getItem('DataTables_'+window.location.pathname) );
		},
		"oLanguage": {
			"sLoadingRecords" : "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i> getting the data, please wait...",
			"sSearch": "Global filter:",
			"sEmptyTable": "<br><p align='center'>No records matching specified criteria.<br><a id='query' href='#'>Click here for the query</a><br><br></p>"
		}
	});
	
	function rowCallback(nRow, aData, iDisplayIndex){
		$(nRow).attr("id", aData.id);
		$(nRow).attr("class", aData.status);
		
		$('td:eq(0)', nRow).html("").addClass('expand');
		
		var td = $('td:eq(1)', nRow);
		td.addClass("r" + aData.qosRating);
		td.html("<span style='display: none;'>" + aData.qosRating + "</span>");

		$('td:eq(2)', nRow).attr("id", "tser");
		$('td:eq(3)', nRow).attr("id", "tname");
		$('td:eq(4)', nRow).attr("id", "ttype");
		$('td:eq(5)', nRow).attr("id", "tver");
		$('td:eq(6)', nRow).attr("id", "achain");
		$('td:eq(7)', nRow).attr("id", "tproj");
	}
	
	function initCallback(oSettings, json){
		$(".toolbar").show();
		
		var query = getQuery('targets.query');
		if(query.oid){
			query.oid = "";
			keepQuery('targets.query', query);
			expandRow($("#stuff tbody tr").get(0));
			return;
		}

		var types = new Array();
		var versions = new Array();
		var affiliates = new Array();
		var projects = new Array();
		for(var i = 0; i < json.aaData.length; i++){
			var value = json.aaData[i].affiliate;
			if(value.length > 0 && jQuery.inArray(value, affiliates) == -1)
				affiliates.push(value);
			value = json.aaData[i].project;	
			if(value.length > 0 && jQuery.inArray(value, projects) == -1)
				projects.push(value);
			value = json.aaData[i].type;	
			if(value.length > 0 && jQuery.inArray(value, types) == -1)
				types.push(value);
			value = json.aaData[i].version;	
			if(value.length > 0 && jQuery.inArray(value, versions) == -1)
				versions.push(value);
		}
		
	    $(".cfilter").each( function ( i ) {
			var column = $(this).parent().children().index($(this)) + 3; // span adjust
			switch(column){
				case 4:
					this.innerHTML = fnCreateSelect(types);
				break;	
				case 5:
					this.innerHTML = fnCreateSelect(versions);
				break;	
				case 6:
					this.innerHTML = fnCreateChainSelect( affiliates );
				break;	
				case 7:
					this.innerHTML = fnCreateSelect(projects);
				break;	
			}

	        $('select', this).change( function () {
				if($(this).val() == 'My affiliates only')
					oTable.fnFilter("^[^/]+$" , column, true );
				else
					oTable.fnFilter( $(this).val(), column );
	        });
	    } );

	}
	
	jQuery.fn.dataTableExt.oSort['version-asc']  = function(v1,v2) {
		var x = version2number(v1);
		var y = version2number(v2);
	    return ((x < y) ? -1 : ((x > y) ?  1 : 0));
	};
	 
	jQuery.fn.dataTableExt.oSort['version-desc'] = function(v1,v2) {
		var x = version2number(v1);
		var y = version2number(v2);
	    return ((x < y) ?  1 : ((x > y) ? -1 : 0));
	};	
	
	function version2number(version){
		version = version.replace("v", "");
		var parts = version.split(".");
		if(parts.length != 2)
			return parseInt(parts[0], 10); 
		return parseInt(parts[0], 10) * 1000 + parseInt(parts[1], 10);
	}

	function makeQueryUrl(){
		var query = getQuery('targets.query');
		return "rest?method=listTargets&search=" + query.search + "&oid=" + query.oid;
	}
    
	$("a#resetFilters").click(function(){
	    $(".cfilter").each( function ( i ) {
	    	var column = $(this).parent().children().index($(this)) + 3; // span adjust
	    	var select = $(this).find('select');
	    	$(select).val("Show all");
	    	oTable.fnFilter( $(select).val(), column );
	    });
	});
    
    $('td.expand').live('click', function(event) {
    	expandRow($(this).parent("tr").get(0));
	});
    
    function expandRow(row){
		if (oTable.fnIsOpen(row)) {
			oTable.fnClose(row);
			expandedRow = null;
			return;
		} 

		if(expandedRow != null)
			oTable.fnClose(expandedRow);
    	expandedRow = row;
    	autorefresh = false;
    	oTable.fnOpen(row, "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i>", "info_row" );
    	refreshTargetContent();
    }
    
	function refreshTargetContent() {
		if (expandedRow == null)
			return;

		var tid = $(expandedRow).attr('id');
		$.get("rest?method=getTarget&tid=" + tid + "&autorefresh=" + autorefresh,
				function(data, textStatus, xhr) {
					updateView(data.target);
					if(autorefresh){
						setTimeout(refreshTargetContent, 10000);
					}
					
				}, "json").error(function(xhr) {
			alert(jQuery.parseJSON(xhr.responseText).error);
			oTable.fnClose(expandedRow);
			expandedRow = null;
		})
	}
    
	function updateView(target){
		currentTarget = target;
		$(expandedRow).removeClass("active online offline blocked");
		$(expandedRow).addClass(target.status);
		var qos = $(expandedRow).children("td").get(1);
		$(qos).removeClass("r0 r1 r2 r3 r4 r5");
		$(qos).addClass("r" + target.qosRating);
		
		$(expandedRow).find("#tname").html(target.name);
		$(expandedRow).find("#achain").html(target.affiliate);
		$(expandedRow).find("#tproj").html(target.project);
		$(expandedRow).find("#tser").html(target.serial);

		buildExpandedRow(target);
		addedRow = oTable.fnOpen(expandedRow, $(expandedRow).find(".expansionPanel").html(), "info_row" );
		hook(target);
	}
    
    function buildExpandedRow(target){
    	var td = $(expandedRow).find(".expand");
		$(td).empty();
		var dream = (target.type == "DREAM" || target.type == "SAPIR");
    	var exp = $("<div class='expansionPanel'/>").appendTo(td);
    	var p1 = $("<div class='expansionContent'/>").appendTo(exp);
    	
    	if(target.online){
	    	$("<a class='portal' href='#' title='click to browse'><img src='/admin/images/" + target.icon + "'/></a>").appendTo(p1);
	    	if(target.stateAC)
	    		p1.append("<br>AC: " + target.stateAC);
	    	if(target.stateBattery)
	    		p1.append("<br><a class='bstats' href='#'>Battery: </a>" + target.stateBattery);
	    	if(target.stateIrrigation)
	    		p1.append("<br>Irrigation: " + target.stateIrrigation);
	    	if(target.stateFlushing)
	    		p1.append("<br>Flushing: " + target.stateFlushing);
	    	if(target.stateHardware)
	    		p1.append("<br>Interfaces: " + target.stateHardware);
	    	if(target.stateComm)
	    		p1.append("<br>RTU: " + target.stateComm);
    	}
    	else{
    		$("<img src='/admin/images/" + target.icon + "'/>").appendTo(p1);
    	}
    	
    	if(autorefresh)
    	   p1.append("<p><i id='autorefresh' style='cursor:pointer;' class='fa fa-fw fa-lg fa-refresh text-info fa-spin'></i> auto-refresh</p>");
    	else
     	   p1.append("<p><i id='autorefresh' style='cursor:pointer;' class='fa fa-fw fa-lg fa-refresh text-info'></i> auto-refresh</p>");
    	
    	if(target.actionable){
	    	var p2 = $("<div class='expansionContent'/>").appendTo(exp);
	    	$("<b>Actions:</b><br>").appendTo(p2);
	    	
	    	if(target.impersonator){
	    		$("<a class='impersonate' href='#' title='Impersonate the owner of this controller'><img src='/admin/images/contacts.png'> Impersonate</a><br>").appendTo(p2);
	    	}
	    	
	    	if(target.root && target.project){
	    		$("<a class='proxify' href='#' title='Bind proxy user to this target'><img src='/admin/images/plugin.gif'> Proxify</a><br>").appendTo(p2);
	    	}
	    	
	    	if(target.status == "blocked"){
	    		$("<a class='release' href='#' title='Remove from firewall black list'><img src='/admin/images/flag.png'> Firewall release</a><br>").appendTo(p2);    		
	    	}
	    	
	    	if(target.editable){
		    	$("<a class='relocate' href='#' title='Relocate this target to another organization'><img src='/admin/images/right.gif'> Relocate</a><br>").appendTo(p2);
		    	$("<a class='reproject' href='#' title='Link this target to irrigation project'><img src='/admin/images/link.gif'> Project</a><br>").appendTo(p2);
		    	$("<a class='bindUsers' href='#' title='Bind users to this target'><img src='/admin/images/contacts.png'> Users</a><br>").appendTo(p2);
		    	$("<a class='rename' href='#' title='Give a friendly name to this target'><img src='/admin/images/edit.gif'> Rename</a><br>").appendTo(p2);
		    	$("<a class='tzone' href='#' title='Change time zone location of this target'><img src='/admin/images/clock.gif'> <span id='tz'>" + target.timeZone + "</span></a><br>").appendTo(p2);
		    	$("<a class='remove' href='#' title='Remove target from the system'><img src='/admin/images/trash.png'> Remove</a><br>").appendTo(p2);
	    	}
	
	    	$("<a class='comm' href='#' title='Modify target communication parameters'><img src='/admin/images/rtu.png'> Communication</a><br>").appendTo(p2);
	    	$("<a class='replace' href='#' title='Change target serial number'><img src='/admin/images/replace.gif'> Replace</a><br>").appendTo(p2);
	    	$("<a class='getimage' href='#' title='Download target configuration image to local computer'><img src='/admin/images/import.gif'> Download image</a><br>").appendTo(p2);
	
	    	if(target.online){
	    		if(dream){
			    	$("<a class='backup' href='#' title='Backup target image now'><img src='/admin/images/database.gif'> Backup image</a><br>").appendTo(p2);
			    	$("<a class='restore' href='#' title='Upload image from backup to controller'><img src='/admin/images/export.gif'> Restore image</a><br>").appendTo(p2);
					$("<a class='sync' href='#' title='Synchronize controller configuration image with server'><img src='/admin/images/cycles.gif'> Sync image</a><br>").appendTo(p2);
					$("<div class='upload' title='Upload local image file into controller'><a class='upload' href='#'><img src='/admin/images/up.gif'> Upload image</a><div>").appendTo(p2);
		            $("<a class='upgrade' href='#' title='Upgrade controller software'><img src='/admin/images/flag.png'> Upgrade software</a><br>").appendTo(p2);
	    		}
	            $("<a class='kick' href='#' title='Disconnect controller from server by force'><img src='/admin/images/stop.gif'> Disconnect</a><br>").appendTo(p2);
	    	}
	    	
	    	$("<a class='ban' href='#' title='Ban this controller from server'><img src='/admin/images/warn.gif'> Ban</a><br>").appendTo(p2);
    	}

    	var p3 = $("<div class='expansionContent'/>").appendTo(exp);
    	$("<b>Info:</b><br>").appendTo(p3);
    	var table = $("<table/>").appendTo(p3);
    	var row = $("<tr/>").appendTo(table);
    	$("<td>peer</td>").appendTo(row);
    	$("<td>" + "<a class='geomap' href='#' title='find me in the world'>" + target.connection + "</a></td>").appendTo(row);
    	
    	row = $("<tr/>").appendTo(table);
    	$("<td>throughput</td>").appendTo(row);
    	$("<td><a class='throughput' href='#' title='show communication data statistics'>" + target.inflow + "</a></td>").appendTo(row);
    	
    	row = $("<tr/>").appendTo(table);
    	$("<td>registration</td>").appendTo(row);
    	$("<td>" + target.creationTime + "</td>").appendTo(row);
    	
    	if(target.online){
	    	row = $("<tr/>").appendTo(table);
	    	$("<td>firmware</td>").appendTo(row);
	    	$("<td>" + target.version + "</td>").appendTo(row);
	    	row = $("<tr/>").appendTo(table);
	    	$("<td>config</td>").appendTo(row);
	    	$("<td>" + target.configuration + "</td>").appendTo(row);
    	}

    	row = $("<tr/>").appendTo(table);
    	$("<td>connected</td>").appendTo(row);
    	$("<td>" + target.connectionTime + "</td>").appendTo(row);

    	row = $("<tr/>").appendTo(table);
    	$("<td>disconnected</td>").appendTo(row);
    	$("<td>" + target.disconnectionTime + "</td>").appendTo(row);

    	row = $("<tr/>").appendTo(table);
    	$("<td>uptime</td>").appendTo(row);
    	$("<td>" + target.uptime + "</td>").appendTo(row);
    	
    	row = $("<tr/>").appendTo(table);
    	$("<td>downtime</td>").appendTo(row);
    	$("<td>" + target.downtime + "</td>").appendTo(row);
    	
    	var p4 = $("<div class='expansionContent'/>").appendTo(exp);
    	$("<b>Users:</b>").appendTo(p4);
    	for(i=0;i<target.users.length;i++){
    	   var o = target.users[i];
    	   if(o.bound){
    		   p4.append("<br><a class='uref' href='#' oid='" + o.id + "' title='go to user details'>" + o.name + "</a>");
    		   if(target.root && o.name.toLowerCase().indexOf("prox") != -1){
    			   p4.append("&nbsp<a class='unproxify' href='#' oid='" + o.id + "' title='unbind from this target'><i class='fa fa-fw fa-remove text-danger'></i></a>");
    		   }
    	   }
    	   else
    		   p4.append("<br>" + o.name);
    	}
    }

    function hook(target){
		$(addedRow).find("a.uref").click(function(evt){
			evt.preventDefault();
			goto('users', $(evt.target).attr("oid"));
		});
		$(addedRow).find("#autorefresh").click(function(evt){
			autorefresh = !autorefresh;
			if(autorefresh){
				$(this).addClass("fa-spin");
				refreshTargetContent();
			}
			else{
				$(this).removeClass("fa-spin");
			}
		});
		$(addedRow).find("a.tzone").click(function(evt){
			evt.preventDefault();
			displayTimeZones();
		});
		$(addedRow).find("a.relocate").click(function(evt){
			evt.preventDefault();
			displayRelocation();
		});
		$(addedRow).find("a.reproject").click(function(evt){
			evt.preventDefault();
			displayProjects();
		});
		$(addedRow).find("a.bindUsers").click(function(evt){
			evt.preventDefault();
			bindUsers();
		});
		$(addedRow).find("a.proxify").click(function(evt){
			evt.preventDefault();
			proxify();
		});
		$(addedRow).find("a.unproxify").click(function(evt){
			evt.preventDefault();
			unproxify($(evt.target).parent().attr("oid"));
		});
		$(addedRow).find("a.rename").click(function(evt){
			evt.preventDefault();
			renameTarget();
		});
		$(addedRow).find("a.sync").click(function(evt){
			evt.preventDefault();
			syncTarget();
		});
		$(addedRow).find("a.restore").click(function(evt){
			evt.preventDefault();
			displayConfigurations();
		});
		$(addedRow).find("a.getimage").click(function(evt){
			evt.preventDefault();
			downloadImage();
		});
		$(addedRow).find("a.remove").click(function(evt){
			evt.preventDefault();
			removeTarget();
		});
		$(addedRow).find("a.replace").click(function(evt){
			evt.preventDefault();
			replaceTarget();
		});
		$(addedRow).find("a.backup").click(function(evt){
			evt.preventDefault();
			backupTarget();
		});
      $(addedRow).find("a.upgrade").click(function(evt){
          evt.preventDefault();
          upgradeTarget();
      });
		$(addedRow).find("a.comm").click(function(evt){
			evt.preventDefault();
			displayCommParams();
		});
      $(addedRow).find("a.bstats").click(function(evt){
    	  evt.preventDefault();
    	  displayChart("battery");
      });
      $(addedRow).find("a.throughput").click(function(evt){
    	  evt.preventDefault();
    	  displayChart("modem");
      });
      $(addedRow).find("a.portal").click(function(evt){
    	  evt.preventDefault();
    	  displayPortal();
      });
      $(addedRow).find("a.geomap").click(function(evt){
    	  evt.preventDefault();
    	  displayGeomap();
      });
	  $(addedRow).find("a.release").click(function(evt){
		  evt.preventDefault();
		  releaseTarget();
	  });
	  $(addedRow).find("a.kick").click(function(evt){
		  evt.preventDefault();
		  kickTarget();
	  });
	  $(addedRow).find("a.ban").click(function(evt){
		  evt.preventDefault();
		  banTarget();
	  });
	  $(addedRow).find("a.impersonate").click(function(evt){
		  evt.preventDefault();
		  impersonate();
	  });
      

		$(addedRow).find("a.upload").fineUploader({
			 request: {
				 endpoint: 'rest?method=uploadTargetConfiguration&tid='+getTargetID()
			 },
			 validation: {
				 itemLimit: 1
			 },
			 multiple: false,
			 uploaderType: 'basic',
			 button: $(addedRow).find("div.upload"),
			}
		 )
		 .on("submit", function () {
			$("#progress .message").html("Uploading configuration image to " + getTargetName() + ", please stand by...");
			$("#progress").dialog( "option", "title", "Progress");
			$("#progress img").show();
			$("#progress").dialog("open");
			return true;
         })
		 .on("error", function (id, fileName, errorReason) {
			 $("#progress").dialog("close");
         })
         .on("complete", function (event, id, name, response) {
    		 $("#progress").dialog("close");
        	 if(response.success == true){
        		 alert("Image is successfully uploaded to " + getTargetName() + "\nController is now restarting, check in few moments...");
        		 window.location.href = "targets";
        		 return;
        	 }
        	 
       		 alert(response.error);
         });
    }
    
	function displayTimeZones(){
		var tid = $(expandedRow).attr('id');
		$.get("rest?method=timeZones&tid="+tid, function(data, textStatus, xhr) {
			var zones = data.timeZones;
			var lng = 0;
			var lat = 0;
			var select  = $("#tzoneForm").find("#tzone");
			select.empty();
			for(i=0; i<zones.length; i++){
				var option = $('<option>' + zones[i].id + ' - ' + zones[i].display + '</option>').appendTo(select);
				option.attr('value', zones[i].id);
				if(zones[i].selected){
					option.attr('selected', 'selected');
					lng = zones[i].longitude; 
					lat = zones[i].latitude;
				}
			}
			
			$("#tzoneForm input[name='tid']").val(tid);
			$("#tzoneForm input[name='latitude']").val(lat);
			$("#tzoneForm input[name='longitude']").val(lng);
			$("#tzoneDialog").dialog( "open" );
			$("#tzoneDialog").dialog( "option", "title", "Time zone and geographical location");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}
	
	function displayRelocation(){
		var tid = $(expandedRow).attr('id');
		$.get("rest?method=getAffiliates&includeParent=true", function(data, textStatus, xhr) {
			var affiliates = data.affiliates;
			var select  = $("#relocationForm").find("#aid");
			select.empty();
			for(i=0; i<affiliates.length; i++){
				var option = $('<option>' + affiliates[i].name + '</option>').appendTo(select);
				option.attr('value', affiliates[i].id);
			}
			
			$("#relocationForm input[name='tid']").val(tid);
			$("#relocationDialog").dialog( "open" );
			$("#relocationDialog").dialog( "option", "title", "Relocate " + getTargetName());
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	function impersonate(){
		if(!currentTarget || !confirm("Would you like to impersonate the owner of " + getTargetName() + "?"))
			return;
		window.location.href = "impersonate?uid=" + currentTarget.impersonator;
	}
	
	function displayProjects(){
		var tid = $(expandedRow).attr('id');
		var tproj = $(expandedRow).find("#tproj").html();
		$.get("rest?method=getProjects&recursive=false&type="+getType(), function(data, textStatus, xhr) {
			var projects = data.projects;
			if(projects.length == 0){
				alert("no projects")
				return;
			}
			var select  = $("#projectForm").find("#pid");
			select.empty();
			$('<option></option>').appendTo(select);
			for(i=0; i<projects.length; i++){
				var option = $('<option>' + projects[i].name + '</option>').appendTo(select);
				option.attr('value', projects[i].id);
				if(tproj == projects[i].name){
					option.attr('selected','selected');
				}
			}
			
			$("#projectForm input[name='tid']").val(tid);
			$("#projectDialog").dialog( "open" );
			$("#projectDialog").dialog( "option", "title", "Assign to project");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}

    function bindUsers(){
    	var tid = $(expandedRow).attr('id');
		$.get("rest?method=getTargetUserBinding&tid="+tid, function(data, textStatus, xhr) {
			var users = data.binding;
			
			// create and populate the users list
			var span = $('#bindForm #selection');
			span.empty();
            var select = $("<select id='items' name='users' multiple='multiple'></select>").appendTo(span);
            for(i=0; i<users.length; i++){
            	var option = $('<option>' + users[i].name + '</option>').appendTo(select);
				option.attr('value', users[i].id);
				if(users[i].bound)
					option.attr('selected', 'selected');
			}
			
			$(select).multiSelect({
				  selectableHeader: "<div class='ms-header'>Available users:</div>",
				  selectionHeader: "<div class='ms-header'>Target users:</div>",
			});

			$("#bindForm input[name='tid']").val(tid);
			$("#bindForm input[name='method']").val("bindTargetUsers");
			$("#bindDialog").dialog( "open" );
			$("#bindDialog").dialog( "option", "title", "Users");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
    }

    function proxify(){
    	var tid = $(expandedRow).attr('id');
		$.get("rest?method=listUsersByRole&role=PROXY", function(data, textStatus, xhr) {
			var users = data.users;
			if(users.length == 0){
				alert("There are no proxy users");
				return;
			}
			
			var select = $("#proxifyForm").find("#uid");
			select.empty();
			for(i=0; i<users.length; i++){
				var option = $('<option>' + users[i].userName + '</option>').appendTo(select);
				option.attr('value', users[i].id);
			}
			
			$("#proxifyForm input[name='tid']").val(tid);
			$("#proxifyDialog").dialog( "open" );
			$("#proxifyDialog").dialog( "option", "title", "Proxify " + getTargetName());
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
    }

    function unproxify(uid){
		$("#progress .message").html("unbinding, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
    	
    	var tid = $(expandedRow).attr('id');
		$.get("rest?method=unbindUserFromTarget&uid=" + uid + "&tid=" + tid, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			updateView(data.target);
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
    }
    
	function displayConfigurations(){
		var tid = $(expandedRow).attr('id');
		$.get("rest?method=getImageVersions&tid="+tid, function(data, textStatus, xhr) {
			var configurations = data.configurations;
			if(configurations.length == 0){
				alert("no configurations available")
				return;
			}
			var select  = $("#cfgForm").find("#cid");
			select.empty();
			for(i=1; i<configurations.length; i++){
				var option = $('<option>' + configurations[i].name + '</option>').appendTo(select);
				option.attr('value', configurations[i].id);
			}
			
			$("#cfgForm input[name='tid']").val(tid);
			$("#cfgDialog").dialog( "open" );
			$("#cfgDialog").dialog( "option", "title", "Select version to restore");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	function downloadImage(){
		var tid = $(expandedRow).attr('id');
		$.get("rest?method=getImageVersions&tid="+tid, function(data, textStatus, xhr) {
			var configurations = data.configurations;
			if(configurations.length == 0){
				alert("no images for this target available")
				return;
			}
			var select  = $("#downloadForm").find("#cid");
			select.empty();
			for(i=0; i<configurations.length; i++){
				var option = $('<option>' + configurations[i].name + '</option>').appendTo(select);
				option.attr('value', configurations[i].id);
			}
			
			$("#downloadForm input[name='tid']").val(tid);
			$("#downloadDialog").dialog( "open" );
			$("#downloadDialog").dialog( "option", "title", "Select image version to download");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	function displayCommParams(row){
		var tid = $(expandedRow).attr('id');
		$.get("rest?method=targetCommParams&tid="+tid, function(data, textStatus, xhr) {
			var params = data.params;
			$("#commForm input[name='tid']").val(tid);
			$("#commForm").find("#pollingRate1").val(params.pollingRate1);
			$("#commForm").find("#pollingRate2").val(params.pollingRate2);
			$("#commForm").find("#readTimeout").val(params.readTimeout);
			$("#commForm").find("#maxErrors").val(params.maxErrors);
			$("#commForm").find("#offlineTimeout").val(params.offlineTimeout);
			$("#commForm").find("#offlineDelay").val(params.offlineDelay);
			
			$("#commDialog").dialog( "open" );
			$("#commDialog").dialog( "option", "title", "Communication parameters");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	$( "#tzoneDialog" ).dialog({
		autoOpen: false,
		height: 320,
		width: 600,
		modal: true,
		buttons: {
			"Update": function() {
				var formData = $("#tzoneForm").serialize();
				$.post("rest?method=setTargetTimeZone", formData, function(data, textStatus, xhr) {
					updateView(data.target);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#relocationDialog" ).dialog({
		autoOpen: false,
		height: 250,
		width: 350,
		modal: true,
		buttons: {
			"Relocate": function() {
				
				$("#progress .message").html("Controller is being relocated, please wait...");
				$("#progress img").show();
				$("#progress").dialog("open");
				
				var formData = $("#relocationForm").serialize();
				$.post("rest?method=relocateTarget", formData, function(data, textStatus, xhr) {
					$("#progress").dialog("close");
					document.location.href = "targets";
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});

	$( "#proxifyDialog" ).dialog({
		autoOpen: false,
		height: 450,
		width: 350,
		modal: true,
		buttons: {
			"Proxify": function() {
				
				$("#progress .message").html("Controller is being proxified, please wait...");
				$("#progress img").show();
				$("#progress").dialog("open");
				
				var formData = $("#proxifyForm").serialize();
				$.post("rest?method=bindTargetToUser", formData, function(data, textStatus, xhr) {
					$("#progress").dialog("close");
					updateView(data.target);
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#projectDialog" ).dialog({
		autoOpen: false,
		height: 250,
		width: 350,
		modal: true,
		buttons: {
			"Assign": function() {
				var formData = $("#projectForm").serialize();
				$.post("rest?method=setTargetProject", formData, function(data, textStatus, xhr) {
					updateView(data.target);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});

	$( "#cfgDialog" ).dialog({
		autoOpen: false,
		height: 250,
		width: 350,
		modal: true,
		buttons: {
			"Restore": function() {
				var formData = $("#cfgForm").serialize();
				$.post("rest?method=restoreTargetConfiguration", formData, function(data, textStatus, xhr) {
					$("#progress").dialog("close");
					updateView(data.target);
					alert("Image is uploaded successfully, the controller is now restarting.\nCheck up in few moments..."); 
					window.location.href = "targets";
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				$("#progress .message").html("Uploading configuration image to " + getTargetName() + ", please stand by...");
				$("#progress").dialog( "option", "title", "Progress");
				$("#progress img").show();
				$("#progress").dialog("open");
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#downloadDialog" ).dialog({
		autoOpen: false,
		height: 300,
		width: 400,
		modal: true,
		buttons: {
			"Download": function() {
				$("#progress .message").html("Downloading target image, please stand by...");
				$("#progress").dialog( "option", "title", "Progress");
				$("#progress img").show();
				$("#progress").dialog("open");
			  
				var formData = $("#downloadForm").serialize();
				$(this).dialog( "close" );
				$.post("rest?method=export&type=image", formData, function(data, textStatus, xhr) {
					$("#progress").dialog( "option", "title", "Done");
					$("#progress img").hide();
					$("#progress .message").html("<a href='" + data.link + "' target='new'>click here to download target image</a>");
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error);
					return;
				})
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#commDialog" ).dialog({
		autoOpen: false,
		height: 400,
		width: 450,
		modal: true,
		buttons: {
			"Save": function() {
				var formData = $("#commForm").serialize();
				$.post("rest?method=setTargetCommParams", formData, function(data, textStatus, xhr) {
					updateView(data.target);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#registerDialog" ).dialog({
		autoOpen: false,
		height: 350,
		width: 450,
		modal: true,
		buttons: {
			"Submit": function() {
				var formData = $("#registerForm").serialize();
				$.post("rest?method=registerTargets", formData, function(data, textStatus, xhr) {
					window.location.href = "targets?oid=" + data.response[0];
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#bindDialog" ).dialog({
		autoOpen: false,
		height: 420,
		width: 720,
		modal: true,
		buttons: {
			"Submit": function() {
				var formData = $("#bindForm").serialize();
				var method = $("#bindForm input[name='method']").val();
				$.post("rest?method=" + method, formData, function(data, textStatus, xhr) {
					updateView(data.project);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
    $("#targetsDialog" ).dialog({
        autoOpen: false,
        height: 360,
        width: 500,
        modal: true,
        buttons: {
            Continue: function() {
                $( this ).dialog( "close" );
            },
            Cancel: function() {
                $( this ).dialog( "close" );
            }
        }
    });  
	
	$('#queryDialog').keypress(function(e) {
		if (e.keyCode == $.ui.keyCode.ENTER) {
			$(this).dialog("close");
			keepQuery('targets.query', $("#queryForm").serializeObject());
			goto("targets");
		}
	});

	$( "#queryDialog" ).dialog({
		autoOpen: false,
		height: 300,
		width: 450,
		modal: true,
		buttons: {
			"Find": function() {
				$(this).dialog("close");
				keepQuery('targets.query', $("#queryForm").serializeObject());
				goto("targets");
			},
			"Reset": function() {
				$(this).dialog( "close" );
				keepQuery('targets.query', {});
				goto("targets");
			},
			Cancel: function() {
				$(this).dialog( "close" );
			}
		},
		close: function() {
			
		}
	});
    
	function renameTarget(){
		var name = prompt("Enter new name for this controller", getTargetName());
		if(name == null)
			return;
		var tid = $(expandedRow).attr('id');
		$.post("rest?method=renameTarget", {'tid' : tid, 'name' : name}, function(data, textStatus, xhr) {
			updateView(data.target);
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	function removeTarget(){
		var tid = $(expandedRow).attr('id');
		if(confirm("Remove " + getTargetName() + " from the system?\nThis will permanently erase ALL target related data.\n\nThis operation is not recoverable!\nPlease confirm.") == true){
			$("#progress .message").html("Removing target...");
			$("#progress").dialog( "option", "title", "Progress");
			$("#progress img").show();
			$("#progress").dialog("open");
			
			$.post("rest?method=removeTarget", {'tid' : tid}, function(data, textStatus, xhr) {
				$("#progress").dialog("close");
				goto("targets");
			}, "json")
			.error(function(xhr) { 
				$("#progress").dialog("close");
				alert(jQuery.parseJSON(xhr.responseText).error);
			})
		}
	}

	function replaceTarget(){
		var tid = $(expandedRow).attr('id');
		if(confirm("Are you sure you want to change serial number for this target?") == false)
			return;
		var serial = prompt("Enter new serial number for this controller", "");
		if(serial == null)
			return;

		$("#progress .message").html("Replacing controller serial number...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");

		$.post("rest?method=replaceTarget", {'tid' : tid, 'serial' : serial}, function(data, textStatus, xhr) {
			$("#progress").dialog("close"); 
			refreshTargetContent();
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close"); 
			alert(jQuery.parseJSON(xhr.responseText).error);
			return;
		})
	}
	
	function syncTarget(){
		if(confirm("This will synchronize current image of " + getTargetName() + " controller with server.\nImage will be downloaded from controller and loaded\ninto server memory.\nProceed?") == true){
			var tid = $(expandedRow).attr('id');
			$("#progress .message").html("Reloading target image, please stand by...");
			$("#progress").dialog( "option", "title", "Progress");
			$("#progress img").show();
			$("#progress").dialog("open");
			$.post("rest?method=syncTargetImage", {'tid' : tid}, function(data, textStatus, xhr) {
				$("#progress").dialog("close"); 
			}, "json")
			.error(function(xhr) { 
				$("#progress").dialog("close");
				alert(jQuery.parseJSON(xhr.responseText).error);
			})
			return true;
		}
	}

	function backupTarget(){
		if(confirm("This will download current image from '" + getTargetName() + "' and save it in server database\nas restore point for later use.\nProceed?") == true){
			var tid = $(expandedRow).attr('id');
			$("#progress .message").html("Backing up controller image, this may take few moments,<br>please stand by...");
			$("#progress").dialog( "option", "title", "Progress");
			$("#progress img").show();
			$("#progress").dialog("open");
			$.post("rest?method=backupTargetConfiguration", {'tid' : tid}, function(data, textStatus, xhr) {
				$("#progress").dialog("close");
			}, "json")
			.error(function(xhr) { 
				$("#progress").dialog("close");
				alert(jQuery.parseJSON(xhr.responseText).error);

			})
		}
	}
	
	function releaseTarget(){
		if(!confirm("This will release controller from server firewall black list.\nProceed?"))
			return;
		var tid = $(expandedRow).attr('id');
		$("#progress .message").html("Releasing controller from firewall black list,<br>please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		$.post("rest?method=releaseTarget", {'tid' : tid}, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			updateView(data.target);
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	function kickTarget(){
		if(!confirm("This will instantly disconnect controller from server.\nProceed?"))
			return;
		var tid = $(expandedRow).attr('id');
		$("#progress .message").html("Disconnecting, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		$.post("rest?method=disconnectTarget", {'tid' : tid}, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			updateView(data.target);
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	function banTarget(){
		if(!confirm("This operation will ban controller by placing it to a firewall ban list.\nProceed?"))
			return;
		var tid = $(expandedRow).attr('id');
		$("#progress .message").html("Processing, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		$.post("rest?method=banTarget", {'tid' : tid}, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			updateView(data.target);
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
    function upgradeTarget(){
        if(confirm("This will upgrade " + getTargetName() + " controller software.\nDuring upgrade controller will perform restart.\nProceed?") == true){
            var tid = $(expandedRow).attr('id');
            $("#progress .message").html("Upgrading software, please stand by...");
            $("#progress").dialog( "option", "title", "Progress");
            $("#progress img").show();
            $("#progress").dialog("open");
            $.post("rest?method=upgradeFirmware", {'tid' : tid}, function(data, textStatus, xhr) {
                $("#progress").dialog("close"); 
                updateView(data.target);
                alert("Upgrade command was successfully sent to controller.\nIt will take some time for operation to complete.");
            }, "json")
            .error(function(xhr) { 
                $("#progress").dialog("close");
                alert(jQuery.parseJSON(xhr.responseText).error);
            })
            return true;
        }
    }
	
   $("a#register").click(function(){
		$.get("rest?method=getTargetTypes", function(data, textStatus, xhr) {
			var types = data.types;
			var select  = $("#registerForm").find("#type");
			select.empty();
			for(i=0; i<types.length; i++){
				var option = $('<option>' + types[i] + '</option>').appendTo(select);
				option.attr('value', types[i]);
			}
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
			return;
		})

		$.get("rest?method=getAffiliates&recursive=true", function(data, textStatus, xhr) {
			var affiliates = data.affiliates;
			var select  = $("#registerForm").find("#aid");
			select.empty();
			for(i=0; i<affiliates.length; i++){
				var option = $('<option>' + affiliates[i].name + '</option>').appendTo(select);
				option.attr('value', affiliates[i].id);
			}
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
			return;
		})
		
		$("#registerDialog").dialog( "open" );
		$("#registerDialog").dialog( "option", "title", "Register new targets");
   });

   $('a#query').live('click', function() {
	   $("#queryForm #search").val(getQuery("targets.query").search);
	   $("#queryForm #search").select();
	   $("#queryDialog").dialog("open");
  });
   
   $("a#upgrade").click(function(e){
        miltiTargetOperation(doupgrade, "Start upgrade");
   });

   $("a#export").click(function(e){
		exportThings("targets");
   });
   
   $("a#locate").click(function(e){
	   window.open("/maps/target?navigation=true&controls=true&drag=true&mapType=terrain", "My locations");
   });
   
   $("a#cleanup").click(function(){
	   if(confirm("This will erase OFFLINE targets which are NOT assigned to ANY project.\nThis operation is not recoverable!\n\nPlease confirm...") == true){
			$.get("rest?method=removeOrphanedTargets", function(data, textStatus, xhr) {
				window.location.href = "targets";
			}, "json")
			.error(function(xhr) { 
				alert(jQuery.parseJSON(xhr.responseText).error);
				return;
			})
	   }
   });
   
    function doupgrade(){
        var selected =  $("#targetsForm").find("#tids").find(":selected");
        var tids = new Array();
        for(var i=0; i<selected.length; i++)
            tids.push($(selected[i]).attr('value'));
        
        $("#progress .message").html("Upgrading software, please stand by...");
        $("#progress").dialog( "option", "title", "Progress");
        $("#progress img").show();
        $("#progress").dialog("open");
        $.post("rest?method=upgradeFirmware", {'tids' : tids.toString()}, function(data, textStatus, xhr) {
           var response = data.response;
           var message = "";
           for(var i=0;i<response.length;i++){
                message += "<br>";
                message += response[i];
           }
           $("#progress img").hide();
            $("#progress .message").html(message);
            $("#progress").dialog( "option", "title", "Complete");
        }, "json")
        .error(function(xhr) { 
            $("#progress").dialog("close");
            alert(jQuery.parseJSON(xhr.responseText).error);
        })    
    } 

    function miltiTargetOperation(callback, actionLabel){
        var rows = oTable.$('tr', {filter:'applied'});
        var select  = $("#targetsForm").find("#tids");
        select.empty();
        for(i=0; i<rows.length; i++){
            if($(rows[i]).hasClass('offline'))
               continue;
            if($(rows[i]).find("#tser").html() == undefined)
            	continue;
	        var option = $('<option>' + $(rows[i]).find("#tser").html() + ' - ' + $(rows[i]).find("#tname").html() + ' - ' + $(rows[i]).find("#tver").html() + '</option>').appendTo(select);
	        option.attr('value', $(rows[i]).attr('id'));
        }
        
        if(select.children().length == 0){
            alert("There are currently no online targets");
            return;
        }

        $("#targetsDialog").dialog( "open" );
        $("#targetsDialog").dialog( "option", "title", "Select targets for upgrade");
        $("#targetsDialog" ).dialog( "option", "buttons", [ 
                    { 
                        text: actionLabel, 
                        click: function() { 
                            $( this ).dialog( "close" );
                            callback(); 
                        } 
                    }, 
                    { 
                        text: "Cancel", 
                        click: function() { 
                            $( this ).dialog( "close" ); 
                        } 
                    },
                    {
                        text: "All", 
                        click: function() { 
                            $("#tids option").attr("selected", "selected");
                        } 
                    },
                    {
                        text: "None", 
                        click: function() {
                            $("#tids option").removeAttr("selected");
                        } 
                    } 
            ] 
        );
    }
    
	function displayChart(series){
		$("#chartDialog").dialog("open");
		$("#chartDialog").dialog("option", "title", getTargetName() + " - " + series);
		$("#chart").empty();
		$("#chart").html("<br><br><div class='m-t-large text-center h5'><i class='fa fa-fw fa-2x fa-umbrella text-info fa-spin'></i><span>&nbsp;&nbsp;&nbsp;loading, please stans by..</div>");
		
		var tid = $(expandedRow).attr('id');
		var url = "rest?method=getObservations&series=" + series + "&tid="+tid;
		$.get(url, function(data, textStatus, xhr) {
			plot(data.dataset);
		}, "json")
		.error(function(xhr) { 
			$("#chart").html("error getting data series");
		})		
	}
	
	function plot(dataset){
		if(dataset.series.length == 0){
			$("#chart").html("<br><br><div class='m-t-large text-center h5'><i class='fa fa-fw fa-2x fa-ban text-danger'></i><span>&nbsp;&nbsp;&nbsp;no data available</div>");
			return;
		}
		
		var input = new Array();
		input.push({
			type : 'line',
			name : dataset.name + " (" + dataset.units + ")",
			data : dataset.series,
			tooltip: {
				valueDecimals: (dataset.units == "Bytes") ? 0 : 2
			}
		});
		
		var chart = new Highcharts.StockChart({
	        chart: {
	        	renderTo: 'chart'
	        },				
			credits: {
	            enabled: false
	        },				
			rangeSelector : {
				selected: 0,
				buttons: [{
					type: 'day',
					count: 1,
					text: '1d'
				}, 
				{
					type: 'day',
					count: 2,
					text: '2d'
				}, 
				{
					type: 'all',
					text: 'All'
				}]	
			},
			title : {
				text : ''
			},
            tooltip: {
                crosshairs: {
                    color: 'green',
                    dashStyle: 'solid'
                },
                shared: true,
                useHTML: true
            },            
			series : input
		});
	}
	
	$( "#chartDialog" ).dialog({
		autoOpen: false,
        height: 550,
        width: 800,
		modal: true,
		buttons: {
			"Close": function() {
				$(this).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	function displayPortal(row){
		var type = getType();
		if(type.startsWith("DREAM") || type.startsWith("SAPIR"))
			window.open("../spot/dream/"+getSerial());
		else if(type.startsWith("OASIS"))
			window.open("../spot/oasis/"+getSerial());
		else if(type.startsWith("AGROTAL"))
			window.open("../spot/agrotal/"+getSerial());
	}

	function displayGeomap(){
		var tid = $(expandedRow).attr('id');
		var title = getLongName();
		$("#chartDialog").dialog( "open" );
		$("#chartDialog").dialog( "option", "title", title);
		$("#chart").empty();
		$("#chart").html("hang on, locating the controller in the world... <img src='/admin/images/anim.gif'>");

		$.get("rest?method=getMapArea&tid="+tid, function(data, textStatus, xhr) {
			var md = data.area.markers[0];
			var latlng = new google.maps.LatLng(md.location.latitude, md.location.longitude);
			new google.maps.MaxZoomService().getMaxZoomAtLatLng(latlng, function(response) {
				if(response.status == google.maps.MaxZoomStatus.OK){
					md.location.zoom = response.zoom-1;
				}
				
			    var myOptions = {
			            zoom: md.location.zoom,
			            center: latlng,
			            mapTypeId: google.maps.MapTypeId.SATELLITE,
			    };
			    var map = new google.maps.Map($('#chart')[0], myOptions);
			    var marker = new google.maps.Marker({
			        position: latlng,
			        map: map,
			        icon: md.icon,
			        title: md.title,
			        animation: google.maps.Animation.DROP,
			        draggable: true
			    });	    
			    
			    google.maps.event.addListener(marker, "dragend", function(event) {
			    	updateTargetLocation(md.id, event.latLng.lat(), event.latLng.lng());
			    }); 		    
				
			});
		}, "json")
		.error(function(xhr) { 
			$("#chart").html("<p>" + jQuery.parseJSON(xhr.responseText).error + "</p>");
		})
	}
	
	function updateTargetLocation(tid,lat,lng){
		$.post("rest?method=setTargetLocation&tid=" + tid + "&latitude=" + lat + "&longitude=" + lng, null, function(data, textStatus, xhr) {
			updateView(data.target);
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}

	function getTargetName(){
		var name = $(expandedRow).find("#tname").html();
		if(name == "")
			return getType() + " #" + getSerial();
		return $(expandedRow).find("#tname").html();		
	}

	function getSerial(){
		return $(expandedRow).find("#tser").html();		
	}

	function getTargetID(){
		return $(expandedRow).attr('id');		
	}
	
	function getLongName(){
		return getTargetName() + " (" + getSerial() + ")";
	}
	function getType(){
		return $(expandedRow).find("#ttype").html();		
	}
});