$(function(){
	var expandedRow;
	var addedRow;
	var currentProject;
	
	$.ajaxSetup ({
		cache: false
	});

	var oTable = $('#stuff').dataTable({
		"sAjaxSource" : makeQueryUrl(),
		"aoColumns" : [{"mData" : "id"}, {"mData" : "name"}, {"mData" : "accessType"}, {"mData" : "targetType"}, {"mData" : "affiliate"}, {"mData" : "country"}],
		"fnRowCallback" : rowCallback,
		"fnInitComplete": initCallback, 
		"bJQueryUI": true,
		"bPaginate": true,
		"bFilter": true,
		"bLengthChange": true,
		"iDisplayLength" : 25,
		"aaSorting": [[ 1, "asc" ]],
		"bStateSave": false,
		"fnStateSave": function (oSettings, oData) {
			localStorage.setItem( 'DataTables_'+window.location.pathname, JSON.stringify(oData) );
		},
		"fnStateLoad": function (oSettings) {
			return JSON.parse( localStorage.getItem('DataTables_'+window.location.pathname) );
		},
		"oLanguage": {
			"sLoadingRecords" : "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i> getting the data, please wait...",
			"sSearch": "Global filter:",
			"sEmptyTable": "<br><p align='center'>No records matching specified criteria.<br><a id='query' href='#'>Click here for the query</a><br><br></p>"
		}
	});

	function rowCallback(nRow, aData, iDisplayIndex){
		$(nRow).attr("id", aData.id);
		$('td:eq(0)', nRow).html("").addClass('expand');
		$('td:eq(1)', nRow).attr("id", "pname");
		$('td:eq(2)', nRow).attr("id", "ptype");
		$('td:eq(2)', nRow).attr("style", "width: 80px;");
		$('td:eq(3)', nRow).attr("id", "ttype");
		$('td:eq(3)', nRow).attr("style", "width: 80px;");
		$('td:eq(4)', nRow).attr("id", "achain");
		$('td:eq(5)', nRow).attr("id", "pcountry");
	}
	
	function initCallback(oSettings, json){
		$(".toolbar").show();
		
		var query = getQuery('projects.query');
		if(query.oid){
			query.oid = "";
			keepQuery('projects.query', query);
			expandRow($("#stuff tbody tr").get(0));
			return;
		}

		var affiliates = new Array();
		var targets = new Array();
		var access = new Array();
		var countries = new Array();
		for(var i = 0; i < json.aaData.length; i++){
			var value = json.aaData[i].affiliate;
			if(value.length > 0 && jQuery.inArray(value, affiliates) == -1)
				affiliates.push(value);
			value = json.aaData[i].targetType;	
			if(value.length > 0 && jQuery.inArray(value, targets) == -1)
			targets.push(value);
			value = json.aaData[i].accessType;	
			if(value.length > 0 && jQuery.inArray(value, access) == -1)
				access.push(value);
			value = json.aaData[i].country;	
			if(value.length > 0 && jQuery.inArray(value, countries) == -1)
				countries.push(value);
		}
		
	    $(".cfilter").each( function ( i ) {
			var column = $(this).parent().children().index($(this)) + 1; // span adjust
			switch(column){
				case 2:
					this.innerHTML = fnCreateSelect(access);
				break;	
				case 3:
					this.innerHTML = fnCreateSelect(targets);
				break;	
				case 4:
					this.innerHTML = fnCreateChainSelect(affiliates);
				break;	
				case 5:
					this.innerHTML = fnCreateSelect(countries);
				break;	
			}

	        $('select', this).change( function () {
				if($(this).val() == 'My affiliates only')
					oTable.fnFilter("^[^/]+$" , column, true );
				else
					oTable.fnFilter( $(this).val(), column );
	        });
	    } );
	}

	function makeQueryUrl(){
		var query = getQuery('projects.query');
		return "rest?method=listProjects&search=" + query.search + "&oid=" + query.oid;
	}

	$("a#resetFilters").click(function(){
	    $(".cfilter").each( function ( i ) {
	    	var column = $(this).parent().children().index($(this)) + 1; // span adjust
	    	var select = $(this).find('select');
	    	$(select).val("Show all");
	    	oTable.fnFilter( $(select).val(), column );
	    });
	});
    
    $('td.expand').live('click', function(event) {
    	expandRow($(this).parent("tr").get(0));
	});
    
    function expandRow(row){
		if (oTable.fnIsOpen(row)) {
			oTable.fnClose(row);
			expandedRow = null;
			return;
		} 

		if(expandedRow != null)
			oTable.fnClose(expandedRow);
    	expandedRow = row;
    	oTable.fnOpen(expandedRow, "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i>", "info_row" );
    	refreshProjectContent();
    }
    
	function refreshProjectContent() {
		if(expandedRow == null)
			return;
		var pid = $(expandedRow).attr('id');
		$.get("rest?method=getProject&pid="+pid, function(data, textStatus, xhr) {
			currentProject = data.project;
			buildExpandedRow(currentProject);
			addedRow = oTable.fnOpen(expandedRow, $(expandedRow).find(".expansionPanel").html(), "info_row" );
			hook();
		}, "json")
		.error(function(xhr){
			oTable.fnClose(expandedRow);
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
    function buildExpandedRow(project){
    	var td = $(expandedRow).find(".expand");
		$(td).empty();
		var image = project.accessType == 'DESKTOP'?"/admin/images/project.png":"/admin/images/project2.png";
    	var exp = $("<div class='expansionPanel'/>").appendTo(td);
    	
    	var p1 = $("<div class='expansionContent'/>").appendTo(exp);
    	$("<img src='" + image + "'/>").appendTo(p1);    	
    	
		var p2 = $("<div class='expansionContent'/>").appendTo(exp);
		$("<b>Actions:</b><br>").appendTo(p2);
    	if(project.impersonator){
    		$("<a class='impersonate' href='#' title='Impersonate the owner of this project'><img src='/admin/images/contacts.png'> Impersonate</a><br>").appendTo(p2);
    	}
    	
    	if(project.editable){
    		$("<a class='bindUsers' href='#' title='Bind users to this project'><img src='/admin/images/link.gif'> Users</a><br>").appendTo(p2);
    		$("<a class='bindTargets' href='#' title='Bind targets to this project'><img src='/admin/images/link.gif'> Targets</a><br>").appendTo(p2);
    		$("<a class='newUser' href='#' title='Create new user and add it to the project'><img src='/admin/images/add.gif'> New user</a><br>").appendTo(p2);
    		$("<a class='editProject' href='#' title='Modify project record'><img src='/admin/images/edit.gif'> Edit</a><br>").appendTo(p2);
    		$("<a class='removeProject' href='#' title='Remove this project'><img src='/admin/images/trash.png'> Remove</a><br>").appendTo(p2);
    		$("<a class='relocate' href='#' title='Relocate this project to another organization'><img src='/admin/images/right.gif'> Relocate</a><br>").appendTo(p2);
    	}
    	
    	var p3 = $("<div class='expansionContent'/>").appendTo(exp);
    	$("<b>Targets:</b><br>").appendTo(p3);
    	for(i=0;i<project.targets.length;i++){
   		   var o = project.targets[i];
		   p3.append("<a href='#' class='tref' oid='" + o.id + "' title='go to target details'>" + o.name + "</a><br>");
    	}
    	
    	var p4 = $("<div class='expansionContent'/>").appendTo(exp);
    	$("<b>Users:</b><br>").appendTo(p4);
    	for(i=0;i<project.users.length;i++){
   		   var o = project.users[i];
   		   if(o.bound)
   			   p4.append("<a href='#' class='uref' oid='" + o.id + "' title='go to user details'>" + o.name + "</a><br>");
   		   else
   			   p4.append(o.name + "<br>");
    	}
	}
	
    function hook(){
		$(addedRow).find("a.tref").click(function(evt){
			evt.preventDefault();
			goto('targets', $(evt.target).attr("oid"));
		});
		$(addedRow).find("a.uref").click(function(evt){
			evt.preventDefault();
			goto('users', $(evt.target).attr("oid"));
		});
		$(addedRow).find("a.newUser").click(function(evt){
			evt.preventDefault();
			newUser();
		});
		$(addedRow).find("a.bindUsers").click(function(evt){
			evt.preventDefault();
			bindUsers();
		});
		$(addedRow).find("a.bindTargets").click(function(evt){
			evt.preventDefault();
			bindTargets();
		});
		$(addedRow).find("a.editProject").click(function(evt){
			evt.preventDefault();
			edit();
		});
		$(addedRow).find("a.removeProject").click(function(evt){
			evt.preventDefault();
			remove();
		});
		$(addedRow).find("a.relocate").click(function(evt){
			evt.preventDefault();
			displayRelocation();
		});
		$(addedRow).find("a.impersonate").click(function(evt){
			evt.preventDefault();
			impersonate();
		});
    }
	
    $("a#addProject").click(function(){
    	$('#addProjectForm #ptype').val("DESKTOP");
        $( "#addProjectDialog" ).dialog( "open" );
     });

    $('#addProjectForm #ptype').change(function() {
    	if($(this).val() == "DESKTOP"){
    		$('#addProjectForm #ttype').val("DREAM");
    		$('#addProjectForm #ttype').prop('disabled', true);
    	}
    	else{
    		$('#addProjectForm #ttype').prop('disabled', false);
    	}
    });
    
    $( "#addProjectDialog" ).dialog({
        autoOpen: false,
        height: 300,
        width: 450,
        modal: true,
        buttons: {
            "Create project": function() {
				var formData = $("#addProjectForm").serialize();
				$.post("rest?method=addProject", formData, function(data, textStatus, xhr) {
					goto('projects', data.project.id);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
            },
            Cancel: function() {
                $( this ).dialog( "close" );
            }
        },
        close: function() {
            //allFields.val( "" ).removeClass( "ui-state-error" );
        }
    });
	
    function edit(){
    	var country = $(expandedRow).find("#pcountry").html();
		$("#editProjectForm input[name='pid']").val($(expandedRow).attr('id'));
		$("#editProjectForm input[name='name']").val($(expandedRow).find("#pname").html());
		$("#editProjectForm select[name='country']").find("option[value='" + country + "']").attr('selected', 'selected');
		$("#editProjectForm input[name='dealer']").val($(expandedRow).find("#pdealer").html());
		$("#editProjectDialog").dialog( "open" );
		$("#editProjectDialog").dialog( "option", "title", "Modify " + getProjectName());
    }
    
	$( "#editProjectDialog" ).dialog({
		autoOpen: false,
		height: 300,
		width: 450,
		modal: true,
		buttons: {
			"Update": function() {
				var formData = $("#editProjectForm").serialize();
				$.post("rest?method=updateProject", formData, function(data, textStatus, xhr) {
					updateView(data.project);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});

    function newUser(row){
    	resetForm($("#newUserForm"));
		$("#newUserForm #username").val("");
		$('#newUserForm #userRole').val("MANAGER");
		$('#newUserForm #userAccess').val("DESKTOP");
		$("#newUserDialog").dialog( "open" );
		$("#newUserDialog").dialog( "option", "title", "New project user");
    }
	
	$( "#newUserDialog" ).dialog({
		autoOpen: false,
		height: 400,
		width: 450,
		modal: true,
		buttons: {
			"Create": function() {
				var formData = $("#newUserForm").serialize();
				var pid = $(expandedRow).attr('id');
				
		        $("#progress .message").html("Adding new user, please stand by...");
		        $("#progress img").show();
		        $("#progress").dialog( "option", "title", "Progress");
		        $("#progress").dialog("open");
				
				$.post("rest?method=addNewUserToProject&pid="+pid, formData, function(data, textStatus, xhr) {
					$("#progress").dialog("close");
					updateView(data.project);
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
    function bindUsers(){
    	var pid = $(expandedRow).attr('id');
    	
		$("#progress .message").html("Listing users, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
    	
		$.get("rest?method=getProjectBinding&pid="+pid, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			var users = data.binding[0];
			
			// create and populate the users list
			var span = $('#bindForm #selection');
			span.empty();
            var select = $("<select id='items' name='users' multiple='multiple'></select>").appendTo(span);
            for(i=0; i<users.length; i++){
            	var option = $('<option>' + users[i].name + '</option>').appendTo(select);
				option.attr('value', users[i].id);
				if(users[i].bound)
					option.attr('selected', 'selected');
			}
			
			$(select).multiSelect({
				  selectableHeader: "<div class='ms-header'>Available users:</div>",
				  selectionHeader: "<div class='ms-header'>Project users:</div>",
			});

			$("#bindForm input[name='pid']").val(pid);
			$("#bindForm input[name='method']").val("bindProjectUsers");
			$("#bindDialog").dialog( "open" );
			$("#bindDialog").dialog( "option", "title", "Users");
			
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
    }
    
    function bindTargets(){
    	var pid = $(expandedRow).attr('id');
		$("#progress .message").html("Listing targets, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
    	
		$.get("rest?method=getProjectBinding&pid="+pid, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			var targets = data.binding[1];
			
			var span = $('#bindForm #selection');
			span.empty();
            var select = $("<select id='items' name='targets' multiple='multiple'></select>").appendTo(span);
            for(i=0; i<targets.length; i++){
            	var option = $('<option>' + targets[i].name + '</option>').appendTo(select);	
				option.attr('value', targets[i].id);
				if(targets[i].bound)
					option.attr('selected', 'selected');
			}
			
			$(select).multiSelect({
				  selectableHeader: "<div class='ms-header'>Available targets:</div>",
				  selectionHeader: "<div class='ms-header'>Project targets:</div>",
			});
			
			$("#bindForm input[name='pid']").val(pid);
			$("#bindForm input[name='method']").val("bindProjectTargets");
			$("#bindDialog").dialog( "open" );
			$("#bindDialog").dialog( "option", "title", "Targets");
			
			
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
    }
    
	$( "#bindDialog" ).dialog({
		autoOpen: false,
		height: 420,
		width: 720,
		modal: true,
		buttons: {
			"Submit": function() {
				var formData = $("#bindForm").serialize();
				var method = $("#bindForm input[name='method']").val();
				$.post("rest?method=" + method, formData, function(data, textStatus, xhr) {
					updateView(data.project);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#relocationDialog" ).dialog({
		autoOpen: false,
		height: 250,
		width: 350,
		modal: true,
		buttons: {
			"Relocate": function() {
				
				$("#progress .message").html("Project is being moved, please wait...");
				$("#progress img").show();
				$("#progress").dialog("open");
				
				var formData = $("#relocationForm").serialize();
				$.post("rest?method=relocateProject", formData, function(data, textStatus, xhr) {
					$("#progress").dialog("close");
					document.location.href = "projects";
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	function remove(){
		if(confirm("Are you sure you want to remove " + getProjectName()) == false)
			return false;
		var pid = $(expandedRow).attr('id'); 
		$.post("rest?method=removeProject", {'pid': pid}, function(data, textStatus, xhr) {
			goto("projects");
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}
	
	function displayRelocation(){
		if(!confirm("Relocate project '" + getProjectName() + "' to another organization?"))
			return;
		
		var pid = $(expandedRow).attr('id');
		$.get("rest?method=getAffiliates&includeParent=true", function(data, textStatus, xhr) {
			var affiliates = data.affiliates;
			var select  = $("#relocationForm").find("#aid");
			select.empty();
			for(i=0; i<affiliates.length; i++){
				var option = $('<option>' + affiliates[i].name + '</option>').appendTo(select);
				option.attr('value', affiliates[i].id);
			}
			
			$("#relocationForm input[name='pid']").val(pid);
			$("#relocationDialog").dialog( "open" );
			$("#relocationDialog").dialog( "option", "title", "Relocate " + getProjectName());
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	function impersonate(){
		if(!currentProject || !confirm("Would you like to impersonate the affiliate of '" + getProjectName() + "' ?"))
			return;
		window.location.href = "impersonate?uid=" + currentProject.impersonator;
	}
	
	$("a#export").click(function(e){
		exportThings("projects");
	});

	$('a#query').live('click', function() {
		$("#queryForm #search").val(getQuery("projects.query").search);
		$("#queryForm #search").select();
		$("#queryDialog").dialog("open");
	});
	
	$('#queryDialog').keypress(function(e) {
		if (e.keyCode == $.ui.keyCode.ENTER) {
			$(this).dialog("close");
			keepQuery('projects.query', $("#queryForm").serializeObject());
			goto("projects");
		}
	});

	$( "#queryDialog" ).dialog({
		autoOpen: false,
		height: 300,
		width: 450,
		modal: true,
		buttons: {
			"Find": function() {
				$(this).dialog("close");
				keepQuery('projects.query', $("#queryForm").serializeObject());
				goto("projects");
			},
			"Reset": function() {
				$(this).dialog( "close" );
				keepQuery('projects.query', {});
				goto("projects");
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});

	function updateView(project){
		currentProject = project;
		
		// table
		var td = $(expandedRow).find("#pname");
		td.html(project.name);

		td = $(expandedRow).find("#pcountry");
		td.html(project.country);

		td = $(expandedRow).find("#pusers");
		td.html(project.users.length);

		td = $(expandedRow).find("#ptargets");
		td.html(project.targets.length);
		
		buildExpandedRow(project);
		addedRow = oTable.fnOpen(expandedRow, $(expandedRow).find(".expansionPanel").html(), "info_row" );
		hook();
	}
   
	function getProjectName(){
		return $(expandedRow).find("#pname").html();		
	}
});