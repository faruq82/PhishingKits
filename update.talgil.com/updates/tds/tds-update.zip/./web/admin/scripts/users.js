$(function(){
	var expandedRow;
	var addedRow;
	var currentUser;

	$.ajaxSetup ({
		cache: false
	});
	
	var oTable = $('#stuff').dataTable({
		"sAjaxSource" : makeQueryUrl(),
		"aoColumns" : [{"mData" : "id"}, {"mData" : "status"}, {"mData" : "userName"}, {"mData" : "affiliate"}, {"mData" : "role"}, {"mData" : "access"}],
		"fnRowCallback" : rowCallback,
		"fnInitComplete": initCallback, 
		"bJQueryUI": true,
		"bPaginate": true,
		"bFilter": true,
		"bLengthChange": true,
		"iDisplayLength" : 25,
		"aaSorting": [[ 1, "desc" ], [2, "asc"]],
		"bStateSave": false,
		"fnStateSave": function (oSettings, oData) {
			localStorage.setItem( 'DataTables_'+window.location.pathname, JSON.stringify(oData) );
		},
		"fnStateLoad": function (oSettings) {
			return JSON.parse( localStorage.getItem('DataTables_'+window.location.pathname) );
		},
		"oLanguage": {
			"sLoadingRecords" : "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i> getting the data, please wait...",
			"sSearch": "Global filter:",
			"sEmptyTable": "<br><p align='center'>No records matching specified criteria.<br><a id='query' href='#'>Click here for the query</a><br><br></p>"
		}
	});

	function rowCallback(nRow, aData, iDisplayIndex){
		$(nRow).attr("id", aData.id);
		$(nRow).attr("class", aData.status);
		
		$('td:eq(0)', nRow).html("").addClass('expand');
		
		var td = $('td:eq(1)', nRow);
		td.attr("id", "ustate");
		td.addClass(aData.status);
		td.html("<span style='display: none;'>" + aData.status + "</span>");

		$('td:eq(2)', nRow).attr("id", "username");
		$('td:eq(3)', nRow).attr("id", "achain");
		$('td:eq(4)', nRow).attr("id", "role");
		$('td:eq(5)', nRow).attr("id", "access");
	}
	
	function initCallback(oSettings, json){
		$(".toolbar").show();
		
		var query = getQuery('users.query');
		if(query.oid){
			query.oid = "";
			keepQuery('users.query', query);
			expandRow($("#stuff tbody tr").get(0));
			return;
		}

		var affiliates = new Array();
		var roles = new Array();
		var access = new Array();
		for(var i = 0; i < json.aaData.length; i++){
			var value = json.aaData[i].affiliate;
			if(value.length > 0 && jQuery.inArray(value, affiliates) == -1)
				affiliates.push(value);
			value = json.aaData[i].role;	
			if(value.length > 0 && jQuery.inArray(value, roles) == -1)
				roles.push(value);
			value = json.aaData[i].access;	
			if(value.length > 0 && jQuery.inArray(value, access) == -1)
				access.push(value);
		}
		
	    $(".cfilter").each( function ( i ) {
			var column = $(this).parent().children().index($(this)) + 2; // span adjust
			switch(column){
				case 3:
					this.innerHTML = fnCreateChainSelect( affiliates );
				break;	
				case 4:
					this.innerHTML = fnCreateSelect(roles);
				break;	
				case 5:
					this.innerHTML = fnCreateSelect(access);
				break;	
			}

	        $('select', this).change( function () {
				if($(this).val() == 'My affiliates only')
					oTable.fnFilter("^[^/]+$" , column, true );
				else
					oTable.fnFilter( $(this).val(), column );
	        });
	    } );
	}

	function makeQueryUrl(){
		var query = getQuery('users.query');
		return "rest?method=listUsers&search=" + query.search + "&oid=" + query.oid;
	}
	
	$("a#resetFilters").click(function(){
	    $(".cfilter").each( function ( i ) {
	    	var column = $(this).parent().children().index($(this)) + 2; // span adjust
	    	var select = $(this).find('select');
	    	$(select).val("Show all");
	    	oTable.fnFilter( $(select).val(), column );
	    });
	});
    
    $('td.expand').live('click', function(event) {
    	expandRow($(this).parent("tr").get(0));
	});
    
    function expandRow(row){
		if (oTable.fnIsOpen(row)) {
			oTable.fnClose(row);
			expandedRow = null;
			return;
		} 

		if(expandedRow != null)
			oTable.fnClose(expandedRow);
    	expandedRow = row;
    	oTable.fnOpen(expandedRow, "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i>", "info_row" );
    	refreshUserContent();
    }
    
	function refreshUserContent() {
		if(expandedRow == null)
			return;
		var uid = $(expandedRow).attr('id');
		$.get("rest?method=getUser&uid="+uid, function(data, textStatus, xhr) {
			updateView(data.user);
		}, "json")
		.error(function(xhr){
			oTable.fnClose(expandedRow);
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
    
    function buildExpandedRow(user){
    	var td = $(expandedRow).find(".expand");
		$(td).empty();
		var image = user.online?"/admin/images/user-online.png":"/admin/images/user-offline.png";
    	var exp = $("<div class='expansionPanel'/>").appendTo(td);

    	var p1 = $("<div class='expansionContent'/>").appendTo(exp);
    	if(user.impersonator)
    		$("<a class='impersonate' href='#' title='click to impersonate affiliate'><img src='" + image + "'/></a>").appendTo(p1);
    	else
    		$("<img src='" + image + "'/>").appendTo(p1);
    		
    	var mail = user.email.split(";").join("<br>");
    	mail = mail.split(",").join("<br>")
        p1.append("<br>" + mail);
    	p1.append("<br>" + user.phone);
    	p1.append("<br><b>login:</b> " + user.loginTime);
    	p1.append("<br><b>seen:</b> " + user.lastTime);
    	
    	var p2 = $("<div class='expansionContent'/>").appendTo(exp);
    	if(user.editable){
    		$("<b>Actions:</b><br>").appendTo(p2);
    		if(user.role != 'BILLING'){
	    		$("<a class='bind' href='#' title='Manage membership in projects'><img src='/admin/images/link.gif'> Projects</a><br>").appendTo(p2);
	    		$("<a class='bindTargets' href='#' title='Manage targets visibility'><img src='/admin/images/link.gif'> Targets</a><br>").appendTo(p2);
	    		if(user.moveable){
	    			$("<a class='relocate' href='#' title='Relocate this user to another organization'><img src='/admin/images/right.gif'> Relocate</a><br>").appendTo(p2);
	    		}
    		}
    		$("<a class='change' href='#' title='Modify user parameter'><img src='/admin/images/edit.gif'> Modify</a><br>").appendTo(p2);
    		if(user.targets.length > 0)
    			$("<a class='lines' href='#' title='Modify irrigation lines permissions'><img src='/admin/images/line.gif'> Lines</a><br>").appendTo(p2);
    		if(user.removable){
    			$("<a class='remove' href='#' title='Remove this user from the system'><img src='/admin/images/trash.png'> Remove</a><br>").appendTo(p2);
    		}
    	}
    	else if(user.removable){
    		$("<b>Actions:</b><br>").appendTo(p2);
    		$("<a class='remove' href='#' title='Remove this user from the system'><img src='/admin/images/trash.png'> Remove</a><br>").appendTo(p2);
    	}
    	
   		$("<a class='apikey' href='#' title='Generate API Key'><img src='/admin/images/lockedstate.gif'>API Key</a><br>").appendTo(p2);
   		$("<a class='push' href='#' title='Send push notification message'><img src='/admin/images/export.gif'> Send message</a><br>").appendTo(p2);
   		$("<a class='revoke' href='#' title='Revoke push notification tokens'><img src='/admin/images/clear.gif'> Revoke tokens</a><br>").appendTo(p2);
    	
    	if(user.online){
    		$("<a class='logout' href='#' title='Terminate all active sessions of this user'><img src='/admin/images/stop.gif'>Disconnect</a><br>").appendTo(p2);
    	}
    	
    	if(user.projects.length > 0){
	    	var p3 = $("<div class='expansionContent'/>").appendTo(exp);
	    	$("<b>Projects:</b><br>").appendTo(p3);
	    	for(i=0;i<user.projects.length;i++){
	    		var o = user.projects[i];
	    		p3.append("<a href='#' class='pref' oid='" + o.id + "' title='go to project details'>" + o.name + "</a><br>");
	    	}
    	}
    	
    	if(user.targets.length > 0){
	    	var p4 = $("<div class='expansionContent'/>").appendTo(exp);
	    	$("<b>Targets:</b><br>").appendTo(p4);
	    	for(i=0;i<user.targets.length;i++){
	    		var o = user.targets[i];
	    		p4.append("<a href='#' class='tref' oid='" + o.id + "' title='go to target details'>" + o.name + "</a><br>");
	    	}
    	}
    }
    
    function hook(){
		$(addedRow).find("a.tref").click(function(evt){
			evt.preventDefault();
			goto('targets', $(evt.target).attr("oid"));
		});
		$(addedRow).find("a.pref").click(function(evt){
			evt.preventDefault();
			goto('projects', $(evt.target).attr("oid"));
		});
		$(addedRow).find("a.remove").click(function(evt){
			evt.preventDefault();
			remove();
		});
		$(addedRow).find("a.relocate").click(function(evt){
			evt.preventDefault();
			displayRelocation();
		});
		$(addedRow).find("a.change").click(function(evt){
			evt.preventDefault();
			change();
		});
		$(addedRow).find("a.lines").click(function(evt){
			evt.preventDefault();
			lines();
		});
		$(addedRow).find("a.bind").click(function(evt){
			evt.preventDefault();
			bindProjects();
		});
		$(addedRow).find("a.bindTargets").click(function(evt){
			evt.preventDefault();
			bindTargets();
		});
		$(addedRow).find("a.impersonate").click(function(evt){
			evt.preventDefault();
			impersonate();
		});
		$(addedRow).find("a.apikey").click(function(evt){
			evt.preventDefault();
			getApiKey();
		});
		$(addedRow).find("a.push").click(function(evt){
			evt.preventDefault();
			pushMessage();
		});
		$(addedRow).find("a.revoke").click(function(evt){
			evt.preventDefault();
			revokeTokens();
		});
		$(addedRow).find("a.logout").click(function(evt){
			evt.preventDefault();
			logout();
		});
    }

   $("a#addUser").click(function(){
		$.get("rest?method=getProjects&recursive=false", function(data, textStatus, xhr) {
			resetForm($("#newUserForm"));
			var projects = data.projects;
			var select  = $("#newUserForm #pid");
			select.empty();
			
			var option = $('<option>-</option>').appendTo(select);
			option.attr('value', "-");
			
			for(i=0; i<projects.length; i++){
				if(projects[i].name){
					option = $('<option>' + projects[i].name + '</option>').appendTo(select);
					option.attr('value', projects[i].id);
				}
			}
			
			$('#newUserForm #userRole').val("MANAGER");
			$('#newUserForm #userAccess').val("DESKTOP");
			
			$("#newUserDialog").dialog( "open" );
			$("#newUserDialog").dialog( "option", "title", "Add new user");
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	});
	
	$( "#newUserDialog" ).dialog({
		autoOpen: false,
		height: 450,
		width: 450,
		modal: true,
		buttons: {
			"Create": function() {
				var formData = $("#newUserForm").serialize();
				$.post("rest?method=addNewUserToProject&user=true", formData, function(data, textStatus, xhr) {
					goto('users', data.user.id);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
   $("a#broadcast").click(function(){
        $("#progress .message").html("Getting list of affiliates, please stand by...");
        $("#progress img").show();
        $("#progress").dialog( "option", "title", "Progress");
        $("#progress").dialog("open");
   
        $.get("rest?method=getAffiliates&recursive=true", function(data, textStatus, xhr) {
            $("#progress").dialog("close");
            var affs = data.affiliates;
            var select  = $("#broadcastForm").find("#aid");
            select.empty();
            
            var option = $('<option><b>** Everyone on my list **</b></option>').appendTo(select);
            option.attr('value', "");
            
            for(i=0; i<affs.length; i++){
                option = $('<option>' + affs[i].name + '</option>').appendTo(select);
                option.attr('value', affs[i].id);
            }
            
            $("#broadcastDialog").dialog( "open" );
            
        }, "json")
        .error(function(xhr) { 
            $("#progress").dialog("close");
            alert(jQuery.parseJSON(xhr.responseText).error);
        })
    });
	
    $("#broadcastDialog" ).dialog({
        autoOpen: false,
        height: 450,
        width: 600,
        modal: true,
        buttons: {
            "Send": function() {
                $("#progress .message").html("Sending messages, please stand by...");
                $("#progress img").show();
                $("#progress").dialog( "option", "title", "Progress");
                $("#progress").dialog("open");
            	
                var formData = $("#broadcastForm").serialize();
                $.post("rest?method=broadcast", formData, function(data, textStatus, xhr) {
                    $("#progress").dialog( "option", "title", "Done");
                    $("#progress img").hide();
                    $("#progress .message").html(data.response);
                }, "json")
                .error(function(xhr) { 
                	alert(jQuery.parseJSON(xhr.responseText).error);
                })

                $(this).dialog( "close" );
                
            },
            Cancel: function() {
                $( this ).dialog( "close" );
            }
        },
        close: function() {
        }
    });
    
	
	function impersonate(){
		if(!currentUser || !confirm("Would you like to impersonate the affiliate of " + getUserName() + "?"))
			return;
		window.location.href = "impersonate?uid=" + currentUser.impersonator;
	}
	
	function bindProjects(){
		var uid = $(expandedRow).attr('id');
		$("#progress .message").html("Listing projects, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		
		$.get("rest?method=getUserProjectBinding&uid="+uid, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			var binding = data.binding;
			if(binding.length == 0){
				alert("no projects to bind to");
				return;
			}
			
			// create and populate the list
			var span = $('#bindForm #selection');
			span.empty();
            var select = $("<select id='items' name='items' multiple='multiple'></select>").appendTo(span);
			for(i=0; i<binding.length; i++){
				var option = $('<option>' + binding[i].name + '</option>').appendTo(select);
				option.attr('value', binding[i].id);
				if(binding[i].bound)
					option.attr('selected', 'selected');
			}
			
			$(select).multiSelect({
				  keepOrder: true,
				  selectableHeader: "<div class='ms-header'>Available projects:</div>",
				  selectionHeader: "<div class='ms-header'>Member of:</div>",
				});
			
			$("#bindForm input[name='uid']").val(uid);
			$("#bindForm input[name='method']").val("bindUserProjects");
			$("#bindDialog").dialog( "open" );
			$("#bindDialog").dialog( "option", "title", "Participation in projects");
			
			
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	function bindTargets(){
		var uid = $(expandedRow).attr('id');
		$("#progress .message").html("Listing targets, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		
		$.get("rest?method=getUserTargetBinding&uid="+uid, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			var binding = data.binding;
			if(binding.length == 0){
				alert("no targets to bind to");
				return;
			}
			
			var span = $('#bindForm #selection');
			span.empty();
            var select = $("<select id='items' name='items' multiple='multiple' style='width: 100%;'></select>").appendTo(span);
			for(i=0; i<binding.length; i++){
				var option = $('<option>' + binding[i].name + '</option>').appendTo(select);
				option.attr('value', binding[i].id);
				if(binding[i].bound)
					option.attr('selected', 'selected');
			}
			
			$(select).multiSelect({
				  selectableHeader: "<div class='ms-header'>Available controllers:</div>",
				  selectionHeader: "<div class='ms-header'>Currently using:</div>",
				});
			 
			$("#bindForm input[name='uid']").val(uid);
			$("#bindForm input[name='method']").val("bindUserTargets");
			$("#bindDialog").dialog( "open" );
			$("#bindDialog").dialog( "option", "title", "Targets");
			
			
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	function remove(){
		if(confirm("Remove " + getUserName() + " from the system?") == true){
			var uid = $(expandedRow).attr('id');
			$.post("rest?method=removeUser", {'uid' : uid}, function(data, textStatus, xhr) {
				goto('users', "");
			}, "json")
			.error(function(xhr) { 
				alert(jQuery.parseJSON(xhr.responseText).error);
			})
		}
	}

	function displayRelocation(){
		if(!confirm("Relocate user '" + getUserName() + "' to another organization?"))
			return;
		
		var uid = $(expandedRow).attr('id');
		$.get("rest?method=getAffiliates&includeParent=true", function(data, textStatus, xhr) {
			var affiliates = data.affiliates;
			var select  = $("#relocationForm").find("#aid");
			select.empty();
			for(i=0; i<affiliates.length; i++){
				var option = $('<option>' + affiliates[i].name + '</option>').appendTo(select);
				option.attr('value', affiliates[i].id);
			}
			
			$("#relocationForm input[name='uid']").val(uid);
			$("#relocationDialog").dialog( "open" );
			$("#relocationDialog").dialog( "option", "title", "Relocate " + getUserName());
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	function logout(){
		if(confirm("Terminate all active sessions of " + getUserName() + "?") == true){
			var uid = $(expandedRow).attr('id');
			$("#progress .message").html("Terminating user sessions, please stand by...");
			$("#progress").dialog( "option", "title", "Progress");
			$("#progress img").show();
			$("#progress").dialog("open");
			$.post("rest?method=logout", {'uid' : uid}, function(data, textStatus, xhr) {
				$("#progress").dialog("close");
				updateView(data.user);
			}, "json")
			.error(function(xhr) { 
				$("#progress").dialog("close");
				alert(jQuery.parseJSON(xhr.responseText).error);
			})
		}
	}
	
	function getApiKey(){
		var uid = $(expandedRow).attr('id');
		$.get("rest?method=getApiKey", {'uid' : uid}, function(data, textStatus, xhr) {
	        $("#progress .message").html(data.key);
	        $("#progress img").hide();
	        $("#progress").dialog( "option", "title", "REST API Key");
	        $("#progress").dialog("open");
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	function pushMessage(){
		   var message = prompt("What would you like to say to this person:", "");
		   var user = getUserName();
		   if(!user || !message)
			   return;

	       $("#progress .message").html("Sending, please stand by...");
	       $("#progress").dialog( "option", "title", "Progress");
	       $("#progress img").show();
	       $("#progress").dialog("open");
	       
	       var params = {"user": user, "message": message};
		   
	       $.post("rest?method=testPush", params, function(data, textStatus, xhr) {
	    	   $("#progress img").hide();
	    	   $("#progress").dialog( "option", "title", "Done");
	    	   $("#progress .message").html("Test message was successfully sent to push provider.<br>Verify if <b>" + user + "</b> received the notification");
	       }, "json")
	       .error(function(xhr) {
	    	   showProgressError("Failed", xhr);
	       });
	}

	function revokeTokens(){
	   if(!confirm("Revoking notification tokens will block this user from receiving push notification until next login"))
	      return;

	   var uid = $(expandedRow).attr('id');
       $("#progress .message").html("Revoking tokens, please stand by...");
       $("#progress").dialog( "option", "title", "Progress");
       $("#progress img").show();
       $("#progress").dialog("open");
       
       $.post("rest?method=revokeTokens&uid="+uid, null, function(data, textStatus, xhr) {
    	   $("#progress img").hide();
    	   $("#progress").dialog( "option", "title", "Done");
    	   $("#progress .message").html("Tokens are revoked");
       }, "json")
       .error(function(xhr) {
    	   showProgressError("Failed", xhr);
       });
	}
	
	function change(){
		var uid = $(expandedRow).attr('id');
		$.get("rest?method=getUser&uid="+uid, function(data, textStatus, xhr) {
			// setup form stuff before showing
			var user = data.user;
			var hideRole = (user.role == 'ADMIN');
			
			$("#editForm input[name='uid']").val(user.id);
			$("#editForm #username").val(user.userName);
			$("#editForm #password").val(user.password);
			$("#editForm #email").val(user.email);
			$("#editForm #phone").val(user.phone);
            $("#editForm #access").prop('disabled', hideRole);
            $("#editForm #role").prop('disabled', hideRole);
			
	         if(hideRole){
		         $('#editForm #access').closest("tr").hide();
		         $('#editForm #role').closest("tr").hide();
	         }
	         else{
		         $('#editForm #access').closest("tr").show();
		         $('#editForm #role').closest("tr").show();
	            $("#editForm #access").val(user.access);
	            $("#editForm #role").val(user.role);
	         }

			$("#editDialog").dialog( "open" );
			$("#editDialog").dialog( "option", "title", "User record");

		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}

	$( "#editDialog" ).dialog({
		autoOpen: false,
		height: 350,
		width: 450,
		modal: true,
		buttons: {
			"Save": function() {
				var formData = $("#editForm").serialize();
				$.post("rest?method=updateUserRecord", formData, function(data, textStatus, xhr) {
					updateView(data.user);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );

			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});

	function lines(){
		var uid = $(expandedRow).attr('id');
		$.get("rest?method=getUser&uid="+uid, function(data, textStatus, xhr) {
			var user = data.user;
			$("#linesDialog").dialog( "open" );
			$("#linesDialog").dialog( "option", "title", "Line restrictions");
			
			var input = $("<input type='hidden'/>").appendTo($("#linesForm"));
			input.attr("name", "uid");
			input.attr("value", user.id);
			
			var table = $("#targetlines > tbody");
			table.empty();
			for(i=0; i<user.lines.length; i++){
				var row = $("<tr/>").appendTo(table);
				var td = $("<td>" + user.lines[i].target + "</td>").appendTo(row);
				td.css("width", "40%");
				td = $("<td/>").appendTo(row);
				td.css("width", "60%");
				input = $("<input type='text'/>").appendTo(td);
				input.attr("name", "expression." + user.lines[i].serial);
				input.css("display", "table-cell");
				input.css("width", "100%");
				input.attr("value", user.lines[i].expression);
			}

		}, "json")
		.error(function(xhr) {
			alert(jQuery.parseJSON(xhr.responseText).error);
		})
	}
	
	$( "#linesDialog" ).dialog({
		autoOpen: false,
		height: 450,
		width: 600,
		modal: true,
		buttons: {
			"Save": function() {
				var formData = $("#linesForm").serialize();
				$.post("rest?method=updateUserLines", formData, function(data, textStatus, xhr) {
					updateView(data.user);
					$("#linesDialog").dialog("close");
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})
			},
			Cancel: function() {
				$("#linesDialog").dialog("close");
			}
		},
		close: function() {
		}
	});
	
	$( "#bindDialog" ).dialog({
		autoOpen: false,
		height: 420,
		width: 720,
		modal: true,
		buttons: {
			"Submit": function() {
				var formData = $("#bindForm").serialize();
				var method = $("#bindForm input[name='method']").val();
				$.post("rest?method=" + method, formData, function(data, textStatus, xhr) {
					updateView(data.user);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$( "#relocationDialog" ).dialog({
		autoOpen: false,
		height: 250,
		width: 350,
		modal: true,
		buttons: {
			"Relocate": function() {

				$("#progress .message").html("User is being relocated, please wait...");
				$("#progress img").show();
				$("#progress").dialog("open");
				
				var formData = $("#relocationForm").serialize();
				$.post("rest?method=relocateUser", formData, function(data, textStatus, xhr) {
					$("#progress").dialog("close");
					goto("users", data.user.id);
				}, "json")
				.error(function(xhr) { 
					$("#progress").dialog("close");
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$("a#export").click(function(e){
		exportThings("users");
	});

	$('a#query').live('click', function() {
		$("#queryForm #search").val(getQuery("users.query").search);
		$("#queryForm #search").select();
		$("#queryDialog").dialog("open");
	});
	
	$('#queryDialog').keypress(function(e) {
		if (e.keyCode == $.ui.keyCode.ENTER) {
			$(this).dialog("close");
			keepQuery('users.query', $("#queryForm").serializeObject());
			goto("users");
		}
	});

	$( "#queryDialog" ).dialog({
		autoOpen: false,
		height: 300,
		width: 450,
		modal: true,
		buttons: {
			"Find": function() {
				$(this).dialog("close");
				keepQuery('users.query', $("#queryForm").serializeObject());
				goto("users");
			},
			"Reset": function() {
				$(this).dialog( "close" );
				keepQuery('users.query', {});
				goto("users");
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			
		}
	});
	
	function updateView(user){
		currentUser = user;
		$(expandedRow).removeClass("online offline");
		$(expandedRow).find("#ustate").removeClass("online offline")
		$(expandedRow).addClass(user.status);
		$(expandedRow).find("#ustate").addClass(user.status);
		
		$(expandedRow).find("#username").html(user.userName);
		$(expandedRow).find("#achain").html(user.organization);
		$(expandedRow).find("#role").html(user.role);
		$(expandedRow).find("#access").html(user.access);
		$(expandedRow).find("#nofProjects").html(user.projects.length);
				
		// expanded row  
		td = $(expandedRow).find(".expand");
		buildExpandedRow(user);
		addedRow = oTable.fnOpen(expandedRow, $(expandedRow).find(".expansionPanel").html(), "info_row" );
		hook();
	}
	
	function getUserName(){
		return $(expandedRow).find("#username").html();		
	}
});