$(function(){
   $("#tabs").tabs();
   $("#tabs").tabs('select', parseInt($("#stab").val()));
   
   $('.sysform').submit(function() {
       $("#progress .message").html("Sending, please stand by...");
       $("#progress").dialog( "option", "title", "Progress");
       $("#progress img").show();
       $("#progress").dialog("open");
	   
       var formData = $(this).serialize();
       $.post("rest?method=updateSystem", formData, function(data, textStatus, xhr) {
    	   $("#progress img").hide();
    	   $("#progress").dialog( "option", "title", "Done");
    	   $("#progress .message").html("Changes are applied successfully");
       }, "json")
       .error(function(xhr) {
    	   showProgressError("Failed", xhr);
       });
	   
	   return false;
   });
   

   $("a#smtpTest").click(function(){
      var account = $("#account").val();
      var retVal = prompt("Enter e-mail address for a test message:", account);
      if(retVal != null)
         window.location.href = "/admin/smtpTest?to=" + retVal;
   });
   
   $("a#pushToken").click(function(){
	   var token = prompt("Enter device token:", "");
	   if(!token)
		   return;

       $("#progress .message").html("Sending, please stand by...");
       $("#progress").dialog( "option", "title", "Progress");
       $("#progress img").show();
       $("#progress").dialog("open");
	   
       $.post("rest?method=testPush&token=" + token, null, function(data, textStatus, xhr) {
    	   $("#progress img").hide();
    	   $("#progress").dialog( "option", "title", "Done");
    	   $("#progress .message").html("Test message was successfully sent to push provider.");
       }, "json")
       .error(function(xhr) {
    	   showProgressError("Failed", xhr);
       });
  });

   $("a#pushUser").click(function(){
	   var user = prompt("Enter registered user name:", "");
	   if(!user)
		   return;

       $("#progress .message").html("Sending, please stand by...");
       $("#progress").dialog( "option", "title", "Progress");
       $("#progress img").show();
       $("#progress").dialog("open");
	   
       $.post("rest?method=testPush&user=" + user, null, function(data, textStatus, xhr) {
    	   $("#progress img").hide();
    	   $("#progress").dialog( "option", "title", "Done");
    	   $("#progress .message").html("Test message was successfully sent to push provider.<br>Verify if <b>" + user + "</b> received the notification");
       }, "json")
       .error(function(xhr) {
    	   showProgressError("Failed", xhr);
       });
  });
   
   $("a#i18n").click(function(){
       $.post("rest?method=updateSystem&type=i18n", null, function(data, textStatus, xhr) {
    	   $("#progress img").hide();
    	   $("#progress").dialog( "option", "title", "Done");
    	   $("#progress .message").html("Localization cache refreshed successfully");
    	   $("#progress").dialog("open");
       }, "json")
       .error(function(xhr) {
    	   showProgressError("Failed", xhr);
       });
  });

   $("a#syncConnectionStates").click(function(){
	   $("#progress img").show();
	   $("#progress").dialog( "option", "title", "Please wait");
	   $("#progress .message").html("Synchronizing states, hold on...");
	   $("#progress").dialog("open");
	   
       $.post("rest?method=updateSystem&type=syncConnectionStates", null, function(data, textStatus, xhr) {
    	   $("#progress img").hide();
    	   $("#progress").dialog( "option", "title", "Done");
    	   $("#progress .message").html("Connection states synchronized successfully");
    	   $("#progress").dialog("open");
       }, "json")
       .error(function(xhr) {
    	   showProgressError("Failed", xhr);
       });
  });
   
   $("a#offenders").click(function(){
        $.get("rest?method=getBlacklist", function(data, textStatus, xhr) {
            var blacklist = data.blacklist;
            if(blacklist.length == 0){
                alert("Nothing blocked at the moment");
                return;
            }
            var select  = $("#offendersForm").find("#offenders");
            select.empty();
            for(i=0; i<blacklist.length; i++){
                var option = $('<option>' + blacklist[i] + '</option>').appendTo(select);
                option.attr('value', blacklist[i]);
            }
            
            $("#offendersDialog").dialog("open");
        }, "json")
        .error(function(xhr) { 
        	alert(jQuery.parseJSON(xhr.responseText).error); 
        })
   });
   
   $("a.toggleCron").click(function(e){
	   var link = findLink(e);
       $.post("rest?method=toggleCronTrigger&name=" + link.attr("id"), null, function(data, textStatus, xhr) {
    	   if(data.paused){
    		   link.html("<img src='/admin/images/start.gif'>");
    		   link.attr('title', "Click here to resume this cron");
    	   }
    	   else{
    		   link.html("<img src='/admin/images/pause.gif'>");
    		   link.attr('title', "Click here to pause this cron");
    	   }
    	   
       }, "json")
       .error(function(xhr) {
    	   alert(jQuery.parseJSON(xhr.responseText).error); 
       });
   });

   $("a.toggleReports").click(function(e){
	   var link = findLink(e);
       $.post("rest?method=toggleReports", null, function(data, textStatus, xhr) {
    	   if(data.enabled){
    		   link.html("<img src='/admin/images/pause.gif'>");
    		   link.attr('title', "Click here to pause reporting service");
    		   $(".reportsLabel").val("enabled");
    	   }
    	   else{
    		   link.html("<img src='/admin/images/start.gif'>");
    		   link.attr('title', "Click here to resume reporting service");
    		   $(".reportsLabel").val("disabled");
    	   }
    	   
       }, "json")
       .error(function(xhr) {
    	   alert(jQuery.parseJSON(xhr.responseText).error); 
       });
   });
   
    $('#broadcastMessage').submit(function() {
        $("#progress .message").html("Sending emails, please stand by...");
        $("#progress img").show();
        $("#progress").dialog( "option", "title", "Progress");
        $("#progress").dialog("open");
        
        var formData = $('#broadcastMessage').serialize();    
        $.post("rest?method=pushMessage", formData, function(data, textStatus, xhr) {
            $("#progress").dialog( "option", "title", "Done");
            $("#progress img").hide();
            $("#progress .message").html(data.response);
        }, "json")
        .error(function(xhr) { 
        	showProgressError("Failed", xhr);
        })
            
        return false;
    });
   
    $("#offendersDialog" ).dialog({
        autoOpen: false,
        height: 350,
        width: 480,
        modal: true,
        title: "Firewall block list",
        buttons: {
            "Unblock selected": function() {
                $(this).dialog( "close" );
                var formData = $("#offendersForm").serialize();
                $.post("rest?method=whitelist", formData, function(data, textStatus, xhr) {
                    alert("OK");
                }, "json")
                .error(function(xhr) { 
                	alert(jQuery.parseJSON(xhr.responseText).error); 
                })
            },
            "Unblock all": function() {
                $(this).dialog( "close" );
                $.post("rest?method=whitelist", null, function(data, textStatus, xhr) {
                    alert("OK");
                }, "json")
                .error(function(xhr) { 
                    json = jQuery.parseJSON(xhr.responseText);
                    alert(json.error); 
                })
            },
            Cancel: function() {
                $( this ).dialog( "close" );
            }
        },
        close: function() {
        }
    });
   
    $("#progress").dialog({
        autoOpen: false,
        height: 250,
        width: 500,
        modal: true,
        buttons: {
            "Hide": function() {
                $(this).dialog( "close" );
            },
        },
        close: function() {
        }
    });
   
	function findLink(event){
		var link = $(event.target);
		if(!link.attr("href")){
			link = link.parent();
			if(!link.attr("href"))
				link = link.parent();
		}
		return link; 
	}
    
});