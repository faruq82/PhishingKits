$(function(){
	$.ajaxSetup ({
		cache: false
	});

	$("#from").datepicker({dateFormat: "dd-M-y"});
	$("#until").datepicker({dateFormat: "dd-M-y"});
	$("#from2").datepicker({dateFormat: "dd-M-y"});
	$("#until2").datepicker({dateFormat: "dd-M-y"});
	
	var oTable = $('#stuff').dataTable({
		"sAjaxSource" : makeQueryUrl(),
		"aoColumns" : [{"mData" : "id"}, {"mData" : "time", "sType": "time"}, {"mData" : "reference"}, {"mData" : "affiliate"}, {"mData" : "operation"}],
		"fnRowCallback" : rowCallback,
		"fnInitComplete": initCallback, 
		"bJQueryUI": true,
		"bPaginate": true,
		"bFilter": true,
		"bLengthChange": true,
		"iDisplayLength" : 25,
		"aaSorting": [[ 1, "asc"]],
		"bStateSave": false,
		"fnStateSave": function (oSettings, oData) {
			localStorage.setItem( 'DataTables_'+window.location.pathname, JSON.stringify(oData) );
		},
		"fnStateLoad": function (oSettings) {
			return JSON.parse( localStorage.getItem('DataTables_'+window.location.pathname) );
		},
		"oLanguage": {
			"sLoadingRecords" : "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i> getting the data, please wait...",
			"sSearch": "Global filter:",
			"sEmptyTable": "<br><p align='center'>No records matching specified criteria.<br><a id='query' href='#'>Click here for the query</a><br><br></p>"
		}
	});		

	function rowCallback(nRow, aData, iDisplayIndex){
		$('td:eq(0)', nRow).html("").addClass('expand');
		$(nRow).attr("id", aData.id);
		if(aData.editable){
			var td = $('td:eq(2)', nRow);
			var a = $("<a href='#' id='qref'>" + aData.reference + "</a>").appendTo(td);
			td.html(a);
			
			$(a).click(function(evt) {
				evt.preventDefault();
				modifyReference(aData, evt.target);
			});
		}
	}

	function initCallback(oSettings, json){
		var actions = ["leased", "reclaimed"];
		var affiliates = new Array();
		for(var i = 0; i < json.aaData.length; i++){
			var aff = json.aaData[i].affiliate;
			if(aff.length > 0 && jQuery.inArray(aff, affiliates) == -1){
				affiliates.push(aff);
			}
		}
		
	    $(".cfilter").each( function ( i ) {
	    	var column = $(this).parent().children().index($(this)) + 2; // span adjust
	        this.innerHTML = fnCreateSelect( i == 0 ? affiliates : actions );
	        $('select', this).change( function () {
	            oTable.fnFilter( $(this).val(), column );
	        } );
	    } );
		
		var query = getQuery('billing.query');
	    $('#range-label').html(query.from + "  <i class='fa fa-angle-double-right text-side'></i>  " + query.until);
	}

	jQuery.fn.dataTableExt.oSort['time-asc']  = function(v1,v2) {
		var x = string2time(v1);
		var y = string2time(v2);
	    return ((x < y) ? -1 : ((x > y) ?  1 : 0));
	};
	 
	jQuery.fn.dataTableExt.oSort['time-desc'] = function(v1,v2) {
		var x = string2time(v1);
		var y = string2time(v2);
	    return ((x < y) ?  1 : ((x > y) ? -1 : 0));
	};	
	
	function string2time(string){
		var parts = string.split(' ');
		var d = parts[0].split('-');
		var t = parts[1].split(':');
		return new Date(d[2]+2000, d[1], d[0], t[0], t[1], t[2]).getTime();
	}
	
	$("a#export").click(function(e){
		if(!confirm("Export this data to Excel file?"))
			return;
		$("#progress .message").html("Generating report, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
	
		$.get(makeExportUrl(), function(data, textStatus, xhr) {
			$("#progress").dialog( "option", "title", "Done");
			$("#progress img").hide();
			$("#progress .message").html("<a href='" + data.link + "' target='new'>click here to download report</a>");
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
			return;
		})
	});
	
   $('td.expand').live('click', function() {
		var row = $(this).parent("tr").get(0);
		if (oTable.fnIsOpen(row)) {
			oTable.fnClose(row);
		} 
		else {
		    oTable.fnOpen(row, "<img class='lazyload' src='../admin/images/progress.gif'/>", "info_row" );
			$.get("rest?method=getQuotaRecord&rid=" + $(row).attr("id"), function(data, textStatus, xhr) {
					expandRow(row, data.record);
				}, "json")
			.error(function(xhr) {
				alert(jQuery.parseJSON(xhr.responseText).error);
				oTable.fnClose(row);
			})
		}
	});
   
   function expandRow(row, record){
	   	var td = $(row).find(".expand");
		$(td).empty();
		
    	var exp = $("<div class='expansionPanel'/>").appendTo(td);
    	var panel = $("<div class='expansionContent'/>").appendTo(exp);
    	populateContent(panel, record.licenses, "Project:", "PROJECT");
    	panel = $("<div class='expansionContent'/>").appendTo(exp);
    	populateContent(panel, record.licenses, "User:", "USER");
    	panel = $("<div class='expansionContent'/>").appendTo(exp);
    	populateContent(panel, record.licenses, "Target:", "TARGET");
    	oTable.fnOpen(row, $(row).find(".expansionPanel").html(), "info_row" );
   }
   
   function populateContent(parent, licenses, label, product){
	   $("<b>" + label + "</b><br>").appendTo(parent);
	   var table = $("<table/>").appendTo(parent);
	   for(var i=0; i < licenses.length; i++){
		   if(licenses[i].product == product){
			   var row = $("<tr/>").appendTo(table);
			   var td  = $("<td/>").appendTo(row);
			   td.html(licenses[i].title);
			   td.addClass(licenses[i].title.toLowerCase());
			   
			   td = $("<td/>").appendTo(row);
			   td.html(licenses[i].amount);
			   td.addClass(licenses[i].title.toLowerCase());
		   }
	   }
   }

	function modifyReference(aData, link){
		var ref = prompt("New reference text:", aData.reference);
		if(!ref)
			return;
		
		$("#progress .message").html("Updating, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		
		$.get("rest?method=updateQuotaRef&id=" + aData.id + "&ref=" + encodeURIComponent(ref), null,function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			$(link).html(ref);
			aData.reference = ref;
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
			return;
		})
	}

	$('a#query').live('click', function() {
		$("#progress .message").html("Getting list of affiliates, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");

		$.get("rest?method=getAffiliates", function(data, textStatus, xhr) {
			var affiliates = data.affiliates;
			var select  = $("#queryForm").find("#aid");
			select.empty();
			
			$('<option>Any</option>').appendTo(select);
			for(i=0; i<affiliates.length; i++){
				var option = $('<option>' + affiliates[i].name + '</option>').appendTo(select);
				option.attr('value', affiliates[i].id);
			}
			
			var data = getQuery('billing.query');
			if(data != null){
				$.each(data, function(name, val){
				    var $el = $('[name="'+name+'"]'),
				        type = $el.attr('type');
				    $el.val(val);
				});			
			}

			$("#progress").dialog("close");
			$("#queryDialog" ).dialog("open");
			
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	});
	
	function makeQueryUrl(){
		var query = getQuery('billing.query');
		return "rest?method=getBilling&aid=" + query.aid + 
		             "&ref=" + query.ref + "&from=" + query.from + "&until=" + query.until;
	}

	function makeExportUrl(){
		var query = getQuery('billing.query');
		return "rest?method=export&type=billing&aid=" + query.aid + 
		             "&ref=" + query.ref + "&from=" + query.from + "&until=" + query.until;
	}
	
	$("a#usage").click(function(){
		$("#progress .message").html("Getting list of affiliates, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");
		
		$.get("rest?method=getAffiliates&namesOnly=true", function(data, textStatus, xhr) {
			var affiliates = data.affiliates;
			var select  = $("#usageForm").find("#aid");
			select.empty();
			
			$('<option>All</option>').appendTo(select);
			for(i=0; i<affiliates.length; i++){
				var option = $('<option>' + affiliates[i].name + '</option>').appendTo(select);
				option.attr('value', affiliates[i].id);
			}

			var data = getQuery('billing.usage');
			$.each(data, function(name, val){
				var $el = $('[name="'+name+'"]'),
					type = $el.attr('type');
				$el.val(val);
			});			

			$("#progress").dialog("close");
			$("#usageDialog" ).dialog( "open" );
			
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	});
	
	function getUsageReport(){
		$("#progress .message").html("Generating usage report, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress img").show();
		$("#progress").dialog("open");

		keepQuery('billing.usage', $("#usageForm").serializeObject());
		var formData = $("#usageForm").serialize();
		$.get("rest?method=export&type=usage",formData,function(data, textStatus, xhr) {
			$("#progress").dialog( "option", "title", "Done");
			$("#progress img").hide();
			$("#progress .message").html("<a href='" + data.link + "' target='new'>click here to download report</a>");
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error); 
			return;
		})
	}
	
	$("#progress").dialog({
		autoOpen: false,
		height: 250,
		width: 500,
		modal: true,
		buttons: {
			"Hide": function() {
				$(this).dialog( "close" );
			},
		},
		close: function() {
		}
	});
	
	$( "#queryDialog" ).dialog({
		autoOpen: false,
		height: 350,
		width: 450,
		modal: true,
		buttons: {
			"Go get it!": function() {
				keepQuery('billing.query', $("#queryForm").serializeObject());
				$(this).dialog( "close" );
				window.location.href = "billing?" + $("#queryForm").serialize();
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			
		}
	});
	
	$( "#usageDialog" ).dialog({
		autoOpen: false,
		height: 350,
		width: 450,
		modal: true,
		buttons: {
			"Go get it!": function() {
				$(this).dialog( "close" );
				getUsageReport();
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			
		}
	});
});