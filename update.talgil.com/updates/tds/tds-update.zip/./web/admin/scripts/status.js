$(function() {
	var state, expandUsers = false;
	window.setTimeout(function() {
		 updateServerState();
	}, 5000);
	
	function updateServerState(){
		$.get("rest?method=getServerState", function(data, textStatus, xhr) {
			state = data.state;
			drawClusterState(state.clusterState);
			drawLoggerState(state.verboseLog)
			drawState($('#nodeAction'), state.nodeAction);
			drawState($('#currentTime'), state.currentTime);
			drawState($('#uptime'), state.uptime);
			drawState($('#memory'), state.memory);
			drawState($('#threads'), state.nofThread);
			drawUsers();
			drawState($('#nofTargets'), state.nofTargetSessions);
			drawState($('#inflow'), state.inflow);
			drawState($('#outflow'), state.outflow);
			drawState($('#datalogRecords'), state.datalogRecords);
			drawState($('#datalogStorage'), state.datalogStorage);
			drawState($('#retention'), state.retentionProgress ? "<i class='fa fa-fw fa-lg fa-cog text-danger fa-spin'></i>" : "");
			
			window.setTimeout(function() {
				 updateServerState();
			}, 5000);
			
		}, "json")
		.error(function(xhr){
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}
	
	function drawState(span, state){
		if(!span)
			return;
		span.html(state);
		span.addClass("state-flush");
		
		setTimeout(function() {
			span.removeClass("state-flush", 600 );
		}, 500);
	}
	
	function drawClusterState(nodes){
		var span = $('#nodeState');
		if(!span || !nodes)
			return;
		var content = "";
		for(var i=0;i<nodes.length;i++){
			if(content)
				content += "<br>";
			var color = nodes[i].active ? "green" : "gray";
			content += ("<font color='" + color + "'>" + nodes[i].address + "</font>");
			if(nodes[i].action){
				content += ("&nbsp(<a href='#' class='node' node.address='" + nodes[i].address + "' node.state='" + nodes[i].state + "'>" + nodes[i].action + "</a>)");				
			}
		}
		
		span.html(content);
		$(span).find("a.node").click(function(e){
		   e.preventDefault();
		   toggleNode($(e.target));
		});
	}
	
	function toggleNode(link){
		var addr = link.attr("node.address");
		var state = link.attr("node.state");
    	if(!confirm("This will " + (state == "ACTIVE"?"de-activate ":"activate ") + addr + " in the cluster.\nAre you sure you want to continue?\n"))
    		return false;
    		
    	$("#progress .message").html("Updating node state, please stand by...");
    	$("#progress").dialog("open");
    	var address = encodeURIComponent(addr);
		$.get("rest?method=toggleNode&address=" + address, function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			drawClusterState(data.state.clusterState);
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
			return;
		})

		return false;
    }

	function drawLoggerState(verbose){
		if($("#toggleLog")){
			$("#toggleLog").removeClass("hidden");
			$("#logIcon").attr("class", "fa text-side fa-toggle-" + (verbose ? "on" : "off"));
		}
		drawState($('#verbose'), verbose ? "Verbose" : "Normal");
	}

	$("a#toggleLog").click(function(e){
		$.get("rest?method=toggleInternalLog", function(data, textStatus, xhr) {
			drawLoggerState(data.state.verboseLog);
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
			return;
		})

		return false;
	});

	$("a#toggleUsers").click(function(e){
		expandUsers = !expandUsers;
		console.log("expandUsers=" + expandUsers);
		drawUsers();
		return false;
	});
	
	function drawUsers(){
		$("#toggleUsers").removeClass("hidden");
		$("#usersIcon").attr("class", "fa text-side fa-toggle-" + (expandUsers ? "on" : "off"));
		drawState($('#nofUsers'), "web: " + state.webUsers.length + ", console: " + state.consoleUsers.length);
		
		if(expandUsers){
			$("#row-web-users").removeClass("hidden");
			$("#row-con-users").removeClass("hidden");
			drawState($('#webUsers'), state.webUsers.join(", "));
			drawState($('#consoleUsers'), state.consoleUsers.join(", "));
		}
		else{
			$("#row-web-users").addClass("hidden");
			$("#row-con-users").addClass("hidden");
		}
	}
	
	$("a#locate").click(function(e){
	   window.open("/maps/target?navigation=true&controls=true&drag=true&mapType=terrain", "My locations");
	});
	
    $("a#restart").click(function() {
        if (confirm("This will restart the server and put it temporaly offline.\nYou will have to reload this admin page after restart is complete.\nAre you sure you want to continue?\n") == true) {
            window.location.href = this.attribute("href");
            return true;
        }
        return false;
    });

    $("a#recount").click(function() {
    	$("#progress .message").html("Recounting datalog sizes, please stand by...");
		$.get("rest?method=recount", function(data, textStatus, xhr) {
			$("#progress").dialog("close");
			drawState($('#datalogRecords'), data.state.datalogRecords);
			drawState($('#datalogStorage'), data.state.datalogStorage);
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error);
			return;
		})

		return false;
    });
    
    $("a#getlog").click(function(e){
		if(!confirm("Download log file?"))
			return;
		$("#progress .message").html("Getting logs, please stand by...");
		$("#progress").dialog( "option", "title", "Progress");
		$("#progress").dialog("open");
	  
		$.get("rest?method=export&type=log", function(data, textStatus, xhr) {
			$("#progress").dialog( "option", "title", "Done");
			$("#progress .message").html("<a href='" + data.link + "' target='new'>click here to download the log file</a>");
		}, "json")
		.error(function(xhr) { 
			$("#progress").dialog("close");
			alert(jQuery.parseJSON(xhr.responseText).error);
			return;
		})
    });
    
    $("a#memstats").click(function() {
        $("#chartDialog").dialog("open");
        $("#chartDialog").dialog("option", "title", "Last 14 days of JVM utilization");
        $("#chart").empty();
        $("#chart").html("hang on, loading performance data... <img src='/admin/images/anim.gif'>");

        $.get("rest?method=getObservations&series=performance", function(data, textStatus, xhr) {
            var observed = data.observations;
            if (observed == 0) {
                $("#chartDialog").dialog("close");
                alert("No data is available");
                return;
            }

            var used = new Array();
            var threads = new Array();
            for (i = 0; i < observed.length; i++) {
                var o = new Array();
                o.push(observed[i].time, observed[i].memoryUsed);
                used.push(o);

                o = [];
                o.push(observed[i].time, observed[i].threads);
                threads.push(o);
            }

            window.chart = new Highcharts.StockChart({
                chart: {
                    renderTo: 'chart',
                    zoomType: 'xy'
                },
                credits: {
                    enabled: false
                },
                rangeSelector: {
                    selected: 0,
                    buttons: [{
                        type: 'day',
                        count: 1,
                        text: '1d'
                    }, {
                        type: 'day',
                        count: 2,
                        text: '2d'
                    }, {
                        type: 'all',
                        text: 'All'
                    }]
                },
                title: {
                    text: ''
                },
                yAxis: [{
                    labels: {
                        formatter: function() {
                            return this.value + ' MB';
                        }
                    },
                    title: {
                        text: 'Used memory'
                    }
                }, {
                    title: {
                        text: 'Threads',
                        style: {
                            color: '#FF3E3E'
                        }
                    },
                    labels: {
                        formatter: function() {
                            return this.value;
                        },
                        style: {
                            color: '#FF3E3E'
                        }
                    },
                    opposite: true
                }],
                series: [{
                    name: 'Used memory (MB)',
                    data: used,
                    tooltip: {
                        valueDecimals: 1
                    },
                    type: 'spline',
                    lineWidth: 4,
                    yAxis: 0
                }, {
                    name: 'Thread count',
                    data: threads,
                    tooltip: {
                        valueDecimals: 0
                    },
                    color: '#FF3E3E',
                    lineWidth: 1,
                    type: 'spline',
                    yAxis: 1
                }]
            });

        }, "json").error(function(xhr) {
        	alert(jQuery.parseJSON(xhr.responseText).error);
        })
    });

    $("a#dstats").click(function() {
        $("#chartDialog").dialog("open");
        $("#chartDialog").dialog("option", "title", "Total data volumes between server and all targets");
        $("#chart").empty();
        $("#chart").html("hang on, loading performance data... <img src='/admin/images/anim.gif'>");

        $.get("rest?method=getObservations&series=performance", function(data, textStatus, xhr) {
            var observed = data.observations;
            if (observed == 0) {
                $("#chartDialog").dialog("close");
                alert("No data is available");
                return;
            }

            var inflow = new Array();
            var outflow = new Array();
            for (i = 0; i < observed.length; i++) {
                var o = new Array();
                o.push(observed[i].time, observed[i].targetsInfow);
                inflow.push(o);

                o = [];
                o.push(observed[i].time, observed[i].targetsOutflow);
                outflow.push(o);
            }

            window.chart = new Highcharts.StockChart({
                chart: {
                    renderTo: 'chart',
                    zoomType: 'xy'
                },
                credits: {
                    enabled: false
                },
                rangeSelector: {
                    selected: 0,
                    buttons: [{
                        type: 'day',
                        count: 1,
                        text: '1d'
                    }, {
                        type: 'day',
                        count: 2,
                        text: '2d'
                    }, {
                        type: 'all',
                        text: 'All'
                    }]
                },
                title: {
                    text: ''
                },
                yAxis: [{
                    labels: {
                        formatter: function() {
                            return Highcharts.numberFormat(this.value / 1024, 0) + ' kB';
                        }
                    },
                    title: {
                        text: 'Inflow and Outflow'
                    }
                }],
                series: [{
                    name: 'Received from targets (bytes)',
                    data: inflow,
                    type: 'spline',
                    lineWidth: 1,
                    tooltip: {
                        valueDecimals: 0
                    },
                    yAxis: 0
                }, {
                    name: 'Sent to targets (bytes)',
                    data: outflow,
                    color: '#FF3E3E',
                    lineWidth: 1,
                    type: 'spline',
                    tooltip: {
                        valueDecimals: 0
                    },
                    yAxis: 0
                }]
            });

        }, "json").error(function(xhr) {
        	alert(jQuery.parseJSON(xhr.responseText).error);
        })
    });

    $("a#sstats").click(function() {
        $("#chartDialog").dialog("open");
        $("#chartDialog").dialog("option", "title", "Users and controller sessions");
        $("#chart").empty();
        $("#chart").html("hang on, loading metrics... <img src='/admin/images/anim.gif'>");

        $.get("rest?method=getObservations&series=performance", function(data, textStatus, xhr) {
            var observed = data.observations;
            if (observed == 0) {
                $("#chartDialog").dialog("close");
                alert("No data is available");
                return;
            }

            var targets = new Array();
            var users = new Array();
            for (i = 0; i < observed.length; i++) {
                var o = new Array();
                o.push(observed[i].time, observed[i].targetSessions);
                targets.push(o);

                o = [];
                o.push(observed[i].time, observed[i].userSessions);
                users.push(o);
            }

            window.chart = new Highcharts.StockChart({
                chart: {
                    renderTo: 'chart',
                    zoomType: 'xy'
                },
                credits: {
                    enabled: false
                },
                rangeSelector: {
                    selected: 0,
                    buttons: [{
                        type: 'day',
                        count: 1,
                        text: '1d'
                    }, {
                        type: 'day',
                        count: 2,
                        text: '2d'
                    }, {
                        type: 'all',
                        text: 'All'
                    }]
                },
                title: {
                    text: ''
                },
                yAxis: [{
                    labels: {
                        formatter: function() {
                            return Highcharts.numberFormat(this.value, 0);
                        }
                    },
                    title: {
                        text: 'Target sessions'
                    }
                }, {
                    title: {
                        text: 'User sessions',
                        style: {
                            color: '#FF3E3E'
                        }
                    },
                    labels: {
                        formatter: function() {
                            return Highcharts.numberFormat(this.value, 0);
                        },
                        style: {
                            color: '#FF3E3E'
                        }
                    },
                    opposite: true
                }],
                series: [{
                    name: 'Targets',
                    data: targets,
                    tooltip: {
                        valueDecimals: 0
                    },
                    type: 'spline',
                    lineWidth: 4,
                    yAxis: 0
                }, {
                    name: 'Users',
                    data: users,
                    tooltip: {
                        valueDecimals: 0
                    },
                    color: '#FF3E3E',
                    lineWidth: 1,
                    type: 'spline',
                    yAxis: 1
                }]
            });

        }, "json").error(function(xhr) {
        	alert(jQuery.parseJSON(xhr.responseText).error);
        })
    });

    $("#chartDialog").dialog({
        autoOpen: false,
        height: 550,
        width: 800,
        modal: true,
        resizable: false,
        buttons: {
            "Close": function() {
                $(this).dialog("close");
            }
        }
    });
    
	$("#progress").dialog({
		autoOpen: false,
		height: 250,
		width: 500,
		modal: true,
		buttons: {
			"Hide": function() {
				$(this).dialog( "close" );
			},
		},
		close: function() {
		}
	});
    
});