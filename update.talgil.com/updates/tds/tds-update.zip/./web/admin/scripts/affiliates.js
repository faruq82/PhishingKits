$(function(){
	var expandedRow;
	var addedRow;
	var currentAffiliate;
	
	$.ajaxSetup ({
		cache: false
	});

	var oTable = $('#stuff').dataTable({
		"sAjaxSource" : makeQueryUrl(),
		"aoColumns" : [{"mData" : "id"}, {"mData" : "contact"}, {"mData" : "chain"}, {"mData" : "country"}],
		"fnRowCallback" : rowCallback,
		"fnInitComplete": initCallback, 
		"bJQueryUI": true,
		"bPaginate": true,
		"bFilter": true,
		"aaSorting": [[ 1, "asc" ]],
		"bLengthChange": true,
		"iDisplayLength" : 25,
		"bStateSave": false,
		"fnStateSave": function (oSettings, oData) {
			localStorage.setItem( 'DataTables_'+window.location.pathname, JSON.stringify(oData) );
		},
		"fnStateLoad": function (oSettings) {
			return JSON.parse( localStorage.getItem('DataTables_'+window.location.pathname) );
		},
		"oLanguage": {
			"sLoadingRecords" : "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i> getting the data, please wait...",
			"sSearch": "Global filter:",
			"sEmptyTable": "<br><p align='center'>You don't have any Affiliates defined.<br>Click here to <a id='addAffiliate' href='#'>add new affiliate</a> now<br><br></p>"
		}
	});
	
	function rowCallback(nRow, aData, iDisplayIndex){
		$(nRow).attr("id", aData.id);
		$(nRow).attr("auid", aData.contactId);
		
		$('td:eq(0)', nRow).html("").addClass('expand');
		$('td:eq(1)', nRow).attr("id", "auser");
		$('td:eq(2)', nRow).attr("id", "achain");
		$('td:eq(3)', nRow).attr("id", "acountry");
	}

	function initCallback(oSettings, json){
		$(".toolbar").show();
		
		var query = getQuery('affiliates.query');
		if(query.oid){
			query.oid = "";
			keepQuery('affiliates.query', query);
			expandRow($("#stuff tbody tr").get(0));
			return;
		}

		var affiliates = new Array();
		var countries = new Array();
		for(var i = 0; i < json.aaData.length; i++){
			var value = json.aaData[i].chain;
			if(value.length > 0 && jQuery.inArray(value, affiliates) == -1)
				affiliates.push(value);
			value = json.aaData[i].country;	
			if(value.length > 0 && jQuery.inArray(value, countries) == -1)
				countries.push(value);
		}
		
	    $(".cfilter").each(function(i){
			var column = $(this).parent().children().index($(this));
			switch(column){
				case 2:
					this.innerHTML = fnCreateChainSelect(affiliates);
				break;	
				case 3:
					this.innerHTML = fnCreateSelect(countries);
				break;	
			}

	        $('select', this).change( function () {
				if($(this).val() == 'My affiliates only')
					oTable.fnFilter("^[^/]+$" , column, true );
				else
					oTable.fnFilter( $(this).val(), column );
	        });
	    } );
	}

	function makeQueryUrl(){
		var query = getQuery('affiliates.query');
		return "rest?method=listAffiliates&search=" + query.search + "&oid=" + query.oid;
	}	

	$("a#refresh").click(function(){
		goto("affiliates");
	});
	
	$("a#resetFilters").click(function(){
	    $(".cfilter").each( function ( i ) {
	    	var column = $(this).parent().children().index($(this));
	    	var select = $(this).find('select');
	    	$(select).val("Show all");
	    	oTable.fnFilter( $(select).val(), column );
	    });
	});
    
    $('td.expand').live('click', function(event) {
    	expandRow($(this).parent("tr").get(0));
	});
	
    function expandRow(row){
		if (oTable.fnIsOpen(row)) {
			oTable.fnClose(row);
			expandedRow = null;
			return;
		} 
		
		if(expandedRow != null)
			oTable.fnClose(expandedRow);
		expandedRow = row;
		oTable.fnOpen(expandedRow, "<i class='fa fa-spinner fa-pulse fa-2x fa-fw text-side'></i>", "info_row" );
		
		var aid = $(expandedRow).attr('id');
		$.get("rest?method=getAffiliate&aid="+aid, function(data, textStatus, xhr) {
			buildExpandedRow(data.affiliate);
			addedRow = oTable.fnOpen(expandedRow, $(expandedRow).find(".expansionPanel").html(), "info_row" );
			hook();
		}, "json")
		.error(function(xhr){
			alert(jQuery.parseJSON(xhr.responseText).error); 
			oTable.fnClose(expandedRow);
		})
    }
    
    function buildExpandedRow(affiliate){
		var td = $(expandedRow).find(".expand");
		$(td).empty();

    	currentAffiliate = affiliate;
		var image = "/admin/images/affiliate.png";
    	var exp = $("<div class='expansionPanel'/>").appendTo(td);
    	var p1 = $("<div class='expansionContent'/>").appendTo(exp);
    	if(affiliate.impersonateable)
    		$("<a class='impersonate' href='#' title='click to impersonate'><img src='" + image + "'/></a>").appendTo(p1);
    	else
    		$("<img src='" + image + "'/>").appendTo(p1);
    	
    	var contacts = affiliate.contact.split(',').join("<br>");
        p1.append("<br>" + contacts);
    	
    	var p2 = $("<div class='expansionContent'/>").appendTo(exp);
    	if(affiliate.editable){
    		$("<a class='addQuota' href='#'><img src='/admin/images/dollar.png'> Adjust quota</a><br>").appendTo(p2);
    		$("<a class='editAffiliate' href='#'><img src='/admin/images/edit.gif'> Modify record</a><br>").appendTo(p2);
    		if(affiliate.multipleContacts)
    			$("<a class='addUser' href='#'><img src='/admin/images/contacts.png'> Add affiliate user</a><br>").appendTo(p2);
    		$("<a class='removeAffiliate' href='#'><img src='/admin/images/trash.png'> Remove</a>").appendTo(p2);
    	}
    	else if(affiliate.multipleContacts){
    		$("<a class='addUser' href='#'><img src='/admin/images/contacts.png'> Add affiliate user</a><br>").appendTo(p2);
    	}
    	
		var aquota = affiliate.allocated;
		var uquota = affiliate.used;
		var actual = affiliate.actualized;
		if(aquota.length == 0)
			return;
    	
    	var p3 = $("<div class='expansionContent'/>").appendTo(exp);
		var table = $("<table style='font-size: 90%;'/>").appendTo(p3);
    	var row = $("<tr/>").appendTo(table);
    	$("<td><b>Quota</b></td>").appendTo(row);
    	$("<td><b>Ordered</b></td>").appendTo(row);
    	$("<td><b>Used</b></td>").appendTo(row);
    	$("<td><a class='usage' href='#' title='Click to calculate usage'><b>Actual</b></a></td>").appendTo(row);
    	for(var i=0; i<aquota.length; i++){
    		if(aquota[i].amount == 0)
    			continue;
    		row = $("<tr/>").appendTo(table);
    		var cls = aquota[i].device.toLowerCase();
        	$("<td>" + aquota[i].title + "</td>").addClass(cls).appendTo(row);
        	$("<td>" + aquota[i].amount + "</td>").addClass(cls).appendTo(row);
        	$("<td>" + uquota[i].amount + "</td>").addClass(cls).appendTo(row);
        	$("<td><span class='usage' id='quota-usage-" + i + "'></span></td>").addClass(cls).appendTo(row);
    	}
    }

    function hook(){
		$(addedRow).find("a.addQuota").click(function(evt){
			evt.preventDefault();
			quote();
		});
		$(addedRow).find("a.editAffiliate").click(function(evt){
			evt.preventDefault();
			edit();
		});
		$(addedRow).find("a.removeAffiliate").click(function(evt){
			evt.preventDefault();
			remove();
		});
		$(addedRow).find("a.addUser").click(function(evt){
			evt.preventDefault();
			addUser();
		});
		$(addedRow).find("a.impersonate").click(function(evt){
			evt.preventDefault();
			impersonate();
		});
		$(addedRow).find("a.usage").click(function(evt){
			evt.preventDefault();
			calcUsage();
		});
    }
    
	function calcUsage(){
		var aid = $(expandedRow).attr('id'); 
		
		$("a.usage").parent().html("<b>Actual</b>");
		$("span.usage").filter(function() {
	        return this.id.match(".*usage.*");
	    }).html("calculating");
		
		$.get("rest?method=getQuota&usage=true&aid="+aid, function(data, textStatus, xhr) {
			var usage = data.usage;
			for(var i=0; i<usage.length; i++){
				$(addedRow).find("#quota-usage-"+i).html(usage[i].amount);
			}
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}
    
	function impersonate(){
		if(confirm("Would you like to impersonate " + getAffiliateName() + "?") == true){
			var uid = $(expandedRow).attr("auid");
			window.location.href = "impersonate?uid=" + uid;
		}
	}
	
	function remove(){
		if(confirm("Are you sure you want to remove " + getAffiliateName() + "?") == false)
			return false;
		var aid = $(expandedRow).attr('id'); 
		$.post("rest?method=removeAffiliate", {'aid': aid}, function(data, textStatus, xhr) {
			goto('affiliates');
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}
	
	function addUser(){
		resetForm($("#addUserForm"));
		$("#addUserForm input[name='aid']").val($(expandedRow).attr('id'));
		$("#addUserDialog").dialog("open");
	}
	
	$( "#addUserDialog" ).dialog({
		autoOpen: false,
		height: 350,
		width: 450,
		modal: true,
		buttons: {
			"Update": function() {
				var formData = $("#addUserForm").serialize();
				$.post("rest?method=addAffiliateUser", formData, function(data, textStatus, xhr) {
					updateView(data.affiliate);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
	$("a#addAffiliate").click(function(){
		$("#addAffiliateForm").find('input:text, input:password').val('');
		$("#addAffiliateDialog").dialog( "open" );
	});
	
	$( "#addAffiliateDialog" ).dialog({
		autoOpen: false,
		height: 400,
		width: 450,
		modal: true,
		buttons: {
			"Create": function() {
				var formData = $("#addAffiliateForm").serialize();
				$.post("rest?method=addAffiliate", formData, function(data, textStatus, xhr) {
					goto('affiliates', data.affiliate.id);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			//allFields.val( "" ).removeClass( "ui-state-error" );
		}
	});

	function edit(){
		var country = $(expandedRow).find("#acountry").html();
		
		$("#editAffiliateForm input[name='aid']").val($(expandedRow).attr('id'));
		$("#editAffiliateForm input[name='name']").val(getAffiliateName());
		$("#editAffiliateForm select[name='country']").find("option[value='" + country + "']").attr('selected', 'selected');
		$("#editAffiliateDialog").dialog( "open" );
		$("#editAffiliateDialog").dialog( "option", "title", "Modify " + getAffiliateName() + " account");
	}

	$( "#editAffiliateDialog" ).dialog({
		autoOpen: false,
		height: 280,
		width: 460,
		modal: true,
		buttons: {
			"Update": function() {
				var formData = $("#editAffiliateForm").serialize();
				$.post("rest?method=updateAffiliate", formData, function(data, textStatus, xhr) {
					updateView(data.affiliate);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error);
				})

				$(this).dialog( "close" );
				
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
		}
	});

	function quote(){
    	var parent = $("#addQuotaForm #parent").val();
		$.get("rest?method=getQuota&aid="+parent, function(data, textStatus, xhr) {
			resetForm($("#addQuotaForm"));
			$("#addQuotaForm table tbody tr").remove();
			
			var tbody = $("#addQuotaForm table tbody");
			var licenses = data.quota.current;
			for(var i=0;i<licenses.length;i++){
				var row = $("<tr/>").appendTo(tbody);
				var td = $("<td/>").appendTo(row);
				td.addClass(licenses[i].device.toLowerCase());
				td.css("width", "50%");
				td.html(licenses[i].title);
				
				if(currentAffiliate.chain.indexOf("/") != -1){ 
					td = $("<td/>").appendTo(row);
					td.html(licenses[i].amount);
					td.prop("title", "Current amount avialable now");
				}

				td = $("<td/>").appendTo(row);
				td.prop("title", "How much quota to transfer");
				td.css("width", "30%");
				var input = $("<input/>").appendTo(td);
				input.prop("disabled", licenses[i].amount == 0);
				input.prop("type", "text");
				input.prop("id", "amount" + i);
				input.prop("name", "amount." + licenses[i].product + "." + licenses[i].device + "." + licenses[i].access);
				input.css("width", "100%");
			}
			
			// keep track on selection box to enable/disable the fields when claiming or leasing
			$('#addQuotaForm #quotaOperation').change(function() {
				for(var i=0;i<licenses.length;i++){
					if($(this).val() == 'lease')
						$("#amount"+i).prop('disabled', licenses[i].amount == 0);
					else
						$("#amount"+i).prop('disabled', false);
				}
			});
			
			$("#addQuotaForm input[name='aid']").val($(expandedRow).attr('id'));
			$("#addQuotaDialog").dialog( "open" );
			$("#addQuotaDialog").dialog( "option", "title", "Transfer part of my quota to " + getAffiliateName() );
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}

	$( "#addQuotaDialog" ).dialog({
		autoOpen: false,
		height: 620,
		width: 620,
		modal: true,
		buttons: {
			"Transfer": function() {
				var formData = $("#addQuotaForm").serialize();
				$.post("rest?method=changeQuota", formData, function(data, textStatus, xhr) {
					updateView(data.affiliate);
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})

				$(this).dialog( "close" );
			},
			Cancel: function() {
				$(this).dialog( "close" );
			}
		},
		close: function() {
		}
	});
	
   $("a#export").click(function(e){
	   exportThings("affiliates");
   });
	
	function updateView(affiliate){
		// table
		$(expandedRow).find("#achain").html(affiliate.chain);
		$(expandedRow).find("#acountry").html(affiliate.country);
		$(expandedRow).find("#auser").html(affiliate.contact);

		// expanded row  
		buildExpandedRow(affiliate);
		addedRow = oTable.fnOpen(expandedRow, $(expandedRow).find(".expansionPanel").html(), "info_row" );
		hook();
	}
	
	function getAffiliateName(){
		var split = $(expandedRow).find("#achain").html().split("/");
		return split[split.length-1];		
	}
});