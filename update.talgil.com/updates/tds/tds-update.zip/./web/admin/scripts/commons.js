$(function(){
	$( "#myQuotaDialog" ).dialog({
		autoOpen: false,
		height: 500,
		width: 580,
		modal: true,
		buttons: {
			Ok: function() {
				$( this ).dialog( "close" );
			}
		}
	});  
	
	$("a#showMyQuota").click(function(){
		var aid = $("#myQuotaDialog input[name='aid']").val();
		$.get("rest?method=getQuota&aid="+aid, function(data, textStatus, xhr) {
			$("#myQuotaDialog table tbody tr").remove();
			
			var aquota = data.quota.allocated;
			var uquota = data.quota.used;
			var tbody = $("#myQuotaDialog table tbody");
			for(var i=0;i<aquota.length;i++){
				var dt = aquota[i].device.toLowerCase();
				var row = $("<tr/>").appendTo(tbody);
				var td = $("<td/>").appendTo(row);
				td.addClass(dt);
				td.html(aquota[i].title);
				
				td = $("<td/>").appendTo(row);
				td.addClass(dt);
				td.html(aquota[i].amount);

				td = $("<td/>").appendTo(row);
				td.addClass(dt);
				td.html(uquota[i].amount);
			}
			
			$( "#myQuotaDialog" ).dialog( "open" );
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	});
	
	$( "#requestQuotaDialog" ).dialog({
		autoOpen: false,
		height: 625,
		width: 580,
		modal: true,
		buttons: {
			"Submit request": function() {
				var formData = $("#requestQuotaForm").serialize();
				$.post("rest?method=requestQuota", formData, function(data, textStatus, xhr) {
					alert("Your request is submitted, our representative will get in touch with you soon.");
				}, "json")
				.error(function(xhr) { 
					alert(jQuery.parseJSON(xhr.responseText).error); 
				})
	
				$( this ).dialog( "close" );
			},
			Cancel: function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			//allFields.val( "" ).removeClass( "ui-state-error" );
		}
	});
	
	$("a#requestQuota").click(function(){
		$( "#requestQuotaDialog" ).dialog( "open" );
	});
	
	$("#progress").dialog({
		autoOpen: false,
		height: 250,
		width: 500,
		modal: true,
		buttons: {
			"Hide": function() {
				$(this).dialog( "close" );
			},
		},
		close: function() {
		}
	});

	$.fn.serializeObject = function()
	{
		var o = {};
		var a = this.serializeArray();
		$.each(a, function() {
			if (o[this.name] !== undefined) {
				if (!o[this.name].push) {
					o[this.name] = [o[this.name]];
				}
				o[this.name].push(this.value || '');
			} else {
				o[this.name] = this.value || '';
			}
		});
		return o;
	};	
});

function exportThings(things){
	if(!confirm("Export " + things + " data into a file?"))
		return;
	$("#progress .message").html("Generating report, please stand by...");
	$("#progress").dialog( "option", "title", "Progress");
	$("#progress img").show();
	$("#progress").dialog("open");
	
	var search = getQuery(things+".query").search;
  
	$.get("rest?method=export&type="+things+"&search="+search, function(data, textStatus, xhr) {
		$("#progress").dialog( "option", "title", "Done");
		$("#progress .message").html("<a href='" + data.link + "' target='new'>click here to download report</a>");
		$("#progress img").hide();
	}, "json")
	.error(function(xhr) { 
		$("#progress").dialog("close");
		alert(jQuery.parseJSON(xhr.responseText).error); 
		return;
	})
}

function showProgressError(title, xhr){
   $("#progress img").hide();
   $("#progress").dialog( "option", "title", title);
   $("#progress .message").html(xhr.responseText ? 
		                         jQuery.parseJSON(xhr.responseText).error : 
		                         JSON.stringify(xhr));
}

function resetForm(form) {
    $(form).find('input:text, input:password, input:file, select, textarea').val('');
    $(form).find('input:radio, input:checkbox').removeAttr('checked').removeAttr('selected');
}

function getQuery(name){
	try {
		var item = localStorage.getItem(name);
		if(item)
			return JSON.parse(item);
		item = {};
		if(name.includes("billing")){
			item.aid = "";
			item.recursive = "";
			item.ref = "";
			item.from = "";
			item.until =""; 
		}
		else{
			item.search = "";
			item.oid = "";
		}
		return item;
	} catch (e) {
		return {};
	}
}

function keepQuery(name, query){
	try {
		localStorage.setItem(name, JSON.stringify(query, null, 2));
	} catch (e) {
	}
}

function goto(href, oid){
	if(href == 'targets'){
		var query = getQuery("targets.query");
		query.oid = oid || "";
		query.search = query.search || "";
		keepQuery("targets.query", query);
	}
	else if(href == 'users'){
		var query = getQuery("users.query");
		query.oid = oid || "";
		query.search = query.search || "";
		keepQuery("users.query", query);
	}
	else if(href == 'projects'){
		var query = getQuery("projects.query");
		query.oid = oid || "";
		query.search = query.search || "";
		keepQuery("projects.query", query);
	}
	else if(href == 'affiliates'){
		var query = getQuery("affiliates.query");
		query.oid = oid || "";
		query.search = query.search || "";
		keepQuery("affiliates.query", query);
	}

	window.location.href = href;
}
