$(function(){
	$.ajaxSetup ({
		cache: false
	});
	
	var cluster;
	var tid = $("#tid").val();
	var sid = $("#sid").val();
	var lg = $("#longitude").val();
	var lt = $("#latitude").val();
	var controls = $("#controls").val() == "true";
	var navigation = $("#navigation").val();
	var drag = $("#drag").val() == "true";
	var mapType = $("#mapType").val();
	if(!mapType)
		mapType = "terrain";
	
	// the call is made to display area of targets 
	if(!lg && !lt){
		(function showArea(tid){
			$("#map-canvas").html("<p align='center'>locating.., one moment please</p>");
			$.get("/maps/area?sid=" + sid + "&tid=" + tid, function(area, textStatus, xhr) {
				if(!tid){
					displayArea(area);
					return;
				}
				
				var latlng = new google.maps.LatLng(area.center.latitude, area.center.longitude);
				new google.maps.MaxZoomService().getMaxZoomAtLatLng(latlng, function(response) {
					if(response.status == google.maps.MaxZoomStatus.OK)
						area.center.zoom = response.zoom;
					displayArea(area);
				});
			}, "json")
			.error(function(xhr) { 
				$("#map-canvas").html("<p align='center'>" + jQuery.parseJSON(xhr.responseText).error + "</p>");
			})
		})(tid);
	}
	else
	// or to display single location by latitude and longitude
	{
		(function showLocation(){
			$("#map-canvas").html("<p align='center'>locating.., one moment please</p>");
			var latlng = new google.maps.LatLng(lt, lg);
			displayLocation(latlng, 6);
		})();
	}
	
	function displayArea(area){
		$("#map-canvas").empty();
	    var myOptions = {
	            zoom: area.center.zoom,
	            center: new google.maps.LatLng(area.center.latitude, area.center.longitude),
	            mapTypeId: mapType,
	            disableDefaultUI: !controls
	    };
	    var map = new google.maps.Map($('#map-canvas')[0], myOptions);
	    cluster = new MarkerClusterer(map, [], {imagePath: '/geomaps/images/m'});
	    for(i=0; i<area.markers.length; i++)
	    	createMarker(map, area.markers[i], i*5);
	    $("#map-canvas").focus();
	    cluster.resetViewport();
	}

	function displayLocation(latlng, zoom){
		$("#map-canvas").empty();
	    var myOptions = {
	            zoom: zoom,
	            center: latlng,
	            mapTypeId: mapType,
	            disableDefaultUI: !controls
	    };
	    
	    var markerData = {
			location: {latitude: lt, longitude: lg},
			icon: "m1.png",
			tooltip: lt + "<br>" + lg
	    };
	    
		var map = new google.maps.Map($('#map-canvas')[0], myOptions);
		cluster = new MarkerClusterer(map, [], {imagePath: '/geomaps/images/m'});
    	createMarker(map, markerData, 0);
		$("#map-canvas").focus();
		cluster.resetViewport();
	}
	
	function createMarker(map, md, delay){
	    var marker = new google.maps.Marker({
	        position: new google.maps.LatLng(md.location.latitude, md.location.longitude),
	        icon: "/geomaps/images/" + md.icon,
	        tooltip: md.tooltip,
	        draggable: drag,
	        //animation: google.maps.Animation.DROP,
	        md: md
	    });

	    var tooltip = new Tooltip({map: map}, marker);
	    tooltip.bindTo("text", marker, "tooltip");
	    
        google.maps.event.addListener(marker, 'mouseover', function() {
            tooltip.addTip();
            tooltip.getPos2(marker.getPosition());
        });	    
        
        google.maps.event.addListener(marker, 'mouseout', function() {
            tooltip.removeTip();
        });        
		
		if(md.id){
			google.maps.event.addListener(marker, "dragend", function(event) {
				updateTargetLocation(md.id, event.latLng.lat(), event.latLng.lng());
			}); 		    
			
			google.maps.event.addListener(marker, "rightclick", function(event) {
				if(typeof(sendNSCommand) === "function"){ 
					sendNSCommand(md.id);
				}
				else{
					new google.maps.MaxZoomService().getMaxZoomAtLatLng(marker.getPosition(), function(response) {
						map.setZoom(8);
						if(response.status == google.maps.MaxZoomStatus.OK)
							map.setZoom(response.zoom-2);
						map.setCenter(marker.getPosition());
					});
				}
			});
	    
			google.maps.event.addListener(marker, "click", function(event) {
				$.get("/maps/info?sid="+sid + "&tid=" + marker.md.id+"&navigation="+navigation, function( data ) {
					$("#portal").html(data);
					$("#portalDialog").dialog("option", "title", marker.md.title);
					$("#portalDialog").dialog("open");
				})
				.error(function(xhr) {
					alert(jQuery.parseJSON(xhr.responseText).error); 
				});
			}); 
		}
	    
//    	setTimeout(function() {
//    		marker.setMap(map);
//        }, delay);
	    marker.setMap(map);    	
    	cluster.addMarker(marker, false);
	}
	
	function updateTargetLocation(tid,lat,lng){
		$.post("/maps/setTargetLocation?tid=" + tid + "&latitude=" + lat + "&longitude=" + lng, null, function(data, textStatus, xhr) {
			
		}, "json")
		.error(function(xhr) { 
			alert(jQuery.parseJSON(xhr.responseText).error); 
		})
	}
	
	$("#portalDialog").dialog({
		autoOpen: false,
        height: 360,
        width: 400,
		modal: true,
		buttons: {
			"Close": function() {
				$(this).dialog( "close" );
			}
		},
		open: function() {
		     $(this).closest('.ui-dialog').find('.ui-dialog-buttonpane button:eq(0)').focus();
		},
		close: function() {
		}
	});
	
});