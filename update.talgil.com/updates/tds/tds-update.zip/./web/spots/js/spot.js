$(document).ready(function() {
	$.ajaxSetup ({
	    cache: false
	});

	var spotHomePage = "/spot/targets";
	var currentActions = 0; 
	var refreshBusy = false;
	var spotFontSize = $.cookie('spot.fontSize');
	if(spotFontSize){
		$("body").css("font-size", spotFontSize == "normal" ? "15px" : spotFontSize);
	}
	
	var progress = new BootstrapDialog({
		title: '',
        message: 'Please stand by',
        closable: false,
        autospin: true
	});

	$('#loginForm').submit(function() {
		$('#signin').html("<i class='fa fa-hand-o-right fa-spin'></i> one moment please...");
		$('#signin').prop('disabled', true);
		var formData = $('#loginForm').serialize();
		$.post("/spot/loginForm", formData, function(data, textStatus, xhr) {
			if(data.rc != 0){
				failed(data.message);
				$('#signin').html("<i class='fa fa-hand-o-right'></i> Sign in");
				$('#signin').prop('disabled', false);
				return;
			}
			
			window.location.href = spotHomePage;
			
		}, "json")
		.error(function(xhr) {
			error(xhr);
			$('#signin').html("<i class='fa fa-hand-o-right'></i> Sign in");
			$('#signin').prop('disabled', false);
		})
	   
	   return false;
	});

	$('body').on('click', "a[href$='impersonate']", function(event) {
		BootstrapDialog.show({
            onshown: function(dlg){
            	var input = "keys=web.common.yes,web.common.no,web.common.cancel,web.cmd.confirm,web.msg.21";
        		$.get("/spot/translate", input, function(data, textStatus, xhr) {
        			var translation = data.translation;
                	dlg.getButton('b1').html(translation[0]);
                	dlg.getButton('b2').html(translation[1]);
                	dlg.getButton('b3').html(translation[2]);
                	dlg.setTitle(translation[3]);
                	dlg.setMessage(translation[4]);
        		}, "json")
        		.error(function(xhr) {
        			dlg.close();
        			error(xhr);
        		})
            },
            buttons: [{
            	id: "b1",
                action: function(dlg){
                	dlg.close();
                	impersonate();
                }
            }, {
            	id: "b2",
                action: function(dlg){
                	dlg.close();
                	window.location.href = "/spot/implist";
                }
            }, {
            	id: "b3",
                action: function(dlg){
                	dlg.close();
                }
            }]
        });
		
		return false;
	});
	
	function impersonate(){
		BootstrapDialog.show({
            message: "<input type='text' class='form-control impusers hide' data-provide='typeahead' placeholder='start typing user name here'>",
            onshown: function(dlg){
            	var input = dlg.getModalBody().find(".impusers");
        		$.get("/spot/getImps", function(data, textStatus, xhr) {
        			input.typeahead({source: data});
        			input.removeClass('hide');
        			input.show();
        			input.focus();
        			
                	var keys = "keys=web.common.imperonate,web.common.cancel,web.msg.20";
            		$.get("/spot/translate", keys, function(out, textStatus, xhr) {
            			var translation = out.translation;
                    	dlg.getButton('b1').html(translation[0]);
                    	dlg.getButton('b2').html(translation[1]);
                    	dlg.setTitle(translation[2]);
            		}, "json")
            		.error(function(xhr) {
            			dlg.close();
            			error(xhr);
            		})
        			
        		}, "json")
        		.error(function(xhr) {
        			dlg.close();
        			error(xhr);
        		})
            },
            buttons: [{
                id: 'b1',
                cssClass: 'btn-primary',
                hotkey: 13,
				action: function(dlg){
					dlg.enableButtons(false);
					var username = dlg.getModalBody().find('input').val();
					$.get("/spot/impersonate?username=" + username, function(data, textStatus, xhr) {
						dlg.close();
						if(xhr.responseJSON != null && xhr.responseJSON.rc != 0){
							failed(xhr.responseJSON.message);
							return;
						}
						
						window.location.href = spotHomePage;
					}, "json")
					.error(function(xhr) {
						dlg.close();
						error(xhr);
					})
				}
            },{
				id: 'b2',
				action: function(dlg){
					dlg.close();
				}
            }]
        });		
	}

	$('body').on('click', "a[href$='preload']", function(event) {
		BootstrapDialog.show({
            onshown: function(dlg){
            	var input = "keys=web.common.yes,web.common.no,web.common.cancel,web.cmd.confirm,web.msg.22";
        		$.get("/spot/translate", input, function(data, textStatus, xhr) {
        			var translation = data.translation;
                	dlg.getButton('b1').html(translation[0]);
                	dlg.getButton('b2').html(translation[1]);
                	dlg.getButton('b3').html(translation[2]);
                	dlg.setTitle(translation[3]);
                	dlg.setMessage(translation[4]);
        		}, "json")
        		.error(function(xhr) {
        			dlg.close();
        			error(xhr);
        		})
            },
            buttons: [{
            	id: "b1",
                action: function(dlg){
                	dlg.close();
                	preload();
                }
            }, {
            	id: "b2",
                action: function(dlg){
                	dlg.close();
                	window.location.href = "/spot/tlist";
                }
            }, {
            	id: "b3",
                action: function(dlg){
                	dlg.close();
                }
            }]
        });
		
		return false;
	});
	
	function preload(){
		BootstrapDialog.show({
            title: "Controller to add",
            message: "<input type='text' class='form-control targets hide' data-provide='typeahead' placeholder='start typing controller serial number or name...'>",
            onshown: function(dlg){
            	var input = dlg.getModalBody().find(".targets");
        		$.get("/spot/listTargets", function(data, textStatus, xhr) {
        			input.typeahead({source: data});
        			input.removeClass('hide');
        			input.show();
        			input.focus();
        			
                	var keys = "keys=web.common.preload,web.common.cancel,web.msg.6";
            		$.get("/spot/translate", keys, function(out, textStatus, xhr) {
            			var translation = out.translation;
                    	dlg.getButton('b1').html(translation[0]);
                    	dlg.getButton('b2').html(translation[1]);
                    	dlg.setTitle(translation[2]);
            		}, "json")
            		.error(function(xhr) {
            			dlg.close();
            			error(xhr);
            		})
        			
        		}, "json")
        		.error(function(xhr) {
        			dlg.close();
        			error(xhr);
        		})
            },
            buttons: [{
                id: 'b1',
                cssClass: 'btn-primary',
                hotkey: 13,
				action: function(dlg){
					dlg.enableButtons(false);
					var serial = dlg.getModalBody().find('input').val();
					$.get("/spot/preload?target=" + serial, function(data, textStatus, xhr) {
						dlg.close();
						if(xhr.responseJSON != null && xhr.responseJSON.rc != 0){
							failed(xhr.responseJSON.message);
							return;
						}
						
						window.location.href = spotHomePage;
					}, "json")
					.error(function(xhr) {
						dlg.close();
						error(xhr);
					})
				}
            },{
				id: 'b2',
				action: function(dlg){
					dlg.close();
				}
            }]
        });
		
		return false;
	}
	
	$('body').on('click', "a[href$='resetPassword'], a[href$='prefs'], a[href*='field?'], a[href*='io/manual?uid'], a[href*='programs/add'], a[href*='clearAlarm'], .spot-action", function(e) {
		promptAndPost(findClickedHref(e), true);
		return false;
	});

	$('body').on('click', "a[href$='support']", function(e) {
		promptAndPost(findClickedHref(e));
		return false;
	});
	
	function promptAndPost(href, hotkey){
		$('<div></div>').load(href, function(response, status, xhr){
			if(status == "success"){
				doPromptAndPost(href, hotkey, response);
				return;
			}
			
			$('<div></div>').load(href, function(response, status, xhr){
				if(status == "success")
					doPromptAndPost(href, hotkey, response);
				else
					failed("Request may not be handled at this time...");
			});
				
		});
	}
	
	function doPromptAndPost(href, hotkey, formBody){
		//currentActions++;
		BootstrapDialog.show({
            title: "",
            message: $('<div></div>').append(formBody),
            onshown: function(dlg){
            	form = dlg.getModalBody().find('form');
            	dlg.setTitle(form.attr("name"));
            	dlg.getButton('b1').html(form.attr("data-button1"));
            	dlg.getButton('b2').html(form.attr("data-button2"));
            	
            	// this prevents the form to react to enter key
            	form.find("input").on('keypress', function(e) {
            	    return e.which !== 13;
            	});
            	
            	// this will select the first input element
            	input = form.find("input[type!='hidden']")[0];
            	if(input != undefined){
            		$(input).focus().select();
            	}
            	
            },
            buttons: [{
            	id: "b1",
                cssClass: 'btn-primary',
                hotkey: hotkey ? 13 : -1,
				action: function(dlg){
					dlg.enableButtons(false);
					form = dlg.getModalBody().find('form');
					var formData = form.serialize();
					$.post(href, formData, function(data, textStatus, xhr) {
						//currentActions--;
						if(data.rc > 0){
							var prevTitle = dlg.getTitle(); 
							var prevType = dlg.getType();
							dlg.setTitle(data.message);
							dlg.setType(BootstrapDialog.TYPE_DANGER);
							setTimeout(function(){
								dlg.setTitle(prevTitle);
								dlg.setType(prevType);
								dlg.enableButtons(true);
							}, 2000);
							return;
						}
						
						dlg.close();
						if(data.redirect)
							promptAndPost(data.redirect);
						else if(data.href)
							window.location.href = data.href;
						else if(data.confirmation)
							info(data.message);
						else
							window.location.reload();
					}, "json")
					.error(function(xhr) {
						//currentActions--;
						dlg.close();
						error(xhr);
					})
				}
            },{
            	id: "b2",
				action: function(dlg){
					// currentActions--;
					dlg.close();
				}
            }]
        });				
	}
	
	$('body').on('click', "a[href*='io/toggle']", function(e) {
		if(refreshBusy){
			// to prevent race conditions with slow connections when refresh is in progres 
			return false;
		}
		
		currentActions++;
		var link = findLink(e);
		var td = link.closest("td");
		var original = td.html(); 
		link.hide();
		td.append("<i class='fa fa-wrench fa-spin text-info'></i>");
		$.post(link.attr("href"), null, function(data, textStatus, xhr) {
			td.html(data.html);
			currentActions--;
		}, "json")
		.error(function(xhr) {
			currentActions--;
			td.html(original);
			error(xhr);
		})
		return false;
	});
	
	$('body').on('click', "a[href*='commands']", function(e) {
		var link = findLink(e);
		
		BootstrapDialog.show({
            title: link.attr("data-title"),
            message: link.attr("data-message"),
            closable: false,
            buttons: [{
            	label: link.attr("data-yes"),
                cssClass: 'btn-primary',
                hotkey: 13,
				action: function(dlg){
					currentActions++;
					dlg.enableButtons(false);
					dlg.setTitle("  ");
					dlg.setMessage("<i class='fa fa-fw fa-2x fa-wrench text-info fa-spin'></i><span>&nbsp;&nbsp;&nbsp;" + link.attr("data-progress"));
					$.post(link.attr("href"), null, function(data, textStatus, xhr) {
						currentActions--;
						dlg.close();
						if(data.rc != 0)
							failed(data.message);
						else if(data.redirect)
							window.location.href = data.redirect; 
						else
							window.location.reload();
						
					}, "json")
					.error(function(xhr) {
						currentActions--;
						dlg.close();
						error(xhr);
					})
				}
            },{
            	label: link.attr("data-no"),
				action: function(dlg){
					dlg.close();
				}
            }]
        });
		return false;
	});
	
	$('body').on('click', "a[href*='resetRunList']", function(e) {
		var href = findClickedHref(e);
		progress.open();
		progress.setMessage('Connecting, please stand by...');
		
		$.post(href, null, function(data, textStatus, xhr) {
			progress.close();
			window.location.reload();
		}, "json")
		.error(function(xhr) {
			progress.close();
			error(xhr);
		})
		return false;
	});

	$('body').on('click', "a[href*='toggleDay']", function(e) {
		var link = findLink(e);
		var href = findClickedHref(e);
		var td = link.closest("td");
		
		progress.open();
		progress.setMessage('Updating, please stand by...');
		
		$.get(href, function(data, textStatus, xhr) {
			progress.close();
			td.html(data.html);
			if(data.rc != 0)
				failed(data.error);
				
		}, "json")
		.error(function(xhr) {
			progress.close();
			error(xhr);
		})
		return false;
	});
	
	$('body').on('click', "a[href*='help']", function(e) {
		var href = findClickedHref(e);
		$.get(href, function(data, textStatus, xhr) {
			BootstrapDialog.show({
	            title: "Help",
	            message: $("<div>"+data.help+"</div>"),
	            buttons: [{
					label: 'Close',
					action: function(dlg){
						dlg.close();
					}
	            }]
	        });
			
		}, "json")
		.error(function(xhr) {
			failed(xhr);
		})
		return false;
	});
	function info(m){
		showAlert(BootstrapDialog.TYPE_SUCCESS, "OK", m);
	}
	function failed(m){
		showAlert(BootstrapDialog.TYPE_DANGER, "", m);
	}
	function error(xhr){
		if(xhr.status == 200){
			json = jQuery.parseJSON(xhr.responseText);
			showAlert(BootstrapDialog.TYPE_DANGER, "Failed", json.message);
		}
		else{
			showAlert(BootstrapDialog.TYPE_DANGER, "Failed server call " + xhr.status, "Please try again...");
		}
	}
	function showAlert(at, t, m){
       BootstrapDialog.alert({
            title: t,
            message: m,
            type: at,
            closable: true,
            closeByKeyboard: true
        });		
	}
	function findLink(event){
		var link = $(event.target);
		if(!link.attr("href")){
			link = link.parent();
			if(!link.attr("href"))
				link = link.parent();
		}
		return link; 
	}
	function findClickedHref(event){
		var link = findLink(event);
		return link ? link.attr("href") : "#"; 
	}
	
	/*
	 * automatic updates of specified content
	 */
	var updateable = $('[data-update-url]');
	var updateStart = new Date().getTime();
	if(typeof updateable.attr("data-update-url") != 'undefined' && typeof updateable.attr("data-interval") != 'undefined'){
		setTimeout(updateContent, updateable.attr("data-interval"));
	}
	else{
		$("#spot-update-indicator").hide();
	}
	
	function updateContent(){
		if(currentActions > 0){
			setTimeout(updateContent, updateable.attr("data-interval"));
			return;
		}

		refreshBusy = true;
		
		$("#spot-update-indicator").pulse({times: 2, duration: 300});
		$('<div></div>').load(updateable.attr("data-update-url"), function(response, status, xhr){
			refreshBusy = false;
			
			// this heder will be set when was redirected to login form
			// stop the timer now
			var rh = xhr.getResponseHeader('Location');
			if(rh != null && rh.indexOf("login") != -1){
				updateable.html("<div class='text-danger m-l-large m-b-large m-t-large text-center-sm'>content not available</div>");
				return;
			}
			
			if(status == "success"){
				updateable.html(response);
				
				// stop auto-updates after 1 hour
				var updateTime = new Date().getTime() - updateStart;
				if(updateTime > 60*60*1000)
					return;
				
				// reduce rate after 15 minutes, otherwise use specified rate
				setTimeout(updateContent, (updateTime > 15*60*1000) ? 60000 : updateable.attr("data-interval"));
			}
			else if(xhr.status == 404){
				window.location.href = spotHomePage;
			}
			else{
				updateable.html("<div class='text-danger m-l-large m-b-large m-t-large text-center-sm'>content not available</div>");
			}
		});
	}
	
	$.fn.pulse = function(options) {
	    var options = $.extend({
	        times: 3,
	        duration: 200
	    }, options);

	    var period = function(callback) {
	        $(this).animate({opacity: 1}, options.duration, function() {
	            $(this).animate({opacity: 0}, options.duration, callback);
	        });
	    };
	    return this.each(function() {
	        var i = +options.times, self = this,
	        repeat = function() { --i && period.call(self, repeat) };
	        period.call(this, repeat);
	    });
	};	
	
	/*
	 * date range selectors 
	 */
	var fromDate, untilDate;
	if(initDatesRange()){
		var fd = $('.from-date').click(function(e){
			e.preventDefault();
			fd.datepicker("setStartDate", null);
			fd.datepicker("setEndDate", untilDate);
			fd.datepicker("show");
		}).datepicker({
			autoclose: true,
			todayHighlight: true,
			format: 'dd MM',
			startDate: null,
			endDate: untilDate,
			beforeShowDay: highlightDate
		}).on("changeDate", function(e){
			fromDate = e.date;
			fd.html(fromDate.getDate() + "/" + (fromDate.getMonth()+1));
			fd.datepicker("hide");
			
			// important - server needs UTC time!
			window.location.href = $('.from-date').attr("href") +
							            "&from=" + utcTime(fromDate) + 
							            "&until=" + utcTime(untilDate);
		});	
	
		var ud = $('.until-date').click(function(e){
			e.preventDefault();
			ud.datepicker("setStartDate", fromDate);
			ud.datepicker("setEndDate", new Date());
			ud.datepicker("show");
		}).datepicker({
			autoclose: true,
			todayHighlight: true,
			fortmat: 'dd MM',
			startDate: fromDate,
			endDate: untilDate,
			beforeShowDay: highlightDate
		}).on("changeDate", function(e){
			untilDate = e.date; 
			ud.html(untilDate.getDate() + "/" + (untilDate.getMonth()+1));
			ud.datepicker("hide");

			// important - server needs UTC time!
			window.location.href = $('.until-date').attr("href") +
			                       "&from=" + utcTime(fromDate) + 
			                       "&until=" + utcTime(untilDate);
		});
	}
	
	function initDatesRange(){
		// server returns the range submitted in UTC
		// to init calendar view, we offset to local time because
		// widget works in local time
		now = new Date();
		offset = now.getTimezoneOffset()*60*1000;
		value = $('.from-date').attr("data-from");
		fromDate = now;
		if(value > 0)
			fromDate = new Date(parseInt(value,10)+offset);
		
		value = $('.until-date').attr("data-until");
		untilDate = now;
		if(value > 0)
			untilDate = new Date(parseInt(value,10)+offset);
		return true;
	}
	
	function highlightDate(date){
		if(date.getTime() >= fromDate.getTime() && date.getTime() <= untilDate.getTime()){
			return {classes: 'bg-light'};
		}
	}
	
	 function utcTime(date) {
	     utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), 
	    		          date.getDate(), date.getHours(),
	    		          date.getMinutes(), date.getSeconds()));
	     return utcDate.getTime();
	 }	
	
});