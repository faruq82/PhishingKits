var clicky_site_ids = clicky_site_ids || [];
clicky_site_ids.push(100886365);
(function() {
  if(typeof clicky_custom == 'undefined')
	  return;
  if(clicky_custom.visitor.username == 'null' || clicky_custom.visitor.username == '' || clicky_custom.visitor.username == 'not logged in')
	  return;
  var s = document.createElement('script');
  s.type = 'text/javascript';
  s.async = true;
  s.src = '//static.getclicky.com/js';
  ( document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0] ).appendChild( s );
})();