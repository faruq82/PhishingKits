$(function(){
	$.ajaxSetup ({
	    cache: false
	});
	
	var spotFontSize = $.cookie('spot.fontSize');
	if(spotFontSize){
		$("body").css("font-size", spotFontSize == "normal" ? "15px" : spotFontSize);
	}

	/*
	 * date range selectors 
	 */
	var fromDate, untilDate;
	initDatesRange();
	displayChart();
	
	var fd = $('.from-date').click(function(e){
		e.preventDefault();
		fd.datepicker("setStartDate", null);
		fd.datepicker("setEndDate", untilDate);
		fd.datepicker("show");
	}).datepicker({
		autoclose: true,
		todayHighlight: true,
		format: 'dd MM',
		startDate: null,
		endDate: untilDate,
		beforeShowDay: highlightDate
	}).on("changeDate", function(e){
		fromDate = e.date;
		fd.html(fromDate.getDate() + "/" + (fromDate.getMonth()+1));
		fd.datepicker("hide");
		displayChart();
	});	

	var ud = $('.until-date').click(function(e){
		e.preventDefault();
		ud.datepicker("setStartDate", fromDate);
		ud.datepicker("setEndDate", new Date());
		ud.datepicker("show");
	}).datepicker({
		autoclose: true,
		todayHighlight: true,
		fortmat: 'dd MM',
		startDate: fromDate,
		endDate: untilDate,
		beforeShowDay: highlightDate
	}).on("changeDate", function(e){
		untilDate = e.date; 
		ud.html(untilDate.getDate() + "/" + (untilDate.getMonth()+1));
		ud.datepicker("hide");
		displayChart();
	});
	
	function initDatesRange(){
		if($('.from-date') == undefined || $('.until-date') == undefined)
			return false;
		
		// server returns the range submitted in UTC
		// to init calendar view, we offset to local time because
		// widget works in local time
		now = new Date();
		offset = now.getTimezoneOffset()*60*1000;
		value = $('.from-date').attr("data-from");
		fromDate = now;
		if(value > 0)
			fromDate = new Date(parseInt(value,10)+offset);
		
		value = $('.until-date').attr("data-until");
		untilDate = now;
		if(value > 0)
			untilDate = new Date(parseInt(value,10)+offset);
		return true;
	}
	
	function highlightDate(date){
		if(date.getTime() >= fromDate.getTime() && date.getTime() <= untilDate.getTime()){
			return {classes: 'bg-light'};
		}
	}
	
	 function utcTime(date) {
	     utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), 
	    		          date.getDate(), date.getHours(),
	    		          date.getMinutes(), date.getSeconds()));
	     return utcDate.getTime();
	 }	
	
	function displayChart(){
		// important - server needs UTC ranges because local time is shifted by caledar
		$("#chart").empty();
		$("#chart").html("<br><br><div class='m-t-large text-center h5'><i class='fa fa-fw fa-2x fa-umbrella text-info fa-spin'></i><span>&nbsp;&nbsp;&nbsp;loading, please stans by..</div>");
		var url = "obs?from=" + utcTime(fromDate) + "&until=" + utcTime(untilDate);
		$.get(url, function(data, textStatus, xhr) {
			plot(data.datasets);
		}, "json")
		.error(function(xhr) { 
			$("#chart").html("error getting data series");
		})		
	}
	
	function plot(datasets){
		if(datasets.length == 0){
			$("#chart").html("<br><br><div class='m-t-large text-center h5'><i class='fa fa-fw fa-2x fa-ban text-danger'></i><span>&nbsp;&nbsp;&nbsp;no data in this time range</div>");
			return;
		}
		
		var input = new Array();
		for(i=0; i<datasets.length; i++){
			input.push({
				type : 'line',
				name : datasets[i].name + " (" + datasets[i].units + ")",
				data : datasets[i].series,
				tooltip: {
					valueDecimals: 2
				}
			});
		}
		
		// 8 hours preset zoom
		//var xmin = input[0].data[0][0];
		//var xmax = xmin + 8 * 60 * 60 * 1000;
		
		var chart = new Highcharts.StockChart({
	        chart: {
	        	defaultSeriesType: 'spline',
	        	zoomType: 'x',
	        	renderTo: 'chart'
	        },				
			credits: {
	            enabled: false
	        },				
			title : {
				text : ''
			},
			subtitle : {
				text : ''
			},
	        xAxis: {
	      //  	min: xmin,
	      //  	max: xmax,
	            type: 'datetime',
	        },
	        yAxis: {
	            title: {
	                text: ''
	            }
	        },		
            rangeSelector: {
            	enabled:false,
            },
            navigator: {
                enabled: false
            },
            tooltip: {
                crosshairs: {
                    color: 'green',
                    dashStyle: 'solid'
                },
                shared: true,
                useHTML: true
            },            
			series : input
		});
	}
	
	
	$('body').on('click', "a[href$='getSensors']", function(e) {
		var link = $(e.target);
		if(!link.attr("href")){
			link = link.parent();
			if(!link.attr("href"))
				link = link.parent();
		}
		
		BootstrapDialog.show({
            title: "",
            message: $('<div></div>').load(link.attr("href")),
            onshown: function(dlg){
            	var form = dlg.getModalBody().find('form');
            	dlg.setTitle(form.attr("name"));
            	dlg.getButton('b1').html(form.attr("b1"));
            	dlg.getButton('b2').html(form.attr("b2"));
            },
            buttons: [{
            	id: "b1",
                label: 'Save',
                cssClass: 'btn-primary',
                hotkey: 13,
				action: function(dlg){
					dlg.enableButtons(false);
					var form = dlg.getModalBody().find('form');
					$.post(form.attr("action"), form.serialize(), function(data, textStatus, xhr) {
						dlg.close();
						$('.titlenav').html(data.title);
						plot(data.datasets);
					}, "json")
					.error(function(xhr) {
						dlg.enableButtons(true);
					})
				}
            },{
            	id: "b2",
				label: 'Cancel',
				action: function(dlg){
					dlg.close();
				}
            }]
        });
		
		return false;
	});
		
});